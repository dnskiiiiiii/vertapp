# How Vert is built

A map of the whole system for someone opening this repository for the first time. It describes the code as of **8 November 2026**. File paths are relative to the repository root, and every claim here was checked against the code that day.

**Start here if you only have ten minutes:** read [What Vert is](#what-vert-is), look at the [system diagram](#the-system-at-a-glance), then follow [one chat question end to end](#one-question-end-to-end).

---

## What Vert is

Vert helps an accountant close a company's month. It connects to the company's books (Xero first, QuickBooks partly), reads the ledger, bank lines, bills and payouts, and then:

- **reconciles**: bank accounts, payment-processor payouts (Stripe), clearing accounts and supplier statements;
- **drafts the entries**: journals, accruals, prepaid and depreciation schedules, bad-debt write-offs and coded bank lines;
- **answers in a chat that shows its working**: tables, tie-outs to the general ledger, and journal-entry cards the accountant approves before anything is posted to Xero.

Two rules shape the whole codebase:

1. **The AI never makes up a number.** Every figure comes from deterministic, cents-exact code. The model writes placeholders, and the system refuses any figure a tool did not return (see [the agent](#the-agent-vert_agent)).
2. **Nothing reaches the books without a person approving it.** The AI proposes; a person approves; then the system posts.

---

## The repository

| Folder | What it is | Language | Size |
|---|---|---|---|
| [`vert-engine/`](vert-engine/) | Everything server-side: the accounting core, the AI agent, the HTTP API, the integrations, the database schema | Python 3.12 | ~1,300 source files, ~1,230 test files |
| [`vert-demo/`](vert-demo/) | The web app the accountant uses | Next.js 16, React 19, plain JavaScript | ~407 test files |

`vert-demo` is a historical name: it started in August as a demo that rendered the engine's output, and grew into the product. Both folders were separate repositories until 8 Nov 2026; their full histories are kept here.

The folder names matter. The web tests read engine source through `../vert-engine/...` to check that the two sides agree on event names, statuses and vocabulary.

---

## The system at a glance

```mermaid
flowchart LR
    A["Accountant<br/>(browser)"] --> W

    subgraph Vercel
      W["<b>vert-platform</b><br/>Next.js web app<br/><i>vert-demo/</i>"]
      API["<b>vert-api</b><br/>FastAPI + the agent<br/><i>vert-engine/</i>"]
      S["<b>vert-sync</b><br/>sync worker<br/><i>vert-engine/vert_connect</i>"]
    end

    W -- "server-side only,<br/>with the user's API key" --> API
    W -- "Sync now" --> S
    API --> DB[("Postgres<br/>one row-level-security<br/>policy per tenant")]
    S --> DB
    API -- "litellm" --> LLM["Claude<br/>(Anthropic)"]
    API -- "post journals, bills,<br/>invoices, bank coding" --> X["Xero"]
    S -- "read ledger, bank,<br/>payroll, budgets" --> X
    S -- "read payouts" --> ST["Stripe"]
    C["pg_cron<br/>(hourly)"] -- "GET /cron/tick" --> API
```

| Deployment | Built from | Entry point |
|---|---|---|
| `vert-platform` | `vert-demo/` | Next.js (`vercel.json` sets region `syd1`) |
| `vert-api` | `vert-engine/` with `vercel.staging.json` | `api_staging/index.py` |
| `vert-sync` | `vert-engine/` with `vercel.sync-staging.json` | `api/sync_staging.py` |

Despite the `staging` in their names, those two config files are what production runs today. `vert-engine/vercel.json` (entry `api/index.py`) is the older production config.

The browser never talks to the API directly. Every call goes through the Next.js server, which adds the user's credentials.

---

## One question, end to end

What happens when the accountant types *"reconcile the ANZ account for October"*:

```mermaid
sequenceDiagram
    participant B as Browser
    participant N as Next.js server<br/>(vert-demo)
    participant A as vert-api<br/>(vert_api)
    participant G as Agent<br/>(vert_agent/chat)
    participant E as Deterministic core<br/>(vert_engine)
    participant D as Postgres
    participant X as Xero

    B->>N: send message (server action)
    N->>A: POST /agent/sessions/{id}/messages<br/>with the user's API key
    A->>D: queue the turn (agent_turns)
    A->>G: run the turn inline
    loop until the answer is complete
        G->>G: model picks a tool
        G->>E: e.g. get_bank_rec_report
        E->>D: read the tenant's ledger mirror
        E-->>G: exact figures + references
    end
    G->>G: fill figure placeholders from tool results<br/>(refuses any figure no tool returned)
    G->>D: append events (answer, tables, cards)
    B->>N: EventSource /api/agent/sessions/{id}/events
    N->>A: proxy the SSE stream
    A-->>B: events stream into the chat
    Note over B: accountant approves a journal card
    B->>N: approve → post
    N->>A: journal routes (segregation of duties checked)
    A->>D: record approval
    A->>X: POST /ManualJournals (draft or posted)
```

The stream reconnects on its own (each SSE connection is closed after 25 s and resumed from the last event number), and the browser falls back to polling every 1.5 s if streaming fails twice (`vert-demo/lib/agent/stream-state.js`).

---

## The engine (`vert-engine/`)

The packages, and which may import which:

```mermaid
flowchart TD
    connect["vert_connect<br/>vendor clients, sync worker<br/>(holds credentials)"] --> api
    connect --> agent
    connect --> core
    api["vert_api<br/>FastAPI, 38 routers"] --> agent
    api --> core
    agent["vert_agent<br/>model layer, chat agent, critic"] --> core
    bench["vert_bench<br/>benchmark"] --> core
    core["vert_engine<br/>deterministic core<br/>no network, no clock, no LLM"]
```

`vert_api` is forbidden from importing `vert_connect`, and `vert_engine` may not import any HTTP library. Tests enforce both rules: `tests/test_boundary.py` and `tests/test_deployment_boundaries.py`.

### `vert_engine/`: the deterministic core

Pure, cents-exact functions. The agent's entry points are listed in `vert_engine/tools.py`.

- **Reconciliation:**
  - `decomposition.py` checks a payout's integrity: the transactions must sum to the payout.
  - `matching.py` and `txn_matching.py` match payouts and bank lines to invoices and bills.
  - Also `bank_reconciliation.py`, `gl/reconciliation.py` and `clearing/` (the clearing-account zero test).
- **Journal entries:** `journal.py` builds draft entries. `posting/xero.py` posts them as a Xero ManualJournal (draft or posted, chosen per client). Posting is idempotent through a `vert:<sha1>` tag in the narration.
- **Workflows:** `workflows/registry.py` discovers the templates in `workflows/templates/`, among them:
  - schedules: `accrual_schedule`, `amortization_schedule`, `deferred_revenue`;
  - reconciliations: `fixed_asset_rollforward`, `gl_reconciliation`, `card_reconciliation`, `payroll_reconciliation`, `clearing_accounts`;
  - analysis: `flux_analysis`, `budget_vs_actual`, `management_commentary`, `unusual_balances`, `misclassification_scan`, `pnl_trend`;
  - entries: `payroll_journal`, `reverse_entry`, and others.

  The month-close checklist is `template_au.CLOSE`.
- **Work papers:** `workpapers/` writes Excel (openpyxl) and PDF; the month-end pack is `/close/{period}/pack.xlsx|.pdf`.
- **State:** `state/` holds the database layer (see [the database](#the-database)).
- **Tenancy and auth:** `tenancy/` covers API keys, roles and segregation of duties: the person who drafted an entry cannot approve or post it.
- **Also here:** `documents/` (PDF, spreadsheet and OCR reading), `ingestion/` (bank statement CSV and PDF import, Stripe and Shopify adapters), `statements/` (P&L and balance sheet), `scheduled_tasks/` (daily, weekly and monthly routines).

### `vert_api/`: the HTTP service

- **App:** `app.py` builds the FastAPI app. `main.py`'s `build()` is the only place on the request path that reads environment variables.
- **Routers:** 38 in `routers/`, among them:
  - the chat: `agent`;
  - the close: `close`, `month_close`, `journal`, `approvals`, `reports`, `ledger`, `bank`, `cash-coding`;
  - payables and receivables: `bills`, `reminders`, `write-offs`;
  - other work: `scheduled`, `documents`, `schedules`, `fixed-assets`;
  - accounts: `connections`, `firm`, `signup`.

  `signup` is the only public route.
- **Auth:** an API key (`vk_live_…` or `vk_test_…`) is checked against a stored hash. `X-Vert-Client` lets a person key switch between clients, and `X-Vert-Actor` names who acted.
- **Tenant isolation is Postgres row-level security:**
  - every business table has a forced RLS policy keyed on `vert_current_tenant()`;
  - that function raises an error if no tenant is set, rather than returning nothing;
  - `state/pg_store.py` sets the tenant at the start of every transaction.
- **Speed:** `close_reads.py` lets concurrent requests share one read of the same month. That read was the main CPU cost.
- **Account suggestions for bank lines:** `coding_suggest.py` asks a cheap model (the bills tier, never the chat's model) to suggest an account for bank lines that no rule or history codes. The engine checks each answer against the client's own chart of accounts and caps it at "medium" confidence, so a suggestion is never coded automatically: a person presses Code. It makes one call per listing, with a daily cap per tenant, and `VERT_CODING_SUGGEST=0` turns it off.

### `vert_agent/`: the agent

- **The chat agent:** `chat/agent.py` runs the loop, and `chat/loop.py` runs it as a worker. In production the turn runs inside the API request (`VERT_AGENT_INLINE=1`, `vert_api/inline_chat.py`).
- **Tools:** about 50, defined in `chat/tools.py` and its sibling modules, for example:
  - reads: `get_close`, `get_bank_rec_report`, `get_account_activity`, `aged_balances`, `get_gst_report`, `get_financial_statements`;
  - documents: `read_document`, `extract_tables`;
  - drafts: `draft_bad_debt`, `draft_payment_reminders`, `draft_sales_invoice`;
  - other: `process_bills`, `reconcile_supplier_statement`, `run_task`, `ask_clarification`, `compute`.
- **No made-up numbers:** the model writes `{{fig:<ref>}}` instead of numbers. `chat/bind.py` fills them from tool results, and turns any figure no tool returned into a visible "couldn't tell".
- **The critic:** `critic.py` sees only the claim and the source records, never the agent's reasoning. It can flag a note, a question or a concern; it cannot block.
- **Writes:** the agent itself only writes events and proposals. Anything that changes the books is an *action card* (approve, post, reverse, sync…) that the person presses. The card then runs through the normal API routes and their checks.
- **Models:** called through litellm (`transports/litellm_transport.py`), chosen by `VERT_MODEL_NAME`, `VERT_CRITIC_MODEL_NAME` and `VERT_BILLS_MODEL`.
  - Production (checked 5 Nov) runs `claude-opus-5-5` for the agent and critic and `claude-haiku-5-5` for reading bills.
  - `.env.example` still names older OpenAI models; ignore those.
- **Events** streamed to the browser are defined in `vert_engine/agent_events.py`: `assistant_text`, `tool_call`, `tool_result`, `action_request`, `artifact`, `abstention`, `plan`, and others.

### `vert_connect/`: the outside world

The only package that holds vendor credentials. Stored credentials are AES-GCM encrypted (`vert_engine/state/credential_cipher.py`).

- **Xero:**
  - reads `/Accounts`, `/Journals`, `/Contacts`, `/Payments`, the trial balance, P&L and bank-summary reports, budgets, fixed assets and payroll pay runs;
  - writes `/ManualJournals`, `/Invoices` (bills and sales invoices), `/CreditNotes`, `/BankTransactions` (cash coding) and `/Attachments`.
- **QuickBooks:** reads, and posts journal entries. QuickBooks has no draft state, so Vert's approval is the only gate.
- **Stripe, Shopify:** payout and transaction reads.
- **Email:** payment reminders via Resend or the client's own SMTP (`email_send.py`).
- **Sync:** `worker.py` (the `vert-sync` service) and `sync.py` pull a tenant's data into Postgres. `cron.py` adds `/cron/sync` and `/cron/tick`. Hourly, `pg_cron` calls `/cron/tick`, which runs any scheduled routines that are due. Vercel's own crons are not used.
- **Auto-coding after each sync:** a scheduled sync then codes the bank lines that a rule or an exact match in the client's history already decides. The code is `_with_coding` in `vert_engine/scheduled_tasks/runner.py`, which calls `autocode` in `vert_api/routers/cash_coding.py`.

### Other folders

| Folder | Purpose |
|---|---|
| `api/`, `api_staging/` | Vercel entry points |
| `deploy/` | Operator scripts: bundle builder, health check, role setup, one-off repairs (dry-run by default) |
| `tools/` | Developer tools: mutation checks, flaky-test sweep |
| `vert_bench/` | Payout-reconciliation benchmark |
| `prepaid`, `books_start` (top level) | Empty stray files, not packages. The real modules are `vert_engine/prepaid.py` and `vert_engine/workflows/books_start.py` |

---

## The web app (`vert-demo/`)

- **Stack:**
  - Next.js 16 App Router, React 19, plain JavaScript;
  - plain CSS, with every colour and size defined once in `app/styles/tokens.css`, which a test enforces;
  - only three runtime dependencies: Phosphor icons, `cmdk` for the ⌘K menu, and Playwright (dev only).
- **Pages (`app/`):**
  - `/` is Month-end: the ask box, the month's progress and the decisions that need the accountant;
  - `/chat/[id]` is a conversation;
  - also `/records`, `/scheduled`, `/bills/[id]`, `/connections`, `/clients` (firm mode), `/statements` and printable `/reports/*`.
- **API routes (`app/api/`):** 55 handlers. Every one is a thin server-side proxy to `vert-api` that adds the session's credentials.
- **The one seam to the engine:** `lib/engine-source.js`.
  - It is the only module that knows the API address (`NEXT_PUBLIC_VERT_API_URL`).
  - With the variable unset, the app runs in *static mode* from a recorded close (`lib/engine-output.json`) with every write disabled.
  - There is deliberately no fallback: if the API is down, pages show an error, never stale figures.
- **Sign-in:**
  - the user signs in with an API key, which the server checks against `GET /session`;
  - `lib/session-seal.js` encrypts the key into an httpOnly cookie (8 h absolute, 30 min idle);
  - `lib/session.js` is the only place the key leaves the server.
- **Acting-as:** `lib/acting-as.js` is the single rule for *who* is acting. The server, the sidebar and the client store all use it.
- **The chat UI:**
  - `components/chat/` holds the thread, composer and result views;
  - `components/chat/answer/` renders answer blocks (bank rec, aged balances, cash coding, statements…);
  - `components/cards/` holds the decision cards (`JournalCard`, `TieOutCard`, `ApproveCard`, `PostSheet`…).
- **Client state:**
  - one reducer, `lib/store.js`, which never holds money;
  - the sidebar re-reads `/api/shell` every 15 s, and only while something is working.

---

## The database

Postgres. The base schema is `vert-engine/vert_engine/state/schema.sql`, followed by migrations 002–063 beside it. Migrations run with `python -m vert_engine.state.migrations up`, as the `vert_migrator` role.

The main tables, by area:

| Area | Tables |
|---|---|
| Tenancy | `tenants`, `api_keys`, `firms`, `firm_members` |
| Ledger mirror (read from Xero) | `gl_accounts`, `gl_entries`, `gl_lines`, `gl_sync_windows`, `bank_lines` |
| Payouts | `payouts`, `payout_transactions`, `settlement_exceptions` |
| Entries and approvals | `journal_entries`, `journal_entry_lines`, `approvals`, `proposals`, `audit_log` |
| The close | `close_months`, `close_tasks`, `period_balances`, `period_snapshots` |
| The agent | `agent_sessions`, `agent_turns`, `agent_events`, `agent_actions`, `agent_memories` |
| Documents | `documents`, `document_blobs`, `document_pages` |
| Other work | `prepaid_schedules`, `fixed_assets`, `budgets`, `bill_inbox_items`, `scheduled_tasks`, `ar_reminder_sends`, `connections`, `sync_runs` |

The service uses separate database roles, so a bug in one path cannot do another path's job:

| Role | Can do |
|---|---|
| `vert_app` | Serve requests, under row-level security |
| `vert_authenticator` | Read only API keys and tenants |
| `vert_provisioner` | Sign-up |
| `vert_syncer` | Write the ledger mirror |
| `vert_retention` | Delete old data |
| `vert_migrator` | Own the tables and run migrations |

Staging's database is on Supabase. The connection strings live only in Vercel's environment settings.

---

## Tests

| Where | Run with | Note |
|---|---|---|
| `vert-engine/` (~1,230 files) | `.venv/bin/python -m pytest -q` | **Needs Postgres on port 55432.** Without it, the row-level-security tests (~320) *skip* and the suite still reports green. |
| `vert-engine/` evals | `python -m vert_engine.evals.harness` (release gate), `python -m vert_agent.evals.harness` | |
| `vert-demo/` (~407 files) | `node --import ./tests/_harness/register.js --test <files>` | Uses `node:test`. Some guard tests temporarily edit source files; don't interrupt a full run. |

---

## Where the code and its docs disagree

Some docs in the repo were written months ago and not kept up. Where they conflict with this file, the code wins.

- **`vert-engine/DEPLOY-PLATFORM.md` §1** says Postgres, Docker and migrations were "never run against a server", and that API mode must stay off on Vercel. Both are long out of date: production runs on Postgres in API mode.
- **`vert-engine/.env.example`** names OpenAI models; production runs Claude.
- **`vert-demo/DESIGN.md`** describes Payouts, Approvals and Exceptions screens, and **`WALKTHROUGH.md`** describes "four Reconciliation tabs". Both designs are gone; the chat is now the workspace. Most of `app/globals.css` is styling for those removed screens.
- **`vert-demo/DEPLOY.md`** lists `VERT_SYNC_TENANT` as required. It was removed.
- **`vert-demo/walk.mjs`, `warm.mjs`, `prodwarm.mjs`** time old URLs that now redirect.

---

## Suggested reading order

1. `vert-demo/PRODUCT.md`: what the product is for.
2. `vert-engine/README.md`: the engine's rules.
3. `vert-engine/vert_engine/tools.py`: what the deterministic core offers.
4. `vert-engine/vert_agent/chat/agent.py` and `chat/bind.py`: how a chat turn runs, and why it can't make up a number.
5. `vert-demo/lib/engine-source.js` and `lib/agent/`: how the web reaches the engine and streams answers.
6. `vert-engine/vert_engine/state/schema.sql`: the data model.
