# Privacy Policy — DRAFT

> **This is a draft for review, not a published policy.** It is written to satisfy
> Shopify Level 1 requirement #7 and Intuit's privacy policy requirement, and to be
> accurate about what the system actually does. **It has not been reviewed by a lawyer
> and must be before publication.** Australian Privacy Principles under the Privacy Act
> 1988 apply, and «FILL» whether you are an APP entity by turnover or by opting in.
>
> Every **«FILL»** is a fact not recorded anywhere in the codebase. Do not guess at them.

**Effective:** «FILL: date»
**Entity:** «FILL: legal entity name, ABN, registered address»
**Contact:** «FILL: privacy@…»

---

## 1. Who we are and what this covers

Vert («FILL: entity») provides payout reconciliation software for e-commerce merchants.
This policy explains what data we handle, why, and what we do not do with it.

We handle two distinct kinds of data and the distinction matters throughout:

- **Your data** — your account, your business, your accounting records. You are our
  customer and we are responsible to you for this.
- **Your customers' order data** — records of sales made through your store, which we
  receive from your connected platforms. For this data **you are the controller and we
  act only on your instruction**, as a service provider. We do not have and do not seek a
  relationship with your customers.

## 2. What we collect

### 2.1 Account data
«FILL: name, email, password hash, organisation name» — whatever the signup flow actually
collects. Keep this list accurate; it must match the built product.

### 2.2 Connected platform data

When you connect a platform, we read only what is needed to reconcile your payouts:

| Source | What we read |
|---|---|
| **Stripe** | Payouts, balance transactions, charges, and payout reconciliation reports |
| **Shopify** | Shopify Payments payouts and their balance-transaction ledger; order financial data — order totals, tax components and line items |
| **QuickBooks Online** | Chart of accounts, and bank transaction lines for the account you nominate |

**We do not read, request or store your customers' names, email addresses, phone numbers
or postal addresses.** Our data access requests to these platforms are scoped to exclude
them, and our queries request named financial fields only.

### 2.3 What we write

To QuickBooks Online, we write journal entries **only after a person at your organisation
has reviewed and approved them.** We never mark a transaction as reconciled.

> **Corrected 2026-08-14 — the earlier wording said "as drafts" and that was false.**
> QuickBooks Online's `JournalEntry` has no draft state: a created entry is in the trial
> balance immediately (`vert_connect/quickbooks_ledger.py:316`, `creates_draft=False`).
> Draft posting is a *Xero* capability, and Xero is no longer the target.
>
> What is true, and what this policy commits to: **approval and posting are separate
> acts, and nothing is posted without a recorded human approval.** On QuickBooks, Vert's
> approval gate is the only gate — so we state that plainly rather than implying the
> ledger holds a second one.

### 2.4 Operational data
Logs, audit records of who did what in the product, and error diagnostics. Credentials
are excluded from logs and error reports by design.

## 3. Why we process it

Solely to provide the service: to decompose each payout into its components, prove it
balances, produce a draft journal entry and working paper, and surface what could not be
resolved automatically so a person can decide.

**We do not:**
- sell or rent data to anyone;
- share your data or your customers' data with third parties for their own purposes;
- use your data or your customers' data to train machine learning models;
- use data from one customer to serve another;
- perform marketing, advertising, profiling or tracking of your customers.

«FILL: If you ever want to use aggregate data for benchmarking or model improvement, that
must be stated here and be opt-in. Do not leave this ambiguous — it is exactly the clause
a reviewer looks for.»

## 4. Automated processing

Vert computes accounting figures automatically. It makes **no automated decision about any
individual person**, and no output of the system has a legal or similarly significant
effect on your customers. Where the system cannot determine a figure with confidence, it
declines and escalates to a person rather than guessing.

## 5. Who else touches the data

Sub-processors, limited to infrastructure:

| Sub-processor | Purpose | Location |
|---|---|---|
| «FILL: Vercel» | Application hosting | «FILL: region» |
| «FILL: Neon» | Database hosting | «FILL: region» |
| «FILL: any model provider, if the agent is enabled for that tenant» | «FILL» | «FILL» |

> **The model provider row needs a decision.** The product can run fully deterministically
> with the agent disabled, which is a supported configuration. If you enable it for
> customers, a third party receives data and must be disclosed here. Being able to say
> "the agent is off and no third-party model sees your books" is a genuine selling point
> to an accountant — consider making that the default and the enabled state opt-in.

## 6. Security

- All data is encrypted in transit using TLS.
- Data at rest is encrypted by our infrastructure providers.
- Each customer's data is isolated at the database layer using PostgreSQL row-level
  security, enforced by the database rather than by application code.
- All changes are recorded in an append-only, hash-chained audit log.
- Credentials are excluded from logs and error reports.
- «FILL: staff access controls — who at the company can access production data, and how
  that access is granted and logged. This must be true before you write it.»

No system is perfectly secure and we do not claim otherwise. See our security incident
response policy for what happens if something goes wrong.

## 7. Retention and deletion

See the data retention policy. In summary: we keep data for as long as needed to provide
the service and to support the accounting records it substantiates, and we delete it
within «FILL: N days» of you closing your account.

You can disconnect any platform at any time from within the product, which revokes our
access immediately.

## 8. Your rights

«FILL: this section needs legal input and depends on which regimes apply — Australian
Privacy Principles, and GDPR/UK GDPR if you have any EU/UK customers or merchants with
EU/UK customers. Cover at minimum: access, correction, deletion, complaint, and the
contact point for each.»

## 9. Changes

We will notify «FILL: how — in-product, email» before material changes take effect.

## 10. Contact

«FILL: privacy contact address, and the complaint escalation path (in Australia, the OAIC).»
