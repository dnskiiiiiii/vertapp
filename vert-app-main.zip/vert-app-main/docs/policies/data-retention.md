# Data Retention Policy — DRAFT

> Required by Shopify Level 1 requirement #8 ("apply data retention periods"). Drafted
> 2026-08-14. **Needs one decision from you and a legal check** — see §2.
>
> The retention periods below are proposals, not facts. Once published they are a
> commitment, and the product must actually enforce them.

**Effective:** «FILL: date» · **Owner:** «FILL» · **Review:** annually

---

## 1. The tension to resolve

Two obligations pull in opposite directions and the policy has to say which wins:

- **Minimisation.** Shopify's approval test is that we hold the minimum necessary.
  Holding order data for years is the opposite of minimal.
- **Substantiation.** Vert produces accounting records. A journal entry that cannot be
  traced back to the payout and orders that justify it is worthless in an audit — and
  Australian record-keeping obligations generally require business records be kept for
  **five years**. A working paper whose evidence was deleted after 90 days does not do the
  job the product exists to do.

**Proposed resolution: retain the derived accounting record for the statutory period,
minimise the raw source data.** These are different things and should have different
periods.

## 2. Proposed periods

| Data | Period | Reasoning |
|---|---|---|
| **Journal entries, reconciliation results, working papers, audit log** | «FILL: 5 years» from end of the financial year | These *are* the accounting record. Deleting them defeats the product's purpose and likely conflicts with the customer's own obligations. |
| **Payout and balance-transaction records** | Same as above | Directly substantiate the entry. A payout decomposition you cannot re-derive is not evidence. |
| **Order financial data (totals, tax, line items)** | «FILL — the decision» | See below. |
| **Vendor credentials** | Until disconnection, then deleted within «FILL: 7 days» | No reason to hold a credential past the connection. |
| **Account data** | Life of account + «FILL: 30 days» | |
| **Operational logs** | «FILL: 90 days» | |
| **Backups** | «FILL: 30 days» rolling | Deletion must propagate — see §4. |

### The order-data decision

Options, and you should pick one before publishing:

**(a) Retain order financial data for the full statutory period.** Strongest audit trail
— a reviewer can always re-derive the GST split. Weakest minimisation story.

**(b) Retain only the derived tax figures, discard the underlying order records after the
period closes.** Better minimisation, and defensible: once the entry is approved, the
figure that mattered is captured in the working paper. Risk: an audit query about *how*
a figure was derived cannot be answered from source.

**(c) Retain in full for «FILL: 12 months», then reduce to derived figures.** Covers the
window in which questions realistically arise, then minimises.

**Recommendation: (c).** It is the honest middle, it is easy to justify to Shopify
("we retain source records only for the period in which reconciliation questions
realistically arise, then reduce to the derived accounting figures"), and it matches how
real bookkeeping questions arrive — clustered near the period, not five years later.

## 3. Deletion on termination

When a customer disconnects a platform: credentials revoked immediately, and deleted
within «FILL: 7 days».

When a customer closes their account: all data deleted within «FILL: 30 days», except
where we are required to retain it, and **except the customer's own accounting records if
they have asked us to export them first**. Offer the export before deleting — a customer
who loses their working papers because they cancelled a subscription will say so publicly,
and they will be right.

«FILL: decide whether closing an account offers a data export, and build it. This is a
product decision with a retention consequence.»

## 4. Enforcement — the part that makes this real

A retention policy nothing enforces is a document, not a control.

> **Built 2026-08-15 — option (c), as an assumption pending your decision.**
> `vert_engine/state/retention.py` + migration 009. Source records are held whole for
> **12 months** and then reduced to their provenance.
>
> **It is a redaction, not a deletion, and that is deliberate.** Every foreign key in
> the schema is `ON DELETE RESTRICT` and a close cites its evidence, so the row cannot
> be removed — and should not be, because the row *is* the provenance. Deleting it
> would not minimise anything (the figure it justified is still in the ledger); it
> would only make that figure unexplainable.
>
> **`content_hash` survives redaction.** The digest was computed over the original
> payload and is never recomputed, so if the original is ever produced — from a vendor
> export, a backup, a support thread — it can be proven to be the one the close read.
> Redaction costs the *content*, not the *auditability*. That is the actual trade.
>
> **It runs as its own database role.** `vert_app` has no UPDATE on `source_records`,
> deliberately, because an evidence table is one a request handler must not rewrite.
> `vert_retention` holds a **column-level** grant on `(raw, redacted_at)` and nothing
> else — so the role that removes payloads is structurally unable to alter the digest
> or the id. Not a rule the job follows; a fact about the database.
>
> **Still to do:** nothing schedules it. It is an operator-invoked pass today, and the
> deployment has to run it. Scheduling is the remaining gap between this control and
> the promise.

- ☑ ~~**No automated deletion exists today.**~~ Enforcement exists as above. What
      remains is scheduling it and choosing the period deliberately.
- ☐ Deletion must reach **backups**, not only live tables. A 30-day rolling backup means
      true deletion completes 30 days after the live delete; the policy should say so
      rather than imply instant erasure.
- ☐ Deletion must be **logged to the audit trail** — with the audit log itself retained,
      since it is the evidence the deletion happened.
- ☐ Note the application role deliberately holds **no `DELETE` grant** on any table.
      That is a good control and it means retention enforcement needs a separate,
      narrowly-privileged path rather than a loosening of the application role.
      **Do not solve this by granting the app DELETE.**

## 5. Before publishing

- ☐ Order-data option chosen (§2)
- ☐ Statutory period confirmed with an Australian accountant or lawyer
- ☐ Automated enforcement built
- ☐ Backup propagation described accurately
- ☐ Export-before-delete decided
- ☐ Periods stated here match the privacy policy exactly
