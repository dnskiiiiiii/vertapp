# Security Incident Response Policy — DRAFT

> Required by Shopify (Level 2 #7) and expected by Intuit's security review. Drafted
> 2026-08-14. **A policy describing controls that do not exist is worse than no policy** —
> everything below marked «FILL» or ☐ must be made true before this is published or
> submitted.
>
> This is written for a very small team, because that is the truth. It is better to have
> an honest single-responder policy than to describe a security operations centre.

**Owner:** «FILL: named person — with a team of one or two, name them»
**Effective:** «FILL: date»
**Review cadence:** every «FILL: 6/12» months, and after every incident.

---

## 1. Scope

Any event that compromises, or may have compromised, the confidentiality, integrity or
availability of: customer accounting data, order data received from connected platforms,
vendor credentials, or the service itself.

Includes: unauthorised access, credential exposure, data loss, a vulnerability disclosed
by a third party, sub-processor breach, and cross-tenant data exposure.

## 2. Severity

| Level | Definition | Response starts |
|---|---|---|
| **P1 — Critical** | Confirmed unauthorised access to customer data; credential exposure; **any cross-tenant data leak** | Immediately, drop everything |
| **P2 — High** | Suspected access, or a vulnerability that would allow it if exploited | Within 4 hours |
| **P3 — Moderate** | Vulnerability with no evidence of exploitation and no direct data exposure | Within 2 business days |
| **P4 — Low** | Hardening item, defence-in-depth gap | Next planned work |

**Cross-tenant exposure is always P1.** For an accounting product it is unrecoverable
reputationally, and the architecture is built specifically to prevent it — so any
occurrence means a control failed and the failure is the incident, whether or not data
actually moved.

## 3. Response

### 3.1 Detect and record
Start a timestamped log immediately, at «FILL: where — a private repo issue, a doc». Every
subsequent step is appended to it. This log is the basis of the notification and of the
post-incident review; reconstructing it afterwards from memory does not work.

### 3.2 Contain
Priorities in order: stop ongoing access, preserve evidence, then restore service.

Available actions today:
- Revoke a tenant's vendor connections (`ConnectionStore.revoke`).
- Revoke API keys / rotate the application database role credential.
- Rotate Vert's own vendor client secrets.
- «FILL: how you take the service offline if you have to — and confirm you can.»

Do not delete anything before evidence is preserved. Logs and the audit chain are how you
find out what actually happened.

### 3.3 Assess
Determine: what data, whose, how much, when, still ongoing? The append-only hash-chained
audit log is the primary source, and `Store.verify_audit_trail` establishes whether the
chain itself is intact.

> ☐ **Prerequisite:** `verify_audit_trail` currently has no production caller. Until it is
> wired up and run, the chain's integrity is unverified and this step is weaker than it
> reads. Fix before publishing this policy.

### 3.4 Notify

| Who | When | Trigger |
|---|---|---|
| Affected customers | Without undue delay, target «FILL: 72h» | Any P1, or P2 where data was likely accessed |
| **OAIC** | As required by the Notifiable Data Breaches scheme | Eligible data breach — likely serious harm |
| **Shopify** | «FILL: confirm the required channel and window in the Partner Program Agreement» | Any incident involving protected customer data |
| **Intuit** | «FILL: confirm channel» | Any incident involving QuickBooks data or tokens |
| Sub-processors | As relevant | If the incident originates with or affects them |

> **Australia's Notifiable Data Breaches scheme is a legal obligation**, not a courtesy.
> «FILL: confirm with a lawyer whether the entity is covered — it turns on turnover and on
> whether you opt in. Do this before you need to know.»

Notifications state: what happened, what data, when, what we have done, what the customer
should do, and who to contact. Plainly, without minimising.

### 3.5 Recover and review
Restore service, confirm the vector is closed, monitor for recurrence.

Then, within «FILL: 5 business days», a blameless post-incident review answering: what
happened, why the existing controls did not prevent it, what changes, and — the one that
matters — **what test now exists so this specific failure cannot recur silently.** A fix
without a regression test is not a fix.

## 4. Contacts

| Role | Person | Contact |
|---|---|---|
| Incident lead | «FILL» | «FILL» |
| Backup | «FILL» | «FILL» |
| Legal | «FILL» | «FILL» |
| Infrastructure providers | «FILL: Vercel, Neon support paths» | «FILL» |

> **A single-person team is a real risk and should be named as one.** If one person holds
> every credential and is unreachable, containment stops. At minimum: a second person with
> break-glass access, «FILL: how that is held and how its use is logged».

## 5. Prerequisites before this policy is honest

- ☐ `verify_audit_trail` called by running code (§3.3)
- ☐ Credential redaction installed in the API service, not only the CLI — otherwise an
      incident triggered by an exception may write the credential into the log you are
      investigating with
- ☐ A documented, tested way to take the service offline
- ☐ Break-glass access for a second person
- ☐ Named contacts filled in above
- ☐ Confirmed notification channels for Shopify and Intuit
- ☐ Legal advice on Notifiable Data Breaches applicability
