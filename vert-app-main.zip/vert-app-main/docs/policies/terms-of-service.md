# Terms of Service — DRAFT

> **This is a draft for review, not a published contract.** It is a reviewable starting
> point for a lawyer, written to be accurate about what the system actually does and to
> satisfy Intuit's requirement for an EULA/terms URL. **It has not been reviewed by a
> lawyer and must be before publication.** Several clauses below — limitation of
> liability, indemnity, governing law — are the ones where a template is actively
> dangerous and where legal input is not optional.
>
> Every **«FILL»** is a fact about the company that is not recorded anywhere in this
> repository. Do not guess at them; several are legal representations.

**Effective:** «FILL: date»
**Entity:** «FILL: legal entity name, ABN, registered address»
**Contact:** «FILL: support@…»

---

## 1. What these terms cover

These terms govern your use of Vert («FILL: entity»), a payout reconciliation service.
By creating an account or connecting a platform you accept them. If you are accepting on
behalf of a business, you represent that you are authorised to bind it.

Our privacy policy at «FILL: URL» forms part of these terms and describes how we handle
data.

## 2. What the service does

Vert reads settlement data from the payment and accounting platforms you connect, and:

- decomposes each payout into its components — sales, processing fees, refunds,
  chargebacks, reserve movements and GST;
- proves the decomposition ties to the amount that reached your bank account;
- produces a working paper showing the derivation;
- produces a **draft** journal entry for a person at your organisation to review;
- surfaces what it could not resolve, rather than guessing.

That is the whole of the service. It is a calculation and presentation tool.

## 3. What the service is not — read this clause

This section is the one that matters most, and it is deliberately blunt.

### 3.1 Everything Vert produces is a draft requiring human approval

Every journal entry, figure, working paper, classification and reconciliation Vert
produces is a **draft proposal**. It has no effect on your books until a person at your
organisation reviews it and approves it. Vert does not post an entry that has not been
explicitly approved by a human, and the approval is recorded against the entry.

You are responsible for that review. Approving a draft is your decision and your
representation that you have checked it.

### 3.2 Vert does not file, lodge, or certify anything

Vert does not, and will not:

- lodge a Business Activity Statement, income tax return, or any other return with the
  Australian Taxation Office or any other authority;
- file or submit anything to any regulator, registry or authority on your behalf;
- certify, audit, sign, or attest to any figure, statement or record;
- complete a bank reconciliation in your accounting system, or mark any transaction as
  reconciled.

Where the service writes to your accounting system, it writes a single journal entry
that a person at your organisation has already approved, and nothing else. It does not
write anything you have not approved.

> **Drafting note — do not publish this section without reading it.** "Draft" means two
> different things and conflating them is the one factual error available in this
> document.
>
> - Inside Vert, every output is a draft until a human approves it. That is
>   unconditional and it is what §3.1 says.
> - Inside your *accounting system*, whether the posted entry lands as a draft depends
>   on the accounting system. **QuickBooks Online has no draft state for a journal
>   entry** — a created entry is in the trial balance immediately (see
>   `vert_connect/quickbooks_ledger.py`, `creates_draft=False`). Xero does have one.
>
> So the sentence "we only ever write drafts to your accounting system" is **false for
> QuickBooks** and must not be published. The true and still-strong statement is the one
> above: nothing is written that a human has not approved, and for a target with no
> draft state Vert's own approval screen is the only gate that exists. The product
> already surfaces this per-target rather than assuming it.
>
> `privacy-policy.md` §2.3 currently contains the incorrect version ("we write journal
> entries **as drafts**") and should be corrected to match.

### 3.3 Vert does not provide accounting, tax, audit or financial advice

Vert is software. It is not a registered tax agent, BAS agent, accountant, auditor or
financial adviser, and nothing it produces is advice. No output is a substitute for the
judgement of a qualified professional, and using the service does not create any
professional or advisory relationship between us.

If a figure Vert produces has consequences for your tax position, your statutory
reporting or your financial statements, that is a matter for your accountant, not for
us.

### 3.4 No warranty that figures are fit for statutory lodgement

We do not warrant that any figure produced by the service is correct, complete, or fit
for inclusion in a Business Activity Statement, a tax return, a financial statement, or
any other statutory or regulatory filing. The service is provided on an "as is" basis to
the fullest extent permitted by law.

Any decision to rely on a figure for a statutory purpose is yours, made after your own
review.

### 3.5 Australian Consumer Law

Nothing in these terms excludes, restricts or modifies any guarantee, right or remedy
under the Australian Consumer Law that cannot lawfully be excluded.

«FILL with legal input: whether the service is supplied to "consumers" as defined, and
the correct form of the ACL limitation-of-remedy wording. This is a specific drafting
question and the standard clause is not always the right one.»

## 4. Your obligations

You agree to:

- **Review every draft before approving it.** This is the core obligation and the
  service is designed around it.
- Provide accurate account information and keep it current.
- Only connect platforms and accounts you are authorised to connect.
- Keep your credentials secure, and tell us promptly if you believe an account has been
  compromised.
- Not attempt to access another customer's data, probe or circumvent the service's
  security controls, or use the service to store or process data unrelated to your own
  accounting.
- Comply with the terms of the third-party platforms you connect (Stripe, Shopify,
  Intuit and any others). Your relationship with those platforms is your own.

## 5. Your data

### 5.1 You remain the controller

You retain all rights in the data you provide and the data we read from platforms you
connect. **You are the controller of that data and we process it only on your
instruction**, as a service provider, for the purpose of providing the service.

We claim no ownership of your accounting data and we do not use it for our own purposes.
Specifically, we do not sell it, do not share it with third parties for their own
purposes, and do not use it to train machine learning models. See the privacy policy.

### 5.2 Our licence

You grant us a limited licence to store, process and transmit your data solely to
operate the service for you. It ends when your account ends, subject to §8.

### 5.3 Accuracy of source data

The service reads data from platforms you connect. We are not responsible for errors,
omissions or unavailability in that source data, and a reconciliation is only as good as
the records it reads. Where source data is missing or contradictory, the service
escalates to you rather than filling the gap.

## 6. Availability and changes

We aim to keep the service available but do not commit to a service level unless one is
agreed separately in writing. «FILL: whether you are offering an SLA, and to whom.»

We may change the service. Where a change materially reduces functionality you rely on,
we will give notice «FILL: how, and how far in advance».

## 7. Fees

«FILL: pricing, billing period, payment terms, taxes, what happens on non-payment,
whether and how prices change. None of this is recorded in the repository.»

## 8. Suspension, termination and export

### 8.1 You may terminate at any time

You can close your account at any time, and disconnect any individual platform from
within the product at any time without closing your account. Disconnecting revokes our
access to that platform.

### 8.2 We may suspend or terminate

We may suspend or terminate your access:

- for non-payment, after notice «FILL: notice period»;
- for a material breach of these terms that is not remedied within «FILL: N days» of
  notice;
- immediately, where continued access presents a security risk to you, to another
  customer, or to the service — in which case we will tell you why as soon as we
  reasonably can;
- if a platform we depend on terminates our access to it, or a legal or regulatory
  requirement prevents us from operating.

Suspension for a security reason is intended to be narrow and short. It is not a
termination and we will restore access once the reason is resolved.

### 8.3 Export on termination

**Before your data is deleted, you may export it.** Your accounting records — the
approved journal entries, reconciliation results and working papers produced for you —
are records you may need for years after you stop being a customer, and losing them
because a subscription ended would be a real harm.

On termination, for a period of «FILL: N days» we will make your data available for
export in a machine-readable format, at no charge. After that period it is deleted in
accordance with the data retention policy at «FILL: URL».

> **Open item, not yet true.** As of «FILL: date» there is no automated export or
> deletion mechanism in the product; see `data-retention.md` §4. Do not publish this
> clause until the export exists — a term promising a capability the software does not
> have is a term you will breach.

## 9. Confidentiality

Each party will keep the other's confidential information confidential and use it only
for the purposes of these terms. Your accounting data is your confidential information.

## 10. Intellectual property

We retain all rights in the service, its software, and its documentation. You get a
non-exclusive, non-transferable right to use it while your account is active. You may not
copy, reverse engineer, or resell the service, except to the extent that restriction is
unenforceable by law.

Feedback you give us about the service may be used without obligation to you, and does
not include any of your data.

## 11. Limitation of liability

«FILL with legal input. This clause must be drafted, not adapted from a template, and it
must be read together with §3 and with the Australian Consumer Law.

The specific facts a drafter needs to know:

- The service produces figures that feed a customer's accounting records and,
  indirectly, their statutory reporting. The plausible loss is not a service outage; it
  is a wrong figure that a human approved and that reached a lodgement.
- The design places a mandatory human review between every output and any effect. That
  is a real and material fact about causation and it should be reflected in the
  drafting.
- The realistic quantum is not bounded by fees paid, so a fees-paid cap is a decision
  with consequences and should be made deliberately rather than by default.
- Decide explicitly whether liability for a data breach is treated differently from
  liability for a wrong figure. They are different risks with different insurance
  answers.

Do not publish this section with a placeholder cap in it.»

## 12. Indemnity

«FILL with legal input: whether a customer indemnity is appropriate at all for this
product and this customer size, and in what direction. Consider it together with §11
rather than separately.»

## 13. Sub-processors and third parties

We use infrastructure sub-processors to operate the service. They are listed at
«FILL: URL — see `sub-processors.md`» and we remain responsible for their handling of
your data.

The service connects to third-party platforms at your direction. We are not responsible
for those platforms, their availability, their pricing, or their terms.

## 14. Changes to these terms

We may change these terms. For material changes we will give notice «FILL: how, and how
far in advance» before they take effect. Continuing to use the service after that means
you accept the change; if you do not, you may terminate.

## 15. Governing law and jurisdiction

«FILL: presumably the laws of Victoria, Australia, with the courts of Victoria having
non-exclusive jurisdiction — but this must be confirmed against where the entity is
actually registered, and where its customers are. Do not state a jurisdiction that does
not match the entity.»

## 16. General

- **Entire agreement.** These terms, the privacy policy and any order form are the whole
  agreement between us.
- **Assignment.** You may not assign these terms without our consent. We may assign them
  as part of a sale of the business, on notice to you.
- **Severability.** If a provision is unenforceable, the rest stands.
- **No waiver.** Not enforcing a term is not a waiver of it.
- **Notices.** «FILL: how notice is given to each party.»

## 17. Contact

«FILL: support and legal contact addresses.»

---

## Before publishing — checklist

- ☐ Reviewed by an Australian lawyer, with §3, §11 and §15 read together
- ☐ Legal entity, ABN and registered address filled in
- ☐ Pricing and billing terms drafted (§7)
- ☐ Data export capability actually built before §8.3 is published
- ☐ Australian Consumer Law wording confirmed (§3.5)
- ☐ Hosted at a stable public URL, and that URL given to Intuit
- ☐ Retention periods here match `data-retention.md` and `privacy-policy.md` exactly
