# Sub-processors — DRAFT (structure only)

> **This is the structure and the open questions, not the answer.** The infrastructure is
> not settled, so the vendor list below is deliberately empty of facts. Filling it in with
> today's guesses would produce a published commitment that is wrong within a month.
>
> Required by Shopify Level 1 #5 (opt-out of data sharing) and #7 (data protection
> agreement), by Intuit's review, and referenced by `privacy-policy.md` §5 and
> `terms-of-service.md` §13. **Those three documents must agree exactly once this is
> filled in.**
>
> Every **«FILL»** is a fact not recorded anywhere in this repository.

**Effective:** «FILL: date» · **Owner:** «FILL» · **Review:** on every vendor change, and
at least annually

---

## 1. What this document has to state, and why

A sub-processor list that says only "we use cloud hosting" fails every review it is put
in front of. Four things are load-bearing, and a reviewer checks for all four:

| Field | Why it is required |
|---|---|
| **Legal entity name** | "Vercel" is a product. The contracting entity is what a DPA binds and what a customer's own legal team checks against their vendor list. |
| **Purpose** | Establishes necessity. A sub-processor that cannot be tied to a service function should not be there. |
| **Data categories** | Which of the two kinds of data it touches — the customer's own data, or their customers' order data. These are not the same and reviewers treat them differently (see `privacy-policy.md` §1). |
| **Location** | Where the data physically sits, and therefore whether a cross-border disclosure has occurred. Under APP 8 this is the customer's problem too, not only ours. |

Two more that are worth adding and are often omitted:

- **Whether it can access data in the clear**, or only ciphertext. A hosting provider that
  holds an encrypted volume and no key is a materially different risk from one that runs
  the application process.
- **The date it was added.** Customers with a change-notification right need to be able to
  see what changed.

## 2. The list

> **Nothing here is settled.** Do not publish this table until the deployment is decided
> and each entity name has been read off an actual contract or terms page rather than a
> marketing site.

| Sub-processor (legal entity) | Purpose | Data categories | Location | Clear-text access? | Added |
|---|---|---|---|---|---|
| «FILL: application hosting provider — legal entity name» | Runs the API and web application | «FILL» | «FILL: region» | «FILL» | «FILL» |
| «FILL: database provider — legal entity name» | Managed PostgreSQL; stores all customer and order data | Customer account data; order financial data; payout records; encrypted vendor credentials | «FILL: region» | «FILL» | «FILL» |
| «FILL: key management / secret storage, if separate from the above» | Holds the credential encryption key outside the database | Encryption key material only — no customer data | «FILL» | n/a | «FILL» |
| «FILL: error tracking / logging, if any» | Diagnostics | «FILL — and see §4: this one is easy to get wrong» | «FILL» | «FILL» | «FILL» |
| «FILL: email provider, if any» | Transactional email | Account data only | «FILL» | «FILL» | «FILL» |
| «FILL: payment / billing provider, if any» | Subscription billing | Billing data only — no accounting or order data | «FILL» | «FILL» | «FILL» |
| **Model provider** — see §3 | «FILL» | «FILL» | «FILL» | «FILL» | «FILL» |

### Questions to answer before each row is written

1. **Is it actually necessary?** Every entry is a disclosure that has to be defended. A
   vendor that saves an afternoon of work is not worth a permanent line on this list.
2. **What is the legal entity, on paper?** Not the brand.
3. **What region is the data actually in?** Not the region of the dashboard — the region
   the data is provisioned in. Check it, do not assume the default.
4. **Is there a signed DPA, and does it permit onward sub-processing?** Your
   sub-processors have sub-processors. At minimum know whether they do.
5. **Does it touch order data, or only your own operational data?** This determines
   whether it falls inside the Shopify protected-customer-data commitments.
6. **What happens to data on termination of that vendor relationship?**

## 3. The model provider — the open decision

This is the one genuine decision in this document, and it is already recorded in
`privacy-policy.md` §5. Restating it here because it belongs on this list or it does not,
and there is no middle position.

**The facts:**

- Vert's accounting engine is fully deterministic. It computes every figure without a
  model. The agent layer proposes explanations and resolutions; it does not produce
  numbers.
- **Running with the agent disabled is a supported configuration**, not a degraded mode.
  The product reconciles, proves and drafts without it.
- If the agent is enabled for a tenant, a third-party model provider receives data
  derived from that tenant's books, and must appear on this list.

**The options:**

| Option | What you can tell a customer | Cost |
|---|---|---|
| **(a) Agent off by default, opt-in per tenant** | "No third-party model sees your books unless you turn it on, and you can leave it off." Sub-processor row is conditional and disclosed at the moment of opt-in. | Two configurations to support and to document. The list must state the conditional row clearly rather than burying it. |
| **(b) Agent on for everyone** | The model provider is an unconditional sub-processor for every customer. | Simplest to operate; strictly the weakest privacy story, and it is the row an accountant will stop at. |
| **(c) No third-party model at any time** | The strongest statement available, and unqualified. | Gives up the agent layer, or requires self-hosting a model — a real infrastructure commitment. |

**Recommendation: (a).** It keeps the strong sentence available for the customers who
want it, without abandoning the capability.

> **This is a selling point, not just a compliance line.** "No third-party model ever sees
> your books" is a sentence an accountant will repeat to their own client, and very few
> tools in this category can say it. It is worth engineering to keep the ability to say
> it truthfully — which means the agent-disabled path must stay genuinely supported and
> tested, not left to rot as a config flag nobody exercises.
>
> The corollary is a discipline: **if the agent is enabled, say so plainly and name the
> provider.** A quiet default that sends books to a model, disclosed only in a footnote,
> destroys the trust the honest version buys.

**Whichever option is chosen, this document must state:**

- whether the agent is on or off by default;
- how a customer turns it off, and whether turning it off is self-serve;
- what data the model provider receives — is it figures and metadata, or order-level
  records?
- whether the provider trains on inputs (it must not; get this in writing);
- the provider's retention period for inputs.

«FILL: answer each of the five above once the decision is made. The fourth is a contract
term, not a settings toggle, and it should be quoted from the contract.»

## 4. Two traps worth naming

**Error tracking is a sub-processor that handles customer data.** It is easy to file under
"tooling" and omit. A stack trace carries application state, and an error report from a
reconciliation carries figures. If an error-tracking vendor is used, it belongs on this
list, and the redaction that keeps credentials out of it (`vert_api/redaction.py`) is a
control worth describing rather than assuming.

**Analytics on the marketing site is not the same thing.** Site analytics touches
prospects, not customer accounting data. Keep it out of this list to avoid muddying it,
and cover it in the privacy policy's website section instead — but do not thereby forget
to disclose it at all.

## 5. Changes and notification

«FILL: the commitment. Standard practice is notice a set number of days before a new
sub-processor begins processing, with a right to object. Decide:

- how notice is given (in-product, email, a subscribe-able page);
- how far in advance;
- whether a customer can object, and what happens if they do — in practice, for a
  small company, "you may terminate without penalty" is the only honest answer, and
  it is better to say that than to imply a veto you cannot honour.»

## 6. Before publishing — checklist

- ☐ Deployment infrastructure decided
- ☐ Every legal entity name read off a contract or terms page, not a marketing site
- ☐ Every region verified against the actual provisioned resource
- ☐ DPA signed with each, and onward sub-processing understood
- ☐ Model-provider decision made (§3) and the default stated
- ☐ Error tracking and email providers considered, not just hosting (§4)
- ☐ Change-notification commitment decided (§5)
- ☐ This list, `privacy-policy.md` §5 and `terms-of-service.md` §13 say the same thing
- ☐ Hosted at a stable public URL, referenced from the privacy policy
