# Vert

Vert is an AI close assistant for accountants: it reads a company's books (Xero first), reconciles, drafts journal entries and schedules, and answers in a chat that shows its working.

This repository holds the whole app. Until 8 Nov 2026 it was two repositories; both histories are kept here unchanged, so old commit hashes still resolve.

**New here? Read [ARCHITECTURE.md](ARCHITECTURE.md)** — how the pieces fit, with diagrams, one question traced end to end, and which older docs are out of date.

| Folder | What it is | Language | Deployed as |
|---|---|---|---|
| [`vert-engine/`](vert-engine/) | Reconciliation core, the agent, the HTTP API, Xero/Stripe sync, Postgres state | Python 3 | Vercel (API and sync projects) |
| [`vert-demo/`](vert-demo/) | The web app (chat workspace, close list, connections) | Next.js | Vercel project `vert-platform` |

The folder names matter: the web app's tests read engine files through `../vert-engine/...`, so keep both folders side by side under these names.

## Running it locally

Engine (needs Postgres on port 55432 — without it ~320 tests skip silently and the suite still reports green):

```sh
cd vert-engine
python -m venv .venv && .venv/bin/pip install -e .
cp .env.example .env.local        # fill in keys; see .env.example
.venv/bin/python -m pytest -q
```

Web app:

```sh
cd vert-demo
npm install
npm run dev
```

Careful with a bare `npm test` in `vert-demo/`: some guard tests (negative-anchor / mutation harness) temporarily edit real source files, and an interrupted run can leave them changed. If `git status` shows edits you didn't make afterwards, `git checkout -- vert-demo` restores them.

More detail: [`vert-engine/README.md`](vert-engine/README.md), [`vert-engine/DEPLOY.md`](vert-engine/DEPLOY.md), [`vert-engine/ONBOARDING.md`](vert-engine/ONBOARDING.md), [`vert-demo/DEPLOY.md`](vert-demo/DEPLOY.md), [`vert-demo/PRODUCT.md`](vert-demo/PRODUCT.md).

Credentials are not in the repository. Production and staging secrets live in Vercel as sensitive environment variables; ask for a development key rather than copying production ones.

## Branches

- `main` — what is live in production.
- Feature branches carry changes to either or both folders.
