import { readFileSync } from "node:fs";
import path from "node:path";

import { Archivo, Inter } from "next/font/google";
import { headers } from "next/headers";
import "./globals.css";
import { PUBLIC_DOC_HEADER } from "@/lib/public-docs";
import { readCloseData } from "@/lib/engine-server";
import { AUTH_REQUIRED, readSession } from "@/lib/session";
import { readDuties } from "@/lib/duties";
import { EngineProvider } from "@/lib/engine-context";
import { StoreProvider } from "@/lib/store";
import AppShell from "@/components/shell/AppShell";
import DataSourceDown from "@/components/shell/DataSourceDown";
import { readShellData } from "@/components/shell/shell-data";
import ShellSkeleton from "@/components/shell/ShellSkeleton";
import { Suspense } from "react";

// THE TWO FACES (founder decision D2, 10 Oct 2026; design-fix-2 spec §3.1).
//   Archivo — the brand face, as on the website: headings, the one hero figure per result
//             and the "Vert" wordmark. Never on a button, label, input, menu or table.
//   Inter   — every word of the interface and every figure, with tabular numerals.
// Both are variable fonts, so no weight list. next/font self-hosts them at build time
// (no request to Google from the browser) and sets `--font-archivo` / `--font-inter` on
// <html>; app/styles/tokens.css reads those into `--font-display` and `--font-ui`.
// The old pairing (the system face for the UI, a self-hosted face for the wordmark alone)
// is gone: the audit (DA2-003) found it left the app with no identity of its own.
const archivo = Archivo({ subsets: ["latin"], variable: "--font-archivo", display: "swap" });
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const FONT_CLASSES = `${archivo.variable} ${inter.variable}`;

export const metadata = {
  // A plain string, not a template: each page sets its own full title
  // ("Month-end — Vert"), and a template here would only give two places to change
  // the suffix.
  title: "Vert",
  description: "Month-end for e-commerce books: Vert runs the checks, you make the decisions.",
};

// Vert has one theme and does not follow the system's dark appearance (founder, 1 Oct
// 2026; app/styles/tokens.css). There is no toggle, so there is nothing to set before hydration and no inline script. An
// inline script used to write a theme attribute on the client before React hydrated,
// which never matched the server's markup — a hydration mismatch on every route. It is
// gone, not suppressed, and nothing may reintroduce it.
//
// THE BROWSER'S OWN CHROME MATCHES THE DESK (design-pass spec §8; WIG theming): the
// theme colour is the sidebar's soft grey, read from tokens.css, because a colour
// written here would be a second place the palette lives (tests/tokens.test.js allows
// hex in tokens.css alone). If the file can't be read the meta is simply left out.
function tokenHex(name) {
  try {
    const css = readFileSync(path.join(process.cwd(), "app", "styles", "tokens.css"), "utf8");
    const found = css.match(new RegExp(`--${name}:\\s*(#[0-9A-Fa-f]{6})\\b`));
    return found ? found[1] : undefined;
  } catch {
    return undefined;
  }
}

export const viewport = {
  colorScheme: "light",
  themeColor: tokenHex("sidebar"),
};

// ONE READ OF THE DATA SOURCE PER REQUEST, AND IT HAPPENS HERE FIRST.
//
// The layout is the only common ancestor of every route, and the sidebar it renders
// carries real figures (the decisions badge, the month, the conversations), so the
// payload has to be available at this level anyway. Reading it here has two further consequences,
// both intended:
//
//   · The payload crosses into the browser as a PROP on <EngineProvider>, in React's
//     own flight data — one snapshot, provably the same bytes on both sides, no
//     second fetch and no hand-rolled <script> to parse. In static mode `engine` is
//     the imported file and `payload` is null, so the document carries nothing extra
//     and every route still prerenders.
//
//   · If the source cannot be read, NO SCREEN RENDERS. `children` is never returned,
//     so no page component runs, so nothing downstream can quietly draw an empty
//     close. What renders instead says so in words and shows no figures.
//     See components/shell/DataSourceDown.js.
//
// This file still does not know which mode it is in. It awaits a payload and passes
// it on; `readCloseData()` and `<EngineProvider>` are the two ends of the seam, and
// neither tells a component anything except "here are the numbers".
/**
 * The half of a session that may cross into the browser.
 *
 * An allowlist, built field by field, and never a spread or an omission of one key.
 * `session.key` is the customer's live API key: it is in the sealed cookie because
 * the server needs it to call vert_api, and it must never be in the flight payload,
 * because that IS the document. A `{ ...session }` here with a `delete` after it
 * would work today and would ship a credential the first time a field was renamed.
 * Null in static mode, where there is no session and the sidebar says nothing about one.
 */
function publicIdentity(session, duties = null) {
  if (!session) return null;
  return {
    // The person's role and the firm's segregation setting (§20.12 H3, M4), read fresh
    // by lib/duties.js; absent unless the engine reported a role.
    ...(duties ? { role: duties.role, segregation: duties.segregation } : {}),
    tenant: session.tenant,
    keyId: session.keyId,
    label: session.label,
    environment: session.environment,
    // A person key's name and firm (§19.0.9): public, and what the rail and the
    // client store must show so they agree with the actor the engine records.
    person: session.person || null,
    firm: session.firm || null,
  };
}

export default async function RootLayout({ children }) {
  // A PUBLIC LEGAL DOCUMENT RENDERS BEFORE ANY OF THIS, AND DEPENDS ON NONE OF IT.
  //
  // /privacy and /terms are the URLs on a vendor application. Everything below this
  // block — the session read, the close read, the shell with its live badge —
  // exists to draw a customer's books, and a legal document needs none of it. Worse, it
  // is actively harmed by it: `readCloseData()` returning a failure replaces `children`
  // with a card saying the service could not be read, which would take down the two
  // pages a reviewer was told to open, for a reason that has nothing to do with them.
  //
  // The flag comes from `proxy.js`, which is the only place that reliably knows the
  // pathname — a layout is not given one. It is a REQUEST header the proxy sets, not
  // anything a browser can send: the proxy runs on every matched request and rewrites
  // the header set wholesale, so a client sending `x-vert-public-doc: 1` at `/` has it
  // dropped rather than honoured. It also grants nothing on its own — it selects a
  // wrapper with no data in it. The credential path is untouched.
  const publicDoc = (await headers()).get(PUBLIC_DOC_HEADER) === "1";
  if (publicDoc) {
    return (
      <html lang="en" className={FONT_CLASSES}>
        <body>{children}</body>
      </html>
    );
  }

  // WHO IS ASKING, BEFORE ANYTHING IS READ.
  //
  // This is the first thing the layout does, and it happens BEFORE `readCloseData()`
  // rather than beside it, because a request with no session must not cause a fetch
  // at all. Not for efficiency — for honesty: `readCloseData()` catches its failure
  // and returns it as data, so an unauthenticated read would come back as a
  // DataSourceDown card saying the service could not be read. It can be read
  // perfectly well; nobody has said who they are. Those are different sentences and
  // the person needs the second one.
  //
  // In static mode `AUTH_REQUIRED` is false, this whole branch is skipped, and the
  // showpiece renders exactly as it always has — no session, no gate, no change.
  const session = AUTH_REQUIRED ? await readSession() : null;

  if (AUTH_REQUIRED && !session) {
    // No shell. The sidebar carries live figures off the close (the decisions
    // badge, the conversations), and drawing it here would put the previous tenant's number on screen
    // beside a box asking who you are. `proxy.js` routes every credential-less
    // request to /login, so `children` is the sign-in screen.
    return (
      <html lang="en" className={FONT_CLASSES}>
        <body>{children}</body>
      </html>
    );
  }

  // STREAM THE FRAME BEFORE THE DATA (verify pass 1 S-UI-8). Every read below used to be
  // awaited before the first byte left, so on a slow link (or a client whose close takes
  // seconds to read) the page was blank for 6.4 s with no loading state. The html and
  // body now go out at once with the shell's skeleton (ShellSkeleton.js), and the shell
  // with its live figures replaces it when the reads land. Nothing is drawn from a
  // guess: the skeleton carries no client, month or count.
  return (
    <html lang="en" className={FONT_CLASSES}>
      <body>
        <Suspense fallback={<ShellSkeleton />}>
          <SignedInShell session={session}>{children}</SignedInShell>
        </Suspense>
      </body>
    </html>
  );
}

/**
 * The signed-in shell, once its reads have landed: the close (the one read of the data
 * source per request, above), the person's duties and the sidebar's own reads. None of
 * them waits for another: the sidebar's months, month and conversations need the
 * session, not the payout register, and take the register's business name and
 * fallbacks only once it lands (staging smoke, 23 Oct 2026: the sidebar's three reads
 * ran after the register's whole load, on every page).
 */
async function SignedInShell({ session, children }) {
  const closeRead = readCloseData();
  // THE SHELL'S OWN READS: the month list, the decisions badge and this month's
  // conversations (components/shell/shell-data.js). Secondary reads: each one that
  // fails leaves its figure absent rather than zero, and none can take the page down.
  const [{ handoff, failure }, duties, shell] = await Promise.all([
    closeRead,
    readDuties(session),
    readShellData({ engine: closeRead.then((read) => read.engine), signedInAs: publicIdentity(session) }),
  ]);

  if (failure) {
    return <DataSourceDown failure={failure} />;
  }

  const signedInAs = publicIdentity(session, duties);

  return (
    <EngineProvider payload={handoff}>
      {/* The store gets the SAME public identity as the sidebar, and for the same
          reason: an approval recorded on the client signs its audit line, and
          until 2026-08-20 it signed "Alex Morgan" on a live tenant's books while
          the server recorded the key label for the identical act. One identity in,
          one answer out — see lib/acting-as.js. */}
      <StoreProvider signedInAs={signedInAs}>
        {/* Only the PUBLIC half of the session crosses this boundary — tenant, key
            id, label. `session.key` is a live credential and is deliberately not
            threaded: AppShell is a client component, so anything passed here is
            serialised into the document and shipped to the browser. That is the
            whole reason `signedInAs` is built by hand instead of spreading the
            session object. `shell` carries no credential either: it is the
            sidebar's words and counts. */}
        <AppShell shell={shell} signedInAs={signedInAs}>
          {children}
        </AppShell>
      </StoreProvider>
    </EngineProvider>
  );
}
