import FirstRun from "@/components/month/FirstRun";
import MonthView from "@/components/month/MonthView";
import { chosenMonth, readMonthEnd, readOpenItems } from "@/components/month/month-reads";
import { SAMPLE_REASON } from "@/components/cards/words";
import { readBankAccount, needsSetup } from "@/components/setup/steps";
import { listBankAccountsAction } from "@/components/sync/actions";
import { documentsStatus } from "@/lib/documents";
import { readConversation, readMonth } from "@/lib/agent/client";
import { readClose } from "@/components/shell/shell-data";
import { readConnections } from "@/lib/connections";
import { readCloseLock, readDocuments } from "@/lib/close";
import { readCloseData } from "@/lib/engine-server";
import { readLedger } from "@/lib/ledger";
import { closeMonthOf, isPeriod } from "@/lib/period";
import { NOTHING_STARTED, monthToShow } from "@/app/clients/model";
import { AUTH_REQUIRED, chosenClient, readPeriods, readSession, readSessionsOf, visibleMonth } from "@/lib/session";
import { transientMonthFailure } from "@/components/month/last-good";
import { createHash } from "node:crypto";
import { sessionContract } from "@/lib/session-contract";

// app/page.js — MONTH-END (`/`), THE ONE HOME PAGE
// ==============================================================================
// Spec §3.2; build plan §3 F3. This used to redirect to the payout register. The agent
// workspace has one destination, and it is the month: the ask box, how far the month
// has got, and the decisions that need you, the first one open.
//
// WHAT THIS SERVER COMPONENT READS, and nothing else:
//   · which month: the one the address names (`?period=`), else the one this browser
//     chose (the month control's cookie), if the service has it, else the latest the
//     service lists — the same rule the sidebar uses
//     (components/shell/shell-data.js), so the badge and this page count one month;
//   · the month: `GET /close/{period}` through lib/agent/client.js (the export's recorded
//     month in the static build);
//   · for each task that needs you, its conversation's events, so the cards can be drawn
//     here with their whole payload — figures, prefill and all;
//   · the ledger (`/approvals/ledger`), which names where Post would write, or says none;
//   · Step 5's lock status (`GET /close/{period}/lock`, W4 29 Oct 2026), for the "Close
//     the month" panel: whether the month is signed off and the ledger's lock date. A
//     GET; asked only for a month the panel is drawn for (month-reads.js readMonthEnd).
//
// FIRST RUN IS DECIDED ON A KNOWN ANSWER ONLY. `needsSetup` is false whenever the reads
// did not land — a failed read is not a client with nothing connected — so a slow or
// absent service never bounces a working client into setup. In the static build there
// is no service and nothing to connect, and the recorded month renders.
//
// NOTHING IS COUNTED HERE. Every number on the page is the payload's (UI-001).
//
// A PAGE VIEW SENDS NO WRITE (smoke test on staging, 23 Oct 2026). Whether the engine
// reads files is asked HERE, on the server, and handed to the ask box. The ask box used
// to ask it from an effect, and `documentsStatus` is a server action (lib/documents.js is
// "use server"), so every view of this page sent a `POST /` from the browser before
// anyone pressed anything: a read on the engine's side, a write on the wire, refused by a
// read-only tester with a console error. On the server it is a plain function call.
// tests/p0-quiet-page-load.test.js guards every effect this page and the shell run.
//
// NOR IS ANYTHING CAUGHT UP HERE, OR ON LOAD AT ALL. `GET /close` never writes (build plan
// §4.0.2); when it says `catchUp.needed`, the page offers Catch up and only that press
// calls `POST /close` (components/month/MonthView.js useCatchUp; staging browser walk 1,
// 31 Oct 2026: catching up on every load re-ran the scans until Xero's day ran out).
// This server component only says whether the press may be offered: a live month read
// from the service, never the static build's recorded one.

export const metadata = { title: "Month-end · Vert" };

// THE FUNCTION MAY RUN AS LONG AS VERT'S ANSWER TAKES (p0, 23 Oct 2026). A Server
// Action runs in its page's function, and this page's (Start the month, + Task, a
// task's change)
// waits on a model turn the engine answers inside its request (up to 240 s; the
// engine-side client waits AGENT_TURN_TIMEOUT_MS, lib/engine-source.js). Vercel stops a
// function at its maxDuration, so this one declares the most the plan allows.
export const maxDuration = 300;

/** The listing's periods, or null when it was not read (unread is never empty). */
function listedPeriods(periodsRead) {
  return periodsRead && periodsRead.ok && Array.isArray(periodsRead.body)
    ? periodsRead.body.map((m) => m && m.period)
    : null;
}

// A client whose listing answered with no months shows the month this browser carried
// in (a jump from the Clients view sets it), as a not-started month — the same
// month the Clients row counted (eval r1 #20). With nothing carried in it shows the
// current close month, not started, so its first screen offers "Start September" and
// its ask box has a month to send (G4 eval r1, NF-1st). The rule is
// app/clients/model.js's.
function chooseMonth(engine, periodsRead, chosen) {
  const shown = monthToShow(listedPeriods(periodsRead), chosen, closeMonthOf(new Date()));
  if (shown) return shown;
  const recorded = engine && engine.close && engine.close.period;
  if (isPeriod(recorded)) return recorded;
  return engine && isPeriod(engine.period) ? engine.period : null;
}

/**
 * The "Close the month" panel's status, as MonthView takes it: the engine's lock status,
 * or null with the words for why it wasn't read; the sample says it has none.
 */
function closeOf(lock, sample) {
  if (sample) return { status: null, words: null, sample: true };
  if (lock && lock.ok) return { status: lock.body, words: null };
  return { status: null, words: lock && lock.message ? lock.message : null };
}

/** The Documents card's reading, as MonthView takes it: the checklist, or null with why. */
function documentsOf(read, sample) {
  if (sample) return { body: null, words: null, sample: true };
  if (read === undefined) return undefined;
  if (read && read.ok) return { body: read.body, words: null };
  return { body: null, words: read && read.message ? read.message : null };
}

/**
 * THE KEY A TAB KEEPS ITS LAST GOOD BOARD UNDER (staging browser walk 1, D2;
 * components/month/last-good.js): one-way, from who is signed in and the client chosen,
 * so a board kept for one client is never drawn for another, nor for the next person
 * on this tab. Null where nobody is signed in (the static build keeps nothing).
 */
async function boardKeyOf(identity) {
  if (!AUTH_REQUIRED || !identity || typeof identity.tenant !== "string") return null;
  const client = await chosenClient(identity).catch(() => null);
  const basis = [identity.tenant, identity.keyId || "", identity.person || "", client || identity.tenant].join("|");
  return createHash("sha256").update(basis).digest("hex").slice(0, 24);
}

/** The months listing answered, and it listed none. */
function noMonths(periodsRead) {
  return Boolean(periodsRead && periodsRead.ok && Array.isArray(periodsRead.body) && periodsRead.body.length === 0);
}

async function firstRunState() {
  if (!AUTH_REQUIRED) return null;
  const [connections, bankAccounts] = await Promise.all([readConnections(), listBankAccountsAction()]);
  if (!needsSetup({ connections, bank: readBankAccount(bankAccounts) })) return null;
  // The same two reads /connections draws its rows from, handed over as they came back:
  // the list answers a failed read differently from an empty one (ConnectionsList).
  return { connections, bank: bankAccounts };
}

/**
 * THE MONTH, READ ONCE PER PAGE LOAD (verify pass 3, S-BK-8). The sidebar's badge
 * (components/shell/shell-data.js) and this page each asked `GET /close/{period}`, the
 * slowest read a page makes (it assesses every task), so every Month-end load paid for
 * it twice. Live, the page takes the shell's request-scoped read; the sample keeps its
 * recorded month.
 */
async function readMonthOnce(period) {
  if (!AUTH_REQUIRED || !period) return readMonth(period);
  const read = await readClose(period);
  return read.ok ? { ok: true, month: read.body, replay: false } : { ok: false, code: read.reason || "not_read", status: read.status ?? 0 };
}

export default async function MonthEndPage({ searchParams }) {
  // `/?period=2026-08` NAMES THE MONTH OUTRIGHT (p1/fix7, 27 Oct 2026): it wins over the
  // month cookie (month-reads.js chosenMonth); an invalid one is ignored. Read only where
  // there is a service: the static build has one recorded month, and reading the query
  // would turn its prerendered page dynamic (app/chat/[id]/page.js does the same).
  const query = AUTH_REQUIRED ? (searchParams && (await searchParams)) || {} : {};
  // EVERY READ GOES OUT AS SOON AS WHAT IT NEEDS IS KNOWN (components/month/month-reads.js
  // readMonthEnd). They used to run one after another, and this page is re-rendered after
  // every decision a card makes, so each serial hop was time the header spent showing the
  // count from before the press (lib/actions.js decideAndSettle); then the month waited
  // behind the whole payout register, and the staging page took 15.7 s (23 Oct 2026).
  const { setup, periodsRead, engine, identity, documents, period, monthRead, ledger, itemsByTask, figures, runs, lock, monthDocuments } = await readMonthEnd(
    {
      setup: firstRunState,
      engine: readCloseData,
      periods: readPeriods,
      chosen: chosenMonth(query, visibleMonth),
      // Who is looking, for the checklist's "Assigned to you" and its approver-only "Mark
      // complete". Read only through sessionContract(), so a session that names nobody
      // (every one, until FIRM binds a person key) gives null and neither appears. The
      // static build has no cookie to read, so it is not asked.
      identity: () => (AUTH_REQUIRED ? readSession() : Promise.resolve(null)),
      // Whether the engine reads files, for the ask box's attach control. Any doubt is off;
      // the static build has no engine to ask.
      documents: () => (AUTH_REQUIRED ? documentsStatus().catch(() => null) : Promise.resolve(null)),
      month: (period) => (period || !AUTH_REQUIRED ? readMonthOnce(period) : Promise.resolve({ ok: false, code: "no_period" })),
      ledger: () => readLedger(),
      openItems: (month, options) => readOpenItems(month, options),
      // The month's conversation list (the sidebar's own read, one request per page) and
      // one conversation: the tasks' conversations are asked as soon as the list names
      // them, beside GET /close rather than after it (month-reads.js readMonthEnd).
      sessions: (period) => readSessionsOf(period),
      conversation: (sessionId) => readConversation(sessionId),
      // Sign off and lock: a read of where the month stands. The static build has no
      // ledger behind it and asks nothing.
      lock: AUTH_REQUIRED ? (period) => readCloseLock(period) : undefined,
      // The month's documents (w33, audit 1.1): statements, bills and receipts. A page
      // read, so the engine reads no Xero; the card's Check bills press does.
      monthDocuments: AUTH_REQUIRED ? (period) => readDocuments(period) : undefined,
    },
    { choose: chooseMonth, noMonths }
  );
  // FIRST RUN IS FOR A CLIENT WITH NO MONTH TO SHOW. Setup is "incomplete" for any tenant
  // with no ledger connected — and posting without a ledger is a supported state, said
  // on the approve card — so gating on setup alone put a tenant whose July was open with
  // decisions waiting on the connect screen instead, for good, as soon as the API could
  // answer the connections read (found on the isolated r3 stack, 1 Oct). A month listed
  // by `/close/periods` (one with payouts, or one somebody opened) is work to show, so
  // first run needs setup AND a listing that answered with no months. An unread listing
  // is not an empty one: it never bounces anybody.
  if (setup && noMonths(periodsRead)) return <FirstRun connections={setup.connections} bank={setup.bank} />;

  const month = monthRead.ok ? monthRead.month : null;
  const sample = !AUTH_REQUIRED;
  const clientName = engine && typeof engine.business === "string" ? engine.business : null;
  const boardKey = await boardKeyOf(identity);

  return (
    // THE HOMEPAGE IS THE ORCHESTRATION BOARD (founders, 22 Oct 2026): every task of the
    // month as a row under Working now / Needs you / Waiting / Done, with the month-end
    // checklist one press away (`?view=checklist`). `runs` is each read conversation's
    // latest run (month-reads.js), for the rows' lines and step bars.
    <MonthView
      initialView="board"
      runs={runs}
      month={month}
      period={(month && month.period) || period}
      itemsByTask={itemsByTask}
      figures={figures}
      ledger={ledger}
      clientName={clientName}
      viewer={sessionContract(identity).person}
      documentsEnabled={Boolean(documents && documents.ok && documents.enabled === true)}
      close={closeOf(lock, sample)}
      monthDocuments={documentsOf(monthDocuments, sample)}
      disabledReason={sample ? SAMPLE_REASON : null}
      canCatchUp={!sample && monthRead.ok && monthRead.replay !== true}
      // A good read is kept for this tab; a read that timed out (the 15 s limit) or met
      // the service's own failure draws the kept board, "as at" its time (D2).
      keep={boardKey && period ? { key: boardKey, failed: transientMonthFailure(monthRead) } : null}
      // A read that was sent and failed can be sent again; a sample with no month, or a
      // client whose listing named no month, has nothing a second read would find.
      canRetry={!monthRead.ok && !sample && Boolean(period)}
      unreadReason={
        monthRead.ok
          ? null
          : sample
            ? "This sample has no month to show yet."
            : !period && noMonths(periodsRead)
              ? NOTHING_STARTED
              : "This month couldn't be read just now. Nothing was changed."
      }
    />
  );
}
