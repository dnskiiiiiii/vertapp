"use client";

// app/error.js — A FAILURE INSIDE A PAGE LEAVES THE SHELL STANDING
// ==============================================================================
// Audit UI-002: an approve that failed on the network replaced the WHOLE APP with a
// framework error, so the person could not tell whether the approval was recorded, and
// a reload invited a second press. This boundary sits under the root layout, so for any
// route below it the sidebar, the month and the account menu stay exactly where they
// were, and only the page's own area says what happened.
//
// The sentence is for the bookkeeper: it cannot know what was recorded, so it says
// that plainly and points at the one place that can say — the page, reloaded — rather
// than claiming "nothing was recorded" about a write it did not see. The digest (which
// is what an operator looks up in the server log) is under Details. Retry re-renders
// the segment; it does not re-send anything.

import { Notice } from "@/components/ui/Notice";

export default function RouteError({ error, reset }) {
  const details = error && error.digest ? `Reference ${error.digest}` : undefined;
  return (
    <section className="route-state" aria-labelledby="route-error-title">
      <h1 className="t-title-2" id="route-error-title">
        This page stopped working
      </h1>
      <Notice kind="error" recorded="unknown" onRetry={reset} retryLabel="Try again" details={details}>
        Vert couldn’t finish showing it.
      </Notice>
    </section>
  );
}
