import { Suspense } from "react";

import ConnectionReturn from "@/components/settings/ConnectionReturn";
import ConnectionsSkeleton from "@/components/settings/ConnectionsSkeleton";
import ConnectionsList from "@/components/setup/ConnectionsList";
import ReminderEmail from "@/components/setup/ReminderEmail";
import { listBankAccountsAction } from "@/components/sync/actions";
import { readConnections } from "@/lib/connections";
import { readEmailSettings, readSentReminders } from "@/lib/reminders";
import { accountAsked, sheetAsked } from "@/components/setup/connections-link";

export const metadata = { title: "Connections · Vert" };

// Sync now is pressed from this page, and the staging worker answers it only when the
// run is over (a Xero bank-and-ledger read is 15–30 s; components/sync/worker-transport.js
// RUN_TIMEOUT_MS). A Server Action runs in its page's function, so this page allows the
// most the plan does, as app/page.js does.
export const maxDuration = 300;

// /connections — WHAT VERT READS FROM (spec §3.6), reached from the account menu.
//
// ONE SURFACE OF ROWS. Stripe, Shopify, QuickBooks, the bank account and a bank
// statement import, each one row with its state in words and one action; Connect and
// Import open sheets (components/setup/ConnectionsList.js). It used to be three
// headed blocks and a column 1800px long with the page head inside a card (UI-067),
// plus a separate /setup errand saying the same Stripe instructions again (UI-061).
// /setup and /settings redirect here now (next.config.mjs), and Month-end's first run
// renders this same list.
//
// WHAT LEFT THIS PAGE, AND WHY. The account-mapping block (a CLI command and a note
// about "whoever runs this service") and the "N settlements are already in this
// tenant's register" line were written for an operator; a bookkeeper can act on
// neither (spec §3.6: no operator text). The register's freshness is on the Stripe row
// now, in words, where it is about the thing that brings payouts in.
//
// THIS PAGE DOES NOT KNOW WHICH DATA SOURCE IS IN USE, and that is enforced —
// tests/no-arithmetic.test.js keeps the list of modules allowed to import
// lib/engine-source short. `readConnections` answers for both modes, and answers a
// FAILED read differently from an EMPTY one; the list renders the difference.
//
// THE TITLE IS NOT BEHIND THE NETWORK. The heading is static and ships at once; each
// read is suspended behind its own boundary and arrives when it arrives, so a slow
// service never leaves a blank frame with no evidence the navigation happened.
//
// THE RETURN LEG IS ANSWERED FIRST. A person arriving back from a vendor's consent
// screen is holding one question — did that work? — so ConnectionReturn sits above the
// rows, behind its own boundary (`searchParams` is a promise in Next 16).
export default function ConnectionsPage({ searchParams }) {
  return (
    // THE SHARED PAGE COLUMN (design-pass spec §7.1; audit §13). Connections used to start
    // flush left in the panel while every other page centred: the same kind of page now
    // lives in the same place, under the same head.
    <div className="page connections-page">
      <header className="page-head">
        <h1 className="t-title-1">Connections</h1>
      </header>
      <Suspense fallback={null}>
        <ReturnNote params={searchParams} />
      </Suspense>
      <Suspense fallback={<ConnectionsSkeleton />}>
        <ConnectionsSection params={searchParams} />
      </Suspense>
      {/* EMAIL FOR REMINDERS (W3 feature 1, 28 Oct 2026): how this client's payment
          reminders go out, behind its own boundary so a slow read holds up nothing. */}
      <Suspense fallback={null}>
        <ReminderEmailSection />
      </Suspense>
    </div>
  );
}

// The outcome of an OAuth round trip, or nothing at all on an ordinary visit. It is a
// report of what happened at the callback a moment ago; the rows below are the live
// answer, and the wording defers to them (lib/connection-return.js).
async function ReturnNote({ params }) {
  return <ConnectionReturn params={await params} />;
}

// The two reads the rows are drawn from, side by side. The bank-account listing only
// matters once a ledger is connected (it lists the ledger's accounts), and it answers
// for itself when it cannot: the row then says "Not checked" rather than "not chosen".
async function ConnectionsSection({ params }) {
  const [connections, bank] = await Promise.all([readConnections(), listBankAccountsAction()]);
  const query = await params;
  return (
    <div className="skel-in">
      <ConnectionsList connections={connections} bank={bank} openSheet={sheetAsked(query)} importAccount={accountAsked(query)} />
    </div>
  );
}

// How payment reminders are sent, read on the server (GET /reminders/email): the row
// draws a failed read as "Not checked" with the engine's words, never as not connected.
// The sent list (GET /reminders/sends) is read beside it, for the sheet's "Sent
// reminders" (contract v2), behind the same boundary.
async function ReminderEmailSection() {
  const [answer, sent] = await Promise.all([readEmailSettings(), readSentReminders(50)]);
  return (
    <div className="skel-in">
      <ReminderEmail answer={answer} sent={sent} />
    </div>
  );
}
