// app/connections/loading.js — the shape of Connections while it comes (UI-016), on the
// same page column and under the same head as the answer (design-pass spec §7.1).
import ConnectionsSkeleton from "@/components/settings/ConnectionsSkeleton";

export default function ConnectionsLoading() {
  return (
    <div className="page connections-page">
      <header className="page-head">
        <h1 className="t-title-1">Connections</h1>
      </header>
      <ConnectionsSkeleton />
    </div>
  );
}
