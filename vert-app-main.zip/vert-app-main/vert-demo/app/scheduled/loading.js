// app/scheduled/loading.js — the shape of Scheduled while it comes. Static blocks, no shimmer.

import { Skeleton } from "@/components/ui/marks";

export default function ScheduledLoading() {
  return (
    <section className="route-state route-loading sched">
      <Skeleton lines={6} label="Loading" />
    </section>
  );
}
