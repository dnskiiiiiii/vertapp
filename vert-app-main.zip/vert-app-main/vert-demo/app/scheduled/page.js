// app/scheduled — THE ROUTINES: DAILY, WEEKLY, MONTHLY
// ==============================================================================
// research/2026-10-27-w3-build/scheduled-spec.md (founder approved 31 Oct 2026). Bills &
// invoices and Journals stopped being modules: their recurring work lives here, beside
// the sync, the reminders, depreciation and the month's start. /bills is redirected to
// `/scheduled?task=bills` (next.config.mjs), which opens that task's sheet on arrival.
//
// The list is read here, on the server, with the key (lib/scheduled.js). A read that
// failed, or a build with no service, is drawn as that ("Not read"): a list that wasn't
// read is never drawn as an empty one.

import ScheduledScreen from "@/components/scheduled/ScheduledScreen";
import { listScheduled } from "@/lib/scheduled";

export const metadata = { title: "Scheduled · Vert" };
export const dynamic = "force-dynamic";
// A write pressed here (approve, post, a scheduled journal's Create) waits up to the
// engine's 300 s (lib/engine-source.js WRITE_TIMEOUT_MS, walk 2 N3), so this function
// is let run that long rather than cut before the write answers.
export const maxDuration = 300;

const TASK = /^[A-Za-z0-9_:.-]{1,128}$/;

export default async function ScheduledPage({ searchParams }) {
  const params = (await searchParams) || {};
  const list = await listScheduled();
  const task = typeof params.task === "string" && TASK.test(params.task) ? params.task : null;
  return <ScheduledScreen initial={list} openTask={task} />;
}
