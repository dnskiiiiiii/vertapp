// app/api/sync — THE SYNC'S READS, FROM THE BROWSER
// ==============================================================================
//   GET /api/sync?latest        → latestSync()             `{ ok, run }`
//   GET /api/sync?register      → registerFreshness()      `{ ok, register }`
//   GET /api/sync?run=<id>      → pollSync(id)             `{ ok, run }`
//   GET /api/sync?accounts      → listBankAccountsAction() `{ ok, kind, message, accounts, chosen }`
//
// WHY A ROUTE FOR THE READS (staging walkthrough, 28 Oct 2026). Opening Connections sent
// two Server Action POSTs before anyone pressed anything: useSync read the register and
// the latest run by calling Server Actions from its mount effect. A page view must send
// GETs only (tests/p0-quiet-page-load.test.js), as /api/journal, /api/tasks and
// /api/skills were done. The functions are the same ones, called here on the server, so
// the worker's address and token still never reach a browser, and each answer is the
// described outcome the action gave (the URL already stripped in components/sync/actions.js).
//
// NO WRITE IS SERVED HERE. Starting a sync and choosing the bank account stay presses,
// through their own Server Actions.

import { latestSync, listBankAccountsAction, pollSync, registerFreshness } from "@/components/sync/actions";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

// The action's own outcome, with a status a proxy can read. A refusal the worker SPOKE
// (no kind: "nothing to list yet") is a state, answered 200 with its sentence.
function answer(result) {
  const r = result && typeof result === "object" ? result : { ok: false, kind: "unreachable", code: "unreachable", message: "" };
  if (r.ok || !r.kind) return reply(r, 200);
  const status =
    r.kind === "unavailable" ? 503 : r.code === "unauthenticated" ? 401 : r.code === "invalid_request" ? 400 : r.kind === "refused" && /^http_4\d\d$/.test(r.code || "") ? Number(r.code.slice(5)) : 502;
  return reply(r, status);
}

async function settle(read) {
  try {
    return answer(await read());
  } catch {
    // Outside a request the session cannot be read; on a real deployment, a fault. Either
    // way the browser hears a refusal by code, never a run or an empty register.
    return reply({ ok: false, kind: "unreachable", code: "unreachable", message: "" }, 502);
  }
}

export async function GET(request) {
  const params = new URL(request.url).searchParams;
  if (params.has("latest")) return settle(() => latestSync());
  if (params.has("register")) return settle(() => registerFreshness());
  if (params.has("accounts")) return settle(() => listBankAccountsAction());
  if (params.has("run")) return settle(() => pollSync(params.get("run") || ""));
  return reply({ ok: false, code: "unknown_read" }, 400);
}
