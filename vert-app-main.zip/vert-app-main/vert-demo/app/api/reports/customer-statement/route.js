// app/api/reports/customer-statement — A CUSTOMER'S STATEMENT AS A FILE, THROUGH THE APP
// ==============================================================================
//   GET ?contact=ID[&from=YYYY-MM-DD]&to=YYYY-MM-DD&format=pdf   → the engine's
//       GET /reports/customer-statement.pdf
//   GET …&format=xlsx                                              → …/customer-statement.xlsx
//
// w46 (audit row 20). A plain link to the engine can't carry the session's key, so the
// browser asks this app and the bytes come back untouched with the engine's own
// filename (lib/api-download.js), as the month-end pack's downloads do. A question that
// isn't one is refused with 400 before the engine is asked. A download is a read:
// nothing here writes, and nothing here sends the statement to anyone.

import { passThroughDownload } from "@/lib/api-download";
import { statementApiPath } from "@/components/reports/customer-statement";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET(request) {
  const q = new URL(request.url).searchParams;
  const path = statementApiPath(q.get("contact") || "", q.get("from") || null, q.get("to") || "", q.get("format") || "");
  if (!path || !/\.(pdf|xlsx)\?/.test(path)) {
    return new Response(JSON.stringify({ error: { code: "invalid_request", message: "Choose a customer, a statement date, and PDF or Excel." } }), {
      status: 400,
      headers: { "content-type": "application/json", "cache-control": "no-store" },
    });
  }
  return passThroughDownload(path);
}
