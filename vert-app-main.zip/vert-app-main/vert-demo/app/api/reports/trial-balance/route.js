// app/api/reports/trial-balance — THE TRIAL BALANCE AS A WORKBOOK, THROUGH THE APP
// ==============================================================================
//   GET ?asAt=YYYY-MM-DD&format=xlsx  → the engine's GET /reports/trial-balance.xlsx
//   GET ?asAt=YYYY-MM-DD              → the engine's GET /reports/trial-balance (JSON)
//
// Close Step 4.1 (w31). A plain link to the engine can't carry the session's key, so
// the browser asks this app and the bytes come back untouched with the engine's own
// filename (lib/api-download.js), as the month-end pack's downloads do. A date that
// isn't one is refused with 400 before the engine is asked. A read: nothing writes.

import { passThroughDownload, readApiJson } from "@/lib/api-download";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };
const ISO_DAY = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export async function GET(request) {
  const q = new URL(request.url).searchParams;
  const asAt = q.get("asAt") || "";
  if (asAt && !ISO_DAY.test(asAt)) return reply({ error: { code: "invalid_request", message: "That isn't a date Vert can strike a trial balance at." } }, 400);
  const query = asAt ? `?asAt=${asAt}` : "";
  if (q.get("format") === "xlsx") return passThroughDownload(`/reports/trial-balance.xlsx${query}`);
  const read = await readApiJson(`/reports/trial-balance${query}`);
  if (!read || read.error) return reply({ error: { code: "not_read", message: (read && read.error) || "Vert couldn't read the trial balance just now." } }, 502);
  return reply(read.body, 200);
}
