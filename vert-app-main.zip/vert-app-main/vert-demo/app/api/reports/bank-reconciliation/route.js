// app/api/reports/bank-reconciliation — THE BANK RECONCILIATION REPORT, READ FROM THE BROWSER
// ==============================================================================
//   GET /api/reports/bank-reconciliation?period=YYYY-MM[&account=…]
//     → `{ read, ledgerName }`: lib/bank-rec-report.js readBankRecReport's answer, and
//       the ledger's name for the report's words
//
// Founder, 8 Nov 2026: the chat's "Open the report" opens the report in a side sheet
// beside the conversation (components/reports/ReportSheet.js), not on its page. The key
// stays on the server. A read: nothing here writes.

import { readBankRecReport } from "@/lib/bank-rec-report";
import { readLedger } from "@/lib/ledger";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

export async function GET(request) {
  const q = new URL(request.url).searchParams;
  const account = (q.get("account") || "").trim() || null;
  const [read, ledger] = await Promise.all([readBankRecReport({ account, period: q.get("period") }), readLedger()]);
  const ledgerName = ledger && ledger.configured === true && typeof ledger.displayName === "string" ? ledger.displayName : null;
  return new Response(JSON.stringify({ read, ledgerName }), { status: 200, headers: HEADERS });
}
