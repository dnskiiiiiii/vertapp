// app/api/reports/account-transactions — ACCOUNT TRANSACTIONS, READ FROM THE BROWSER
// ==============================================================================
//   GET /api/reports/account-transactions?accounts=453,090&from=YYYY-MM-DD&to=YYYY-MM-DD
//     → the engine's GET /reports/account-transactions, as it answered
//
// WHY A ROUTE (close Step 4.2, w31). The trial balance's rows open an account's lines
// in a side sheet (components/reports/TrialBalanceView.js); the read needs the
// session's key, which stays on the server (lib/api-download.js readApiJson). The
// question is checked here first (components/reports/account-transactions.js
// accountTransactionsPath), so the browser can't make this app ask the engine for a
// path of its choosing. A read: nothing here writes. The engine reads Xero for the
// range and keeps it five minutes.

import { readApiJson } from "@/lib/api-download";
import { accountTransactionsPath } from "@/components/reports/account-transactions";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export async function GET(request) {
  const q = new URL(request.url).searchParams;
  const accounts = (q.get("accounts") || "").split(",").map((a) => a.trim()).filter(Boolean);
  const from = q.get("from") || "";
  const to = q.get("to") || "";
  const ours = accountTransactionsPath({ accounts, from, to });
  if (!ours) return reply({ error: { code: "invalid_request", message: "Name up to 12 accounts and a date range, first day on or before the last." } }, 400);
  const engine = ours.replace(/^\/api/, "");
  const read = await readApiJson(engine);
  if (!read || read.error) return reply({ error: { code: "not_read", message: (read && read.error) || "Vert couldn't read the account's transactions just now." } }, 502);
  return reply(read.body, 200);
}
