// app/api/tasks — THE NEW TASK FORM'S TWO READS, FROM THE BROWSER
// ==============================================================================
//   GET /api/tasks?presets   → `{ ok, presets }`, the engine's `GET /tasks/presets`
//   GET /api/tasks?groups    → `{ ok, groups }`, the engine's `GET /tasks/groups`
//
// WHY A ROUTE FOR THE READS (walkthrough, 27 Oct 2026). Opening the New task sheet sent
// two `POST /` requests with a `Next-Action` header: the form read its presets and the
// client's groups by calling `listTaskPresets` and `listTaskGroups`, Server Actions in
// lib/tasks.js. A read on the engine's side was a write on the wire, and each came back
// with a fresh render of the page (proxy.js slides the session cookie, and a changed
// cookie revalidates). These GETs return the list and nothing else, as /api/skills and
// /api/budgets do for their sheets (tests/p0-quiet-page-load.test.js).
//
// THE KEY STAYS ON THE SERVER: lib/tasks.js reads it from the sealed session. A read
// that failed answers its code and no list: an empty list would read as "no tasks" or
// "no groups", which is a claim. The form words the refusal.
//
// POST AND PATCH ARE NOT SERVED HERE. Create, a change and New group are Server Actions
// (lib/tasks.js), which add the actor and read every write back; a second road that took
// a press from a plain fetch would be one more place to forget the actor. They answer
// 501 with a code.

import { listTaskGroups, listTaskPresets } from "@/lib/tasks";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

function failed(result) {
  const r = result || {};
  const status = r.kind === "unavailable" ? 503 : r.kind === "unreachable" ? 502 : Number.isInteger(r.status) && r.status >= 400 ? r.status : 502;
  return reply({ ok: false, code: r.code || "unreachable" }, status);
}

export async function GET(request) {
  const params = new URL(request.url).searchParams;
  if (params.has("presets")) {
    const result = await listTaskPresets();
    return result && result.ok && Array.isArray(result.presets) ? reply({ ok: true, presets: result.presets }, 200) : failed(result);
  }
  if (params.has("groups")) {
    const result = await listTaskGroups();
    return result && result.ok && Array.isArray(result.groups) ? reply({ ok: true, groups: result.groups }, 200) : failed(result);
  }
  return reply({ ok: false, code: "unknown_read" }, 400);
}

function notBuilt() {
  return reply({ error: { code: "not_built" } }, 501);
}

export const POST = notBuilt;
export const PATCH = notBuilt;
