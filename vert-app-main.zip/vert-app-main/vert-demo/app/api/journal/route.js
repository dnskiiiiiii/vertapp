// app/api/journal — ONE JOURNAL ENTRY, READ FROM THE BROWSER
// ==============================================================================
//   GET /api/journal?entry=je:4fcfbe5aff66 → `{ ok, people, posted }`
//   GET /api/journal?accounts               → `{ ok, accounts }` the chart, for a picker
//                                             (components/cards/chart-read.js)
//   GET /api/journal?list                   → `{ ok, journal }` every entry, the list
//                                             Records reads again after a decision (W8-2)
//
// WHY A ROUTE FOR THE READ (staging walkthrough D4, 27 Oct 2026). Opening an entry on
// Records sent two `POST /records` requests with a `Next-Action` header: the sheet read
// who drafted, approved and posted it, and its filed documents, by calling Server
// Actions from effects. One engine read (`GET /journal/{id}`) answers both, so this
// GET returns both shapes (components/records/entry-people.js and
// components/cards/journal-model.js postedReadingOf) and nothing else, as /api/skills,
// /api/budgets and /api/tasks do (tests/p0-quiet-page-load.test.js).
//
// THE KEY STAYS ON THE SERVER: lib/entry-read.js reads it from the sealed session. A
// read that failed answers its code, never an empty entry. Writes (approve, post,
// reverse) are not served here: they stay presses through their own Server Actions.

import { readEntryForBrowser } from "@/lib/entry-read";
import { readCardLedger, readChartAccounts } from "@/lib/journal";
import { readJournalList } from "@/lib/journal-list";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

const ENTRY_ID = /^[a-z]{1,16}:[0-9a-f]{6,64}$/;

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export async function GET(request) {
  const params = new URL(request.url).searchParams;
  if (params.has("ledger")) {
    // The cards' ledger descriptor (components/cards/useCardLedger.js), staging D4 retest.
    const ledger = await readCardLedger();
    return ledger && typeof ledger === "object" && ledger.ok !== false ? reply({ ok: true, ledger }, 200) : reply({ ok: false, code: (ledger && ledger.code) || "unreachable" }, ledger && ledger.kind === "unavailable" ? 503 : 502);
  }
  if (params.has("list")) {
    // The Journal entries list, read again after a decision in its sheet (W8-2).
    const read = await readJournalList();
    if (read.ok) return reply({ ok: true, journal: read.journal }, 200);
    return reply({ ok: false, code: read.code }, read.code === "no_service" ? 503 : read.code === "signed_out" ? 401 : 502);
  }
  if (params.has("accounts")) {
    // The chart of accounts for the editors' pickers (staging browser walk 1, 31 Oct
    // 2026): this was the readChartAccounts Server Action, a POST from an effect.
    const chart = await readChartAccounts();
    if (chart && chart.ok) return reply({ ok: true, accounts: chart.accounts }, 200);
    const c = chart || {};
    return reply({ ok: false, code: c.code || "unreachable", message: c.message || null }, c.kind === "unavailable" ? 503 : c.kind === "refused" ? 409 : 502);
  }
  const entryId = params.get("entry") || "";
  if (!ENTRY_ID.test(entryId)) return reply({ ok: false, code: "bad_entry_id" }, 400);
  const result = await readEntryForBrowser(entryId);
  if (result && result.ok) return reply({ ok: true, people: result.people, posted: result.posted }, 200);
  const r = result || {};
  const status = r.kind === "unavailable" ? 503 : Number.isInteger(r.status) && r.status >= 400 ? r.status : 502;
  return reply({ ok: false, code: r.code || "unreachable" }, status);
}
