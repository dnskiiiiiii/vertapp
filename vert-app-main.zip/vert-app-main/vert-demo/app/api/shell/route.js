// app/api/shell/route.js — THE SIDEBAR'S OWN RE-READ OF THIS MONTH
// ==============================================================================
// While a conversation is Vert's working, the sidebar has to learn when it starts
// needing you (spec §4.5). It used to learn by calling `router.refresh()` every 15
// seconds, which re-renders the whole route on a timer: a page that changes itself
// with nobody touching it, and, when the read was slow or cut off, Next's fallback
// turned the refresh into a full browser navigation back to the page being left
// (eval iter 1, D6: "interrupted by another navigation"). This route answers the two
// figures the sidebar keeps live, as data, and a failed read changes nothing on screen.
//
// Read through the same reader as the layout (components/shell/shell-data.js
// readShellMonth), with the signed-in session's credential; the proxy has already
// refused a request with no session.

import { readShellMonth } from "@/components/shell/shell-data";
import { isPeriod } from "@/lib/period";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

export async function GET(request) {
  const period = new URL(request.url).searchParams.get("period");
  if (!isPeriod(period)) {
    return new Response(JSON.stringify({ ok: false, code: "invalid_period" }), { status: 400, headers: HEADERS });
  }
  // `close=0`: the list only, for the poll while something is Vert's working.
  const close = new URL(request.url).searchParams.get("close") !== "0";
  const month = await readShellMonth(period, null, { close });
  return new Response(JSON.stringify({ ok: true, period, ...month }), { status: 200, headers: HEADERS });
}
