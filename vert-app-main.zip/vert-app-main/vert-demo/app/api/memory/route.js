// app/api/memory — WHAT VERT KNOWS ABOUT THIS CLIENT, READ FROM THE BROWSER
// ==============================================================================
// Build plan §19.6 F-BRAIN. `GET /api/memory?template=` → `{ ok, knows: {measured,
// answers} }` (lib/memory.js `listWhatVertKnows`). Forget is a Server Action in
// lib/memory.js, read back before it is reported; this route only reads, for the
// reason app/api/skills gives. The key stays on the server; a refusal is a code.

import { listWhatVertKnows } from "@/lib/memory";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

export async function GET(request) {
  const template = new URL(request.url).searchParams.get("template") || null;
  const result = await listWhatVertKnows(template);
  if (result.ok) return new Response(JSON.stringify({ ok: true, knows: result.knows }), { status: 200, headers: HEADERS });
  const status = result.kind === "unavailable" ? 503 : result.kind === "unreachable" ? 502 : result.status || 400;
  return new Response(JSON.stringify({ ok: false, kind: result.kind, code: result.code }), { status, headers: HEADERS });
}
