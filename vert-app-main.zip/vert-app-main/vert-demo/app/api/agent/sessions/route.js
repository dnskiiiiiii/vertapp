// app/api/agent/sessions — START (OR FIND) A CONVERSATION, FROM THE BROWSER
// ==============================================================================
// `POST { period, text | template | subject }` → `{ ok, sessionId, opening? }`, the
// described outcome of lib/agent/client.js `startConversation`. The ask box, a task
// row and Can-do-now reach it through lib/agent/actions.js.
//
// WHY A ROUTE AND NOT A SERVER ACTION: a server action here came back with a fresh
// render of the page it was called from, because proxy.js slides the session cookie on
// every request and a changed cookie makes an action revalidate. The router held the
// move to the conversation until that render ended, 2 s later (eval C4). This route
// returns the start and nothing else. lib/agent/actions.js has the measurements.
//
// THE KEY STAYS ON THE SERVER, as on every route under app/api/agent: the tenant key is
// read from the sealed session here (lib/session.js, through the client), never sent
// by the browser. Nothing here writes to the books: a conversation is Vert's own
// record, and a task it runs only reads.
//
// SAME ORIGIN ONLY. A server action checks the Origin header for us; a route handler
// must do it itself. The session cookie is SameSite=Lax, which already keeps it off a
// cross-site POST; this refuses one outright, so a page elsewhere cannot start a
// conversation in someone's name even on a browser that sends the cookie.

import { startConversation } from "@/lib/agent/client";
import { isSameOrigin } from "@/lib/agent/same-origin";

export const dynamic = "force-dynamic";

// THE FUNCTION MAY RUN AS LONG AS VERT'S ANSWER TAKES (p0, 23 Oct 2026). A start
// (typed text, a task, Run again)
// waits on a model turn the engine answers inside its request (up to 240 s; the
// engine-side client waits AGENT_TURN_TIMEOUT_MS, lib/engine-source.js). Vercel stops a
// function at its maxDuration, so this one declares the most the plan allows.
export const maxDuration = 300;

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

// The only fields a start carries (plan §2.3 `POST /agent/sessions`).
function requestOf(body) {
  const b = body && typeof body === "object" ? body : {};
  const out = {};
  if (typeof b.period === "string") out.period = b.period;
  if (typeof b.template === "string") out.template = b.template;
  if (typeof b.text === "string") out.text = b.text;
  if (b.again === true) out.again = true;
  if (typeof b.sessionId === "string" && b.sessionId) out.sessionId = b.sessionId;
  if (b.subject && typeof b.subject === "object" && typeof b.subject.kind === "string" && b.subject.id != null) {
    out.subject = { kind: b.subject.kind, id: String(b.subject.id) };
  }
  return out;
}

export async function POST(request) {
  if (!isSameOrigin(request)) {
    return reply({ ok: false, kind: "refused", status: 403, code: "cross_origin", message: "Nothing was recorded." }, 403);
  }
  let body = null;
  try {
    body = await request.json();
  } catch {
    return reply({ ok: false, kind: "refused", status: 400, code: "invalid_request", message: "Nothing was recorded." }, 400);
  }
  const result = await startConversation(requestOf(body));
  if (result.ok) return reply(result, 200);
  const status = result.kind === "unavailable" ? 503 : result.kind === "unreachable" ? 502 : result.status || 400;
  return reply({ ok: false, kind: result.kind, status: result.status || 0, code: result.code, message: result.message }, status);
}
