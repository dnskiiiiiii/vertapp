// app/api/agent/sessions/[id] — ONE CONVERSATION'S EVENTS AFTER A SEQ, FOR POLLING
// ==============================================================================
// The fallback when the stream fails twice (build plan §2.7): the browser reads
// `?after=<last seq>` every 1.5 s. Same key rule as the stream beside it: the key is
// added on the server and never sent to the browser.

import { readConversation } from "@/lib/agent/client";

export const dynamic = "force-dynamic";

export async function GET(request, { params }) {
  const { id } = await params;
  const raw = Number.parseInt(new URL(request.url).searchParams.get("after") ?? "", 10);
  const after = Number.isInteger(raw) && raw >= 0 ? raw : null;
  const result = await readConversation(id, { after });
  const headers = { "content-type": "application/json", "cache-control": "no-store" };
  if (!result.ok) {
    return new Response(JSON.stringify({ error: { code: result.code || result.kind } }), {
      status: result.status || 502,
      headers,
    });
  }
  return new Response(JSON.stringify({ session: result.session, events: result.events }), { status: 200, headers });
}
