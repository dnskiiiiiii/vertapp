// app/api/agent/sessions/[id]/events — THE CONVERSATION STREAM, WITH THE KEY LEFT HERE
// ==============================================================================
// The browser follows a conversation with an `EventSource` on THIS route. This route
// asks vert_api's `GET /agent/sessions/{id}/events` with the signed-in session's key
// (added in lib/agent/client.js from lib/session.js authHeaders) and streams the body
// through untouched. The key never reaches the browser: not in a URL, not in a query
// string, not in a header the page can read (build plan §1.2, §2.7).
//
// RESUMING. The browser holds the last `seq` it drew. It sends it as `?after=` when it
// reconnects on its own schedule, and the browser's own EventSource retry sends it as
// `Last-Event-ID`. The larger of the two wins, so a reconnect never replays an event
// the thread already has and never skips one it does not.

import { streamConversation } from "@/lib/agent/client";

export const dynamic = "force-dynamic";

function seqFrom(value) {
  const n = Number.parseInt(value ?? "", 10);
  return Number.isInteger(n) && n >= 0 ? n : null;
}

export async function GET(request, { params }) {
  const { id } = await params;
  const fromQuery = seqFrom(new URL(request.url).searchParams.get("after"));
  const fromHeader = seqFrom(request.headers.get("last-event-id"));
  const after = fromQuery === null ? fromHeader : fromHeader === null ? fromQuery : Math.max(fromQuery, fromHeader);

  const upstream = await streamConversation(id, { after, signal: request.signal });
  if (!upstream.ok) {
    // A code, never the service's prose: the browser's machine only needs to know the
    // stream did not open, and falls back to polling after two of these.
    return new Response(JSON.stringify({ error: { code: upstream.code || upstream.kind } }), {
      status: upstream.status || 502,
      headers: { "content-type": "application/json", "cache-control": "no-store" },
    });
  }
  return new Response(upstream.response.body, {
    status: 200,
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-store, no-transform",
      connection: "keep-alive",
      "x-accel-buffering": "no",
    },
  });
}
