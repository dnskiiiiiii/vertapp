// app/api/agent/artifacts/[id]/xlsx — EVERY RESULT'S WORKBOOK, THROUGH THE APP
// ==============================================================================
// Build plan §4.2 and §4.4 FP 4. The engine serves each result's workbook at
// `/agent/artifacts/{artifactId}.xlsx` (vert_api/routers/exports.py, built by
// result_book from the same table the pane draws). This route streams it to the
// browser with the key added on the server (lib/agent/client.js `artifactWorkbook`),
// as the conversation routes beside it do. Every delivered chip and the pane's
// Download point here, for every artifact kind (lib/agent/links.js maps the engine's
// `xlsxHref` to this path).
//
// A refusal answers with its status and a code, never a sentence and never a file
// (lib/agent/workbook-response.js): a workbook link that returned an empty or invented
// file would be worse than a download that fails.

import { artifactWorkbook } from "@/lib/agent/client";
import { workbookResponse } from "@/lib/agent/workbook-response";

export const dynamic = "force-dynamic";

export async function GET(_request, { params }) {
  const { id } = await params;
  return workbookResponse(await artifactWorkbook(typeof id === "string" ? id : ""));
}
