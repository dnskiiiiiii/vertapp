// app/api/agent/status — WHETHER THE ASSISTANT CAN ANSWER, AND NOTHING ELSE
// ==============================================================================
// `{ assistant: live | not_verified | failing | off | offline | not_set_up }` for the
// signed-in client. The API's operator remedy (which provider, which key reference) is
// dropped in lib/agent/client.js before it gets here: a bookkeeper never sees setup
// text (spec §10), and a field that is never sent cannot be drawn by mistake.

import { assistantState } from "@/lib/agent/client";

export const dynamic = "force-dynamic";

export async function GET() {
  const result = await assistantState();
  const headers = { "content-type": "application/json", "cache-control": "no-store" };
  if (!result.ok) {
    return new Response(JSON.stringify({ error: { code: result.code || result.kind } }), {
      status: result.status || 502,
      headers,
    });
  }
  return new Response(JSON.stringify({ assistant: result.assistant }), { status: 200, headers });
}
