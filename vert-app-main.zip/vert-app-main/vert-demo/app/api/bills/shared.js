// app/api/bills/shared.js — WHAT EVERY BILLS ROUTE ANSWERS WITH
//
// A refusal is its status and `{ ok: false, kind, code, message }`, never a 200 with an
// empty list: "no bills" is a claim, and an unread inbox is not one. Every route that
// changes something checks the request's origin first (S-SE-17), before the body is
// read, because it acts as the signed-in person.

export const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

/** The HTTP status a lib/bills.js refusal answers with. */
export function statusOf(result) {
  if (result.kind === "unavailable") return 503;
  if (result.kind === "unreachable" || result.kind === "unconfirmed") return 502;
  if (result.kind === "blocked") return 409;
  return Number.isInteger(result.status) && result.status >= 400 ? result.status : 400;
}

export function refusal(result) {
  // `reason` is the engine's detail.reason (confirm_duplicate), so the page can ask for the second press.
  return new Response(JSON.stringify({ ok: false, kind: result.kind, code: result.code, reason: result.reason || null, message: result.message || null }), { status: statusOf(result), headers: HEADERS });
}

export function answer(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

/** The refusal a cross-origin write gets, before its body is read. */
export function crossOrigin() {
  return refusal({ kind: "refused", status: 403, code: "cross_origin", message: "Nothing was changed." });
}

/** A JSON body, or null when it isn't one. */
export async function jsonOf(request) {
  try {
    const body = await request.json();
    return body && typeof body === "object" && !Array.isArray(body) ? body : null;
  } catch {
    return null;
  }
}
