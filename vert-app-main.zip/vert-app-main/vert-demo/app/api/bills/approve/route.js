// app/api/bills/approve — APPROVE THE SELECTED BILLS (POST { itemIds }, at most 50)
//
// Only ever the person's press of "Approve & send selected": each id is one they ticked.
// The engine approves each on its own and answers one result per id.

import { approveBills } from "@/lib/bills";
import { isSameOrigin } from "@/lib/agent/same-origin";
import { answer, crossOrigin, jsonOf, refusal } from "../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const body = await jsonOf(request);
  const result = await approveBills(body && Array.isArray(body.itemIds) ? body.itemIds : []);
  if (!result.ok) return refusal(result);
  return answer({ ok: true, results: result.results });
}
