// app/api/bills/contacts — XERO CONTACTS BY NAME, FOR "EMPLOYEE PAID" (walk 3, W3-5)
// ==============================================================================
//   GET /api/bills/contacts?q=oli → `{ ok, contacts: [{ contactId, name, isEmployee }], asAt }`
//
// From Vert's stored copy of the ledger's contacts (lib/bills.js searchContacts); the key
// is added on the server. A read: nothing is changed.

import { searchContacts } from "@/lib/bills";
import { answer, refusal } from "../shared";

export const dynamic = "force-dynamic";

export async function GET(request) {
  const q = new URL(request.url).searchParams.get("q") || "";
  const result = await searchContacts(q);
  if (!result.ok) return refusal(result);
  return answer({ ok: true, contacts: result.contacts, asAt: result.asAt });
}
