// app/api/bills — THE BILLS INBOX, THROUGH THE APP
// ==============================================================================
//   GET  /api/bills?status=   → the inbox (lib/bills.js listBills)
//   POST /api/bills           → add files (multipart `files`, `kind`): documents to the
//                               engine's /bills/upload, each .eml to /bills/email
//
// THE UPLOAD IS A ROUTE, NOT A SERVER ACTION, because a Server Action's body is capped at
// 1 MB and a scanned bill is not (app/api/documents/route.js, the same reason). The key
// is added on the server (lib/session.js); the browser never sees it.

import { listBills, uploadBills } from "@/lib/bills";
import { isSameOrigin } from "@/lib/agent/same-origin";
import { answer, crossOrigin, refusal } from "./shared";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function GET(request) {
  const status = new URL(request.url).searchParams.get("status") || null;
  const result = await listBills({ status });
  if (!result.ok) return refusal(result);
  return answer({ ok: true, items: result.items, counts: result.counts, xero: result.xero, unreadable: result.unreadable });
}

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  let form;
  try {
    form = await request.formData();
  } catch {
    const length = Number(request.headers.get("content-length") || 0);
    if (length > 0) {
      return refusal({ kind: "refused", code: "unreadable_upload", message: "Those files didn't arrive in full, so they weren't sent. Nothing was stored. Try again with files under 25 MB." });
    }
    return refusal({ kind: "refused", code: "no_file", message: "Choose a bill, an invoice or a forwarded email to add." });
  }
  const result = await uploadBills(form);
  if (!result.ok) return refusal(result);
  return answer({ ok: true, items: result.items, refused: result.refused, emails: result.emails }, 201);
}
