// app/api/bills/[id] — ONE BILL: READ IT (GET, `?refresh=1` re-reads Xero), SAVE EDITS (PATCH)

import { getBill, saveBill } from "@/lib/bills";
import { isSameOrigin } from "@/lib/agent/same-origin";
import { answer, crossOrigin, jsonOf, refusal } from "../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET(request, { params }) {
  const { id } = await params;
  const refresh = new URL(request.url).searchParams.get("refresh") === "1";
  const result = await getBill(typeof id === "string" ? id : "", { refresh });
  if (!result.ok) return refusal(result);
  return answer({ ok: true, item: result.item });
}

export async function PATCH(request, { params }) {
  if (!isSameOrigin(request)) return crossOrigin();
  const { id } = await params;
  const body = await jsonOf(request);
  const result = await saveBill(typeof id === "string" ? id : "", body || {});
  if (!result.ok) return refusal(result);
  return answer({ ok: true, item: result.item });
}
