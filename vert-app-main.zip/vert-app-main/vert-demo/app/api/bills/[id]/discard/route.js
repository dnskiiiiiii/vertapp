// app/api/bills/[id]/discard — SET ONE BILL ASIDE. It is never sent, and stays listed as set aside.

import { discardBill } from "@/lib/bills";
import { isSameOrigin } from "@/lib/agent/same-origin";
import { answer, crossOrigin, refusal } from "../../shared";

export const dynamic = "force-dynamic";

export async function POST(request, { params }) {
  if (!isSameOrigin(request)) return crossOrigin();
  const { id } = await params;
  const result = await discardBill(typeof id === "string" ? id : "");
  if (!result.ok) return refusal(result);
  return answer({ ok: true, item: result.item });
}
