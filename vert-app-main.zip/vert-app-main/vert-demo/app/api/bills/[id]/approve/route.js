// app/api/bills/[id]/approve — APPROVE ONE BILL, ON THE PERSON'S PRESS
//
// Sent to Xero as a draft, or (without the write permission) approved with its fields to
// enter by hand. A refusal (a blocking flag, a duplicate, a settled state) is the
// engine's 409 or 422 in its own words.

import { approveBill } from "@/lib/bills";
import { isSameOrigin } from "@/lib/agent/same-origin";
import { answer, crossOrigin, jsonOf, refusal } from "../../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(request, { params }) {
  if (!isSameOrigin(request)) return crossOrigin();
  const { id } = await params;
  // `confirmDuplicate` (a possible duplicate) and `checkedLedger` (retrying a send that may
  // have landed) are the person's second press: only `true` counts, and a body that isn't
  // JSON (or is absent) is no confirmation.
  const body = await jsonOf(request);
  // `remember` is the person's Remember tick: only `true` saves the bill's coding as a
  // rule (engine w36, opt-in), and the engine's sentence for it comes back as `remembered`.
  const result = await approveBill(typeof id === "string" ? id : "", {
    confirmDuplicate: Boolean(body && body.confirmDuplicate === true),
    checkedLedger: Boolean(body && body.checkedLedger === true),
    remember: Boolean(body && body.remember === true),
  });
  if (!result.ok) return refusal(result);
  return answer({ ok: true, item: result.item, outcome: result.outcome, remembered: result.remembered || null });
}
