// app/api/write-offs/shared.js — THE WIRE FOR BAD-DEBT WRITE-OFFS, AND ITS RULES
// ==============================================================================
// W4 (29 Oct 2026), on the engine's routes (vert_api/routers/write_offs.py):
//
//   GET  /write-offs/accounts        {accounts, choice, words}                 read
//   GET  /write-offs?invoiceId=      {writeOffs: [...], documentMode}           read
//   POST /write-offs                 {invoiceId, amountCents, accountCode?, reason?} → 201 {writeOff}   draft
//   POST /write-offs/{id}/approve    {checkedLedger?} → {writeOff, documentMode}  approve (not the drafter)
//   POST /write-offs/{id}/discard    (no body) → {writeOff}                   draft
//   POST /write-offs/small-balances  {items: [{invoiceId, amountCents}], accountCode?, limitCents?}
//                                    → {results: [{invoiceId, ok, writeOff?, error?}], documentMode}
//                                    a person clears the small balances they ticked (w47)
//
// WHY ITS OWN MODULE, as app/api/reminders/shared.js: the parts that take a fetch and a
// base URL are the parts worth testing, and they must not be reachable from a browser with
// arguments of its choosing. lib/write-offs.js supplies the key, the actor and the base on
// the server; the routes under app/api/write-offs/ check the origin.
//
// EVERY FUNCTION RETURNS, NEVER THROWS: `{ ok: true, ... }` or `{ ok: false, code, status,
// message }`. `message` is the engine's own `error.message` when it sent one. An APPROVE
// that lost its answer may have created the credit note in the ledger: it says so, never
// "nothing was sent".

import { engineFetch } from "@/lib/engine-gate";
import { refusalFrom, refused } from "@/app/api/reminders/shared";
import { documentModeOf, writeOffAccountsOf, writeOffOf, writeOffsOf } from "@/components/chat/answer/write-off";

const TIMEOUT_MS = 15000;
// A write that reaches the ledger or a mail server: lib/engine-source.js WRITE_TIMEOUT_MS,
// kept as a copy (this module doesn't import the seam; tests/no-arithmetic.test.js).
const WRITE_TIMEOUT_MS = 280000;
// Drafting re-reads the invoice from the ledger; approving writes the credit note there.
const WORK_TIMEOUT_MS = 60000;
const ID = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;
const LEDGER_ID = /^[^\x00-\x1f\x7f]{1,200}$/;
const MAX_REASON = 500;
// The engine's own bounds for a small-balance press (vert_engine/write_offs/small_balances.py).
const MAX_SMALL_ITEMS = 50;
const MAX_LIMIT_CENTS = 5000;
const ACCOUNT_CODE = /^[^\x00-\x1f\x7f]{1,32}$/;

const NOTHING_SENT = "Nothing was sent.";
const NOTHING_CHANGED = "Nothing was changed.";
export const LOST_SMALL = "Vert didn't answer, so it isn't known which credit notes reached the ledger. Check the ledger before clearing again: Vert won't clear one twice.";
export const LOST_APPROVE = "Vert didn't answer, so it isn't known whether the credit note reached the ledger. Check the ledger before approving again.";

function unreachable(message) {
  return { ok: false, kind: "unreachable", code: "unreachable", status: 0, message };
}

/* ─────────────────────────────── the bodies ─────────────────────────────── */

/** `POST /write-offs`'s body, or a refusal before anything is sent. */
export function createBody(request) {
  const r = request && typeof request === "object" ? request : {};
  if (typeof r.invoiceId !== "string" || !LEDGER_ID.test(r.invoiceId)) return refused("invalid_request", `Vert couldn't tell which invoice to write off. ${NOTHING_SENT}`);
  if (!Number.isSafeInteger(r.amountCents) || r.amountCents <= 0) return refused("invalid_request", `Enter an amount more than zero to write off. ${NOTHING_SENT}`);
  const body = { invoiceId: r.invoiceId, amountCents: r.amountCents };
  if (typeof r.accountCode === "string" && r.accountCode.trim()) body.accountCode = r.accountCode.trim();
  if (typeof r.reason === "string" && r.reason.trim()) body.reason = r.reason.trim().slice(0, MAX_REASON);
  return { ok: true, body };
}

/** `POST /write-offs/{id}/approve`'s body: only a real yes to "I've checked the ledger". */
export function approveBody(request) {
  const r = request && typeof request === "object" ? request : {};
  return { ok: true, body: r.checkedLedger === true ? { checkedLedger: true } : {} };
}

/** `POST /write-offs/small-balances`'s body, or a refusal before anything is sent. */
export function smallBalancesBody(request) {
  const r = request && typeof request === "object" ? request : {};
  const items = Array.isArray(r.items) ? r.items : [];
  if (!items.length) return refused("invalid_request", `Tick at least one small balance to clear. ${NOTHING_SENT}`);
  if (items.length > MAX_SMALL_ITEMS) return refused("invalid_request", `Clear at most ${MAX_SMALL_ITEMS} at a time. ${NOTHING_SENT}`);
  const out = [];
  for (const i of items) {
    if (!i || typeof i.invoiceId !== "string" || !LEDGER_ID.test(i.invoiceId) || !Number.isSafeInteger(i.amountCents) || i.amountCents <= 0 || i.amountCents > MAX_LIMIT_CENTS) {
      return refused("invalid_request", `Vert couldn't tell which small balance to clear. ${NOTHING_SENT}`);
    }
    out.push({ invoiceId: i.invoiceId, amountCents: i.amountCents });
  }
  const body = { items: out };
  if (typeof r.accountCode === "string" && ACCOUNT_CODE.test(r.accountCode.trim())) body.accountCode = r.accountCode.trim();
  if (Number.isSafeInteger(r.limitCents) && r.limitCents > 0 && r.limitCents <= MAX_LIMIT_CENTS) body.limitCents = r.limitCents;
  return { ok: true, body };
}

/** The engine's `{results}` for a small-balance press, each read whole, or null. */
export function smallResultsOf(raw) {
  if (!raw || typeof raw !== "object" || !Array.isArray(raw.results)) return null;
  const out = [];
  for (const r of raw.results) {
    if (!r || typeof r !== "object" || typeof r.invoiceId !== "string" || typeof r.ok !== "boolean") return null;
    const writeOff = r.writeOff ? writeOffOf(r.writeOff) : null;
    if (r.writeOff && !writeOff) return null;
    const err = r.error && typeof r.error === "object" ? r.error : null;
    out.push({ invoiceId: r.invoiceId, ok: r.ok, writeOff, message: err && typeof err.message === "string" ? err.message : null, reason: err && typeof err.reason === "string" ? err.reason : null });
  }
  return out;
}

/* ─────────────────────────────── the calls ─────────────────────────────── */

async function call(fetchImpl, url, init, timeoutMs = TIMEOUT_MS) {
  let response;
  try {
    response = await engineFetch(fetchImpl, url, { ...init, cache: "no-store", signal: AbortSignal.timeout(timeoutMs) });
  } catch (cause) {
    if (cause && typeof cause.digest === "string") throw cause; // Next's own control flow
    return { response: null };
  }
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  return { response, body };
}

const jsonHeaders = (headers) => ({ ...headers, "content-type": "application/json", accept: "application/json" });

function oneFrom(response, body, fallback, unreadWords) {
  if (response.status < 200 || response.status >= 300) {
    // A write-off already there (the engine's write_off_exists) comes back with the
    // refusal, read like any other, so the card can show it and its links.
    const refused = refusalFrom(response.status, body, fallback);
    const detail = body && typeof body === "object" && body.error && typeof body.error === "object" ? body.error.detail : null;
    const existing = detail && typeof detail === "object" ? writeOffOf(detail.writeOff) : null;
    return existing ? { ...refused, existing } : refused;
  }
  const writeOff = writeOffOf(body && typeof body === "object" ? body.writeOff : null);
  if (!writeOff) return refused("bad_response", unreadWords, response.status);
  // How the client's credit notes reach the ledger (4 Nov 2026), passed on when said.
  return { ok: true, writeOff, documentMode: documentModeOf(body) };
}

/** GET /write-offs/accounts: the chart's bad debts accounts. */
export async function getAccounts({ base, headers = {}, fetchImpl = globalThis.fetch }) {
  const { response, body } = await call(fetchImpl, `${base}/write-offs/accounts`, { method: "GET", headers: { ...headers, accept: "application/json" } });
  if (!response) return unreachable("Vert couldn't read the chart's bad debts accounts just now.");
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, "");
  const accounts = writeOffAccountsOf(body);
  if (!accounts) return refused("bad_response", "Vert's list of bad debts accounts couldn't be read.", response.status);
  return { ok: true, accounts };
}

/** GET /write-offs?invoiceId=: the write-offs Vert holds (for one invoice, when named). */
export async function getWriteOffs({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const id = request && typeof request.invoiceId === "string" && LEDGER_ID.test(request.invoiceId) ? request.invoiceId : null;
  const url = id ? `${base}/write-offs?invoiceId=${encodeURIComponent(id)}` : `${base}/write-offs`;
  const { response, body } = await call(fetchImpl, url, { method: "GET", headers: { ...headers, accept: "application/json" } });
  if (!response) return unreachable("Vert couldn't list the write-offs just now.");
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, "");
  const writeOffs = writeOffsOf(body);
  if (!writeOffs) return refused("bad_response", "Vert's list of write-offs couldn't be read.", response.status);
  return { ok: true, writeOffs, documentMode: documentModeOf(body) };
}

/** POST /write-offs: draft one. Nothing reaches the ledger until a second person approves. */
export async function postWriteOff({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const built = createBody(request);
  if (!built.ok) return built;
  const { response, body } = await call(fetchImpl, `${base}/write-offs`, { method: "POST", headers: jsonHeaders(headers), body: JSON.stringify(built.body) }, WORK_TIMEOUT_MS);
  if (!response) return unreachable(`Drafting the write-off didn't reach Vert. ${NOTHING_SENT}`);
  return oneFrom(response, body, NOTHING_SENT, `Vert's draft write-off couldn't be read. ${NOTHING_SENT}`);
}

/** POST /write-offs/{id}/approve: the second person's approval, which creates the DRAFT
 *  credit note in the ledger (or hands back the fields to enter by hand). */
export async function postApprove({ id, request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  if (typeof id !== "string" || !ID.test(id)) return refused("invalid_request", `Vert couldn't tell which write-off to approve. ${NOTHING_SENT}`);
  const built = approveBody(request);
  // Approving writes the credit note to the ledger: it waits as long as the engine allows (walk 2, N3).
  const { response, body } = await call(fetchImpl, `${base}/write-offs/${id}/approve`, { method: "POST", headers: jsonHeaders(headers), body: JSON.stringify(built.body) }, WRITE_TIMEOUT_MS);
  // A lost answer may have created the credit note: say so, never "nothing was sent".
  if (!response) return unreachable(LOST_APPROVE);
  if (response.status >= 500) return refusalFrom(response.status, body, LOST_APPROVE);
  return oneFrom(response, body, NOTHING_SENT, `Vert answered without saying what happened. ${LOST_APPROVE}`);
}

/** POST /write-offs/small-balances: a person clears the ticked small balances, one credit
 *  note each. A lost answer may have created some of them: it says so, never "nothing was sent". */
export async function postSmallBalances({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const built = smallBalancesBody(request);
  if (!built.ok) return built;
  const { response, body } = await call(fetchImpl, `${base}/write-offs/small-balances`, { method: "POST", headers: jsonHeaders(headers), body: JSON.stringify(built.body) }, WRITE_TIMEOUT_MS);
  if (!response) return unreachable(LOST_SMALL);
  if (response.status >= 500) return refusalFrom(response.status, body, LOST_SMALL);
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, NOTHING_SENT);
  const results = smallResultsOf(body);
  if (!results) return refused("bad_response", `Vert answered without saying what happened. ${LOST_SMALL}`, response.status);
  return { ok: true, results, documentMode: documentModeOf(body) };
}

/** POST /write-offs/{id}/discard: set it aside (kept, never deleted). */
export async function postDiscard({ id, base, headers = {}, fetchImpl = globalThis.fetch }) {
  if (typeof id !== "string" || !ID.test(id)) return refused("invalid_request", `Vert couldn't tell which write-off to set aside. ${NOTHING_CHANGED}`);
  const { response, body } = await call(fetchImpl, `${base}/write-offs/${id}/discard`, { method: "POST", headers: { ...headers, accept: "application/json" } });
  if (!response) return unreachable(`Setting the write-off aside didn't reach Vert. ${NOTHING_CHANGED}`);
  return oneFrom(response, body, NOTHING_CHANGED, `Vert's answer couldn't be read. ${NOTHING_CHANGED}`);
}
