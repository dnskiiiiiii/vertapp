// app/api/write-offs/small-balances — A PERSON CLEARS THE SMALL BALANCES THEY TICKED
// ==============================================================================
// w47 (audit row 19). POST {items: [{invoiceId, amountCents}], accountCode?, limitCents?}
// → {results, documentMode}, the engine's POST /write-offs/small-balances: each document
// re-read from the ledger, then one credit note each (a customer's for an invoice, a
// supplier's for a bill), a DRAFT or approved and allocated as the client's
// `documentMode` says. One refused never stops the rest. A lost answer never says nothing
// was sent. Same origin only; the key and the actor are added on the server.

import { isSameOrigin } from "@/lib/agent/same-origin";
import { clearSmallBalances } from "@/lib/write-offs";
import { crossOrigin, jsonOf, refusal, reply } from "../../reminders/respond";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const body = await jsonOf(request);
  const result = await clearSmallBalances(body && typeof body === "object" ? body : {});
  return result.ok ? reply({ results: result.results, documentMode: result.documentMode || null }, 200) : refusal(result);
}
