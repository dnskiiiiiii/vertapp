// app/api/write-offs/accounts — THE CHART'S BAD DEBTS ACCOUNTS, FOR THE WRITE-OFF FORM
// ==============================================================================
// GET → {accounts, choice: one | several | none, words}, the engine's GET
// /write-offs/accounts. A read, made when a person opens the form (never on a page view).

import { readWriteOffAccounts } from "@/lib/write-offs";
import { refusal, reply } from "../../reminders/respond";

export const dynamic = "force-dynamic";

export async function GET() {
  const result = await readWriteOffAccounts();
  return result.ok ? reply(result.accounts, 200) : refusal(result);
}
