// app/api/write-offs/[id]/approve — A SECOND PERSON APPROVES A WRITE-OFF
// ==============================================================================
// POST {checkedLedger?} → {writeOff, documentMode}, the engine's POST
// /write-offs/{id}/approve: the engine creates the credit note in the ledger as a DRAFT,
// or approved and allocated to the invoice when the client's `documentMode` is
// "authorised" (or hands back the fields to enter by hand). The drafter can't approve their own (403 in the engine's words). A lost
// answer never says nothing was sent. Same origin only.

import { isSameOrigin } from "@/lib/agent/same-origin";
import { approveWriteOff } from "@/lib/write-offs";
import { crossOrigin, jsonOf, refusal, reply } from "../../../reminders/respond";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(request, { params }) {
  if (!isSameOrigin(request)) return crossOrigin();
  const { id } = await params;
  const body = await jsonOf(request);
  const result = await approveWriteOff(typeof id === "string" ? id : "", body && typeof body === "object" ? body : {});
  return result.ok ? reply({ writeOff: result.writeOff, documentMode: result.documentMode || null }, 200) : refusal(result);
}
