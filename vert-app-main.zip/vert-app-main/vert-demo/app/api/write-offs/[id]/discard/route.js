// app/api/write-offs/[id]/discard — SET A DRAFTED WRITE-OFF ASIDE (kept, never deleted).

import { isSameOrigin } from "@/lib/agent/same-origin";
import { discardWriteOff } from "@/lib/write-offs";
import { crossOrigin, refusal, reply } from "../../../reminders/respond";

export const dynamic = "force-dynamic";

export async function POST(request, { params }) {
  if (!isSameOrigin(request)) return crossOrigin();
  const { id } = await params;
  const result = await discardWriteOff(typeof id === "string" ? id : "");
  return result.ok ? reply({ writeOff: result.writeOff }, 200) : refusal(result);
}
