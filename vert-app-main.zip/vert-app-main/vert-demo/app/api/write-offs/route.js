// app/api/write-offs — LIST THE WRITE-OFFS (GET ?invoiceId=), OR DRAFT ONE (POST)
// ==============================================================================
// W4 (29 Oct 2026). POST {invoiceId, amountCents, accountCode?, reason?} → 201 {writeOff},
// the engine's POST /write-offs: a DRAFT write-off kept in Vert. Nothing reaches the ledger
// until a second person approves it (./[id]/approve). Same origin only; the key and the
// actor are added on the server (lib/write-offs.js).

import { isSameOrigin } from "@/lib/agent/same-origin";
import { draftWriteOff, readWriteOffs } from "@/lib/write-offs";
import { crossOrigin, jsonOf, refusal, reply } from "../reminders/respond";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET(request) {
  const invoiceId = new URL(request.url).searchParams.get("invoiceId");
  const result = await readWriteOffs({ invoiceId: invoiceId || undefined });
  return result.ok ? reply({ writeOffs: result.writeOffs, documentMode: result.documentMode || null }, 200) : refusal(result);
}

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const body = await jsonOf(request);
  const result = await draftWriteOff(body && typeof body === "object" ? body : {});
  if (result.ok) return reply({ writeOff: result.writeOff, documentMode: result.documentMode || null }, 201);
  if (!result.existing) return refusal(result);
  // The write-off already there rides on the refusal (review, 29 Oct 2026).
  return reply({ error: { code: result.code || "state_conflict", message: result.message, existing: result.existing } }, result.status || 409);
}
