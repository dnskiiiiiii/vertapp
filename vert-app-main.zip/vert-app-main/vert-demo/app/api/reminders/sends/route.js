// app/api/reminders/sends — WHAT PAYMENT REMINDERS WERE SENT
// ==============================================================================
// GET → {sends: [...]}, the engine's GET /reminders/sends?limit=50 (contract v2: each row's
// status is sent | unknown | failed | sending | cancelled, and whether the recipient or
// the message was changed). A read: the key is added on the server (lib/reminders.js);
// components/chat/answer/SentReminders.js reads the rows.

import { readSentReminders } from "@/lib/reminders";
import { refusal, reply } from "../respond";

export const dynamic = "force-dynamic";

export async function GET() {
  const result = await readSentReminders(50);
  return result.ok ? reply({ sends: result.sends }, 200) : refusal(result);
}
