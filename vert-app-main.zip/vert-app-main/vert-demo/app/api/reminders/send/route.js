// app/api/reminders/send — SEND THE REMINDERS A PERSON APPROVED
// ==============================================================================
// POST {asAt?, emails: [{draftId?, contactId, invoiceIds, to, subject, body,
// confirmResend?}]} → {results: [{contactId, status, to, messageId, words, ...}]}, from
// the engine's POST /reminders/send (role: approve). Only a press reaches this: the
// drafts screen sends nothing on its own. Same origin only; the key and the actor are
// added on the server (lib/reminders.js). A send is never retried (lib/engine-gate.js).

import { isSameOrigin } from "@/lib/agent/same-origin";
import { sendReminders } from "@/lib/reminders";
import { crossOrigin, jsonOf, refusal, reply } from "../respond";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const body = await jsonOf(request);
  const b = body && typeof body === "object" ? body : {};
  const result = await sendReminders({ asAt: b.asAt, emails: b.emails });
  return result.ok ? reply({ results: result.results }, 200) : refusal(result);
}
