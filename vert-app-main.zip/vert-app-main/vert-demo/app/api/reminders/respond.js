// app/api/reminders/respond.js — ONE ANSWER SHAPE FOR EVERY REMINDER ROUTE
// ==============================================================================
// A described outcome from lib/reminders.js becomes a response: the data with 200, or
// `{error: {code, message, connect?}}` with the engine's status (the browser's
// lib/reminders-client.js reads exactly this). Nothing here reads or logs a request.

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

export function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

/** A refusal from lib/reminders.js, as the route answers it. */
export function refusal(result) {
  const r = result || {};
  const status = r.kind === "unavailable" ? 503 : r.kind === "unreachable" ? 502 : Number.isInteger(r.status) && r.status >= 400 ? r.status : 502;
  const error = { code: r.code || "unreachable", message: r.message || "Vert couldn't do that just now." };
  if (r.connect) error.connect = true;
  return reply({ error }, status);
}

/** Cross-origin (lib/agent/same-origin.js, checked by each route): refused before the
 * body is read, and the engine never asked. */
export function crossOrigin() {
  return reply({ error: { code: "cross_origin", message: "Nothing was sent or changed." }, code: "cross_origin" }, 403);
}

/** The request's JSON body, or null when it has none or it doesn't parse. */
export async function jsonOf(request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}
