// app/api/reminders/email/test — SEND A TEST EMAIL TO MYSELF
// ==============================================================================
// POST (no body) → {test: {status: "sent"|"failed", to, messageId, words}}, from the
// engine's POST /reminders/email/test. It only ever goes to the connected sender's own
// address (contract v2), so this route reads nothing from the request but its origin.
// Rate limited by the engine; a 429 comes back with its words. Same origin only; the key
// and the actor are added on the server (lib/reminders.js).

import { isSameOrigin } from "@/lib/agent/same-origin";
import { sendTestEmail } from "@/lib/reminders";
import { crossOrigin, refusal, reply } from "../../respond";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const result = await sendTestEmail();
  return result.ok ? reply({ test: result.test }, 200) : refusal(result);
}
