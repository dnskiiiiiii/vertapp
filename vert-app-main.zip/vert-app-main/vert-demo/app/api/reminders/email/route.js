// app/api/reminders/email — HOW THIS CLIENT'S PAYMENT REMINDERS ARE SENT
// ==============================================================================
// GET    → the engine's EmailSettings (never a password)       GET    /reminders/email
// PUT    {backend, address, appPassword?} → EmailSettings      PUT    /reminders/email
// DELETE → EmailSettings, connected=false                      DELETE /reminders/email
//
// The key and the actor are added on the server (lib/reminders.js). PUT carries the
// client's Gmail app password to the engine: it is read from the body once, handed on,
// and is in no response and no log. Same origin only, as every mutating route.

import { isSameOrigin } from "@/lib/agent/same-origin";
import { disconnectEmail, readEmailSettings, saveEmailSettings } from "@/lib/reminders";
import { crossOrigin, jsonOf, refusal, reply } from "../respond";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET() {
  const result = await readEmailSettings();
  return result.ok ? reply({ settings: result.settings }, 200) : refusal(result);
}

export async function PUT(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const body = await jsonOf(request);
  const b = body && typeof body === "object" ? body : {};
  const result = await saveEmailSettings({ backend: b.backend, address: b.address, appPassword: b.appPassword });
  return result.ok ? reply({ settings: result.settings }, 200) : refusal(result);
}

export async function DELETE(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const result = await disconnectEmail();
  return result.ok ? reply({ settings: result.settings }, 200) : refusal(result);
}
