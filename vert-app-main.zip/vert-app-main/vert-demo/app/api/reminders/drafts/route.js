// app/api/reminders/drafts — DRAFT ONE PAYMENT REMINDER PER OVERDUE CUSTOMER
// ==============================================================================
// POST {asAt?} → {reminders}, the engine's POST /reminders/drafts answer as it came
// (the `shape.reminders` object; components/chat/answer/reminders.js reads it). Drafting
// sends nothing. Same origin only; the key and the actor are added on the server.

import { isSameOrigin } from "@/lib/agent/same-origin";
import { draftReminders } from "@/lib/reminders";
import { crossOrigin, jsonOf, refusal, reply } from "../respond";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const body = await jsonOf(request);
  const result = await draftReminders({ asAt: body && typeof body === "object" ? body.asAt : undefined });
  return result.ok ? reply({ reminders: result.reminders }, 200) : refusal(result);
}
