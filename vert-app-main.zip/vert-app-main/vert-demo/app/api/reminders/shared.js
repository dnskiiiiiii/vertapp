// app/api/reminders/shared.js — THE WIRE FOR PAYMENT REMINDERS, AND ITS RULES
// ==============================================================================
// W3 feature 1 (28 Oct 2026), on the engine's routes (vert_api/routers/reminders.py):
//
//   GET    /reminders/email        EmailSettings                          read
//   PUT    /reminders/email        {backend, address, appPassword?}       manage_connections
//   DELETE /reminders/email        EmailSettings (connected=false)        manage_connections
//   POST   /reminders/email/test   (no body) → {status, to, messageId, words} manage_connections
//   POST   /reminders/drafts       {asAt?} → the `shape.reminders` object read
//   POST   /reminders/send         {asAt?, emails: [...]} → {results}     approve
//   GET    /reminders/sends?limit  {sends: [...]}                          read
//
// CONTRACT v2 (28 Oct 2026): an email is `{draftId?, contactId, invoiceIds, to, subject,
// intro, closing, confirmResend?, confirmRecipient?}`, never a body (the engine writes
// the invoice block at send time); at most 50 per request; the test email takes no
// address (it only goes to the connected sender) and is rate limited (429 with words).
//
// WHY ITS OWN MODULE, as app/api/budgets/shared.js: the parts that take a fetch and a
// base URL are the parts worth testing, and they must not be reachable from a browser
// with arguments of its choosing. lib/reminders.js supplies the key, the actor and the
// base on the server; the routes under app/api/reminders/ check the origin.
//
// THE APP PASSWORD travels in exactly one body (PUT /reminders/email), to the engine.
// It is in no message, no refusal and no log here, and nothing the engine answers is
// passed back with one in it (lib/reminder-email.js copies the settings field by field).
//
// EVERY FUNCTION RETURNS, NEVER THROWS: `{ ok: true, ... }` or `{ ok: false, code,
// status, message, connect? }`. `message` is the engine's own `error.message` when it
// sent one (the contract: it is shown to the person), else a sentence of ours that says
// what did not happen. `connect: true` on a 409 not_configured / not_connected: email
// isn't connected, and the screen links to /connections.

import { engineFetch } from "@/lib/engine-gate";
import { emailSettingsOf, looksLikeEmail } from "@/lib/reminder-email";

const TIMEOUT_MS = 15000;
// A write that reaches the ledger or a mail server: lib/engine-source.js WRITE_TIMEOUT_MS,
// kept as a copy (this module doesn't import the seam; tests/no-arithmetic.test.js).
const WRITE_TIMEOUT_MS = 280000;
// Drafting reads the ledger's overdue invoices; sending talks to a mail server per
// customer. Both are given longer than a settings read, and both are still bounded.
const WORK_TIMEOUT_MS = 60000;
// One shared cap with the engine and the drafts screen (reminders.js MAX_EMAILS_PER_SEND).
const MAX_EMAILS = 50;
const MAX_INVOICES = 1000;
const SENT_LIST = "Check Sent reminders before sending again.";
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;
const ID = /^[^\x00-\x1f\x7f]{1,200}$/;

const NOTHING_SENT = "Nothing was sent.";
export const LOST_SEND = `Vert didn't answer, so it isn't known whether the reminders went. ${SENT_LIST}`;
const NOTHING_CHANGED = "Nothing was changed.";

export function refused(code, message, status = 0, extra = {}) {
  return { ok: false, kind: "refused", code, status, message, ...extra };
}

function unreachable(message) {
  return { ok: false, kind: "unreachable", code: "unreachable", status: 0, message };
}

const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

/** The engine's refusal, read: its code, its words, and whether to point at /connections. */
export function refusalFrom(status, body, fallback) {
  const envelope = body && typeof body === "object" ? body.error : null;
  const code = envelope && typeof envelope.code === "string" && /^[a-z][a-z0-9_]*$/.test(envelope.code) ? envelope.code : `http_${status}`;
  const said = envelope ? text(envelope.message) : null;
  let message = said;
  if (!message) {
    if (status === 401) message = `Sign in again. ${fallback}`;
    else if (status === 403) message = `Your role can't do that for this client. ${fallback}`;
    else message = `Vert couldn't do that just now (${code}). ${fallback}`;
  }
  const connect = status === 409 && (code === "not_configured" || code === "not_connected");
  return refused(code, message, status, connect ? { connect: true } : {});
}

/* ─────────────────────────────── the bodies ─────────────────────────────── */

/** `PUT /reminders/email`'s body, or a refusal before anything is sent. */
export function emailBody(request) {
  const r = request && typeof request === "object" ? request : {};
  if (r.backend !== "resend" && r.backend !== "smtp") return refused("invalid_request", `Choose how reminders are sent. ${NOTHING_CHANGED}`);
  if (!looksLikeEmail(r.address)) return refused("invalid_request", `Enter the client's email address, like accounts@example.com. ${NOTHING_CHANGED}`);
  const body = { backend: r.backend, address: r.address.trim() };
  if (r.backend === "smtp") {
    if (typeof r.appPassword !== "string" || !r.appPassword.trim()) {
      return refused("invalid_request", `Enter the Gmail app password for this address. ${NOTHING_CHANGED}`);
    }
    body.appPassword = r.appPassword;
  }
  return { ok: true, body };
}

/** `POST /reminders/drafts`'s body. */
export function draftsBody(request) {
  const r = request && typeof request === "object" ? request : {};
  if (r.asAt === undefined || r.asAt === null) return { ok: true, body: {} };
  if (typeof r.asAt !== "string" || !ISO_DAY.test(r.asAt)) return refused("invalid_request", "Vert couldn't tell which date to draft reminders as at.");
  return { ok: true, body: { asAt: r.asAt } };
}

function emailItem(e) {
  if (!e || typeof e !== "object") return null;
  if (typeof e.contactId !== "string" || !ID.test(e.contactId)) return null;
  if (!Array.isArray(e.invoiceIds) || !e.invoiceIds.length || e.invoiceIds.length > MAX_INVOICES || e.invoiceIds.some((i) => typeof i !== "string" || !ID.test(i))) return null;
  if (!looksLikeEmail(e.to)) return null;
  if (typeof e.subject !== "string" || !e.subject.trim()) return null;
  // The person's two parts of the email. A `body` is never read: the invoice block is the
  // engine's, written at send time, and an edited one would be an amount Vert didn't read.
  if (typeof e.intro !== "string" || typeof e.closing !== "string") return null;
  // The contract's key order, so a body reads the same however it was built.
  const out = {};
  if (typeof e.draftId === "string" && ID.test(e.draftId)) out.draftId = e.draftId;
  Object.assign(out, { contactId: e.contactId, invoiceIds: [...e.invoiceIds], to: e.to.trim(), subject: e.subject, intro: e.intro, closing: e.closing });
  if (e.confirmResend === true) out.confirmResend = true;
  if (e.confirmRecipient === true) out.confirmRecipient = true;
  return out;
}

/** `POST /reminders/send`'s body, or a refusal before anything is sent. */
export function sendBody(request) {
  const r = request && typeof request === "object" ? request : {};
  if (!Array.isArray(r.emails) || !r.emails.length) return refused("invalid_request", `Pick at least one reminder to send. ${NOTHING_SENT}`);
  if (r.emails.length > MAX_EMAILS) return refused("invalid_request", `Send at most ${MAX_EMAILS} reminders at once. ${NOTHING_SENT}`);
  const emails = r.emails.map(emailItem);
  if (emails.some((e) => !e)) return refused("invalid_request", `Each reminder needs an address, a subject, its opening and closing words, and its invoices. ${NOTHING_SENT}`);
  const body = {};
  if (typeof r.asAt === "string" && ISO_DAY.test(r.asAt)) body.asAt = r.asAt;
  body.emails = emails;
  return { ok: true, body };
}

/* ─────────────────────────────── the calls ─────────────────────────────── */

async function call(fetchImpl, url, init, timeoutMs = TIMEOUT_MS) {
  let response;
  try {
    response = await engineFetch(fetchImpl, url, { ...init, cache: "no-store", signal: AbortSignal.timeout(timeoutMs) });
  } catch (cause) {
    if (cause && typeof cause.digest === "string") throw cause; // Next's own control flow
    return { response: null };
  }
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  return { response, body };
}

const jsonHeaders = (headers) => ({ ...headers, "content-type": "application/json", accept: "application/json" });

function settingsFrom(response, body, fallback) {
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, fallback);
  const settings = emailSettingsOf(body);
  if (!settings) return refused("bad_response", `Vert's answer about email couldn't be read. ${fallback}`, response.status);
  return { ok: true, settings };
}

/** GET /reminders/email. */
export async function getEmailSettings({ base, headers = {}, fetchImpl = globalThis.fetch }) {
  const { response, body } = await call(fetchImpl, `${base}/reminders/email`, { method: "GET", headers: { ...headers, accept: "application/json" } });
  if (!response) return unreachable("Vert couldn't check how reminders are sent just now.");
  return settingsFrom(response, body, "");
}

/** PUT /reminders/email. The one body that carries an app password. */
export async function putEmailSettings({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const built = emailBody(request);
  if (!built.ok) return built;
  const { response, body } = await call(fetchImpl, `${base}/reminders/email`, { method: "PUT", headers: jsonHeaders(headers), body: JSON.stringify(built.body) }, WORK_TIMEOUT_MS);
  if (!response) return unreachable(`Saving the email settings didn't reach Vert. ${NOTHING_CHANGED}`);
  return settingsFrom(response, body, NOTHING_CHANGED);
}

/** DELETE /reminders/email. */
export async function deleteEmailSettings({ base, headers = {}, fetchImpl = globalThis.fetch }) {
  const { response, body } = await call(fetchImpl, `${base}/reminders/email`, { method: "DELETE", headers: { ...headers, accept: "application/json" } });
  if (!response) return unreachable(`Disconnecting didn't reach Vert. ${NOTHING_CHANGED}`);
  return settingsFrom(response, body, NOTHING_CHANGED);
}

/** POST /reminders/email/test, with no body: it only ever goes to the connected address. */
export async function postEmailTest({ base, headers = {}, fetchImpl = globalThis.fetch }) {
  const { response, body } = await call(fetchImpl, `${base}/reminders/email/test`, { method: "POST", headers: { ...headers, accept: "application/json" } }, WORK_TIMEOUT_MS);
  if (!response) return unreachable(`The test email didn't reach Vert. ${NOTHING_SENT}`);
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, NOTHING_SENT);
  const b = body && typeof body === "object" ? body : {};
  // "unknown": the mail server took it and didn't confirm. It MAY have been sent.
  if (b.status !== "sent" && b.status !== "failed" && b.status !== "unknown") return refused("bad_response", `Vert didn't say whether the test email went.`, response.status);
  if (b.status === "unknown") return { ok: true, test: { status: "unknown", to: text(b.to), messageId: null, words: text(b.words) || "The test email may have been sent: the mail server didn't confirm it." } };
  return { ok: true, test: { status: b.status, to: text(b.to), messageId: text(b.messageId), words: text(b.words) } };
}

/** POST /reminders/drafts. The drafts come back as the engine sent them; the screen reads them. */
export async function postDrafts({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const built = draftsBody(request);
  if (!built.ok) return built;
  const { response, body } = await call(fetchImpl, `${base}/reminders/drafts`, { method: "POST", headers: jsonHeaders(headers), body: JSON.stringify(built.body) }, WORK_TIMEOUT_MS);
  if (!response) return unreachable(`Drafting the reminders didn't reach Vert. ${NOTHING_SENT}`);
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, NOTHING_SENT);
  if (!body || typeof body !== "object" || typeof body.measured !== "boolean") return refused("bad_response", `Vert's drafts couldn't be read. ${NOTHING_SENT}`, response.status);
  return { ok: true, reminders: body };
}

/** POST /reminders/send. Each result says what happened to one customer's email. */
export async function postSend({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const built = sendBody(request);
  if (!built.ok) return built;
  // A send talks to a mail server per customer: it waits as long as the engine allows
  // (walk 2, N3), so its answer, not a timeout, is what is shown.
  const { response, body } = await call(fetchImpl, `${base}/reminders/send`, { method: "POST", headers: jsonHeaders(headers), body: JSON.stringify(built.body) }, WRITE_TIMEOUT_MS);
  // A send that lost its answer may have gone: say so, never "nothing was sent".
  if (!response) return unreachable(LOST_SEND);
  // So may one the engine failed part way through: some emails can have gone.
  if (response.status >= 500) return refusalFrom(response.status, body, LOST_SEND);
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, NOTHING_SENT);
  if (!body || !Array.isArray(body.results)) return refused("bad_response", `Vert answered without saying which reminders went. ${SENT_LIST}`, response.status);
  return { ok: true, results: body.results };
}

/** GET /reminders/sends?limit=N (1–200, 50 by default): what was sent, as the engine keeps it. */
export async function getSends({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const asked = request && Number.isInteger(request.limit) ? request.limit : 50;
  const limit = Math.min(Math.max(asked, 1), 200);
  const { response, body } = await call(fetchImpl, `${base}/reminders/sends?limit=${limit}`, { method: "GET", headers: { ...headers, accept: "application/json" } });
  if (!response) return unreachable("Vert couldn't list the sent reminders just now.");
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, "");
  if (!body || !Array.isArray(body.sends)) return refused("bad_response", "Vert's list of sent reminders couldn't be read.", response.status);
  return { ok: true, sends: body.sends };
}
