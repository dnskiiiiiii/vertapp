// app/api/documents/shared.js — what every documents route answers a refusal with.
//
// The one way a document's bytes leave the app: the engine's type and disposition, or
// a JSON refusal with its status. Never a 200 with an empty body.

export function bytesResponse(result) {
  if (!result || !result.ok) {
    const status = result && Number.isInteger(result.status) && result.status >= 400 ? result.status : 502;
    return new Response(JSON.stringify({ ok: false, code: (result && result.code) || "unreachable" }), {
      status,
      headers: { "content-type": "application/json", "cache-control": "no-store" },
    });
  }
  return new Response(result.bytes, {
    status: 200,
    headers: { "content-type": result.contentType, "content-disposition": result.disposition, "cache-control": "private, no-store" },
  });
}

/** The HTTP status a lib/documents.js refusal answers with. */
export function statusOf(result) {
  if (result.kind === "unavailable") return 503;
  if (result.kind === "unreachable") return 502;
  if (result.code === "documents_disabled") return 409;
  return Number.isInteger(result.status) && result.status >= 400 ? result.status : 400;
}
