// app/api/documents — FILES IN CHAT, THROUGH THE APP
// ==============================================================================
// Build plan §19.8 F-FILES. The browser's door to the engine's `/documents` routes,
// with the key added on the server (lib/documents.js), as the conversation routes
// beside it do:
//
//   GET  /api/documents?session=   → the files Vert holds (the context sheet's Files)
//   POST /api/documents            → attach one file (multipart `file`, `session`)
//
// THE UPLOAD IS A ROUTE, NOT A SERVER ACTION, because a Server Action's body is capped
// at 1 MB by default and a scanned invoice is not. The engine's own 25 MB limit is the
// one that applies. When the engine doesn't read files the POST is refused with a
// code and nothing is sent (lib/documents.js `uploadDocument`); the composer never
// draws the control in that case, so the refusal is the second wall, not the first.
//
// A refusal answers with its status and a code, never an empty list: "no files" is a
// claim, and an unread list is not one.

import { listDocuments, uploadDocument } from "@/lib/documents";
import { isSameOrigin } from "@/lib/agent/same-origin";
import { statusOf } from "./shared";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function refusal(result) {
  return new Response(JSON.stringify({ ok: false, kind: result.kind, code: result.code, message: result.message || null }), { status: statusOf(result), headers: HEADERS });
}

export async function GET(request) {
  const session = new URL(request.url).searchParams.get("session") || null;
  const result = await listDocuments({ session });
  if (!result.ok) return refusal(result);
  return new Response(JSON.stringify({ ok: true, items: result.items, total: result.total }), { status: 200, headers: HEADERS });
}

export async function POST(request) {
  // The upload acts as the signed-in person (her cookie rides along), so a page on
  // another site must not be able to make it (S-SE-17): the same guard the
  // conversation route uses, checked before the body is even read.
  if (!isSameOrigin(request)) {
    return refusal({ kind: "refused", status: 403, code: "cross_origin", message: "Nothing was stored." });
  }
  let form;
  try {
    form = await request.formData();
  } catch {
    // A body that arrived but could not be read as a form is not "no file": it was cut
    // short on the way (D37), and saying "Choose a file" sent the person looking for a
    // mistake they hadn't made.
    const length = Number(request.headers.get("content-length") || 0);
    if (length > 0) {
      return refusal({ kind: "refused", code: "unreadable_upload", message: "That file didn't arrive in full, so it wasn't sent. Nothing was stored. Try again, or attach a file under 25 MB." });
    }
    return refusal({ kind: "refused", code: "no_file", message: "Choose a file to attach." });
  }
  const result = await uploadDocument(form);
  if (!result.ok) return refusal(result);
  return new Response(JSON.stringify({ ok: true, document: result.document, intake: result.intake }), { status: 201, headers: HEADERS });
}
