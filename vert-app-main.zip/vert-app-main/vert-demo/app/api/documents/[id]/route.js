// app/api/documents/[id] — ONE FILE, WHOLE, FOR THE PANE (components/chat/results/DocumentView.js)
// ==============================================================================
// Its pages and their text, or a workbook's sheets, as the engine read them, with the
// key added on the server. A refusal is a status and a code, never a blank document.

import { getDocument } from "@/lib/documents";
import { statusOf } from "../shared";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

export async function GET(_request, { params }) {
  const { id } = await params;
  const result = await getDocument(typeof id === "string" ? id : "");
  if (!result.ok) {
    return new Response(JSON.stringify({ ok: false, kind: result.kind, code: result.code, message: result.message || null }), { status: statusOf(result), headers: HEADERS });
  }
  return new Response(JSON.stringify({ ok: true, document: result.document }), { status: 200, headers: HEADERS });
}
