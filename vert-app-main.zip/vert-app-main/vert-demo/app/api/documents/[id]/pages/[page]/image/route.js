// app/api/documents/[id]/pages/[page]/image — ONE PAGE, AS AN IMAGE, for the pane's
// page view. Through the app, key on the server; a refusal is a status and a code.

import { documentBytes } from "@/lib/documents";
import { bytesResponse } from "../../../../shared";

export const dynamic = "force-dynamic";

export async function GET(_request, { params }) {
  const { id, page } = await params;
  const n = /^[1-9][0-9]{0,4}$/.test(String(page ?? "")) ? Number(page) : -1;
  return bytesResponse(await documentBytes(typeof id === "string" ? id : "", { page: n }));
}
