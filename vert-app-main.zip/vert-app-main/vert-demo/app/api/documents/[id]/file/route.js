// app/api/documents/[id]/file — THE FILE AS STORED (or `?variant=uploaded`, the photo
// before it became a PDF page), streamed through the app with the key added on the
// server. A refusal is a status and a code, never an empty file.

import { documentBytes } from "@/lib/documents";
import { bytesResponse } from "../../shared";

export const dynamic = "force-dynamic";

export async function GET(request, { params }) {
  const { id } = await params;
  const variant = new URL(request.url).searchParams.get("variant") === "uploaded" ? "uploaded" : "stored";
  return bytesResponse(await documentBytes(typeof id === "string" ? id : "", { variant }));
}
