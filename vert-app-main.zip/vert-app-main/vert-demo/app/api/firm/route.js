// app/api/firm — THE FIRM'S CLIENTS AND SKILLS, READ FROM THE BROWSER
// ==============================================================================
// Build plan §19.9 F-FIRM. `GET /api/firm?period=2026-09` → the switcher's client list
// (lib/firm.js `listClients`); `GET /api/firm?view=detail&period=2026-09` → Clients'
// prepare/review detail (`readClientsDetail`); `GET /api/firm?view=skills` → the firm's skills with each
// client fork (lib/firm.js `listFirmSkills`), for the skill sheet's indented rows.
//
// WHY A ROUTE FOR THE READS. The switcher and the skill sheet open over a page that may
// be streaming a conversation; a Server Action answers with a fresh render of the page
// (the sliding cookie revalidates it), which would hold that stream. The writes — the
// switch and the fork — stay Server Actions in lib/firm.js, which prove each one with
// the engine before saying it happened.
//
// THE KEY STAYS ON THE SERVER: lib/firm.js reads it from the sealed session. A refusal
// answers with a code and no sentence; the caller words it.

import { listClients, listFirmSkills, readClientsDetail } from "@/lib/firm";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

function failed(result) {
  const status = result.kind === "unavailable" ? 503 : result.kind === "unreachable" ? 502 : result.status || (result.code === "forbidden" ? 403 : 400);
  return reply({ ok: false, kind: result.kind, code: result.code }, status);
}

export async function GET(request) {
  const params = new URL(request.url).searchParams;
  if (params.get("view") === "skills") {
    const result = await listFirmSkills();
    return result.ok ? reply({ ok: true, skills: result.skills }, 200) : failed(result);
  }
  // `?view=detail`: Clients' prepare/review detail after its rows (app/clients/detail-read.js),
  // a Server Action called from an effect until 28 Oct 2026 (tests/p0-quiet-page-load.test.js).
  if (params.get("view") === "detail") {
    const result = await readClientsDetail(params.get("period") || "");
    return result && result.ok ? reply(result, 200) : failed(result || { kind: "unreachable", code: "unreachable" });
  }
  // `?view=switcher`: the switcher and cmd-K, which need names and status words only
  // (lib/firm.js listClients detail; verify pass 1 S-E2E-3).
  const result = await listClients(params.get("period") || "", { detail: params.get("view") !== "switcher" });
  return result.ok ? reply(result, 200) : failed(result);
}
