// app/api/firm/people — THE FIRM'S PEOPLE AND ROLES, READ FROM THE BROWSER (§20.12 H3)
// ==============================================================================
// Owner: F-SEC. `GET /api/firm/people` → lib/people.js `listPeople`. A route for the
// read for the reason app/api/firm gives: the people sheet opens from the account
// menu over a page that may be streaming a conversation, and a Server Action answers
// with a fresh render of the page. The role change stays a Server Action
// (lib/people.js setRole), which reads the change back before saying it happened.
// The key stays on the server; a refusal answers with a code and the sheet words it.

import { listPeople } from "@/lib/people";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

export async function GET() {
  const result = await listPeople();
  if (result.ok) return new Response(JSON.stringify(result), { status: 200, headers: HEADERS });
  const status = result.kind === "not_built" ? 404 : result.kind === "unavailable" ? 503 : result.kind === "unreachable" ? 502 : result.code === "forbidden" ? 403 : 400;
  return new Response(JSON.stringify({ ok: false, kind: result.kind, code: result.code }), { status, headers: HEADERS });
}
