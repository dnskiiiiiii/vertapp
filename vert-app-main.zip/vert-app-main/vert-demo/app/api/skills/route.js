// app/api/skills — A TASK'S SKILL, READ FROM THE BROWSER
// ==============================================================================
// Build plan §19.6 F-BRAIN. `GET /api/skills?template=prepaid_schedule` → the skill as
// the sheet draws it (lib/skills.js `getSkill`), with what Vert knows about this
// client. `GET /api/skills?template=_tenant` → `{ ok, paused }` for the account menu.
//
// WHY A ROUTE FOR THE READ. The sheet opens over a conversation that is still
// streaming; a Server Action called from it comes back with a fresh render of the page
// (proxy.js slides the session cookie, and a changed cookie revalidates), which held
// the conversation for two seconds in eval C4. The read returns the skill and nothing
// else. The writes (Save, Forget, Pause Vert) stay Server Actions in lib/skills.js and
// lib/memory.js, which read every write back before reporting it.
//
// THE KEY STAYS ON THE SERVER: lib/skills.js reads it from the sealed session. A
// refusal answers with a code and no sentence; the sheet words it.

import { getSkill, readPause } from "@/lib/skills";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

function failed(result) {
  const status = result.kind === "unavailable" ? 503 : result.kind === "unreachable" ? 502 : result.status || 400;
  return reply({ ok: false, kind: result.kind, code: result.code }, status);
}

export async function GET(request) {
  const template = new URL(request.url).searchParams.get("template") || "";
  if (template === "_tenant") {
    const result = await readPause();
    return result.ok ? reply({ ok: true, paused: result.paused }, 200) : failed(result);
  }
  const result = await getSkill(template);
  return result.ok ? reply({ ok: true, skill: result.skill }, 200) : failed(result);
}
