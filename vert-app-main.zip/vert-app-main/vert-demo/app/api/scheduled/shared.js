// app/api/scheduled/shared.js — WHAT EVERY SCHEDULED ROUTE ANSWERS WITH
//
// The bills routes' rules (app/api/bills/shared.js): a refusal is its status and
// `{ ok: false, kind, code, message }`, never a 200 with an empty list, and every route
// that changes something checks the request's origin before its body is read.

import { answer, jsonOf, refusal } from "../bills/shared";

export { answer, jsonOf, refusal };

export function crossOrigin() {
  return refusal({ kind: "refused", status: 403, code: "cross_origin", message: "Not changed" });
}
