// app/api/scheduled — THE SCHEDULED LIST, AND MAKING A TASK
// ==============================================================================
//   GET  /api/scheduled   → the list (lib/scheduled.js listScheduled)
//   POST /api/scheduled   → `{ kind, name?, cadence, config? }` → the task
//
// The key is added on the server (lib/session.js); the browser never sees it.

import { isSameOrigin } from "@/lib/agent/same-origin";
import { createScheduled, listScheduled } from "@/lib/scheduled";

import { answer, crossOrigin, jsonOf, refusal } from "./shared";

export const dynamic = "force-dynamic";

export async function GET() {
  const result = await listScheduled();
  if (!result.ok) return refusal(result);
  return answer({ ok: true, tasks: result.tasks, waitingTotal: result.waitingTotal, timezone: result.timezone, unreadable: result.unreadable });
}

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const body = await jsonOf(request);
  const result = await createScheduled(body || {});
  if (!result.ok) return refusal(result);
  return answer({ ok: true, task: result.task, drafted: result.drafted || [] }, 201);
}
