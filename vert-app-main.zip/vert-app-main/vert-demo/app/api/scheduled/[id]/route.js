// app/api/scheduled/[id] — ONE TASK: READ IT WITH ITS DETAIL (GET), CHANGE IT (PATCH)

import { isSameOrigin } from "@/lib/agent/same-origin";
import { getScheduled, patchScheduled } from "@/lib/scheduled";

import { answer, crossOrigin, jsonOf, refusal } from "../shared";

export const dynamic = "force-dynamic";

export async function GET(_request, { params }) {
  const { id } = await params;
  const result = await getScheduled(typeof id === "string" ? id : "");
  if (!result.ok) return refusal(result);
  return answer({ ok: true, task: result.task, detail: result.detail, timezone: result.timezone });
}

export async function PATCH(request, { params }) {
  if (!isSameOrigin(request)) return crossOrigin();
  const { id } = await params;
  const body = await jsonOf(request);
  const result = await patchScheduled(typeof id === "string" ? id : "", body || {});
  if (!result.ok) return refusal(result);
  return answer({ ok: true, task: result.task });
}
