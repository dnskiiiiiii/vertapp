// app/api/scheduled/[id]/end — END A TASK (a journal ends its recurring journal)

import { isSameOrigin } from "@/lib/agent/same-origin";
import { endScheduled } from "@/lib/scheduled";

import { answer, crossOrigin, refusal } from "../../shared";

export const dynamic = "force-dynamic";

export async function POST(request, { params }) {
  if (!isSameOrigin(request)) return crossOrigin();
  const { id } = await params;
  const result = await endScheduled(typeof id === "string" ? id : "");
  if (!result.ok) return refusal(result);
  return answer({ ok: true, task: result.task });
}
