// app/api/scheduled/[id]/run — RUN A TASK NOW, AS A DUE RUN WOULD (drafts only)

import { isSameOrigin } from "@/lib/agent/same-origin";
import { runScheduled } from "@/lib/scheduled";
import { runOf } from "@/lib/scheduled-model";

import { answer, crossOrigin, refusal } from "../../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(request, { params }) {
  if (!isSameOrigin(request)) return crossOrigin();
  const { id } = await params;
  const result = await runScheduled(typeof id === "string" ? id : "");
  if (!result.ok) return refusal(result);
  // The run itself, so Run now can say what it did (walk 4, W4-11).
  return answer({ ok: true, task: result.task, run: runOf(result.body && result.body.run) });
}
