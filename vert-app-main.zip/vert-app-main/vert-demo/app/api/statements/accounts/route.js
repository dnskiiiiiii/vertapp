// app/api/statements/accounts — WHICH ACCOUNTS A STATEMENT CAN BE FOR, READ FROM THE BROWSER
// ==============================================================================
//   GET /api/statements/accounts → `{ ok, accounts }` (bank, card and loan accounts on the
//   chart, lib/statement-accounts.js) or `{ ok: false, message }` saying why not.
//
// A GET, because the import sheet reads it on opening: a read must never be a Server
// Action POST (tests/p0-quiet-page-load.test.js). The chart is read on the server
// (lib/ledger-activity.js), so the key stays here. A chart that couldn't be read is a
// sentence, never an empty list: "no accounts" would be a claim nobody measured.

import { readLedgerAccounts } from "@/lib/ledger-activity";
import { statementAccounts } from "@/lib/statement-accounts";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export async function GET() {
  try {
    const read = await readLedgerAccounts();
    if (!read.ok) return reply({ ok: false, code: read.code || "unread", message: read.message || "Vert couldn't read your chart of accounts just now." }, read.kind === "unavailable" ? 503 : 200);
    return reply({ ok: true, accounts: statementAccounts(read.accounts) }, 200);
  } catch {
    return reply({ ok: false, code: "unreachable", message: "Vert couldn't read your chart of accounts just now." }, 502);
  }
}
