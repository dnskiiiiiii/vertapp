// app/api/statements — A STATEMENT ALREADY ATTACHED, READ FROM THE BROWSER
// ==============================================================================
//   GET /api/statements?document=<uuid>[&file_name=&account_id=&currency=&deposits_are_positive=]
//     → the question's inspection (components/chat/questions/actions.js
//       inspectQuestionStatementAction): `{ ok, fileName, inspection, preview }` or a refusal
//
// WHY A ROUTE FOR THE READ (28 Oct 2026). A statement question with one statement
// attached reads it on arrival; as a Server Action that was a POST before anyone pressed
// anything (tests/p0-quiet-page-load.test.js). The inspection writes nothing upstream, and
// it is called here on the server, so the key stays there. A dropped file and the commit
// (`confirmStatementAction`) are presses and stay Server Actions; neither is served here.

import { inspectQuestionStatementAction } from "@/components/chat/questions/actions";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };
const DOCUMENT_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const FIELDS = ["file_name", "account_id", "currency", "deposits_are_positive"];

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export async function GET(request) {
  const params = new URL(request.url).searchParams;
  const documentId = (params.get("document") || "").trim();
  if (!DOCUMENT_ID.test(documentId)) {
    return reply({ ok: false, kind: "refused", status: 400, code: "bad_document_id", remedy: "That statement isn't one Vert holds. Nothing was imported.", reason: null, rowNumber: null, inspection: null }, 400);
  }
  const form = new FormData();
  form.append("document_id", documentId);
  for (const key of FIELDS) {
    const value = params.get(key);
    if (typeof value === "string" && value.trim()) form.append(key, value.trim());
  }
  try {
    const outcome = await inspectQuestionStatementAction(null, form);
    if (outcome && outcome.ok) return reply(outcome, 200);
    const r = outcome || {};
    const status = r.kind === "unavailable" ? 503 : Number.isInteger(r.status) && r.status >= 400 && r.status < 600 ? r.status : 502;
    return reply(r, status);
  } catch {
    return reply({ ok: false, kind: "unreachable", status: 502, remedy: "The request didn't reach Vert. Nothing was imported.", reason: null, rowNumber: null, inspection: null }, 502);
  }
}
