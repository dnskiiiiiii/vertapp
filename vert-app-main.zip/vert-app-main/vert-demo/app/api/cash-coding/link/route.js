// app/api/cash-coding/link — "WHICH XERO ACCOUNT IS THIS STATEMENT", THROUGH THE APP
// ==============================================================================
//   POST /api/cash-coding/link  { period, account, glAccount }  → the fresh grid
//
// Founder, 7 Nov 2026. The grid asks which Xero bank account an unlinked statement is,
// instead of sending the person to run the bank reconciliation. The key and actor are
// added on the server (lib/cash-coding.js); the browser never sees them.

import { linkCashAccount } from "@/lib/cash-coding";
import { isSameOrigin } from "@/lib/agent/same-origin";
import { answer, crossOrigin, jsonOf, refusal } from "../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const result = await linkCashAccount(await jsonOf(request));
  if (!result.ok) return refusal(result);
  return answer({ ...(result.body || {}), ok: true });
}
