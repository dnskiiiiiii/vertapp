// app/api/cash-coding/code — "CODE N LINES", THROUGH THE APP
// ==============================================================================
//   POST /api/cash-coding/code  { period, account, lines: [{ lineId, accountCode,
//                                 taxType?, contact?, remember }] }  → the engine's per-row results
//
// w25 contract §2. The key and the actor are added on the server (lib/cash-coding.js);
// the browser never sees them. Reached only from the person's press of "Code N lines".

import { codeCashLines } from "@/lib/cash-coding";
import { isSameOrigin } from "@/lib/agent/same-origin";
import { answer, crossOrigin, jsonOf, refusal } from "../shared";

export const dynamic = "force-dynamic";
// The engine writes each line to Xero inside the request (lib/engine-source.js
// WRITE_TIMEOUT_MS), so the function may run as long as that takes.
export const maxDuration = 300;

export async function POST(request) {
  if (!isSameOrigin(request)) return crossOrigin();
  const result = await codeCashLines(await jsonOf(request));
  if (!result.ok) return refusal(result);
  return answer({ ...(result.body || {}), ok: true });
}
