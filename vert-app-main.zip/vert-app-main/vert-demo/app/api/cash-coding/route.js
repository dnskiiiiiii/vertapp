// app/api/cash-coding — ONE ACCOUNT'S LINES TO CODE, READ FROM THE BROWSER
// ==============================================================================
//   GET /api/cash-coding?period=YYYY-MM[&account=<id>]  → the engine's GET /cash-coding
//
// The chat draws the Cash coding grid inside its answer (founder, 8 Nov 2026: "it should
// be just the cash coding table in the chat and not need to click into it"), so the
// browser reads the grid here and switches account in place. A read: it writes nothing.
// The key is added on the server (lib/cash-coding.js); the browser never sees it.

import { readCashCoding } from "@/lib/cash-coding";
import { answer, refusal } from "./shared";

export const dynamic = "force-dynamic";
// The engine's read waits on its Xero reads (cached 5 minutes on its side).
export const maxDuration = 60;

export async function GET(request) {
  const q = new URL(request.url).searchParams;
  const result = await readCashCoding({ account: q.get("account"), period: q.get("period") });
  if (!result.ok) return refusal(result);
  return answer({ ok: true, body: result.body });
}
