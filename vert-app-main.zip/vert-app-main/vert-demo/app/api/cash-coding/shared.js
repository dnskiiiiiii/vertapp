// app/api/cash-coding/shared.js — WHAT EVERY CASH CODING ROUTE ANSWERS WITH
//
// The bills routes' answers (app/api/bills/shared.js): a refusal is its status and
// `{ ok: false, kind, code, message }`, and every route that changes something checks
// the request's origin first, before the body is read.

export { answer, crossOrigin, jsonOf, refusal } from "../bills/shared";
