// app/api/activity — WHO DID WHAT IN ONE CONVERSATION, READ FROM THE BROWSER
// ==============================================================================
// Build plan §19.0.9, §19.9 F-FIRM. `GET /api/activity?session=<id>` → the engine's
// `GET /activity?session=`: the conversation's people and Vert in one list, each line
// with the actor the engine recorded ("Priya approved JE 1", "Vert posted JE #4421").
// The context sheet draws it; it is not a new screen.
//
// THE KEY STAYS ON THE SERVER (lib/session.js sessionGet adds it, and the chosen
// client with it). A read that could not be made answers by status and code only:
// 503 where there is no service (the sheet then draws no section, as it does for
// files), 401 signed out, 502 when the read failed — never an empty list, which would
// say "nobody has done anything here", which nobody measured.

import { sessionGet } from "@/lib/session";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };
const SESSION_ID = /^[A-Za-z0-9_-]{1,128}$/;

function reply(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

const STATUS = { "no-service": 503, "signed-out": 401, failed: 502 };

export async function GET(request) {
  const session = new URL(request.url).searchParams.get("session") || "";
  if (!SESSION_ID.test(session)) return reply({ ok: false, code: "invalid_request" }, 400);
  const read = await sessionGet(`/activity?session=${encodeURIComponent(session)}`);
  if (!read.ok) return reply({ ok: false, code: read.reason }, STATUS[read.reason] || 502);
  const items = read.body && Array.isArray(read.body.items) ? read.body.items : null;
  if (!items) return reply({ ok: false, code: "bad_response" }, 502);
  return reply({ ok: true, sessionId: read.body.sessionId || session, items }, 200);
}
