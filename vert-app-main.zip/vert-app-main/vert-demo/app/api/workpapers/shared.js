// app/api/workpapers/shared.js — THE WIRE FOR A WORKBOOK EDIT, AND ITS RULES
// ==============================================================================
// Build plan §19.0.10 and §19.10 F-EDIT, on XLS's engine routes:
//
//   POST /workpapers/{artifactId}/cells   change input cells; the engine writes version n+1
//   GET  /workpapers/{artifactId}.xlsx    the workbook as it now stands (./[id]/xlsx, through
//                                         lib/api-download.js)
//
// WHY THIS IS ITS OWN MODULE. lib/workpapers.js is a "use server" file, and every export
// of one is a Server Action the browser can call with arguments of its choosing. The
// parts that take a fetch implementation and a base URL cannot be exported from there
// (a browser could aim them anywhere), yet they are the parts worth testing. So the wire
// lives here, plain and injectable, and the Server Action supplies the key and the base.
//
// WHAT IS CHECKED BEFORE ANYTHING IS SENT, and why each is here as well as in the engine:
//   · the artifact id and every cell reference have the engine's own shape, so no path
//     segment or body field is built from anything else;
//   · money is integer cents and words are text, never both, never neither (the engine's
//     CellEdit); a cell cannot be emptied from the pane;
//   · nothing starting with "=" is sent: a formula typed into an input cell would turn
//     the person's input into Vert's arithmetic, and the engine refuses it anyway;
//   · `baseVersion` is the version the person was looking at. A save against any other is
//     refused by the engine (409) so a teammate's change is never overwritten unseen.
//
// EVERY FUNCTION RETURNS, NEVER THROWS: `{ ok: true, ... }` or `{ ok: false, kind, code,
// status, message }`, and every refusal says that nothing was saved.

import { engineFetch } from "@/lib/engine-gate";

// vert_api/routers/workpapers.py `_ARTIFACT` and `_CELL_REF`, restated.
export const ARTIFACT_ID = /^[^\x00-\x1f\x7f/]+:[^\x00-\x1f\x7f/:]+$/;
export const CELL_REF = /^[^!]{1,31}![A-Z]{1,3}[1-9][0-9]{0,6}$/;
export const MAX_EDITS = 200;
export const MAX_TEXT = 1000;
const TIMEOUT_MS = 30000;

const NOTHING_SAVED = "Nothing was saved.";

// WHICH WORKBOOK (ENG-DOCS-e2, D43). A schedule laid into last month's upload has two
// workbooks, each with its own cells and version: Vert's own (`house`) and the copy in
// the person's format (`yours`). The cells GET and POST default to `house`; the copy is
// edited, and downloaded, by naming it.
export const TARGETS = Object.freeze(["house", "yours"]);

/** `target` when it is one the engine knows, else null (the engine's default). */
export function targetOf(value) {
  return TARGETS.includes(value) ? value : null;
}

function withTarget(path, target) {
  const t = targetOf(target);
  return t ? `${path}?target=${t}` : path;
}

/**
 * The cells a save touched, as "Sheet!A1" references. The engine answers
 * `{sheet: [cell]}` (D43: kept only if it was an array, so the bar always got [] and
 * never said a formula was left to recalculate); a flat list is kept as it came.
 */
export function cellList(value) {
  const out = [];
  const push = (ref) => {
    if (typeof ref === "string" && ref.trim() && !out.includes(ref.trim())) out.push(ref.trim());
  };
  if (Array.isArray(value)) value.forEach(push);
  else if (value && typeof value === "object") {
    for (const [sheet, cells] of Object.entries(value)) {
      for (const c of Array.isArray(cells) ? cells : []) {
        if (typeof c !== "string" || !c.trim()) continue;
        push(c.includes("!") ? c : `${sheet}!${c}`);
      }
    }
  }
  return out;
}

export function refused(code, message, status = 0) {
  return { ok: false, kind: "refused", code, status, message };
}

/** The engine path for an artifact; the ":" between session and key is kept, as the
 * engine's own href keeps it (`quote(artifact_id, safe=':')`). */
export function artifactPath(artifactId) {
  return encodeURIComponent(artifactId).replace(/%3A/g, ":");
}

export function isArtifactId(value) {
  return typeof value === "string" && value.length >= 3 && value.length <= 300 && ARTIFACT_ID.test(value);
}

/**
 * The request body for `edits`, or a refusal. Each edit is `{ cell, cents }` or
 * `{ cell, text }`, exactly one of the two.
 */
export function cellsBody(edits, baseVersion) {
  if (!Number.isInteger(baseVersion) || baseVersion < 0) return refused("invalid_request", `The workbook's version wasn't known. ${NOTHING_SAVED}`);
  if (!Array.isArray(edits) || !edits.length) return refused("no_edits", `There are no changes to save. ${NOTHING_SAVED}`);
  if (edits.length > MAX_EDITS) return refused("too_many", `Save at most ${MAX_EDITS} cells at a time. ${NOTHING_SAVED}`);
  const out = [];
  const seen = new Set();
  for (const edit of edits) {
    const cell = edit && typeof edit.cell === "string" ? edit.cell : "";
    if (!CELL_REF.test(cell)) return refused("invalid_request", `"${String(cell).slice(0, 40)}" isn't a cell Vert can change. ${NOTHING_SAVED}`);
    if (seen.has(cell)) return refused("invalid_request", `${cell} was changed twice in one save. ${NOTHING_SAVED}`);
    seen.add(cell);
    const hasCents = edit.cents !== undefined && edit.cents !== null;
    const hasText = edit.text !== undefined && edit.text !== null;
    if (hasCents === hasText) return refused("invalid_request", `${cell}: a cell is an amount or words, not both and not neither. ${NOTHING_SAVED}`);
    if (hasCents) {
      if (!Number.isSafeInteger(edit.cents)) return refused("invalid_request", `${cell}: an amount is whole cents. ${NOTHING_SAVED}`);
      out.push({ cell, cents: edit.cents });
    } else {
      if (typeof edit.text !== "string" || !edit.text.trim()) return refused("invalid_request", `${cell}: Vert can't empty a cell from here. ${NOTHING_SAVED}`);
      if (edit.text.trim().startsWith("=")) return refused("formula_refused", `${cell}: formulas can't be typed here; the workbook's own formulas stay as they are. ${NOTHING_SAVED}`);
      if (edit.text.length > MAX_TEXT) return refused("invalid_request", `${cell}: at most ${MAX_TEXT} characters. ${NOTHING_SAVED}`);
      out.push({ cell, text: edit.text });
    }
  }
  return { ok: true, body: { baseVersion, edits: out } };
}

/** The engine's answer to a save, read back before it is reported as saved. */
export function savedFrom(status, body, artifactId) {
  if (status < 200 || status >= 300) {
    const envelope = body && body.error;
    const code = envelope && typeof envelope.code === "string" && /^[a-z][a-z0-9_]*$/.test(envelope.code) ? envelope.code : `http_${status}`;
    const said = envelope && typeof envelope.message === "string" && envelope.message.trim() ? envelope.message.trim() : "";
    const message = status === 409 && envelope && envelope.detail && Number.isInteger(envelope.detail.version) && Number.isInteger(envelope.detail.baseVersion)
      ? "Someone saved this workbook since you opened it. Reload it and make your change again. Nothing was saved."
      : said
        ? (/nothing was saved/i.test(said) ? said : `${said} ${NOTHING_SAVED}`)
        : `The workbook wasn't saved (${code}). ${NOTHING_SAVED}`;
    return refused(code, message, status);
  }
  // A 2xx that does not name the new version is not reported as saved: nobody could
  // download what it claims to have written.
  if (!body || body.artifactId !== artifactId || !Number.isInteger(body.version) || body.version < 1) {
    return refused("bad_response", `Vert didn't confirm the new version. Reload the workbook before saving again.`, status);
  }
  const target = targetOf(body.target);
  return {
    ok: true,
    artifactId,
    version: body.version,
    documentId: typeof body.documentId === "string" ? body.documentId : null,
    target,
    title: typeof body.title === "string" && body.title.trim() ? body.title.trim() : null,
    // The app's own download for the version just written (./[id]/xlsx/route.js), of
    // the workbook the save named (the response's `href` target): after a house edit
    // the .xlsx default would serve the copy when an upload exists (D43).
    download: workbookHref(artifactId, body.version, target),
    // Formula cells the edit touched, saved uncached: Excel recalculates them on open.
    uncached: cellList(body.uncached),
    // Totals the engine recomputed and cached itself on this save (D43).
    recomputed: cellList(body.recomputed),
    // The engine's own sentences about the save (verify pass 2, ENG-DOCS): e.g. "JE 1 in
    // version 1 debits $200.00; the entry drafted in Vert still debits $181.82…". Said
    // beside "Saved as version N", never dropped; strings only, at most five.
    said: (Array.isArray(body.said) ? body.said : []).filter((w) => typeof w === "string" && w.trim()).map((w) => w.trim()).slice(0, 5),
  };
}

/** The app path that downloads an artifact's latest workbook. `v` only busts caches;
 *  `target` names which workbook ("house" or "yours") when the result has two. */
export function workbookHref(artifactId, version = null, target = null) {
  const base = `/api/workpapers/${encodeURIComponent(artifactId)}/xlsx`;
  const query = [];
  if (Number.isInteger(version) && version > 0) query.push(`v=${version}`);
  if (targetOf(target)) query.push(`target=${target}`);
  return query.length ? `${base}?${query.join("&")}` : base;
}

/** POST the edits; `headers` carries the key and the actor, added on the server. */
export async function postCells({ artifactId, edits, baseVersion, base, headers = {}, fetchImpl = globalThis.fetch, target = null }) {
  if (!isArtifactId(artifactId)) return refused("invalid_request", `That isn't a workbook Vert has. ${NOTHING_SAVED}`);
  const built = cellsBody(edits, baseVersion);
  if (!built.ok) return built;
  let response;
  try {
    response = await engineFetch(fetchImpl, `${base}${withTarget(`/workpapers/${artifactPath(artifactId)}/cells`, target)}`, {
      method: "POST",
      headers: { ...headers, "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify(built.body),
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (cause) {
    if (cause && typeof cause.digest === "string") throw cause; // Next's own control flow
    return { ok: false, kind: "unreachable", code: "unreachable", status: 0, message: `The change didn't reach Vert. ${NOTHING_SAVED}` };
  }
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  return savedFrom(response.status, body, artifactId);
}

// ─────────────── reading a generated workbook's input cells (eval r2 #7) ───────────────
//
//   GET /workpapers/{artifactId}/cells   the input cells of the workbook as it now stands
//
// WHY THE PANE ASKS. A generated result's table is the month's schedule, not a list of
// cells, so it names no workbook cell a person could change, and the engine lists
// `editable` only for a workbook a person uploaded (modify_workbook). The engine's own
// reading of the file (modify_workbook `input_cells`: every cell under a heading row
// that is not a formula and not merged) is the one rule for which cells are inputs, so
// the pane fetches that list instead of guessing it from the table; a guess would be a
// second implementation of the rule, and an input the engine then refused would lie.
//
// WHAT IS KEPT. A cell is kept only when its reference has the engine's own shape and
// its value now is not a formula: a formula the engine wrongly listed stays read-only
// here too. The version is the one the cells were read from, and is what a save is sent
// against, so a teammate's newer save is refused (409) rather than overwritten.

export const MAX_LISTED = 200;

/** The engine's answer to "which cells can change", read before the pane draws inputs. */
export function inputCellsFrom(status, body, artifactId) {
  if (status < 200 || status >= 300) {
    const envelope = body && body.error;
    const code = envelope && typeof envelope.code === "string" && /^[a-z][a-z0-9_]*$/.test(envelope.code) ? envelope.code : `http_${status}`;
    const said = envelope && typeof envelope.message === "string" && envelope.message.trim() ? envelope.message.trim() : "";
    const message = status === 404 && code === "http_404"
      ? "Vert can't open this workbook's cells for editing yet."
      : said || `Vert couldn't read this workbook's cells (${code}).`;
    return { ok: false, kind: "refused", code, status, message };
  }
  if (!body || body.artifactId !== artifactId || !Number.isInteger(body.version) || body.version < 0 || !Array.isArray(body.cells)) {
    return { ok: false, kind: "refused", code: "bad_response", status, message: "Vert didn't say which cells of this workbook can change." };
  }
  const seen = new Set();
  const cells = [];
  for (const c of body.cells) {
    if (!c || typeof c.cell !== "string" || !CELL_REF.test(c.cell) || seen.has(c.cell)) continue;
    const value = c.value === null || c.value === undefined ? "" : String(c.value);
    if (value.trim().startsWith("=")) continue;
    seen.add(c.cell);
    cells.push({
      cell: c.cell,
      label: typeof c.label === "string" ? c.label : "",
      heading: typeof c.heading === "string" ? c.heading : "",
      value,
    });
    if (cells.length >= MAX_LISTED) break;
  }
  const total = Number.isInteger(body.total) && body.total >= cells.length ? body.total : cells.length;
  // WHICH WORKBOOK THESE ARE (D43): its own name, and every workbook the result has,
  // each with its version, so the pane names what it edits and offers the other.
  const targets = (Array.isArray(body.targets) ? body.targets : [])
    .filter((t) => t && targetOf(t.target) && Number.isInteger(t.version) && t.version >= 0)
    .map((t) => ({ target: t.target, title: typeof t.title === "string" && t.title.trim() ? t.title.trim() : null, version: t.version }));
  return {
    ok: true,
    artifactId,
    version: body.version,
    cells,
    total,
    target: targetOf(body.target),
    title: typeof body.title === "string" && body.title.trim() ? body.title.trim() : null,
    targets,
  };
}

/** GET the input cells; `headers` carries the key and the actor, added on the server. */
export async function getInputCells({ artifactId, base, headers = {}, fetchImpl = globalThis.fetch, target = null }) {
  if (!isArtifactId(artifactId)) return { ok: false, kind: "refused", code: "invalid_request", status: 0, message: "That isn't a workbook Vert has." };
  let response;
  try {
    response = await engineFetch(fetchImpl, `${base}${withTarget(`/workpapers/${artifactPath(artifactId)}/cells`, target)}`, {
      method: "GET",
      headers: { ...headers, accept: "application/json" },
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (cause) {
    if (cause && typeof cause.digest === "string") throw cause; // Next's own control flow
    return { ok: false, kind: "unreachable", code: "unreachable", status: 0, message: "Vert couldn't be reached to read this workbook's cells." };
  }
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  return inputCellsFrom(response.status, body, artifactId);
}

// ─────────────── saving an edited commentary (iteration 4, §20.0 decisions 7–8) ───────────────
//
//   POST /workpapers/{artifactId}/commentary   {baseVersion, sections: [{key, paragraphs: [{text}]}]}
//
// COMM-B's route (vert_api/routers/workpapers.py `save_commentary`, CommentaryEdits). The
// body is built by the editor (components/chat/results/Commentary.js commentaryEdits,
// figures rebound to their `{{fig:…}}` tokens); it is checked again here against the
// engine's own limits before anything leaves, so a body the engine would refuse is
// refused with words, not a 422. Numbers a person typed stay their text: the engine
// re-scans the saved prose and marks them "added by", and nothing here counts them.
//
// SAVED ONLY WHEN THE ENGINE NAMES THE NEW VERSION, as for a cell edit: the screen says
// "Saved as v2" from the engine's answer, and the conversation then receives the
// artifact again as v2 on its stream, which is what the pane redraws from.

export const MAX_SECTIONS = 12;
export const MAX_PARAGRAPHS = 50;
export const MAX_PARAGRAPH = 4000;
const SECTION_KEY = /^[a-z][a-z0-9_]{0,63}$/;

/** The engine's CommentaryEdits, exact keys, or a refusal before anything is sent. */
export function commentaryBody(body) {
  const b = body && typeof body === "object" ? body : {};
  if (!Number.isInteger(b.baseVersion) || b.baseVersion < 1) return refused("invalid_request", `Vert can't tell which version this is. ${NOTHING_SAVED}`);
  if (!Array.isArray(b.sections) || !b.sections.length || b.sections.length > MAX_SECTIONS) return refused("invalid_request", `The commentary's sections weren't readable. ${NOTHING_SAVED}`);
  const sections = [];
  const seen = new Set();
  for (const s of b.sections) {
    if (!s || typeof s.key !== "string" || !SECTION_KEY.test(s.key) || seen.has(s.key)) return refused("invalid_request", `The commentary's sections weren't readable. ${NOTHING_SAVED}`);
    seen.add(s.key);
    const paras = Array.isArray(s.paragraphs) ? s.paragraphs : [];
    if (paras.length > MAX_PARAGRAPHS) return refused("invalid_request", `A section holds at most ${MAX_PARAGRAPHS} paragraphs. ${NOTHING_SAVED}`);
    const out = [];
    for (const p of paras) {
      if (!p || typeof p.text !== "string") return refused("invalid_request", `A paragraph wasn't readable. ${NOTHING_SAVED}`);
      if (p.text.length > MAX_PARAGRAPH) return refused("invalid_request", `A paragraph is at most 4,000 characters. ${NOTHING_SAVED}`);
      if (p.text.trim()) out.push({ text: p.text });
    }
    sections.push({ key: s.key, paragraphs: out });
  }
  return { ok: true, body: { baseVersion: b.baseVersion, sections } };
}

/** The engine's answer to a commentary save, read back before it is reported. */
export function commentarySavedFrom(status, body, artifactId) {
  if (status === 501) return refused("not_connected", `Saving commentary isn't connected here yet. ${NOTHING_SAVED}`, status);
  if (status === 404) return refused("artifact_not_found", `Vert couldn't find this commentary. ${NOTHING_SAVED}`, status);
  const saved = savedFrom(status, body, artifactId);
  if (!saved.ok) return saved;
  return { ok: true, artifactId, version: saved.version, download: saved.download };
}

/** POST the edited commentary; `headers` carries the key and the actor, added on the server. */
export async function postCommentary({ artifactId, body, base, headers = {}, fetchImpl = globalThis.fetch }) {
  if (!isArtifactId(artifactId)) return refused("invalid_request", `That isn't a commentary Vert has. ${NOTHING_SAVED}`);
  const built = commentaryBody(body);
  if (!built.ok) return built;
  let response;
  try {
    response = await engineFetch(fetchImpl, `${base}/workpapers/${artifactPath(artifactId)}/commentary`, {
      method: "POST",
      headers: { ...headers, "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify(built.body),
      cache: "no-store",
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });
  } catch (cause) {
    if (cause && typeof cause.digest === "string") throw cause; // Next's own control flow
    return { ok: false, kind: "unreachable", code: "unreachable", status: 0, message: `The change didn't reach Vert. ${NOTHING_SAVED}` };
  }
  let answer = null;
  try {
    answer = await response.json();
  } catch {
    answer = null;
  }
  return commentarySavedFrom(response.status, answer, artifactId);
}
