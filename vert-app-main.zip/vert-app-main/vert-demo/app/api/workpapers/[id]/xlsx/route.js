// app/api/workpapers/[id]/xlsx — A RESULT'S WORKBOOK AS IT NOW STANDS
// ==============================================================================
// Build plan §19.10 F-EDIT. The engine's `GET /workpapers/{artifactId}.xlsx` serves the
// newest of: the person's last in-pane edit (a saved version), their own uploaded format
// with this month laid in, or Vert's house workbook. The pane's "Save changes · Download"
// fetches here after a save, so the file that downloads is the version that carries the
// edit — the house workbook at /api/agent/artifacts/{id}/xlsx is rebuilt from the table
// and would silently drop it.
//
// The bytes pass through lib/api-download.js, the one module that streams engine-built
// files with the session's key added on the server; a refusal is the engine's sentence
// with its status, never a file. An id the engine could not have minted is refused here
// with nothing sent.

import { passThroughDownload } from "@/lib/api-download";
import { artifactPath, isArtifactId, targetOf } from "../../shared";

export const dynamic = "force-dynamic";

export async function GET(request, { params }) {
  const { id } = await params;
  if (!isArtifactId(id)) {
    return new Response(JSON.stringify({ error: { code: "artifact_not_found" } }), {
      status: 404,
      headers: { "content-type": "application/json", "cache-control": "no-store" },
    });
  }
  // Which workbook (D43): `?target=house|yours` reaches the engine as it came; any
  // other value is dropped, and the engine's default (the copy when one exists) holds.
  let target = null;
  try {
    target = targetOf(new URL(request.url).searchParams.get("target"));
  } catch {
    target = null;
  }
  return passThroughDownload(`/workpapers/${artifactPath(id)}.xlsx${target ? `?target=${target}` : ""}`);
}
