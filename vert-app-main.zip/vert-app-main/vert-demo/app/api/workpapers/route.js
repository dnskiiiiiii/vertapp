// app/api/workpapers — NOTHING IS SERVED AT THE ROOT (build plan §19.10 F-EDIT).
// ==============================================================================
// An edited workbook downloads from ./[id]/xlsx, and edits are saved by the Server
// Action in lib/workpapers.js (which adds the key and the actor on the server). The
// engine's `GET /workpapers` is a JSON list of what can be generated, not something the
// browser reads, so the root answers 404 with a code: a route that returned an empty
// list would read as "nothing there", which is a claim.

export const dynamic = "force-dynamic";

function notServed() {
  return new Response(JSON.stringify({ error: { code: "not_found" } }), {
    status: 404,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
}

export const GET = notServed;
export const POST = notServed;
export const PATCH = notServed;
