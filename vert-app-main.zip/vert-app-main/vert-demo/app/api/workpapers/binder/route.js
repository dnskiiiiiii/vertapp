// app/api/workpapers/binder — THE MONTH'S BINDER, THROUGH THE APP
// ==============================================================================
// Verify pass 3, D35 / S-E2E-6. The engine serves every workbook a month delivered as
// one zip at `GET /workpapers/binder.zip?period=YYYY-MM` (vert_api/routers/workpapers.py
// `workpaper_binder`). The binder card used to build its download from its artifact id
// (`/api/agent/artifacts/<binder>/xlsx`), which the engine refuses (409: the binder has
// no table), so the browser's download was cancelled. This route passes the real zip
// through with the session's key added on the server (lib/api-download.js), as the
// other workbook routes do. `?contents=1` answers the binder's contents list instead
// (the titles the engine's index lists for the month), so the pane can say what is in
// the zip before it is downloaded.

import { passThroughDownload, readApiJson } from "@/lib/api-download";

export const dynamic = "force-dynamic";

const PERIOD = /^[0-9]{4}-(0[1-9]|1[0-2])$/;

function refused(status, code) {
  return new Response(JSON.stringify({ error: { code } }), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store" },
  });
}

/** The binder's contents from the engine's index: the delivered results, by title. Pure. */
export function binderContents(body) {
  const rows = body && Array.isArray(body.workpapers) ? body.workpapers : [];
  const out = [];
  for (const r of rows) {
    if (!r || r.kind !== "result" || typeof r.title !== "string" || !r.title.trim()) continue;
    out.push(r.title.trim());
  }
  return out;
}

export async function GET(request) {
  const url = new URL(request.url);
  const period = url.searchParams.get("period") || "";
  if (!PERIOD.test(period)) return refused(400, "invalid_request");
  if (url.searchParams.get("contents")) {
    const read = await readApiJson(`/workpapers?period=${period}`);
    if (!read || read.error) return refused(502, "not_read");
    return new Response(JSON.stringify({ period, contents: binderContents(read.body) }), {
      status: 200,
      headers: { "content-type": "application/json", "cache-control": "no-store" },
    });
  }
  return passThroughDownload(`/workpapers/binder.zip?period=${period}`);
}
