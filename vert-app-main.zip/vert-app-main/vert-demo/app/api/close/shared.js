// app/api/close/shared.js — THE WIRE FOR STEP 5 OF THE CLOSE LIST, AND ITS RULES
// ==============================================================================
// W4 Step 5 (29 Oct 2026), on the engine's close routes:
//
//   GET  /close/{period}/statements   the profit and loss, balance sheet and cash flow  read
//   GET  /close/{period}/pack         the month-end pack's contents list (lib/api-download.js
//                                     readApiJson, as the binder's)                        read
//   GET  /close/{period}/pack.pdf     the pack as a PDF (passed through as bytes)        read
//   GET  /close/{period}/pack.xlsx    the pack as a workbook                             read
//   GET  /close/{period}/lock         where sign-off and the ledger's lock date stand    read
//   GET  /close/{period}/documents    the month's statements, bills and receipts (w33;   read
//                                     ?live=1 on the card's press reads Xero's bills)
//   POST /close/{period}/sign-off     Vert closes the month on its side → the lock status approve
//                                     ({acknowledgeOpen: [keys]} only once the person has
//                                     confirmed the month's open rows by name, below)
//   POST /close/{period}/reopen       {reason} reopens it; who and why are kept          approve
//
// WHY ITS OWN MODULE, as app/api/reminders/shared.js: the parts that take a fetch and a
// base URL are the parts worth testing, and they must not be reachable from a browser
// with arguments of its choosing. lib/close.js supplies the key, the actor and the base
// on the server; the routes under app/api/close/ check the period and the origin.
//
// EVERY FUNCTION RETURNS, NEVER THROWS: `{ ok: true, status, body }` or `{ ok: false,
// kind, code, status, message }`. `message` is the engine's own `error.message` with its
// `detail.remedy` when it sent them (they are written for the person), else a sentence
// of ours that says what did and didn't happen. A sign-off whose answer was lost is never
// worded as "nothing happened": it may have landed, and Check again reads which.

import { engineFetch } from "@/lib/engine-gate";

const READ_TIMEOUT_MS = 30000;
// Signing off keeps the month's balances on the engine's side, which reads the ledger.
const SIGN_OFF_TIMEOUT_MS = 60000;
const PERIOD = /^[0-9]{4}-(0[1-9]|1[0-2])$/;
const FORMATS = new Set(["pdf", "xlsx"]);

const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

/** Whether `v` is a month this app builds an engine path from (YYYY-MM, 01 to 12). Pure. */
export function isClosePeriod(v) {
  return typeof v === "string" && PERIOD.test(v);
}

/** The engine's path for the pack in `format` ("pdf" or "xlsx"), or null. Pure. */
export function packPath(period, format) {
  return isClosePeriod(period) && FORMATS.has(format) ? `/close/${period}/pack.${format}` : null;
}

/** The engine's path for the pack's contents list. Pure. */
export function packContentsPath(period) {
  return isClosePeriod(period) ? `/close/${period}/pack` : null;
}

function refused(code, message, status = 0, kind = "refused") {
  return { ok: false, kind, code, status, message };
}

/** The engine's refusal envelope, read into words a person can act on. */
export function refusalFrom(status, body, fallback) {
  const envelope = body && typeof body === "object" && body.error && typeof body.error === "object" ? body.error : null;
  const code = envelope && typeof envelope.code === "string" && /^[a-z][a-z0-9_]*$/.test(envelope.code) ? envelope.code : `http_${status}`;
  const said = envelope ? text(envelope.message) : null;
  const remedy = envelope && envelope.detail && typeof envelope.detail === "object" ? text(envelope.detail.remedy) : null;
  let message = said ? [said, remedy].filter(Boolean).join(" ") : null;
  if (!message) {
    if (status === 401) message = `Sign in again. ${fallback}`;
    else if (status === 403) message = `Your role can't do that for this client. ${fallback}`;
    else message = `Vert couldn't do that just now (${code}). ${fallback}`;
  }
  const out = refused(code, message, status, status === 409 ? "blocked" : "refused");
  // OPEN WORK, NAMED (engine w3/int, UI walk D3): a sign-off over open checklist rows is
  // refused with each row in `detail.openItems`, so the panel can show them and the
  // person can confirm them by name. Carried as the engine sent them; the panel reads
  // them strictly (components/month/close-step.js openItemsOf).
  const open = envelope && envelope.detail && typeof envelope.detail === "object" ? envelope.detail.openItems : null;
  if (code === OPEN_ITEMS && Array.isArray(open)) out.openItems = open;
  return out;
}

/** The engine's code for a sign-off refused over open work nobody confirmed can wait. */
export const OPEN_ITEMS = "open_items_unacknowledged";

/** The most open rows one sign-off confirms (the engine's `SignOff.acknowledgeOpen`). */
export const ACKNOWLEDGE_MAX = 200;
const KEY_MAX = 200;

/**
 * The open rows' keys a sign-off's body confirms, or null when it confirms none: a list
 * of 1 to 200 non-blank strings, else nothing. Anything else is no acknowledgement, never
 * a partial one: the engine names every open row again if one is missing. Pure.
 */
export function acknowledgedOf(body) {
  const keys = body && typeof body === "object" && !Array.isArray(body) ? body.acknowledgeOpen : null;
  if (!Array.isArray(keys) || !keys.length || keys.length > ACKNOWLEDGE_MAX) return null;
  if (!keys.every((k) => typeof k === "string" && k.trim() && k.length <= KEY_MAX)) return null;
  return keys.slice();
}

/**
 * What the app's close routes answer the browser for a described outcome: `{ status,
 * body }`. A refusal is `{error: {code, message}}` with the engine's status, and the open
 * rows under `error.detail.openItems` when the engine named them. Pure.
 */
export function closeRouteAnswer(result, fallback = "Vert couldn't do that just now.") {
  if (result && result.ok) return { status: 200, body: result.body };
  const r = result || {};
  const status = r.kind === "unavailable" ? 503 : r.kind === "unreachable" ? 502 : Number.isInteger(r.status) && r.status >= 400 ? r.status : 502;
  const error = { code: r.code || "unreachable", message: r.message || fallback };
  if (Array.isArray(r.openItems)) error.detail = { openItems: r.openItems };
  return { status, body: { error } };
}

async function call(fetchImpl, url, init, timeoutMs) {
  let response;
  try {
    response = await engineFetch(fetchImpl, url, { ...init, cache: "no-store", signal: AbortSignal.timeout(timeoutMs) });
  } catch (cause) {
    if (cause && typeof cause.digest === "string") throw cause; // Next's own control flow
    return { response: null, body: null };
  }
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  return { response, body };
}

async function read(path, { base, headers = {}, fetchImpl = globalThis.fetch }, lost) {
  const { response, body } = await call(fetchImpl, `${base}${path}`, { method: "GET", headers: { ...headers, accept: "application/json" } }, READ_TIMEOUT_MS);
  if (!response) return refused("unreachable", lost, 0, "unreachable");
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, "");
  if (!body || typeof body !== "object") return refused("bad_response", `Vert's answer couldn't be read. ${lost}`, response.status);
  return { ok: true, status: response.status, body };
}

const BAD_PERIOD = "That isn't a month Vert can close. Choose a month like 2026-09.";

/** GET /close/{period}/lock: where sign-off and the ledger's lock date stand. */
export async function getLock({ period, ...rest }) {
  if (!isClosePeriod(period)) return refused("invalid_request", BAD_PERIOD, 400);
  return read(`/close/${period}/lock`, rest, "Vert couldn't read the month's close status just now.");
}

/** The engine's path for the month's documents checklist (w33, audit 1.1); `live` only
 *  for the person's press, which reads Xero's bills. Pure. */
export function documentsPath(period, { live = false } = {}) {
  return isClosePeriod(period) ? `/close/${period}/documents${live ? "?live=1" : ""}` : null;
}

/** GET /close/{period}/documents: statements, bills and receipts, in or missing. A read. */
export async function getDocuments({ period, live = false, ...rest }) {
  if (!isClosePeriod(period)) return refused("invalid_request", BAD_PERIOD, 400);
  return read(documentsPath(period, { live }), rest, "Vert couldn't read the month's documents just now.");
}

/** GET /close/{period}/statements. */
export async function getStatements({ period, ...rest }) {
  if (!isClosePeriod(period)) return refused("invalid_request", BAD_PERIOD, 400);
  return read(`/close/${period}/statements`, rest, "Vert couldn't read the month's statements just now.");
}

/**
 * POST /close/{period}/sign-off, once. `headers` carry the key and the actor (lib/close.js).
 * A POST is never asked twice (lib/engine-gate.js): the engine may have signed the month
 * off before the answer was lost, so a lost answer says so and points at Check again.
 *
 * `acknowledgeOpen`: the keys of the open rows the person confirmed can wait, sent only
 * when they were (`{"acknowledgeOpen": [...]}`); a clean month signs off with no body.
 */
export async function postSignOff({ period, acknowledgeOpen = null, base, headers = {}, fetchImpl = globalThis.fetch }) {
  if (!isClosePeriod(period)) return refused("invalid_request", `${BAD_PERIOD} Nothing was signed off.`, 400);
  const keys = acknowledgedOf({ acknowledgeOpen });
  const init = keys
    ? { method: "POST", headers: { ...headers, accept: "application/json", "content-type": "application/json" }, body: JSON.stringify({ acknowledgeOpen: keys }) }
    : { method: "POST", headers: { ...headers, accept: "application/json" } };
  const { response, body } = await call(fetchImpl, `${base}/close/${period}/sign-off`, init, SIGN_OFF_TIMEOUT_MS);
  if (!response) return refused("unreachable", "Vert didn't answer, so it isn't known whether the month was signed off. Press Check again to read where it stands.", 0, "unreachable");
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, "The month wasn't signed off.");
  if (!body || typeof body !== "object") return refused("bad_response", "Vert answered, but its answer couldn't be read. Press Check again to read where the month stands.", response.status);
  return { ok: true, status: response.status, body };
}

/** The most a reopening's reason may say (the engine's `Reopen.reason`). */
export const REASON_MAX = 500;

/** A reopening's reason, trimmed, or null when it is blank or too long. Pure. */
export function reasonOf(v) {
  const t = text(v);
  return t && t.length <= REASON_MAX ? t : null;
}

/**
 * POST /close/{period}/reopen with the person's reason, once. Reopening lets Vert draft
 * journals, bills and coded transactions into the month again; the engine keeps who
 * reopened it and why (review, 29 Oct 2026). A lost answer says it may have landed.
 */
export async function postReopen({ period, reason, base, headers = {}, fetchImpl = globalThis.fetch }) {
  if (!isClosePeriod(period)) return refused("invalid_request", `${BAD_PERIOD} Nothing was reopened.`, 400);
  const why = reasonOf(reason);
  if (!why) return refused("invalid_request", `Say why the month is being reopened (up to ${REASON_MAX} characters). Nothing was reopened.`, 400);
  const { response, body } = await call(
    fetchImpl,
    `${base}/close/${period}/reopen`,
    { method: "POST", headers: { ...headers, accept: "application/json", "content-type": "application/json" }, body: JSON.stringify({ reason: why }) },
    READ_TIMEOUT_MS
  );
  if (!response) return refused("unreachable", "Vert didn't answer, so it isn't known whether the month was reopened. Press Check again to read where it stands.", 0, "unreachable");
  if (response.status < 200 || response.status >= 300) return refusalFrom(response.status, body, "The month wasn't reopened.");
  if (!body || typeof body !== "object") return refused("bad_response", "Vert answered, but its answer couldn't be read. Press Check again to read where the month stands.", response.status);
  return { ok: true, status: response.status, body };
}
