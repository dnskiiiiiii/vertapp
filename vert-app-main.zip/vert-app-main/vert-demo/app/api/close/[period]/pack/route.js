// app/api/close/[period]/pack — THE MONTH-END PACK, THROUGH THE APP
// ==============================================================================
// W4 Step 5 (29 Oct 2026): "Download month-end pack". The engine builds the pack (the
// executive summary, the three statements, aged receivables and payables, and the
// commentary when one was drafted) as a PDF and as a workbook. A plain link to the
// engine can't carry the session's key, and a key in a URL is a credential in browser
// history, so the browser asks this app and the bytes come back untouched with the
// engine's own filename (lib/api-download.js), as the workpapers binder does:
//
//   GET ?format=pdf   → GET /close/{period}/pack.pdf
//   GET ?format=xlsx  → GET /close/{period}/pack.xlsx
//   GET ?contents=1   → GET /close/{period}/pack, the pack's sections as JSON
//
// A month or a format that isn't one is refused with 400 before the engine is asked.
// A download is a read: nothing here writes.

import { passThroughDownload, readApiJson } from "@/lib/api-download";
import { isClosePeriod, packContentsPath, packPath } from "../../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function answer(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export async function GET(request, { params }) {
  const { period } = (await params) || {};
  if (!isClosePeriod(period)) return answer({ error: { code: "invalid_request", message: "That isn't a month Vert can make a pack for." } }, 400);
  const query = new URL(request.url).searchParams;
  if (query.get("contents")) {
    const read = await readApiJson(packContentsPath(period));
    if (!read || read.error) return answer({ error: { code: "not_read", message: (read && read.error) || "Vert couldn't list the month-end pack just now." } }, 502);
    return answer(read.body, 200);
  }
  const path = packPath(period, query.get("format") || "");
  if (!path) return answer({ error: { code: "invalid_request", message: "Choose the pack as a PDF or as Excel." } }, 400);
  return passThroughDownload(path);
}
