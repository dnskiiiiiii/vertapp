// app/api/close/[period]/lock — SIGN OFF THE MONTH, AND WHERE THE LEDGER'S LOCK DATE STANDS
// ==============================================================================
// W4 Step 5 (29 Oct 2026): "Sign off and lock". Vert closes the month on its side, then
// the person sets the lock date in the ledger, and Check again reads whether it is set.
//
//   GET  → GET  /close/{period}/lock      the lock status (it re-reads the ledger's lock date)
//   POST → POST /close/{period}/sign-off  Vert signs the month off (role: approve); the
//                                          same lock status comes back. Optional body
//                                          {acknowledgeOpen: [keys]}: the open rows the
//                                          person confirmed can wait (engine w3/int, D3)
//
// Only a press reaches the POST: Month-end reads the status on the server and sends no
// write on a page view (tests/p0-quiet-page-load.test.js). Same origin only; the key and
// the actor are added on the server (lib/close.js). A sign-off is never retried
// (lib/engine-gate.js). A refusal is `{error: {code, message}}` with the engine's status,
// its message the engine's own words and remedy (app/api/close/shared.js refusalFrom).

import { isSameOrigin } from "@/lib/agent/same-origin";
import { readCloseLock, signOffClose } from "@/lib/close";
import { acknowledgedOf, closeRouteAnswer, isClosePeriod } from "../../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function answer(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

/** A described outcome from lib/close.js, as the route answers it (shared.js closeRouteAnswer:
 *  the open rows of a 409 ride under error.detail.openItems). */
function respond(result) {
  const { status, body } = closeRouteAnswer(result);
  return answer(body, status);
}

const BAD_PERIOD = { error: { code: "invalid_request", message: "That isn't a month Vert can close." } };

export async function GET(request, { params }) {
  const { period } = (await params) || {};
  if (!isClosePeriod(period)) return answer(BAD_PERIOD, 400);
  return respond(await readCloseLock(period));
}

export async function POST(request, { params }) {
  // Cross-origin is refused before anything else is read, and the engine is never asked.
  if (!isSameOrigin(request)) return answer({ error: { code: "cross_origin", message: "Nothing was signed off." } }, 403);
  const { period } = (await params) || {};
  if (!isClosePeriod(period)) return answer({ error: { code: "invalid_request", message: "That isn't a month Vert can close. Nothing was signed off." } }, 400);
  // The body is optional: a clean month signs off with none. With open work, the second
  // press sends the rows' keys the person confirmed (`acknowledgeOpen`); anything else is
  // read as no confirmation, and the engine names the rows again.
  let body = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }
  return respond(await signOffClose(period, acknowledgedOf(body)));
}
