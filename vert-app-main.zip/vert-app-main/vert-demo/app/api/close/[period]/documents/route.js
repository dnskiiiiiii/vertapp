// app/api/close/[period]/documents — THE MONTH'S DOCUMENTS, READ AGAIN ON A PRESS
// ==============================================================================
// w33 (audit 1.1, the close checklist's Step 1 "Collect documents"). Month-end reads the
// checklist on the server (app/page.js, a page read: the engine reads no Xero); the
// card's "Check bills" press asks this route with ?live=1, and only then does the engine
// read Xero's bills for the suppliers who usually bill monthly.
//
//   GET → GET /close/{period}/documents[?live=1]    a read; it writes nothing
//
// The key is added on the server (lib/close.js). A refusal is `{error: {code, message}}`
// with the engine's status and words (app/api/close/shared.js closeRouteAnswer).

import { readDocuments } from "@/lib/close";
import { closeRouteAnswer, isClosePeriod } from "../../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function answer(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export async function GET(request, { params }) {
  const { period } = (await params) || {};
  if (!isClosePeriod(period)) return answer({ error: { code: "invalid_request", message: "That isn't a month Vert can close." } }, 400);
  const live = new URL(request.url).searchParams.get("live") === "1";
  const { status, body } = closeRouteAnswer(await readDocuments(period, { live }));
  return answer(body, status);
}
