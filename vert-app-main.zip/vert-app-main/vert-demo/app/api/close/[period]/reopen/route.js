// app/api/close/[period]/reopen — REOPEN A SIGNED-OFF MONTH, SAYING WHY
// ==============================================================================
// Close Step 5 review (29 Oct 2026). Signing a month off stops Vert drafting journals,
// bills or coded transactions dated in it, so it can be undone: a person with the approve
// role reopens it with a reason, which the engine keeps beside who did it.
//
//   POST {reason} → POST /close/{period}/reopen   → the lock status, now reopened
//
// Only a press reaches this (the panel's Reopen, after the reason is typed). Same origin
// only; the key and the actor are added on the server (lib/close.js). Never retried.

import { isSameOrigin } from "@/lib/agent/same-origin";
import { reopenClose } from "@/lib/close";
import { isClosePeriod, reasonOf } from "../../shared";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

function answer(body, status) {
  return new Response(JSON.stringify(body), { status, headers: HEADERS });
}

export async function POST(request, { params }) {
  if (!isSameOrigin(request)) return answer({ error: { code: "cross_origin", message: "Nothing was reopened." } }, 403);
  const { period } = (await params) || {};
  if (!isClosePeriod(period)) return answer({ error: { code: "invalid_request", message: "That isn't a month Vert can reopen. Nothing was reopened." } }, 400);
  let body = null;
  try {
    body = await request.json();
  } catch {
    body = null;
  }
  const reason = reasonOf(body && typeof body === "object" ? body.reason : null);
  if (!reason) return answer({ error: { code: "invalid_request", message: "Say why the month is being reopened. Nothing was reopened." } }, 400);
  const result = await reopenClose(period, reason);
  if (result && result.ok) return answer(result.body, 200);
  const r = result || {};
  const status = r.kind === "unavailable" ? 503 : r.kind === "unreachable" ? 502 : Number.isInteger(r.status) && r.status >= 400 ? r.status : 502;
  return answer({ error: { code: r.code || "unreachable", message: r.message || "Vert couldn't reopen the month just now." } }, status);
}
