// app/api/budgets — THE BUDGET LIST, READ THROUGH THE APP (build plan §20.5 F-WIRE)
// ==============================================================================
// GET is the engine's `GET /budgets`, with the key added on the server as the
// conversation routes beside it do (lib/budgets.js listBudgets), and re-shaped by
// app/api/budgets/shared.js to the fields the sheet reads. A list the engine did not
// send is an error with a code, never `[]`: an empty list reads as "you have no
// budgets", which is a claim.
//
// `GET ?imports=YYYY-MM` is the month's open import questions (lib/budgets.js
// importQuestions), for Needs you. It is a GET so a page view sends no POST: Needs you
// called the server action itself from an effect, a `POST /` on every view of a running
// month (smoke test, 23 Oct; tests/p0-quiet-page-load.test.js). It never fails the
// page: an unread month answers an error with a code, and Needs you lists nothing.
//
// POST IS NOT SERVED HERE. Import and Choose are Server Actions (lib/budgets.js), which
// add the actor as well as the key; a second road that took a press from a plain fetch
// would be one more place to forget the actor. It answers 405 with a code.

import { importQuestions, listBudgets } from "@/lib/budgets";

export const dynamic = "force-dynamic";

const HEADERS = { "content-type": "application/json", "cache-control": "no-store" };

const STATUS_FOR = { no_service: 503, signed_out: 401, unreachable: 502 };

const PERIOD = /^\d{4}-(0[1-9]|1[0-2])$/;

export async function GET(request) {
  const url = request && typeof request.url === "string" ? new URL(request.url) : null;
  if (url && url.searchParams.has("imports")) {
    const period = url.searchParams.get("imports");
    if (!PERIOD.test(period || "")) return new Response(JSON.stringify({ error: { code: "no_period" } }), { status: 400, headers: HEADERS });
    const read = await importQuestions(period);
    if (read && read.ok && Array.isArray(read.imports)) return new Response(JSON.stringify({ imports: read.imports }), { status: 200, headers: HEADERS });
    const code = (read && read.code) || "unreachable";
    return new Response(JSON.stringify({ error: { code } }), { status: STATUS_FOR[code] || 502, headers: HEADERS });
  }
  const result = await listBudgets();
  if (result && result.ok) {
    return new Response(JSON.stringify({ budgets: result.budgets, lookups: result.lookups }), { status: 200, headers: HEADERS });
  }
  const code = (result && result.code) || "unreachable";
  const status = STATUS_FOR[code] || (Number.isInteger(result && result.status) && result.status >= 400 ? result.status : 502);
  return new Response(JSON.stringify({ error: { code } }), { status, headers: HEADERS });
}

export async function POST() {
  return new Response(JSON.stringify({ error: { code: "method_not_allowed" } }), { status: 405, headers: HEADERS });
}
