// app/api/budgets/shared.js — THE WIRE FOR THE BUDGET SHEET, AND ITS RULES
// ==============================================================================
// Build plan §20.0 decisions 2–4, §20.5 F-WIRE, on BSTORE's engine routes
// (vert_api/routers/budgets.py):
//
//   GET  /budgets                 every imported budget (latest version), each year's
//                                 choice marked, and where the ledger's own budgets stand
//   GET  /budgets/{id}            one version, its lines and its tie-out
//   POST /budgets/import          {sessionId, source, documentId?, sheet?, qboId?, fy?}
//   POST /budgets/{id}/choose     {sessionId, fy}
//
// WHY THIS IS ITS OWN MODULE. lib/budgets.js is a "use server" file, and every export of
// one is a Server Action a browser can call with arguments of its choosing. The parts
// that take a fetch and a base URL cannot be exported from there (a browser could aim
// them anywhere), yet they are the parts worth testing. So the wire lives here, plain
// and injectable, and the Server Action supplies the key, the actor and the base, as
// app/api/workpapers/shared.js does for a workbook edit.
//
// AN IMPORT IS A TURN, AND ONLY THE TURN COUNTS AS STARTED (decision 2). The engine
// answers a press with `{sessionId, turnId, queued, words}`: the conversation the import
// runs in (the month's "Import budget" conversation, which may not be the one the sheet
// was opened from) and the turn it queued. A 2xx with no turn — the assistant isn't
// running, so nothing was queued — is a refusal in the engine's words, never "started".
//
// NOTHING IS PERSISTED FROM HERE. The routes record the request and queue the turn; the
// turn stores the version once its questions are answered. So nothing this file says can
// claim a budget was imported.
//
// EVERY FUNCTION RETURNS, NEVER THROWS: `{ ok: true, ... }` or `{ ok: false, kind, code,
// status, message }`, and every refusal of a press says that nothing was recorded.

import { engineFetch } from "@/lib/engine-gate";

// The engine's ids: a budget id and a conversation id are opaque, short and never carry
// a path separator or a control character, so no path segment is built from anything
// else.
export const BUDGET_ID = /^[^\x00-\x1f\x7f/?#]{1,200}$/;
export const SESSION_ID = /^[A-Za-z0-9_.:-]{1,200}$/;
export const DOCUMENT_ID = /^[^\x00-\x1f\x7f/?#]{1,200}$/;
const TIMEOUT_MS = 15000;
// Import and Choose queue a turn the engine answers before it returns (vert_api
// inline_chat, up to 240 s): lib/engine-source.js AGENT_TURN_TIMEOUT_MS, kept as a copy
// here because this file is also drawn into the browser bundle (tests pin the two equal).
const TURN_TIMEOUT_MS = 280000;

const NOTHING_RECORDED = "Nothing was recorded.";
export const NOT_RUNNING = "Vert's assistant isn't running for this client, so the import wasn't started. Nothing was recorded.";
export const COULD_NOT_LIST = "Vert couldn't list the budgets just now. Nothing was changed.";

export function refused(code, message, status = 0) {
  return { ok: false, kind: "refused", code, status, message };
}

function unreachable(message) {
  return { ok: false, kind: "unreachable", code: "unreachable", status: 0, message };
}

function envelopeOf(status, body) {
  const envelope = body && body.error;
  const code = envelope && typeof envelope.code === "string" && /^[a-z][a-z0-9_]*$/.test(envelope.code) ? envelope.code : `http_${status}`;
  const said = envelope && typeof envelope.message === "string" && envelope.message.trim() ? envelope.message.trim() : "";
  return { code, said };
}

/** The engine's words for a refused press, always ending in what was not recorded. */
function pressRefusal(status, body) {
  const { code, said } = envelopeOf(status, body);
  let message;
  if (status === 404 && code === "session_not_found") message = `Vert couldn't find this conversation. ${NOTHING_RECORDED}`;
  else if (status === 404) message = `Vert doesn't have that budget. ${NOTHING_RECORDED}`;
  else if (status === 401 || status === 403) message = `Sign in again to import a budget. ${NOTHING_RECORDED}`;
  else if (status === 501) message = `Importing budgets isn't connected here yet. ${NOTHING_RECORDED}`;
  else if (said && (status === 400 || status === 409)) message = /nothing was/i.test(said) ? said : `${said} ${NOTHING_RECORDED}`;
  else message = `The import wasn't started (${code}). ${NOTHING_RECORDED}`;
  return refused(code, message, status);
}

/* ─────────────────────────────── the bodies ─────────────────────────────── */

/**
 * The body `POST /budgets/import` takes (the engine's BudgetImportRequest, which forbids
 * any other key), or a refusal before anything is sent. `source` is the engine's
 * `ImportSource`: "qbo", or "document" for an xlsx attached in the conversation.
 */
export function importBody(request) {
  const r = request && typeof request === "object" ? request : {};
  if (typeof r.sessionId !== "string" || !SESSION_ID.test(r.sessionId)) {
    return refused("no_session", `Open a conversation first: the import runs as a turn in it. ${NOTHING_RECORDED}`);
  }
  if (r.source !== "qbo" && r.source !== "document") return refused("invalid_request", `Vert imports a budget from the ledger or from an attached file. ${NOTHING_RECORDED}`);
  const body = { sessionId: r.sessionId, source: r.source };
  if (r.source === "document") {
    if (typeof r.documentId !== "string" || !DOCUMENT_ID.test(r.documentId)) return refused("invalid_request", `Attach the budget's .xlsx in this conversation first. ${NOTHING_RECORDED}`);
    body.documentId = r.documentId;
  }
  if (typeof r.sheet === "string" && r.sheet.trim()) body.sheet = r.sheet.trim().slice(0, 200);
  if (r.source === "qbo" && typeof r.qboId === "string" && r.qboId.trim()) body.qboId = r.qboId.trim().slice(0, 200);
  if (Number.isInteger(r.fy) && r.fy >= 2000 && r.fy <= 2100) body.fy = r.fy;
  return { ok: true, body };
}

/** The body `POST /budgets/{id}/choose` takes, or a refusal before anything is sent. */
export function chooseBody({ sessionId, budgetId, fy } = {}) {
  if (typeof sessionId !== "string" || !SESSION_ID.test(sessionId)) {
    return refused("no_session", `Open a conversation first: the choice is made as a turn in it. ${NOTHING_RECORDED}`);
  }
  if (typeof budgetId !== "string" || !BUDGET_ID.test(budgetId)) return refused("invalid_request", `That isn't a budget Vert has. ${NOTHING_RECORDED}`);
  if (!Number.isInteger(fy) || fy < 2000 || fy > 2100) return refused("invalid_request", `Vert couldn't tell which year this budget is for. ${NOTHING_RECORDED}`);
  return { ok: true, budgetId, body: { sessionId, fy } };
}

/* ─────────────────────────────── the answers ─────────────────────────────── */

/**
 * A press's answer, read back before it is reported. Started only when the engine names
 * the conversation AND the turn it queued; a 2xx without a turn is the engine saying the
 * assistant isn't running, in its own words.
 */
export function startedFrom(status, body) {
  if (status < 200 || status >= 300) return pressRefusal(status, body);
  const b = body && typeof body === "object" ? body : {};
  if (typeof b.sessionId !== "string" || !SESSION_ID.test(b.sessionId)) {
    return refused("bad_response", `Vert didn't say where the import runs. ${NOTHING_RECORDED}`, status);
  }
  if (typeof b.turnId !== "string" || !b.turnId || b.queued === false) {
    const said = typeof b.words === "string" && b.words.trim() ? b.words.trim() : "";
    return refused("not_queued", said ? (/nothing was/i.test(said) ? said : `${said}. ${NOTHING_RECORDED}`.replace(/\.\./g, ".")) : NOT_RUNNING, status);
  }
  return {
    ok: true,
    sessionId: b.sessionId,
    turnId: b.turnId,
    words: typeof b.words === "string" && b.words.trim() ? b.words.trim() : "Import started in this conversation",
  };
}

/** One budget as the sheet lists it: only the fields the sheet reads, typed. */
function budgetItem(b) {
  if (!b || typeof b !== "object" || typeof b.budgetId !== "string" || !BUDGET_ID.test(b.budgetId)) return null;
  const out = {
    budgetId: b.budgetId,
    name: typeof b.name === "string" ? b.name : "",
    fy: Number.isInteger(b.fy) ? b.fy : null,
    source: typeof b.source === "string" ? b.source : null,
    version: Number.isInteger(b.version) ? b.version : null,
    active: b.active !== false,
    budgetType: typeof b.budgetType === "string" ? b.budgetType : null,
    chosen: b.chosen === true,
    sessionId: typeof b.sessionId === "string" ? b.sessionId : null,
  };
  if (typeof b.declined === "string" && b.declined.trim()) out.declined = b.declined;
  if (typeof b.phasing === "string") out.phasing = b.phasing;
  return out;
}

/**
 * The ledger lookup, as the engine reported it: `found`, `none` or `unchecked` with its
 * reason. An answer that names none of the three is unread, never "none".
 */
function lookupOf(raw) {
  const l = raw && typeof raw === "object" ? raw : null;
  const outcome = l && ["found", "none", "unchecked"].includes(l.outcome) ? l.outcome : null;
  if (!outcome) return null;
  const out = { outcome };
  for (const k of ["key", "lookedFor", "where", "reason", "words"]) if (typeof l[k] === "string") out[k] = l[k];
  if (Number.isInteger(l.count)) out.count = l.count;
  return out;
}

/**
 * One of the ledger's own budgets (`ledgerBudgets`, GET /budgets): only the fields the
 * sheet reads, typed. `importedBudgetId` is the stored budget it matches, or null.
 * `declined` is the engine's sentence for one it lists and will not import (a Xero
 * tracking budget, engine budget_import.ledger_budget_rows), kept only when it says
 * something: the sheet shows it and offers that row nothing.
 */
function ledgerBudgetOf(l) {
  if (!l || typeof l !== "object" || typeof l.qboId !== "string" || !l.qboId.trim()) return null;
  const declined = typeof l.declined === "string" && l.declined.trim() ? { declined: l.declined } : {};
  return {
    ...declined,
    qboId: l.qboId,
    name: typeof l.name === "string" ? l.name : "",
    fy: Number.isInteger(l.fy) ? l.fy : null,
    active: l.active !== false,
    budgetType: typeof l.budgetType === "string" ? l.budgetType : null,
    phasing: typeof l.phasing === "string" ? l.phasing : null,
    importedBudgetId: typeof l.importedBudgetId === "string" && BUDGET_ID.test(l.importedBudgetId) ? l.importedBudgetId : null,
  };
}

/** `GET /budgets`'s answer. A list the engine didn't send is unread, never empty. */
export function listFrom(status, body) {
  if (status < 200 || status >= 300) {
    const { code } = envelopeOf(status, body);
    return { ok: false, kind: "refused", code, status, message: COULD_NOT_LIST };
  }
  if (!body || !Array.isArray(body.budgets)) return { ok: false, kind: "refused", code: "bad_response", status, message: COULD_NOT_LIST };
  const budgets = body.budgets.map(budgetItem).filter(Boolean);
  const ledger = lookupOf(body.lookups && body.lookups.ledger);
  // The ledger's own budgets, when the engine read its answer (F-BUD-fix1's need):
  // absent or null is unread (the sheet then says the count its rows can't back),
  // never an empty ledger.
  const ledgerBudgets = Array.isArray(body.ledgerBudgets) ? body.ledgerBudgets.map(ledgerBudgetOf).filter(Boolean) : null;
  return { ok: true, budgets, lookups: { ledger }, ledgerBudgets };
}

/** `GET /budgets/{id}`'s answer: the version and its tie-out, as the engine worded it. */
export function detailFrom(status, body, budgetId) {
  if (status < 200 || status >= 300) {
    const { code } = envelopeOf(status, body);
    return { ok: false, kind: "refused", code, status, message: status === 404 ? "Vert doesn't have that budget." : "Vert couldn't read that budget just now." };
  }
  const item = budgetItem(body);
  if (!item || item.budgetId !== budgetId) return { ok: false, kind: "refused", code: "bad_response", status, message: "Vert couldn't read that budget just now." };
  const t = body.tieOut && typeof body.tieOut === "object" ? body.tieOut : null;
  const tieOut =
    t && typeof t.words === "string" && t.words.trim()
      ? { words: t.words, equal: t.equal === true && t.measured !== false, rightSource: typeof t.rightSource === "string" ? t.rightSource : null }
      : null;
  return { ok: true, budget: { ...item, tieOut } };
}

/* ─────────────────────────────── the calls ─────────────────────────────── */

async function call(fetchImpl, url, init, timeoutMs = TIMEOUT_MS) {
  let response;
  try {
    response = await engineFetch(fetchImpl, url, { ...init, cache: "no-store", signal: AbortSignal.timeout(timeoutMs) });
  } catch (cause) {
    if (cause && typeof cause.digest === "string") throw cause; // Next's own control flow
    return { response: null };
  }
  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }
  return { response, body };
}

/** GET /budgets; `headers` carries the key, added on the server. */
export async function getBudgets({ base, headers = {}, fetchImpl = globalThis.fetch }) {
  const { response, body } = await call(fetchImpl, `${base}/budgets`, { method: "GET", headers: { ...headers, accept: "application/json" } });
  if (!response) return unreachable(COULD_NOT_LIST);
  return listFrom(response.status, body);
}

/** GET /budgets/{id}. */
export async function getBudgetDetail({ budgetId, base, headers = {}, fetchImpl = globalThis.fetch }) {
  if (typeof budgetId !== "string" || !BUDGET_ID.test(budgetId)) return refused("invalid_request", "That isn't a budget Vert has.");
  const { response, body } = await call(fetchImpl, `${base}/budgets/${encodeURIComponent(budgetId)}`, { method: "GET", headers: { ...headers, accept: "application/json" } });
  if (!response) return unreachable("Vert couldn't read that budget just now.");
  return detailFrom(response.status, body, budgetId);
}

/** POST /budgets/import; `headers` carries the key and the actor. */
export async function postImport({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const built = importBody(request);
  if (!built.ok) return built;
  const { response, body } = await call(fetchImpl, `${base}/budgets/import`, {
    method: "POST",
    headers: { ...headers, "content-type": "application/json", accept: "application/json" },
    body: JSON.stringify(built.body),
  }, TURN_TIMEOUT_MS);
  if (!response) return unreachable(`The import didn't reach Vert. ${NOTHING_RECORDED}`);
  return startedFrom(response.status, body);
}

/** POST /budgets/{id}/choose. */
export async function postChoose({ request, base, headers = {}, fetchImpl = globalThis.fetch }) {
  const built = chooseBody(request);
  if (!built.ok) return built;
  const { response, body } = await call(fetchImpl, `${base}/budgets/${encodeURIComponent(built.budgetId)}/choose`, {
    method: "POST",
    headers: { ...headers, "content-type": "application/json", accept: "application/json" },
    body: JSON.stringify(built.body),
  }, TURN_TIMEOUT_MS);
  if (!response) return unreachable(`The choice didn't reach Vert. ${NOTHING_RECORDED}`);
  return startedFrom(response.status, body);
}

/* ───────────────────── the import's open questions (Needs you, #10) ───────────────────── */

/** The template the engine runs an import as (vert_engine templates/budget_import.py). */
export const IMPORT_TEMPLATE = "budget_import";

/**
 * The import conversations of `period` that are waiting on a person's answer, from the
 * conversation list and each one's events: `[{sessionId, title, questions: [{questionId,
 * title, figures}]}]`. A conversation is listed only when it holds an open question —
 * the engine's `needsYou` flag alone is a state word, and the row has to say WHAT is
 * asked. `openQuestions(events)` is the month's own reader (components/month/model.js
 * openItems), passed in so this stays one rule.
 */
export function importQuestionsFrom(sessions, eventsBySession, openQuestions) {
  const out = [];
  for (const s of Array.isArray(sessions) ? sessions : []) {
    if (!s || s.template !== IMPORT_TEMPLATE || typeof s.sessionId !== "string" || !SESSION_ID.test(s.sessionId)) continue;
    const events = eventsBySession && eventsBySession[s.sessionId];
    if (!Array.isArray(events)) continue;
    const questions = openQuestions(events)
      .filter((i) => i && i.type === "question" && i.question && i.question.questionId != null)
      .map((i) => ({ questionId: String(i.question.questionId), title: i.question.title || "", figures: i.question.figures || {} }));
    if (!questions.length) continue;
    out.push({ sessionId: s.sessionId, title: typeof s.title === "string" && s.title.trim() ? s.title : "Import budget", questions });
  }
  return out;
}

/** The anchor the thread gives a question card, and the href that opens a conversation at it. */
export function questionAnchor(questionId) {
  return `question-${String(questionId).replace(/[^A-Za-z0-9_-]/g, "_")}`;
}

export function questionHref(sessionId, questionId) {
  return `/chat/${encodeURIComponent(sessionId)}#${questionAnchor(questionId)}`;
}
