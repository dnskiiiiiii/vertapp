// app/not-found.js — AN ADDRESS THAT IS NOT HERE
// ==============================================================================
// Inside the shell, so the sidebar is still the way on (apple-design §16: never trap the
// person). Design-fix-2 DA2-076: the muted mark, a title-2 heading and one line in the
// page column, a secondary "Go to Month-end", then up to three recent conversations
// (components/shell/NotFoundState.js). Old addresses redirect (next.config.mjs), so
// reaching this means a mistyped or retired link, not a moved screen.

import NotFoundState from "@/components/shell/NotFoundState";

export const metadata = { title: "Not found · Vert" };

export default function NotFound() {
  return <NotFoundState kind="page" />;
}
