// app/loading.js — THE SHAPE OF MONTH-END, WHILE IT COMES
// ==============================================================================
// Spec §11.4; audit UI-016; design-fix-2 DA2-030. Every route segment without its own
// loading.js shows this skeleton the moment a navigation starts, inside the shell. It was
// one bar and four lines, which looked like nothing that ever arrives, and Home then
// jumped into place. It is now Home's own shape on the page column: the 28 px title and
// its line, the 6 px bar, the 64 px ask box, the section head and the decision card's
// outline, so what lands lands where the placeholder stood. Blocks pulse in opacity once
// per 1.2 s (the Skeleton primitive), still under reduced motion; no shimmer, no spinner.

import { SkeletonBlock } from "@/components/ui/marks";
import EarlyAsk from "@/components/month/EarlyAsk";

export default function Loading() {
  return (
    <section className="page route-loading route-loading-home" role="status" aria-live="polite" aria-busy="true">
      <span className="sr-only">Loading this page</span>
      <div className="sk-stack sk-head">
        <SkeletonBlock width="10rem" height="1.75rem" radius="var(--r-sm)" />
        <SkeletonBlock width="14rem" height="0.875rem" />
      </div>
      <SkeletonBlock width="100%" height="0.375rem" radius="var(--r-bar)" />
      {/* A real box, not a block shaped like one (D40): what is typed is kept. */}
      <EarlyAsk />
      <div className="sk-stack">
        <SkeletonBlock width="6rem" height="0.875rem" />
        <div className="sk-card" aria-hidden="true">
          <SkeletonBlock width="60%" height="1.125rem" />
          <SkeletonBlock width="40%" height="0.875rem" />
          <SkeletonBlock width="100%" height="2.5rem" radius="var(--r-sm)" />
          <SkeletonBlock width="100%" height="2.5rem" radius="var(--r-sm)" />
        </div>
      </div>
    </section>
  );
}
