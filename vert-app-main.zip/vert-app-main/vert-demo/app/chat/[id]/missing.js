// app/chat/[id]/missing.js — A TASK CONVERSATION THIS CLIENT HASN'T OPENED
// ==============================================================================
// Verify pass 4, stress-adversarial F3 and e2e-close F9 (S-E2E-2).
//
// A task conversation's id is `<period>-<template>` ("2026-07-approve_entries"), the SAME
// id on every client. When it was not found under the client on screen, the page sent a
// firm person to the client search, which walked the firm and switched to the first
// client that held that id: with Stress Unicode chosen, the link landed on Stresslab's
// conversation and rewrote the client cookie, with no word said. And a link that named
// its client for a task not yet started came back "looked for" and was refused as
// "another client's conversation", though Month-end's row opens it in one press.
//
// So a task-shaped id is never searched for across clients. Under the client on screen
// it is one of two facts, said in words, with nothing switched:
//
//   not_started   the month lists the task and no conversation is open for it yet:
//                 "Open it" starts it the way Month-end's row does.
//   not_listed    the month does not list the task for this client.
//
// A free conversation's id (a random key) names one client only, so following it to
// the client that holds it is still the client search's job. Pure.

const TASK_ID = /^(\d{4}-(?:0[1-9]|1[0-2]))-([a-z][a-z0-9_]{1,63})$/;

/** `{ period, template }` for a task conversation's id, or null. Pure. */
export function taskOfId(id) {
  const m = typeof id === "string" ? TASK_ID.exec(id) : null;
  return m ? { period: m[1], template: m[2] } : null;
}

/**
 * What the page says for a task id not found under this client, from the month the
 * engine read (`GET /close/{period}`): `{ kind: "not_started", title, period, template }`,
 * `{ kind: "not_listed", period, template }`, or `{ kind: "unread", period, template }`
 * when the month could not be read (then nothing is offered). Pure.
 */
export function missingTask(task, monthRead) {
  if (!task) return null;
  if (!monthRead || !monthRead.ok || !monthRead.month || !Array.isArray(monthRead.month.tasks)) return { kind: "unread", ...task };
  const listed = monthRead.month.tasks.find((t) => t && t.template === task.template);
  if (!listed) return { kind: "not_listed", ...task };
  const title = typeof listed.title === "string" && listed.title.trim() ? listed.title.trim() : null;
  return { kind: "not_started", title, ...task };
}

/** The words a template id reads as when the month gives no title: "approve journal entries". */
export function templateWords(template) {
  return String(template || "").replace(/_/g, " ").trim();
}
