"use client";

// app/chat/[id]/error.js — A FAILURE KEEPS THE SHELL
// ==============================================================================
// UI-002: the sidebar and the way back stay on screen when a conversation fails to
// render. What happened, what was recorded (nothing, by this page), and Try again.

import Link from "next/link";

import { IconCaretLeft } from "@/components/ui/icons";
export default function ConversationError({ reset }) {
  return (
    <div className="chat bleed chat-unavailable">
      <div className="chat-main">
        <p className="chat-problem-head" role="alert">
          This conversation couldn't be shown. Nothing was changed.
        </p>
        <p>
          <button type="button" className="chat-quiet" onClick={() => reset()}>
            Try again
          </button>{" "}
          <Link href="/"><IconCaretLeft className="caret-leading" />Back to Month-end</Link>
        </p>
      </div>
    </div>
  );
}
