// app/chat/[id]/missing-read.js — THE ONE MONTH READ, ONLY WHEN A TASK ISN'T THERE
// ==============================================================================
// The conversation page never awaits the month on its way to a conversation (eval C4,
// tests/chat-opening.test.js): a found conversation draws from its own read. Only the
// 404 of a task's id reads the month, to say whether this client has the task at all
// (./missing.js). Nothing else here.

import { readMonth } from "@/lib/agent/client";
import { missingTask } from "./missing";

/** What to say for a task id not found under the client on screen (see ./missing.js). */
export async function readMissingTask(task) {
  return missingTask(task, await readMonth(task.period));
}
