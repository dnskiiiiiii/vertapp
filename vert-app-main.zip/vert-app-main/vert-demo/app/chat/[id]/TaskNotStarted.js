"use client";

// app/chat/[id]/TaskNotStarted.js — SAY IT ISN'T STARTED, AND OFFER TO OPEN IT
// ==============================================================================
// See ./missing.js. "Open it" is Month-end's row press (startConversation with the
// period and template): it writes only the conversation, under the client on screen,
// and then opens it. Nothing switches client.

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/Button";
import { IconCaretLeft } from "@/components/ui/icons";
import { startConversation } from "@/lib/agent/actions";
import { monthName } from "@/lib/period";
import { templateWords } from "./missing";

export default function TaskNotStarted({ missing, clientName = null }) {
  const router = useRouter();
  const [state, setState] = useState({ busy: false, error: null });
  const who = clientName || "This client";
  const month = `${monthName(missing.period)} ${missing.period.slice(0, 4)}`;
  const task = missing.title || templateWords(missing.template);
  async function open() {
    setState({ busy: true, error: null });
    const result = await startConversation({ period: missing.period, template: missing.template });
    if (result && result.ok && typeof result.sessionId === "string") {
      router.replace(`/chat/${encodeURIComponent(result.sessionId)}`);
      return;
    }
    setState({ busy: false, error: (result && result.message) || "It didn't open. Nothing was changed." });
  }
  return (
    <div className="chat bleed chat-unavailable" data-missing-task={missing.kind}>
      <div className="chat-main">
        {missing.kind === "not_started" ? (
          <>
            <p className="chat-problem-head" role="status">
              {`${who} hasn't started ${task} for ${month} yet.`}
            </p>
            <p>
              <Button variant="secondary" busy={state.busy} busyLabel="Opening…" onClick={open} data-open-task="">
                {`Open ${task}`}
              </Button>
            </p>
            {state.error ? <p className="t-footnote" role="alert">{state.error}</p> : null}
          </>
        ) : missing.kind === "not_listed" ? (
          <p className="chat-problem-head" role="status">
            {`${who} has no ${task} in ${month}. Nothing was opened or changed.`}
          </p>
        ) : (
          <p className="chat-problem-head" role="alert">
            {`Vert couldn't read ${month} for ${who === "This client" ? "this client" : who} just now, so it can't say whether ${task} is on its list. Nothing was opened or changed.`}
          </p>
        )}
        <p>
          <Link href="/"><IconCaretLeft className="caret-leading" />Back to Month-end</Link>
        </p>
      </div>
    </div>
  );
}
