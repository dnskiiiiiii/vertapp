// app/chat/[id] — ONE CONVERSATION
// ==============================================================================
// Spec §3.3. The server reads the conversation and its events (lib/agent/client.js),
// the month's sources for the context sheet, and the ledger's name for `{{ledger}}`,
// then hands them to the client view, which follows the stream from the last event
// drawn here.
//
// A conversation that does not exist is a 404. A conversation that could not be READ
// is not: it keeps the shell and says so in a sentence, with the way back, because an
// unreachable service and a missing conversation are different facts (spec §4.2 row 8;
// UI-002).
//
// In the static build the conversations are recordings from the export, listed for
// prerendering, and drawn behind the replay band.

import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { AUTH_REQUIRED, chosenClient, readSession } from "@/lib/session";
import { chatClientDecision, linkClientPath } from "@/app/clients/open/resolve";
import { SetVisibleMonth } from "@/components/shell/MonthControl";
import ClientInAddress from "@/components/shell/ClientInAddress";
import { LIVE, recordedConversationIds } from "@/lib/agent/client";
import { taskOfId } from "./missing";
import { readMissingTask } from "./missing-read";
import TaskNotStarted from "./TaskNotStarted";
import { readConversationPage } from "@/lib/agent/conversation-page";
import ConversationView from "@/components/chat/ConversationView";
import { documentsStatus } from "@/lib/documents";

import { IconCaretLeft } from "@/components/ui/icons";
export const metadata = { title: "Conversation · Vert" };

// THE FUNCTION MAY RUN AS LONG AS VERT'S ANSWER TAKES (p0, 23 Oct 2026). A Server
// Action runs in its page's function, and this page's (a message, an answer, a plan
// press, a budget Import or Choose)
// waits on a model turn the engine answers inside its request (up to 240 s; the
// engine-side client waits AGENT_TURN_TIMEOUT_MS, lib/engine-source.js). Vercel stops a
// function at its maxDuration, so this one declares the most the plan allows.
export const maxDuration = 300;

// PRERENDER LIST IN STATIC MODE ONLY. A route that exports `generateStaticParams` is
// rendered on demand as a STATIC page for any id not in the list, and reading the
// session cookie there throws DYNAMIC_SERVER_USAGE: in API mode the list is empty, so
// every /chat/<id> was a 500. With no export the route is dynamic, as a signed-in
// conversation must be; the static build still prerenders its recordings.
async function recordedParams() {
  return recordedConversationIds().map((id) => ({ id }));
}
export const generateStaticParams = LIVE ? undefined : recordedParams;

export default async function ConversationPage({ params, searchParams }) {
  const { id } = await params;
  // Asked only with a service: the static build reads no query and stays prerendered.
  const query = AUTH_REQUIRED ? (searchParams && (await searchParams)) || {} : {};
  const session = AUTH_REQUIRED ? await readSession() : null;
  const inFirm = Boolean(session && session.person && session.firm);
  // THE CLIENT ON SCREEN (verify pass 2 S-E2E-3). A task conversation's id is the same
  // on every client, so the link names its client and that is decided before anything
  // is read: another client's link switches (proven by the client search) or is
  // refused, and never shows this client's thread under it.
  const current = session ? (await chosenClient(session)) || session.tenant || null : null;
  const decision = AUTH_REQUIRED ? chatClientDecision({ wanted: query.client, current, inFirm, looked: query.looked === "clients" }) : "open";
  if (decision === "switch") redirect(linkClientPath(id, query.client));
  if (decision === "refuse") {
    return (
      <div className="chat bleed chat-unavailable">
        <div className="chat-main">
          <p className="chat-problem-head" role="alert">
            This link is to another client&rsquo;s conversation, and Vert can&rsquo;t open that client here. Nothing was opened or changed.
          </p>
          <p>
            <Link href="/"><IconCaretLeft className="caret-leading" />Back to Month-end</Link>
          </p>
        </div>
      </div>
    );
  }
  // The month is not awaited here: see lib/agent/conversation-page.js (eval C4).
  // Whether the engine reads files is asked here, on the server, beside the conversation:
  // asked by the composer from the browser it was a server action, a POST on every view
  // (smoke test, 23 Oct; tests/p0-quiet-page-load.test.js). Any doubt is off.
  const [convo, documents] = await Promise.all([
    readConversationPage(id),
    AUTH_REQUIRED ? documentsStatus().catch(() => null) : Promise.resolve(null),
  ]);
  if (!convo.ok) {
    // Not there (a 404, or an address that names no conversation): the not-found page,
    // "This conversation doesn't exist", never "couldn't be read just now" (walk 5).
    if (convo.missing) {
      // A LINK INTO ANOTHER OF THE FIRM'S CLIENTS (W0c CO-22, wired in verify pass 1 F-4).
      // The conversation is not under the client this browser is on: a firm person's
      // link goes once to the client search (app/clients/open), which switches to the
      // client holding it, or comes back `?looked=clients` and this page says not found.
      // A TASK'S ID IS THE SAME ON EVERY CLIENT (verify pass 4, F3 / S-E2E-2): it is
      // never searched for across the firm, which switched to whichever client held it.
      // Under the client on screen it is "not started yet" (with Open) or "not on this
      // client's list", said in words, nothing switched (./missing.js).
      const task = taskOfId(id);
      if (task) return <TaskNotStarted missing={await readMissingTask(task)} />;
      if (inFirm && query.looked !== "clients") redirect(`/clients/open?conversation=${encodeURIComponent(id)}`);
      notFound();
    }
    return (
      <div className="chat bleed chat-unavailable">
        <div className="chat-main">
          <p className="chat-problem-head" role="alert">
            {convo.sentence || "This conversation couldn't be read just now. Nothing was changed."}
          </p>
          <p>
            <Link href="/"><IconCaretLeft className="caret-leading" />Back to Month-end</Link>
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* The sidebar's month follows the open conversation (W09, sidebar month). */}
      {/* A task conversation only: a free question about another month leaves yours (D58). */}
      <SetVisibleMonth period={convo.session && convo.session.template ? convo.session.period : null} />
      {/* The address names the client on screen, so a copied link opens these books. */}
      {AUTH_REQUIRED && current ? <ClientInAddress client={current} /> : null}
      <ConversationView
      sessionId={id}
      session={convo.session}
      events={convo.events}
      replay={convo.replay}
      ledgerName={convo.ledgerName}
      sources={convo.sources}
      documentsEnabled={Boolean(documents && documents.ok && documents.enabled === true)}
      />
    </>
  );
}
