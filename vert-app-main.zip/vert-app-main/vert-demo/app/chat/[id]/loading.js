// app/chat/[id]/loading.js — THE CONVERSATION'S SHAPE WHILE IT LOADS
// ==============================================================================
// Every route segment has a skeleton, so a press on a conversation moves at once
// (spec §11.4; UI-016): the header, a few lines of thread and the composer, in place.
//
// A conversation the ask box just started is not a skeleton: its first events came
// back with the request that created it, and OpeningView draws them at once (eval C4:
// the reply within 2 s of Enter; lib/agent/opening.js).

import { SkeletonBlock } from "@/components/ui";
import OpeningView from "@/components/chat/OpeningView";

export default function ConversationLoading() {
  return <OpeningView>{skeleton()}</OpeningView>;
}

// THE CONVERSATION'S OWN SHAPE (design-fix-2 DA2-030): the head (back, title, tools),
// two turns (a question on the right, Vert's answer with its identity row on the left)
// and the composer at the foot, so the thread lands where its placeholder stood.
function skeleton() {
  return (
    <div className="chat bleed route-loading-chat" aria-busy="true">
      <div className="chat-main">
        <div className="chat-head sk-chat-head" aria-hidden="true">
          <SkeletonBlock width="1.75rem" height="1.75rem" radius="var(--r-sm)" />
          <SkeletonBlock width="14rem" height="1.125rem" />
        </div>
        <div className="chat-scroll sk-thread" aria-hidden="true">
          <div className="sk-turn sk-turn-you">
            <SkeletonBlock width="18rem" height="2.5rem" radius="var(--r-card)" />
          </div>
          <div className="sk-turn">
            <div className="sk-identity">
              <SkeletonBlock width="1.25rem" height="1.25rem" radius="50%" />
              <SkeletonBlock width="3rem" height="0.75rem" />
            </div>
            <SkeletonBlock width="85%" height="1rem" />
            <SkeletonBlock width="70%" height="1rem" />
            <SkeletonBlock width="100%" height="8rem" radius="var(--r-card)" />
          </div>
        </div>
        <div className="sk-composer" aria-hidden="true">
          <SkeletonBlock width="100%" height="3.5rem" radius="var(--r-card)" />
        </div>
        <p className="chat-visually-hidden" role="status">Loading the conversation…</p>
      </div>
    </div>
  );
}
