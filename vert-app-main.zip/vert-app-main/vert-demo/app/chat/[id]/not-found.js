// app/chat/[id]/not-found.js — A CONVERSATION THAT ISN'T THERE
// ==============================================================================
// Design-fix-2 DA2-076. app/chat/[id]/page.js calls notFound() when the service answers
// 404 for the conversation; this says that, rather than the site-wide "nothing at this
// address", and offers the way on: Month-end and the recent conversations.

import NotFoundState from "@/components/shell/NotFoundState";

export const metadata = { title: "Conversation not found · Vert" };

export default function ConversationNotFound() {
  return <NotFoundState kind="conversation" />;
}
