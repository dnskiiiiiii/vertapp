// app/chat/layout.js — THE CONVERSATION ROUTES' OWN STYLESHEET
// ==============================================================================
// Build plan §4.4 FP 2: the result pane's layout (beside the chat at 1024 px and wider,
// a full sheet below) and the table it draws live in app/chat/pane.css, loaded here so
// they arrive after the app's own sheets (app/globals.css) and only where a
// conversation is drawn. It adds no markup: the conversation renders inside the app
// shell exactly as before.

import "./pane.css";

export default function ChatLayout({ children }) {
  return children;
}
