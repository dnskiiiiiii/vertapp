// app/reconciliation/bank/cash-coding/loading.js — THE GRID'S SHAPE, WHILE THE LINES COME
// ==============================================================================
// Staging check CC-4 (3 Nov 2026): the view took 8 to 32 s to read, and until it did the
// page held the shape of Month-end (app/loading.js) or nothing. This is Cash coding's own
// shape from the first frame: the title, Reconcile | Cash coding, the switcher's chips,
// the toolbar, and the grid with Xero's columns over rows of placeholders, so what lands
// lands where the placeholder stood. Blocks pulse as the Skeleton primitive does.

import { SkeletonBlock } from "@/components/ui/marks";

const HEADS = ["Date", "Payee", "Description", "Account", "Tax rate", "Spent", "Received"];
const ROWS = [0, 1, 2, 3, 4, 5];

export default function CashCodingLoading() {
  return (
    <section className="page cc-page route-loading" role="status" aria-live="polite" aria-busy="true" data-cc-loading="">
      <span className="sr-only">Loading the lines to code</span>
      <div className="sk-stack sk-head">
        <SkeletonBlock width="16rem" height="1.75rem" radius="var(--r-sm)" />
        <SkeletonBlock width="7rem" height="0.875rem" />
      </div>
      <nav className="tabs-ink cc-tabs" aria-hidden="true">
        <span className="tab-ink">Reconcile</span>
        <span className="tab-ink" aria-current="page">
          Cash coding
        </span>
      </nav>
      <div className="cc-accounts" aria-hidden="true">
        <SkeletonBlock width="14rem" height="2rem" radius="var(--r-pill, 999px)" />
      </div>
      <div className="cc-toolbar" aria-hidden="true">
        <SkeletonBlock width="18rem" height="1.75rem" radius="var(--r-sm)" />
        <SkeletonBlock width="8rem" height="2.25rem" radius="var(--r-sm)" />
      </div>
      <table className="cc-grid" aria-hidden="true">
        <thead>
          <tr>
            <th scope="col" className="cc-col-check" />
            {HEADS.map((h) => (
              <th key={h} scope="col" className={h === "Spent" || h === "Received" ? "num-col" : undefined}>
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {ROWS.map((i) => (
            <tr key={i} className="cc-row">
              <td className="cc-col-check">
                <SkeletonBlock width="1rem" height="1rem" />
              </td>
              {HEADS.map((h) => (
                <td key={h}>
                  <SkeletonBlock width={h === "Account" || h === "Description" ? "90%" : "70%"} height="0.875rem" />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
