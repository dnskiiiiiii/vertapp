// app/reconciliation/bank/cash-coding — ONE BANK ACCOUNT'S UNCODED LINES, CODED TOGETHER
// ==============================================================================
// Xero's Cash coding (founder and co-founder, 3 Nov 2026; w25 contract v1): the lines
// for one account and month in a grid, each with Vert's proposed account and tax rate,
// ticked and coded together. The chat's "cash code" answer links here, and the bank
// reconciliation sits beside it as "Reconcile | Cash coding".
//
//   ?account=<statement account id>&period=YYYY-MM
//
// `account` may be left out: the engine then answers the one account with lines, or
// asks for one to be picked. `period` names the month; without it, the month
// Month-end shows, by the sidebar's rule (as app/statements/page.js).
//
// READ HERE, ON THE SERVER, WITH THE KEY (lib/cash-coding.js). A read that failed is
// said in words, never drawn as an empty month.

import CashCodingScreen from "@/components/cash-coding/CashCodingScreen";
import { monthAsked } from "@/components/month/month-reads";
import { readCashCoding } from "@/lib/cash-coding";
import { busiestAccount } from "@/lib/cash-coding-model";
import { closeMonthOf, isPeriod, shownMonth } from "@/lib/period";
import { AUTH_REQUIRED, sessionGet, visibleMonth } from "@/lib/session";

export const metadata = { title: "Cash coding · Vert" };
export const dynamic = "force-dynamic";
// "Code N lines" is a route, but the read waits on the engine's Xero reads (cached 5
// minutes on its side), so the page may take a while the first time.
export const maxDuration = 60;

/** The month Month-end shows, by the sidebar's rule, or null when none can be named. */
async function shownPeriod() {
  const [read, chosen] = await Promise.all([sessionGet("/close/periods"), visibleMonth()]);
  const body = read.ok ? read.body : null;
  const list = Array.isArray(body) ? body : body && Array.isArray(body.periods) ? body.periods : null;
  if (!list) return isPeriod(chosen) ? chosen : null;
  return shownMonth(list.map((m) => m && m.period).filter(isPeriod), chosen, closeMonthOf(new Date()));
}

export default async function CashCodingPage({ searchParams }) {
  const query = (searchParams && (await searchParams)) || {};
  const raw = Array.isArray(query.account) ? query.account[0] : query.account;
  const account = typeof raw === "string" && raw.trim() ? raw.trim() : null;
  const period = monthAsked(query) || (AUTH_REQUIRED ? await shownPeriod() : null);
  if (!period) {
    return <CashCodingScreen initial={{ ok: false, message: "Vert couldn't tell which month to show. Open Cash coding from Month-end." }} />;
  }
  const first = await readCashCoding({ account, period });
  // STRAIGHT TO THE LINES (founder, 8 Nov 2026: fewer clicks). With several accounts and
  // none named, the engine asks for one to be picked; the page opens the one with the most
  // lines instead, and the switcher above the grid still reaches the others.
  const busiest = !account && first.ok ? busiestAccount(first.body) : null;
  const read = busiest ? await readCashCoding({ account: busiest, period }) : first;
  return <CashCodingScreen initial={read.ok ? read : first} period={period} />;
}
