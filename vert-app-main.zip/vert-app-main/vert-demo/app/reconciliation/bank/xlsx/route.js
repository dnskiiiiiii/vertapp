// The bank reconciliation as an Excel workbook (GET /reconciliations/bank.xlsx),
// with the same query the on-screen reconciliation used, passed through unchanged.
import { passThroughDownload } from "@/lib/api-download";

export const dynamic = "force-dynamic";

const ALLOWED = ["account", "as_at", "gl_account", "books_start", "closing_balance", "closing_balance_source", "currency"];

export async function GET(request) {
  const incoming = new URL(request.url).searchParams;
  const query = new URLSearchParams();
  for (const k of ALLOWED) if (incoming.get(k)) query.set(k, incoming.get(k));
  return passThroughDownload(`/reconciliations/bank.xlsx?${query}`);
}
