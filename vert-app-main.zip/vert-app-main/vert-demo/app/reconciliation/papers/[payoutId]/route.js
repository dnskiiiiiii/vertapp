// app/reconciliation/papers/[payoutId]/route.js — THE WORKING PAPER, AS A FILE
// ==============================================================================
// A Route Handler and not a page, because what this returns is a DOCUMENT rather
// than a screen. It carries no app shell, no navigation and no session chrome: the
// reader it is written for has no login, and a working paper wrapped in a product's
// sidebar is a screenshot of an app, not evidence.
//
// It is served over the signed-in session like every other read, because a working
// paper contains a customer's books. `readCloseData()` reads the caller's own
// credential out of this request's cookie (lib/engine-server.js → lib/session.js),
// so an expired session gets the API's 401 as a failure and not somebody else's
// close. Nothing about the artefact being handed onwards afterwards changes who is
// allowed to produce it.
//
// ONE URL, TWO DISPOSITIONS. `?download=1` sets `attachment` and names the file;
// without it the browser renders the document in place, which is the preview. There
// is deliberately no separate preview route: a preview that is a different code path
// from the artefact is a preview that can disagree with it, and this is the one
// document in the product where that would be a lie in an audit file.
//
// THE FAILURE PATH RETURNS A DOCUMENT TOO. An unreachable API here must not be a
// blank page or a Next error digest — somebody is trying to produce evidence and
// needs to know why they did not get it. It answers 502 with the same self-contained
// HTML shell carrying the reason and the URL that was tried.

import { readCloseData } from "@/lib/engine-server";
import { paperPeriod, workingPaper, workingPaperFilename } from "@/lib/working-paper";
import { workingPaperHtml } from "@/lib/working-paper-html";
import { visibleMonth } from "@/lib/session";


function documentResponse(html, { status = 200, filename = null } = {}) {
  const headers = {
    "content-type": "text/html; charset=utf-8",
    // Never cached. A working paper is produced from the close as it stands at the
    // moment it is asked for, and a stale one is a document asserting a sign-off
    // that may since have been withdrawn.
    "cache-control": "no-store",
    // The document is self-contained by construction; this is the same statement
    // made to the browser, so a file that grew a remote reference fails visibly in
    // the console rather than silently depending on a network the auditor's machine
    // may not have.
    "content-security-policy": "default-src 'none'; style-src 'unsafe-inline'; img-src data:",
    "x-content-type-options": "nosniff",
  };
  if (filename) headers["content-disposition"] = `attachment; filename="${filename}"`;
  return new Response(html, { status, headers });
}

export async function GET(request, { params }) {
  const { payoutId } = await params;
  const download = new URL(request.url).searchParams.get("download") === "1";

  const { engine, failure } = await readCloseData();

  if (failure) {
    return documentResponse(
      workingPaperHtml({
        // ONE PLAIN SENTENCE, NO ADDRESS. This used to print the API's URL and the data
        // source's own message — written for whoever runs the service — into a file a
        // client downloads (eval r1, rubric C7). readCloseData has already logged the
        // whole failure server-side, which is where an operator looks.
        missing:
          "Vert couldn't make this working paper just now, because this month's figures " +
          "didn't arrive. Nothing partial was written: a working paper assembled from " +
          "figures that did not all arrive would be evidence of the wrong thing. Try again " +
          "in a moment.",
      }),
      { status: 502 }
    );
  }

  const period = paperPeriod(engine, payoutId, await visibleMonth());
  const paper = workingPaper(period && period !== engine.period ? { ...engine, period } : engine, payoutId);
  return documentResponse(workingPaperHtml(paper), {
    status: paper.missing ? 404 : 200,
    // A document that could not be produced is not offered as a download. Saving a
    // 404 to disk under an audit-file name is how an empty page ends up filed.
    filename: !paper.missing && download ? workingPaperFilename(payoutId) : null,
  });
}
