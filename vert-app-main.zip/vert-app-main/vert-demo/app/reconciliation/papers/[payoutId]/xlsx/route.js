// The payout working paper as a formula-backed Excel workbook, built by the engine
// (GET /workpapers/payouts/{id}.xlsx) and passed through unchanged.
import { passThroughDownload } from "@/lib/api-download";

export const dynamic = "force-dynamic";

export async function GET(_request, { params }) {
  const { payoutId } = await params;
  return passThroughDownload(`/workpapers/payouts/${encodeURIComponent(payoutId)}.xlsx`);
}
