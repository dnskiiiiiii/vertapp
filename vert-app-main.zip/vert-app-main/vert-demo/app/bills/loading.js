// app/bills/loading.js — the shape of the inbox while it comes. Static blocks, no shimmer.

import { Skeleton } from "@/components/ui/marks";

export default function BillsLoading() {
  return (
    <section className="route-state route-loading bills">
      <Skeleton lines={6} label="Loading bills and invoices" />
    </section>
  );
}
