// app/bills/[id] — ONE BILL OR INVOICE'S REVIEW, THE SCHEDULED SHEET'S "REVIEW" TARGET
// ==============================================================================
// research/2026-10-27-w3-build/scheduled-spec.md: Bills & invoices is no longer a module
// (/bills is redirected to /scheduled?task=bills), and each item's review stays here,
// at /bills/<id>. The review is the one it always was (components/bills/BillReview.js):
// the fields beside the document, and Approve, which sends a DRAFT to Xero only on the
// person's press. Back goes to the Bills & invoices sheet.
//
// The item and the Xero connection are read here, on the server, with the key
// (lib/bills.js). A read that failed is drawn as that, never as an empty review.

import BillReviewPage from "@/components/bills/BillReviewPage";
import { getBill, listBills } from "@/lib/bills";
import { isItemId } from "@/lib/bills-model";

export const metadata = { title: "Review · Vert" };
export const maxDuration = 300;

export default async function BillPage({ params }) {
  const { id } = await params;
  const itemId = typeof id === "string" && isItemId(id) ? id : null;
  const [one, list] = await Promise.all([itemId ? getBill(itemId) : Promise.resolve(null), listBills({ status: null })]);
  return <BillReviewPage item={one && one.ok ? one.item : null} xero={list && list.ok ? list.xero : null} failure={one && !one.ok ? one : null} />;
}
