// app/login/page.js — the screen a bookkeeper meets before anything else.
// ==============================================================================
// Spec §3.1; audit UI-052, UI-074. At most 30 words on the screen (it had 154), one
// field, one filled button.
//
// THE FIRST BRAND MOMENT (founder decision D5; design-fix-2 DA2-021, DA2-079). A quiet
// centred lockup on the desk, with no card box: the 40 px navy mark over "Vert" in
// Archivo, the title (title-2), one value line, the field on paper, the full-width Sign in,
// and Privacy and Terms in captions at the foot. The column is TOP-ANCHORED, at
// max(14vh, 4rem), and the field reserves one line for its error, so nothing on the screen
// moves when a code is refused (it used to jump 20 px as the centred card grew).
//
// It renders OUTSIDE the app shell: no sidebar, no badge, no conversations. That is not
// a styling choice. Every one of those reads a figure off the close, and there is no
// close to read yet — the request has no credential, so the API has served nothing and
// would refuse to. A sign-in screen framed by a sidebar saying "29 decisions need you"
// would be showing somebody the previous client's number before asking who they are.
// app/layout.js draws the shell only when a session exists.
//
// WHY A CODE IN A BOX AND NOT AN EMAIL AND PASSWORD. The identity this product has is
// key-based: vert_engine/tenancy stores scrypt-hashed keys, scoped to a tenant,
// revocable, with a documented rotation path. A bookkeeper knows it as their "Vert
// access code"; the key's technical prefix is never shown or asked for, and the field
// takes the whole code as pasted. A code identifies a PRACTICE, not a person, which is
// why the actor on an approval is recorded separately (lib/acting-as.js). Email with a
// magic link is a founder decision still open; codes stay for integrations either way.
//
// "Where do I find it?" holds the facts a person without a code needs — who issues
// one, that there is no sign-up, that a lost one is replaced rather than re-sent — one
// press down, so they do not count against the 30 words everyone else reads.

import Link from "next/link";

import SignInForm from "@/components/auth/SignInForm";
import { SIGN_IN, sessionEndedSentence } from "@/components/auth/copy";
import { Wordmark } from "@/components/shell/icons";
import SkipLink from "@/components/shell/SkipLink";
import { Disclosure, Notice } from "@/components/ui";
import { AUTH_REQUIRED, REJECTED, sessionState } from "@/lib/session";
import { safeNext } from "@/lib/return-path";

import "./login.css";

import { IconCaretRight } from "@/components/ui/icons";
export const metadata = {
  title: "Sign in · Vert",
};

// The session is read per request, so this route can never be prerendered into a
// static page that claims a session state from build time.
export const dynamic = "force-dynamic";

export default async function LoginPage({ searchParams }) {
  const state = await sessionState();
  // The page the session ended on, carried by the proxy (verify pass 1 F10).
  const next = AUTH_REQUIRED ? safeNext(((searchParams && (await searchParams)) || {}).next) : null;
  const ended = state.ok ? null : sessionEndedSentence(state.reason, REJECTED);

  // With a service, this screen is drawn outside the shell and is the page's one main
  // landmark. The static build has nothing to sign in to and draws it inside the shell,
  // whose <main> already holds it — a second one there would be two main landmarks.
  const Root = AUTH_REQUIRED ? "main" : "section";

  // Outside the shell this page has no skip link of its own, so its first Tab stop was
  // the field (WIG G6; ui-pass-1 output-ui #37). Inside the shell (static build) the
  // shell's skip link is already first.
  return (
    <>
    {AUTH_REQUIRED ? <SkipLink /> : null}
    <Root className="sign-in" id={AUTH_REQUIRED ? "main" : undefined} tabIndex={AUTH_REQUIRED ? -1 : undefined}>
      <div className="sign-in-inner">
        <Wordmark className="sign-in-wordmark" size={40} />
        <div className="sign-in-intro">
          <h1 className="t-title-2 sign-in-title">{SIGN_IN.title}</h1>
          <p className="sign-in-value">{SIGN_IN.value}</p>
        </div>

        {ended ? <Notice kind="status">{ended}</Notice> : null}

        {AUTH_REQUIRED ? (
          <>
            <SignInForm next={next} />
            <Disclosure summary={SIGN_IN.help} className="sign-in-help">
              <p className="t-footnote">{SIGN_IN.helpBody}</p>
            </Disclosure>
          </>
        ) : (
          // No form at all, rather than a form that cannot work. A disabled field
          // invites somebody to hunt for why; a sentence saying there is nothing to
          // sign in to is the reason. It does not name the variable that would switch
          // this on: this screen is read by a bookkeeper.
          <p className="t-body">
            {SIGN_IN.sample}{" "}
            <Link href="/" className="link">
              {SIGN_IN.openSample}
              <IconCaretRight className="caret-trailing" />
            </Link>
          </p>
        )}
      </div>
      {/* The two public documents, under the surface and out of its way: a sign-in page
          is the one place a stranger lands, and these are what they may ask to read. */}
      <nav className="sign-in-legal" aria-label="Legal">
        <Link href="/privacy">Privacy</Link>
        <Link href="/terms">Terms</Link>
      </nav>
    </Root>
    </>
  );
}
