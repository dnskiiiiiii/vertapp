// app/records — THE EVIDENCE: PAYOUTS, JOURNAL ENTRIES, BANK LINES
// ==============================================================================
// Spec §3.5. One address for what used to be three registers: /payouts, /approvals and
// /exceptions all redirect here (next.config.mjs), each to the view it became —
// `?tab=entries` for the approvals queue, `?filter=needs-you` for the exceptions.
//
// `?payout=<id>` opens that payout's record sheet on arrival and is the one address for
// a payout; the redirect from /payouts keeps the query string, so an old deep link
// still opens the right record. `?line=<id>` does the same for a bank line, and
// `?entry=<id>` for a journal entry (the ledger memo's back-link). A record the link
// names is shown in ITS month, whatever month the sidebar has (RecordsScreen,
// model.js deepLinkScope); `?period=` names the month outright.
//
// The payload is read here only to find out whether it could be read at all: a close
// that did not arrive is the failure card, never an empty list (an empty register and
// an unreachable API look identical, and one of them is a false clean month).

import RecordsScreen from "@/components/records/RecordsScreen";
import { NEEDS_YOU_FILTER, bankFilterFrom, tabFrom } from "@/components/records/model";
import DataSourceDown from "@/components/shell/DataSourceDown";
import { readCloseData } from "@/lib/engine-server";
import { closeMonthOf, isPeriod, shownMonth } from "@/lib/period";
import { listDocuments } from "@/lib/documents";
import { DOCUMENTS_PAGE, documentsOffset, documentsView } from "@/components/records/documents-model";
import { documentParam, workbookView } from "@/components/records/workbook-model";
import { redirect } from "next/navigation";
import { AUTH_REQUIRED, readSession, sessionGet, visibleMonth } from "@/lib/session";
import { shouldLookForEntry } from "@/app/clients/open/resolve";
import { readAccountActivity, readLedgerAccounts } from "@/lib/ledger-activity";
import { accountsView, activityView, periodRange } from "@/components/records/activity-model";
import { entryMonth } from "@/lib/entry-month";
import { readJournalList } from "@/lib/journal-list";

/** The Accounts tab's reads (verify pass 3, S-BK-8): the chart, and with `?account=`
 *  the first page of that account's lines for the month, in the account's currency. */
async function readAccounts(params, period) {
  const answer = await readLedgerAccounts();
  const accounts = accountsView(answer);
  const id = one(params.account);
  if (!id) return { accounts, activity: null };
  const range = periodRange(period);
  const row = accounts.read ? accounts.rows.find((r) => r.id === id) : null;
  if (!range || !row || !row.currency) {
    const words = !range ? "Choose a month to list this account's lines." : !accounts.read ? accounts.words : !row ? "That account isn't on the chart." : "Vert doesn't know this account's currency, so it can't list its lines.";
    return { accounts, activity: { request: { account: id }, first: { read: false, rows: [], words } } };
  }
  // `?limit=` (1 to 1,000) sets the page size; the engine's own cap is 1,000.
  const asked = Number(one(params.limit));
  const limit = Number.isInteger(asked) && asked >= 1 && asked <= ACTIVITY_PAGE ? asked : ACTIVITY_PAGE;
  const request = { account: id, from: range.from, to: range.to, currency: row.currency, limit };
  return { accounts, activity: { request, first: activityView(await readAccountActivity(request)) } };
}

const ACTIVITY_PAGE = 1000;

export const metadata = { title: "Records · Vert" };
// A write pressed here (approve, post, a scheduled journal's Create) waits up to the
// engine's 300 s (lib/engine-source.js WRITE_TIMEOUT_MS, walk 2 N3), so this function
// is let run that long rather than cut before the write answers.
export const maxDuration = 300;

function one(value) {
  return typeof value === "string" && value ? value : null;
}

/**
 * THE MONTH THE SIDEBAR SHOWS, by the sidebar's own rule (components/shell/
 * shell-data.js `readShellData`): the month this browser chose if the service lists
 * it, else the latest month listed; with no service, the months the payload names,
 * else its own period. Records used to ignore the choice and list the whole register
 * under the payload's month — "Payouts · June … Needs you (29)" beside a July badge
 * of 4 (eval r1, S7/S9). The same rule here means the list and the badge are one
 * month's. Null when no month can be named; the screen then lists everything under
 * no month name rather than inventing one.
 */
async function recordsMonth(engine) {
  const read = await sessionGet("/close/periods");
  const body = read.ok ? read.body : null;
  const listedOf = (list) => (Array.isArray(list) ? list.map((m) => m && m.period).filter(isPeriod) : []);
  const chosen = await visibleMonth();
  // The service answered: the sidebar's own rule (lib/period.js shownMonth, verify pass 1
  // F22), so a month offered and not yet started is this page's month too.
  if (read.ok && (Array.isArray(body) || (body && Array.isArray(body.periods)))) {
    return shownMonth(listedOf(Array.isArray(body) ? body : body.periods), chosen, closeMonthOf(new Date()));
  }
  let listed = listedOf(engine && engine.periods);
  if (!listed.length && engine && isPeriod(engine.period)) listed = [engine.period];
  if (chosen && listed.includes(chosen)) return chosen;
  return [...listed].sort().at(-1) || null;
}

/**
 * EVERY JOURNAL ENTRY, OF EVERY OWNER (build plan §4.6 FS). The close payload carries
 * the payout entries only; a prepaid release, a manual entry and a reversal are on the
 * engine's journal road, `GET /journal?state=all`. Read only for the Journal entries
 * tab. Null when there is no service or the read failed — the screen then lists the
 * payout entries and says, in words, that the others were not read.
 */
async function readJournal() {
  const read = await readJournalList();
  return read.ok ? read.journal : null;
}

export default async function RecordsPage({ searchParams }) {
  const { engine, failure } = await readCloseData();
  if (failure) return <DataSourceDown failure={failure} />;

  const params = (await searchParams) || {};
  // `?entry=je:…` is the ledger memo's back-link (vert_api/main.py VERT_ENTRY_PATH): an
  // entry is on the Journal entries tab even when the link names no tab.
  const entryId = one(params.entry);
  // THE BACK-LINK NAMES NO CLIENT (verify pass 1 F-4, P19). Opened while this browser is
  // on another of the firm's clients, the entry is a measured 404 here: the link goes to
  // the client search (app/clients/open), which switches to the client holding it and
  // comes back marked `looked=clients`, so it is never sent twice.
  if (entryId && AUTH_REQUIRED && one(params.looked) !== "clients") {
    const session = await readSession();
    const inFirm = Boolean(session && session.person && session.firm);
    if (inFirm) {
      const here = await sessionGet(`/journal/${encodeURIComponent(entryId)}`);
      if (shouldLookForEntry({ entryId, status: here.ok ? 200 : here.status, inFirm, looked: false })) {
        redirect(`/clients/open?entry=${encodeURIComponent(entryId)}`);
      }
    }
  }
  const tab = entryId && !one(params.tab) ? "entries" : tabFrom(one(params.tab));
  // `?period=2026-08` names the month outright (P19/P28: June's in-transit payouts could
  // not be shown while July was the sidebar's month); otherwise the sidebar's month.
  const requested = isPeriod(one(params.period)) ? one(params.period) : null;
  const period = requested || (await recordsMonth(engine));
  // ONE-OFF JOURNALS ARE WRITTEN HERE (scheduled-spec.md: Journals is no longer a module;
  // Month-end → Records "New entry"). The editor dates itself in the first month that
  // isn't signed off (lib/entry-month.js; UI walk D4), read only on the entries tab.
  const [journal, entryPeriod] = tab === "entries" ? await Promise.all([readJournal(), entryMonth(period)]) : [null, null];
  // The Documents tab (verify pass 2 S-UI-2): one page of the client's files.
  const offset = documentsOffset(params.offset);
  const documents = tab === "documents" ? documentsView(await listDocuments({ limit: DOCUMENTS_PAGE, offset }), { offset }) : null;
  // `?document=<id>` opens a workbook's sheets under the list (verify pass 4, S-FL-7).
  const documentId = tab === "documents" ? documentParam(params.document) : null;
  const workbook = documentId ? workbookView(await sessionGet(`/documents/${encodeURIComponent(documentId)}/workbook`), documentId) : null;
  const { accounts = null, activity = null } = tab === "accounts" ? await readAccounts(params, period) : {};
  return (
    <RecordsScreen
      period={period}
      pinned={Boolean(requested)}
      entryId={entryId}
      // Keyed by the tab so moving between tabs starts each list fresh — its own
      // filter, search and open record — rather than carrying one tab's into another.
      key={tab}
      tab={tab}
      filter={tab === "bank" ? bankFilterFrom(one(params.filter)) : one(params.filter) === NEEDS_YOU_FILTER ? NEEDS_YOU_FILTER : null}
      payoutId={one(params.payout)}
      lineId={one(params.line)}
      journal={journal}
      entryPeriod={entryPeriod}
      documents={documents}
      workbook={workbook}
      accounts={accounts}
      activity={activity}
    />
  );
}
