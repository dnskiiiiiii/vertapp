// app/records/loading.js — the shape of Records while it comes (UI-016). Static
// blocks, no shimmer: a title, the tabs, and rows.

import { Skeleton } from "@/components/ui/marks";

export default function RecordsLoading() {
  return (
    <section className="route-state route-loading records">
      <Skeleton lines={6} label="Loading records" />
    </section>
  );
}
