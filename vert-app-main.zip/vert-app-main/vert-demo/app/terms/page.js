// app/terms/page.js — THE PUBLIC TERMS URL
// ==============================================================================
// Intuit requires an EULA/terms URL alongside the privacy policy. Same arrangement as
// app/privacy/page.js: public, no chrome, no session, no engine.
//
// This document is further from finished than the privacy policy is, and it says so
// where it matters. §11 (limitation of liability) and §12 (indemnity) are not written —
// they are notes to a lawyer — and they render as unwritten clauses rather than as
// prose, because a limitation of liability that a reader could mistake for a term is
// the worst single thing this route could put on a public URL.

import PolicyDocument from "@/components/legal/PolicyDocument";
import { SOURCE, TITLE } from "@/lib/policies/terms-of-service";

export const metadata = {
  title: "Terms of service (draft) · Vert",
  description:
    "The terms governing use of Vert. A working draft: unestablished facts and unwritten clauses are marked in place, not guessed at.",
  robots: { index: false, follow: false },
};

export default function TermsPage() {
  return <PolicyDocument source={SOURCE} title={TITLE} />;
}
