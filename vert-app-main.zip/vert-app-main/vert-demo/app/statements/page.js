// app/statements — THE MONTH'S FINANCIAL STATEMENTS, FULL WIDTH
// ==============================================================================
// W4 Step 5 of the close list (29 Oct 2026). The profit and loss, the balance sheet and
// the cash flow for one month, with their two checks and the month-end pack's two
// downloads: the same card a statements answer draws in the chat (components/chat/
// answer/Statements.js), all three statements stacked.
//
// REACHED FROM MONTH-END, NOT THE SIDEBAR. The sidebar is exactly Month-end, Journals and
// Bills & invoices (tests/sidebar.test.js); the statements are Month-end's section
// (components/shell/ia.js MONTH_END_SECTION), opened from its "Close the month" panel and
// from a statements answer's "Open statements". A link back to Month-end leads the page.
//
// WHICH MONTH: `?period=YYYY-MM` names it outright, as on Month-end (month-reads.js
// monthAsked); otherwise the month Month-end shows, by the sidebar's own rule
// (lib/period.js shownMonth over the months listing and this browser's choice).
//
// READ HERE, ON THE SERVER, WITH THE KEY (lib/close.js readStatements: `GET /close/
// {period}/statements`). Nothing on this page writes. A read that failed, a session that
// signed out, or a build with no service is said in words, never drawn as statements
// of zeros.

import Link from "next/link";
import Statements from "@/components/chat/answer/Statements";
import { statementsOf } from "@/components/chat/answer/financial-statements";
import { monthAsked } from "@/components/month/month-reads";
import { IconCaretLeft, IconDownload } from "@/components/ui/icons";
import { NO_SERVICE_WORDS, readStatements } from "@/lib/close";
import { closeMonthOf, isPeriod, periodLabel, shownMonth } from "@/lib/period";
import { AUTH_REQUIRED, sessionGet, visibleMonth } from "@/lib/session";

export const metadata = { title: "Financial statements · Vert" };
export const maxDuration = 60;

/** The month Month-end shows, by the sidebar's rule, or null when none can be named. */
async function shownPeriod() {
  const [read, chosen] = await Promise.all([sessionGet("/close/periods"), visibleMonth()]);
  const body = read.ok ? read.body : null;
  const list = Array.isArray(body) ? body : body && Array.isArray(body.periods) ? body.periods : null;
  if (!list) return isPeriod(chosen) ? chosen : null;
  return shownMonth(list.map((m) => m && m.period).filter(isPeriod), chosen, closeMonthOf(new Date()));
}

export default async function StatementsPage({ searchParams }) {
  // The static build has one recorded month and no service: reading the query would
  // turn its prerendered page dynamic, and there is nothing to read anyway.
  if (!AUTH_REQUIRED) return <Frame period={null} words={NO_SERVICE_WORDS} />;
  const query = (searchParams && (await searchParams)) || {};
  const period = monthAsked(query) || (await shownPeriod());
  if (!period) return <Frame period={null} words="Vert couldn't tell which month to show. Open the statements from Month-end." />;
  const read = await readStatements(period);
  if (!read.ok) return <Frame period={period} words={read.message} />;
  if (!statementsOf(read.body)) {
    return <Frame period={period} words={`Vert's statements for ${periodLabel(period)} couldn't be read as they were sent, so they aren't drawn here.`} />;
  }
  return (
    <Frame period={period}>
      <Statements statements={read.body} full />
    </Frame>
  );
}

function Frame({ period, words = null, children = null }) {
  return (
    <div className="page statements-page" data-statements-page="">
      <Link className="link statements-back t-footnote" href={period ? `/?period=${period}` : "/"}>
        <IconCaretLeft aria-hidden="true" />
        <span>Month-end</span>
      </Link>
      <header className="page-head">
        <div>
          <h1 className="t-title-1">Financial statements</h1>
          <p className="page-head-sub">{period ? `Profit and loss, balance sheet and cash flow for ${periodLabel(period)}.` : "Profit and loss, balance sheet and cash flow."}</p>
        </div>
        {period && !words ? (
          <div className="statements-pack">
            <a className="btn btn-secondary btn-sm" href={`/api/close/${period}/pack?format=pdf`} download data-pack-download="pdf">
              <IconDownload aria-hidden="true" />
              <span>Download month-end pack</span>
            </a>
            <a className="btn btn-quiet btn-sm" href={`/api/close/${period}/pack?format=xlsx`} download data-pack-download="xlsx">
              Excel
            </a>
          </div>
        ) : null}
      </header>
      {words ? (
        <p className="statements-unread t-body" role="status" data-statements-unread="">
          {words}
        </p>
      ) : null}
      {children}
    </div>
  );
}
