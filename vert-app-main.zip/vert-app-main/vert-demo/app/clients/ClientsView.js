"use client";

// app/clients/ClientsView.js — EVERY CLIENT'S MONTH, ONE ROW EACH (#20)
// ==============================================================================
// Build plan §19.9 F-FIRM; reference teardown "Clients": one firm-wide segmented bar,
// one row per client with a status word, "N decisions need you" and "7 of 13" (S8's
// words, W0c CO-22), the tabs All
// clients / Assigned to you, and a row that opens that client's Month-end.
//
// THE SAME SHAPE AT EVERY ALTITUDE. The bar is Month-end's own Progress fed the firm's
// totals, and each row carries the same bar small (design-pass spec §6.8, §7.3), so a
// task, a client and the firm read the same way.
//
// DESIGN-FIX-2 (DA2-054). The table says each fact once, in its own column:
//
//   Client                Progress              Decisions   Preparer     Reviewer     Due
//   [N] Northwind         ▬▬▬▬▬▬▬  1 of 11          9        (SL)         Unassigned   7 Oct  ›
//   [H] Harbour & Co      September hasn't started  –          Unassigned   Unassigned   No due date  ›
//   + Add a client…
//
// The client's initial in a 24 px tile; the row's bar 6 px, Done's share only (verify
// pass 3, U53: the four status colours on a row had no word beside them); Needs you as a
// plain tabular count in the attention ink, or "–" (the accounting zero mark, in a
// figure cell); Preparer and Reviewer as 20 px initials, "Unassigned" in words for
// nobody, and Due "No due date" (verify pass 3, U69 T1: "–" is not a word for nobody).
// The legend and the explainer copied from Month-end are gone: the counts are in the
// rows. The "Every client / Assigned to you" choice lives in the address as
// `?show=assigned`.
//
// A TABLE OF ROWS, NOT A COLUMN OF WORDS (design-pass spec §7.3; audit §12 P1). The
// rows used to hold only a name on the left and every fact pushed to the right edge of
// a 752 px column. Now the page takes the shared column and each row reads across it:
// Client · Progress (a 4 px bar and "1 of 11") · Decisions (an attention count chip) ·
// Preparer · Reviewer · Status (the chip, one of the four words) · a chevron, because
// the whole row opens the client. Preparer and Reviewer are the names the client's own
// month lists on its tasks (lib/firm.js listClients); a read month naming nobody says "Unassigned",
// an unread one draws nothing. On a phone each client is a short row: the name and
// status, then the bar with the decisions beside it, then who prepares and reviews.
// Every number on a
// row is that client's `GET /close` count as the engine copied it; the bar adds only the
// clients that were read, and says in words how many were not (unread is never zero).
//
// A ROW IS A PRESS, NOT A LINK. Opening a client switches this browser to it first
// (lib/firm.js switchClient proves the switch with the engine before remembering it),
// then goes to Month-end. A plain link to "/" would open whichever client was last
// chosen and show the wrong books under the right name.

import Link from "next/link";
import { useEffect, useState } from "react";

import { IconChevronRight } from "@/components/shell/icons";
import { ProgressBar, Segmented, StatusCounts } from "@/components/ui";
import { IconAdd } from "@/components/ui/icons";
import { STATUS_WORDS } from "@/lib/status";
import { switchClient } from "@/lib/firm";
import { readClientsDetailByGet } from "./detail-read";
import { goToSwitchedClient } from "@/components/shell/switching";

import { TABS, clientDue, clientName, decisionsWords, firmTotals, firmDoneWords, notStarted, notStartedWords, peopleWords, progressWords, rowStatusWord, rowsFor, searchClients, withDetail } from "./model";
import { IconCaretRight, IconSearch } from "@/components/ui/icons";
import { showsRegisterChrome } from "@/components/shared/registerChrome";
import { FIRM_STEPS_TITLE } from "@/components/skills/firm-skills-model";
import "./clients.css";

/** The bar's four parts from a client's (or the firm's) counts; null when unread. */
function partsOf(counts) {
  if (!counts) return null;
  return { done: counts.done, working: counts.working, attention: counts.needsYou, waiting: counts.waiting };
}

/** A name's initials, two at most ("Sam Lee" → "SL"). */
function initialsOf(name) {
  const parts = String(name || "").split(/[^A-Za-z0-9]+/).filter(Boolean);
  return parts.slice(0, 2).map((p) => p[0].toUpperCase()).join("") || "·";
}

/**
 * The row's own bar: how much of the month is done, as a length, beside the words that
 * say it ("1 of 11"). Drawn only when every count was read and the month has started.
 *
 * ONE QUANTITY, NOT FOUR COLOURS (verify pass 3, U53). The row's bar used to be the
 * firm bar's four status segments small: Needs you, Vert's working and Waiting told
 * apart by colour alone, with no word or glyph beside them on the row (the firm bar has
 * its StatusCounts legend; a row has no room for one). The row now draws Done's share
 * only, which its words carry, and the status counts are said where they have words:
 * the Needs you column and the firm bar's legend.
 */
function MiniBar({ client, name }) {
  if (notStarted(client) || !client || !client.counts || !client.progress) return null;
  return <ProgressBar className="clients-mini" done={client.progress.done} total={client.progress.total} label={`${name}: ${progressWords(client)} tasks done`} />;
}

/**
 * Needs you: the count, plain and tabular, in the attention ink; its words for assistive
 * tech. A measured zero is "–" in the tertiary ink; an unread count draws nothing at all,
 * because unread is never zero.
 */
function Decisions({ client }) {
  const words = decisionsWords(client);
  if (!words) {
    return Number.isInteger(client && client.decisions) && client.decisions === 0 ? (
      <span className="clients-none num">
        <span aria-hidden="true">–</span>
        <span className="sr-only">None need you</span>
      </span>
    ) : null;
  }
  return (
    <span className="clients-need">
      <span className="clients-need-count num" aria-hidden="true">
        {client.decisions}
      </span>
      <span className="clients-need-words">{words}</span>
    </span>
  );
}

/** A Preparer or Reviewer cell: 20 px initials per person, "–" for nobody, nothing when unread. */
function Person({ list, role, from = "tasks" }) {
  const words = peopleWords(list);
  // The firm's role holders, when this month's tasks name nobody (verify pass 4,
  // S-E2E-3; lib/firm-month.js withFirmRoles): said as the firm's, never as an assignee.
  const fromFirm = from === "firm" && Array.isArray(list) && list.length > 0;
  const whose = fromFirm ? `${words}, the firm’s ${role === "preparer" ? "preparer" : "reviewer"}${list[1] ? "s" : ""}` : words;
  if (!words) return <span className="clients-person-cell" data-role={role} />;
  const label = role === "preparer" ? "Preparer" : "Reviewer";
  if (!list.length) {
    // Nobody, IN WORDS (verify pass 3, U69 T1): "–" is the accounting zero mark and
    // belongs in a figure cell only; a name cell says "Unassigned".
    return (
      <span className="clients-person-cell" data-role={role}>
        <span className="clients-person-label">{label}</span>
        <span className="clients-person-none">{words}</span>
      </span>
    );
  }
  return (
    <span className="clients-person-cell" data-role={role}>
      <span className="clients-person-label">{label}</span>
      <span className="clients-avatars" title={fromFirm ? `${whose}. No task this month names one yet.` : words} data-from={fromFirm ? "firm" : undefined}>
        {list.slice(0, 3).map((name) => (
          // The initials are drawn by CSS from the attribute, so the row's text is the
          // names themselves, once.
          <span key={name} className="clients-avatar" data-initials={initialsOf(name)} aria-hidden="true" />
        ))}
        <span className="clients-person sr-only">{whose}</span>
      </span>
    </span>
  );
}

/** Due: "7 Oct" in tabular figures, in the problem ink with "late" for assistive tech when past. */
function Due({ client, period }) {
  const due = clientDue(client, period);
  // Read, and no task has a due day: said in words, "No due date" (verify pass 3, U69
  // T1: "–" is a figure cell's zero mark, not a date's absence; a blank cell under a
  // named column read as a failed read). Unread: nothing, because nothing is known.
  if (!due && client && client.people) {
    return (
      <span className="clients-due-cell" data-none="true">
        <span className="clients-person-none">No due date</span>
      </span>
    );
  }
  if (!due) return <span className="clients-due-cell" />;
  return (
    <span className="clients-due-cell">
      <span className="clients-due-label">Due</span>
      <time className="clients-due num" dateTime={due.iso} data-late={due.late ? "true" : undefined}>
        {due.text}
      </time>
      {due.late ? <span className="sr-only">, late</span> : null}
    </span>
  );
}

function ClientRow({ client, current, busy, onOpen, monthLabel, period }) {
  // A month not started says so; its tasks-done count is not drawn beside it.
  const progress = notStarted(client) ? notStartedWords(client, monthLabel) : progressWords(client);
  const unassignedUnread = client.assigned == null && client.counts;
  const name = clientName(client);
  const word = rowStatusWord(client, STATUS_WORDS);
  return (
    <li className="clients-row-item">
      <button
        type="button"
        className="row clients-row"
        data-client={client.tenantId}
        aria-current={current ? "true" : undefined}
        aria-busy={busy ? "true" : undefined}
        disabled={busy}
        onClick={() => onOpen(client.tenantId)}
      >
        <span className="clients-client">
          <span className="clients-tile" aria-hidden="true">
            {initialsOf(name).slice(0, 1)}
          </span>
          <span className="clients-name t-body" translate="no" title={name}>{name}</span>
          {/* The status in words for assistive tech; on screen the count and the bar say it. */}
          {/* A month not started says so once, in its visible sentence (shell-u1 W20). */}
          {notStarted(client) ? null : <span className="sr-only">, {word || (client && client.status) || "Not read"}</span>}
        </span>
        <span className="clients-progress-cell">
          <MiniBar client={client} name={name} />
          {progress ? <span className="clients-progress num">{progress}</span> : null}
          {!word && !progress ? <span className="clients-word">{(client && client.status) || "Not read"}</span> : null}
        </span>
        <span className="clients-need-cell">
          <Decisions client={client} />
        </span>
        <Person list={client.people && client.people.preparers} role="preparer" from={client.people && client.people.from && client.people.from.preparers} />
        <Person list={client.people && client.people.reviewers} role="reviewer" from={client.people && client.people.from && client.people.from.reviewers} />
        <Due client={client} period={period} />
        <IconChevronRight className="clients-chevron" />
        {unassignedUnread ? <span className="clients-note t-footnote">Couldn&apos;t check what&apos;s assigned to you here</span> : null}
      </button>
    </li>
  );
}

/** Keep the choice in the address (WIG: deep-link state; DA2-080) without re-reading every client. */
function rememberTab(tab) {
  try {
    const url = new URL(window.location.href);
    url.searchParams.delete("tab");
    if (tab === "mine") url.searchParams.set("show", "assigned");
    else url.searchParams.delete("show");
    window.history.replaceState(window.history.state, "", url);
  } catch {
    // The tab still changes; only the address doesn't follow.
  }
}

/**
 * "Add a client…" (DA2-054): a quiet row at the foot. Clients are engaged by Vert's team,
 * not created here, so the row says how in one line rather than opening a form that
 * could not work.
 */
function AddClient() {
  const [open, setOpen] = useState(false);
  return (
    <div className="clients-add">
      <button type="button" className="row clients-add-row" aria-expanded={open ? "true" : "false"} onClick={() => setOpen((was) => !was)}>
        <IconAdd className="clients-add-icon" />
        <span>Add a client…</span>
      </button>
      {open ? (
        <p className="clients-add-note" role="status">
          A new client is added when your firm engages it in Vert. Ask the person who set up Vert for your firm to add one.
        </p>
      ) : null}
    </div>
  );
}

export default function ClientsView({ result: quickResult, current = null, initialTab = "all", detailPending: pendingAtFirst = false }) {
  // THE DETAIL AFTER THE ROWS (verify pass 3 S-UI-2): the page answered with the firm's
  // one read; who prepares and reviews each client is asked for here, once the rows are
  // on screen, and laid over them, with a GET (./detail-read.js: arriving sends no
  // Server Action). A failed read leaves the quick rows as they were.
  const [detail, setDetail] = useState(null);
  const [detailPending, setDetailPending] = useState(pendingAtFirst);
  const period = quickResult && quickResult.ok ? quickResult.period : null;
  useEffect(() => {
    if (!pendingAtFirst || !period) return undefined;
    let live = true;
    setDetailPending(true);
    readClientsDetailByGet(period)
      .then((read) => {
        if (live) setDetail(read && read.ok ? read : null);
      })
      .catch(() => {})
      .finally(() => {
        if (live) setDetailPending(false);
      });
    return () => {
      live = false;
    };
  }, [pendingAtFirst, period]);
  const result = withDetail(quickResult, detail);
  const [tab, setTab] = useState(initialTab);
  const [query, setQuery] = useState("");
  const [opening, setOpening] = useState(null);
  const [problem, setProblem] = useState(null);

  if (!result || !result.ok) {
    return (
      <div className="page clients">
        <header className="page-head">
          <div className="page-head-words">
            <h1 className="t-title-1">Clients</h1>
            <p className="clients-verdict t-callout">{(result && result.message) || "Vert couldn't read your clients just now."}</p>
          </div>
        </header>
      </div>
    );
  }

  const clients = result.clients;
  const totals = firmTotals(clients);
  const done = firmDoneWords(totals.counts);
  const tabRows = rowsFor(tab, clients);
  const rows = searchClients(tabRows, query);
  const count = clients.length === 1 ? "1 client" : `${clients.length} clients`;

  async function open(tenantId) {
    setProblem(null);
    setOpening(tenantId);
    // The firm's month goes with the jump: the row counted this client's month, so
    // Month-end opens on that month (eval r1 #20), not on a month this browser chose
    // for another client, nor on none for a client with no months listed yet.
    const switched = await switchClient(tenantId, { period: result.period || null });
    if (!switched || !switched.ok) {
      setOpening(null);
      setProblem((switched && switched.message) || "Vert couldn't open that client. You're still on the one you had.");
      return;
    }
    // One document load of the new client's Month-end (components/shell/switching.js,
    // verify pass 5 S-E2E-3 F12), never a push and a refresh queued behind the action's
    // own re-render. `opening` keeps the row busy until the page goes.
    goToSwitchedClient();
  }

  function choose(next) {
    setTab(next);
    rememberTab(next);
  }

  return (
    <div className="page clients" data-clients="">
      <header className="page-head">
        <div className="page-head-words">
          <h1 className="t-title-1">Clients</h1>
          {/* One fact per line (spec §6.10): the month and the firm's size on the left;
              how far the firm has got is the figure on the same line's right, said as
              the bar's own sums. */}
          <div className="clients-sub">
            <p className="page-head-sub" data-clients-verdict="">
              {[result.label, count].filter(Boolean).join(" · ")}
            </p>
            {done ? (
              <p className="clients-done" data-clients-done="">
                <span className="clients-done-figure num">{done.replace(/ done$/, "")}</span> tasks done
              </p>
            ) : null}
          </div>
        </div>
      </header>

      {totals.counts || totals.unread > 0 ? (
        <div className="clients-overview">
          {totals.counts ? (
            <>
              <ProgressBar className="clients-firm-bar" done={totals.counts.done} total={totals.counts.total} parts={partsOf(totals.counts)} label={`${done.replace(/ done$/, "")} tasks done`} />
              {/* Each segment's word and glyph (U53; verify pass 1 F-8): the bar alone was colour. */}
              <StatusCounts counts={totals.counts} className="clients-counts" unit="Tasks" />
            </>
          ) : null}
          {totals.unread > 0 ? (
            <p className="clients-unread" data-clients-unread="">
              {totals.unread === 1 ? "1 client couldn't be read, so it isn't in the bar." : `${totals.unread} clients couldn't be read, so they aren't in the bar.`}
            </p>
          ) : null}
        </div>
      ) : null}

      <section className="clients-section" aria-label="Clients this month">
        <div className="clients-tools">
          <Segmented options={TABS.map((t) => ({ value: t.key, label: t.label }))} value={tab} onChange={choose} label="Show" />
          {/* FIND A CLIENT BY NAME (verify pass 2 S-UI-2), once the list is long enough to need it. */}
          {showsRegisterChrome(clients.length) ? (
          <label className="checklist-search-field clients-search">
            <IconSearch className="checklist-search-glyph" size={14} aria-hidden="true" />
            <input
              type="search"
              className="checklist-search-input"
              name="clientSearch"
              aria-label="Search clients"
              placeholder="Search clients…"
              autoComplete="off"
              spellCheck={false}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </label>
          ) : null}
          {detailPending ? (
            <p className="clients-pending t-footnote" role="status" data-clients-pending="">
              Reading who prepares and reviews each client…
            </p>
          ) : null}
        </div>

        {problem ? (
          <p className="clients-problem t-footnote" role="alert">
            {problem}
          </p>
        ) : null}

        {rows.length ? (
          <div className="clients-table">
            <div className="clients-cols" aria-hidden="true">
              <span>Client</span>
              <span>Progress</span>
              {/* DECISIONS, NOT "NEEDS YOU" (verify pass 5, W20): the band above counts
                  tasks by status ("Needs you 4"); this column counts the decisions waiting
                  ("5 decisions need you"). One name for two figures read as a contradiction. */}
              <span className="clients-col-num">Decisions</span>
              <span>Preparer</span>
              <span>Reviewer</span>
              <span>Due</span>
              <span />
            </div>
            <ul className="clients-list" aria-label={tab === "mine" ? "Clients with work assigned to you" : "Clients"}>
              {rows.map((c) => (
                <ClientRow key={c.tenantId} client={c} current={c.tenantId === current} busy={opening === c.tenantId} onOpen={open} monthLabel={result.label} period={result.period} />
              ))}
            </ul>
          </div>
        ) : (
          <p className="clients-empty t-callout">
            {query.trim() && tabRows.length
              ? `No client matches “${query.trim()}”.`
              : tab === "mine"
                ? "Nothing is assigned to you this month."
                : "No clients are listed for this month."}
          </p>
        )}
        <AddClient />
        {/* THE FIRM'S SKILLS (verify pass 2 D44): written once, used for every client,
            and copied for one client when it needs its own. Named for what it is to the
            person, not with the word "skill" (verify pass 4, U65: "skill" belongs on
            the load line, the skill sheet and the skill-update card only), and a 44 px
            press at phone width (S-UI-4: it was 16 px tall). */}
        <p className="clients-skills-link t-footnote">
          <Link href="/clients/skills" className="link clients-firm-steps">
            {FIRM_STEPS_TITLE}<IconCaretRight className="caret-trailing" />
          </Link>
        </p>
      </section>
    </div>
  );
}
