// app/clients/skills — THE FIRM'S SKILLS (verify pass 2, D44)
// ==============================================================================
// Reached from the Clients view. A person in a firm sees every skill the firm has written
// and each client against it, with Edit and Fork (components/skills/FirmSkillsView.js).
// A tenant key and the static build have no firm: one sentence says so.

import { AUTH_REQUIRED, readSession } from "@/lib/session";
import { listFirmSkills } from "@/lib/firm";
import FirmSkillsView from "@/components/skills/FirmSkillsView";
import { FIRM_STEPS_TITLE } from "@/components/skills/firm-skills-model";

export const metadata = { title: `${FIRM_STEPS_TITLE} · Vert` };
export const dynamic = "force-dynamic";

export default async function FirmSkillsPage() {
  const session = AUTH_REQUIRED ? await readSession() : null;
  if (!session || !session.person || !session.firm) {
    return <FirmSkillsView answer={{ ok: false, message: "Your firm’s steps for each task appear when a person in a firm signs in with their own key." }} />;
  }
  return <FirmSkillsView answer={await listFirmSkills()} />;
}
