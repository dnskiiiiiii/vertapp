// app/clients — THE CLIENTS VIEW (#20), THE ONE NEW ROUTE OF ITERATION 3
// ==============================================================================
// Build plan §19.9 F-FIRM, §19.0.9. Firm mode: every client the signed-in person's firm
// serves, for the month the sidebar shows, each as its own `GET /close` counted it
// (vert_api/routers/firm.py copies the counts; nothing here recomputes one).
//
// ONLY A PERSON IN A FIRM HAS CLIENTS. A tenant key belongs to one client, and the
// static build has no firm at all: both get one sentence saying so, never an empty
// list (which would claim the firm has no clients) and never the fixture dressed as a
// firm. The switcher only links here when the session names a firm, so this sentence
// is reached by typing the address, not by a dead control.
//
// THE SIDEBAR'S MONTH (verify pass 1 F22). The view opens on the month the sidebar
// and Month-end show for the client this browser is on, by their one rule (lib/period.js
// shownMonth): this browser's choice when it can be shown, else that client's latest
// started month, else the current close month (never the calendar month, which nobody
// can close yet: W0c CO-22, eval r3 F5). Only when that client's months couldn't be read
// is the month worked out from every client's listing (model.js firmMonthToShow); a
// client whose months couldn't be read is left out of that choice, never read as none.

import { readSession, sessionGet, visibleMonth, AUTH_REQUIRED, chosenClient } from "@/lib/session";
import { clientPeriods } from "@/lib/actions";
import { listClients } from "@/lib/firm";
import { closeMonthOf, isPeriod } from "@/lib/period";

import ClientsView from "./ClientsView";
import { firmMonthToShow, monthToShow, tabFrom } from "./model";

export const metadata = { title: "Clients · Vert" };

const CLIENT_ID = /^[a-z0-9][a-z0-9_-]{0,63}$/;

/** The periods a `GET /close/periods` body lists, or null when it isn't one. */
function periodsOf(body) {
  const list = Array.isArray(body) ? body : body && body.periods;
  return Array.isArray(list) ? list.map((m) => m && m.period).filter(isPeriod) : null;
}

/**
 * The month to show and, when it was already read for it, the client list. The current
 * client's own listing decides when it lists this browser's choice (one read, as
 * before); otherwise every client's listing is read and the firm's month chosen.
 */
async function clientsMonth(current) {
  const read = await sessionGet("/close/periods");
  const here = periodsOf(read.ok ? read.body : null);
  const chosen = await visibleMonth();
  const today = closeMonthOf(new Date());
  // ONE RULE (verify pass 1 F22): the month the sidebar and Month-end show for the client
  // this browser is on (lib/period.js shownMonth), so Clients never names August beside a
  // September Month-end. Only when this client's months couldn't be read is the firm's
  // month worked out from every client's listing instead.
  if (here) return { period: monthToShow(here, chosen, today), listed: null };
  // The firm's list is read QUICK here (`detail: false`): only the ids are wanted, and a
  // detailed read is one close read per client (verify pass 3 S-UI-2).
  const first = chosen || today;
  const listed = await listClients(first, { detail: false });
  const others = listed.ok ? listed.clients.map((c) => c && c.tenantId).filter((id) => typeof id === "string" && CLIENT_ID.test(id) && id !== current) : [];
  const listings = [here, ...(await Promise.all(others.map((id) => clientPeriods(id))))];
  const period = firmMonthToShow(listings, chosen, today);
  return { period, listed: period === first && listed.ok ? listed : null };
}

const NO_FIRM = {
  ok: false,
  message: "The Clients view lists a firm's clients. It appears when a person signs in with their own key.",
};

// THE ROWS FIRST, THE DETAIL AFTER (verify pass 2 and 3, S-UI-2). With 126 clients the
// firm's one read answers in about 2.4 s, but each client's own month read (who
// prepares, who reviews, what is assigned to you) is one more read per client. Pass 2
// streamed that detail into the same response behind a Suspense boundary, which still
// held the document open: the page's load finished, and the first row was measured, at
// 11.9 s. The page now answers with the firm's read alone (`detail: false`) and ends;
// the view asks for the detail itself once it is on screen (ClientsView, through
// lib/firm.js readClientsDetail) and fills it in. Neither render invents what the other
// lacks: an unread Preparer is drawn as nothing, never as "Unassigned".

export default async function ClientsPage({ searchParams }) {
  const params = (await searchParams) || {};
  const session = AUTH_REQUIRED ? await readSession() : null;
  if (!session || !session.person || !session.firm) {
    return <ClientsView result={NO_FIRM} />;
  }
  const current = (await chosenClient(session)) || session.tenant;
  const initialTab = tabFrom(params.show === "assigned" ? "mine" : params.tab);
  const { period, listed } = await clientsMonth(current);
  if (!period) return <ClientsView result={{ ok: false, message: "Vert couldn't find a month to show." }} current={current} initialTab={initialTab} />;
  const quick = listed || (await listClients(period, { detail: false }));
  return <ClientsView result={quick} current={current} initialTab={initialTab} detailPending={Boolean(quick.ok)} />;
}
