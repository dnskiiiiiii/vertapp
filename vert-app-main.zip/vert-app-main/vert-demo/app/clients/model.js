// app/clients/model.js — THE CLIENTS VIEW'S WORDS AND TOTALS, PURE
// ==============================================================================
// Build plan §19.9 F-FIRM (#20). Every client's numbers are that client's own
// `GET /close/{period}` counts, copied across by the engine's `GET /firm/clients` with
// no arithmetic of its own (vert_api/routers/firm.py). This module reads them; it never
// recomputes one. The only sum on the page is the firm-wide bar, and it adds ONLY the
// clients whose counts were read: a client the engine could not read is not a client
// with nothing to do, so it is left out of the bar and said in words beside it.
//
// Pure, so the page (server) and the switcher sheet (client) share it, and tests drive
// it without a renderer. It imports lib/format.js's naming rule, so a client is
// called the same thing here as at the top of the sidebar, and lib/period.js's month rule.

import { MONTHS, accountName } from "../../lib/format.js";
import { shownMonth } from "../../lib/period.js";

const isCount = (n) => Number.isInteger(n) && n >= 0;

/** The four per-word counts the bar is drawn from, in the Month-end bar's order. */
export const BAR_KEYS = Object.freeze(["done", "working", "needsYou", "waiting"]);

/** Were this client's counts read? (`counts: null` means the engine couldn't.) */
export function isMeasured(client) {
  const c = client && client.counts;
  return Boolean(c) && isCount(c.total) && BAR_KEYS.every((k) => isCount(c[k]));
}

/**
 * The firm-wide bar's counts: each per-word count summed over the MEASURED clients whose
 * month HAS STARTED, plus how many clients were left out and why. `null` when no client
 * was counted, so the bar draws nothing rather than an empty bar that reads as "no work".
 *
 * A MONTH NOBODY STARTED IS NOT IN THE BAR (ui-pass-1 walkthrough #18, W20). Its row says
 * "September hasn't started" and draws no "0 of 5" and no mini bar, because tasks counted
 * in a month that hasn't started are a count of nothing the row can stand behind (W0c
 * CO-22, below). The bar used to add those same counts anyway, so the header read
 * "Needs you 7" while the rows beneath it accounted for 6: Harbour's unopened September
 * was counted in the sum and disowned in its own row. One rule now serves both: a
 * not-started client is left out of the bar and said in words beside it, as an unread
 * one is.
 */
export function firmTotals(clients) {
  const list = Array.isArray(clients) ? clients : [];
  const measured = list.filter(isMeasured);
  const unread = list.length - measured.length;
  const counted = measured.filter((c) => !notStarted(c));
  const waitingOnStart = measured.length - counted.length;
  if (!counted.length) return { counts: null, measured: 0, unread, notStarted: waitingOnStart };
  const counts = { total: 0, done: 0, working: 0, needsYou: 0, waiting: 0, decisions: 0 };
  for (const c of counted) {
    counts.total += c.counts.total;
    for (const k of BAR_KEYS) counts[k] += c.counts[k];
    counts.decisions += isCount(c.counts.decisions) ? c.counts.decisions : 0;
  }
  return { counts, measured: counted.length, unread, notStarted: waitingOnStart };
}

/**
 * "2 of 10 done" across the firm, from the firm totals; null with nothing measured or
 * no tasks. The two numbers are the bar's own sums, said as counts: a percentage would
 * be a third figure derived from them, and the counts already say it.
 */
export function firmDoneWords(counts) {
  if (!counts || !isCount(counts.total) || counts.total === 0) return null;
  return `${counts.done} of ${counts.total} done`;
}

/**
 * "1 client hasn't started September, so it isn't in the bar." — the words beside the
 * bar for the clients left out of it because their month has not started; null for none.
 */
export function notStartedNote(n, monthLabel = null) {
  if (!isCount(n) || n === 0) return null;
  const month = typeof monthLabel === "string" && monthLabel.trim() ? monthLabel.trim().split(/\s+/)[0] : "this month";
  return n === 1
    ? `1 client hasn't started ${month}, so it isn't in the bar.`
    : `${n} clients haven't started ${month}, so they aren't in the bar.`;
}

/** "3 need action" / "1 needs action", from the client's own `decisions`; null when unread or none. */
export function needActionWords(client) {
  const n = client && client.decisions;
  if (!isCount(n) || n === 0) return null;
  return n === 1 ? "1 needs action" : `${n} need action`;
}

/** "7 of 13", the client's own progress; null when unread. */
export function progressWords(client) {
  const p = client && client.progress;
  if (!p || !isCount(p.done) || !isCount(p.total)) return null;
  return `${p.done} of ${p.total}`;
}

// ── THE ROW IN THE FOUR STATUS WORDS (W0c CO-22; eval r3 output-visual F13, §9.1 S8) ──
//
// The rows said "6 need action" and "Not started", and S8 allows four status words on
// any screen: Needs you, Vert's working, Waiting, Done. So the decisions are said the
// way Month-end's header says them ("6 decisions need you"), and a month nobody has
// started is a client WAITING on its Start, said in a sentence ("July hasn't started")
// rather than as a fifth status — and with no "3 of 12" beside it, because tasks done
// in a month that hasn't started is a count of nothing the row can stand behind.

/** "1 decision needs you" / "6 decisions need you"; null when unread or none. */
export function decisionsWords(client) {
  const n = client && client.decisions;
  if (!isCount(n) || n === 0) return null;
  return n === 1 ? "1 decision needs you" : `${n} decisions need you`;
}

/** Whether the engine says this client's month has not been started (`opened: false`). */
export function notStarted(client) {
  return Boolean(client) && (client.opened === false || client.status === "Not started");
}

/**
 * The status word a row draws: the engine's when it is one of the four, and null
 * otherwise. A month not started draws NO status word (verify pass 2 F25 / pass 3 F15:
 * "Waiting" beside "July hasn't started" said two things about one row); its sentence
 * ("July hasn't started") is its status. An unread client says so in a sentence too.
 */
export function rowStatusWord(client, words) {
  const allowed = Array.isArray(words) ? words : [];
  if (notStarted(client)) return null;
  const w = client && client.status;
  return typeof w === "string" && allowed.includes(w) ? w : null;
}

/** The row's sentence for a month not started ("July hasn't started"), else null. */
export function notStartedWords(client, monthLabel = null) {
  if (!notStarted(client)) return null;
  const month = typeof monthLabel === "string" && monthLabel.trim() ? monthLabel.trim().split(/\s+/)[0] : "This month";
  return `${month} hasn't started`;
}

/**
 * Which month the Clients view opens on (W0c CO-22; eval r3 correctness F5: Priya's
 * opened on October). A firm person's own client may have no months at all (Priya's
 * home is Harbour, a new engagement), so the current client's listing alone sent the
 * view to the calendar month. The firm's current close month is the latest month ANY
 * of its clients has started; this browser's choice wins when some client lists it.
 *
 *   listings   each client's `GET /close/periods`, as arrays of periods; null for a
 *              listing that couldn't be read (left out, never read as "no months")
 *   chosen     this browser's month, or null
 *   fallback   the month to show when no client lists any (the calendar month)
 *
 * Pure.
 */
export function firmMonthToShow(listings, chosen, fallback) {
  const months = new Set();
  for (const listed of Array.isArray(listings) ? listings : []) {
    if (!Array.isArray(listed)) continue;
    for (const p of listed) if (typeof p === "string" && ISO_MONTH.test(p)) months.add(p);
  }
  const valid = typeof chosen === "string" && ISO_MONTH.test(chosen) ? chosen : null;
  if (valid && months.has(valid)) return valid;
  const latest = [...months].sort().at(-1);
  return latest || valid || fallback || null;
}

/**
 * The name a row shows: the business, else the client id in words, by the sidebar's
 * own rule (lib/format.js accountName), so "harbour-co" is "Harbour Co" in the list and
 * in the switcher header alike. Never blank.
 */
export function clientName(client) {
  const name = client && typeof client.name === "string" ? client.name.trim() : "";
  const id = client && typeof client.tenantId === "string" ? client.tenantId : "";
  return accountName({ business: name, tenant: id }) || "A client";
}

/** The two tabs. "Assigned to you" is per person; it is drawn only for a person. */
export const TABS = Object.freeze([
  { key: "all", label: "Every client" },
  { key: "mine", label: "Assigned to you" },
]);

/**
 * The rows a tab shows.
 *
 * `assigned` per client is the number of tasks that client's own `GET /close?assigned=me`
 * listed, or null when that read failed. A client whose assignment could not be read
 * is KEPT under "Assigned to you", marked, rather than dropped: dropping it would say
 * "nothing of yours there", which nobody checked.
 */
export function rowsFor(tab, clients) {
  const list = Array.isArray(clients) ? clients : [];
  if (tab !== "mine") return list;
  return list.filter((c) => c.assigned == null || c.assigned > 0);
}

/**
 * The clients whose name (or id) holds every word of `query`, case- and accent-blind
 * (verify pass 2 S-UI-2: 125 clients and no way to find one but scrolling). An empty
 * query keeps every row. Pure; the order is the list's own.
 */
export function searchClients(clients, query) {
  const list = Array.isArray(clients) ? clients : [];
  const fold = (text) => String(text || "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const words = fold(query).split(/\s+/).filter(Boolean);
  if (!words.length) return list;
  return list.filter((c) => {
    const hay = `${fold(clientName(c))} ${fold(c && c.tenantId)}`;
    return words.every((w) => hay.includes(w));
  });
}

/** The tab to show from a query value: anything but "mine" is All. */
export function tabFrom(value) {
  return value === "mine" ? "mine" : "all";
}

const ISO_MONTH = /^\d{4}-(0[1-9]|1[0-2])$/;

/**
 * Which month a client's pages show, from its months listing and this browser's choice.
 *
 *   listed   the periods `GET /close/periods` listed, or null when that read failed
 *   chosen   the month this browser chose (the month cookie), or null
 *
 * The choice wins when the client lists it; else the latest listed month. A client
 * whose listing ANSWERED WITH NO MONTHS (a new engagement, Harbour in eval r1 #20) has
 * started nothing yet, and that is a measured fact, not a failed read: the chosen month
 * is shown as it stands, and its own `GET /close/{period}` says "Not started", exactly
 * as the Clients view counted it. An unread listing is not an empty one, so it never
 * promotes the choice (null; the caller keeps its own fallback).
 *
 *   fallback the month to offer when the listing answered with no months and this
 *            browser chose none: the current close month (lib/period.js closeMonthOf).
 *            Without it a new client had no month at all, so its first screen had no
 *            Start and its ask box sent `period: null` (G4 eval r1, NF-1st).
 *
 * Pure and shared by Month-end (app/page.js), the sidebar (shell-data.js) and the
 * Clients view, so the row a person pressed and the month they land on agree.
 */
export function monthToShow(listed, chosen, fallback = null) {
  // ONE RULE (verify pass 1, F02/F22): lib/period.js shownMonth. A chosen month the
  // listing does not name is still shown when it is no later than the latest month that
  // can be closed (`fallback`, the current close month) or the month after the latest
  // listed one, so the next month and earlier ones can be reached and started.
  return shownMonth(listed, chosen, fallback);
}

/** The sentence for a client with no months started and no month chosen to show. */
export const NOTHING_STARTED = "No month has been started for this client yet.";

// ── PREPARER AND REVIEWER (design-pass spec §7.3; critique r1 #19) ──
//
// The names the client's own month lists (lib/firm.js listClients). Read and nobody named is said in
// words, "Unassigned"; unread draws nothing, because unread is never "nobody".

/** "Name" or "Name, Name"; "Unassigned" for a read month naming nobody; null when unread. */
export function peopleWords(list) {
  if (!Array.isArray(list)) return null;
  return list.length ? list.join(", ") : "Unassigned";
}

// ── DUE (design-fix-2 DA2-054) ──────────────────────────────────────────────────
// A client's month is due when its last task is: the latest due its own `GET /close`
// lists (lib/firm.js copies each task's `due`). The engine stores a day of the month
// (1–31) or a full date; a close is worked in the month after the one it closes, so
// September's "due 7" is 7 October. Chosen by comparison, never summed. Late is a due
// day before today on a month that is not all done.

/** One stored due as an ISO date, or null. */
export function dueIso(due, period) {
  if (typeof due === "string" && /^\d{4}-\d{2}-\d{2}$/.test(due)) return due;
  if (!(typeof due === "number" && Number.isInteger(due) && due >= 1 && due <= 31)) return null;
  if (!(typeof period === "string" && /^\d{4}-\d{2}$/.test(period))) return null;
  const [py, pm] = period.split("-").map((n) => Number.parseInt(n, 10));
  const y = pm === 12 ? py + 1 : py;
  const m = pm === 12 ? 1 : pm + 1;
  const d = Math.min(due, new Date(Date.UTC(y, m, 0)).getUTCDate());
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

/** `{ text: "7 Oct", iso, late }` for a client's month, or null when no task has a due. */
export function clientDue(client, period, now = new Date()) {
  const dues = client && client.people && Array.isArray(client.people.dues) ? client.people.dues : [];
  let iso = null;
  for (const due of dues) {
    const one = dueIso(due, period || (client && client.period));
    if (one && (!iso || one > iso)) iso = one;
  }
  if (!iso) return null;
  const [y, m, d] = iso.split("-").map((n) => Number.parseInt(n, 10));
  if (!(m >= 1 && m <= 12)) return null;
  const counts = client.counts;
  const allDone = Boolean(counts && counts.total > 0 && counts.done === counts.total);
  const today = now instanceof Date && !Number.isNaN(now.getTime())
    ? `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`
    : null;
  return { text: `${d}\u00a0${MONTHS[m - 1]}`, iso, year: y, late: Boolean(!allDone && today && today > iso) };
}

/**
 * The quick rows with each client's detail laid over them by id (verify pass 3 S-UI-2).
 * Only `assigned` and `people` are taken from the detail; a client the detail doesn't
 * name keeps its quick row as it was. Pure.
 */
export function withDetail(result, detail) {
  if (!result || !result.ok || !detail || !detail.ok || !Array.isArray(detail.clients)) return result;
  if (detail.period && result.period && detail.period !== result.period) return result;
  const byId = new Map(detail.clients.filter((c) => c && c.tenantId).map((c) => [c.tenantId, c]));
  return {
    ...result,
    clients: result.clients.map((c) => {
      const d = c && byId.get(c.tenantId);
      return d ? { ...c, assigned: d.assigned ?? null, people: d.people ?? null } : c;
    }),
  };
}
