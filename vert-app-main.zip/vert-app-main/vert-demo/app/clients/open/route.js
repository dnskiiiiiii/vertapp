// app/clients/open — FOLLOW A LINK INTO ANOTHER CLIENT'S CONVERSATION (W0c CO-22)
// ==============================================================================
// `GET /clients/open?conversation=<id>` (or `?entry=<id>`, the ledger memo's back-link):
// for a person in a firm, find which of the
// firm's clients holds the conversation (resolve.js), switch this browser to it the
// way the Clients view does (lib/firm.js switchClient, proven with the engine before
// it is remembered), and open the conversation there, on its own month.
//
// WHO REACHES THIS. The conversation page, when it answers 404 for a firm person, sends
// the link here once (`?looked=clients` on the way back stops a second trip): wired in
// app/chat/[id]/page.js by that page's owner (W0c's needs_from_others). A tenant key,
// the static build, or a conversation no client holds goes straight back to the page,
// which then says honestly that there is nothing at that address.
//
// IT WRITES NOTHING BUT THIS BROWSER'S CHOICE OF CLIENT AND MONTH. Every read is the
// engine's, under the person's own key; a client the person is not engaged with
// answers 403 and is simply not the answer.

import { NextResponse } from "next/server";
import { conversationUnder, entryUnder } from "@/lib/actions";
import { listClients, switchClient } from "@/lib/firm";
import { chosenClient, readSession, rememberMonth, visibleMonth } from "@/lib/session";
import { closeMonthOf } from "@/lib/period";
import { taskOfId } from "@/app/chat/[id]/missing";
import { CONVERSATION_ID, ENTRY_ID, LINK_CLIENT, conversationPath, entryPath, findConversationClient, findEntryClient, openPlace } from "./resolve";

export const dynamic = "force-dynamic";

const CLIENT_ID = /^[a-z0-9][a-z0-9_-]{0,63}$/;

/**
 * A redirect to a path on THIS host, as a relative Location. `request.url` names the
 * address the server bound (measured: `localhost` behind `next start -H 127.0.0.1`), and
 * an absolute redirect to another host name drops the session cookie, so the person
 * lands on the sign-in screen instead of the conversation.
 */
function to(path) {
  return new NextResponse(null, { status: 307, headers: { Location: path } });
}

/** The firm's client ids, other than none: the list the search walks. */
async function firmClients() {
  const listed = await listClients((await visibleMonth()) || closeMonthOf(new Date()));
  return listed.ok ? listed.clients.map((c) => c && c.tenantId).filter((t) => typeof t === "string" && CLIENT_ID.test(t)) : [];
}

export async function GET(request) {
  const url = new URL(request.url);
  const entry = url.searchParams.get("entry") || "";
  if (entry) return openEntry(entry);
  if (!url.searchParams.has("conversation") && url.searchParams.has("next")) return openPlaceNow(url.searchParams);
  const id = url.searchParams.get("conversation") || "";
  if (!CONVERSATION_ID.test(id)) return to("/");
  // A link that names its client (verify pass 2 S-E2E-3) is followed to THAT client
  // only: the same id under any other client is another client's books.
  const named = url.searchParams.get("client") || "";
  const wanted = LINK_CLIENT.test(named) ? named : null;
  const back = (looked, client = wanted) => to(conversationPath(id, { looked, client }));
  const session = await readSession();
  if (!session || !session.person || !session.firm) return back(true);
  const current = (await chosenClient(session)) || session.tenant;
  const clients = wanted ? (wanted === session.tenant ? [wanted] : (await firmClients()).filter((t) => t === wanted)) : await firmClients();
  // A task's id is the same on every client (verify pass 4, F3): with no client named,
  // a search would land on whichever client holds it. It opens under the client on
  // screen, where the page says whether it is started (app/chat/[id]/missing.js).
  if (!wanted && taskOfId(id)) return back(false, null);
  const found = await findConversationClient({ clients, current: wanted ? null : current, read: (tenant) => conversationUnder(tenant, id) });
  if (!found) {
    // NOT STARTED THERE YET (S-E2E-2): the link names a client of this firm and a task it
    // hasn't opened. The person chose that client by the link, so the browser switches to
    // it as for a found one, and the page then offers to open the task there; it is never
    // refused as "another client's conversation".
    if (wanted && clients.includes(wanted) && wanted !== current && taskOfId(id)) {
      const switched = await switchClient(wanted, { period: taskOfId(id).period });
      if (switched && switched.ok) return back(false, wanted);
    }
    return back(true);
  }
  const switched = await switchClient(found.tenant, { period: found.period });
  return back(!(switched && switched.ok), found.tenant);
}

/**
 * `?entry=je:…` — the ledger memo's back-link, sent here by Records when the entry is not
 * under the client this browser is on (verify pass 1 F-4, P19). Every way out lands on
 * Records marked as looked for, so a link no client holds is said once, never looped.
 */
async function openEntry(id) {
  if (!ENTRY_ID.test(id)) return to("/records?tab=entries");
  const back = (period = null) => to(entryPath(id, { period }));
  const session = await readSession();
  if (!session || !session.person || !session.firm) return back();
  const current = (await chosenClient(session)) || session.tenant;
  const clients = await firmClients();
  const found = await findEntryClient({ clients, current, read: (tenant) => entryUnder(tenant, id) });
  if (!found) return back();
  const switched = await switchClient(found.tenant, { period: found.period });
  return back(switched && switched.ok ? found.period : null);
}

/**
 * `?client=<tenant>&period=<month>&next=<path>` — put a place back, then go on (verify
 * pass 5, S-CF-9 F3 and S-E2E-3 F12): resolve.js `openPlace` says what, this does it.
 */
async function openPlaceNow(params) {
  return to(await openPlace(params, { switchTo: switchClient, remember: rememberMonth }));
}
