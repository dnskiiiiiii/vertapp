// app/clients/open/resolve.js — WHICH OF THE FIRM'S CLIENTS HOLDS THIS CONVERSATION?
// ==============================================================================
// W0c CO-22 (eval r3 correctness F5). Priya, whose own client is Harbour, opened Sam's
// link into a Northwind conversation and read "There's nothing at this address": the
// conversation was read under the client her browser was on, and it lives under
// another. A firm person may open any of the firm's clients, so the link is followed
// the way the reference follows it — find the client that holds the conversation,
// switch to it, then open it (route.js). Nothing here guesses: a client is the answer
// only when reading the conversation UNDER that client answers 200. Pure, with the read
// injected, so tests drive it without a server.

import { isLinkClient, isLinkMonth, safeNext, withoutClient } from "@/lib/return-path";

/** The shape a conversation id has in a link (`/chat/<id>`): never a path, never empty. */
export const CONVERSATION_ID = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;

/**
 * The first client (other than `current`, which already said not found) under which
 * `read(tenant)` finds the conversation: `{ tenant, period }`, or null.
 *
 * `read(tenant)` answers `{ status, period? }` — the status of
 * `GET /agent/sessions/{id}` under that client, and the conversation's month when it
 * was found. Any answer but 200 is "not here": a 403 (not engaged), a 404, a failure.
 * Clients are tried in order, one at a time, and the first that holds it wins.
 */
export async function findConversationClient({ clients, current = null, read }) {
  const list = Array.isArray(clients) ? clients : [];
  for (const tenant of list) {
    if (typeof tenant !== "string" || !tenant || tenant === current) continue;
    let answer = null;
    try {
      answer = await read(tenant);
    } catch {
      answer = null;
    }
    if (answer && answer.status === 200) {
      const period = typeof answer.period === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(answer.period) ? answer.period : null;
      return { tenant, period };
    }
  }
  return null;
}

/** The shape of a client id in a link (lib/session.js isClientId, held equal). */
export const LINK_CLIENT = /^[a-z0-9][a-z0-9_-]{0,61}[a-z0-9]$/;

/**
 * Where the link goes after the search: the conversation, marked as already looked for
 * when nothing held it, and naming the client it was opened under (verify pass 2
 * S-E2E-3) so the address read back from the bar is that client's conversation.
 */
export function conversationPath(id, { looked = false, client = null } = {}) {
  const q = new URLSearchParams();
  if (typeof client === "string" && LINK_CLIENT.test(client)) q.set("client", client);
  if (looked) q.set("looked", "clients");
  const query = q.toString();
  return `/chat/${encodeURIComponent(id)}${query ? `?${query}` : ""}`;
}

// ── A CONVERSATION LINK NAMES ITS CLIENT (verify pass 2 S-E2E-3) ───────────────────────
// A task conversation's id is the same on every client (`2026-07-approve_entries`), so
// `/chat/<id>` alone named no books: opened while this browser was on Stresslab, Fresh
// Start's link showed Stresslab's thread. The address now carries `?client=<tenant>`,
// and the page decides by it BEFORE reading anything:
//
//   open     the link names no client (an in-app link: the client on screen), or the
//            client this browser is on.
//   switch   it names another client and the person is in a firm: the client search
//            (route.js) proves the switch with the engine, then opens it there.
//   refuse   it names another client and cannot be switched to (a tenant key, or the
//            search already came back): Vert says so and opens nothing.

/** What the conversation page does with the client its link names. Pure. */
export function chatClientDecision({ wanted, current, inFirm = false, looked = false }) {
  if (typeof wanted !== "string" || !LINK_CLIENT.test(wanted)) return "open";
  if (wanted === current) return "open";
  if (inFirm && !looked) return "switch";
  return "refuse";
}

/** The client search for a link that names its client: only that client is tried. */
export function linkClientPath(id, client) {
  const q = new URLSearchParams({ conversation: id, client });
  return `/clients/open?${q.toString()}`;
}

// ── PUT A PLACE BACK, THEN GO ON (verify pass 5, S-CF-9 F3 and S-E2E-3 F12) ─────────────
// `/clients/open?client=<tenant>&period=<month>&next=<path>` (lib/return-path.js placeHop).
// Two callers. Signing in again after a session expired: the proxy carried the client
// and month this browser had open, and they are put back for the new session. And a page
// address that named a client (`/?client=X`): the proxy sends it here so the address is
// honoured or stripped, never left contradicting the header.
//
// The client is PROVEN with the engine under this session's key before it is remembered
// (`switchTo` is lib/firm.js switchClient), exactly as a switch from the Clients view is:
// a client this key cannot reach is refused and the browser stays where it was. A month
// on its own is a preference and is simply remembered. Either way the person lands on
// `next` with `client` stripped, so nothing loops and the address never names a client
// the header does not.

/** Do the hop: switch (proven) and/or remember the month; answers the path to land on. */
export async function openPlace(params, { switchTo, remember }) {
  const next = withoutClient(safeNext(params.get("next") || "") || "/") || "/";
  const named = params.get("client");
  const month = params.get("period");
  const period = isLinkMonth(month) ? month : null;
  try {
    if (isLinkClient(named)) await switchTo(named, { period });
    else if (period) await remember(period);
  } catch {
    // A switch that failed to complete leaves the browser where it was; the page still opens.
  }
  return next;
}

// ── THE LEDGER MEMO'S BACK-LINK (verify pass 1 F-4, P19) ───────────────────────────────
// `/records?tab=entries&entry=je:…` (vert_api/main.py VERT_ENTRY_PATH) names the entry
// and not the client, so opened while this browser was on another client it read "isn't
// among the journal entries Vert read just now". It is followed like a conversation
// link: the client that answers 200 for `GET /journal/{id}` holds it, the browser is
// switched there, and Records opens the entry. The same search, with another read.

/** The shape of an entry id in the back-link: a kind, a colon, hex (vert_api journal.py _ENTRY_ID). */
export const ENTRY_ID = /^[a-z]{1,16}:[0-9a-f]{6,64}$/;

/** Which client holds the entry: the same first-answer-200 search as a conversation's. */
export const findEntryClient = findConversationClient;

/**
 * Where an entry link goes after the search: Records' Journal entries tab with the entry
 * open, marked as already looked for (`looked=clients`) so Records never sends it back.
 */
export function entryPath(id, { period = null } = {}) {
  const q = new URLSearchParams({ tab: "entries", entry: id, looked: "clients" });
  if (typeof period === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(period)) q.set("period", period);
  return `/records?${q.toString()}`;
}

/**
 * Whether Records should send an entry link to the client search: an entry was named,
 * it was not found under the client this browser is on (a 404, measured — never a failed
 * read), the person is in a firm, and the link has not been looked for already.
 */
export function shouldLookForEntry({ entryId, status, inFirm, looked }) {
  return Boolean(inFirm) && !looked && typeof entryId === "string" && ENTRY_ID.test(entryId) && status === 404;
}
