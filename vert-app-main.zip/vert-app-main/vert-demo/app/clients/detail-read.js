// app/clients/detail-read.js — WHO PREPARES AND REVIEWS EACH CLIENT, READ WITH A GET
// ==============================================================================
// Clients draws its rows from the page's one read, then lays the prepare/review detail
// over them. That second read was the `readClientsDetail` Server Action, called from an
// effect: a POST on every arrival at Clients, with a fresh render of the page riding
// back (found by tests/p0-quiet-page-load.test.js, 28 Oct 2026). It is now a GET to
// app/api/firm?view=detail, which calls the same function on the server, so the key
// stays there. A read that failed is null: the quick rows stay as they were, and no
// client is drawn as having nobody assigned.

/** `{ ok, period, clients }` or null. Never throws. */
export async function readClientsDetailByGet(period, fetchImpl = null) {
  const doFetch = fetchImpl || (typeof window !== "undefined" && typeof window.fetch === "function" ? window.fetch.bind(window) : null);
  if (!doFetch || typeof period !== "string" || !period) return null;
  try {
    const response = await doFetch(`/api/firm?view=detail&period=${encodeURIComponent(period)}`, {
      method: "GET",
      headers: { accept: "application/json" },
      cache: "no-store",
      credentials: "same-origin",
    });
    const body = response && typeof response.json === "function" ? await response.json().catch(() => null) : null;
    return response && response.ok && body && body.ok === true && Array.isArray(body.clients) ? body : null;
  } catch {
    return null;
  }
}
