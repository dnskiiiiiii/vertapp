// app/reports/account-transactions — ACCOUNT TRANSACTIONS, FULL WIDTH, PRINTABLE
// ==============================================================================
// Close checklist Step 4.2 (w31, 3 Nov 2026). Every transaction line on the accounts
// named over a date range, read from Xero for the request, laid out as Xero's Account
// Transactions (opening, lines with running balance, closing), each account tied to its
// movement in the books, lines that look miscoded marked. Reached from an Account
// Transactions answer's "Open account transactions" and the trial balance.
//
// `?accounts=453,090&from=YYYY-MM-DD&to=YYYY-MM-DD`. Read here, on the server, with the
// key (lib/reports.js). Nothing here writes. A list that may be short says so, per
// account, in the engine's words.

import Link from "next/link";
import AccountTransactions from "@/components/reports/AccountTransactions";
import PrintButton from "@/components/reports/PrintButton";
import { AccountTransactionsForm } from "@/components/reports/ReportForms";
import { accountTransactionsOf } from "@/components/reports/account-transactions";
import "@/components/reports/reports.css";
import { IconCaretLeft } from "@/components/ui/icons";
import { ISO_DAY, readAccountTransactions } from "@/lib/reports";
import { AUTH_REQUIRED } from "@/lib/session";

export const metadata = { title: "Account transactions · Vert" };
export const maxDuration = 60;

export default async function AccountTransactionsPage({ searchParams }) {
  const query = (searchParams && (await searchParams)) || {};
  const accounts = typeof query.accounts === "string" ? query.accounts : "";
  const from = typeof query.from === "string" && ISO_DAY.test(query.from) ? query.from : "";
  const to = typeof query.to === "string" && ISO_DAY.test(query.to) ? query.to : "";
  if (!AUTH_REQUIRED) return <Frame q={{ accounts, from, to }} words="These are the sample books, with no Vert service behind them, so there are no transactions to read here." />;
  if (!accounts || !from || !to) return <Frame q={{ accounts, from, to }} words="Name an account and a date range." />;
  const read = await readAccountTransactions(accounts, from, to);
  if (!read.ok) return <Frame q={{ accounts, from, to }} words={read.message} />;
  if (!accountTransactionsOf(read.body)) return <Frame q={{ accounts, from, to }} words="Vert's account transactions couldn't be read as they were sent, so they aren't drawn here." />;
  return (
    <Frame q={{ accounts, from, to }} printable>
      <AccountTransactions accountTransactions={read.body} />
    </Frame>
  );
}

function Frame({ q, words = null, printable = false, children = null }) {
  const period = q.to ? q.to.slice(0, 7) : null;
  return (
    <div className="page statements-page reports-page" data-reports-page="account-transactions">
      <Link className="link statements-back t-footnote" href={period ? `/reports/trial-balance?asAt=${q.to}` : "/reports/trial-balance"}>
        <IconCaretLeft aria-hidden="true" />
        <span>Trial balance</span>
      </Link>
      <header className="page-head">
        <div>
          <h1 className="t-title-1">Account transactions</h1>
          <p className="page-head-sub">Every line on the accounts named, read from your ledger.</p>
        </div>
        <div className="reports-actions">
          <AccountTransactionsForm accounts={q.accounts} from={q.from} to={q.to} />
          {printable ? <PrintButton /> : null}
        </div>
      </header>
      {words ? (
        <p className="statements-unread t-body" role="status" data-report-unread="">
          {words}
        </p>
      ) : null}
      {children}
    </div>
  );
}
