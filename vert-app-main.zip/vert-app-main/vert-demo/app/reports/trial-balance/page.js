// app/reports/trial-balance — THE TRIAL BALANCE, FULL WIDTH, PRINTABLE
// ==============================================================================
// Close checklist Step 4.1 (w31, 3 Nov 2026). Every account's balance as at a date,
// laid out as Xero's Trial Balance, with each unusual balance flagged on its row; the
// same card a "run a trial balance" answer draws in the chat. Press an account and its
// Account Transactions open beside it (components/reports/TrialBalanceView.js).
//
// WHICH DATE: `?asAt=YYYY-MM-DD`, else the end of last month (the engine's default).
// Reached from Month-end (components/shell/ia.js MONTH_END_SECTION) and from a trial
// balance answer's "Open the trial balance". Read here, on the server, with the key
// (lib/reports.js). Nothing on this page writes. A read that failed is said in words,
// never drawn as a trial balance of zeros.

import Link from "next/link";
import TrialBalanceView from "@/components/reports/TrialBalanceView";
import PrintButton from "@/components/reports/PrintButton";
import { TrialBalanceDateForm } from "@/components/reports/ReportForms";
import { trialBalanceOf } from "@/components/reports/trial-balance";
import "@/components/reports/reports.css";
import { IconCaretLeft, IconDownload } from "@/components/ui/icons";
import { ISO_DAY, readTrialBalance } from "@/lib/reports";
import { AUTH_REQUIRED } from "@/lib/session";

export const metadata = { title: "Trial balance · Vert" };
export const maxDuration = 60;

export default async function TrialBalancePage({ searchParams }) {
  if (!AUTH_REQUIRED) return <Frame asAt={null} words="These are the sample books, with no Vert service behind them, so there is no trial balance to read here." />;
  const query = (searchParams && (await searchParams)) || {};
  const asked = typeof query.asAt === "string" && ISO_DAY.test(query.asAt) ? query.asAt : null;
  const read = await readTrialBalance(asked);
  if (!read.ok) return <Frame asAt={asked} words={read.message} />;
  const tb = trialBalanceOf(read.body);
  if (!tb) return <Frame asAt={asked} words="Vert's trial balance couldn't be read as it was sent, so it isn't drawn here." />;
  return (
    <Frame asAt={tb.asAt} title={tb.title}>
      <TrialBalanceView trialBalance={read.body} />
    </Frame>
  );
}

function Frame({ asAt, title = null, words = null, children = null }) {
  const period = asAt ? asAt.slice(0, 7) : null;
  return (
    <div className="page statements-page reports-page" data-reports-page="trial-balance">
      <Link className="link statements-back t-footnote" href={period ? `/?period=${period}` : "/"}>
        <IconCaretLeft aria-hidden="true" />
        <span>Month-end</span>
      </Link>
      <header className="page-head">
        <div>
          <h1 className="t-title-1">Trial balance</h1>
          <p className="page-head-sub">{title || "Every account's balance as at a date."}</p>
        </div>
        <div className="reports-actions">
          <TrialBalanceDateForm asAt={asAt || ""} />
          {asAt && !words ? (
            <>
              <a className="btn btn-quiet btn-sm" href={`/api/reports/trial-balance?asAt=${asAt}&format=xlsx`} download data-report-download="xlsx">
                <IconDownload aria-hidden="true" />
                <span>Excel</span>
              </a>
              <PrintButton />
            </>
          ) : null}
        </div>
      </header>
      {words ? (
        <p className="statements-unread t-body" role="status" data-report-unread="">
          {words}
        </p>
      ) : null}
      {children}
    </div>
  );
}
