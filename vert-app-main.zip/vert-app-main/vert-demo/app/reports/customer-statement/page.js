// app/reports/customer-statement — ONE CUSTOMER'S STATEMENT, FULL WIDTH, PRINTABLE
// ==============================================================================
// Function-fidelity audit row 20 (w46, 4 Nov 2026). Reached from a statement answer's
// "Open statement": `?contact=ID&to=YYYY-MM-DD` is the outstanding statement as at that
// day, and `&from=YYYY-MM-DD` makes it the activity statement for the period. Read here,
// on the server, with the key (lib/reports.js). Every line, Balance due, the ageing and
// the PDF and Excel downloads.
//
// Nothing here sends anything: a statement goes to a customer only attached to their
// payment reminder, on a person's Approve & send. Unread is said in the engine's words.

import Link from "next/link";
import CustomerStatement from "@/components/reports/CustomerStatement";
import PrintButton from "@/components/reports/PrintButton";
import { customerStatementOf } from "@/components/reports/customer-statement";
import "@/components/reports/reports.css";
import { IconCaretLeft } from "@/components/ui/icons";
import { ISO_DAY, readCustomerStatement } from "@/lib/reports";
import { AUTH_REQUIRED } from "@/lib/session";

export const metadata = { title: "Statement · Vert" };
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const CONTACT = /^[A-Za-z0-9-]{1,64}$/;

function today() {
  // The engine judges "a day to come" in the client's own zone; the page only fills the
  // default, the firm's day (lib/format's display calendar is Sydney's).
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Australia/Sydney" }).format(new Date());
}

export default async function CustomerStatementPage({ searchParams }) {
  const query = (searchParams && (await searchParams)) || {};
  const day = (v) => (typeof v === "string" && ISO_DAY.test(v) ? v : "");
  const contact = typeof query.contact === "string" && CONTACT.test(query.contact) ? query.contact : "";
  const from = day(query.from);
  const to = day(query.to) || today();
  if (!contact) return <Frame words="Ask Vert for a customer's statement in the chat, as in “statement for Bayside Club”, and open it from there." />;
  if (!AUTH_REQUIRED) return <Frame words="These are the sample books, with no Vert service behind them, so there is no statement to read here." />;
  const read = await readCustomerStatement(contact, from || null, to);
  if (!read.ok) return <Frame words={read.message} />;
  const s = customerStatementOf(read.body);
  if (!s) return <Frame words="Vert's statement couldn't be read as it was sent, so it isn't drawn here." />;
  return (
    <Frame name={s.contactName} printable={s.measured === true}>
      <CustomerStatement customerStatement={read.body} />
    </Frame>
  );
}

function Frame({ name = null, words = null, printable = false, children = null }) {
  return (
    <div className="page statements-page reports-page" data-reports-page="customer-statement">
      <Link className="link statements-back t-footnote" href="/">
        <IconCaretLeft aria-hidden="true" />
        <span>Back</span>
      </Link>
      <header className="page-head">
        <div>
          <h1 className="t-title-1">{name ? `Statement for ${name}` : "Customer statement"}</h1>
        </div>
        <div className="reports-actions">{printable ? <PrintButton /> : null}</div>
      </header>
      {words ? (
        <p className="statements-unread t-body" role="status" data-report-unread="">
          {words}
        </p>
      ) : null}
      {children}
    </div>
  );
}
