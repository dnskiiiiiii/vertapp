// app/reports/gst — THE GST REPORT, FULL WIDTH, PRINTABLE
// ==============================================================================
// Function-fidelity audit row 22 (w42, 4 Nov 2026). GST for a month or a quarter by tax
// rate, GST collected and paid, the GST account's net movement tied to them, and the
// checks to run first — read from the ledger for the request. Reached from a GST
// report answer's "Open the GST report".
//
// `?from=YYYY-MM-DD&to=YYYY-MM-DD`; without them, last month. Read here, on the server,
// with the key (lib/reports.js). Nothing here writes, and it files nothing anywhere: a
// report for checking. A report that may be short says so in the engine's words.

import Link from "next/link";
import GstReport from "@/components/reports/GstReport";
import PrintButton from "@/components/reports/PrintButton";
import { GstReportForm } from "@/components/reports/ReportForms";
import { gstReportOf } from "@/components/reports/gst-report";
import "@/components/reports/reports.css";
import { IconCaretLeft } from "@/components/ui/icons";
import { closeMonthOf, periodEnd } from "@/lib/period";
import { ISO_DAY, readGstReport } from "@/lib/reports";
import { AUTH_REQUIRED } from "@/lib/session";

export const metadata = { title: "GST report · Vert" };
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export default async function GstReportPage({ searchParams }) {
  const query = (searchParams && (await searchParams)) || {};
  const asked = (v) => (typeof v === "string" && ISO_DAY.test(v) ? v : "");
  const month = closeMonthOf(new Date());
  const from = asked(query.from) || `${month}-01`;
  const to = asked(query.to) || periodEnd(month);
  if (!AUTH_REQUIRED) return <Frame q={{ from, to }} words="These are the sample books, with no Vert service behind them, so there is no GST to read here." />;
  const read = await readGstReport(from, to);
  if (!read.ok) return <Frame q={{ from, to }} words={read.message} />;
  const report = gstReportOf(read.body);
  if (!report) return <Frame q={{ from, to }} words="Vert's GST report couldn't be read as it was sent, so it isn't drawn here." />;
  return (
    <Frame q={{ from, to }} span={report.span} printable>
      <GstReport gstReport={read.body} />
    </Frame>
  );
}

function Frame({ q, span = null, words = null, printable = false, children = null }) {
  return (
    <div className="page statements-page reports-page" data-reports-page="gst">
      <Link className="link statements-back t-footnote" href={`/?period=${q.to.slice(0, 7)}`}>
        <IconCaretLeft aria-hidden="true" />
        <span>Month-end</span>
      </Link>
      <header className="page-head">
        <div>
          <h1 className="t-title-1">GST report</h1>
          <p className="page-head-sub">{span ? `GST by tax rate for ${span}, tied to the GST account.` : "GST by tax rate, tied to the GST account."}</p>
        </div>
        <div className="reports-actions">
          <GstReportForm from={q.from} to={q.to} />
          {printable ? <PrintButton /> : null}
        </div>
      </header>
      {words ? (
        <p className="statements-unread t-body" role="status" data-report-unread="">
          {words}
        </p>
      ) : null}
      {children}
    </div>
  );
}
