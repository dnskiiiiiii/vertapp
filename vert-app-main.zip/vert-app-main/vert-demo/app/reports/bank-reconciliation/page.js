// app/reports/bank-reconciliation — THE BANK RECONCILIATION REPORT
// ==============================================================================
// Every bank and card account as at the month's end, against its real statement, in
// Xero's layout: the summary, then each outstanding item (w29-contract.md). The chat's
// "bank reconciliation report" answer links here.
//
//   ?period=YYYY-MM[&account=<code, name or statement account>]
//
// Without `period`, the month Month-end shows, by the sidebar's rule (as
// app/reconciliation/bank/cash-coding/page.js). READ HERE, ON THE SERVER, WITH THE KEY
// (lib/bank-rec-report.js). A read that failed is said in words, never drawn as tied.

import BankRecReport from "@/components/reports/BankRecReport";
import { monthAsked } from "@/components/month/month-reads";
import { readBankRecReport } from "@/lib/bank-rec-report";
import { readLedger } from "@/lib/ledger";
import { closeMonthOf, isPeriod, shownMonth } from "@/lib/period";
import { AUTH_REQUIRED, sessionGet, visibleMonth } from "@/lib/session";

export const metadata = { title: "Bank reconciliation · Vert" };
export const dynamic = "force-dynamic";
// Each account's reconciliation is read from the books, so the first read may take a while.
export const maxDuration = 60;

async function shownPeriod() {
  const [read, chosen] = await Promise.all([sessionGet("/close/periods"), visibleMonth()]);
  const body = read.ok ? read.body : null;
  const list = Array.isArray(body) ? body : body && Array.isArray(body.periods) ? body.periods : null;
  if (!list) return isPeriod(chosen) ? chosen : null;
  return shownMonth(list.map((m) => m && m.period).filter(isPeriod), chosen, closeMonthOf(new Date()));
}

export default async function BankRecReportPage({ searchParams }) {
  const query = (searchParams && (await searchParams)) || {};
  const raw = Array.isArray(query.account) ? query.account[0] : query.account;
  const account = typeof raw === "string" && raw.trim() ? raw.trim() : null;
  const period = monthAsked(query) || (AUTH_REQUIRED ? await shownPeriod() : null);
  if (!period) {
    return <BankRecReport initial={{ ok: false, message: "Vert couldn't tell which month to show. Open the report from Month-end." }} />;
  }
  const [read, ledger] = await Promise.all([readBankRecReport({ account, period }), readLedger()]);
  const ledgerName = ledger && ledger.configured === true && typeof ledger.displayName === "string" ? ledger.displayName : null;
  return <BankRecReport initial={read} ledgerName={ledgerName} />;
}
