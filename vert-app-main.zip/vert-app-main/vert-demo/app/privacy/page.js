// app/privacy/page.js — THE PUBLIC PRIVACY POLICY URL
// ==============================================================================
// Shopify Level 1 requirement #7 and Intuit's app review both require a privacy policy
// at a public URL. Vert has no domain, so the platform serves it: this route IS the URL
// that goes on both applications.
//
// It is reachable with no account. `proxy.js` lets it past the session gate AND past
// the shared demo password, and `app/layout.js` draws it with no product chrome, so
// nothing about it depends on a session, a tenant or the engine being reachable. See
// lib/public-docs.js for the pair of decisions that make that true.

import PolicyDocument from "@/components/legal/PolicyDocument";
import { SOURCE, TITLE } from "@/lib/policies/privacy-policy";

export const metadata = {
  title: "Privacy policy (draft) · Vert",
  description:
    "How Vert handles merchant and order data in payout reconciliation. A working draft: unestablished facts are marked in place, not guessed at.",
  // NOT INDEXED, AND THAT IS NOT A CONTRADICTION OF "PUBLIC". Public means any person
  // with the URL can read it without an account, which is what a vendor reviewer needs.
  // A draft policy full of unestablished facts, ranking in a search for "Vert privacy
  // policy", is a different thing and not a thing anybody asked for. Remove this when
  // the document is finished and the facts are real.
  robots: { index: false, follow: false },
};

export default function PrivacyPage() {
  return <PolicyDocument source={SOURCE} title={TITLE} />;
}
