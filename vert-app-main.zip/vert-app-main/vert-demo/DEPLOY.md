# Deploying the demo

**Never run `vercel deploy` in this directory without `--scope`.** The CLI's
current login is `vansh-6201`, whose only scope contains Pivotal's live
production sites including `portal.pivotalconversations.ai`. An unscoped deploy
lands there.

## One-time setup

1. Sign in to your **personal** Vercel account in a browser.
2. Create a token: Account Settings → Tokens → Create. Scope it to that account,
   short expiry is fine.
3. Find that account's scope slug: Settings → General → "Vercel ID", or run
   `vercel teams ls --token=YOUR_TOKEN`.

Using a token rather than `vercel login` is deliberate — the CLI holds one login
at a time, so logging in would sign you out of the Pivotal account you use daily.

## Deploy

```bash
cd vert-demo

export VERCEL_TOKEN=...        # personal account token
export VERT_SCOPE=...          # personal scope slug

# Confirm the token points where you think it does BEFORE deploying.
vercel whoami --token=$VERCEL_TOKEN

# First deploy — creates the project. Answer "vert-demo" to the name prompt.
vercel --token=$VERCEL_TOKEN --scope=$VERT_SCOPE

# Production
vercel --prod --token=$VERCEL_TOKEN --scope=$VERT_SCOPE
```

`vercel whoami` before every first deploy of a session. It is the only step that
prevents the mistake this file exists to prevent.

## What ships

`.vercelignore` excludes `*.md` and `design-refs/` — strategy docs and Dawoud's
Notion design exports are not ours to publish and are not needed at runtime.
There is no `public/` directory, no `.env`, and no credentials in source.

## Data source — the live demo runs against the API

**The live demo is API-backed.** Its Vercel project sets `NEXT_PUBLIC_VERT_API_URL`
to the deployed `vert_api`, and every page reads that tenant's books per request: there
is a sign-in screen, and approvals, posts and syncs are real writes against the API.
This file used to say the opposite (leave the variable unset); that described the
original static showpiece, not what is deployed (go-live security review, L5).

Setting the variable does three things, and all three are deliberate:

1. **It chooses the data source.** There is deliberately **no fallback**: if the URL is
   unreachable, every route serves a page that names the URL it tried and shows no
   figures at all, rather than quietly rendering file figures under a live banner.
2. **It turns the sign-in gate on.** Every route redirects to `/login` until a key is
   verified by the API. Run the API **authenticated** (see "The trap" below).
3. **It needs `VERT_SESSION_SECRET`.** A production server (`next start`) with the URL
   set and no secret **refuses** to seal or open a session (`lib/session-seal.js`
   `SessionSecretMissing`, build plan §20.12 L1): the first sign-in fails with a log
   line naming the variable. Set it to a long random string, the same value on every
   instance. `next build` does not need it.

`NEXT_PUBLIC_*` is inlined into the client bundle at build time, so the variable must
be set for the **build** as well as the server; a build made without it is the static
showpiece below whatever the server says.

### The static showpiece (no API)

With `NEXT_PUBLIC_VERT_API_URL` unset the demo reads `lib/engine-output.json`, needs
no backend and has no sign-in: a recorded close, with every write disabled and its
reason on the control. Use it only for a deployment that is meant to have no books
behind it, and never set the variable on such a project without the API it names.

The two modes differ in one further way that is visible in `next build`:

| | static (no URL) | API mode (the live demo) |
|---|---|---|
| routes | prerendered `○` except `/payouts` `ƒ` (it reads `searchParams`) | every route `ƒ` |
| reads | the file, in the bundle | the API, **per request** |
| writes | disabled, with the reason on the control | Approve / Reject / Post / Sync POST to the API |
| sign-in | none | required; sessions need `VERT_SESSION_SECRET` |

The whole of the switch is in three modules: `lib/engine-source.js` (which source, and
the write requests), `lib/engine-server.js` (when the read happens, and why the routes
go dynamic) and `lib/engine-context.js` (how the payload reaches the browser). Each one
carries its reasoning in its header.

## Access

The deployment is **open** — anyone with the URL can view it. The URL is
unlisted, not private.

`proxy.js` contains a basic-auth gate that is **inert unless `DEMO_USER` and
`DEMO_PASS` are set** in Vercel project env vars. To lock it down later, set both
and redeploy. To confirm which state you are in, load the URL in a private window.

Because it is open: don't paste the link anywhere indexable, and delete the
project when the demo period ends.

## After deploying

Sign in on the live URL with a test tenant's key and walk Month-end, a conversation
and an approval before sharing it. A sign-in that fails with a server error is the
missing `VERT_SESSION_SECRET` refusal above.

---

## Running against a real Vert service

This section is the API-backed deployment in detail — the live demo's mode — and the
variables it reads. It exists
because on 2026-08-06 the product was driven end to end this way — signed in, synced,
approved and posted — and the variables that make that work were documented in
`vert-engine/DEPLOY.md` and nowhere on this side.

### The trap, first

`NEXT_PUBLIC_VERT_API_URL` does two things, and only the first is obvious. It chooses
the data source **and** it turns the sign-in gate on: in API mode every route redirects
to `/login`. The sign-in screen then asks the API to verify the pasted key — and if the
API is running with `VERT_ALLOW_UNAUTHENTICATED=1` it correctly refuses, because there
is no authenticator to verify against.

**Two correct refusals, and nobody reaches a screen.** Measured in a browser. If you set
the URL, run the API **authenticated**.

### Server variables

Read by `next start`. None of them is `NEXT_PUBLIC_`, so none reaches the browser.

| Variable | Required | What happens without it |
|---|---|---|
| `NEXT_PUBLIC_VERT_API_URL` | **yes, for the live demo** (build and server) | Static mode: the committed sample close, no sign-in, no writes. |
| `VERT_SESSION_SECRET` | **yes, in API mode** | A production server refuses to seal or open sessions (`SessionSecretMissing`): no one can sign in, and the log names the variable. In development the demo generates a per-process key and warns. |
| `VERT_SYNC_WORKER_URL` | for the Sync button | The button renders and says plainly that no worker is configured. Nothing is sent. |
| `VERT_SYNC_TOKEN` | with the above | The worker refuses the call. Service-to-service only — the browser never sees it. |
| `VERT_SYNC_TENANT` | with the above | Which tenant the worker writes into. |
| `DEMO_USER` / `DEMO_PASS` | no | The basic-auth gate stays inert. |

**`VERT_SYNC_TENANT` must name the same tenant as the API key the browser signs in
with.** Nothing enforces the agreement. A demo configured for one tenant against an API
answering for another renders one tenant's figures beside a button that writes into the
other's books — reproduced, and it is a wrong number on screen rather than an error.

### The known gap in the freshness line

`components/sync/actions.js registerFreshness()` fetches `${API_BASE_URL}/sync/status`
with **no credential and no tenant header**, so it answers for the API's default tenant
rather than for the signed-in one. On an authenticated deployment the API refuses it,
which is safe; on an open one it can report a different tenant's register. It needs
`lib/session.js authHeaders()`. Not fixed.
