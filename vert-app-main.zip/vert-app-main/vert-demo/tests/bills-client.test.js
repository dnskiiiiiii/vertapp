// tests/bills-client.test.js — THE BROWSER'S CALLS TO /api/bills (lib/bills-client.js)
// ==============================================================================
// The screen asks only this app's routes. Each call's path, method and body is held
// here, ids are checked before a path is built, a bad request is refused without a
// fetch, and every answer (a refusal, a dropped connection) returns rather than throws.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import * as api from "../lib/bills-client.js";
import { ID, ID2, item, json, recordingFetch } from "./bills-fixtures.js";

const ok = (body = {}) => json({ ok: true, ...body });

test("each call goes to its route with its method and body", async () => {
  const { calls, fetchImpl } = recordingFetch(() => ok({ item: item(), items: [], results: [] }));
  await api.listInbox({ fetchImpl });
  await api.listInbox({ status: "sent", fetchImpl });
  await api.listInbox({ status: "sent&evil=1", fetchImpl });
  await api.readItem(ID, { refresh: true, fetchImpl });
  await api.save(ID, { document: { dueDate: "2026-11-30" } }, { fetchImpl });
  await api.approve(ID, { fetchImpl });
  await api.approveMany([ID, ID2, ID], { fetchImpl });
  await api.discard(ID, { fetchImpl });
  assert.deepEqual(
    calls.map((c) => [c.init.method, c.url]),
    [
      ["GET", "/api/bills"],
      ["GET", "/api/bills?status=sent"],
      ["GET", "/api/bills"],
      ["GET", `/api/bills/${ID}?refresh=1`],
      ["PATCH", `/api/bills/${ID}`],
      ["POST", `/api/bills/${ID}/approve`],
      ["POST", "/api/bills/approve"],
      ["POST", `/api/bills/${ID}/discard`],
    ]
  );
  assert.deepEqual(JSON.parse(calls[4].init.body), { document: { dueDate: "2026-11-30" } });
  assert.deepEqual(JSON.parse(calls[6].init.body), { itemIds: [ID, ID2] });
  for (const c of calls) assert.equal(c.init.credentials, "same-origin");
});

test("upload sends every file under `files`, with the kind, and no content-type of its own", async () => {
  const { calls, fetchImpl } = recordingFetch(() => ok({ items: [item()], refused: [], emails: [] }));
  const a = new File(["%PDF"], "a.pdf", { type: "application/pdf" });
  const b = new File(["From: x"], "fwd.eml", { type: "message/rfc822" });
  const out = await api.upload([a, b], { kind: "invoice", fetchImpl });
  assert.equal(out.ok, true);
  const [c] = calls;
  assert.equal(c.url, "/api/bills");
  assert.equal(c.init.method, "POST");
  assert.deepEqual(c.init.body.getAll("files").map((f) => f.name), ["a.pdf", "fwd.eml"]);
  assert.equal(c.init.body.get("kind"), "invoice");
  assert.equal(c.init.headers["content-type"], undefined);
  await api.upload([a], { kind: "anything", fetchImpl });
  assert.equal(calls[1].init.body.get("kind"), "bill");
});

test("a bad id, an empty batch or too many are refused without a fetch", async () => {
  const { calls, fetchImpl } = recordingFetch(() => ok());
  for (const out of [
    await api.readItem("../x", { fetchImpl }),
    await api.save("x", { document: {} }, { fetchImpl }),
    await api.approve(`${ID}/../../x`, { fetchImpl }),
    await api.discard("", { fetchImpl }),
    await api.approveMany([], { fetchImpl }),
    await api.approveMany([ID, "nope"], { fetchImpl }),
    await api.approveMany(Array.from({ length: 51 }, (_, i) => `0f8fad5b-d9cb-469f-a165-${String(i).padStart(12, "0")}`), { fetchImpl }),
    await api.upload([], { fetchImpl }),
  ]) {
    assert.equal(out.ok, false);
    assert.equal(typeof out.message, "string");
  }
  assert.equal(calls.length, 0);
});

test("a refusal keeps the route's words; a dropped connection returns, never throws", async () => {
  const refusing = recordingFetch(() => json({ ok: false, kind: "blocked", code: "approve_blocked", message: "Already in Xero." }, 409));
  const out = await api.approve(ID, { fetchImpl: refusing.fetchImpl });
  assert.deepEqual([out.ok, out.kind, out.code, out.status, out.message, out.reason], [false, "blocked", "approve_blocked", 409, "Already in Xero.", null]);
  const dropped = async () => {
    throw new TypeError("Failed to fetch");
  };
  const lost = await api.approve(ID, { fetchImpl: dropped });
  assert.equal(lost.kind, "unconfirmed");
  assert.match(lost.message, /couldn't confirm whether it reached Xero/);
  const html = recordingFetch(() => new Response("<html>", { status: 500 }));
  const odd = await api.save(ID, { document: {} }, { fetchImpl: html.fetchImpl });
  assert.deepEqual([odd.ok, odd.code], [false, "http_500"]);
  assert.match(odd.message, /Your changes are still here/);
});
