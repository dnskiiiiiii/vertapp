// tests/audit-trail-unread.test.js — THE AUDIT TRAIL'S OWN UNREAD ZERO
// =============================================================================
// FOUND BY DRIVING THE CHART-GAP RESOLVE FLOW ON A LIVE TENANT, 2026-08-23.
//
// A `chart_gap` was filed against po_8Hm's `unclassified_txn` and then answered with
// a `txn_class`. Both were accepted by the API, both are rows in the tenant's
// database, and the panel that sent them printed the confirmation for each. On the
// very same rail, eight lines below, the Audit history block said:
//
//     "No decisions recorded yet for this exception."
//
// It said that on every load of every live deployment, whatever had been recorded,
// because `useAuditFor()` read `lib/store.js` React state and nothing in this app ever
// fetched a recorded decision back. The empty label turned that silence into a measured
// count of zero. That is the standing rule this project keeps re-finding: an unread zero
// is not a measured zero, and absence renders in words.
//
// RE-POINTED BY G1, 2026-09-30. The block lived in components/audit/AuditTrail.js, drawn
// by the exceptions rail and the approvals detail pane; the agent workspace retired all
// three (spec §12.1: "the audit placeholder … Details ▾"). Who decided what is now said
// by the decision's own collapsed line — "Approved $9,350.73 · Vansh · 10:42" — built
// from the API's accepted result (components/cards/words.js `doneLine`), which is a
// measured answer about ONE decision rather than a claim about the whole history.
//
// So the component-render cases retired with the component (count ledger: 3 render
// cases, 2 call-site cases). What is kept is the defect itself, as a negative over every
// shipped source: no screen may claim a measured empty history it never read.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { listAppSources, read, stripComments } from "./_harness/source.js";
import { doneLine } from "../components/cards/words.js";

// The sentences that were false on a live tenant, and their near relations.
const MEASURED_EMPTY_HISTORY = /No decisions recorded|no audit events|Nothing has been decided|No history yet/i;

test("no shipped screen claims a measured empty decision history", () => {
  // Read off the RAW source minus comments: the sentence is a string literal, so
  // `stripNonCode` would blank the very thing this looks for.
  const hits = listAppSources("components", "app", "lib").filter((rel) => MEASURED_EMPTY_HISTORY.test(stripComments(read(rel))));
  assert.deepEqual(
    hits,
    [],
    "a shipped source claims no decision was recorded. Nothing in this app reads the " +
      "decision history back from the API, so that sentence is an unread zero shown as a " +
      "measured one — the defect this file was written for."
  );
});

test("a decision's own line always names who, even when the API recorded nobody", () => {
  // The replacement for the trail is the collapsed line, and its failure mode is the
  // blank actor (UI-024). With no recorded actor it still says someone.
  for (const settled of [{ by: "Vansh", at: "2026-09-30T10:42:00Z" }, { by: null }, {}]) {
    const line = doneLine("approve", settled, { amount: "$9,350.73" });
    assert.match(line, /^Approved \$9,350\.73 · \S/, `the line lost its actor: ${line}`);
  }
});

test("a line whose write the API could not confirm says so, rather than claiming it", () => {
  const line = doneLine("approve", { by: "Vansh", verified: false, outcome: "approved" });
  assert.match(line, /couldn't confirm/i, `an unverified write read as done: ${line}`);
});
