// tests/aging-v2.test.js — THE REMINDER DEFECTS AN ADVERSARIAL REVIEW FOUND, HELD SHUT
// ==============================================================================
// Contract v2 (28 Oct 2026, after the review). Each block reproduces one defect first:
//
//   1. results were keyed by contactId, so sending a customer's AUD reminder marked
//      their USD reminder sent too. Every result and every state is keyed by draftId.
//   2. the whole body was editable, so a person could change an invoice's amount in an
//      email the engine then sent as Vert's. Only `intro` and `closing` are editable; the
//      invoice block is the engine's, written at send time. `body` is never sent.
//   3. the recipient: `to` defaults to Xero's address; a changed or typed one needs an
//      explicit "Send to X instead of Y?" and goes with `confirmRecipient: true`.
//   4. statuses: `unknown` is "may have been sent" (never sent, never not sent),
//      `needs_confirm` says which confirmation, refusals keep the engine's words.
//   5. at most 50 emails per send request.
//   6. the test email takes no address; a 429 shows the engine's words.
//   7. a Sent reminders list from GET /reminders/sends.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { render, textOf } from "./_harness/render.js";
import { ROOT, read, stripComments } from "./_harness/source.js";
import ReminderDrafts from "../components/chat/answer/ReminderDrafts.js";
import SentReminders from "../components/chat/answer/SentReminders.js";
import {
  MAX_EMAILS_PER_SEND,
  canSendDraft,
  emailOf,
  recipientChanged,
  remindersOf,
  resultKey,
  resultTone,
  resultWords,
  selectedEmails,
  sendResultsOf,
  sendStatusWords,
  sendsOf,
} from "../components/chat/answer/reminders.js";
import { getSends, postEmailTest, postSend, sendBody } from "../app/api/reminders/shared.js";
import { sendTestReminderEmail } from "../lib/reminders-client.js";

const FIX = JSON.parse(readFileSync(path.join(ROOT, "tests", "fixtures", "aging-shape.json"), "utf8"));
const clone = (v) => JSON.parse(JSON.stringify(v));
const R = () => remindersOf(FIX.reminders);
const byId = (r, id) => r.drafts.find((d) => d.draftId === id);
const drafts = (props = {}) => render(ReminderDrafts, { reminders: FIX.reminders, ledgerName: "Xero", writes: true, ...props });
function draftHtml(html, id) {
  const start = html.indexOf(`data-draft="${id}"`);
  assert.ok(start >= 0, `no draft ${id}`);
  const next = html.indexOf('data-draft="', start + 12);
  const foot = html.indexOf("data-drafts-foot", start);
  return html.slice(start, Math.min(...[next, foot, html.length].filter((i) => i > start)));
}
function engine(status, body) {
  const calls = [];
  const fetchImpl = async (url, init = {}) => {
    calls.push({ url, method: init.method || "GET", body: init.body === undefined ? undefined : JSON.parse(init.body) });
    return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
  };
  return { calls, fetchImpl };
}

/* ── 1. keyed by draft, never by contact ─────────────────────────────────────── */

test("1: a result names its draft; the same customer's other currency is untouched", () => {
  const r = R();
  const aud = byId(r, "r-1a2b");
  const usd = byId(r, "r-1a2b-usd");
  assert.equal(aud.contactId, usd.contactId, "the fixture holds one customer in two currencies");
  const [res] = sendResultsOf({ results: [{ draftId: "r-1a2b-usd", contactId: "c-city", currency: "USD", status: "sent", words: "Sent." }] });
  assert.equal(resultKey(res, r.drafts), "r-1a2b-usd");
  // A result with no draftId is matched on contact AND currency, never on contact alone.
  const [loose] = sendResultsOf({ results: [{ contactId: "c-city", currency: "USD", status: "sent" }] });
  assert.equal(resultKey(loose, r.drafts), "r-1a2b-usd");
  const [ambiguous] = sendResultsOf({ results: [{ contactId: "c-city", status: "sent" }] });
  assert.equal(resultKey(ambiguous, r.drafts), null, "a contact with two drafts and no currency names neither");
});

test("1: sending the USD reminder never marks the AUD one sent, nor drops it", () => {
  const results = { "r-1a2b-usd": { draftId: "r-1a2b-usd", contactId: "c-city", currency: "USD", status: "sent", words: "Sent to accounts@citylimo.example." } };
  const html = drafts({ initial: { results } });
  assert.match(draftHtml(html, "r-1a2b-usd"), /data-result="sent"/);
  const aud = draftHtml(html, "r-1a2b");
  assert.doesNotMatch(aud, /data-result=/, "the AUD draft has no result");
  assert.match(aud, />Approve &amp; send</, "and can still be sent");
  assert.ok(!/results\[d\.contactId\]|next\[x\.contactId\]/.test(stripComments(read("components/chat/answer/ReminderDrafts.js"))), "no state is keyed by contact");
});

/* ── 2. intro and closing are the person's; the invoice block is the engine's ─── */

test("2: the email sent carries intro and closing, never a body", () => {
  const r = R();
  const e = emailOf(byId(r, "r-3c4d"), { intro: "Hello again,", closing: "Thanks" });
  assert.equal(e.intro, "Hello again,");
  assert.equal(e.closing, "Thanks");
  assert.equal("body" in e, false);
  const sent = sendBody({ emails: [e] });
  assert.equal(sent.ok, true);
  assert.equal("body" in sent.body.emails[0], false);
  assert.equal(sendBody({ emails: [{ ...e, body: "Pay $1 instead" }] }).body.emails[0].body, undefined, "a body is never forwarded");
});

test("2: only intro and closing are editable; the invoice block between them is read-only", () => {
  const city = draftHtml(drafts(), "r-1a2b");
  const areas = [...city.matchAll(/<textarea[^>]*name="([^"]+)"/g)].map((m) => m[1]);
  assert.deepEqual(areas.map((n) => n.split("-").pop()), ["intro", "closing"]);
  assert.match(city, /<textarea[^>]*>Hi City Limousines,/);
  const intro = city.indexOf("-intro");
  const closing = city.indexOf("-closing");
  const block = city.slice(intro, closing);
  assert.ok(block.includes("INV-0012"), "the invoice list sits between the two");
  assert.doesNotMatch(block, /<textarea[^>]*>[^<]*INV-0012/, "and it is not in a textarea");
  // Walk 2 copy list: said as a label, once per draft ("Filled from Xero at send").
  assert.match(textOf(city), /Filled from Xero at send/);
});

test("2: invoices past the listed count are summarised as the email will say them", () => {
  const raw = clone(FIX.reminders);
  Object.assign(raw.drafts[2], { listed: 1, moreCount: 3, moreCents: 125000 });
  const html = drafts({ reminders: raw });
  assert.match(textOf(draftHtml(html, "r-3c4d")), /and 3 more overdue invoices totalling \$1,250\.00/);
});

test("2: a draft from before v2 (no intro/closing) is read but can't be sent", () => {
  const raw = clone(FIX.reminders);
  delete raw.drafts[2].intro;
  delete raw.drafts[2].closing;
  const r = remindersOf(raw);
  const d = byId(r, "r-3c4d");
  assert.ok(d, "still read");
  assert.equal(canSendDraft(d, r.sender).ok, false);
  assert.match(canSendDraft(d, r.sender).reason, /draft the reminders again/i);
});

/* ── 3. the recipient ─────────────────────────────────────────────────────────── */

test("3: to defaults to Xero's address, and a changed one needs confirmRecipient", () => {
  const r = R();
  const bay = byId(r, "r-3c4d");
  assert.equal(bay.ledgerAddress, "ap@bayside.example");
  assert.equal(recipientChanged(bay, {}), false);
  assert.equal(recipientChanged(bay, { to: "boss@bayside.example" }), true);
  assert.equal(emailOf(bay, { to: "boss@bayside.example" }).confirmRecipient, undefined, "never confirmed by default");
  assert.equal(emailOf(bay, { to: "boss@bayside.example" }, { confirmRecipient: true }).confirmRecipient, true);
  assert.equal(emailOf(bay, {}, { confirmRecipient: true }).confirmRecipient, undefined, "only a changed recipient carries it");
  assert.equal(sendBody({ emails: [emailOf(bay, { to: "boss@bayside.example" }, { confirmRecipient: true })] }).body.emails[0].confirmRecipient, true);
});

test("3: a draft with no address in Xero is sendable once one is typed (and then confirmed)", () => {
  const r = R();
  const ridge = byId(r, "r-5e6f");
  assert.equal(ridge.ledgerAddress, null);
  assert.equal(canSendDraft(ridge, r.sender).ok, false);
  assert.match(canSendDraft(ridge, r.sender).reason, /type one in and confirm it/);
  assert.equal(canSendDraft(ridge, r.sender, { to: "ap@ridgeway.example" }).ok, true);
  assert.equal(canSendDraft(ridge, r.sender, { to: "not an address" }).ok, false);
  const plan = selectedEmails(r.drafts, new Set(["r-5e6f"]), { "r-5e6f": { to: "ap@ridgeway.example" } }, r.sender);
  assert.deepEqual(plan.emails, []);
  assert.deepEqual(plan.awaiting.map((d) => d.draftId), ["r-5e6f"], "a typed address waits for its yes");
  const yes = selectedEmails(r.drafts, new Set(["r-5e6f"]), { "r-5e6f": { to: "ap@ridgeway.example" } }, r.sender, { recipientOk: new Set(["r-5e6f"]) });
  assert.equal(yes.emails[0].confirmRecipient, true);
  assert.equal(yes.emails[0].to, "ap@ridgeway.example");
});

test("3: the no-address draft offers an address field, and a changed recipient asks before it sends", () => {
  const ridge = draftHtml(drafts(), "r-5e6f");
  assert.match(ridge, /<input[^>]*type="email"/);
  assert.match(textOf(ridge), /type one in and confirm it/);
  const asked = draftHtml(drafts({ initial: { edits: { "r-3c4d": { to: "boss@bayside.example" } }, confirming: ["r-3c4d"] } }), "r-3c4d");
  assert.match(textOf(asked), /Send to boss@bayside\.example instead of ap@bayside\.example\?/);
  const typed = draftHtml(drafts({ initial: { edits: { "r-5e6f": { to: "ap@ridgeway.example" } }, confirming: ["r-5e6f"] } }), "r-5e6f");
  assert.match(textOf(typed), /Send to ap@ridgeway\.example instead of no address in Xero\?/);
});

test("3: canSendDraft says one thing: a typed, confirmed address is sendable", () => {
  const src = read("components/chat/answer/reminders.js");
  assert.doesNotMatch(src, /an address typed here would be one the ledger doesn't hold/);
  assert.doesNotMatch(src, /can't be sent even if/i);
});

/* ── 4. statuses ───────────────────────────────────────────────────────────────── */

test("4: unknown is 'may have been sent', never sent and never not sent", () => {
  const [u] = sendResultsOf({ results: [{ draftId: "r-3c4d", contactId: "c-bayside", currency: "AUD", status: "unknown", words: null }] });
  assert.equal(u.status, "unknown");
  assert.match(resultWords(u), /may have been sent/i);
  assert.doesNotMatch(resultWords(u), /^Sent|not sent/i);
  assert.equal(resultTone(u), "attention");
  const html = draftHtml(drafts({ initial: { results: { "r-3c4d": u } } }), "r-3c4d");
  assert.match(html, /data-result="unknown"/);
  assert.match(textOf(html), /Sent reminders/, "it points at the list that says what happened");
  assert.doesNotMatch(html, />Approve &amp; send</, "not offered again as if nothing went");
});

test("4: needs_confirm says which yes it needs, and asks for that one", () => {
  const [resend, recipient] = sendResultsOf({
    results: [
      { draftId: "r-3c4d", contactId: "c-bayside", currency: "AUD", status: "needs_confirm", confirm: "resend", lastRemindedOn: "2026-10-27", words: null },
      { draftId: "r-1a2b-usd", contactId: "c-city", currency: "USD", status: "needs_confirm", confirm: "recipient", ledgerAddress: "billing@citylimo.example", words: null },
    ],
  });
  assert.equal(resend.confirm, "resend");
  assert.equal(recipient.confirm, "recipient");
  assert.equal(recipient.ledgerAddress, "billing@citylimo.example");
  assert.match(resultWords(resend), /27 Oct 2026|reminded/i);
  assert.match(resultWords(recipient), /billing@citylimo\.example/);
  const html = drafts({ initial: { results: { "r-3c4d": resend, "r-1a2b-usd": recipient }, confirming: ["r-3c4d", "r-1a2b-usd"] } });
  assert.match(textOf(draftHtml(html, "r-3c4d")), /Reminded on 27 Oct 2026\. Send again\?/);
  assert.match(textOf(draftHtml(html, "r-1a2b-usd")), /instead of billing@citylimo\.example\?/);
});

test("4: a refusal keeps the engine's words, such as already being sent", () => {
  const [x] = sendResultsOf({ results: [{ draftId: "r-3c4d", contactId: "c-bayside", currency: "AUD", status: "refused", words: "This reminder is already being sent." }] });
  assert.equal(resultWords(x), "This reminder is already being sent.");
  assert.match(textOf(draftHtml(drafts({ initial: { results: { "r-3c4d": x } } }), "r-3c4d")), /already being sent/);
});

/* ── 5. at most 50 per request ──────────────────────────────────────────────────── */

test("5: one shared max of 50 emails per send; more than 50 ticked is refused in words, nothing posted", () => {
  assert.equal(MAX_EMAILS_PER_SEND, 50);
  const one = emailOf(R().drafts[2], {});
  assert.equal(sendBody({ emails: Array.from({ length: 50 }, () => one) }).ok, true);
  const over = sendBody({ emails: Array.from({ length: 51 }, () => one) });
  assert.equal(over.ok, false);
  assert.match(over.message, /50/);
  const raw = clone(FIX.reminders);
  const base = raw.drafts[2];
  raw.drafts = Array.from({ length: 51 }, (_, i) => ({ ...clone(base), draftId: `r-many-${i}`, contactId: `c-${i}` }));
  const r = remindersOf(raw);
  const ticked = new Set(r.drafts.map((d) => d.draftId));
  const plan = selectedEmails(r.drafts, ticked, {}, r.sender);
  assert.equal(plan.tooMany, true);
  assert.deepEqual(plan.emails, [], "nothing is posted past the cap");
  const html = drafts({ reminders: raw, initial: { selected: [...ticked] } });
  const button = html.match(/<button[^>]*data-send-selected=""[^>]*>/)[0];
  assert.match(button, /aria-disabled="true"/);
  assert.match(textOf(html), /at most 50 reminders at once/);
});

/* ── 6. the test email ──────────────────────────────────────────────────────────── */

test("6: the test email takes no address, on the wire or in the route", async () => {
  const { calls, fetchImpl } = engine(200, { status: "sent", to: "books@demo.example", messageId: "m", words: "Sent a test email to books@demo.example." });
  const got = await postEmailTest({ request: { to: "someone@else.example" }, base: "http://e", headers: {}, fetchImpl });
  assert.equal(got.ok, true);
  assert.equal(calls[0].body === undefined || Object.keys(calls[0].body).length === 0, true, "no `to` reaches the engine");
  const browser = [];
  await sendTestReminderEmail({ fetchImpl: async (url, init) => { browser.push(init); return new Response("{}", { status: 200 }); } });
  assert.equal(browser[0].body, undefined, "the browser sends no body");
  assert.doesNotMatch(stripComments(read("app/api/reminders/email/test/route.js")), /\.to\b|jsonOf/);
});

test("6: a 429 shows the engine's words", async () => {
  const { fetchImpl } = engine(429, { error: { code: "rate_limited", message: "Five test emails an hour at most. Try again after 11:00 am.", detail: null } });
  const got = await postEmailTest({ base: "http://e", headers: {}, fetchImpl });
  assert.equal(got.ok, false);
  assert.equal(got.status, 429);
  assert.equal(got.message, "Five test emails an hour at most. Try again after 11:00 am.");
});

/* ── 7. the sent list ────────────────────────────────────────────────────────────── */

const SENDS = {
  sends: [
    { sendId: "s-1", contactId: "c-city", contactName: "City Limousines", invoiceIds: ["inv-0012"], to: "accounts@citylimo.example", ledgerAddress: "accounts@citylimo.example", backend: "smtp", status: "sent", messageId: "m-1", sentBy: "Sam Lee", sentAt: "2026-10-25T01:00:00Z", subject: "Overdue", recipientEdited: false, bodyEdited: false, currency: "AUD", words: null },
    { sendId: "s-2", contactId: "c-bayside", contactName: "Bayside Club", invoiceIds: ["inv-0007"], to: "boss@bayside.example", ledgerAddress: "ap@bayside.example", backend: "smtp", status: "unknown", messageId: null, sentBy: "Sam Lee", sentAt: "2026-10-28T02:00:00Z", subject: "Overdue", recipientEdited: true, bodyEdited: true, currency: "AUD", words: "The mail server stopped answering mid-send." },
    { sendId: "s-3", contactId: "c-ridge", contactName: "Ridgeway University", invoiceIds: ["inv-0003"], to: "ap@ridgeway.example", ledgerAddress: null, backend: "smtp", status: "sending", messageId: null, sentBy: "Sam Lee", sentAt: "2026-10-28T03:00:00Z", subject: "Overdue", recipientEdited: true, bodyEdited: false, currency: "AUD", words: null },
    { sendId: "bad" },
  ],
};

test("7: the sent list reads GET /reminders/sends, newest first, each status in words", async () => {
  const { calls, fetchImpl } = engine(200, SENDS);
  const got = await getSends({ request: { limit: 50 }, base: "http://e", headers: {}, fetchImpl });
  assert.equal(calls[0].url, "http://e/reminders/sends?limit=50");
  const rows = sendsOf({ sends: got.sends });
  assert.deepEqual(rows.map((s) => s.sendId), ["s-3", "s-2", "s-1"]);
  assert.deepEqual(rows.map(sendStatusWords), ["Being sent", "May have been sent", "Sent"]);
  assert.equal(sendStatusWords({ status: "failed" }), "Not sent");
  assert.equal(sendStatusWords({ status: "cancelled" }), "Cancelled");
});

test("7: the list says who it went to, and when the recipient or message was changed", () => {
  const html = render(SentReminders, { sends: SENDS, ledgerName: "Xero" });
  const text = textOf(html);
  assert.match(text, /Sent reminders/);
  assert.match(text, /Bayside Club/);
  assert.match(text, /May have been sent/);
  assert.match(text, /recipient changed from ap@bayside\.example/);
  assert.match(text, /message edited/);
  assert.match(text, /The mail server stopped answering mid-send\./);
  assert.match(text, /Being sent/);
  assert.match(text, /typed in; Xero had no address/);
  assert.ok(text.indexOf("Ridgeway") < text.indexOf("Bayside") && text.indexOf("Bayside") < text.indexOf("City Limousines"), "newest first");
  assert.equal(render(SentReminders, { sends: { sends: [] } }).includes("No reminders have been sent"), true);
});

test("7: 'check the sent list' wording points at Sent reminders, and the route exists", async () => {
  const lost = await postSend({ request: { emails: [emailOf(R().drafts[2], {})] }, base: "http://e", headers: {}, fetchImpl: async () => { throw new TypeError("x"); } });
  assert.match(lost.message, /Sent reminders/);
  for (const rel of ["app/api/reminders/shared.js", "lib/reminders.js", "lib/reminders-client.js", "components/chat/answer/ReminderDrafts.js"]) {
    assert.doesNotMatch(stripComments(read(rel)), /sent list/i, `${rel} still says "the sent list"`);
  }
  assert.match(read("app/api/reminders/sends/route.js"), /export async function GET/);
  const page = stripComments(read("app/connections/page.js"));
  assert.match(page, /readSentReminders\(/, "the Email for reminders sheet shows the list too");
});
