// The Month-end ask opens its conversation as soon as it exists (9 Nov 2026, the
// bookkeeper walk: twice the emptied box, 40 s into Vert writing its reply, read as the
// question lost). The match is pure; the look is a GET in the press's own handler.
import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { startedConversation } from "../components/month/AskBox.js";
import { read, stripComments } from "./_harness/source.js";

const SINCE = 1_800_000_000_000;
const chat = (title, at = SINCE + 2000, extra = {}) => ({ id: "c-1", title, href: "/chat/c-1", status: "Vert's working", updatedAt: at, ...extra });

test("the conversation whose title starts the ask, touched since it was sent, is the one", () => {
  const ask = "Morning - where are we with October? What's left before I can close?";
  const found = startedConversation([chat("Morning - where are we with October? What's left before I c…")], ask, SINCE);
  assert.equal(found && found.href, "/chat/c-1");
  assert.equal(startedConversation([chat("Is the October bank fee coded?")], "Is the October bank fee coded?", SINCE).id, "c-1");
});

test("an older chat, a task's conversation, or another question is never taken for it", () => {
  const ask = "Accrue $1,500 audit fees for October";
  assert.equal(startedConversation([chat(ask, SINCE - 3_600_000)], ask, SINCE), null, "yesterday's same words");
  assert.equal(startedConversation([chat("Accruals", SINCE + 1000, { template: "accrual_schedule" })], ask, SINCE), null);
  assert.equal(startedConversation([chat("Who owes us money?")], ask, SINCE), null);
  assert.equal(startedConversation([chat("Accrue")], ask, SINCE), null, "a title too short to tell");
  assert.equal(startedConversation(null, ask, SINCE), null);
});

test("the look runs from the send itself and never once the answer has moved the page", () => {
  const src = stripComments(read("components/month/AskBox.js"));
  assert.match(src, /setTimeout\(look, JUMP_AFTER_MS\);\s*const result = await againIfNoAnswer/);
  assert.match(src, /settled = true;\s*if \(jumped\) return;/);
});
