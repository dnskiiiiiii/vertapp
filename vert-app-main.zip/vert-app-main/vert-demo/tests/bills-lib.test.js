// tests/bills-lib.test.js — WHAT lib/bills.js ASKS THE ENGINE, AND WHAT IT ANSWERS
// ==============================================================================
// The engine is replaced by a recording fetch, so each export's request is held to the
// W3 contract: its path, method and body, the id checked before a path is built from
// it, and a refusal answered in words rather than thrown. API mode is switched on for
// this process before the module is imported (lib/engine-source.js reads the variable
// once, at module scope); the cookie jar is the harness's empty one, so no key is sent.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { ID, ID2, item, json, recordingFetch } from "./bills-fixtures.js";

process.env.NEXT_PUBLIC_VERT_API_URL = "http://vert-api.invalid:8000";
const bills = await import("../lib/bills.js");
const BASE = "http://vert-api.invalid:8000";

async function withFetch(reply, run) {
  const real = globalThis.fetch;
  const rec = recordingFetch(reply);
  globalThis.fetch = rec.fetchImpl;
  try {
    return await run(rec.calls);
  } finally {
    globalThis.fetch = real;
  }
}

const LIST = { items: [item(), { id: "nope" }], counts: { extracted: 1 }, ledger: { connected: true, canWriteInvoices: false, canWriteContacts: false, words: "Read only." } };

/* ── reads ───────────────────────────────────────────────────────────────────── */

test("listBills GETs /bills, with ?status= only for a status the engine names", async () => {
  await withFetch(() => json(LIST), async (calls) => {
    const out = await bills.listBills();
    assert.equal(out.ok, true);
    assert.equal(out.items.length, 1, "an item with no uuid is not listed");
    assert.equal(out.unreadable, 1);
    assert.deepEqual(out.counts, { extracted: 1 });
    assert.equal(out.xero.canWriteInvoices, false);
    await bills.listBills({ status: "needs_review" });
    await bills.listBills({ status: "all&x=1" });
    assert.deepEqual(calls.map((c) => [c.url, c.init.method || "GET"]), [
      [`${BASE}/bills`, "GET"],
      [`${BASE}/bills?status=needs_review`, "GET"],
      [`${BASE}/bills`, "GET"],
    ]);
  });
});

test("a list that isn't the engine's shape is a refusal, never an empty inbox", async () => {
  await withFetch(() => json({ items: null }), async () => {
    const out = await bills.listBills();
    assert.equal(out.ok, false);
    assert.equal(out.code, "bad_response");
  });
  await withFetch(() => json({ error: { code: "xero_unavailable", message: "Xero didn't answer.", detail: { remedy: "Try again in a minute." } } }, 502), async () => {
    const out = await bills.listBills();
    assert.deepEqual([out.ok, out.kind, out.code, out.message], [false, "refused", "xero_unavailable", "Xero didn't answer. Try again in a minute."]);
  });
  await withFetch(() => {
    throw new TypeError("fetch failed");
  }, async () => {
    const out = await bills.listBills();
    assert.deepEqual([out.ok, out.kind], [false, "unreachable"]);
  });
});

test("getBill checks the id first, and asks ?refresh=1 only when told", async () => {
  await withFetch(() => json({ item: item() }), async (calls) => {
    assert.equal((await bills.getBill(ID)).item.id, ID);
    await bills.getBill(ID, { refresh: true });
    for (const bad of ["../documents", `${ID}/approve`, "", null]) {
      const out = await bills.getBill(bad);
      assert.deepEqual([out.ok, out.code], [false, "invalid_request"]);
    }
    assert.deepEqual(calls.map((c) => c.url), [`${BASE}/bills/${ID}`, `${BASE}/bills/${ID}?refresh=1`]);
  });
  await withFetch(() => json({ item: item({ id: ID2 }) }), async () => {
    assert.equal((await bills.getBill(ID)).code, "bad_response", "an answer about another item is not this one");
  });
});

/* ── writes ──────────────────────────────────────────────────────────────────── */

test("saveBill PATCHes /bills/{id} with { document, contact }, as JSON, with the actor", async () => {
  await withFetch(() => json({ item: item() }), async (calls) => {
    const out = await bills.saveBill(ID, { document: { dueDate: "2026-11-30" }, contact: { choice: "new", name: " Acme Group " }, extra: 1 });
    assert.equal(out.ok, true);
    const [c] = calls;
    assert.equal(c.url, `${BASE}/bills/${ID}`);
    assert.equal(c.init.method, "PATCH");
    assert.equal(c.init.headers["content-type"], "application/json");
    assert.ok(c.init.headers["X-Vert-Actor"], "a write names who made it");
    assert.deepEqual(JSON.parse(c.init.body), { document: { dueDate: "2026-11-30" }, contact: { choice: "new", name: "Acme Group" } });
  });
});

test("saveBill refuses, sending nothing, an empty change or a contact choice with nothing chosen", async () => {
  await withFetch(() => json({ item: item() }), async (calls) => {
    assert.equal((await bills.saveBill(ID, {})).code, "no_change");
    assert.equal((await bills.saveBill(ID, { contact: { choice: "existing" } })).code, "invalid_request");
    assert.equal((await bills.saveBill("x", { document: {} })).code, "invalid_request");
    assert.equal(calls.length, 0);
  });
});

test("approveBill POSTs /bills/{id}/approve and hands back the item and its outcome", async () => {
  const body = { item: item({ status: "sent" }), outcome: { status: "sent", words: "Sent to Xero as a draft", xeroUrl: "https://go.xero.com/x", manualFields: [] } };
  await withFetch(() => json(body), async (calls) => {
    const out = await bills.approveBill(ID);
    assert.equal(out.ok, true);
    assert.equal(out.outcome.status, "sent");
    assert.equal(out.outcome.xeroUrl, "https://go.xero.com/x");
    assert.equal(calls[0].url, `${BASE}/bills/${ID}/approve`);
    assert.equal(calls[0].init.method, "POST");
  });
});

test("an approval the engine refuses comes back in its words, as blocked for a 409", async () => {
  const refusal = { error: { code: "approve_blocked", message: "This bill is already in Xero.", detail: { remedy: "Open the one in Xero instead." } } };
  await withFetch(() => json(refusal, 409), async () => {
    const out = await bills.approveBill(ID);
    assert.deepEqual([out.ok, out.kind, out.code], [false, "blocked", "approve_blocked"]);
    assert.equal(out.message, "This bill is already in Xero. Open the one in Xero instead.");
  });
  await withFetch(() => json({ error: { code: "flags_block", message: "Fix the total first." } }, 422), async () => {
    const out = await bills.approveBill(ID);
    assert.deepEqual([out.kind, out.status, out.message], ["refused", 422, "Fix the total first."]);
  });
  await withFetch(() => new Response("<html>bad gateway</html>", { status: 502 }), async () => {
    const out = await bills.approveBill(ID);
    assert.equal(out.message, "We couldn't confirm whether it reached Xero. Check Xero before trying again.", "a proxy's answer is not the engine's words, and may have landed");
  });
  await withFetch(() => {
    throw new TypeError("fetch failed");
  }, async () => {
    const out = await bills.approveBill(ID);
    assert.equal(out.kind, "unconfirmed");
    assert.match(out.message, /couldn't confirm whether it reached Xero/, "an unanswered approval is never 'nothing was sent'");
  });
});

test("approveBills POSTs { itemIds }, de-duplicated, at most 50, every one a uuid", async () => {
  const reply = { results: [{ itemId: ID, ok: true, item: item(), outcome: { status: "approved", words: "", xeroUrl: null, manualFields: [{ label: "Contact", value: "Acme" }] } }, { itemId: ID2, ok: false, message: "Duplicate in Xero." }] };
  await withFetch(() => json(reply), async (calls) => {
    const out = await bills.approveBills([ID, ID2, ID]);
    assert.equal(out.ok, true);
    assert.equal(out.results.length, 2);
    assert.equal(out.results[0].outcome.manualFields.length, 1);
    assert.equal(out.results[1].ok, false);
    assert.equal(calls[0].url, `${BASE}/bills/approve`);
    assert.deepEqual(JSON.parse(calls[0].init.body), { itemIds: [ID, ID2] });
    const fiftyOne = Array.from({ length: 51 }, (_, i) => `0f8fad5b-d9cb-469f-a165-${String(i).padStart(12, "0")}`);
    assert.equal((await bills.approveBills(fiftyOne)).code, "too_many");
    assert.equal((await bills.approveBills([ID, "x"])).code, "invalid_request");
    assert.equal((await bills.approveBills([])).code, "invalid_request");
    assert.equal(calls.length, 1, "a refused batch sends nothing");
  });
});

test("discardBill POSTs /bills/{id}/discard", async () => {
  await withFetch(() => json({ item: item({ status: "discarded" }) }), async (calls) => {
    assert.equal((await bills.discardBill(ID)).item.status, "discarded");
    assert.equal(calls[0].url, `${BASE}/bills/${ID}/discard`);
    assert.equal(calls[0].init.method, "POST");
  });
});

/* ── uploads ─────────────────────────────────────────────────────────────────── */

function form(files, kind) {
  const f = new FormData();
  for (const [name, type] of files) f.append("files", new Blob(["x"], { type }), name);
  if (kind) f.append("kind", kind);
  return f;
}

test("uploadBills sends documents together to /bills/upload and each .eml alone to /bills/email", async () => {
  const reply = (url) =>
    url.endsWith("/bills/email")
      ? json({ items: [item({ id: ID2, source: "email-forward" })], refused: [], email: { from: "Jo <jo@acme.example>", subject: "Invoice 1043", attachments: [{ filename: "inv.pdf", mediaType: "application/pdf", bytes: 1200 }] } }, 201)
      : json({ items: [item()], refused: [{ filename: "b.png", message: "This file has no bill on it." }] }, 201);
  await withFetch(reply, async (calls) => {
    const out = await bills.uploadBills(form([["a.pdf", "application/pdf"], ["b.png", "image/png"], ["fwd.eml", "message/rfc822"], ["notes.docx", "application/msword"]], "invoice"));
    assert.equal(out.ok, true);
    assert.deepEqual(out.items.map((i) => i.id), [ID, ID2]);
    assert.deepEqual(out.refused.map((r) => r.filename).sort(), ["b.png", "notes.docx"]);
    assert.match(out.refused.find((r) => r.filename === "b.png").message, /^b\.png has no bill on it\.$/);
    assert.equal(out.emails[0].subject, "Invoice 1043");
    assert.deepEqual(calls.map((c) => c.url), [`${BASE}/bills/upload`, `${BASE}/bills/email`]);
    const up = calls[0].init.body;
    assert.deepEqual(up.getAll("files").map((f) => f.name), ["a.pdf", "b.png"]);
    assert.equal(up.get("kind"), "invoice");
    assert.equal(calls[0].init.headers["content-type"], undefined, "the platform sets the multipart boundary");
    assert.equal(calls[1].init.body.get("file").name, "fwd.eml");
  });
});

test("an upload with nothing readable sends nothing; a failed call is named while the others stand", async () => {
  await withFetch(() => json({ items: [] }, 201), async (calls) => {
    assert.equal((await bills.uploadBills(form([]))).code, "no_file");
    assert.equal((await bills.uploadBills(form([["x.docx", ""]]))).code, "no_readable_file");
    assert.equal(calls.length, 0);
  });
  const reply = (url) => (url.endsWith("/bills/email") ? json({ error: { code: "bad_mime", message: "This file isn't an email." } }, 422) : json({ items: [item()], refused: [] }, 201));
  await withFetch(reply, async () => {
    const out = await bills.uploadBills(form([["a.pdf", "application/pdf"], ["fwd.eml", ""]]));
    assert.equal(out.ok, true);
    assert.equal(out.items.length, 1);
    assert.deepEqual(out.refused, [{ filename: "fwd.eml", message: "fwd.eml isn't an email." }]);
  });
  await withFetch(() => json({ error: { code: "too_large", message: "Too big." } }, 413), async () => {
    const out = await bills.uploadBills(form([["a.pdf", "application/pdf"]]));
    assert.deepEqual([out.ok, out.code, out.status], [false, "too_large", 413]);
  });
});
