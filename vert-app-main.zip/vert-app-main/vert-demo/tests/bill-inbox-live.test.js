// tests/bill-inbox-live.test.js — THE INBOX IN AN ANSWER IS THE INBOX NOW
// Founder's walk, 8 Nov 2026: an answer from the morning said "only one item is waiting"
// beside an inbox holding five. The answer's block re-reads the inbox when drawn.
import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { billInboxShapeOf, withLiveInbox, LIVE_ROWS } from "../components/chat/answer/bill-inbox.js";

const ID = (n) => `00000000-0000-4000-8000-00000000000${n}`;
const answered = billInboxShapeOf({ measured: true, words: "1 item is waiting.", waiting: 1, ready: 0, rows: [
  { id: ID(9), kind: "invoice", contact: "City Limousines", statusWords: "Needs review", totalCents: 55000 },
], readyIds: [] });
const item = (n, status, contactName, totalCents = 1000) => ({ id: ID(n), kind: "bill", status, statusWords: status === "extracted" ? "Ready to approve" : status === "needs_review" ? "Needs review" : "Set aside", document: { contactName, totalCents, issueDate: "2026-10-29" } });

test("the rows are the inbox's waiting items now, ready ones first, and Approve sends only those", () => {
  const live = withLiveInbox(answered, [item(1, "needs_review", "Acme"), item(2, "discarded", "Old"), item(3, "extracted", "Harbourview")]);
  assert.equal(live.waiting, 2);
  assert.deepEqual(live.rows.map((r) => r.contact), ["Harbourview", "Acme"]);
  assert.deepEqual(live.readyIds, [ID(3)]);
  assert.equal(live.rows[0].href, `/bills/${ID(3)}`);
  assert.equal(live.rows[1].totalCents, 1000);
});

test("past five rows the rest are counted as more", () => {
  const many = Array.from({ length: 7 }, (_, k) => item(k, "needs_review", `S${k}`));
  const live = withLiveInbox(answered, many);
  assert.equal(live.rows.length, LIVE_ROWS);
  assert.equal(live.more, 2);
});

test("an inbox not read keeps the engine's answer", () => {
  assert.equal(withLiveInbox(answered, null), null);
  assert.equal(withLiveInbox(null, []), null);
  assert.equal(withLiveInbox({ ...answered, measured: false }, []), null);
});
