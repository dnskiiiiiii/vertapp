// tests/aging-readers.test.js — AGED BALANCES AND REMINDER DRAFTS, READ FROM THE ENGINE
// ==============================================================================
// W3 feature 1 (28 Oct 2026): "who owes us, who do we owe, and chase the overdue ones".
// The engine sends `shape.agedBalances` (a list of sides) and `shape.reminders` (the
// drafted emails). These readers only READ: every total, bucket and count is the
// engine's; a side or a draft that doesn't read as the contract says is dropped whole,
// never half-drawn; an unread side keeps the engine's words and never becomes $0.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { ROOT } from "./_harness/source.js";
import { BUCKET_KEYS, agedBalancesOf, agedSideOf, currenciesWords, isOverdueBucket } from "../components/chat/answer/aged-balances.js";
import {
  canSendDraft,
  confirmNeeded,
  emailOf,
  remindersOf,
  resultTone,
  resultWords,
  sendResultsOf,
  selectedEmails,
} from "../components/chat/answer/reminders.js";
import { shapeOf } from "../components/chat/answer/shape.js";

const FIX = JSON.parse(readFileSync(path.join(ROOT, "tests", "fixtures", "aging-shape.json"), "utf8"));
const clone = (v) => JSON.parse(JSON.stringify(v));

/* ───────────────────────────── aged balances ───────────────────────────── */

test("both sides read, receivables first, every figure the engine's own", () => {
  const sides = agedBalancesOf(FIX.agedBalances);
  assert.equal(sides.length, 2);
  assert.deepEqual(sides.map((s) => s.side), ["receivables", "payables"]);
  const ar = sides[0];
  assert.equal(ar.title, "Aged receivables");
  assert.equal(ar.measured, true);
  const aud = ar.currencies[0];
  assert.equal(aud.currency, "AUD");
  assert.equal(aud.totalCents, 1234500);
  assert.equal(aud.overdueCents, 800000);
  assert.equal(aud.overdueCount, 4);
  assert.deepEqual(aud.buckets.map((b) => b.key), BUCKET_KEYS);
  assert.deepEqual(aud.buckets.map((b) => b.cents), [434500, 300000, 200000, 100000, 200000, 0]);
  assert.equal(aud.contacts[1].buckets.d90_plus, 200000);
  assert.equal(aud.topOverdue[0].number, "INV-0007");
  assert.equal(aud.topOverdue[0].url, "https://go.xero.com/AccountsReceivable/View.aspx?InvoiceID=inv-0007");
  assert.deepEqual(ar.action, { kind: "draft_reminders", label: "Draft reminders", asAt: "2026-10-28" });
  assert.equal(sides[1].action, null);
});

test("the six buckets are the contract's keys in its order, and only the aged ones are overdue", () => {
  assert.deepEqual(BUCKET_KEYS, ["current", "d1_30", "d31_60", "d61_90", "d90_plus", "credit"]);
  assert.deepEqual(BUCKET_KEYS.filter(isOverdueBucket), ["d1_30", "d31_60", "d61_90", "d90_plus"]);
});

test("an unread side keeps the engine's words and carries no figure at all", () => {
  const side = agedSideOf(FIX.unread);
  assert.equal(side.measured, false);
  assert.match(side.words, /couldn't read your invoices/);
  assert.deepEqual(side.currencies, []);
  assert.equal(side.action, null, "nothing to chase on a side that was not read");
  // Figures sent beside measured=false are not read as figures.
  const lying = { ...clone(FIX.unread), currencies: clone(FIX.agedBalances[0].currencies) };
  assert.deepEqual(agedSideOf(lying).currencies, []);
  // Unread with no words cannot say why: dropped, never drawn as a blank.
  assert.equal(agedSideOf({ ...clone(FIX.unread), words: null }), null);
});

test("a malformed side is dropped whole, never half-drawn", () => {
  const breakers = [
    (s) => { s.side = "debtors"; },
    (s) => { s.measured = "yes"; },
    (s) => { s.currencies[0].totalCents = "1234500"; },
    (s) => { s.currencies[0].buckets.pop(); },
    (s) => { s.currencies[0].buckets[1].key = "d0_30"; },
    (s) => { s.currencies[0].buckets.reverse(); },
    (s) => { s.currencies[0].contacts[0].buckets.d31_60 = null; },
    (s) => { s.currencies[0].contacts[0].name = ""; },
    (s) => { s.currencies[0].topOverdue[0].amountDueCents = 12.5; },
    (s) => { s.currencies[0].topOverdue[0].dueDate = "13/09/2026"; },
    (s) => { s.currencies = "AUD"; },
  ];
  for (const breakIt of breakers) {
    const raw = clone(FIX.agedBalances[0]);
    breakIt(raw);
    assert.equal(agedSideOf(raw), null, String(breakIt));
  }
  // One broken side does not take the good one with it.
  const both = clone(FIX.agedBalances);
  both[0].currencies[0].buckets.pop();
  const read = agedBalancesOf(both);
  assert.deepEqual(read.map((s) => s.side), ["payables"]);
  assert.equal(agedBalancesOf([]), null);
  assert.equal(agedBalancesOf({ side: "receivables" }), null, "the contract sends a list");
});

test("a link out is only ever a secure one", () => {
  const raw = clone(FIX.agedBalances[0]);
  raw.currencies[0].topOverdue[0].url = "javascript:alert(1)";
  assert.equal(agedSideOf(raw).currencies[0].topOverdue[0].url, null);
});

test("the action is drawn only where the contract allows it: a measured receivables side", () => {
  const ap = clone(FIX.agedBalances[1]);
  ap.action = { kind: "draft_reminders", label: "Draft reminders", asAt: "2026-10-28" };
  assert.equal(agedSideOf(ap).action, null, "nobody sends a supplier a reminder");
  const other = clone(FIX.agedBalances[0]);
  other.action = { kind: "post_everything", label: "Post" };
  assert.equal(agedSideOf(other).action, null);
});

test("several currencies are said in words as separate, never one sum", () => {
  const ap = agedBalancesOf(FIX.agedBalances)[1];
  assert.deepEqual(ap.currencies.map((c) => c.currency), ["AUD", "USD"]);
  assert.match(currenciesWords(ap.currencies), /AUD and USD/);
  assert.match(currenciesWords(ap.currencies), /not added together/);
  assert.equal(currenciesWords(agedBalancesOf(FIX.agedBalances)[0].currencies), null, "one currency needs no note");
});

test("shapeOf carries agedBalances and reminders, so an aging answer is a shaped answer", () => {
  const shape = shapeOf({ agedBalances: FIX.agedBalances, reminders: FIX.reminders });
  assert.ok(shape, "an answer carrying only aged balances is still drawn");
  assert.equal(shape.agedBalances.length, 2);
  assert.equal(shape.reminders.drafts.length, 4);
  assert.equal(shapeOf({ agedBalances: [{ side: "nope" }] }), null);
});

/* ───────────────────────────── reminder drafts ───────────────────────────── */

test("the drafts read whole: recipient, subject, body, invoices, pay link or its words", () => {
  const r = remindersOf(FIX.reminders);
  assert.equal(r.asAt, "2026-10-28");
  assert.equal(r.resendDays, 7);
  assert.deepEqual(r.sender, { connected: true, backend: "smtp", fromAddress: "accounts@demo.example", words: null });
  assert.equal(r.drafts.length, 4);
  const [city, cityUsd, bayside, ridgeway] = r.drafts;
  assert.equal(city.to, "accounts@citylimo.example");
  assert.equal(city.ledgerAddress, "accounts@citylimo.example", "to starts as the ledger's address");
  assert.match(city.intro, /^Hi City Limousines,/);
  assert.match(city.closing, /Kind regards/);
  assert.deepEqual([cityUsd.contactId, cityUsd.currency], ["c-city", "USD"], "one customer, a draft per currency");
  assert.equal(city.needsConfirm, true);
  assert.equal(city.lastRemindedOn, "2026-10-25");
  assert.match(city.payLinkWords, /no online payment link/);
  assert.equal(bayside.invoices[0].payUrl, "https://in.xero.com/pay/inv-0007");
  assert.equal(ridgeway.to, null);
  assert.match(ridgeway.toWords, /no email address/);
});

test("a malformed draft is dropped whole, and a draft with no address must say why", () => {
  const breakers = [
    (d) => { d.draftId = ""; },
    (d) => { d.subject = 7; },
    (d) => { d.invoices = []; },
    (d) => { d.invoices[0].amountDueCents = "300"; },
    (d) => { d.to = null; d.ledgerAddress = null; d.toWords = null; },
    (d) => { d.needsConfirm = "true"; },
    (d) => { d.lastRemindedOn = "last week"; },
  ];
  for (const breakIt of breakers) {
    const raw = clone(FIX.reminders);
    breakIt(raw.drafts[0]);
    const r = remindersOf(raw);
    assert.equal(r.drafts.length, 3, String(breakIt));
    assert.ok(!r.drafts.some((d) => d.draftId === "r-1a2b"), String(breakIt));
  }
  const noSender = clone(FIX.reminders);
  delete noSender.sender;
  assert.equal(remindersOf(noSender), null, "with no word on the sender, nothing can say whether it can send");
});

test("unread overdue invoices keep the engine's words and offer no draft", () => {
  const raw = { ...clone(FIX.reminders), measured: false, words: "Vert couldn't read the overdue invoices from Xero.", drafts: clone(FIX.reminders.drafts) };
  const r = remindersOf(raw);
  assert.equal(r.measured, false);
  assert.match(r.words, /couldn't read/);
  assert.deepEqual(r.drafts, []);
  assert.equal(remindersOf({ ...raw, words: null }), null);
});

test("a draft can be sent only with a connected sender, an address and a press", () => {
  const r = remindersOf(FIX.reminders);
  const [city, , bayside, ridgeway] = r.drafts;
  assert.deepEqual(canSendDraft(bayside, r.sender), { ok: true, reason: null });
  assert.equal(canSendDraft(ridgeway, r.sender).ok, false);
  assert.match(canSendDraft(ridgeway, r.sender).reason, /no email address/);
  const off = { connected: false, backend: null, fromAddress: null, words: "Email isn't connected for this client yet." };
  assert.equal(canSendDraft(bayside, off).ok, false);
  assert.equal(canSendDraft(bayside, off).reason, "Email isn't connected for this client yet.");
  // v2: an address typed where the ledger has none is sendable (once confirmed).
  assert.equal(canSendDraft(ridgeway, r.sender, { to: "ap@ridgeway.example" }).ok, true);
  assert.equal(canSendDraft(city, r.sender, { to: "   " }).ok, false, "a blanked address is no address");
});

test("the email sent is the person's edit of the draft, with the draft's invoices", () => {
  const r = remindersOf(FIX.reminders);
  const bayside = r.drafts[2];
  assert.deepEqual(emailOf(bayside, { subject: "Please pay", intro: "Hi again,", closing: "Thanks", body: "Edited body" }), {
    draftId: "r-3c4d",
    contactId: "c-bayside",
    invoiceIds: ["inv-0007"],
    to: "ap@bayside.example",
    subject: "Please pay",
    intro: "Hi again,",
    closing: "Thanks",
  });
  assert.equal(emailOf(bayside, {}).subject, bayside.subject, "an untouched draft sends as drafted");
});

test("a draft reminded within the resend window needs a second, explicit yes", () => {
  const r = remindersOf(FIX.reminders);
  const [city, , bayside] = r.drafts;
  assert.equal(confirmNeeded(city), true);
  assert.equal(confirmNeeded(bayside), false);
  assert.equal(emailOf(city, {}).confirmResend, undefined, "never confirmed by default");
  assert.equal(emailOf(city, {}, { confirmResend: true }).confirmResend, true);
  assert.equal(emailOf(bayside, {}, { confirmResend: true }).confirmResend, undefined, "only a draft that needs it carries it");
});

test("send selected sends only the ticked, sendable drafts; a recent one waits for its yes", () => {
  const r = remindersOf(FIX.reminders);
  const ticked = new Set(["r-1a2b", "r-3c4d", "r-5e6f"]);
  const first = selectedEmails(r.drafts, ticked, {}, r.sender);
  assert.deepEqual(first.emails.map((e) => e.contactId), ["c-bayside"]);
  assert.deepEqual(first.awaiting.map((d) => d.draftId), ["r-1a2b"]);
  assert.deepEqual(first.blocked.map((b) => b.draft.draftId), ["r-5e6f"]);
  const yes = selectedEmails(r.drafts, ticked, {}, r.sender, { resendOk: new Set(["r-1a2b"]) });
  assert.deepEqual(yes.emails.map((e) => [e.contactId, e.confirmResend === true]), [["c-city", true], ["c-bayside", false]]);
  assert.deepEqual(selectedEmails(r.drafts, new Set(), {}, r.sender).emails, []);
});

test("each send result says what happened in the engine's words, with its tone", () => {
  const read = sendResultsOf({
    results: [
      { contactId: "c-bayside", status: "sent", to: "ap@bayside.example", messageId: "m-1", words: "Sent to ap@bayside.example.", lastRemindedOn: "2026-10-28", sentAt: "2026-10-28T01:02:03Z" },
      { contactId: "c-city", status: "needs_confirm", to: "accounts@citylimo.example", messageId: null, words: "Reminded on 25 Oct 2026. Send again?", lastRemindedOn: "2026-10-25", sentAt: null },
      { contactId: "c-x", status: "failed", to: "x@x.example", messageId: null, words: null, lastRemindedOn: null, sentAt: null },
      { contactId: "c-y", status: "exploded" },
    ],
  });
  assert.deepEqual(read.map((x) => x.status), ["sent", "needs_confirm", "failed"]);
  assert.equal(resultWords(read[0]), "Sent to ap@bayside.example.");
  assert.equal(resultWords(read[2]), "Not sent.");
  assert.deepEqual(read.map(resultTone), ["done", "attention", "problem"]);
  assert.equal(resultTone({ status: "refused" }), "problem");
  assert.equal(sendResultsOf({ nope: 1 }), null);
});
