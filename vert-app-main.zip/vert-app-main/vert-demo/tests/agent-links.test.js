// tests/agent-links.test.js — AN ENGINE LINK IS DRAWN ONLY WHERE THE APP SERVES IT
// ==============================================================================
// lib/agent/links.js maps the engine's download paths onto the app's pass-through
// routes and refuses the ones nothing in app/ answers (eval 9.3.F-8, known-red D-11).
// The route oracle is tests/_harness/routes.js, the same one no-false-affordance uses,
// so a mapping onto a path that does not exist on disk goes red here.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { appHref } from "../lib/agent/links.js";
import { servedBy } from "./_harness/routes.js";

test("the bank rec's workbook maps to the app's pass-through, query kept as written", () => {
  const q = "?account=csv%3Aoperating&as_at=2026-07-31&closing_balance=3500000";
  assert.equal(appHref(`/reconciliations/bank.xlsx${q}`), `/reconciliation/bank/xlsx${q}`);
  assert.ok(servedBy(appHref(`/reconciliations/bank.xlsx${q}`)));
});

test("a payout's workbook maps to its paper's xlsx route", () => {
  assert.equal(appHref("/workpapers/payouts/po_1.xlsx"), "/reconciliation/papers/po_1/xlsx");
  assert.ok(servedBy(appHref("/workpapers/payouts/po_1.xlsx")));
});

test("an API path with no app counterpart draws no link, never a dead one", () => {
  for (const dead of ["/workpapers?period=2026-07", "/workpapers", "/reconciliations/other", "//evil.example/x", "https://x.example/", null, undefined, 42]) {
    assert.equal(appHref(dead), null, String(dead));
  }
});

test("an app path passes through untouched", () => {
  for (const ok of ["/records?tab=bank", "/chat/2026-07-bank_reconciliation", "/reconciliation/bank/xlsx?account=x"]) {
    assert.equal(appHref(ok), ok);
  }
});
