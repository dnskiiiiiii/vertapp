// tests/bills-live-check.test.js — THE LIVE BROWSER CHECK OF w3/int (29 Oct 2026)
// ==============================================================================
// Two things a person saw that the earlier tests didn't: a refusal that said
// "Nothing was recorded." twice (the engine's sentence, then the notice's own), and an
// inbox row that said only "Needs review" for a file uploaded before (the flag lived
// in the review pane alone).

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { render, textOf } from "./_harness/render.js";
import BillsScreen from "../components/bills/BillsScreen.js";
import { duplicateMarkOf, noticeText } from "../lib/bills-model.js";
import { ID, ID2, ID3, XERO_WRITES, item } from "./bills-fixtures.js";

test("a refusal never says what was recorded twice: the notice says it, once", () => {
  const engine = "You drafted this entry, so someone else must approve it. Nothing was recorded. Ask a reviewer.";
  assert.equal(noticeText(engine, "nothing"), "You drafted this entry, so someone else must approve it. Ask a reviewer.");
  assert.equal(noticeText("Not sent.", "nothing"), "Not sent.");
  assert.equal(noticeText("It couldn't be read. Nothing was recorded.", "nothing"), "It couldn't be read.");
});

test("the review's notice goes through noticeText", async () => {
  const { read, stripComments } = await import("./_harness/source.js");
  const src = stripComments(read("components/bills/BillReview.js"));
  assert.match(src, /noticeText\(failure\.message, failure\.recorded\)/);
});

test("a duplicate marker names a same-file upload or a possible duplicate, and nothing else", () => {
  const sameFile = item({ status: "needs_review", flags: [{ code: "same_file", field: "invoiceNumber", severity: "review", words: "This file was uploaded before." }] });
  assert.equal(duplicateMarkOf(sameFile), "Uploaded before");
  assert.equal(duplicateMarkOf(item({ status: "needs_review", duplicate: { status: "possible", words: "Same amount." } })), "Possible duplicate");
  assert.equal(duplicateMarkOf(item({ status: "duplicate", duplicate: { status: "duplicate" } })), null, "the status already says it");
  assert.equal(duplicateMarkOf(item()), null);
});

test("the inbox row shows the duplicate marker beside the status", () => {
  const list = {
    ok: true,
    items: [
      item({ id: ID, status: "needs_review", statusWords: "Needs review", flags: [{ code: "same_file", field: "invoiceNumber", severity: "review", words: "This file was uploaded before." }] }),
      item({ id: ID2, status: "needs_review", statusWords: "Needs review", duplicate: { status: "possible", words: "Same amount." } }),
      item({ id: ID3 }),
    ],
    counts: { needs_review: 2, extracted: 1 },
    xero: XERO_WRITES,
  };
  const html = render(BillsScreen, { initial: list });
  const text = textOf(html);
  assert.match(text, /Uploaded before/);
  assert.match(text, /Possible duplicate/);
  assert.equal((html.match(/data-duplicate-mark=/g) || []).length, 2);
});

test("the bill's own drafter sees Approve disabled with the engine's reason", async () => {
  const { approvalOf } = await import("../lib/bills-model.js");
  const words = "You uploaded or changed this bill, so someone else at your firm approves it: your firm keeps the person who prepares a bill apart from the person who approves it. Ask a reviewer to approve it.";
  const a = approvalOf(item({ canApprove: false, approveBlockedWords: words, drafterBlocked: true }));
  assert.equal(a.can, false);
  assert.equal(a.reason, words);
});

// ── the live check's copy nits (29 Oct 2026, second pass) ──

test("the page names Xero where the engine says 'the ledger'", async () => {
  const { xeroView, ledgerAsXero } = await import("../lib/bills-model.js");
  const v = xeroView({ connected: false, canWriteInvoices: false, words: "The ledger isn't connected, so Vert can't match contacts, check for duplicates or send drafts." });
  assert.equal(v.words, "Xero isn't connected, so Vert can't match contacts, check for duplicates or send drafts.");
  assert.equal(ledgerAsXero("Approving sends each bill to the ledger as a draft."), "Approving sends each bill to Xero as a draft.");
  assert.equal(ledgerAsXero("The ledger hasn't granted it. Check the ledger's bills."), "Xero hasn't granted it. Check Xero's bills.");
});

test("the duplicate step's button says what will happen, by the connection", async () => {
  const { confirmStepOf } = await import("../lib/bills-model.js");
  const { XERO_WRITES, XERO_READ_ONLY } = await import("./bills-fixtures.js");
  const writes = confirmStepOf("duplicate", XERO_WRITES);
  assert.equal(writes.button, "Yes, it's a different bill");
  assert.match(writes.after, /sends it to Xero as a draft/);
  const readOnly = confirmStepOf("duplicate", XERO_READ_ONLY);
  assert.equal(readOnly.button, "Yes, it's a different bill");
  assert.match(readOnly.after, /fields to enter by hand/);
  assert.match(confirmStepOf("duplicate", null).after, /fields to enter by hand/);
  assert.equal(confirmStepOf("check_ledger", XERO_WRITES).button, "I've checked Xero");
  const { read, stripComments } = await import("./_harness/source.js");
  const src = stripComments(read("components/bills/BillReview.js"));
  assert.doesNotMatch(src, /Yes, send it anyway/);
  assert.match(src, /confirmStepOf\(/);
});

test("the duplicate step names the earlier bill and links to it, never its id", async () => {
  const { sameFileOf } = await import("../lib/bills-model.js");
  const earlier = "7c9e6679-7425-40de-944b-e07fc1f90ae7";
  const it = item({ flags: [{ code: "same_file", field: "invoiceNumber", severity: "review", words: "This file was uploaded before: Harbour HOS-20931, 14 Oct 2026, ready to approve.", sameFile: { itemId: earlier, contactName: "Harbour", invoiceNumber: "HOS-20931", issueDate: "2026-10-14", status: "extracted", statusWords: "Ready to approve" } }] });
  const link = sameFileOf(it);
  assert.equal(link.href, `/bills/${earlier}`);
  assert.match(link.words, /Harbour/);
  assert.match(link.words, /HOS-20931/);
  assert.match(link.words, /14\sOct\s2026/);
  assert.match(link.words, /Ready to approve/);
  assert.doesNotMatch(link.words, new RegExp(earlier));
  assert.equal(sameFileOf(item()), null);
  assert.equal(sameFileOf(item({ flags: [{ code: "same_file", sameFile: { itemId: "not-a-uuid" } }] })), null, "a link is built only from an item id");
  const { read, stripComments } = await import("./_harness/source.js");
  assert.match(stripComments(read("components/bills/BillReview.js")), /sameFileOf\(/);
});
