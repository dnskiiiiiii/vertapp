// tests/bills-fixtures.js — INBOX ITEMS IN THE ENGINE'S SHAPE, FOR tests/bills-*.test.js
// ==============================================================================
// Built to the W3 contract (lead's brief, 28 Oct 2026): GET /bills → { items, counts,
// xero }, each item an InboxItem with money in integer cents. `item(overrides)` makes one
// that can be approved; each test bends the field it is about.

export const ID = "0f8fad5b-d9cb-469f-a165-70867728950e";
export const ID2 = "7c9e6679-7425-40de-944b-e07fc1f90ae7";
export const ID3 = "16fd2706-8baf-433b-82eb-8c7fada847da";
export const DOC_ID = "a3bb189e-8bf9-4888-9912-ace4e6543002";

export function line(overrides = {}) {
  return {
    description: "Office chairs",
    quantity: "2",
    unitAmountCents: 50000,
    taxCents: 10000,
    lineAmountCents: 100000,
    accountCode: "720",
    accountName: "Office Equipment",
    taxType: "INPUT",
    taxName: "GST on Expenses",
    codingConfidence: "high",
    codingBasis: "Acme's last three bills were coded to 720.",
    alternatives: [{ accountCode: "429", accountName: "General Expenses", taxType: "INPUT", taxName: "GST on Expenses", basis: "A common account for furniture under $1,000." }],
    ...overrides,
  };
}

export function item(overrides = {}) {
  const { document: doc = {}, ...rest } = overrides;
  return {
    id: ID,
    documentId: DOC_ID,
    filename: "acme-inv-1043.pdf",
    mediaType: "application/pdf",
    source: "upload",
    sourceRef: null,
    kind: "bill",
    status: "extracted",
    statusWords: "Ready to approve",
    document: {
      contactName: "Acme Pty Ltd",
      taxNumber: "53 004 085 616",
      email: "accounts@acme.example",
      invoiceNumber: "INV-1043",
      issueDate: "2026-10-12",
      dueDate: "2026-11-11",
      currency: "AUD",
      amountsAre: "Exclusive",
      lines: [line()],
      subtotalCents: 100000,
      taxCents: 10000,
      totalCents: 110000,
      confidence: { contactName: "high", dueDate: "low", totalCents: "medium" },
      method: "model",
      ...doc,
    },
    flags: [],
    contact: { status: "matched", matchedBy: "tax_number", contactId: "c-acme", name: "Acme Pty Ltd", candidates: [], choice: "existing", words: "Matched by ABN." },
    duplicate: { status: "none", words: "Not in Xero yet.", xeroInvoiceId: null, xeroUrl: null, xeroStatus: null, invoiceNumber: null },
    xero: null,
    manualFields: [],
    canApprove: true,
    approveBlockedWords: null,
    approvedBy: null,
    approvedAt: null,
    pushedAt: null,
    createdAt: "2026-10-28T01:00:00Z",
    createdBy: "Sam Lee",
    ...rest,
  };
}

export const XERO_WRITES = { connected: true, canWriteInvoices: true, canWriteContacts: true, words: "Xero is connected: Demo Company (AU)." };
export const XERO_READ_ONLY = { connected: true, canWriteInvoices: false, canWriteContacts: false, words: "Xero is connected for reading only." };

/** A Response with a JSON body, as the engine (or this app's route) answers. */
export function json(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
}

/** A fetch that records each call and answers with `reply(url, init)`. */
export function recordingFetch(reply) {
  const calls = [];
  const fetchImpl = async (url, init = {}) => {
    calls.push({ url: String(url), init });
    return reply(String(url), init);
  };
  return { calls, fetchImpl };
}
