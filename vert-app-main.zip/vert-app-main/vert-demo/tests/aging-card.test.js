// tests/aging-card.test.js — THE AGED BALANCES CARD AND THE REMINDER DRAFTS, AS DRAWN
// ==============================================================================
// W3 feature 1 (28 Oct 2026). Under the verdict: per side and per currency, the summary
// (owed, overdue, how many overdue), the bucket table by contact with the engine's
// totals row, the most overdue invoices with a link into the ledger, and for receivables
// one "Draft reminders". The drafts: one editable email per customer, nothing sent, each
// with its own "Approve & send", and "Approve & send selected" over the ticks.
//
// The harness renders on the server with no clicks, so a pressed state is handed in as
// `initial`, as tests/bank-rec-rows.test.js does.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { render, textOf } from "./_harness/render.js";
import { ROOT, read, stripComments } from "./_harness/source.js";
import AgedBalances from "../components/chat/answer/AgedBalances.js";
import ReminderDrafts from "../components/chat/answer/ReminderDrafts.js";
import ShapeBlocks from "../components/chat/answer/ShapeBlocks.js";
import { agedBalancesOf } from "../components/chat/answer/aged-balances.js";
import { remindersOf } from "../components/chat/answer/reminders.js";
import { shapeOf } from "../components/chat/answer/shape.js";
import { formatMoney } from "../lib/format.js";

const FIX = JSON.parse(readFileSync(path.join(ROOT, "tests", "fixtures", "aging-shape.json"), "utf8"));
const clone = (v) => JSON.parse(JSON.stringify(v));

/** The markup of one side, from its tag to the next side's. */
function sideHtml(html, side) {
  const start = html.indexOf(`data-aged-side="${side}"`);
  assert.ok(start >= 0, `no ${side} side`);
  const next = html.indexOf("data-aged-side=", start + 20);
  return html.slice(start, next > start ? next : html.length);
}

test("each side says what is owed, what is overdue and how many, in the engine's figures", () => {
  const html = render(AgedBalances, { agedBalances: FIX.agedBalances, ledgerName: "Xero" });
  const ar = textOf(sideHtml(html, "receivables"));
  assert.ok(ar.includes("Aged receivables"));
  assert.ok(ar.includes("28 Oct 2026"), "as at, as a date a person reads");
  assert.ok(ar.includes(formatMoney(1234500)), "total owed");
  assert.ok(ar.includes(formatMoney(800000)), "overdue");
  assert.ok(/4 of 9 invoices overdue/.test(ar), "the engine's counts, worded");
  const ap = textOf(sideHtml(html, "payables"));
  assert.ok(ap.includes("Aged payables"));
  assert.ok(/1 of 3 bills overdue/.test(ap));
});

test("the bucket table is by contact, with the engine's labels and its totals row", () => {
  const html = render(AgedBalances, { agedBalances: FIX.agedBalances });
  const ar = sideHtml(html, "receivables");
  const text = textOf(ar);
  for (const label of ["Current", "1–30 days", "31–60 days", "61–90 days", "Over 90 days", "Total"]) {
    assert.ok(text.includes(label), label);
  }
  // A bucket that is $0.00 in its total and for every contact isn't a column (founder,
  // 8 Nov 2026): this fixture's Unapplied credit is zero throughout.
  assert.ok(!text.includes("Unapplied credit"), "an all-zero column is drawn");
  assert.ok(text.includes("City Limousines") && text.includes("Bayside Club"));
  // The totals row is the engine's buckets and total, never a sum of the rows above.
  const foot = ar.slice(ar.indexOf("<tfoot"), ar.indexOf("</tfoot>"));
  assert.ok(foot.length > 0, "a totals row");
  for (const cents of [434500, 300000, 200000, 100000, 1234500]) assert.ok(textOf(foot).includes(formatMoney(cents)), String(cents));
});

test("an overdue cell carries the attention tone; current and credit never do", () => {
  const ar = sideHtml(render(AgedBalances, { agedBalances: FIX.agedBalances }), "receivables");
  const cells = [...ar.matchAll(/<td[^>]*data-bucket="([a-z0-9_]+)"[^>]*>/g)].map((m) => [m[1], /data-tone="attention"/.test(m[0])]);
  assert.ok(cells.length >= 12, "every contact's buckets are drawn");
  for (const [key, tone] of cells) {
    if (key === "current" || key === "credit") assert.equal(tone, false, key);
  }
  assert.ok(cells.some(([key, tone]) => key === "d31_60" && tone), "City Limousines' 31–60 is highlighted");
  // A zero in an overdue bucket is not drawn as a problem.
  assert.ok(cells.some(([key, tone]) => key === "d1_30" && !tone), "a zero overdue bucket is quiet");
});

test("the most overdue invoices: number, due date, days overdue, amount, and a link into Xero", () => {
  const ar = sideHtml(render(AgedBalances, { agedBalances: FIX.agedBalances, ledgerName: "Xero" }), "receivables");
  const text = textOf(ar);
  assert.ok(text.includes("INV-0007"));
  assert.ok(text.includes("30 Jun 2026"));
  assert.ok(text.includes("120 days overdue"));
  assert.ok(text.includes(formatMoney(200000)));
  // The number is the link into Xero (founder, 8 Nov 2026: one link, not a button per row).
  assert.match(ar, /<a [^>]*href="https:\/\/go\.xero\.com\/AccountsReceivable\/View\.aspx\?InvoiceID=inv-0007"[^>]*target="_blank"[^>]*rel="noopener noreferrer"[^>]*aria-label="INV-0007, open in Xero"[^>]*>INV-0007<\/a>/);
  assert.ok(!text.includes("Open in Xero"), "a separate Open in Xero on each row");
});

test("receivables carry one Draft reminders press; payables carry none", () => {
  const html = render(AgedBalances, { agedBalances: FIX.agedBalances });
  assert.equal((sideHtml(html, "receivables").match(/data-draft-reminders=""/g) || []).length, 1);
  assert.ok(textOf(sideHtml(html, "receivables")).includes("Draft reminders"));
  assert.ok(!textOf(sideHtml(html, "payables")).includes("Draft reminders"));
});

test("several currencies are separate blocks, said in words, with no figure that adds them", () => {
  const ap = sideHtml(render(AgedBalances, { agedBalances: FIX.agedBalances }), "payables");
  assert.equal((ap.match(/data-currency="/g) || []).length, 2);
  assert.match(textOf(ap), /not added together/);
  // AUD 410000 + USD 99000 would be 509000: that figure must not exist anywhere.
  assert.ok(!textOf(ap).includes(formatMoney(509000)));
  assert.ok(textOf(ap).includes("2 more contacts"), "the left-out contacts are counted, so the rows needn't add to the totals");
});

test("a side that was not read says the engine's words, and never $0", () => {
  const html = render(AgedBalances, { agedBalances: [FIX.unread] });
  const text = textOf(html);
  assert.match(text, /couldn't read your invoices/);
  assert.ok(!/\$0\.00/.test(text), "an unread side is not a zero");
  assert.ok(!text.includes("Draft reminders"));
  assert.equal(render(AgedBalances, { agedBalances: [{ side: "nope" }] }), "", "nothing readable, nothing drawn");
});

test("the drafts appear inline under the headline once drafted, above the table", () => {
  const html = render(AgedBalances, { agedBalances: FIX.agedBalances, initial: { drafts: FIX.reminders } });
  const ar = sideHtml(html, "receivables");
  // Who to chase comes first (founder, 8 Nov 2026), then the table that explains it.
  assert.ok(ar.indexOf("data-reminder-drafts") > 0 && ar.indexOf("data-reminder-drafts") < ar.indexOf("<table"), "above the table");
  assert.ok(textOf(ar).includes("City Limousines"));
});

test("ShapeBlocks draws the aging card and the drafts from an answer's shape", () => {
  const shape = shapeOf({ agedBalances: FIX.agedBalances, reminders: FIX.reminders });
  const html = render(ShapeBlocks, { shape, ledgerName: "Xero" });
  assert.match(html, /data-aged-balances=""/);
  assert.match(html, /data-reminder-drafts=""/);
});

test("the readers are idempotent, so the screen can re-read what events.js already read", () => {
  const once = agedBalancesOf(FIX.agedBalances);
  assert.deepEqual(agedBalancesOf(once), once);
  const r = remindersOf(FIX.reminders);
  assert.deepEqual(remindersOf(r), r);
});

/* ───────────────────────────── the drafts ───────────────────────────── */

const drafts = (props = {}) => render(ReminderDrafts, { reminders: FIX.reminders, ledgerName: "Xero", writes: true, ...props });

function draftHtml(html, id) {
  const start = html.indexOf(`data-draft="${id}"`);
  assert.ok(start >= 0, `no draft ${id}`);
  const next = html.indexOf("data-draft=\"", start + 12);
  const foot = html.indexOf("data-drafts-foot", start);
  const ends = [next, foot, html.length].filter((i) => i > start);
  return html.slice(start, Math.min(...ends));
}

test("one editable draft per customer: To, Subject and Body, and nothing has been sent", () => {
  const html = drafts();
  assert.match(textOf(html), /Nothing has been sent/);
  const city = draftHtml(html, "r-1a2b");
  assert.match(city, /<input[^>]*type="email"[^>]*value="accounts@citylimo\.example"/);
  assert.match(city, /<input[^>]*value="Overdue invoices from Demo Company \(AU\)"/);
  assert.match(city, /<textarea[^>]*>Hi City Limousines,/);
  assert.ok(textOf(city).includes("INV-0012"));
  assert.ok(textOf(city).includes("45 days overdue"));
  assert.ok(textOf(city).includes(formatMoney(30000)));
  assert.match(textOf(city), /no online payment link/, "the engine's words where Xero gave no pay link");
  const bayside = draftHtml(html, "r-3c4d");
  assert.match(bayside, /href="https:\/\/in\.xero\.com\/pay\/inv-0007"/);
});

test("a customer reminded before says when", () => {
  assert.match(textOf(draftHtml(drafts(), "r-1a2b")), /Last reminded on 25 Oct 2026/);
  assert.doesNotMatch(textOf(draftHtml(drafts(), "r-3c4d")), /Last reminded/);
});

test("a draft with no address shows the engine's words and can't be sent until one is typed", () => {
  const ridge = draftHtml(drafts(), "r-5e6f");
  assert.match(textOf(ridge), /Xero has no email address for Ridgeway University/);
  assert.match(ridge, /<input[^>]*type="email"[^>]*value=""/, "an empty address field to type one into (v2)");
  assert.match(ridge, /aria-disabled="true"[^>]*>Approve &amp; send/);
  assert.match(ridge, /type="checkbox"[^>]*disabled=""/);
});

test("every sendable draft has its own Approve & send, and one Approve & send selected over the ticks", () => {
  const html = drafts();
  for (const id of ["r-1a2b", "r-3c4d"]) assert.match(draftHtml(html, id), /Approve &amp; send</, id);
  assert.equal((html.match(/data-send-selected=""/g) || []).length, 1);
  // w46: each draft also carries its own Attach statement box; the selection is the rest.
  const statementBoxes = (html.match(/type="checkbox"[^>]*name="draft-[^"]+-statement"/g) || []).length;
  assert.equal(statementBoxes, 4, "one Attach statement per draft");
  assert.equal((html.match(/type="checkbox"/g) || []).length - statementBoxes, 4, "one per draft, two for the customer in two currencies");
  assert.ok(!/type="checkbox"[^>]*checked/.test(html), "nothing is ticked until the person ticks it");
});

test("a recently reminded draft asks a second, explicit question before it sends again", () => {
  const html = drafts({ initial: { confirming: ["r-1a2b"] } });
  const city = draftHtml(html, "r-1a2b");
  assert.match(textOf(city), /Reminded on 25 Oct 2026\. Send again\?/);
  assert.match(city, /data-confirm-resend=""/);
  assert.doesNotMatch(textOf(draftHtml(html, "r-3c4d")), /Send again\?/);
});

test("each result says what happened, in the engine's words", () => {
  const results = {
    "r-3c4d": { draftId: "r-3c4d", contactId: "c-bayside", currency: "AUD", status: "sent", to: "ap@bayside.example", messageId: "m-1", words: "Sent to ap@bayside.example.", lastRemindedOn: "2026-10-28", sentAt: null },
    "r-1a2b": { draftId: "r-1a2b", contactId: "c-city", currency: "AUD", status: "failed", to: "accounts@citylimo.example", messageId: null, words: "Gmail refused the message.", lastRemindedOn: null, sentAt: null },
  };
  const html = drafts({ initial: { results } });
  const bayside = draftHtml(html, "r-3c4d");
  assert.match(textOf(bayside), /Sent to ap@bayside\.example\./);
  assert.match(bayside, /data-result="sent"/);
  assert.doesNotMatch(bayside, />Approve &amp; send</, "a sent draft is not offered again");
  assert.match(textOf(draftHtml(html, "r-1a2b")), /Gmail refused the message\./);
});

test("with email not connected, the engine's words, a link to connect, and no send", () => {
  const raw = clone(FIX.reminders);
  raw.sender = { connected: false, backend: null, fromAddress: null, words: "Email for reminders isn't connected for this client yet." };
  const html = drafts({ reminders: raw });
  assert.match(textOf(html), /Email for reminders isn't connected for this client yet\./);
  assert.match(html, /<a [^>]*href="\/connections"/);
  const sendButtons = [...html.matchAll(/<button[^>]*>(?:Approve &amp; send[^<]*)</g)].map((m) => m[0]);
  assert.ok(sendButtons.length >= 3);
  for (const b of sendButtons) assert.match(b, /aria-disabled="true"/);
});

test("on the sample books nothing can be sent, and it says why", () => {
  const html = render(ReminderDrafts, { reminders: FIX.reminders });
  assert.match(textOf(html), /sample/);
  for (const b of [...html.matchAll(/<button[^>]*>(?:Approve &amp; send[^<]*)</g)].map((m) => m[0])) assert.match(b, /aria-disabled="true"/);
});

test("nothing sends without a press: no effect in the drafts or the card sends a request", () => {
  for (const rel of ["components/chat/answer/ReminderDrafts.js", "components/chat/answer/AgedBalances.js"]) {
    const src = stripComments(read(rel));
    assert.ok(!/useEffect\(/.test(src), `${rel} has an effect`);
  }
});

test("an engine needs_confirm on a draft drafted without one asks again with the engine's date", () => {
  const results = { "r-3c4d": { draftId: "r-3c4d", contactId: "c-bayside", currency: "AUD", status: "needs_confirm", confirm: "resend", to: "ap@bayside.example", messageId: null, words: "Reminded on 27 Oct 2026 from Xero. Send again?", lastRemindedOn: "2026-10-27", sentAt: null } };
  const bayside = draftHtml(drafts({ initial: { results, confirming: ["r-3c4d"] } }), "r-3c4d");
  assert.match(bayside, /data-confirm-resend=""/);
  assert.match(textOf(bayside), /Reminded on 27 Oct 2026\. Send again\?/);
});
