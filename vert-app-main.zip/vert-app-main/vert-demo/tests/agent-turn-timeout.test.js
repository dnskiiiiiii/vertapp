// tests/agent-turn-timeout.test.js — A CALL THAT WAITS ON VERT'S ANSWER WAITS LONG ENOUGH
// ==============================================================================
// THE DEFECT (p0, 23 Oct 2026). "When I prompt the thing, it doesn't do the task." The
// staging API answers a typed message INSIDE the request that sends it (vert_api
// inline_chat.answer_inline, budget 240 s), in 11–69 s measured. The app's engine client
// gave up on every request after 15 s (REQUEST_TIMEOUT_MS), so the Next route answered
// 502 "unreachable" while the engine was still writing the reply, and the person saw
// nothing happen.
//
// THE RULE. Every request whose engine route can answer a model turn before it returns
// waits AGENT_TURN_TIMEOUT_MS (under Vercel's 300 s ceiling, over the engine's 240 s
// budget); an ordinary read keeps 15 s, so a hung read still fails fast. The engine's
// inline callers are POST /agent/sessions, POST /agent/sessions/{id}/messages, the three
// plan presses, POST /tasks and PATCH /tasks/{id} (a task's first turn), POST
// /close/{period} (Start the month) and the budget sheet's Import and Choose.
//
// AND EACH HOP ON THE WAY LETS IT. The Next functions that make these calls declare
// `maxDuration = 300`, so Vercel does not stop the function before the engine answers.
//
// HOW THE TIMEOUT IS SEEN. `AbortSignal.timeout(ms)` is wrapped for the file and records
// the ms of every signal made; the fakes below answer at once.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const BASE = "http://vert-api.invalid:8000";
process.env.NEXT_PUBLIC_VERT_API_URL = BASE;

const made = [];
const realTimeout = AbortSignal.timeout.bind(AbortSignal);
AbortSignal.timeout = (ms) => {
  made.push(ms);
  return realTimeout(ms);
};

const source = await import("../lib/engine-source.js");
const client = await import("../lib/agent/client.js");
const tasks = await import("../lib/tasks.js");
const actions = await import("../lib/actions.js");
const budgets = await import("../app/api/budgets/shared.js");

const { AGENT_TURN_TIMEOUT_MS, REQUEST_TIMEOUT_MS } = source;

function jsonResponse(body, status = 200) {
  return { ok: status >= 200 && status < 300, status, json: async () => body, text: async () => JSON.stringify(body), headers: new Headers({ "content-type": "application/json" }) };
}

// Every request made, with the timeout its signal was made with.
function fakeFetch(answer) {
  const calls = [];
  const fetchImpl = async (url, init = {}) => {
    calls.push({ url: String(url), method: init.method || "GET", ms: made[made.length - 1] });
    return typeof answer === "function" ? answer(String(url), init) : answer;
  };
  return { calls, fetchImpl };
}

async function withGlobalFetch(answer, fn) {
  const before = globalThis.fetch;
  const fake = fakeFetch(answer);
  globalThis.fetch = fake.fetchImpl;
  try {
    await fn(fake.calls);
  } finally {
    globalThis.fetch = before;
  }
  return fake.calls;
}

test("the turn timeout is over the engine's 240 s inline budget and under Vercel's 300 s", () => {
  assert.equal(REQUEST_TIMEOUT_MS, 15000);
  assert.ok(AGENT_TURN_TIMEOUT_MS > 240000, `${AGENT_TURN_TIMEOUT_MS}`);
  assert.ok(AGENT_TURN_TIMEOUT_MS < 300000, `${AGENT_TURN_TIMEOUT_MS}`);
});

test("starting a conversation with typed text waits for the turn; reading its opening does not", async () => {
  const { calls, fetchImpl } = fakeFetch((url) =>
    url.endsWith("/agent/sessions") ? jsonResponse({ sessionId: "s1" }, 201) : jsonResponse({ session: { sessionId: "s1" }, events: [] })
  );
  const r = await client.startConversation({ period: "2026-09", text: "do the accruals" }, { fetchImpl });
  assert.equal(r.ok, true);
  assert.equal(calls[0].method, "POST");
  assert.equal(calls[0].ms, AGENT_TURN_TIMEOUT_MS);
  assert.equal(calls[1].method, "GET");
  assert.equal(calls[1].ms, REQUEST_TIMEOUT_MS);
});

test("a template start, Run again and Try again wait for the turn", async () => {
  const { calls, fetchImpl } = fakeFetch(jsonResponse({ sessionId: "s1" }, 201));
  await client.startConversation({ period: "2026-09", template: "accruals", again: true }, { fetchImpl });
  assert.equal(calls[0].ms, AGENT_TURN_TIMEOUT_MS);
});

test("a message and an answer to a question wait for the turn", async () => {
  const { calls, fetchImpl } = fakeFetch(jsonResponse({ accepted: true, turnId: "t1" }, 202));
  await client.sendToConversation("s1", { text: "and the bank rec" }, { fetchImpl });
  await client.sendToConversation("s1", { answer: { questionId: "q1", optionId: "a" } }, { fetchImpl });
  assert.deepEqual(calls.map((c) => c.ms), [AGENT_TURN_TIMEOUT_MS, AGENT_TURN_TIMEOUT_MS]);
});

test("each plan press waits for the turn its replay can queue", async () => {
  const { calls, fetchImpl } = fakeFetch(jsonResponse({ ok: true }));
  await client.pressPlan("a1", { decision: "approve" }, { fetchImpl });
  await client.pressPlan("a1", { decision: "reject", notes: "no" }, { fetchImpl });
  await client.pressPlan("a1", { decision: "edit", settings: {} }, { fetchImpl });
  assert.deepEqual(calls.map((c) => c.url.split("/plan/")[1]), ["start", "reject", "edit"]);
  assert.deepEqual(calls.map((c) => c.ms), [AGENT_TURN_TIMEOUT_MS, AGENT_TURN_TIMEOUT_MS, AGENT_TURN_TIMEOUT_MS]);
});

test("ordinary reads keep the short timeout; a write waits as long as the engine allows", async () => {
  // Staging browser walk 2, N3: a coding's settle (which creates the Spend Money in Xero)
  // took 40 s and was cut at 15 s, and the row said "Nothing was recorded" over it. A
  // write now waits WRITE_TIMEOUT_MS; a hung READ still fails fast.
  const { calls, fetchImpl } = fakeFetch(jsonResponse({ ok: true, verified: true }));
  await client.readMonth("2026-09", { fetchImpl });
  await client.readConversation("s1", { fetchImpl });
  await client.settle("a1", "approved", { fetchImpl });
  await client.decline("a1", { fetchImpl });
  await client.cancelConversation("s1", { fetchImpl });
  assert.equal(calls.length, 5);
  assert.deepEqual(calls.map((c) => c.ms), [REQUEST_TIMEOUT_MS, REQUEST_TIMEOUT_MS, ...Array(3).fill(source.WRITE_TIMEOUT_MS)]);
});

test("a new task and a changed task wait for the first turn the engine runs for them", async () => {
  const TASK = { id: "t_1", kind: "task", period: "2026-07", title: "Chase it", sessionId: "s_1" };
  const calls = await withGlobalFetch(jsonResponse({ task: TASK, verified: true, measured: true }), async () => {
    await tasks.createTask({ title: "Chase it", period: "2026-07" });
    await tasks.updateTask("t_1", { title: "Chase it now" });
    await tasks.completeTask("t_1");
  });
  assert.deepEqual(calls.map((c) => c.method), ["POST", "PATCH", "POST"]);
  assert.deepEqual(calls.map((c) => c.ms), [AGENT_TURN_TIMEOUT_MS, AGENT_TURN_TIMEOUT_MS, source.WRITE_TIMEOUT_MS]);
});

test("Start the month waits for the tasks it runs inside the request", async () => {
  const calls = await withGlobalFetch(jsonResponse({ period: "2026-09" }), async () => {
    await actions.startMonth("2026-09");
  });
  assert.equal(calls[0].method, "POST");
  assert.ok(calls[0].url.endsWith("/close/2026-09"));
  assert.equal(calls[0].ms, AGENT_TURN_TIMEOUT_MS);
});

test("the budget sheet's Import and Choose wait for the turn; its reads do not", async () => {
  const { calls, fetchImpl } = fakeFetch(jsonResponse({ sessionId: "s1", turnId: "t1" }, 202));
  await budgets.postImport({ request: { sessionId: "s1", source: "qbo" }, base: BASE, fetchImpl });
  await budgets.postChoose({ request: { sessionId: "s1", budgetId: "b1", fy: 2026 }, base: BASE, fetchImpl });
  await budgets.getBudgets({ base: BASE, fetchImpl });
  assert.deepEqual(calls.map((c) => c.method), ["POST", "POST", "GET"]);
  assert.deepEqual(calls.map((c) => c.ms), [AGENT_TURN_TIMEOUT_MS, AGENT_TURN_TIMEOUT_MS, REQUEST_TIMEOUT_MS]);
});

// Every Next function between the browser and those calls: the start's route handler,
// and the pages whose Server Actions send a message, press a plan, import a budget,
// make a task or start the month (a Server Action runs in its page's function).
const HOPS = ["app/api/agent/sessions/route.js", "app/chat/[id]/page.js", "app/page.js"];

for (const file of HOPS) {
  test(`${file} lets its function run 300 s, so Vercel does not stop it before Vert answers`, () => {
    const text = readFileSync(new URL(`../${file}`, import.meta.url), "utf8");
    assert.match(text, /^export const maxDuration = 300;$/m);
  });
}
