// tests/_press-scan.js — WHICH ELEMENTS CAN BE PRESSED, AND WHICH CLASSES ANSWER A PRESS
// ==============================================================================
// Shared by tests/press.test.js (apple-design A1: every pressable answers on
// pointer-down) and anything else that needs the same two readings. Kept out of the
// test file so the scanner itself can be tested against constructed source.
//
// WHY A SOURCE SCAN AND NOT A BROWSER. The rule is about every pressable in the app,
// including ones only reachable after a sign-in, a live ledger or a failed sync. A
// browser can only press what a fixture shows it; the source names every class a
// pressable can wear. The scan is deliberately conservative: it reads string literals
// inside `className`, so a class built at runtime from a variable is not seen — and an
// element whose classes it cannot see is held to the kit-level catch-all instead.

import { readFileSync } from "node:fs";
import path from "node:path";

/** Strip /* *\/ comments from CSS, keeping line breaks. */
function stripCssComments(css) {
  return css.replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, " "));
}

/**
 * Every class that has an `:active` rule of its own in the given CSS, as a Set.
 *
 * A rule counts when one of its comma-separated selectors names the class AND carries
 * `:active` on the same compound (`.row:active`, `.btn-commit:active`). A rule inside
 * `prefers-reduced-motion` counts too: reduced motion removes the scale, never the
 * colour, so the class still answers.
 */
export function classesWithActive(css) {
  const out = new Set();
  const src = stripCssComments(css);
  for (const m of src.matchAll(/([^{}]+)\{/g)) {
    for (const sel of m[1].split(",")) {
      if (!sel.includes(":active")) continue;
      // The compound that carries :active, and any class on it.
      for (const compound of sel.trim().split(/[\s>+~]+/)) {
        if (!compound.includes(":active")) continue;
        for (const c of compound.matchAll(/\.([A-Za-z_][\w-]*)/g)) out.add(c[1]);
      }
    }
  }
  return out;
}

/** The JSX opening tags in a source file: `{ tag, attrs, line }`, braces balanced. */
export function openingTags(src) {
  const tags = [];
  // `Link` is next/link's anchor: it renders an <a href>, so it is read as one. The
  // conversation's "‹ July" back link was a <Link> the scan never saw (eval r2, A1).
  const re = /<([a-z][a-z0-9]*|Link)\b/g;
  let m;
  while ((m = re.exec(src))) {
    let i = re.lastIndex;
    let depth = 0;
    let quote = null;
    for (; i < src.length; i++) {
      const ch = src[i];
      if (quote) {
        if (ch === "\\") { i++; continue; }
        if (ch === quote) quote = null;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === "`") { quote = ch; continue; }
      if (ch === "{") depth++;
      else if (ch === "}") depth--;
      else if (ch === ">" && depth === 0) break;
      else if (ch === "<" && depth === 0) { i = -1; break; } // not a tag (a comparison)
    }
    if (i < 0) continue;
    const attrs = src.slice(re.lastIndex, i);
    const line = src.slice(0, m.index).split("\n").length;
    tags.push({ tag: m[1] === "Link" ? "a" : m[1], attrs, line });
  }
  return tags;
}

/** The class tokens a tag's `className` names in string literals. */
export function classTokens(attrs) {
  const at = attrs.search(/\bclassName\s*=/);
  if (at < 0) return [];
  let rest = attrs.slice(at).replace(/^className\s*=\s*/, "");
  let expr;
  if (rest[0] === '"' || rest[0] === "'") {
    expr = rest.slice(0, rest.indexOf(rest[0], 1) + 1);
  } else if (rest[0] === "{") {
    let depth = 0, i = 0;
    for (; i < rest.length; i++) {
      if (rest[i] === "{") depth++;
      else if (rest[i] === "}" && --depth === 0) break;
    }
    expr = rest.slice(0, i + 1);
  } else return [];
  const out = [];
  for (const s of expr.matchAll(/"([^"]*)"|'([^']*)'|`([^`]*)`/g)) {
    const text = (s[1] ?? s[2] ?? s[3] ?? "").replace(/\$\{[^}]*\}/g, " ");
    for (const t of text.split(/\s+/)) if (/^[A-Za-z_][\w-]*$/.test(t)) out.push(t);
  }
  return out;
}

/**
 * Is this tag something a person presses? A `<button>`, a `<summary>`, anything with
 * `role="button"`, `role="tab"` or `role="option"`, and any element with an `onClick`.
 * Every link with an href is pressable too. Iteration 2 first counted only links drawn
 * as rows or chips, and the conversation's back link, a plain text link at the top of
 * every conversation, gave no sign of a press and failed A1 on every sample (eval r2).
 */
export function isPressable({ tag, attrs }, tokens) {
  if (tag === "button" || tag === "summary") return true;
  if (/\brole\s*=\s*["'](button|tab|option|menuitem)["']/.test(attrs)) return true;
  if (/\bonClick\s*=/.test(attrs)) return true;
  if (tag === "a" && /\bhref\s*=/.test(attrs)) return true;
  return false;
}

/** Read every pressable in the given files: `{ file, line, tag, tokens }`. */
export function pressables(root, files) {
  const out = [];
  for (const file of files) {
    const src = readFileSync(path.join(root, file), "utf8");
    for (const t of openingTags(src)) {
      const tokens = classTokens(t.attrs);
      if (isPressable(t, tokens)) out.push({ file, line: t.line, tag: t.tag, tokens });
    }
  }
  return out;
}
