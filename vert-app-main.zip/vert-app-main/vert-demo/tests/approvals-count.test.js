// tests/approvals-count.test.js — ONE FACT, ONE NUMBER
// ==============================================================================
// FOUND IN A BROWSER, on vert-platform.vercel.app, tenant `vansh-live`,
// 2026-08-18. The Approvals screen stated one fact four contradicting ways:
//
//   page header   "3 draft journal entries"
//   queue heading "Approval queue 1"
//   pager         "1—1 of 1"
//   chips         Pending(1) High risk(2) JE(3) Recs(1) Payments(0) Me(0) Confident(1)
//
// It was a STATE bug and not a copy bug: each surface counted for itself.
//
// RE-POINTED BY G1, 2026-09-30. The approvals queue, its chips, pager, detail pane and
// the register head this file compared were all deleted with the register screens
// (spec §12.1), and the agent workspace replaced "count for yourself" with one unit,
// decisions, computed once by the engine (spec §1.3, UI-001). tests/month.test.js holds
// Month-end's header, the sidebar's input and the task rows to one fixture payload. What
// this file now holds is the same invariant on the REAL export, across the three places
// a decision is counted or drawn:
//
//   · the month's `counts.decisions` is the sum of its tasks' `decisions` (the engine
//     agreeing with itself — a screen that shows both must never have to choose);
//   · each needs-you task's count is the number of open decisions its own conversation
//     carries, so the "Approve journal entries · 23 decisions" row opens onto 23 things;
//   · the sidebar badge and the Month-end header state the same number, off two reads.
//
// Count ledger: the 26 queue, chip, pager and pane cases retired with those
// components; 5 cases here, all on the export.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { render, textOf } from "./_harness/render.js";
import { ENGINE } from "./_harness/engine.js";
import { readConversation, readMonth } from "../lib/agent/client.js";
import { openItems, verdictLine } from "../components/month/model.js";
import { readShellData } from "../components/shell/shell-data.js";
import MonthView from "../components/month/MonthView.js";

const MONTHS = Object.values(ENGINE.close.months);

test("PRECONDITION: the export records months with decisions in them", () => {
  assert.ok(MONTHS.length >= 1);
  assert.ok(MONTHS.some((m) => m.counts.decisions > 0), "no recorded month has a decision; nothing below can disagree");
});

test("every month's decisions are the sum of its tasks' decisions", () => {
  for (const month of MONTHS) {
    const sum = month.tasks.reduce((n, t) => n + t.decisions, 0);
    assert.equal(month.counts.decisions, sum, `${month.period}: the header and the rows would state different numbers`);
  }
});

test("each needs-you task's count is the number of open decisions its conversation carries", async () => {
  // A row reading "23 decisions" that opens onto 24 cards (or 22) is the chip-and-heading
  // defect in the new unit. Counted as the conversation's open items: action requests
  // not yet settled and questions not yet answered — the per-entry cards, not the
  // Approve-many shortcut, which decides the same 23 things and is not a 24th.
  for (const month of MONTHS) {
    for (const task of month.tasks.filter((t) => t.status === "Needs you")) {
      const convo = await readConversation(task.sessionId);
      assert.ok(convo.ok, `${month.period} ${task.template}: its conversation is not recorded`);
      const open = openItems(convo.events).filter((i) => !(i.type === "action" && i.action.kind === "approve_many"));
      assert.equal(open.length, task.decisions, `${month.period} ${task.template}: the row says ${task.decisions}, the conversation holds ${open.length}`);
    }
  }
});

test("a task with no decisions is not Needs you, and a Needs-you task has at least one", () => {
  for (const month of MONTHS) {
    for (const t of month.tasks) {
      if (t.status === "Needs you") assert.ok(t.decisions > 0 || t.problem, `${month.period} ${t.template} needs you with nothing to decide and no problem`);
      else assert.equal(t.decisions, 0, `${month.period} ${t.template} is ${t.status} and still counts decisions`);
    }
  }
});

// DESIGN-FIX-2 (DA2-006): the header says the tasks done, once. CHECKLIST U61 (verify pass 1
// F-9): the header ALSO says the decisions, as the same figure as the badge and the pager
// ("13 for you to decide"), never the tasks that need you. All read the same payload.
// 9 Nov 2026: the badge is the TASKS that need you (the band's figure); the header names no
// second count.
test("the sidebar badge reads the tasks that need you; the Month-end header states its tasks done", async () => {
  const shell = await readShellData({ engine: ENGINE });
  const read = await readMonth(shell.period);
  assert.ok(read.ok);
  const header = textOf(render(MonthView, { month: read.month, period: read.month.period, itemsByTask: {} }));
  assert.ok(header.includes(verdictLine(read.month)));
  const shown = header.match(/(\d+) of (\d+) tasks? done/) || [];
  assert.equal(shell.decisions, read.month.counts.needsYou, "the sidebar's badge input is not the month's Needs you count");
  assert.deepEqual([Number(shown[1]), Number(shown[2])], [read.month.counts.done, read.month.counts.total], "the header states a different count from the payload's");
  assert.doesNotMatch(header, /decisions? needs? you/, "the header names a sixth idea");
  assert.doesNotMatch(header, /for you to decide/, "the header says a second count");
});
