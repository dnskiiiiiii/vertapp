// tests/aging-engine-output.test.js — THE READERS TAKE WHAT THE ENGINE ACTUALLY SENDS
// ==============================================================================
// tests/fixtures/aging-shape-engine.json is real output of the engine's
// vert_engine.aging.shape_side and vert_engine.reminders.shape_reminders (validated
// against agent_events.AnswerShape there), not a hand-written stand-in. If the two
// halves drift, this is the test that says so.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { ROOT } from "./_harness/source.js";
import { agedBalancesOf } from "../components/chat/answer/aged-balances.js";
import { remindersOf } from "../components/chat/answer/reminders.js";

const shape = JSON.parse(readFileSync(path.join(ROOT, "tests/fixtures/aging-shape-engine.json"), "utf8"));

test("every side the engine sends is read, with its own totals and the draft action", () => {
  const sides = agedBalancesOf(shape.agedBalances);
  assert.equal(sides.length, 2);
  const [rec, pay] = sides;
  assert.equal(rec.side, "receivables");
  assert.deepEqual(rec.currencies.map((c) => c.currency), ["AUD", "NZD"]);
  assert.equal(rec.currencies[0].totalCents, shape.agedBalances[0].currencies[0].totalCents);
  assert.equal(rec.action.kind, "draft_reminders");
  assert.equal(pay.side, "payables");
  assert.equal(pay.action, null);
});

test("every draft the engine sends is read, the recently reminded one held for a second yes", () => {
  const rem = remindersOf(shape.reminders);
  assert.deepEqual(rem.drafts.map((d) => d.contactName), ["Acme", "Cove", "Kiwi"]);
  const [acme, cove] = rem.drafts;
  assert.equal(acme.needsConfirm, true);
  assert.equal(acme.lastRemindedOn, "2026-10-25");
  assert.equal(cove.to, null);
  assert.ok(cove.toWords);
});

test("the engine's v2 drafts carry their editable words and are sendable as drafted", async () => {
  const { canSendDraft, emailOf } = await import("../components/chat/answer/reminders.js");
  const rem = remindersOf(shape.reminders);
  const [acme] = rem.drafts;
  assert.ok(acme.intro && acme.closing);
  assert.equal(canSendDraft(acme, rem.sender).ok, true);
  const email = emailOf(acme);
  assert.equal(email.body, undefined);
  assert.equal(email.intro, acme.intro);
  assert.equal(email.draftId, shape.reminders.drafts[0].draftId);
});
