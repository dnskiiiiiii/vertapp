// tests/aging-phone-labels.test.js — AT 390 PX EVERY AGED FIGURE KEEPS ITS BUCKET'S NAME
// ==============================================================================
// Staging browser walk 1 (31 Oct 2026, D12): at 390 px the aged table's rows became
// cards of bare figures ($0.00 / $6,187.50 / $0.00 …) with no "Current / 1–30 / …".
// The answer's tables stack on a phone (app/styles/chat.css .shape-table, max-width
// 640px): the column header is hidden and each cell prints its own `data-label` before
// its value. AgedBalances' cells carried none, and its row heading is a <th>, which the
// stacked layout didn't place. Now every figure says its bucket, and the contact leads.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { render } from "./_harness/render.js";
import { ROOT, read } from "./_harness/source.js";
import AgedBalances from "../components/chat/answer/AgedBalances.js";

const FIX = JSON.parse(readFileSync(path.join(ROOT, "tests", "fixtures", "aging-shape.json"), "utf8"));

test("every figure cell in the aged table names its bucket, or Total", () => {
  const html = render(AgedBalances, { agedBalances: FIX.agedBalances, ledgerName: "Xero" });
  const tables = [...html.matchAll(/<table class="shape-table aging-table"[\s\S]*?<\/table>/g)].map((m) => m[0]);
  assert.ok(tables.length >= 1, "no aged table drawn");
  for (const table of tables) {
    const heads = [...table.matchAll(/<th scope="col"[^>]*>([\s\S]*?)<\/th>/g)].map((m) => m[1].replace(/<[^>]+>/g, "").trim());
    const body = table.slice(table.indexOf("<tbody"));
    const cells = [...body.matchAll(/<td\b([^>]*)>/g)].map((m) => m[1]);
    assert.ok(cells.length > 0);
    for (const attrs of cells) {
      const label = (attrs.match(/data-label="([^"]*)"/) || [])[1];
      assert.ok(label, `a figure has no label to show at 390 px: <td${attrs}>`);
      assert.ok(heads.includes(label.replace(/&amp;/g, "&")), `"${label}" is not one of the table's headings (${heads.join(", ")})`);
    }
  }
});

test("on a phone the contact (a row heading) leads its card, across the full width", () => {
  const css = read("components/chat/answer/aging.css");
  assert.match(css, /@media \(max-width: 640px\)[\s\S]*\.aging-table tbody th[^{]*\{[^}]*grid-column: 1 \/ -1/);
});
