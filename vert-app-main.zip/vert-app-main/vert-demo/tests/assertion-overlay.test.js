// tests/assertion-overlay.test.js — THE DEGRADE SIGNAL, AND EVERY SCREEN THAT OWES IT
// =============================================================================
// WHAT IS BEING GUARDED.
//
// `GET /payouts` and `GET /payouts/{id}` now carry `assertionsMeasured` and
// `assertionsUnmeasuredReason`: whether a reviewer's recorded answers were applied to
// the figures on the response, and — when they were not — the engine's own sentence
// saying which absence it is. Before that, both routes served pre-assertion figures as
// though measured, with nothing on the wire to say so.
//
// Reproduced against a live tenant on 2026-08-25, with the `assertions` relation
// renamed away, on a payout whose clean state rests entirely on two recorded answers:
//
//     GET /payouts/po_8Hm  →  exceptions: ["unclassified_txn"]
//                             state.status: "awaiting_approval"
//                             assertionsMeasured: false
//
// Two honest readings of one payout, computed from different inputs. The body is only
// coherent because the third line is on it. This file is the demo's half: the third
// line has to reach a person.
//
// THREE STATES AND NOT TWO, WHICH IS MOST OF THE POINT. `true` is a real measurement —
// the engine performs a live read rather than asking whether a store exists. `false` is
// a real measurement. An ABSENT field is neither, and the standing rule on this project
// is that it renders as unknown IN WORDS and never as clean. A boolean coerced from a
// missing key is how "nobody looked" becomes "nothing to see".
//
// TWO KINDS OF ASSERTION, AND THE SECOND IS THE ONE THIS REPO KEEPS NEEDING.
// Twenty-four mutations have survived their first test on this project, and the
// recurring shape is a mutation that DELETES A CALL SITE while leaving a perfect
// function behind. So the pure functions are tested as functions, and every surface is
// tested by RENDERING THE REAL COMPONENT and reading the words out of the markup —
// never by asserting that a module exports a sentence.
//
// WHERE A SOURCE SCAN IS USED IT READS THE RAW FILE. `stripNonCode` blanks string
// literals, and a scan for a rendered sentence — or for a route, which is a string
// literal — can never see its subject through it. That trap cost this project a
// green run last round and is not repeated here.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { render, textOf } from "./_harness/render.js";
import { read } from "./_harness/source.js";
// STATIC_ENGINE DIRECTLY, for the reason tests/absent-is-not-clean.test.js gives:
// `_harness/engine.js` memoises the payout feeds against this payload at import time.
import { STATIC_ENGINE as ENGINE, loadFromApi } from "../lib/engine-source.js";
import {
  MEASURED,
  SHORT_UNAPPLIED,
  SHORT_UNKNOWN,
  TITLE_UNAPPLIED,
  TITLE_UNKNOWN,
  UNAPPLIED_REASON,
  UNKNOWN,
  UNKNOWN_REASON,
  UNMEASURED,
  combineAssertionSignals,
  overlayCaveat,
  readAssertionSignal,
} from "../lib/assertion-overlay.js";
import { workingPaper } from "../lib/working-paper.js";
import { workingPaperHtml } from "../lib/working-paper-html.js";

// The engine's real sentence, copied out of vert_engine/state/repository.py
// ASSERTIONS_TABLE_ABSENT. Used verbatim so the tests below assert on the words a
// reviewer would actually be shown rather than on a placeholder.
const ENGINE_REASON =
  "This database has no `assertions` table, so no human's answer could be read and " +
  "none is applied below. Migration 0004 creates it. This is not the same as nobody " +
  "having answered: nothing was looked at.";

/* ════════════════════════════════════════════════════════════════════════════ *
 * 1 — READING ONE ROUTE'S ANSWER
 * ════════════════════════════════════════════════════════════════════════════ */

test("a live `true` is measured, and carries no reason", () => {
  const s = readAssertionSignal({ assertionsMeasured: true, assertionsUnmeasuredReason: null });
  assert.equal(s.state, MEASURED);
  assert.equal(s.reason, null);
});

test("a live `false` is unmeasured, and carries the ENGINE'S sentence verbatim", () => {
  const s = readAssertionSignal({
    assertionsMeasured: false,
    assertionsUnmeasuredReason: ENGINE_REASON,
  });
  assert.equal(s.state, UNMEASURED);
  // Verbatim. A renderer free to write its own words for "nobody looked" writes a
  // gentler one eventually.
  assert.equal(s.reason, ENGINE_REASON);
});

test("an ABSENT field is unknown — never measured, and never unmeasured either", () => {
  // The whole rule, in one assertion. A deployment too old to send the key has not
  // told us the overlays were applied; it has told us nothing.
  assert.equal(readAssertionSignal({}).state, UNKNOWN);
  assert.equal(readAssertionSignal(null).state, UNKNOWN);
  assert.equal(readAssertionSignal({ assertionsMeasured: null }).state, UNKNOWN);
});

test("a TRUTHY STRING does not promote into a measurement", () => {
  // The standing rule on this project: a truthy string must not promote into a
  // reassurance. `"false"` is the one that matters — it is truthy — but `"true"` is
  // refused for the same reason, because a build sending strings has not been
  // understood well enough to be believed either way.
  assert.equal(readAssertionSignal({ assertionsMeasured: "false" }).state, UNKNOWN);
  assert.equal(readAssertionSignal({ assertionsMeasured: "true" }).state, UNKNOWN);
  assert.equal(readAssertionSignal({ assertionsMeasured: 1 }).state, UNKNOWN);
  assert.equal(readAssertionSignal({ assertionsMeasured: 0 }).state, UNKNOWN);
});

/* ════════════════════════════════════════════════════════════════════════════ *
 * 2 — ONE ANSWER FOR A PAGE LOAD BUILT FROM MANY READS
 * ════════════════════════════════════════════════════════════════════════════ */

test("one read that lost the overlays condemns the whole page load", () => {
  // THE MID-REQUEST DEGRADE, WHICH IS HOW THIS ACTUALLY HAPPENS. The repository turns
  // the overlays off after the read that failed, so the register — fetched first — can
  // honestly answer `true` while a payout fetched a moment later answers `false`. A
  // screen marked from the register alone would be marked clean on the strength of the
  // read that happened BEFORE the failure.
  const combined = combineAssertionSignals([
    { state: MEASURED, reason: null },
    { state: MEASURED, reason: null },
    { state: UNMEASURED, reason: ENGINE_REASON },
    { state: MEASURED, reason: null },
  ]);
  assert.equal(combined.state, UNMEASURED);
  assert.equal(combined.reason, ENGINE_REASON);
});

test("an unknown read is not covered by a measured one", () => {
  const combined = combineAssertionSignals([
    { state: MEASURED, reason: null },
    { state: UNKNOWN, reason: null },
  ]);
  assert.equal(combined.state, UNKNOWN);
});

test("measured only when EVERY read said so, and never from an empty list", () => {
  assert.equal(combineAssertionSignals([{ state: MEASURED, reason: null }]).state, MEASURED);
  // Nothing was asked. That is not a clean answer.
  assert.equal(combineAssertionSignals([]).state, UNKNOWN);
  assert.equal(combineAssertionSignals(null).state, UNKNOWN);
});

/* ════════════════════════════════════════════════════════════════════════════ *
 * 3 — THE PAYLOAD ALWAYS CARRIES IT
 * ════════════════════════════════════════════════════════════════════════════ */

// A minimal API, enough for loadFromApi to assemble a payload. The point of these two
// tests is the `assertions` key, so everything else is the smallest thing that passes
// the shape checks.
function fakeApi({ registerSignal = {}, detailSignal = {} } = {}) {
  const ids = ["po_1"];
  const detail = {
    payout: { id: "po_1", amount: 1000, currency: "AUD", arrival_date: "2026-06-01" },
    txns: [],
    decomp: { groups: [], sumNet: 0, delta: 0, integrityOk: true, suspenseNet: 0 },
    je: { lines: [], balanced: true, sumDr: 0, sumCr: 0 },
    tie: { status: "matched", candidates: [] },
    summary: {},
    exceptions: [],
    ...detailSignal,
  };
  return async (url) => {
    const body = (payload) => ({
      ok: true,
      status: 200,
      headers: { get: () => "application/json" },
      json: async () => payload,
      text: async () => JSON.stringify(payload),
    });
    if (url.includes("/payouts?")) {
      return body({
        business: "B",
        period: "2026-06",
        payouts: [{ id: "po_1" }],
        page: { total: 1, returned: 1, limit: 100, offset: 0 },
        ...registerSignal,
      });
    }
    if (url.includes("/bank-lines")) return body({ bankLines: [] });
    if (url.includes("/proposals")) return body({ proposals: [], page: { total: 0, returned: 0, limit: 100, offset: 0 } });
    if (url.includes("/exceptions")) return body({ untraceable: [], chartGaps: [], chartGapsMeasured: true });
    if (url.includes("/payouts/")) return body(detail);
    throw new Error(`unexpected ${url}`);
  };
}

test("an API payload ALWAYS carries `assertions`, even when the wire said nothing", async () => {
  // THE INVARIANT THE WHOLE SIGNAL RESTS ON. `overlayCaveat` reads the key's ABSENCE as
  // "this is the static showpiece, which has no overlay layer to lose" and prints
  // nothing. So an API payload that dropped the key would be rendered as clean — the
  // exact reassurance this file exists to prevent — and the older deployment that sends
  // no such field is the likeliest way to produce one.
  const engine = await loadFromApi("http://vert-api.invalid:8000", { fetchImpl: fakeApi() });
  assert.ok(engine.assertions, "the payload must carry an `assertions` answer");
  assert.equal(engine.assertions.state, UNKNOWN);
  // And it renders as words, not as silence.
  assert.equal(overlayCaveat(engine).state, UNKNOWN);
});

test("a register that measured and a detail that did not comes back UNMEASURED", async () => {
  // The mid-request degrade, end to end through the real loader rather than through
  // `combineAssertionSignals` alone: a detail read is where it actually shows up, and a
  // loader that collected the register's answer and forgot the details' would pass the
  // unit test above and ship the defect.
  const engine = await loadFromApi("http://vert-api.invalid:8000", {
    fetchImpl: fakeApi({
      registerSignal: { assertionsMeasured: true, assertionsUnmeasuredReason: null },
      detailSignal: { assertionsMeasured: false, assertionsUnmeasuredReason: ENGINE_REASON },
    }),
  });
  assert.equal(engine.assertions.state, UNMEASURED);
  assert.equal(engine.assertions.reason, ENGINE_REASON);
});

test("both reads measured is the only way to a measured payload", async () => {
  const engine = await loadFromApi("http://vert-api.invalid:8000", {
    fetchImpl: fakeApi({
      registerSignal: { assertionsMeasured: true, assertionsUnmeasuredReason: null },
      detailSignal: { assertionsMeasured: true, assertionsUnmeasuredReason: null },
    }),
  });
  assert.equal(engine.assertions.state, MEASURED);
  assert.equal(overlayCaveat(engine), null, "nothing to warn about");
});

/* ════════════════════════════════════════════════════════════════════════════ *
 * 4 — WHAT A SURFACE IS HANDED
 * ════════════════════════════════════════════════════════════════════════════ */

test("the static showpiece prints nothing: there is no overlay layer to lose", () => {
  // The ONE case that is silent rather than caveated, and it is silent for a reason
  // rather than by omission: this build's decisions live in lib/store.js, there is no
  // API and no `assertions` relation, and nothing could have failed to be overlaid.
  assert.equal(ENGINE.assertions, undefined, "the committed export carries no such key");
  assert.equal(overlayCaveat(ENGINE), null);
});

test("a measured close prints no reassurance either", () => {
  // NO "the answers were applied" BANNER. A caveat that appears on every page teaches
  // its readers to skim the box, and the one time it matters they will skim that too.
  assert.equal(overlayCaveat({ assertions: { state: MEASURED, reason: null } }), null);
});

test("unmeasured hands over what it costs AND the engine's own reason", () => {
  const c = overlayCaveat({ assertions: { state: UNMEASURED, reason: ENGINE_REASON } });
  assert.equal(c.state, UNMEASURED);
  assert.equal(c.body, UNAPPLIED_REASON);
  assert.equal(c.detail, ENGINE_REASON);
  // The costs, named. These are the two consequences a reader cannot work out for
  // themselves from "the overlay failed".
  assert.match(c.body, /classified will read as\s+unmapped/);
  assert.match(c.body, /unblocked will read as blocked/);
  // And it refuses to be read as "nobody answered".
  assert.match(c.body, /not a claim that nobody\s+answered/);
});

test("unknown says UNKNOWN in words, and invents no engine sentence to sit beside it", () => {
  const c = overlayCaveat({ assertions: { state: UNKNOWN, reason: null } });
  assert.equal(c.state, UNKNOWN);
  assert.equal(c.body, UNKNOWN_REASON);
  assert.match(c.body, /UNKNOWN/);
  // Not softened into "probably fine", and not hardened into the known degrade either.
  assert.notEqual(c.body, UNAPPLIED_REASON);
  assert.equal(c.detail, null, "there is no engine sentence to quote, so none is shown");
});

/* ════════════════════════════════════════════════════════════════════════════ *
 * 5 — THE COMPONENT, RENDERED
 * ════════════════════════════════════════════════════════════════════════════ */

// RETIRED BY G1, 2026-09-30 — these rendered OverlayCaveat, the register's Status column
// (PayoutTable), the register's deep links (ReconcileScreen) and the exceptions page,
// all deleted with the register screens (spec §12.1). The three-state signal and the
// working paper's caveat are kept; the deep link is held on Records below. FINDING,
// named in G1's handoff: when the API could not apply a reviewer's recorded answers
// (assertionsMeasured false or absent), Month-end, Records and the chat say nothing —
// only the working paper carries the caveat. Count ledger:
//   · OverlayCaveat renders the sentences, the scope and the engin
//   · OverlayCaveat renders NOTHING when there is nothing to say
//   · the caveat is a caution, not a break in the books
//   · the register's Status column says the word in it was not ame
//   · the Status column says UNKNOWN when the deployment did not a
//   · the Status column carries no marker on a measured close
//   · the exceptions register prefers the measured answer to the o
//   · a deep link to a payout PAST THE FIRST PAGE opens its panel
//   · a deep link to a payout ON the first page still opens it
//   · the last payout in the register is reachable by its own link
//   · no deep link leaves the register on page one with nothing op
//   · an unknown payout id opens nothing and still renders the reg
//   · a caveat nested inside one that said it in full does not rep
//   · one register page shows the explanation exactly once, with a

/* ════════════════════════════════════════════════════════════════════════════ *
 * 6 — THE REGISTER'S STATUS COLUMN
 * ════════════════════════════════════════════════════════════════════════════ */

// The payload is mutated and put back, rather than cloned, for the reason
// tests/absent-is-not-clean.test.js records: under the render harness `useEngine()`
// serves STATIC_ENGINE regardless, so a clone never reaches the component. The
// `finally` is what keeps this from leaking into the next test in this file — the
// suite's one piece of shared module state, and it is deliberately confined here.
function withAssertions(state, reason, fn) {
  const had = "assertions" in ENGINE;
  const prior = ENGINE.assertions;
  ENGINE.assertions = { state, reason };
  try {
    return fn();
  } finally {
    if (had) ENGINE.assertions = prior;
    else delete ENGINE.assertions;
  }
}

const EMPTY_TABLE_PROPS = {
  runs: [],
  total: 0,
  openId: null,
  onToggle: () => {},
  density: { value: "comfortable", set: () => {} },
  filters: { query: "", processors: [], statuses: [] },
  page: { from: 0, to: 0, total: 0, page: 1, pageCount: 1, onPage: () => {}, pageSize: 10, pageSizes: [10] },
  selection: { ids: [], onToggle: () => {}, onToggleAll: () => {}, onClear: () => {} },
};

test("the four exported sentences are the words they claim to be", () => {
  /* WHY A LITERAL PIN, AFTER ROUND 17 SPENT A COMMIT REMOVING LITERALS.
   *
   * Round 17 was right that a guard forbidding a HAND-WRITTEN FRAGMENT of a sentence
   * drifts: reword the heading and the negative goes on forbidding something nothing
   * can emit. So every other assertion in this file now points at the exported
   * constant. What that bought in stability it cost in reach — every one of those
   * assertions is `text.includes(TITLE_UNKNOWN)` or `new RegExp(SHORT_UNKNOWN)`, and
   * an empty or nonsense constant satisfies all of them. `includes("")` is true, and
   * `new RegExp("")` matches anything. Found on 2026-08-25 while triaging why
   * `/were applied/i` probes UNANCHORED: blanking the literal in lib/assertion-overlay.js
   * leaves the whole suite green.
   *
   * The fix is not to go back to fragments. It is to pin the words ONCE, here, named as
   * the vocabulary contract, so that every other use can go on reading the constant and
   * still cannot be satisfied by a constant that has stopped saying anything. A
   * deliberate rewording changes one line in this file; an accidental erasure changes
   * nothing and goes red.
   *
   * The rules the words themselves have to keep: each says what was NOT established,
   * names whose answers, and never reads as a property of the payout. */
  assert.equal(SHORT_UNAPPLIED, "Reviewers' answers not applied to this figure.");
  assert.equal(SHORT_UNKNOWN, "Not stated whether reviewers' answers were applied.");
  assert.equal(TITLE_UNAPPLIED, "No reviewer's answer could be read");
  assert.equal(TITLE_UNKNOWN, "Not known whether reviewers' answers were applied");
  for (const s of [SHORT_UNAPPLIED, SHORT_UNKNOWN, TITLE_UNAPPLIED, TITLE_UNKNOWN]) {
    assert.ok(s.length > 20, "a sentence this suite matches on has been emptied out");
    assert.doesNotMatch(s, /verified|clean|fine|no issues/i, "an unmeasured read reads as reassurance");
  }
});

/* ════════════════════════════════════════════════════════════════════════════ *
 * 7 — THE WORKING PAPER
 * ════════════════════════════════════════════════════════════════════════════ */

test("the working paper carries the caveat, at the top, before the first figure", () => {
  // THE ONE ARTEFACT THAT CANNOT BE RE-READ. Every screen gets a second chance at a
  // refresh; a printout does not, and this is the document somebody files.
  const id = ENGINE.payoutIds[0];
  const { paper, html } = withAssertions(UNMEASURED, ENGINE_REASON, () => {
    const paper = workingPaper(ENGINE, id);
    return { paper, html: workingPaperHtml(paper) };
  });
  assert.equal(paper.overlay.state, UNMEASURED);

  assert.ok(html.includes("No reviewer's answer could be read"), "the caveat is on the paper");
  assert.ok(html.includes("Migration 0004 creates it"), "the engine's own sentence is on it");
  assert.ok(
    html.includes("including the sign-off block"),
    "the paper says the condition covers the sign-off, which is the block a reader trusts most"
  );

  // ABOVE THE FIRST FIGURE. A caveat printed after the settlement facts is a caveat
  // read after they have been believed.
  assert.ok(
    html.indexOf("No reviewer's answer could be read") < html.indexOf("<h2>The settlement</h2>"),
    "the caveat must precede the settlement facts"
  );
});

test("a measured close leaves the paper with no caveat and no reassurance", () => {
  // The same correction as the Status column above: /answer could be read/ and
  // /answers were applied/ were hand-written fragments of the two headings, which are
  // now TITLE_UNAPPLIED and TITLE_UNKNOWN. The paper is driven in both states that DO
  // print a heading, so this test knows the absence it asserts is an absence and not a
  // heading that has been reworded out from under it.
  const id = ENGINE.payoutIds[0];

  const unmeasured = withAssertions(UNMEASURED, ENGINE_REASON, () =>
    workingPaperHtml(workingPaper(ENGINE, id))
  );
  assert.ok(unmeasured.includes(TITLE_UNAPPLIED), "the UNMEASURED paper carries its heading");
  const unknown = withAssertions(UNKNOWN, null, () =>
    workingPaperHtml(workingPaper(ENGINE, id))
  );
  assert.ok(unknown.includes(TITLE_UNKNOWN), "the UNKNOWN paper carries its heading");

  const html = withAssertions(MEASURED, null, () => workingPaperHtml(workingPaper(ENGINE, id)));
  assert.ok(!html.includes(TITLE_UNAPPLIED), "a measured close carried the UNMEASURED heading");
  assert.ok(!html.includes(TITLE_UNKNOWN), "a measured close carried the UNKNOWN heading");
});

/* ════════════════════════════════════════════════════════════════════════════ *
 * 8 — THE CALL SITES
 * ════════════════════════════════════════════════════════════════════════════ */
//
// THE MUTATION THIS SECTION CATCHES, and it is the one that has survived first on this
// project twenty-four times: a perfect `overlayCaveat` and a screen that stops calling
// it. Sections 5 to 7 render three of the surfaces; the other four are a server
// component, a client screen needing interaction, and two panes that need a payout
// installed to mount at all. For those, the call site itself is the assertion.
//
// THE FILES ARE READ RAW. `stripNonCode` blanks string literals, so a scan for a JSX
// tag would survive it but a scan for a rendered sentence would not — and a scan that
// cannot see its subject is a test that can never fail. Read whole, matched on the
// mounted component AND on the payload it is handed, because a mounted
// `<OverlayCaveat caveat={null} />` is a call site that renders nothing forever.

// RE-POINTED BY G1, 2026-09-30. The six call sites this listed — the approvals page and
// pane, the exceptions page, the register, its panel and the AI rail — were all deleted
// with the register screens (spec §12.1), and on the first run against the screen that
// replaced them this section found Records silent on an unmeasured payload. The caveat
// was restored on Records (components/records/RecordsScreen.js) and is RENDERED here,
// under a payload in each of the three states, rather than scanned for.

import RecordsScreen from "../components/records/RecordsScreen.js";

test("Records mounts the caveat, above the list, from the engine's own answer", () => {
  const src = read("components/records/RecordsScreen.js");
  assert.match(src, /overlayCaveat\(engine\)/, "Records no longer reads the engine's answer");
  const at = src.indexOf("records-caveat");
  assert.ok(at > 0 && at < src.indexOf("<Table"), "the caveat is not drawn above the list");
});

test("Records says, in words, that the answers were not applied — and nothing when they were", () => {
  const unmeasured = withAssertions(UNMEASURED, ENGINE_REASON, () => render(RecordsScreen, { tab: "payouts" }));
  assert.match(unmeasured, /data-overlay-state="unmeasured"/);
  assert.ok(textOf(unmeasured).includes(TITLE_UNAPPLIED), "an unmeasured list says nothing about it");
  assert.ok(textOf(unmeasured).includes(ENGINE_REASON), "the engine's own reason is not one press away");

  const unknown = withAssertions(UNKNOWN, null, () => render(RecordsScreen, { tab: "payouts" }));
  assert.ok(textOf(unknown).includes(TITLE_UNKNOWN), "an unknown read was drawn as clean");

  const measured = withAssertions(MEASURED, null, () => render(RecordsScreen, { tab: "payouts" }));
  assert.doesNotMatch(measured, /data-overlay-state=/, "a measured list carries a caveat");
});

/* ════════════════════════════════════════════════════════════════════════════ *
 * 9 — A SEPARATE FINDING FROM THE SAME SWEEP: THE DEEP LINK THAT OPENED NOTHING
 * ════════════════════════════════════════════════════════════════════════════ */
//
// `/payouts?payout=<id>` is THE address for a payout. `lib/exceptions.js` builds every
// exception row's "View payout" link from it, and it is the one route this product has
// from a finding to the settlement it is about.
//
// FOUND IN A BROWSER, SIGNED IN AGAINST THE API, 2026-08-25, while confirming the
// caveat above. ReconcileScreen set `openId` from the query and left `page` at 1, and
// the register renders only the current page's slice — so a link to any payout past the
// tenth landed on page one with no panel, no scroll and nothing said. On that tenant it
// was 17 of 27 payouts, every one of them reached by pressing "Investigate" on an
// exception.
//
// A CONTROL THAT LIES, which is the class this sweep is for: the press is registered,
// the URL changes, and the thing it promised does not happen.
//
// These tests live in this file rather than a new one because they were found by the
// same pass and share its fixtures. They render the REAL screen: the defect was a
// missing initial value, and any test that asserted on a computed page number rather
// than on the presence of the panel would have passed against the broken code.

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE DEEP LINK, ON RECORDS (G1, 2026-09-30). `/payouts?payout=<id>` redirects to
 * `/records?payout=<id>` with its query string, and Records opens that payout's sheet
 * on arrival. There is no pager to land on the wrong page of, so the old "past the
 * first page" cases reduce to: every payout's own link opens it, and an unknown one
 * opens nothing and still lists the month.
 * ══════════════════════════════════════════════════════════════════════════ */

test("every payout's own deep link opens its record sheet", () => {
  for (const id of ENGINE.payoutIds) {
    const html = render(RecordsScreen, { tab: "payouts", payoutId: id });
    assert.ok(html.includes(`data-record="${id}"`), `/records?payout=${id} opened nothing`);
  }
});

test("an unknown payout id opens nothing, and the list still renders", () => {
  const html = render(RecordsScreen, { tab: "payouts", payoutId: "po_not_a_payout" });
  assert.doesNotMatch(html, /data-record=/, "an unknown id opened a sheet");
  assert.equal((html.match(/<td data-label="Status"/g) || []).length, ENGINE.payoutIds.length);
});
