// tests/answer-shape-p4.test.js — EVERY TASK ANSWER IN THE FOUNDER'S ANSWER SHAPE (Q-SHAPE-1..5)
// ==============================================================================
// The founder, 17 Oct 2026 (research reference/answer-shape.md): "This is more what outputs
// should look like", and on the approve-entries pane: "it says 3 entries but it is not
// clear and intuitive enough, we need clear way to show 3 entries on the screen which they
// can see". The wire is verify/shape-contract.md (`assistant_text.shape`).
//
// Each check runs over EVERY answer type the fixtures carry (tests/shape-fixtures.js) and
// is driven against the defect it exists for:
//
//   Q-SHAPE-1  the work is an inline table, top rows plus "N more in the workbook"; an
//              unmeasured cell is words, never $0.00;
//   Q-SHAPE-2  four lines to the GL; ✓ only on a measured zero variance the engine called
//              tied — a `tied: true` over a non-zero or unread variance draws no ✓;
//   Q-SHAPE-3  "I've delivered N things", numbered, naming what happens next;
//   Q-SHAPE-4  the JE card inline: title, status · date, Account | Debit | Credit |
//              Description, Total, one primary action worded by createsDraft and role-aware;
//   Q-SHAPE-5  N entries are N numbered cards, a blocked one blocked on its own card, the
//              bulk naming what it covers, the headline's count what is on screen, and the
//              approve-entries pane opening on the entries with no counts-only Summary tab.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { render, textOf } from "./_harness/render.js";
import { threadModel } from "../lib/agent/events.js";
import ConversationView from "../components/chat/ConversationView.js";
import TableView from "../components/chat/results/TableView.js";
import { DeliveredList, StaticEntryCard, TieOut, WorkTable, tieOutState } from "../components/chat/answer/ShapeBlocks.js";
import { entriesPaneSheets, entryLayout, paneEntriesFor, shapeOf } from "../components/chat/answer/shape.js";
import { primaryActionOf } from "../components/chat/answer/shape-action.js";
import { drawnByShape } from "../components/chat/Thread.js";
import { ANSWER_TYPES, QB_LEDGER, XERO_DRAFT_LEDGER, shapeConversation } from "./shape-fixtures.js";

const view = ({ session, events }) => render(ConversationView, { sessionId: session.sessionId, session, events, replay: false, sources: [], ledgerName: "QuickBooks" });
const count = (html, re) => (html.match(re) || []).length;
const answerOf = (html) => {
  const at = html.indexOf('data-message="assistant_text"');
  assert.ok(at > 0, "no answer drawn");
  return html.slice(at);
};
const answerItem = (events) => threadModel(events).items.find((i) => i.kind === "answer");

/* ── Q-SHAPE-1 ─────────────────────────────────────────────────────────────── */

test("Q-SHAPE-1: every answer type draws its work as an inline table, in the answer, before the entries", () => {
  for (const type of ANSWER_TYPES.filter((t) => t !== "approve_entries")) {
    const convo = shapeConversation(type);
    const html = answerOf(view(convo));
    assert.equal(count(html, /class="shape-table"/g), 1, `${type}: no inline work table`);
    const shape = answerItem(convo.events).shape;
    for (const c of shape.work.columns) assert.match(html, new RegExp(`data-col="${c.key}">${c.label.replace(/[%]/g, "\\$&")}<`), `${type}: column ${c.label} missing`);
    // Money is right-aligned (the num class on its header and cells).
    const money = shape.work.columns.find((c) => c.kind === "money");
    assert.match(html, new RegExp(`<th scope="col" class="num" data-col="${money.key}"`), `${type}: money column not right-aligned`);
    // The work comes before the entry cards and the workbook chip.
    const table = html.indexOf('class="shape-table"');
    const card = html.indexOf('class="dcard jcard');
    if (card > 0) assert.ok(table < card, `${type}: the table is under the entry`);
  }
});

test("Q-SHAPE-1: a long schedule shows its top rows and says how many more are in the workbook", () => {
  const html = answerOf(view(shapeConversation("prepaid")));
  assert.match(textOf(html), /4 more in the workbook/);
  assert.equal(count(html.slice(html.indexOf('class="shape-table"'), html.indexOf("</table>")), /<tr data-role="figure"/g), 5);
});

test("Q-SHAPE-1 constructed defect: an unmeasured money cell reads as words, never $0.00", () => {
  const convo = shapeConversation("accruals");
  const html = answerOf(view(convo));
  const work = html.slice(html.indexOf('class="shape-work"'), html.indexOf("</table>"));
  assert.match(textOf(work), /Contractor hours Timesheet not received Not worked out yet/);
  assert.doesNotMatch(textOf(work), /\$0\.00/);
  // The same cell with its words stripped is not drawn as a zero either.
  const item = answerItem(convo.events);
  const bare = { ...item.shape.work, rows: item.shape.work.rows.map((r) => ({ ...r })) };
  const stripped = textOf(render(WorkTable, { work: bare }));
  assert.doesNotMatch(stripped, /\$0\.00/);
});

/* ── Q-SHAPE-2 ─────────────────────────────────────────────────────────────── */

test("Q-SHAPE-2: four lines to the GL on every answer type; the movement signed when it is taken off", () => {
  for (const type of ANSWER_TYPES.filter((t) => t !== "approve_entries")) {
    const html = answerOf(view(shapeConversation(type)));
    const block = html.slice(html.indexOf('class="shape-tieout"'));
    assert.equal(count(block.slice(0, block.indexOf("</ul>")), /class="shape-tie-line"/g), 4, `${type}: not four lines`);
    assert.match(block, /data-tie-kind="variance"/, `${type}: no variance line`);
  }
  const deferred = answerOf(view(shapeConversation("deferred_revenue")));
  // Verify pass 8 (S-BK-3): one negative style on screen, the minus, in every block
  // (tests/vf-demo-chat-p8-signs.test.js); the contract's brackets stay in the workbook.
  assert.match(deferred, /data-tie-kind="movement"><span class="shape-tie-label">Less July recognition:<\/span> <span class="shape-tie-amount num">−<span/);
});

test("Q-SHAPE-2: ✓ only where the variance is a measured zero; off in the problem ink; unchecked in words", () => {
  const tied = answerOf(view(shapeConversation("deferred_revenue")));
  assert.match(tied, /data-shape-tieout="tied"/);
  assert.equal(count(tied, /data-tie-tick=""/g), 1);
  const off = answerOf(view(shapeConversation("depreciation")));
  assert.match(off, /data-shape-tieout="off"/);
  assert.equal(count(off, /data-tie-tick=""/g), 0, "a variance that doesn't tie carries a tick");
  assert.match(off, /data-tie-off=""/);
  assert.match(textOf(off), /a disposal in June is in the register and not in the GL/);
  const unchecked = answerOf(view(shapeConversation("accruals")));
  assert.match(unchecked, /data-shape-tieout="unchecked"/);
  assert.equal(count(unchecked, /data-tie-tick=""/g), 0, "an unread GL carries a tick");
  assert.match(textOf(unchecked), /Couldn.t check against the GL: 2100 hasn.t synced since 30 Jun\./);
  assert.doesNotMatch(textOf(unchecked.slice(unchecked.indexOf('data-tie-kind="variance"'), unchecked.indexOf("</li>", unchecked.indexOf('data-tie-kind="variance"')))), /\$0\.00/, "an unread variance drawn as $0.00");
});

test("Q-SHAPE-2 constructed defect: `tied: true` over a variance that is not zero, or not read, draws no ✓", () => {
  const item = answerItem(shapeConversation("depreciation").events);
  const lying = { ...item.shape.tieOut, tied: true, words: "Ties to the GL." };
  assert.equal(tieOutState(lying, item.figures), "off");
  const html = render(TieOut, { tieOut: lying, figures: item.figures });
  assert.equal(count(html, /data-tie-tick=""/g), 0);
  assert.doesNotMatch(textOf(html), /Ties to the GL/, "the engine's tie words drawn under a variance that doesn't tie");
  const unread = { ...item.figures, variance: { ...item.figures.variance, cents: 0, measured: false } };
  assert.equal(tieOutState({ ...item.shape.tieOut, tied: true }, unread), "unchecked");
  const lineUnread = { ...item.shape.tieOut, tied: true, lines: item.shape.tieOut.lines.map((l) => (l.kind === "opening" ? { ...l, measured: false } : l)) };
  const zero = { ...item.figures, variance: { ...item.figures.variance, cents: 0 } };
  assert.equal(tieOutState(lineUnread, zero), "unchecked");
  assert.equal(tieOutState({ ...item.shape.tieOut, tied: true }, zero), "tied");
});

/* ── Q-SHAPE-3 ─────────────────────────────────────────────────────────────── */

test("Q-SHAPE-3: \"I've delivered N things\" is drawn only when no card under it says the same", () => {
  // Founder, 8 Nov 2026: each delivered file and entry is its own card, with its action,
  // right under the work; the numbered list said them all a second time.
  for (const type of ANSWER_TYPES) {
    const convo = shapeConversation(type);
    const html = answerOf(view(convo));
    const item = answerItem(convo.events);
    const cards = Boolean(item.shape.entries) || (Array.isArray(item.delivered) && item.delivered.length > 0);
    if (cards) assert.ok(!html.includes('class="shape-delivered"'), `${type}: the list repeats the cards under it`);
    else assert.match(textOf(html), /I've delivered \d+ things?:/, `${type}: nothing says what was delivered`);
  }
  // The list itself, where it is drawn: numbered, one item per delivered thing, the
  // ledger named.
  const item = answerItem(shapeConversation("prepaid").events);
  const block = render(DeliveredList, { delivered: item.shape.delivered, ledger: item.shape.ledger, ledgerName: "QuickBooks Online" });
  assert.match(textOf(block), /^I've delivered \d+ things?:/);
  assert.equal(count(block, /<li value="/g), item.shape.delivered.items.length);
});

test("Q-SHAPE-3: with no ledger connected, what happens next keeps its ledger-neutral words", () => {
  const item = answerItem(shapeConversation("prepaid", { ledger: { configured: false } }).events);
  const text = textOf(render(DeliveredList, { delivered: item.shape.delivered, ledger: item.shape.ledger }));
  assert.match(text, /it goes to your ledger/);
});

/* ── Q-SHAPE-4 ─────────────────────────────────────────────────────────────── */

test("Q-SHAPE-4: the JE card is inline on every entry type: title, status and date, the four columns, Total", () => {
  for (const type of ["deferred_revenue", "prepaid", "accruals", "depreciation", "amortisation", "payroll", "card_rec", "gl_rec", "approve_entries"]) {
    const convo = shapeConversation(type);
    const html = answerOf(view(convo));
    const shape = answerItem(convo.events).shape;
    assert.ok(shape.entries, type);
    const text = textOf(html);
    for (const e of shape.entries.items) {
      assert.ok(html.includes(e.je.lines[0].description), `${type}: a line's description is not on screen`);
    }
    assert.match(text, /Account Debit Credit Description/, `${type}: not Account | Debit | Credit | Description`);
    assert.match(text, /Total \$[\d,]+\.\d\d \$[\d,]+\.\d\d/, `${type}: no Total row`);
    assert.ok(count(html, /data-side-empty=""/g) >= 2, `${type}: an empty side is not "–"`);
  }
});

test("Q-SHAPE-4: the primary action is worded by createsDraft, with the ledger's posting effect beside it", () => {
  const qb = answerOf(view(shapeConversation("deferred_revenue", { ledger: QB_LEDGER })));
  assert.match(textOf(qb), /This posts a journal entry to your QuickBooks Online company\. Approve and post to QuickBooks Online…/);
  const xero = answerOf(view(shapeConversation("deferred_revenue", { ledger: XERO_DRAFT_LEDGER })));
  assert.match(textOf(xero), /This creates a DRAFT manual journal in your Xero organisation\. Approve and send to Xero as draft…/);
  assert.doesNotMatch(textOf(xero), /Approve and post to Xero/, "a draft-making ledger worded as a post");
  // The payout approval card too.
  const entries = answerOf(view(shapeConversation("approve_entries", { ledger: XERO_DRAFT_LEDGER })));
  assert.match(textOf(entries), /Approve and send to Xero as draft…/);
});

test("Q-SHAPE-4: role-aware — a viewer who may not approve gets who approves, never a fake Approve", () => {
  const entry = shapeOf(answerItem(shapeConversation("prepaid", { mayApprove: false, whyNot: "You drafted this entry, so someone else at your firm must approve it." }).events).shape).entries.items[0];
  assert.deepEqual(primaryActionOf(entry, QB_LEDGER), { kind: "line", words: "You drafted this entry, so someone else at your firm must approve it." });
  const unknown = { ...entry, mayApprove: null, whyNot: null };
  assert.deepEqual(primaryActionOf(unknown, QB_LEDGER), { kind: "line", words: "A reviewer approves this entry." });
  const html = render(StaticEntryCard, { entry, ledger: QB_LEDGER });
  assert.doesNotMatch(html, /btn-commit/);
  assert.match(textOf(html), /someone else at your firm must approve it/);
  // A reviewer's label comes from the ledger target, never hard-coded.
  assert.equal(primaryActionOf({ ...entry, mayApprove: true }, QB_LEDGER).label, "Approve and post to QuickBooks Online");
  assert.equal(primaryActionOf({ ...entry, mayApprove: true }, XERO_DRAFT_LEDGER).label, "Approve and send to Xero as draft");
  assert.equal(primaryActionOf({ ...entry, status: "approved" }, XERO_DRAFT_LEDGER).label, "Send to Xero as draft");
  assert.equal(primaryActionOf({ ...entry, status: "approved" }, QB_LEDGER).label, "Post to QuickBooks Online");
});

/* ── Q-SHAPE-5 ─────────────────────────────────────────────────────────────── */

test("Q-SHAPE-5: three entries are three numbered cards; the blocked one is blocked on its own card", () => {
  const convo = shapeConversation("approve_entries");
  const html = answerOf(view(convo));
  assert.equal(count(html, /<li class="shape-entry[^"]*"[^>]*data-entry-n="/g), 3);
  assert.match(textOf(html), /Entry 1 of 3/);
  assert.match(textOf(html), /Entry 2 of 3/);
  const blocked = html.slice(html.indexOf("data-entry-blocked"), html.indexOf("</li>", html.indexOf("data-entry-blocked")));
  assert.match(textOf(blocked), /Waits on a payout break/);
  assert.match(textOf(blocked), /3 of 3/);
  assert.match(textOf(blocked), /Resolve payout breaks/, "the blocked entry has no action that resolves it");
  assert.doesNotMatch(blocked, /btn-commit|Approve and post|data-approve-only/, "a blocked entry offers approve");
  // The positive beside it: the ready entries' cards do offer approve, so the absence
  // above is about the blocked card and not about a render that offers nothing.
  const ready = html.slice(0, html.indexOf("data-entry-blocked"));
  assert.equal(count(ready, /data-approve-only=""/g), 2, "the two ready entries do not offer Approve only");
  // The headline's count is what is on screen.
  assert.match(textOf(html), /3 entries, \$23,595\.00\s?: 2 ready to approve, 1 waits on a payout break\./);
});

test("Q-SHAPE-5: the bulk names exactly what it covers, never \"all N\"", () => {
  const html = answerOf(view(shapeConversation("approve_entries")));
  const text = textOf(html);
  assert.match(text, /Approve the 2 ready entries together\?/);
  assert.match(text, /Approve the 2 ready entries · \$20,120\.00/);
  assert.doesNotMatch(text, /Approve all/);
  // One accent in view: the bulk; each entry's own commit is quiet.
  assert.equal(count(html, /btn-commit/g), 1);
});

test("Q-SHAPE-5: each entry is drawn once — the thread does not draw an answer's entry cards again on their own", () => {
  const convo = shapeConversation("approve_entries");
  const html = view(convo);
  assert.equal(count(html, /data-message="action_request"/g), 3, "2 entry cards + 1 bulk, drawn once each");
  const items = threadModel(convo.events).items;
  assert.deepEqual([...drawnByShape(items)].sort(), ["a-appr-1", "a-appr-2", "a-appr-many"]);
  // No "Review the 2 entries ›" pointing at cards already on screen.
  assert.doesNotMatch(textOf(html), /Review the 2 entries/);
});

test("Q-SHAPE-5: above five entries, three cards and a compact list of the rest, never a bare count", () => {
  const convo = shapeConversation("approve_entries", { entryCount: 7 });
  const html = answerOf(view(convo));
  assert.equal(count(html, /<li class="shape-entry[^"]*"[^>]*data-entry-n="/g), 3);
  assert.match(html, /data-entry-rows="4"/);
  const rows = html.slice(html.indexOf('class="shape-entry-rows"'));
  assert.match(textOf(rows), /4 of 7 Stripe payout · 21 Jul \$2,100\.00 Draft/);
  assert.match(textOf(rows), /7 of 7 Stripe payout · 31 Jul \$777\.00 Draft/);
  assert.deepEqual(entryLayout(answerItem(convo.events).shape.entries.items).rows.map((e) => e.n), [4, 5, 6, 7]);
});

test("Q-SHAPE-5 constructed defect: an engine `of` that disagrees with the list is not what the screen says", () => {
  const item = answerItem(shapeConversation("approve_entries").events);
  const raw = { entries: { items: item.shape.entries.items.map((e) => ({ ...e, of: 4 })) } };
  const shaped = shapeOf(raw);
  assert.deepEqual(shaped.entries.items.map((e) => `${e.n} of ${e.of}`), ["1 of 3", "2 of 3", "3 of 3"]);
  // A blocked entry that claims ready is still not ready.
  const claimed = shapeOf({ entries: { items: [{ ...item.shape.entries.items[2], ready: true }] } });
  assert.equal(claimed.entries.items[0].ready, false);
});

test("Q-SHAPE-5: the approve-entries pane opens on the entries, one numbered card each, with no counts-only Summary tab", () => {
  const convo = shapeConversation("approve_entries");
  const items = threadModel(convo.events).items;
  const artifact = items.find((i) => i.kind === "result").artifact;
  const entries = paneEntriesFor(items, artifact.artifactId);
  assert.ok(entries, "the pane found no entries for its result");
  const html = render(TableView, { artifact, entries, ledgerName: "QuickBooks" });
  assert.doesNotMatch(html, /data-sheet-name="Summary &amp; Flags"|data-sheet-name="Summary & Flags"/, "the counts-only Summary tab is still a tab");
  assert.match(html, /data-sheet-name="Entries"[^>]*>|aria-selected="true"[^>]*data-sheet-name="Entries"/);
  assert.match(html, /role="tab"[^>]*aria-selected="true"[^>]*data-sheet-name="Entries"/, "the pane does not open on Entries");
  assert.match(html, /data-pane-entries="3"/);
  assert.equal(count(html, /<li class="shape-entry"/g), 3);
  const text = textOf(html);
  assert.match(text, /Account Debit Credit Description/);
  assert.match(text, /Waits on a payout break/);
  assert.match(text, /3 entries, \$23,595\.00/);
  // The stat tiles may stay as the head.
  assert.match(html, /class="pane-summary"/);
});

test("Q-SHAPE-5: before the engine sends entries, an approve-entries pane still opens on Entries without the Summary tab", () => {
  const items = threadModel(shapeConversation("approve_entries").events).items;
  const artifact = items.find((i) => i.kind === "result").artifact;
  const { sheets, opensOn } = entriesPaneSheets(artifact, null);
  assert.deepEqual(sheets.map((s) => s.name), ["Entries", "Sources"]);
  assert.equal(opensOn, "Entries");
  const html = render(TableView, { artifact, ledgerName: "QuickBooks" });
  assert.match(html, /role="tab"[^>]*aria-selected="true"[^>]*data-sheet-name="Entries"/);
  // Another result keeps its sheets and its own opening tab.
  const other = threadModel(shapeConversation("prepaid").events).items.find((i) => i.kind === "result").artifact;
  assert.equal(entriesPaneSheets(other, null).opensOn, null);
});

/* ── unchanged where there is no shape ────────────────────────────────────── */

test("an answer with no shape draws as before: no shape blocks, the facts open", () => {
  const convo = shapeConversation("prepaid");
  const events = convo.events.map((e) => (e.type === "assistant_text" ? { ...e, payload: { ...e.payload, shape: undefined } } : e));
  const html = answerOf(view({ ...convo, events }));
  assert.doesNotMatch(html, /data-answer-shape|shape-table|data-shape-entries/);
  assert.match(textOf(html), /Plan ready/);
});

test("Q-SHAPE-5 constructed defect: a blocked entry whose approve card the engine also sent still offers no approve", () => {
  const convo = shapeConversation("approve_entries");
  const card = convo.events.find((e) => e.type === "action_request" && e.payload.actionId === "a-appr-1");
  const events = convo.events.map((e) => {
    if (e.type !== "assistant_text") return e;
    const items = e.payload.shape.entries.items.map((it) => (it.block ? { ...it, actionId: "a-appr-3" } : it));
    return { ...e, payload: { ...e.payload, shape: { ...e.payload.shape, entries: { ...e.payload.shape.entries, items } } } };
  });
  events.push({ ...card, seq: 99, payload: { ...card.payload, actionId: "a-appr-3", target: { kind: "payout", id: "po_fx3" }, prefill: { payoutId: "po_fx3", note: null } } });
  const html = answerOf(view({ ...convo, events }));
  const blocked = html.slice(html.indexOf("data-entry-blocked"), html.indexOf("</li>", html.indexOf("data-entry-blocked")));
  assert.match(textOf(blocked), /Waits on a payout break/);
  assert.doesNotMatch(blocked, /btn-commit|Approve and post|Approve and send|data-approve-only/, "the blocked entry's own approve card was drawn");
  assert.equal(count(html.slice(0, html.indexOf("data-entry-blocked")), /data-approve-only=""/g), 2, "the ready entries lost their approve");
});

test("Q-SHAPE-2: a tie-out over several unlike accounts draws each account's block; ✓ on the whole only when every account ties", () => {
  const figures = {
    tot_v: { cents: 0, currency: "aud", measured: true },
    a1_o: { cents: 100000, currency: "aud", measured: true }, a1_v: { cents: 0, currency: "aud", measured: true },
    a2_o: { cents: 5000, currency: "aud", measured: true }, a2_v: { cents: 0, currency: "aud", measured: false },
  };
  const raw = {
    tieOut: {
      lines: [{ kind: "variance", label: "Unexplained, all accounts", figureRef: "tot_v", measured: true }],
      tied: true,
      accounts: [
        { account: "1000 · Everyday account", lines: [{ kind: "opening", label: "Balance per bank statement", figureRef: "a1_o", measured: true }, { kind: "variance", label: "GL variance", figureRef: "a1_v", measured: true }], tied: true },
        { account: "2200 · GST payable", lines: [{ kind: "opening", label: "GST per return", figureRef: "a2_o", measured: true }, { kind: "variance", label: "GL variance", figureRef: "a2_v", measured: false }], words: "Couldn't read 2200 from the ledger." },
      ],
    },
  };
  const tieOut = shapeOf(raw).tieOut;
  assert.equal(tieOut.accounts.length, 2);
  // Constructed defect: the engine's top-level `tied: true` while one account is unread.
  assert.equal(tieOutState(tieOut, figures), "unchecked");
  const html = render(TieOut, { tieOut, figures });
  assert.match(html, /^<div class="shape-tieout" data-shape-tieout="unchecked"/);
  assert.equal(count(html, /class="shape-tie-account"/g), 2);
  assert.equal(count(html, /data-tie-tick=""/g), 1, "only the account that ties carries a tick");
  assert.match(textOf(html), /Couldn.t read 2200 from the ledger\./);
  const allTie = { ...figures, a2_v: { cents: 0, currency: "aud", measured: true } };
  const tied = shapeOf({ tieOut: { ...raw.tieOut, accounts: raw.tieOut.accounts.map((a) => ({ ...a, tied: true, lines: a.lines.map((l) => ({ ...l, measured: true })) })) } }).tieOut;
  assert.equal(tieOutState(tied, allTie), "tied");
});

test("Q-SHAPE-2: an absent `tied` (the engine drops nulls) is words, never ✓", () => {
  const item = answerItem(shapeConversation("deferred_revenue").events);
  const { tied, ...rest } = item.shape.tieOut;
  assert.equal(tied, true);
  const absent = shapeOf({ tieOut: { ...rest, tied: undefined } }).tieOut;
  assert.equal(tieOutState(absent, item.figures), "unchecked");
});

test("Q-SHAPE-4 constructed defect: a live entry card for a viewer the read says may not approve draws who approves, not Approve", () => {
  const why = "You drafted this entry, so someone else at your firm must approve it.";
  const html = answerOf(view(shapeConversation("prepaid", { mayApprove: false, whyNot: why })));
  const card = html.slice(html.indexOf('<li class="shape-entry'));
  assert.match(textOf(card), /someone else at your firm must approve it/);
  assert.doesNotMatch(card, /data-approve-only|Approve and post to|Approve and send to/, "a live Approve drawn for a viewer the read refused");
  // Positive beside it: a reviewer's card does offer it.
  assert.match(answerOf(view(shapeConversation("prepaid"))), /Approve and post to QuickBooks Online…/);
  // The payout approval card, too.
  const payouts = answerOf(view(shapeConversation("approve_entries", { mayApprove: false, whyNot: why })));
  assert.equal(count(payouts, /data-approve-and-post=""/g), 0);
  assert.match(textOf(payouts), /someone else at your firm must approve it/);
});
