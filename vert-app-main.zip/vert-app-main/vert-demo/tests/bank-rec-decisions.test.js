// tests/bank-rec-decisions.test.js — A CODING IS APPROVED ON ITS ROW
// ==============================================================================
// Migration 052 gives each bank line Vert proposed a coding for ONE decision
// (`coding_approve`), and the engine lays it on the row as `decision`. The row draws
// Approve and Change; a line Vert wasn't sure about asks which account, with its
// alternatives; once decided, the row says what happened in words ("Created in Xero:
// click OK on the reconcile screen", "Approved: enter these in Xero" with the fields,
// "Already in Xero"); the section of lines Xero doesn't have carries one "Approve N
// high-confidence". Driven by the engine's own fixture (tests/fixtures/
// bank-rec-shape.json) with decisions laid on in the shape agent_events.BankRecDecision
// describes.
//
// Rendered with no browser (tests/_harness/render.js): presses can't be driven here, so
// the presses' wiring is asserted on the pure helpers and on the server action's
// described outcome, and the markup on what each state draws.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { render, textOf } from "./_harness/render.js";
import { ROOT } from "./_harness/source.js";
import BankRecRows from "../components/chat/answer/BankRecRows.js";
import { bankRecOf, changeOf, codingChoices, decisionOf, fieldsText, highConfidenceIds, pickedAccount, planNow } from "../components/chat/answer/bank-rec.js";
import { approveCoding, approveHighConfidenceCodings } from "../lib/agent/actions.js";
import { formatMoney } from "../lib/format.js";

const FIX = JSON.parse(readFileSync(path.join(ROOT, "tests", "fixtures", "bank-rec-shape.json"), "utf8"));
const WITH = FIX.withStatement;
const LINK = "https://go.xero.com/Bank/BankRec.aspx?accountID=acc-everyday";

const pending = (id, extra = {}) => ({ id, kind: "coding_approve", state: "pending", words: "Waiting for approval", confidence: "high", ...extra });
const FIELDS = [
  { label: "Bank account", value: "1010 Everyday" },
  { label: "Transaction", value: "Spend Money" },
  { label: "Account", value: "429 General Expenses" },
  { label: "Tax rate", value: "GST on Expenses" },
  { label: "Amount", value: "65.50", amountCents: 6550 },
];

/** The fixture with `decisions` laid on its coding rows (row id → decision), and any extra statement rows. */
function withDecisions(decisions, extraRows = []) {
  return {
    ...WITH,
    sections: WITH.sections.map((s) => {
      const rows = s.rows.map((r) => (decisions[r.id] ? { ...r, decision: decisions[r.id] } : r));
      const more = s.key === "statement_only" ? extraRows : [];
      return { ...s, rows: [...rows, ...more], count: s.count + more.length };
    }),
  };
}

const draw = (bankRec) => render(BankRecRows, { bankRec, ledgerName: "Xero" });

/** One row's markup, from its opening tag to the next row's. */
function rowHtml(html, decisionId) {
  const at = html.indexOf(`data-decision="${decisionId}"`);
  assert.ok(at >= 0, `no decision ${decisionId}`);
  const start = html.lastIndexOf('class="bankrec-row"', at);
  const next = html.indexOf('class="bankrec-row"', at);
  return html.slice(start, next < 0 ? html.length : next);
}

const buttons = (html) => [...html.matchAll(/<button[^>]*>([\s\S]*?)<\/button>/g)].map((m) => textOf(m[1]));

// A second coded line Vert is only fairly sure of: not one "Approve all high-confidence" takes.
const MEDIUM = {
  id: "csv:e:13",
  status: "coded",
  statusWords: "Coding proposed",
  confidence: "medium",
  bank: { date: "2026-07-28", description: "MOBIL ST LEONARDS", amountCents: 7000, direction: "out" },
  proposal: { kind: "coding", accountCode: "449", accountName: "Motor Vehicle Expenses", taxType: "INPUT", taxName: "GST on Expenses", contact: "Mobil", basis: "Coded like the one earlier payment to Mobil." },
  decision: pending("a-3", { confidence: "medium" }),
};

test("a proposed coding draws Approve and Change, with its status in words", () => {
  const html = draw(withDecisions({ "csv:e:5": pending("a-1") }));
  const row = rowHtml(html, "a-1");
  assert.match(row, /data-decision-state="pending"/);
  assert.ok(textOf(row).includes("Waiting for approval"));
  assert.deepEqual(buttons(row), ["Approve", "Change"]);
  // A sample month sends nothing, and says so beside the press rather than hiding it.
  assert.match(row, /aria-disabled="true"/);
  assert.ok(textOf(row).includes("This is a sample month"));
  // The row's own proposal is still drawn above the decision.
  assert.ok(textOf(row).includes("429 · General Expenses"));
});

test("while its Approve is in flight the row says Approving…, keeps its coding, and never draws an outcome without its fields (B6)", () => {
  // What the thread folds on in the ~1 s before the settle answers: a decision_settled it
  // read closes the coding as "approved" with no fields, by the raw key (lib/agent/events.js
  // SETTLED_CODING). Drawn, that read "Approved: the fields are to enter by hand · key:
  // founder" with nothing under it, then corrected itself.
  const interim = { ...pending("a-1"), state: "settled", outcome: "approved", words: "Approved: the fields are to enter by hand", by: "key: founder" };
  const pressing = { "a-1": { which: "approve", from: pending("a-1") } };
  const html = render(BankRecRows, { bankRec: withDecisions({ "csv:e:5": interim }), ledgerName: "Xero", initial: { pressing } });
  const row = rowHtml(html, "a-1");
  const text = textOf(row);
  // The pending row as it was pressed: its word, its coding, the press busy and inert.
  assert.match(row, /data-decision-state="pending"/);
  assert.match(row, /data-pressing="approve"/);
  assert.ok(text.includes("Waiting for approval"));
  assert.ok(text.includes("429 · General Expenses"), "the row's coding is kept while it approves");
  assert.match(row, /<button[^>]*aria-busy="true"[^>]*>[\s\S]*?Approving…/);
  assert.match(row, /<button[^>]*aria-disabled="true"[^>]*>[\s\S]*?Change/);
  // The folded outcome is drawn only once the press is over (the engine's answer then).
  assert.ok(!row.includes('data-outcome="approved"'), "an outcome was drawn while the settle was in flight");
  assert.ok(!text.includes("the fields are to enter by hand"), "the fieldless outcome showed during the press");
  const after = rowHtml(draw(withDecisions({ "csv:e:5": interim })), "a-1");
  assert.ok(after.includes('data-outcome="approved"'));
});

test("a line Vert wasn't sure about asks which account, with its alternatives as the answers", () => {
  const html = draw(withDecisions({ "csv:e:12": pending("a-2", { confidence: "low" }) }));
  const row = rowHtml(html, "a-2");
  assert.ok(textOf(row).includes("Which account does this go to?"));
  assert.deepEqual(buttons(row), ["493 · Travel - National", "429 · General Expenses", "Something else"]);
  assert.ok(!buttons(row).includes("Approve"), "nothing to approve until an account is picked");
  assert.match(row, /role="group" aria-label="Which account this line goes to"/);
});

test("the statement section carries one Approve N high-confidence, for the rows that qualify", () => {
  const html = draw(withDecisions({ "csv:e:5": pending("a-1"), "csv:e:12": pending("a-2", { confidence: "low" }) }, [MEDIUM]));
  const start = html.indexOf('data-section="statement_only"');
  const head = html.slice(start, html.indexOf('class="bankrec-table"', start));
  assert.match(head, /data-bankrec-bulk=""/);
  assert.deepEqual(buttons(head), ["Approve 1 high-confidence"]);
  // Only there: no other section offers it.
  assert.equal(html.split("data-bankrec-bulk").length - 1, 1);
  // With nothing high-confidence left to approve, there is no bulk press at all.
  const none = draw(withDecisions({ "csv:e:5": { ...pending("a-1"), state: "settled", outcome: "approved", words: "Approved: enter these in {{ledger}}" } }, [MEDIUM]));
  assert.equal(none.split("data-bankrec-bulk").length - 1, 0);
});

test("approved without the grant: the fields to enter in Xero, copyable, and the reconcile link", () => {
  const settled = { ...pending("a-1"), state: "settled", outcome: "approved", words: "Approved: enter these in {{ledger}}", by: "Priya Shah", fields: FIELDS, ledgerLink: LINK };
  const row = rowHtml(draw(withDecisions({ "csv:e:5": settled })), "a-1");
  const text = textOf(row);
  assert.ok(text.includes("Approved: enter these in Xero") && text.includes("Priya Shah"));
  assert.ok(!text.includes("{{ledger}}"));
  assert.match(row, /<dl class="bankrec-fields"/);
  for (const f of FIELDS.slice(0, 4)) assert.ok(text.includes(`${f.label} ${f.value}`), f.label);
  assert.ok(text.includes(`Amount ${formatMoney(6550)}`), "the amount is the engine's cents, formatted");
  // Folded under one press (founder, 8 Nov 2026), Copy inside it.
  assert.deepEqual(buttons(row), ["Fields to enter", "Copy the fields"]);
  assert.match(row, new RegExp(`href="${LINK.replace(/[.?]/g, "\\$&")}"`));
  assert.ok(text.includes("OK it in Xero"));
});

test("created in Xero, and already in Xero, each say so with the link and no press", () => {
  const created = { ...pending("a-1"), state: "settled", outcome: "created", words: "Created in {{ledger}}: click OK on the reconcile screen", ledgerLink: LINK };
  let row = rowHtml(draw(withDecisions({ "csv:e:5": created })), "a-1");
  assert.ok(textOf(row).includes("Created in Xero: click OK on the reconcile screen"));
  assert.match(row, /data-outcome="created"/);
  assert.deepEqual(buttons(row), []);
  assert.ok(textOf(row).includes("OK it in Xero"));
  const already = { ...created, outcome: "already_in_ledger", words: "Already in {{ledger}}" };
  row = rowHtml(draw(withDecisions({ "csv:e:5": already })), "a-1");
  assert.ok(textOf(row).includes("Already in Xero"));
  assert.deepEqual(buttons(row), []);
});

test("a viewer who may not approve is told why, and may still change it for someone else", () => {
  const refused = pending("a-1", { mayApprove: false, whyNot: "You changed this coding, so someone else at your firm must approve it." });
  const row = rowHtml(draw(withDecisions({ "csv:e:5": refused })), "a-1");
  assert.ok(textOf(row).includes("someone else at your firm must approve it"));
  assert.deepEqual(buttons(row), ["Change"]);
});

test("a person's change waiting for someone else says whose and what it changed to", () => {
  const changed = pending("a-4", {
    words: "Changed by Sam Lee: waiting for someone else to approve",
    changedBy: "Sam Lee",
    coding: { accountCode: "453", accountName: "Office Expenses", taxType: "INPUT", taxName: "GST on Expenses", contact: "Officeworks" },
  });
  const text = textOf(rowHtml(draw(withDecisions({ "csv:e:5": changed })), "a-4"));
  assert.ok(text.includes("Changed by Sam Lee: waiting for someone else to approve"));
  assert.ok(text.includes("Changed to 453 Office Expenses · GST on Expenses · Officeworks"));
});

test("set aside is a word too, never a missing row", () => {
  const declined = { ...pending("a-1"), state: "declined", outcome: "declined", words: "Set aside" };
  const row = rowHtml(draw(withDecisions({ "csv:e:5": declined })), "a-1");
  assert.ok(textOf(row).includes("Set aside"));
  assert.deepEqual(buttons(row), []);
});

test("a decision closed because its statement line was removed says so, with nothing to press (p1 e2e)", () => {
  for (const [outcome, words] of [["withdrawn", "Withdrawn: its statement line was removed"], ["void", "Void: its statement line was removed"]]) {
    const closed = { ...pending("a-1"), state: "declined", outcome, words };
    assert.equal(decisionOf(closed).outcome, outcome);
    const row = rowHtml(draw(withDecisions({ "csv:e:5": closed })), "a-1");
    assert.ok(textOf(row).includes(words));
    assert.deepEqual(buttons(row), []);
  }
});

// ─────────────────────────── the pure parts behind the presses ───────────────────────────

test("a decision is read as the contract says, or dropped", () => {
  assert.equal(decisionOf(null), null);
  assert.equal(decisionOf({ id: "a", kind: "approve", state: "pending", words: "x" }), null);
  assert.equal(decisionOf({ id: "a", kind: "coding_approve", state: "maybe", words: "x" }), null);
  assert.equal(decisionOf({ id: "a", kind: "coding_approve", state: "pending" }), null, "a status always carries its word");
  const d = decisionOf({ ...pending("a"), ledgerLink: "javascript:alert(1)", fields: [{ label: "Amount", value: "1.00", amountCents: 100 }, { nope: 1 }] });
  assert.equal(d.ledgerLink, null, "a link out is only ever a secure web link");
  assert.deepEqual(d.fields, [{ label: "Amount", value: "1.00", amountCents: 100 }]);
  const view = bankRecOf(withDecisions({ "csv:e:5": pending("a-1") }));
  const row = view.sections[2].rows.find((r) => r.id === "csv:e:5");
  assert.equal(row.decision.id, "a-1");
});

test("Approve N high-confidence takes pending, approvable, high-confidence rows with an account", () => {
  const view = bankRecOf(withDecisions({ "csv:e:5": pending("a-1") }, [
    MEDIUM,
    { ...MEDIUM, id: "x:1", confidence: "high", decision: pending("a-5", { mayApprove: false }) },
    { ...MEDIUM, id: "x:2", confidence: "high", decision: { ...pending("a-6"), state: "settled", outcome: "approved", words: "Approved" } },
    { ...MEDIUM, id: "x:3", confidence: "high", decision: pending("a-7") },
  ]));
  const section = view.sections.find((s) => s.key === "statement_only");
  assert.deepEqual(highConfidenceIds(section), ["a-1", "a-7"]);
  // A press on this screen that settled one leaves it out.
  assert.deepEqual(highConfidenceIds(section, { "a-7": { ...pending("a-7"), state: "settled" } }), ["a-1"]);
});

test("Change offers Vert's choices and the chart, and sends only what changed", () => {
  const row = bankRecOf(WITH).sections[2].rows.find((r) => r.id === "csv:e:5");
  const chart = [{ id: "q1", number: "453", name: "Office Expenses", active: true }, { id: "q2", number: "473", name: "Repairs", active: false }, { id: "q3", number: "429", name: "General Expenses", active: true }];
  const choices = codingChoices(row, chart);
  assert.deepEqual(choices.accounts.map((a) => a.value), ["429", "461", "453"], "own, alternatives, then active chart accounts, once each");
  assert.deepEqual(choices.taxes.map((t) => t.value), ["", "INPUT"]);
  const current = choices.current;
  assert.deepEqual(changeOf(current, { accountCode: "429", taxType: "INPUT", contact: "Officeworks" }), {});
  assert.deepEqual(changeOf(current, { accountCode: "453", taxType: "", contact: "Officeworks" }), { accountCode: "453" });
  assert.deepEqual(changeOf(current, { accountCode: "453", taxType: "INPUT", contact: "Officeworks Pty" }), { accountCode: "453", taxType: "INPUT", contactName: "Officeworks Pty" });
  assert.equal(fieldsText(FIELDS.slice(0, 2)), "Bank account: 1010 Everyday\nTransaction: Spend Money");
});

test("Change on a line Vert asked about keeps the line's payee: an alternative's payee is another business", () => {
  // p1 e2e (24 Oct 2026): INSURANCE, a line Vert asked about, was approved through
  // Change as "453 Office Expenses · 7-Eleven": the editor started with no contact,
  // and picking the alternative 453 (offered because 7-Eleven is coded there) filled
  // in 7-Eleven as the payee of an insurance payment.
  const row = {
    id: "csv:e:9", status: "pick_account",
    bank: { date: "2026-07-24", direction: "out", amountCents: 126500, description: "INSURANCE" },
    proposal: { kind: "coding", contact: "Insurance", basis: "Vert has not seen a payment to \"Insurance\" before.",
      alternatives: [
        { accountCode: "493", accountName: "Travel - National", taxType: "INPUT", taxName: "GST on Expenses", contact: "Passing Places Parking" },
        { accountCode: "453", accountName: "Office Expenses", taxType: "INPUT", taxName: "GST on Expenses", contact: "7-Eleven" },
      ] },
    decision: pending("a-5", { confidence: "low" }),
  };
  const choices = codingChoices(row, []);
  assert.equal(choices.current.contact, "Insurance", "the editor starts from the line's own payee");
  const picked = pickedAccount(choices, "453", choices.current.contact);
  assert.equal(picked.contact, "Insurance");
  assert.equal(picked.taxType, "INPUT");
  assert.deepEqual(changeOf(choices.current, { accountCode: "453", taxType: picked.taxType, contact: picked.contact }),
    { accountCode: "453", taxType: "INPUT" }, "the payee is not sent as a change");
  // A field the person cleared is not refilled with another business's name either.
  assert.equal(pickedAccount(choices, "453", "").contact, "");
});

test("the Plan's coding steps follow the presses made on this screen", () => {
  // p1 e2e (24 Oct 2026): three codings approved, and the Plan still read "Approve 3
  // codings". The engine recounts on read; a press on this screen recounts here.
  const coded = (id, d) => ({ id, status: "coded", statusWords: "Coding proposed", bank: { date: "2026-07-31", direction: "out", amountCents: 100, description: id }, proposal: { kind: "coding", accountCode: "404" }, decision: d });
  const view = bankRecOf({
    period: "2026-07", statement: true, account: "090", currency: "AUD",
    sections: [{ key: "statement_only", title: "On the statement", count: 3, measured: true,
      rows: [coded("x:1", pending("a-1")), coded("x:2", pending("a-2")),
        { id: "x:3", status: "pick_account", statusWords: "Pick the account", bank: { date: "2026-07-14", direction: "out", amountCents: 38500, description: "J PATEL" }, proposal: { kind: "coding", contact: "Patel" }, decision: pending("a-3", { confidence: "low" }) }] }],
    plan: [{ n: 1, kind: "approve_codings", count: 2, words: "Approve 2 codings" },
      { n: 2, kind: "confirm_matches", count: 1, words: "In {{ledger}}, click OK on 1 suggested match" },
      { n: 3, kind: "pick_accounts", count: 1, words: "Pick the account for 1 line" }],
    tieOut: { status: "not_measured", words: "x" },
  });
  assert.deepEqual(planNow(view, {}).map((s) => s.words), ["Approve 2 codings", "In {{ledger}}, click OK on 1 suggested match", "Pick the account for 1 line"]);
  const settled = (id) => ({ ...pending(id), state: "settled", outcome: "approved", words: "Approved" });
  const now = planNow(view, { "x:1": settled("a-1"), "x:3": settled("a-3") });
  assert.deepEqual(now.map((s) => [s.n, s.words]), [[1, "Approve 1 coding"], [2, "In {{ledger}}, click OK on 1 suggested match"]]);
});

test("the presses' server actions describe their outcome and never throw", async () => {
  // This suite runs with no service behind it: the outcome says so, in words.
  const one = await approveCoding("a-1", { accountCode: "453" });
  assert.equal(one.ok, false);
  assert.equal(one.kind, "unavailable");
  assert.ok(/nothing here can be sent/i.test(one.message), one.message);
  const bad = await approveCoding("../x");
  assert.equal(bad.ok, false);
  assert.ok(bad.message.includes("Nothing was sent"));
  const none = await approveHighConfidenceCodings([]);
  assert.equal(none.ok, false);
  const many = await approveHighConfidenceCodings(["a-1", "a-2"]);
  assert.equal(many.ok, false);
  assert.equal(many.kind, "unavailable");
});

test("a re-read answer whose codings were laid on since replaces the held copy (walkthrough 3)", async () => {
  // After approving codings the Plan dropped them only on a reload: the approve's
  // revalidated render brought the answer re-read (decisions laid on, plan recounted by
  // vert_api shape_viewer), and the conversation kept the copy it already held, because
  // the first copy of a seq wins. A re-read of the same answer that differs only in its
  // bank rec is that answer as it stands now.
  const { mergeEvents } = await import("../lib/agent/events.js");
  const answer = (plan, state) => ({ seq: 7, sessionId: "s", at: "2026-10-24T09:00:00Z", type: "assistant_text", author: "vert", basis: "exact",
    payload: { verdict: "v", facts: [], figures: {}, shape: { bankRec: { plan, sections: [{ key: "statement_only", rows: [{ id: "x:1", decision: { id: "a-1", kind: "coding_approve", state, words: "w" } }] }] } } } });
  const held = answer([{ n: 1, kind: "approve_codings", count: 1, words: "Approve 1 coding" }], "pending");
  const reread = answer([], "settled");
  const merged = mergeEvents([held], [reread]);
  assert.equal(merged.length, 1);
  assert.deepEqual(merged[0].payload.shape.bankRec.plan, []);
  // Anything else about it differs: not the same answer, the first copy still wins.
  const other = { ...reread, payload: { ...reread.payload, verdict: "IMPOSTER" } };
  assert.equal(mergeEvents([held], [other])[0].payload.verdict, "v");
});
