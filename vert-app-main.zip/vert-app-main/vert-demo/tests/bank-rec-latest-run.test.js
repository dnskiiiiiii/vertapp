// tests/bank-rec-latest-run.test.js — ACTIONS BELONG TO THE LATEST RUN (recheck 4, 26 Oct 2026)
// ==============================================================================
// The July bank-rec conversation held two runs. The older one, its workbook "replaced by
// a later run below", still drew live Approve/Change on its coding rows; the tester's
// Approve landed there (it did settle the action), and the LATEST run's Plan kept
// "Approve 3 codings" for 20 s, until a reload. Now an answer whose bank rec a later
// answer redraws is read-only with "See the latest run below", and a settle anywhere
// (a decision_settled in the thread) takes the coding off the latest run's Plan at once.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { render, textOf } from "./_harness/render.js";
import { threadModel } from "../lib/agent/events.js";
import ShapeBlocks from "../components/chat/answer/ShapeBlocks.js";

const SESSION = { sessionId: "2026-07-bank_reconciliation", period: "2026-07", template: "bank_reconciliation", title: "Reconcile the bank account", state: "needs_you" };
const ev = (seq, type, payload) => ({ seq, sessionId: SESSION.sessionId, at: `2026-10-26T09:${String(seq).padStart(2, "0")}:00Z`, type, author: "vert", basis: null, payload });
const pending = (id) => ({ id, kind: "coding_approve", state: "pending", words: "Waiting for approval", confidence: "medium", coding: { accountCode: "270" }, mayApprove: true });
const coded = (id, actionId, words) => ({ id, status: "coded", statusWords: "Coding proposed", bank: { date: "2026-07-31", direction: "in", amountCents: 1597, description: words }, proposal: { kind: "coding", accountCode: "270", accountName: "Interest Income" }, confidence: "medium", decision: pending(actionId) });
const rec = () => ({
  period: "2026-07", statement: true, account: "090 · Business Bank Account", currency: "AUD",
  sections: [{ key: "statement_only", title: "On the bank statement, not in {{ledger}}", count: 2, measured: true, totalCents: 1000,
    rows: [coded("csv:b:1", "a-1", "MOBIL"), coded("csv:b:2", "a-2", "INTEREST")] }],
  plan: [{ n: 1, kind: "approve_codings", count: 2, words: "Approve 2 codings" }],
  tieOut: { status: "not_measured", words: "x" },
});
const answer = (seq) => ev(seq, "assistant_text", { verdict: "Reconciled.", facts: [], figures: {}, shape: { bankRec: rec() } });
const RUNS = [ev(1, "run_state", { state: "working" }), answer(2), ev(3, "run_state", { state: "needs_you" }),
  ev(4, "run_state", { state: "working" }), answer(5), ev(6, "run_state", { state: "needs_you" })];

const answers = (thread) => thread.items.filter((i) => i.kind === "answer" && i.shape && i.shape.bankRec);
const draw = (item) => render(ShapeBlocks, { shape: item.shape, figures: {}, superseded: item.superseded || null, seq: item.seq });

test("only the latest run's bank rec offers Approve; the older one says where the latest is", () => {
  const [older, latest] = answers(threadModel(RUNS, SESSION));
  assert.deepEqual(older.superseded, { seq: 5 });
  assert.equal(latest.superseded || null, null);
  const old = draw(older);
  assert.doesNotMatch(old, />Approve</, "a superseded run drew Approve");
  assert.doesNotMatch(old, />Change</);
  assert.match(old, /href="#bankrec-5"[^>]*>See the latest run</);
  const now = draw(latest);
  assert.match(now, />Approve</);
  assert.match(now, /id="bankrec-5"/);
});

test("a settle anywhere takes the coding off the latest run's Plan without a reload", () => {
  const settled = [...RUNS, ev(7, "decision_settled", { actionId: "a-1", outcome: "approved", by: "Priya Shah", at: "2026-10-26T09:07:00Z", verified: false, actorMatchesSettler: false })];
  const [, latest] = answers(threadModel(settled, SESSION));
  const html = draw(latest);
  assert.match(textOf(html), /Approve 1 coding/);
  assert.doesNotMatch(textOf(html), /Approve 2 codings/);
  const mobil = latest.shape.bankRec.sections[0].rows.find((r) => r.id === "csv:b:1");
  assert.notEqual(mobil.decision.state, "pending");
});
