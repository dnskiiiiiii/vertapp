// tests/bank-rec-confirm-write.test.js — A CODING THAT WRITES TO THE LEDGER IS CONFIRMED FIRST
// ==============================================================================
// Staging browser walk 1 (31 Oct 2026, D6): each proposed coding in the bank rec had a
// bare Approve, and one press created an AUTHORISED Spend Money in Xero at once. The walk's
// script pressed the first Approve in too large a container and created an unintended
// 7-Eleven $9.80 Spend Money; nothing on the page stopped it or offered a way back. The
// journal's Post has a "Post this entry?" confirm; this write had none.
//
// Now every press that approves a coding (Approve, an alternative account, Approve with
// this change, Approve N high-confidence) opens a confirm that names what will be created
// — "Create a Spend Money of $24.60 on 090 Business Bank Account, coded to 493 Travel -
// National?" — and only its commit sends the approval.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { render, textOf } from "./_harness/render.js";
import { ROOT, read, stripComments } from "./_harness/source.js";
import BankRecRows from "../components/chat/answer/BankRecRows.js";
import { bulkWriteQuestion, codingWriteQuestion } from "../components/chat/answer/bank-rec.js";

const FIX = JSON.parse(readFileSync(path.join(ROOT, "tests", "fixtures", "bank-rec-shape.json"), "utf8"));
const WITH = FIX.withStatement;
const pending = (id, extra = {}) => ({ id, kind: "coding_approve", state: "pending", words: "Waiting for approval", confidence: "high", ...extra });

function withDecisions(decisions) {
  return { ...WITH, sections: WITH.sections.map((s) => ({ ...s, rows: s.rows.map((r) => (decisions[r.id] ? { ...r, decision: decisions[r.id] } : r)) })) };
}

const plain = (s) => String(s).replace(/[  ]/g, " ");

const CAB = {
  id: "csv:cab",
  bank: { date: "2026-10-28", description: "CABCHARGE TAXI VERT TEST 31OCT", amountCents: 2460, direction: "out" },
  proposal: { kind: "coding", accountCode: "493", accountName: "Travel - National", taxType: "INPUT", taxName: "GST on Expenses" },
};

test("the question names the transaction, its amount, the bank account and the coding", () => {
  const q = codingWriteQuestion({ row: CAB, coding: CAB.proposal, account: "090 · Business Bank Account", ledger: "Xero" });
  assert.equal(plain(q.title), "Create a Spend Money of $24.60 on 090 Business Bank Account, coded to 493 Travel - National?");
  assert.equal(q.commit, "Create in Xero");
  const received = codingWriteQuestion({ row: { ...CAB, bank: { ...CAB.bank, direction: "in" } }, coding: { accountCode: "200", accountName: "Sales" }, account: "090 · Business Bank Account", ledger: "Xero" });
  assert.equal(plain(received.title), "Create a Receive Money of $24.60 on 090 Business Bank Account, coded to 200 Sales?");
  // Another ledger, or none named: said without Xero's words, and never "Create in your ledger".
  const qbo = codingWriteQuestion({ row: CAB, coding: CAB.proposal, account: "1010 Everyday", ledger: "QuickBooks Online" });
  assert.equal(plain(qbo.title), "Create a payment of $24.60 on 1010 Everyday, coded to 493 Travel - National?");
  assert.equal(qbo.commit, "Create in QuickBooks Online");
  const none = codingWriteQuestion({ row: CAB, coding: CAB.proposal, account: null, ledger: "your ledger" });
  assert.equal(plain(none.title), "Approve a payment of $24.60, coded to 493 Travel - National?");
  assert.equal(none.commit, "Approve");
});

test("the bulk question names how many it creates", () => {
  const q = bulkWriteQuestion({ count: 2, ledger: "Xero", account: "090 · Business Bank Account" });
  assert.equal(plain(q.title), "Create 2 transactions on 090 Business Bank Account in Xero, each coded as shown?");
  assert.equal(q.commit, "Create 2 in Xero");
});

test("pressing Approve opens the confirm, naming what will be created, with Cancel; nothing is sent from the row's press", () => {
  const html = render(BankRecRows, { bankRec: withDecisions({ "csv:e:5": pending("a-1") }), ledgerName: "Xero", initial: { confirming: { "a-1": { which: "approve", change: null } } } });
  const text = plain(textOf(html));
  assert.ok(text.includes("Create a Spend Money of $65.50 on 1010 Everyday account, coded to 429 General Expenses?"), text);
  assert.match(html, /data-coding-confirm=""/);
  assert.match(html, /<button[^>]*>[\s\S]*?Cancel/);
  assert.match(html, /<button[^>]*data-coding-confirm=""[^>]*>[\s\S]*?Create in Xero/);
});

test("no press on a coding row sends the approval itself: only the confirm's commit calls approveCoding", () => {
  const src = stripComments(read("components/chat/answer/BankRecRows.js"));
  // The row's presses ask; they never send.
  assert.doesNotMatch(src, /onClick=\{\(\) => send\(/, "a coding press sends the approval without a confirm");
  assert.doesNotMatch(src, /onSubmit=\{\(change\) => send\(/, "Approve with this change sends without a confirm");
  assert.doesNotMatch(src, /onClick=\{press\}/, "Approve N high-confidence sends without a confirm");
  // The two writes are each called from one place: the confirm.
  assert.equal((src.match(/\bapproveCoding\(/g) || []).length, 1);
  assert.equal((src.match(/\bapproveHighConfidenceCodings\(/g) || []).length, 1);
});
