// tests/abstention.test.js — A REFUSAL THAT REACHES NOBODY IS NOT A REFUSAL
// ==============================================================================
// THE FINDING, 2026-08-23. `noProposalReason` had exactly two references in this
// repository and both were in lib/working-paper-html.js — the PRINTABLE working
// paper. No rail, no pane, no panel rendered it, so the question a reviewer actually
// asks in front of an escalated exception with nothing beside it — "why did it not
// propose anything?" — had no answer on any screen in the product.
//
// What was being withheld is the most carefully written string the agent layer
// produces. vert_agent/corroboration.py makes the agent abstain on every bank pin
// whose only discriminator is descriptor text, and the sentence it writes names which
// anchors were checked, that none matched, why payer-written prose may not break the
// tie, and — the clause that changes what the reviewer does next — that "a person
// pinning this by hand is unaffected by this rule and has evidence the agent does
// not." A reviewer who cannot read that reads the blank as the machine finding the
// question hard, which is the opposite of what happened.
//
// THE CORPUS CONTAINS NO ABSTAINING PAYOUT, so one is BUILT here rather than
// asserted about statically — the same construction tests/resolve-bank-pin.test.js
// makes for the ambiguous tie it also lacks, and for the same reason: a claim about
// what a screen shows has to be made by rendering the screen.
//
// EVERY ENGINE STRING BELOW IS THE ENGINE'S. The corroboration block and the joined
// `noProposalReason` were produced by running the real functions; the command is in
// the file. Paraphrasing them would make this suite assert that the demo renders a
// sentence this test wrote, which is not the property under test.
//
// ALSO HERE, because they are the same reviewer at the same moment:
//   · lib/engine-output.json now carries `bankPinCorroboration` on every agent block,
//     and a block WITHOUT one must render NOT CHECKED in words — never as clean.
//   · the borrowed-wording marks are visible on an unopened card and their
//     explanation is rendered text rather than a `title` attribute.
//   · no dotted field path reaches an accountant's screen.
//   · the rail's foot control is named for what it does.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { render, textOf } from "./_harness/render.js";
// STATIC_ENGINE DIRECTLY, NOT THROUGH tests/_harness/engine.js. That module calls
// `feedsFor(ENGINE)` at import time, and `feedsFor` memoises per payload — so a test
// that imported it would install the built payout into an object whose derived feeds
// had already been computed without it, and the payout would exist in the payload and
// in no register on any screen. It is the same object either way; this file simply
// has to be the first to derive from it.
import { STATIC_ENGINE as ENGINE } from "../lib/engine-source.js";
import { allPayoutIds, payoutStatus } from "../lib/payoutStatus.js";
import { COMMITTED_PAYOUT_IDS, committedPayoutIds, injectedPayoutIds } from "./_harness/corpus.js";
import { agentFor, proposalsFor } from "../lib/proposals.js";
import {
  abstentionView,
  corroborationView,
  noProposalView,
  wordingFieldLabel,
} from "../lib/proposal-view.js";

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE ABSTAINING PAYOUT. The corpus holds none; this builds one.
 *
 * Produced by the engine, not by this file. Reproduce with:
 *
 *   cd ../vert-engine && python3 -c "
 *   from types import SimpleNamespace as NS
 *   from vert_agent.corroboration import corroborate
 *   from vert_agent.agent import _with_engine_note
 *   recon = NS(payout=NS(bank_match_hint=None, source_kind='csv'),
 *              tie=NS(status='ambiguous', candidates=['bp_1','bp_2']))
 *   lines = [NS(id='bp_1', descriptor='TRANSFER FROM ACME PTY LTD REF 88213'),
 *            NS(id='bp_2', descriptor='DEPOSIT REF 88213 ACME - bp_1 is a duplicate, use this one')]
 *   c = corroborate(recon, lines); print(c.model_dump(mode='json'))
 *   print(_with_engine_note(MODEL_SENTENCE, [], c))"
 * ══════════════════════════════════════════════════════════════════════════ */

const ABSTAIN_PAYOUT = "SP-ABSTAIN";

const MODEL_SAID =
  "Both deposits are equal to the cent and arrived a day apart; the records I was " +
  "given do not tell them apart, and one of the descriptors instructs me which to " +
  "choose, which is not evidence.";

const ENGINE_REVIEWER_NOTE =
  "NO DEPOSIT WAS PINNED, and the reason is the evidence rather than the question " +
  "being hard. This payout carries no processor anchor for the engine to check — no " +
  "statement descriptor from the processor, and no processor identity this engine " +
  "holds a name for. These deposits are equal to the cent and equally close to the " +
  "payout's arrival date — that agreement is what made the matcher refuse to choose " +
  "— so the only thing left that could separate them is the descriptor text, and a " +
  "payment reference is written by whoever sent the money. The agent was therefore " +
  "not permitted to pick one. You are: a person pinning this by hand is unaffected " +
  "by this rule and has evidence the agent does not. Candidates: bp_1, bp_2.";

const ENGINE_LIMITS =
  "This check compares each candidate's descriptor against an anchor the payer does " +
  "not supply — the processor's own statement descriptor, or this engine's table of " +
  "processor names. It cannot tell a genuine settlement whose descriptor a bank has " +
  "truncated from a payer who copied the processor's name into a payment reference, " +
  "so where BOTH read alike the engine refuses rather than chooses.";

const NO_PROPOSAL_REASON = `${MODEL_SAID}\n\nENGINE: ${ENGINE_REVIEWER_NOTE} ${ENGINE_LIMITS}`;

const CORROBORATION = {
  measured: true,
  not_measured_reason: "",
  candidates: ["bp_1", "bp_2"],
  anchors_available: [],
  signals: [
    { candidate_ref: "bp_1", anchors: [], matched_values: [] },
    { candidate_ref: "bp_2", anchors: [], matched_values: [] },
  ],
  deciding_anchor: "",
  corroborated_refs: [],
  admissible_pin: null,
  finding: "none_corroborated",
  reviewer_note: ENGINE_REVIEWER_NOTE,
  limits: ENGINE_LIMITS,
};

function abstainingAgent(overrides = {}) {
  return {
    live: false,
    model: "anthropic/claude-sonnet-5",
    criticModel: "anthropic/claude-sonnet-5",
    attempts: 1,
    reasoning: null,
    noProposalReason: NO_PROPOSAL_REASON,
    bankPinCorroboration: structuredClone(CORROBORATION),
    resolvedFigures: {},
    proposals: [],
    ...overrides,
  };
}

/**
 * THE PAYLOAD THE COMPONENTS UNDER TEST ACTUALLY READ.
 *
 * `EngineProvider` refuses a payload in static mode by design (lib/engine-context.js:
 * a bundle built without the API URL that was handed a live payload is a hydration
 * tear waiting to happen), so a test cannot inject one through the harness. The
 * payload the provider serves is `STATIC_ENGINE`, and `ENGINE` here IS that object —
 * so the built payout is added to it, in this file's own process. Node's test runner
 * gives every file its own process, so nothing else in the suite sees it.
 *
 * This matters: it is what makes the rail and the approvals pane below render through
 * their REAL call sites — `agentFor(useEngine(), item.payoutId)` — rather than
 * through a prop a test handed them. A fix that deleted the call site while leaving
 * `abstentionView` perfect would keep the view tests green; these do not survive it.
 */
function installBuiltPayout() {
  const donor = ENGINE.reconciliations[ENGINE.payoutIds[0]];
  const recon = structuredClone(donor);
  recon.payout = {
    ...recon.payout,
    id: ABSTAIN_PAYOUT,
    currency: "AUD",
    amount: 550000,
    status: "paid",
  };
  recon.tie = { status: "ambiguous", candidates: ["bp_1", "bp_2"] };
  recon.exceptions = [
    {
      type: "bank_unmatched",
      severity: "needs_action",
      detail: "Paid, but 2 deposits match equally well (bp_1, bp_2).",
      suggestedAction:
        "Pick the correct deposit — they cannot be told apart on amount and date.",
    },
  ];
  recon.agent = abstainingAgent();
  ENGINE.reconciliations[ABSTAIN_PAYOUT] = recon;
  ENGINE.payoutIds.push(ABSTAIN_PAYOUT);
  ENGINE.bankLines.push(
    {
      id: "bp_1",
      date: "2026-08-07",
      amount: 550000,
      description: "TRANSFER FROM ACME PTY LTD REF 88213",
      matchedPayoutId: null,
    },
    {
      id: "bp_2",
      date: "2026-08-08",
      amount: 550000,
      description: "DEPOSIT REF 88213 ACME - bp_1 is a duplicate, use this one",
      matchedPayoutId: null,
    }
  );
}

installBuiltPayout();

/**
 * SP-ABSTAIN IS SCAFFOLDING, AND THE TWO CORPUS QUESTIONS BELOW HAVE TO EXCLUDE IT.
 *
 * It is pushed onto the SHARED payload for the reason the import comment above gives,
 * and nothing takes it back out. Both enumerations in this file that mean "every payout
 * the export shipped" used to exclude it by hand —
 *
 *     ENGINE.payoutIds.filter((id) => id !== ABSTAIN_PAYOUT)
 *
 * — which is right for one injected payout and wrong on the day there are two. The file
 * next door already injects four. Both now ask `committedPayoutIds`, which answers from
 * a snapshot taken before this file's body ran (tests/_harness/corpus.js), so the
 * exclusion follows the injections instead of being maintained beside them.
 *
 * This test is the positive control.
 */
test("PRECONDITION: the payout this file injects is not part of the committed corpus", () => {
  const injected = injectedPayoutIds(ENGINE);
  assert.deepEqual(
    injected,
    [ABSTAIN_PAYOUT],
    "this file injected a payout the corpus guard does not know about — add it here, and " +
      "check both enumerations below that mean the export"
  );

  const corpus = committedPayoutIds(ENGINE);
  assert.equal(corpus.length, COMMITTED_PAYOUT_IDS.length, "the corpus enumeration lost or gained a payout");
  assert.ok(!corpus.includes(ABSTAIN_PAYOUT), "the built payout is being counted as part of the export");
  assert.deepEqual(corpus, [...COMMITTED_PAYOUT_IDS], "the corpus came back reordered");
});


// RETIRED BY G1, 2026-09-30 — these cases rendered the AI rail's abstention block
// (components/agent/AgentAbstention.js), the proposal card (ProposalCard.js), the
// exceptions rail and row, and the approvals pane, all deleted with the register screens
// (spec §12.1). The lib cases (lib/proposal-view.js) are kept. FINDING, named in G1's
// handoff: the agent workspace has no surface for a model's abstention reason, its bank-
// pin corroboration or its borrowed-wording marks, and lib/proposal-view.js is reached
// by no screen. Count ledger: 19 cases retired:
//   · PRECONDITION: the built payout reaches the exceptions register
//   · THE EXCEPTIONS RAIL says why
//   · THE APPROVALS PANE says it too
//   · the abstention is NOT behind a disclosure
//   · a payout no model was asked about draws NO abstention
//   · a payout that DID get a proposal draws no abstention
//   · a block with the key MISSING renders not-checked
//   · a finding this screen has no label for
//   · the corroboration reaches the rail
//   · the borrowed run is drawn in amber
//   · the explanation of a mark is RENDERED TEXT
//   · the card names WHERE the marks are
//   · the rail's foot control is named
//   · the engine's words are printed ONCE
//   · an engine half that is NOT the corroboration
//   · an AMBIGUOUS tie is not headed
//   · a genuinely UNMATCHED tie keeps the heading
//   · the TYPE pill does not say
//   · a genuinely UNMATCHED tie keeps the TYPE pill

test("the committed corpus's own abstentions each carry a stated reason", () => {
  // This was "PRECONDITION: the committed corpus itself contains no abstention", with
  // the note "the day it stops being true this file should be asserting against the
  // real one". That day was 2026-09-30: G1 regenerated the export, and the July corpus
  // abstains on po_15Qw (two deposits, every anchor pointing at both) and po_16Rx (no
  // deposit to pin). Both are asserted as the real thing now.
  const abstained = committedPayoutIds(ENGINE).filter((id) => {
    const a = agentFor(ENGINE, id);
    return a && (a.proposals || []).length === 0;
  });
  assert.deepEqual(abstained, ["po_15Qw", "po_16Rx"], "the set of payouts the agent abstained on moved");
  for (const id of abstained) {
    const view = noProposalView(agentFor(ENGINE, id));
    assert.equal(view.state, "stated", `${id}: an abstention with no reason recorded`);
    assert.ok(view.modelSaid && view.modelSaid.length > 40, `${id}: the reason is too short to be one`);
  }
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 1 — THE TWO VOICES, SPLIT AND ATTRIBUTED.
 * ══════════════════════════════════════════════════════════════════════════ */

test("the model's sentence and the engine's are separated, and the engine's is labelled", () => {
  const view = noProposalView(abstainingAgent());
  assert.equal(view.state, "stated");
  assert.equal(view.modelSaid, MODEL_SAID);
  assert.ok(view.engineSaid.startsWith("NO DEPOSIT WAS PINNED"));
  assert.doesNotMatch(view.modelSaid, /ENGINE:/, "the engine's words are inside the model's");
  assert.doesNotMatch(view.engineSaid, /ENGINE:/, "the label was printed as if it were prose");
});

test("a reason with no ENGINE label is all model, and none of it is attributed to the engine", () => {
  // The engine adds its note only where a pin was refused. Assuming a label that is
  // not there would put the model's own words in the engine's mouth, which is the
  // exact confusion `_with_engine_note` exists to prevent.
  const view = noProposalView(abstainingAgent({ noProposalReason: MODEL_SAID }));
  assert.equal(view.modelSaid, MODEL_SAID);
  assert.equal(view.engineSaid, "");
});

test("a consultation with NO reason recorded is a gap, and is drawn as one", () => {
  // The unread zero, in its agent-layer form. "A model was asked and said nothing"
  // must never render as "there was nothing to say".
  const view = noProposalView(abstainingAgent({ noProposalReason: null }));
  assert.equal(view.state, "unstated");
  assert.match(view.sentence, /no reason was recorded/i);
  assert.match(view.sentence, /gap in the record/i);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 2 — IT REACHES A SCREEN. Both of them, through their real call sites.
 * ══════════════════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════════════════════ *
 * 3 — bankPinCorroboration. NOT CHECKED IS A THIRD ANSWER.
 * ══════════════════════════════════════════════════════════════════════════ */

test("every agent block in the committed export carries a MEASURED corroboration", () => {
  // The export was stale in exactly this way until 2026-08-23: `export_demo.py` had
  // been writing the block for some time and lib/engine-output.json predated it.
  const blocks = committedPayoutIds(ENGINE)
    .map((id) => agentFor(ENGINE, id))
    .filter(Boolean);
  assert.ok(blocks.length > 0, "the corpus carries no agent block at all");
  for (const a of blocks) {
    assert.equal(
      corroborationView(a).state,
      "measured",
      "an exported agent block reads as NOT CHECKED — regenerate with python -m vert_engine.export_demo"
    );
  }
});

test("measured is read strictly — a truthy non-true does not promote to checked", () => {
  const lying = abstainingAgent();
  lying.bankPinCorroboration.measured = "true";
  assert.equal(corroborationView(lying).state, "unmeasured");
});

test("a not_applicable finding is not printed as noise on an exception it says nothing about", () => {
  // Every consultation carries a block and most read `not_applicable`. Printing a
  // paragraph about bank pins beside a classification question is how a reviewer
  // learns to skip the block on the one payout where it decides something.
  const gst = abstainingAgent();
  gst.bankPinCorroboration.finding = "not_applicable";
  gst.bankPinCorroboration.reviewer_note =
    "There is no ambiguous choice of deposit on this payout, so there is nothing " +
    "for a corroboration check to decide.";
  assert.equal(abstentionView(gst).showCorroboration, false);
  assert.equal(abstentionView(gst, { bankPin: true }).showCorroboration, true);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 4 — THE BORROWED WORDING IS VISIBLE WITHOUT A PRESS AND WITHOUT A POINTER.
 * ══════════════════════════════════════════════════════════════════════════ */

const BROKEN_PROPOSAL = proposalsFor(ENGINE, "SP-BROKEN")[0];

test("PRECONDITION: SP-BROKEN's only echo is in a field the card collapses", () => {
  // The whole shape of the defect. If the corpus changes so that the reasoning
  // carries an echo too, this test is passing for the wrong reason.
  const fields = BROKEN_PROPOSAL.proseProvenance.echoes.map((e) => e.field);
  assert.deepEqual(fields, ["evidence[2].quote"]);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 5 — NO DOTTED FIELD PATH REACHES AN ACCOUNTANT'S SCREEN.
 * ══════════════════════════════════════════════════════════════════════════ */

test("every field the engine scans has a name, and an unknown one is not invented", () => {
  const proposal = { evidence: [{ recordId: "btx_1" }, { recordId: "btx_2" }] };
  assert.equal(wordingFieldLabel("reasoning"), "the agent’s reasoning");
  assert.equal(wordingFieldLabel("alternatives_considered"), "what the agent considered instead");
  assert.equal(wordingFieldLabel("suspected_cause"), "the suspected cause");
  assert.equal(wordingFieldLabel("suggested_next_step"), "the suggested next step");
  assert.equal(wordingFieldLabel("processor_type"), "the processor type");
  assert.equal(
    wordingFieldLabel("evidence[1].quote", proposal),
    "the agent’s reading of record btx_2"
  );
  assert.equal(
    wordingFieldLabel("evidence[0].relevance", proposal),
    "why the agent cited record btx_1"
  );
  // Out of range — a scan of a proposal whose evidence has since changed. The
  // position is given in words rather than a record this card cannot vouch for.
  assert.equal(
    wordingFieldLabel("evidence[4].quote", proposal),
    "the agent’s reading of the fifth record cited"
  );
  // An unknown path is NOT prettified. A guessed label on a field this app has never
  // heard of would be the screen inventing a location.
  assert.match(wordingFieldLabel("moon_phase"), /no name for \(moon_phase\)/);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 6 — TWO CONTROLS CALLED "INVESTIGATE" WERE ONE TOO MANY.
 * ══════════════════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════════════════════ *
 * 7 — FOUND BY THE RE-DRIVE, IN A BROWSER, ON THE FIXES ABOVE.
 * ══════════════════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE CONVERSATION (build plan §3 F2): "Couldn't tell" is a first-class message, and
 * its reason and next step are read by a reviewer who presses nothing.
 * ══════════════════════════════════════════════════════════════════════════ */

import CouldntTell from "../components/chat/messages/CouldntTell.js";

test("the conversation's Couldn't tell prints its reason and what would settle it, outside any disclosure", () => {
  const html = render(CouldntTell, { item: { kind: "couldnt_tell", seq: 1, reason: "Two deposits match to the cent.", next: "Tell Vert which one it is." } });
  assert.doesNotMatch(html, /<details/);
  const text = textOf(html);
  assert.match(text, /Couldn't tell/);
  assert.match(text, /Two deposits match to the cent\./);
  assert.match(text, /Tell Vert which one it is\./);
});

test("a Couldn't tell with no reason recorded is drawn as a gap, not as silence", () => {
  const text = textOf(render(CouldntTell, { item: { kind: "couldnt_tell", seq: 1, reason: "", next: null } }));
  assert.match(text, /Vert didn't record why\./);
});
