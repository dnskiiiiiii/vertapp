// tests/answer-named-tasks.test.js — AN ANSWER LINKS THE TASKS IT NAMES, NOT ALL OF THEM
// Founder's walk, 8 Nov 2026: "which tasks are done?" answered three, then listed all
// sixteen tasks the turn read as links, burying the three it was about.
import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { namedTasks } from "../components/chat/messages/Answer.js";

const T = (template, label) => ({ template, label, href: `/chat/2026-10-${template}` });
const ALL = [T("bank_reconciliation", "Reconcile the bank account"), T("workpapers", "Build workpapers"), T("gl_reconciliation", "GL reconciliations"), T("card_reconciliation", "Credit card reconciliation"), T("fixed_asset_rollforward", "Fixed assets"), T("integration_feeds", "Integration feeds"), T("misclassification_scan", "Misclassification scan"), T("gl_900", "Reconcile 900 · Loan"), T("deferred_revenue", "Deferred revenue")];

test("only the tasks the answer's words name are linked", () => {
  const got = namedTasks(ALL, ["3 of October's 16 tasks are done: Integration feeds, Misclassification scan, and the reconciliation of the Loan account."]);
  assert.deepEqual(got.map((t) => t.template), ["integration_feeds", "misclassification_scan", "gl_900"]);
});

test("a task said in other words is still named: the fixed asset questions, the bank", () => {
  const got = namedTasks(ALL, ["Start with the bank reconciliations.", "Then do the credit card reconciliation and the fixed asset questions."]);
  assert.deepEqual(got.map((t) => t.template), ["bank_reconciliation", "card_reconciliation", "fixed_asset_rollforward"]);
});

test("an answer pointing at a list keeps every task; one naming none shows none", () => {
  assert.equal(namedTasks(ALL, ["The tasks are listed below."]).length, ALL.length);
  assert.deepEqual(namedTasks(ALL, ["Nothing is waiting on you."]), []);
  assert.deepEqual(namedTasks(null, ["x"]), []);
});
