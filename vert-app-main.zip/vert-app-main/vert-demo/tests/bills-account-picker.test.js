// tests/bills-account-picker.test.js — A BILL LINE IS CODED FROM THE CHART, ITS TAX RATE BY NAME
// ==============================================================================
// Staging browser walk 1 (31 Oct 2026, D11): Officeworks Ltd, a new contact, came with
// "Must fix: Line 1 has no account". The Account input's list held only Vert's
// suggestions — none here — so the bookkeeper had to know "453" by heart, while the
// Journals editor lists all 65 accounts. The Tax type input showed the raw code "INPUT";
// its name, "GST on Expenses", was printed under the account's error instead.
//
// Now the line picks its account from the chart (Vert's suggestions first), read with the
// same GET the journal editor uses, and its tax rate from a list worded by name.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { render, textOf } from "./_harness/render.js";
import { read, stripComments } from "./_harness/source.js";
import BillReview from "../components/bills/BillReview.js";
import { lineAccountChoices, lineTaxChoices } from "../lib/bills-model.js";
import { XERO_WRITES, item, line } from "./bills-fixtures.js";

const CHART = [
  { id: "a-200", number: "200", name: "Sales", active: true },
  { id: "a-453", number: "453", name: "Office Expenses", active: true },
  { id: "a-720", number: "720", name: "Office Equipment", active: true },
  { id: "a-old", number: "999", name: "Retired", active: false },
  { id: "a-nonum", number: null, name: "No code", active: true },
];

test("a line's accounts: Vert's suggestions first, then the active chart, each once, by code and name", () => {
  const original = line();
  const { groups } = lineAccountChoices({ original, current: "720", chart: CHART });
  assert.deepEqual(groups.map((g) => g.label), ["Vert's suggestions", "Your chart of accounts"]);
  assert.deepEqual(groups[0].options.map((o) => o.label), ["720 Office Equipment", "429 General Expenses"]);
  assert.deepEqual(groups[1].options.map((o) => o.value), ["200", "453"], "the chart repeats a suggestion, or lists an inactive or uncoded account");
  // A line with no suggestion is coded from the chart alone.
  const bare = lineAccountChoices({ original: line({ accountCode: null, accountName: null, alternatives: [] }), current: "", chart: CHART });
  assert.deepEqual(bare.groups.map((g) => g.label), ["Your chart of accounts"]);
  assert.ok(bare.groups[0].options.some((o) => o.label === "453 Office Expenses"));
  // A code typed earlier that the chart doesn't hold is kept, said as such.
  const typed = lineAccountChoices({ original: null, current: "455", chart: CHART });
  assert.ok(typed.groups.some((g) => g.options.some((o) => o.value === "455" && /455/.test(o.label))));
});

test("tax rates are offered by name; a rate the engine names only by code keeps the code", () => {
  const it = item({ document: { lines: [line(), line({ taxType: "EXEMPTEXPENSES", taxName: "GST Free Expenses", alternatives: [] })] } });
  const options = lineTaxChoices({ item: it, original: it.document.lines[0], current: "INPUT" });
  assert.deepEqual(options.map((o) => [o.value, o.label]), [["", "The account's own rate"], ["INPUT", "GST on Expenses"], ["EXEMPTEXPENSES", "GST Free Expenses"]]);
  // The engine's own list of the organisation's rates, when it sends one, is the list.
  const withRates = lineTaxChoices({ item: { ...it, taxRates: [{ taxType: "INPUT", name: "GST on Expenses" }, { taxType: "BASEXCLUDED", name: "BAS Excluded" }] }, original: null, current: "" });
  assert.deepEqual(withRates.map((o) => o.label), ["The account's own rate", "GST on Expenses", "BAS Excluded"]);
  const unknown = lineTaxChoices({ item: item({ document: { lines: [line({ taxName: null, alternatives: [] })] } }), original: null, current: "INPUT" });
  assert.ok(unknown.some((o) => o.value === "INPUT" && o.label === "INPUT"));
});

test("the review draws the account as a picker from the chart and the tax rate by name, never the raw code", () => {
  const officeworks = item({ document: { contactName: "Officeworks Ltd", lines: [line({ accountCode: null, accountName: null, codingConfidence: null, codingBasis: null, alternatives: [] })] } });
  const html = render(BillReview, { item: officeworks, xero: XERO_WRITES, chart: { accounts: CHART, note: null }, onItem() {}, onBack() {} });
  const accountSelect = (html.match(/<select[^>]*id="line-0-account"[\s\S]*?<\/select>/) || [""])[0];
  assert.ok(accountSelect, "the line's account is not a picker");
  assert.match(textOf(accountSelect), /453 Office Expenses/);
  assert.match(textOf(accountSelect), /200 Sales/);
  const taxSelect = (html.match(/<select[^>]*id="line-0-taxtype"[\s\S]*?<\/select>/) || [""])[0];
  assert.ok(taxSelect, "the line's tax rate is not a picker");
  assert.match(taxSelect, /<option value="INPUT"[^>]*>GST on Expenses<\/option>/);
  assert.doesNotMatch(textOf(taxSelect), /\bINPUT\b/);
});

test("with the chart unread the review says so and still offers Vert's suggestions", () => {
  const html = render(BillReview, { item: item(), xero: XERO_WRITES, chart: { accounts: [], note: "Vert couldn't read your chart of accounts just now. Your edits are kept." }, onItem() {}, onBack() {} });
  assert.match(textOf(html), /couldn't read your chart of accounts just now/);
  assert.match(textOf(html), /720 Office Equipment/);
});

test("the chart is read with the editors' GET, never a Server Action", () => {
  const src = stripComments(read("components/bills/BillReview.js"));
  assert.match(src, /readChartOnce\(\)/);
  assert.doesNotMatch(src, /readChartAccounts/);
});
