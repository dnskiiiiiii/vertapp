// tests/bills-routes.test.js — EVERY BILLS ROUTE THAT CHANGES SOMETHING REFUSES ANOTHER ORIGIN
// ==============================================================================
// The routes under app/api/bills act as the signed-in person (her cookie rides along),
// so a page on another site must not be able to upload, save, approve or set aside
// (S-SE-17, the guard app/api/documents/route.js carries). Each is called here with a
// cross-site, a same-site-other-port and an Origin-less request: each answers 403
// `cross_origin`, and the engine is never asked. The same-origin request does reach it,
// so the refusal is the guard's and not something else's.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { ID, item, json, recordingFetch } from "./bills-fixtures.js";

process.env.NEXT_PUBLIC_VERT_API_URL = "http://vert-api.invalid:8000";
const list = await import("../app/api/bills/route.js");
const bulk = await import("../app/api/bills/approve/route.js");
const one = await import("../app/api/bills/[id]/route.js");
const approveOne = await import("../app/api/bills/[id]/approve/route.js");
const discardOne = await import("../app/api/bills/[id]/discard/route.js");

const HOST = "127.0.0.1:3250";
const FOREIGN = [{ origin: "http://127.0.0.1:3241", "sec-fetch-site": "same-site" }, { origin: "https://evil.example", "sec-fetch-site": "cross-site" }, {}];
const SAME = { origin: `http://${HOST}`, "sec-fetch-site": "same-origin" };
const params = { params: Promise.resolve({ id: ID }) };

function uploadBody() {
  const form = new FormData();
  form.append("files", new Blob(["%PDF-1.4"], { type: "application/pdf" }), "planted.pdf");
  return form;
}

const WRITES = [
  ["POST /api/bills", (h) => list.POST(new Request(`http://${HOST}/api/bills`, { method: "POST", headers: { host: HOST, ...h }, body: uploadBody() }))],
  ["POST /api/bills/approve", (h) => bulk.POST(new Request(`http://${HOST}/api/bills/approve`, { method: "POST", headers: { host: HOST, "content-type": "application/json", ...h }, body: JSON.stringify({ itemIds: [ID] }) }))],
  ["PATCH /api/bills/[id]", (h) => one.PATCH(new Request(`http://${HOST}/api/bills/${ID}`, { method: "PATCH", headers: { host: HOST, "content-type": "application/json", ...h }, body: JSON.stringify({ document: { dueDate: "2026-11-30" } }) }), params)],
  ["POST /api/bills/[id]/approve", (h) => approveOne.POST(new Request(`http://${HOST}/api/bills/${ID}/approve`, { method: "POST", headers: { host: HOST, ...h } }), params)],
  ["POST /api/bills/[id]/discard", (h) => discardOne.POST(new Request(`http://${HOST}/api/bills/${ID}/discard`, { method: "POST", headers: { host: HOST, ...h } }), params)],
];

function engineReply(url) {
  if (url.endsWith("/bills/approve")) return json({ results: [{ itemId: ID, ok: true, item: item(), outcome: { status: "sent", words: "", xeroUrl: null, manualFields: [] } }] });
  if (url.endsWith("/approve")) return json({ item: item(), outcome: { status: "sent", words: "", xeroUrl: null, manualFields: [] } });
  if (url.endsWith("/bills/upload")) return json({ items: [item()], refused: [] }, 201);
  return json({ item: item() });
}

test("every bills write refuses a request from another origin with 403, and asks the engine nothing", async () => {
  const real = globalThis.fetch;
  const rec = recordingFetch(engineReply);
  globalThis.fetch = rec.fetchImpl;
  try {
    for (const [name, call] of WRITES) {
      for (const h of FOREIGN) {
        const res = await call(h);
        assert.equal(res.status, 403, `${name} ${JSON.stringify(h)}`);
        const body = await res.json();
        assert.deepEqual([body.ok, body.code], [false, "cross_origin"], name);
      }
    }
    assert.equal(rec.calls.length, 0, "no byte reached the engine");
    // The same request from this app's own page goes through: the 403 was the guard.
    for (const [name, call] of WRITES) {
      const res = await call(SAME);
      assert.ok(res.status === 200 || res.status === 201, `${name} answered ${res.status} from the same origin`);
    }
    assert.equal(rec.calls.length, WRITES.length);
  } finally {
    globalThis.fetch = real;
  }
});

test("a refusal keeps its status and words; an unread inbox is never a 200 with no items", async () => {
  const real = globalThis.fetch;
  globalThis.fetch = async () => json({ error: { code: "approve_blocked", message: "This bill is already in Xero." } }, 409);
  try {
    const res = await approveOne.POST(new Request(`http://${HOST}/api/bills/${ID}/approve`, { method: "POST", headers: { host: HOST, ...SAME } }), params);
    assert.equal(res.status, 409);
    assert.deepEqual(await res.json(), { ok: false, kind: "blocked", code: "approve_blocked", reason: null, message: "This bill is already in Xero." });
    globalThis.fetch = async () => {
      throw new TypeError("fetch failed");
    };
    const listed = await list.GET(new Request(`http://${HOST}/api/bills`));
    assert.equal(listed.status, 502);
    const body = await listed.json();
    assert.equal(body.ok, false);
    assert.equal("items" in body, false);
  } finally {
    globalThis.fetch = real;
  }
});
