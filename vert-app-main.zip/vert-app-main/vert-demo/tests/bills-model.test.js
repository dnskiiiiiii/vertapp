// tests/bills-model.test.js — THE BILLS INBOX'S WORDS AND RULES (lib/bills-model.js)
// ==============================================================================
// W3 "bill & invoice automation". What this file holds:
//
//   1. Every status in words, the engine's words preferred, the ledger word never shown.
//   2. Approve is offered only when nothing a person can see is wrong: the engine's
//      canApprove, no blocking flag, not a duplicate, nothing unsaved, not settled.
//   3. Each flag lands beside its field; a line's flags follow its index.
//   4. Money is the engine's cents, formatted; an absent figure is words, never $0.00.
//   5. The PATCH body carries only what changed, lines whole, and refuses bad input.
//   6. The panels' words: contact, duplicate (with a Xero link only on xero.com),
//      outcome (sent, or fields to enter by hand), the Xero connection line.
//   7. Uploads: a forwarded .eml goes to the email route, the rest to upload, and an
//      unreadable or oversized file is refused before anything is sent.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import {
  MAX_BULK,
  NEW_CONTACT_WORDS,
  STATUSES,
  approvalOf,
  approveLabel,
  bulkOf,
  centsInput,
  confidenceWords,
  contactView,
  draftOf,
  duplicateView,
  emptyLine,
  fieldConfidence,
  filterItems,
  filtersOf,
  flagsByField,
  flagsFor,
  isDirty,
  isItemId,
  lineFlags,
  moneyText,
  noLedgerWord,
  outcomeView,
  patchOf,
  safeXeroUrl,
  settledOutcome,
  sourceView,
  unplacedFlags,
  contactFlagsOf,
  methodNoteOf,
  pushNotesOf,
  statusTone,
  statusWords,
  uploadPlanOf,
  xeroView,
} from "../lib/bills-model.js";
import { ID, ID2, ID3, XERO_READ_ONLY, XERO_WRITES, item, line } from "./bills-fixtures.js";

const LEDGER_WORD = new RegExp(`\\b${"po"}sted\\b`, "i");

/* ── 1: status words ─────────────────────────────────────────────────────────── */

test("every engine status has its words, and the words carry the state", () => {
  const words = Object.fromEntries(STATUSES.map((s) => [s.id, s.words]));
  assert.deepEqual(words, {
    extracted: "Ready to approve",
    needs_review: "Needs review",
    duplicate: "Duplicate in Xero",
    approved: "Approved: enter in Xero",
    sent: "Sent to Xero as a draft",
    failed: "Couldn't send",
    unconfirmed: "Couldn't confirm: check Xero",
    discarded: "Set aside",
  });
  for (const s of STATUSES) {
    assert.equal(statusWords({ status: s.id }), s.words, `${s.id} without engine words`);
    assert.notEqual(statusTone(s.id), "unknown");
  }
  assert.equal(statusTone("sent"), "done");
  assert.equal(statusTone("failed"), "problem");
  assert.equal(statusWords({ status: "mystery" }), "Status not read");
  assert.equal(statusWords(null), "Status not read");
});

test("the engine's statusWords are used when present, and never when they say the ledger word", () => {
  assert.equal(statusWords({ status: "sent", statusWords: "Sent to Xero as a draft on 28 Oct" }), "Sent to Xero as a draft on 28 Oct");
  assert.equal(statusWords({ status: "sent", statusWords: `${"Po"}sted to Xero` }), "Sent to Xero as a draft");
  assert.equal(statusWords({ status: "extracted", statusWords: "   " }), "Ready to approve");
  assert.equal(noLedgerWord(`It was ${"po"}sted.`), null);
  assert.equal(noLedgerWord(`${"Po"}sting now`), null);
  // A word that merely contains the letters is not the word.
  assert.equal(noLedgerWord("Postcode 2000 is on the bill"), "Postcode 2000 is on the bill");
  assert.equal(noLedgerWord(42), null);
});

test("filters list All then every status; a count the engine didn't send is null, never 0", () => {
  const f = filtersOf({ extracted: 3, sent: 0 });
  assert.equal(f[0].id, "all");
  assert.equal(f.length, STATUSES.length + 1);
  assert.equal(f.find((x) => x.id === "extracted").count, 3);
  assert.equal(f.find((x) => x.id === "sent").count, 0, "a measured zero is kept");
  assert.equal(f.find((x) => x.id === "duplicate").count, null, "an unsent count is not a zero");
  assert.ok(filtersOf(null).every((x) => x.count === null));
  const items = [item(), item({ id: ID2, status: "sent" })];
  assert.equal(filterItems(items, "sent").length, 1);
  assert.equal(filterItems(items, "all").length, 2);
  assert.equal(filterItems(items, "nonsense").length, 2);
});

/* ── 2: approval ─────────────────────────────────────────────────────────────── */

test("approve is offered for a clean, extracted item the engine says can be approved", () => {
  assert.deepEqual(approvalOf(item()), { can: true, reason: null, confirm: null, confirmKind: null });
});

test("approve is withheld, with its reason, for every state a person can see is wrong", () => {
  const cases = [
    [item({ status: "duplicate" }), /already in Xero/],
    [item({ duplicate: { status: "duplicate", xeroUrl: "https://go.xero.com/x" } }), /already in Xero/],
    [item({ status: "sent" }), /Already sent to Xero as a draft/],
    [item({ status: "approved" }), /Already approved/],
    [item({ status: "discarded" }), /Set aside/],
    [item({ flags: [{ code: "total_mismatch", field: "totalCents", severity: "block", words: "The lines add to $1,000.00, not $1,100.00." }] }), /Fix this first: The lines add to/],
    [item({ canApprove: false, approveBlockedWords: "The contact has no name yet." }), /The contact has no name yet/],
    [item({ canApprove: false }), /hasn't said this one can be approved/],
    [item({ id: "not-a-uuid" }), /didn't send this item whole/],
  ];
  for (const [it, reason] of cases) {
    const a = approvalOf(it);
    assert.equal(a.can, false, JSON.stringify(it.status));
    assert.match(a.reason, reason);
  }
  assert.match(approvalOf(item(), { dirty: true }).reason, /Save your changes first/);
  // A review flag alone does not hold approval: the person has seen it beside its field.
  assert.equal(approvalOf(item({ flags: [{ code: "due_soon", field: "dueDate", severity: "review", words: "Due in 2 days." }] })).can, true);
  // Two blocks are counted, and the first is named.
  const two = approvalOf(item({ flags: [{ severity: "block", field: "dueDate", words: "No due date." }, { severity: "block", field: null, words: "Unreadable page." }] }));
  assert.match(two.reason, /^Fix 2 things first, starting with: No due date\./);
});

test("a stale canApprove can't override a blocking flag or a duplicate", () => {
  assert.equal(approvalOf(item({ canApprove: true, flags: [{ severity: "block", field: "totalCents", words: "x" }] })).can, false);
  assert.equal(approvalOf(item({ canApprove: true, status: "duplicate" })).can, false);
});

test("bulk approval sends only the ticked items that may be approved, at most 50", () => {
  const items = [item(), item({ id: ID2, status: "duplicate" }), item({ id: ID3 })];
  assert.deepEqual(bulkOf(items, new Set([ID, ID2])), { ready: [ID], held: [ID2], confirm: [], checkXero: [] });
  assert.deepEqual(bulkOf(items, [ID3]), { ready: [ID3], held: [], confirm: [], checkXero: [] });
  assert.deepEqual(bulkOf(items, []), { ready: [], held: [], confirm: [], checkXero: [] });
  const many = Array.from({ length: 60 }, (_, i) => item({ id: `0f8fad5b-d9cb-469f-a165-${String(i).padStart(12, "0")}` }));
  const out = bulkOf(many, many.map((x) => x.id));
  assert.equal(out.ready.length, MAX_BULK);
  assert.equal(out.held.length, 10);
});

test("the commit says what the press does: a draft in Xero, or fields to enter by hand", () => {
  assert.equal(approveLabel(XERO_WRITES), "Approve and send to Xero as a draft");
  assert.equal(approveLabel(XERO_READ_ONLY), "Approve & get fields for Xero");
  assert.equal(approveLabel(null), "Approve & get fields for Xero");
});

/* ── 3: flags and confidence ─────────────────────────────────────────────────── */

test("each flag is keyed by its field, blocks first; a flag about no field is general", () => {
  const it = item({
    flags: [
      { code: "due_soon", field: "dueDate", severity: "review", words: "Due in 2 days." },
      { code: "no_due", field: "document.dueDate", severity: "block", words: "No due date." },
      { code: "acct", field: "lines[1].accountCode", severity: "review", words: "Unusual account." },
      { code: "line", field: "lines[1]", severity: "block", words: "Line has no amount." },
      { code: "other", field: "lines[0].taxType", severity: "review", words: "Check the tax." },
      { code: "page", field: null, severity: "review", words: "Page 2 was blank." },
    ],
  });
  const by = flagsByField(it);
  assert.deepEqual(flagsFor(by, "dueDate").map((f) => f.code), ["no_due", "due_soon"], "document. is dropped and blocks lead");
  assert.deepEqual(by.general.map((f) => f.code), ["page"]);
  assert.deepEqual(lineFlags(by, 1).map((f) => [f.code, f.cell]).sort(), [["acct", "accountCode"], ["line", null]]);
  assert.deepEqual(lineFlags(by, 0).map((f) => f.cell), ["taxType"]);
  assert.deepEqual(lineFlags(by, 2), []);
  assert.deepEqual(flagsFor(by, "totalCents"), []);
});

test("a flag with no field drawn for it is listed above the fields, never dropped", () => {
  const it = item({
    flags: [
      { code: "a", field: "dueDate", severity: "review", words: "drawn" },
      { code: "b", field: "lines[0].accountName", severity: "review", words: "a cell not drawn" },
      { code: "c", field: "lines[5].taxType", severity: "block", words: "a line not there" },
      { code: "d", field: "duplicate", severity: "review", words: "no such field" },
      { code: "e", field: null, severity: "review", words: "no field" },
      { code: "f", field: "lines[0]", severity: "review", words: "the line" },
    ],
  });
  assert.deepEqual(unplacedFlags(it).map((f) => f.code), ["c", "d", "e"]);
  // The undrawn cell's flag leads its own line instead (BillReview's LineBlock).
  assert.deepEqual(lineFlags(flagsByField(it), 0).map((f) => f.cell).sort(), ["accountName", null]);
});

test("confidence is marked quietly for low and medium readings, and not for high", () => {
  const it = item();
  assert.equal(fieldConfidence(it, "dueDate"), "Low confidence");
  assert.equal(fieldConfidence(it, "totalCents"), "Medium confidence");
  assert.equal(fieldConfidence(it, "contactName"), null);
  assert.equal(fieldConfidence(it, "email"), null, "an unrated field is unmarked");
  assert.equal(confidenceWords("high"), null);
});

/* ── 4: money ────────────────────────────────────────────────────────────────── */

test("money is the engine's cents, formatted; an absent figure is words, never $0.00", () => {
  assert.equal(moneyText(110000), "$1,100.00");
  assert.equal(moneyText(0), "$0.00", "a measured zero is a zero");
  assert.equal(moneyText(null), "Not read");
  assert.equal(moneyText(undefined, "Vert didn't read a total"), "Vert didn't read a total");
  assert.equal(moneyText(12.5), "Not read", "a fraction of a cent is not the engine's money");
  assert.equal(centsInput(123456), "1,234.56");
  assert.equal(centsInput(-500), "-5.00");
  assert.equal(centsInput(null), "");
});

/* ── 5: the form and its PATCH ───────────────────────────────────────────────── */

test("an untouched form is not dirty and offers no PATCH body", () => {
  const it = item();
  const draft = draftOf(it);
  assert.equal(isDirty(it, draft), false);
  assert.deepEqual(patchOf(it, draft), { ok: true, errors: {}, body: null });
  assert.equal(draft.lines[0].unitAmount, "500.00");
  assert.equal(draft.contactChoice, "existing");
  assert.equal(draft.contactId, "c-acme");
});

test("the PATCH carries only the fields that changed", () => {
  const it = item();
  const draft = { ...draftOf(it), invoiceNumber: " INV-1043A ", dueDate: "2026-11-30" };
  assert.equal(isDirty(it, draft), true);
  assert.deepEqual(patchOf(it, draft).body, { document: { invoiceNumber: "INV-1043A", dueDate: "2026-11-30" } });
});

test("a changed line sends every line, whole, in cents; an emptied tax is null", () => {
  const it = item({ document: { lines: [line(), line({ description: "Desk", unitAmountCents: 30000, lineAmountCents: 30000, quantity: "1" })] } });
  const draft = draftOf(it);
  draft.lines = draft.lines.map((l, i) => (i === 1 ? { ...l, unitAmount: "$1,250.5", tax: "" } : l));
  const { ok, body } = patchOf(it, draft);
  assert.equal(ok, true);
  assert.equal(body.document.lines.length, 2);
  assert.equal(body.document.lines[0].unitAmountCents, 50000);
  assert.equal(body.document.lines[1].unitAmountCents, 125050);
  assert.equal(body.document.lines[1].taxCents, null);
  assert.equal(body.document.lines[1].quantity, "1");
  assert.equal("origin" in body.document.lines[0], false, "the draft's bookkeeping is never sent");
  // A line removed is a change; a line added starts empty.
  const fewer = { ...draftOf(it), lines: draftOf(it).lines.slice(0, 1) };
  assert.equal(patchOf(it, fewer).body.document.lines.length, 1);
  assert.equal(emptyLine().origin, null);
});

test("the printed totals are typed and sent as cents, null when blank, and never added up", () => {
  const it = item();
  const draft = draftOf(it);
  assert.deepEqual([draft.subtotal, draft.tax, draft.total], ["1,000.00", "100.00", "1,100.00"]);
  const edited = { ...draft, total: "$1,210.00", tax: "" };
  assert.equal(isDirty(it, edited), true);
  assert.deepEqual(patchOf(it, edited).body, { document: { totalCents: 121000, taxCents: null } });
  const bad = patchOf(it, { ...draft, subtotal: "about 1000" });
  assert.equal(bad.ok, false);
  assert.match(bad.errors.subtotalCents, /Enter an amount in dollars/);
  // An unread total starts blank, not $0.00.
  assert.equal(draftOf(item({ document: { totalCents: null } })).total, "");
});

test("input that can't be sent is named on its field, and no body is offered", () => {
  const it = item();
  const draft = draftOf(it);
  draft.issueDate = "12/10/2026";
  draft.currency = "dollars";
  draft.email = "not an email";
  draft.lines = [{ ...draft.lines[0], quantity: "two", lineAmount: "1.234" }];
  const out = patchOf(it, draft);
  assert.equal(out.ok, false);
  assert.equal(out.body, null);
  assert.deepEqual(Object.keys(out.errors).sort(), ["currency", "email", "issueDate", "lines[0].lineAmount", "lines[0].quantity"]);
});

test("the contact choice is sent as the engine names it: existing with an id, or new with a name", () => {
  const it = item({ contact: { status: "matched", matchedBy: "fuzzy", contactId: "c-1", name: "Acme", candidates: [{ contactId: "c-2", name: "Acme Holdings", taxNumber: null, score: 0.8 }], choice: "existing" } });
  const other = { ...draftOf(it), contactId: "c-2" };
  assert.deepEqual(patchOf(it, other).body, { contact: { choice: "existing", contactId: "c-2" } });
  const fresh = { ...draftOf(it), contactChoice: "new", contactId: "", newContactName: "Acme Group" };
  assert.deepEqual(patchOf(it, fresh).body, { contact: { choice: "new", name: "Acme Group" } });
  const nameless = { ...draftOf(it), contactChoice: "new", newContactName: "  " };
  assert.equal(patchOf(it, nameless).errors.contact, "Name the new contact.");
});

/* ── 6: the panels' words ────────────────────────────────────────────────────── */

test("the contact panel says how the contact was matched, or that it is new", () => {
  assert.equal(contactView(item().contact).words, "Matched to Acme Pty Ltd in Xero by ABN.");
  assert.match(contactView({ status: "matched", matchedBy: "name", name: "Acme" }).words, /by name\.$/);
  assert.match(contactView({ status: "matched", matchedBy: "fuzzy", name: "Acme" }).words, /close name match, so check it/);
  const fresh = contactView({ status: "new", contactId: null, name: "Acme", candidates: [], choice: "new" });
  assert.equal(fresh.words, NEW_CONTACT_WORDS);
  assert.equal(fresh.choice, "new");
  assert.match(contactView({ status: "unread" }).words, /couldn't read Xero's contacts/);
  assert.match(contactView(null).words, /couldn't read/);
});

test("a contact a person chose reads as chosen by you; contact flags go beside the choice", () => {
  assert.equal(contactView({ status: "matched", matchedBy: "person", confirmed: true, name: "Acme", contactId: "c-1" }).words, "Matched to Acme in Xero, chosen by you.");
  assert.equal(contactView({ status: "matched", matchedBy: null, confirmed: true, name: "Acme", contactId: "c-1" }).words, "Matched to Acme in Xero, chosen by you.");
  const by = flagsByField(
    item({
      flags: [
        { code: "contact_choose", field: "contactName", severity: "block", words: "Choose which Acme this is." },
        { code: "contact_fuzzy", field: "contactName", severity: "review", words: "A close name match." },
        { code: "name_long", field: "contactName", severity: "review", words: "The name is cut off." },
      ],
    })
  );
  const split = contactFlagsOf(by);
  assert.deepEqual(split.choice.map((f) => f.code), ["contact_choose", "contact_fuzzy"]);
  assert.deepEqual(split.name.map((f) => f.code), ["name_long"]);
  // A contact_choose block holds approval like any other block.
  assert.equal(approvalOf(item({ flags: [{ code: "contact_choose", field: "contactName", severity: "block", words: "Choose which Acme this is." }] })).can, false);
});

test("the method note and the send's own notes are shown in words, when the engine sent them", () => {
  assert.equal(methodNoteOf(item({ methodNote: "Read by rules: the model was unavailable." })), "Read by rules: the model was unavailable.");
  assert.equal(methodNoteOf(item({ methodNote: null })), null);
  // A push sentence that only repeats the status is said once, by the status (walk 3).
  assert.deepEqual(pushNotesOf(item({ pushWords: "Sent to Xero as a draft at 10:42 am.", attachment: "attached" })), ["The document was attached."]);
  assert.deepEqual(pushNotesOf(item({ attachment: "not attached: Xero refused files over 10 MB" })), ["The document was not attached: Xero refused files over 10 MB."]);
  assert.deepEqual(pushNotesOf(item({ pushWords: `${"Po"}sted to Xero` })), []);
  assert.deepEqual(pushNotesOf(item()), []);
});

test("a duplicate blocks, with a link to the copy in Xero; a link not on xero.com is never drawn", () => {
  const d = duplicateView({ status: "duplicate", words: null, xeroUrl: "https://go.xero.com/AccountsPayable/View.aspx?InvoiceID=1", invoiceNumber: "INV-1043" });
  assert.equal(d.blocking, true);
  assert.match(d.words, /already in Xero as INV-1043/);
  assert.equal(d.url, "https://go.xero.com/AccountsPayable/View.aspx?InvoiceID=1");
  assert.equal(duplicateView({ status: "duplicate", xeroUrl: "https://evil.example/xero.com" }).url, null);
  assert.equal(duplicateView({ status: "none" }), null);
  assert.equal(duplicateView({ status: "possible" }).blocking, false);
  assert.match(duplicateView({ status: "unread" }).words, /couldn't check Xero/);
  assert.equal(safeXeroUrl("http://go.xero.com/x"), null, "not https");
  assert.equal(safeXeroUrl("https://xero.com.evil.example/"), null);
  assert.equal(safeXeroUrl("javascript:alert(1)"), null);
});

test("an approval's outcome: sent as a draft with its link, or approved with the fields to enter", () => {
  const sent = outcomeView({ status: "sent", words: `${"Po"}sted`, xeroUrl: "https://go.xero.com/x", manualFields: [] });
  assert.deepEqual(sent, { status: "sent", words: "Sent to Xero as a draft", url: "https://go.xero.com/x", fields: [] });
  const manual = outcomeView({ status: "approved", words: "", xeroUrl: null, manualFields: [{ label: "Contact", value: "Acme" }, { label: "Total", value: 1100 }, { label: "", value: "x" }] });
  assert.equal(manual.words, "Approved: enter these in Xero");
  assert.deepEqual(manual.fields, [{ label: "Contact", value: "Acme" }, { label: "Total", value: "1100" }]);
  assert.equal(outcomeView(null), null);
  assert.equal(settledOutcome(item({ status: "sent", xero: { invoiceId: "x", url: "https://go.xero.com/y", status: "DRAFT" } })).url, "https://go.xero.com/y");
  assert.deepEqual(settledOutcome(item({ status: "approved", manualFields: [{ label: "Due", value: "2026-11-11" }] })).fields, [{ label: "Due", value: "2026-11-11" }]);
  assert.equal(settledOutcome(item()), null);
});

test("the Xero line explains that without write permission, approvals give fields for entry by hand", () => {
  const ro = xeroView(XERO_READ_ONLY);
  assert.equal(ro.state, "read-only");
  assert.match(ro.explain, /fields to enter in Xero by hand, until Xero is reconnected with the new invoices and contacts permissions/);
  const w = xeroView(XERO_WRITES);
  assert.equal(w.state, "writes");
  assert.match(w.explain, /sends a bill to Xero as a draft/);
  assert.equal(xeroView({ connected: false }).state, "disconnected");
  assert.equal(xeroView(null).state, "unread");
});

test("the source is framed when it's a PDF or an image, through the app's documents route", () => {
  assert.deepEqual(sourceView(item()), { kind: "frame", href: "/api/documents/a3bb189e-8bf9-4888-9912-ace4e6543002/file", words: null });
  assert.equal(sourceView(item({ mediaType: "image/tiff" })).kind, "frame");
  assert.equal(sourceView(item({ mediaType: "text/csv", source: "csv" })).kind, "link");
  assert.equal(sourceView(item({ documentId: "../../etc" })).kind, "none");
});

/* ── 7: uploads ──────────────────────────────────────────────────────────────── */

test("a forwarded .eml goes to the email route; documents to upload; anything else is refused", () => {
  const f = (name, size = 10, type = "") => ({ name, size, type });
  const plan = uploadPlanOf([f("a.pdf"), f("b.PNG"), f("fwd.eml"), f("c.xlsx"), f("note.docx"), f("raw", 10, "message/rfc822"), f("big.pdf", 26 * 1024 * 1024)]);
  assert.deepEqual(plan.documents.map((x) => x.name), ["a.pdf", "b.PNG", "c.xlsx"]);
  assert.deepEqual(plan.emails.map((x) => x.name), ["fwd.eml", "raw"]);
  assert.deepEqual(plan.refused.map((x) => x.filename), ["note.docx", "big.pdf"]);
  assert.match(plan.refused[1].message, /larger than 25 MB/);
  const many = uploadPlanOf(Array.from({ length: 22 }, (_, i) => f(`${i}.pdf`)));
  assert.equal(many.documents.length, 20);
  assert.equal(many.refused.length, 2);
});

test("ids are uuid4s, and nothing else is one", () => {
  assert.equal(isItemId(ID), true);
  for (const bad of ["", "abc", `${ID}/approve`, "../bills", ID.toUpperCase(), null, 7]) assert.equal(isItemId(bad), false, String(bad));
  assert.equal(LEDGER_WORD.test(NEW_CONTACT_WORDS), false);
});
