// tests/_harness/figures.js — IS EVERY AMOUNT ON SCREEN BOUND TO THE ENGINE?
// ==============================================================================
// Rubric C1 (build plan §9.3) samples `[data-figure]` elements across Month-end, Records,
// the cards and the results, and compares `data-cents` and the string with the API's
// answer for the same reference. That check can only see figures that carry the
// binding. A dollar amount rendered as plain text is invisible to it, so a page whose
// every amount is unbound scores "20/20 exact" on the one bound figure it has. The
// round-3 eval measured exactly that: 33 unbound money strings and 1 bound figure
// across seven pages.
//
// So the guard is the complement of C1: find every money string in rendered markup
// that sits OUTSIDE an element carrying `data-figure`. The markup is scanned as a tag
// stream with a stack, not with a regex over the text, because "inside" is a property
// of nesting: `<span data-figure><b>$7,000.00</b></span>` is bound, and a sibling
// `<b>$7,000.00</b>` after the span closes is not.
//
// ONE DECLARED EXCEPTION: `data-verbatim="engine"`. A sentence the engine wrote with an
// amount already formatted inside it ("A possible cause for the $150.00 AUD that does
// not reconcile") carries no cents to bind, and the app may not re-derive them from the
// words (that would be the app doing arithmetic on a string). Such text is marked where
// it is printed and reported separately by `verbatimMoney`, so the exception is visible
// and countable rather than silent; the fix is the engine emitting the figure as a
// figure, not this marker.
//
// Void elements (`<br>`, `<img>`, `<input>` …) and self-closed tags never open a scope.
// An attribute value is not rendered text, so `aria-label="$7,000.00 approved"` is not
// scanned here; the accessible name is the jargon guard's concern, not C1's.

const VOID = new Set(["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr"]);

// The shapes lib/format.js produces: "$7,000.00", "−$12.34", "($12.34)", "$7,000".
export const MONEY = /\$\s?\d[\d,]*(?:\.\d{2})?/g;

function decode(text) {
  return text
    .replace(/&nbsp;/g, " ")
    .replace(/&#x27;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/&#36;|&dollar;/g, "$");
}

/**
 * Every money string in `html` that is not inside a `[data-figure]` element, as
 * `{money, context}`; `context` is the surrounding text so a failure names the place.
 * Content of <style>, <script>, <title> and <head> is not rendered text and is skipped.
 */
export function unboundMoney(html) {
  return scan(html).unbound;
}

/** Money strings inside `[data-verbatim="engine"]`: the engine's own sentences. */
export function verbatimMoney(html) {
  return scan(html).verbatim;
}

function scan(html) {
  const out = [];
  const verbatim = [];
  const stack = []; // [{name, bound, hidden, verbatim}]
  const re = /<(\/?)([a-zA-Z][\w-]*)([^>]*?)(\/?)>|<!--[\s\S]*?-->|<![^>]*>|([^<]+)/g;
  let m;
  while ((m = re.exec(html))) {
    if (m[5] !== undefined) {
      if (stack.some((s) => s.bound || s.hidden)) continue;
      const text = decode(m[5]);
      const into = stack.some((s) => s.verbatim) ? verbatim : out;
      for (const hit of text.matchAll(MONEY)) {
        into.push({ money: hit[0], context: text.replace(/\s+/g, " ").trim().slice(0, 120) });
      }
      continue;
    }
    if (!m[2]) continue; // comment or doctype
    const name = m[2].toLowerCase();
    if (m[1]) {
      // Close the nearest open element of this name; anything left open inside it
      // (browser-tolerated sloppy markup) closes with it.
      for (let i = stack.length - 1; i >= 0; i--) {
        if (stack[i].name === name) {
          stack.length = i;
          break;
        }
      }
      continue;
    }
    if (m[4] || VOID.has(name)) continue;
    const bound = /\sdata-figure(?:\s*=|\s|$)/.test(m[3]);
    const hidden = name === "style" || name === "script" || name === "title" || name === "head";
    const isVerbatim = /\sdata-verbatim="engine"/.test(m[3]);
    stack.push({ name, bound, hidden, verbatim: isVerbatim });
  }
  return { unbound: out, verbatim };
}

/** Every bound figure: `{ref, cents, text}` for each element carrying `data-figure`. */
export function boundFigures(html) {
  const out = [];
  for (const m of html.matchAll(/<([a-zA-Z][\w-]*)([^>]*\sdata-figure(?:=("[^"]*"|'[^']*'))?[^>]*)>/g)) {
    const attrs = m[2];
    const ref = /\sdata-figure="([^"]*)"/.exec(attrs);
    const cents = /\sdata-cents="(-?\d+)"/.exec(attrs);
    out.push({ ref: ref ? ref[1] : "", cents: cents ? Number(cents[1]) : null, at: m.index });
  }
  return out;
}
