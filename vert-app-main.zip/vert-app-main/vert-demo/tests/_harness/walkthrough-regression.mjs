// tests/_harness/walkthrough-regression.mjs — DID ANY WALKTHROUGH BEAT THAT PASSED BEFORE STOP PASSING?
// ==============================================================================
// WHAT THIS IS FOR. The §18 walkthrough is 21 beats driven in a real browser over a
// throwaway stack (the G3a / G4a scripts, kept beside the research notes). Each run writes
// scorecards: one verdict per beat plus every check behind it. Iteration 4's bar (build plan
// §20.7 "WP") is "no beat that passed at G3 regresses". Reading 21 rows by eye against 21
// rows is exactly how a regression slips through, so the comparison is code, and the code
// lives here, in the repo, with constructed defects that prove it can go red.
//
// FOUR WAYS A RUN CAN LOOK GREEN WHILE A BEAT HAS REGRESSED, each one guarded below:
//
//   · the beat was never run (a scorecard is missing, or a script died before it). An
//     unrun beat is unmeasured, and unmeasured is never "fine": it counts as regressed.
//   · the beat's verdict says WORKS but one of its own deciding checks failed (a verdict
//     written by hand, or a script whose verdictFor drifted from its checks). The checks
//     are the measurement; a verdict that contradicts them is not believed.
//   · the beat appears twice (a re-run of one script beside an older file) and the first
//     copy passed while the second did not. The worst copy is the one that counts.
//   · "WORKS (recording)" is accepted only where the baseline itself was "WORKS (recording)"
//     (#14: posting into the recording ledger, not a real one). A beat that WORKED
//     outright at G3 and now only works against the recorder has lost something.
//
// A "polish: …" check is reported but never decides a verdict (the scripts' own rule).
//
//   node tests/_harness/walkthrough-regression.mjs <baseline.json> <scorecard.json>...
//   node tests/_harness/walkthrough-regression.mjs --self-test
//
// Exit 1 on any regression (or any self-test case that comes out wrong).

import fs from "node:fs";
import { fileURLToPath } from "node:url";

export const BEATS = 21;
const RANK = { WORKS: 3, "WORKS (recording)": 2 };
const rank = (v) => RANK[v] ?? 0;

/** A beat's verdict as its checks allow: a deciding check that failed makes it BROKEN. */
function believed(beat, checks) {
  const own = checks.filter((c) => String(c.beat) === String(beat.beat) && !/^polish:/i.test(c.name || ""));
  const failed = own.filter((c) => c.ok === false);
  if (rank(beat.verdict) && failed.length) {
    return { verdict: "BROKEN", why: `says ${beat.verdict} but ${failed.length} deciding check(s) failed: ${failed.map((c) => c.name).join("; ")}` };
  }
  return { verdict: beat.verdict, why: "" };
}

/**
 * Compare a run against the baseline.
 * @param {{[n: string]: {verdict: string, title?: string}}} baseline
 * @param {{beats: object[], checks?: object[]}[]} scorecards
 */
export function compareWalkthrough(baseline, scorecards) {
  const now = {};
  for (const card of scorecards) {
    const checks = card.checks || [];
    for (const b of card.beats || []) {
      const got = believed(b, checks);
      const prev = now[String(b.beat)];
      if (!prev || rank(got.verdict) < rank(prev.verdict)) now[String(b.beat)] = got;
    }
  }
  const rows = [];
  for (let n = 1; n <= BEATS; n++) {
    const was = baseline[n]?.verdict ?? "NOT SCORED";
    const is = now[n]?.verdict ?? "NOT RUN";
    let status;
    if (rank(was)) status = rank(is) >= rank(was) ? "held" : "REGRESSED";
    else status = rank(is) ? "fixed" : "still broken";
    rows.push({ beat: n, title: baseline[n]?.title, g3: was, now: is, status, why: now[n]?.why || "" });
  }
  const regressions = rows.filter((r) => r.status === "REGRESSED");
  const works = rows.filter((r) => r.beat !== 14 && r.now === "WORKS").length;
  return { rows, regressions: regressions.length, summary: { works: `${works}/${BEATS - 1}`, b14: now[14]?.verdict ?? "NOT RUN", regressions: regressions.length } };
}

function selfTest() {
  const base = {};
  for (let n = 1; n <= BEATS; n++) base[n] = { verdict: n === 8 ? "BROKEN" : n === 14 ? "WORKS (recording)" : "WORKS" };
  const allPass = () => ({
    beats: Array.from({ length: BEATS }, (_, i) => ({ beat: String(i + 1), verdict: i + 1 === 14 ? "WORKS (recording)" : "WORKS" })),
    checks: Array.from({ length: BEATS }, (_, i) => ({ beat: i + 1, name: "the beat's check", ok: true })),
  });
  const edit = (f) => { const c = allPass(); f(c); return [c]; };
  const cases = [
    ["product shape: every beat passes", [allPass()], 0],
    ["defect: beat #3 BROKEN", edit((c) => { c.beats[2].verdict = "BROKEN"; }), 1],
    ["defect: beat #12 never run", edit((c) => { c.beats.splice(11, 1); }), 1],
    ["defect: a whole scorecard missing (beats 15-21)", edit((c) => { c.beats.splice(14); }), 7],
    ["defect: #9 says WORKS but a deciding check failed", edit((c) => { c.checks.push({ beat: 9, name: "beat completes", ok: false }); }), 1],
    ["polish only: #9's failed polish check does not decide", edit((c) => { c.checks.push({ beat: 9, name: "polish: wording", ok: false }); }), 0],
    ["defect: #5 run twice, the later copy BROKEN", (() => { const a = allPass(); const b = { beats: [{ beat: "5", verdict: "BROKEN" }], checks: [] }; return [a, b]; })(), 1],
    ["defect: #4 only works against the recorder now", edit((c) => { c.beats[3].verdict = "WORKS (recording)"; }), 1],
    ["defect: #14 NOT BUILT", edit((c) => { c.beats[13].verdict = "NOT BUILT"; }), 1],
    ["#8 (BROKEN at G3) still broken is not a regression", edit((c) => { c.beats[7].verdict = "BROKEN"; }), 0],
  ];
  let bad = 0;
  for (const [name, cards, want] of cases) {
    const got = compareWalkthrough(base, cards).regressions;
    const ok = got === want;
    bad += !ok;
    console.log(`${ok ? "ok  " : "FAIL"} ${name}: ${got} regression(s), expected ${want}`);
  }
  return bad ? 1 : 0;
}

if (process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url))) {
  const args = process.argv.slice(2);
  if (args[0] === "--self-test") process.exit(selfTest());
  if (args.length < 2) { console.error("usage: walkthrough-regression.mjs <baseline.json> <scorecard.json>... | --self-test"); process.exit(2); }
  const [b, ...cards] = args;
  const baseline = JSON.parse(fs.readFileSync(b, "utf8")).beats;
  const read = cards.filter((f) => fs.existsSync(f) || (console.log(`MISSING scorecard ${f}`), false)).map((f) => JSON.parse(fs.readFileSync(f, "utf8")));
  const out = compareWalkthrough(baseline, read);
  for (const r of out.rows) console.log(`#${String(r.beat).padStart(2)} ${r.status.padEnd(12)} G3 ${r.g3.padEnd(18)} now ${r.now}${r.why ? `  (${r.why})` : ""}`);
  console.log(JSON.stringify(out.summary));
  if (process.env.WALKTHROUGH_REGRESSION_OUT) fs.writeFileSync(process.env.WALKTHROUGH_REGRESSION_OUT, JSON.stringify({ at: new Date().toISOString(), files: cards, ...out }, null, 2));
  process.exit(out.regressions ? 1 : 0);
}
