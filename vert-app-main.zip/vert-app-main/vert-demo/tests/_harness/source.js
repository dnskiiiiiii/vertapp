// tests/_harness/source.js — READ THE APP'S OWN SOURCE, WITHOUT ITS PROSE
// ==============================================================================
// Two of this suite's claims are STRUCTURAL rather than behavioural: "no
// arithmetic has crept back into the JS", and gate 1 (`ReconcileScreen`'s bulk
// approve skips blocked payouts), which lives inside a component body that
// cannot be driven without a DOM. Both are asserted by scanning source text.
//
// A naive `grep` over these files is worthless, because this codebase's house
// style is heavy comments — `lib/payouts.js`'s own docstring contains the words
// "add a calculation", the minus signs in `formatCentsSigned`'s comments are
// literal `-` characters, and `lib/money.js` holds a U+2212 in a string. A scan
// that cannot tell code from commentary produces false positives, gets an
// exclusion bolted on, and stops being evidence.
//
// So: strip block comments, line comments, string literals and template
// literals FIRST, replacing each with a space so token boundaries and (for
// multi-line spans) line numbers survive. Everything that remains is code.
// `stripNonCode` is itself covered by tests/harness.test.js — a stripper nobody
// checked is the same trap as a verifier that cannot fail.

import { readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { ROOT } from "./loader.js";

export { ROOT };

export function read(relPath) {
  return readFileSync(path.join(ROOT, relPath), "utf8");
}

// Every .js file under one of the app's own directories, relative to ROOT.
export function listAppSources(...dirs) {
  const out = [];
  for (const dir of dirs) {
    const abs = path.join(ROOT, dir);
    const walk = (p) => {
      for (const name of readdirSync(p).sort()) {
        const full = path.join(p, name);
        if (statSync(full).isDirectory()) walk(full);
        else if (name.endsWith(".js")) out.push(path.relative(ROOT, full));
      }
    };
    walk(abs);
  }
  return out;
}

// Replace comments and literals with spaces. Character-by-character rather than
// regex, because every regex approach to this problem is wrong on some input
// (a `//` inside a string, a `*/` inside a template, a `/` that is division and
// not a regex literal).
export function stripNonCode(src) {
  return scan(src, false);
}

/**
 * THE OTHER HALF OF THE SAME PROBLEM: comments out, STRING LITERALS KEPT.
 *
 * WHY THIS EXISTS. `stripNonCode` blanks string literals, and that is right for its
 * own subject — arithmetic, identifiers, structure. It is exactly wrong for a guard
 * whose subject IS a literal, and four of this suite's guards were written that way
 * and could never fire. Measured on 2026-08-25 by putting back the very thing each
 * one forbids, and watching every one of them pass:
 *
 *   tests/gates.test.js      `import { verifyPayout } from "./verifier"` added to
 *                            lib/store.js — an import specifier is a string literal.
 *   tests/rail.test.js       `<button aria-label="Settings" onClick={…} />` put back
 *                            into SideNav — a JSX attribute value is a string literal.
 *   tests/setup.test.js      `{ label: "Setup", href: "/setup" }` added to the rail —
 *                            a route is a string literal. (The same trap was found in
 *                            a different file the round before.)
 *   tests/bank-import.test.js  a `return "date"` translation layer restored.
 *
 * A ROUND LATER, FIVE MORE, found by mutating every negative source guard in the suite
 * rather than by reading them (2026-08-25):
 *
 *   tests/ai-rail-truth.test.js   `case "START_RUN":` back in lib/store.js's reducer —
 *                                 an action type is a string literal.
 *   tests/engine-source.test.js   `error.digest === "DYNAMIC_SERVER_USAGE"` — an error
 *                                 digest is a string literal.
 *   tests/no-arithmetic.test.js   `process.env["NEXT_PUBLIC_VERT_API_URL"]` — the
 *   (`knowers` and `leaks`)       bracket access form is a string literal.
 *   tests/prefill-arm.test.js     `proposal["prefill"]` — the same, one field down.
 *
 * The rule that came out of it is in tests/guard-primitive.test.js: `stripNonCode` is
 * now an EXCEPTION a guard must justify, not the default it reaches for, and the money
 * arithmetic scan is the only subject that still justifies it.
 *
 * Each of those guards carries a comment naming the mutation it catches. None of them
 * caught it. A guard that cannot see its subject is worse than no guard: it is a green
 * line in the report standing where a person believes a check is happening.
 *
 * WHY NOT RAW SOURCE. Because the house style is heavy comments and the files
 * discuss the very things being forbidden — components/shell/ia.js explains at length
 * why `/setup` is NOT a rail item, and a raw scan would fail on the explanation. That
 * false positive is what sent these guards to `stripNonCode` in the first place. The
 * answer is neither raw nor `stripNonCode`: it is comments out, literals in.
 *
 * ONE SCANNER, TWO OUTPUTS. It shares `scan` with `stripNonCode` rather than
 * reimplementing the hard part — a line comment opened inside a string, a block
 * comment closed inside a template, a slash that is division and not a regex — so the
 * two cannot drift apart on any input. (That list is written out in words rather than
 * in symbols because the symbols for the second one close THIS comment: the first
 * draft of this docstring ended itself three lines early and would not parse.)
 */
export function stripComments(src) {
  return scan(src, true);
}

function scan(src, keepLiterals) {
  const out = [];
  let i = 0;
  const n = src.length;

  // Keep newlines so a reported line number still points at the right line.
  const blank = (from, to) => {
    for (let k = from; k < to; k++) out.push(src[k] === "\n" ? "\n" : " ");
  };

  // A literal is blanked or kept depending on which output was asked for. Comments
  // always go through `blank`, in both modes — that is the half the two share.
  const literal = (from, to) => {
    if (!keepLiterals) return blank(from, to);
    for (let k = from; k < to; k++) out.push(src[k]);
  };

  // A `/` starts a regex literal only where a value cannot already have ended.
  // Look back at the last non-space code character to decide.
  // AND A KEYWORD IS NOT A VALUE, WHICH COST THE MASK EIGHTEEN LINES OF A TEST FILE.
  // FOUND 2026-08-30 alongside the newline rule above. The look-back asks whether the
  // last code character could have ENDED a value, and a letter could — so `return /re/`
  // and `typeof /re/` were read as division, and the scan carried on into the regex
  // body. tests/absent-is-not-clean.test.js:414 holds `return /^\s*["']use server["']…/`
  // and the `"` inside that character class opened a string that ran to the next quote
  // eighteen lines later. Same failure as the newline one, from the other direction.
  //
  // The fix is the word, not the character: after one of these a `/` can only begin a
  // regex, because none of them is a value.
  const KEYWORD_BEFORE_REGEX =
    /(?:^|[^A-Za-z0-9_$])(return|typeof|instanceof|case|in|of|do|else|yield|await|new|delete|void|throw)$/;

  const regexAllowedHere = () => {
    for (let k = out.length - 1; k >= 0; k--) {
      const c = out[k];
      if (c === " " || c === "\n" || c === "\t" || c === "\r") continue;
      if (!/[A-Za-z0-9_$)\].]/.test(c)) return true;
      // A word character can end a value (`x / y`) or a keyword (`return /re/`). Read
      // back over the identifier and ask which it was.
      let w = k;
      while (w >= 0 && /[A-Za-z0-9_$]/.test(out[w])) w--;
      return KEYWORD_BEFORE_REGEX.test(out.slice(0, k + 1).join(""));
    }
    return true;
  };

  while (i < n) {
    const c = src[i];
    const next = src[i + 1];

    if (c === "/" && next === "/") {
      let j = i;
      while (j < n && src[j] !== "\n") j++;
      blank(i, j);
      i = j;
      continue;
    }

    if (c === "/" && next === "*") {
      let j = src.indexOf("*/", i + 2);
      j = j === -1 ? n : j + 2;
      blank(i, j);
      i = j;
      continue;
    }

    // A QUOTED RUN THAT CROSSES A NEWLINE IS NOT A STRING, AND PRETENDING IT WAS
    // DESYNCHRONISED THE MASK OVER FORTY LINES OF A COMPONENT.
    // ------------------------------------------------------------------------
    // FOUND 2026-08-30. This scanner knows JS and not JSX, and in JSX TEXT an
    // apostrophe is an apostrophe. components/je/JournalEntry.js writes "the payout's
    // own transaction detail" on line 88; the scanner opened a string there and closed
    // it on "the entry's own Σ debits" on line 122, so thirty-four lines of markup —
    // and the JSX comment inside them — were handed back as literal text. The probe
    // locates producers in `stripComments(src)` precisely so that a COMMENT can never
    // count as a branch the app can emit, and here it did: the only `Σ debits` the
    // probe could see in that file was the one inside that comment. It blanked the
    // comment, watched the suite stay green, and recorded UNANCHORED over a guard whose
    // real producer — `&Sigma; debits`, twelve lines further down — it never touched.
    // That is the defect this whole mechanism exists to hunt, in the mask it rests on.
    //
    // No JSX parser is needed to fix it, because ECMAScript already forbids the thing
    // that goes wrong: a single- or double-quoted string may not contain a raw newline.
    // A run that reaches one was never a string, so the quote is ordinary text and the
    // scan advances one character. Nothing legal changes; the desync cannot start.
    if (c === '"' || c === "'") {
      let j = i + 1;
      while (j < n && src[j] !== c && src[j] !== "\n") j += src[j] === "\\" ? 2 : 1;
      if (j >= n || src[j] === "\n") {
        out.push(c);
        i++;
        continue;
      }
      j = Math.min(j + 1, n);
      literal(i, j);
      i = j;
      continue;
    }

    if (c === "`") {
      // Template literals nest: `${ ... `inner` ... }` is legal. Track depth so
      // the interpolated EXPRESSIONS survive as code (they can hold arithmetic)
      // while the literal text does not.
      //
      // The BACKTICKS themselves are kept. They are the only remaining marker
      // that a value came out of a literal, and the arithmetic scan needs it:
      // `…${amount} — ` + `…` is string concatenation, and without the backtick
      // the scan sees the identifier `amount` beside a `+` and reports a money
      // sum that is not there.
      let j = i + 1;
      out.push("`");
      while (j < n) {
        if (src[j] === "\\") {
          literal(j, j + 2);
          j += 2;
          continue;
        }
        if (src[j] === "`") {
          out.push("`");
          j++;
          break;
        }
        if (src[j] === "$" && src[j + 1] === "{") {
          let depth = 1;
          let k = j + 2;
          out.push(keepLiterals ? "$" : " ", keepLiterals ? "{" : " ");
          while (k < n && depth > 0) {
            if (src[k] === "{") depth++;
            else if (src[k] === "}") depth--;
            if (depth === 0) break;
            k++;
          }
          // Recurse so nested literals inside the interpolation are stripped too.
          out.push(...scan(src.slice(j + 2, k), keepLiterals));
          out.push(keepLiterals ? "}" : " ");
          j = k + 1;
          continue;
        }
        literal(j, j + 1);
        j++;
      }
      i = j;
      continue;
    }

    if (c === "/" && regexAllowedHere()) {
      let j = i + 1;
      let inClass = false;
      let closed = false;
      while (j < n) {
        const d = src[j];
        if (d === "\\") {
          j += 2;
          continue;
        }
        if (d === "\n") break;
        if (d === "[") inClass = true;
        else if (d === "]") inClass = false;
        else if (d === "/" && !inClass) {
          closed = true;
          j++;
          while (j < n && /[a-z]/.test(src[j])) j++;
          break;
        }
        j++;
      }
      if (closed) {
        literal(i, j);
        i = j;
        continue;
      }
    }

    out.push(c);
    i++;
  }

  return out.join("");
}

/**
 * A REGEX FOR ONE PROPERTY READ, IN BOTH SPELLINGS.
 *
 * `obj.prefill` and `obj["prefill"]` are the same read, and a guard written as
 * `/\.prefill\b/` sees only the first. Under `stripNonCode` the second was invisible
 * twice over — the helper blanked the literal AND the pattern wanted a dot — so a
 * component could take the forbidden field by writing three extra characters.
 * Measured 2026-08-25 on components/agent/ProposalCard.js: `proposal["prefill"]`
 * passed tests/prefill-arm.test.js 30/30.
 *
 * Feed the output `stripComments`, never `stripNonCode`: the bracket form IS a string
 * literal, and the literal-blanking scanner erases the half this exists to catch.
 */
export function propAccess(name) {
  return new RegExp(`\\.\\s*${name}\\b|\\[\\s*["']${name}["']\\s*\\]`);
}

// The braced body that follows `marker`, matched brace-for-brace. Slicing "from
// the marker to the next `function`" is what a lazy version of this does, and it
// silently swallowed the whole rest of lib/store.js the first time — a scan over
// too much source reports the wrong file's sins as this function's.
export function bodyAfter(src, marker) {
  const at = src.indexOf(marker);
  if (at === -1) return null;
  const open = src.indexOf("{", at);
  if (open === -1) return null;
  let depth = 0;
  for (let i = open; i < src.length; i++) {
    if (src[i] === "{") depth++;
    else if (src[i] === "}" && --depth === 0) return src.slice(at, i + 1);
  }
  return null;
}

// Stripped source as numbered lines, for reporting a hit at a real location.
export function codeLines(relPath) {
  return stripNonCode(read(relPath))
    .split("\n")
    .map((text, idx) => ({ file: relPath, line: idx + 1, text }));
}
