// tests/_harness/render.js — RENDER A REAL COMPONENT, WITH NO BROWSER
// ==============================================================================
// `react-dom/server` is already a dependency (react-dom ships it), so the demo's
// real components can be rendered to markup with nothing new installed — no
// jsdom, no testing-library, no headless browser. What that buys is the
// difference between asserting a component's PREDICATE and asserting what a
// reviewer would actually see: gate 2 is "the approve control is disabled", and
// the honest form of that claim is "no approve button appears in the markup".
//
// WHAT THIS CANNOT DO, stated so no test is written believing otherwise:
//   · `useEffect` does not run under server rendering. Anything a component
//     only does in an effect is invisible here.
//   · There is no interaction. State cannot be changed, so a behaviour that
//     needs a click (ReconcileScreen's bulk selection) cannot be driven this
//     way, and tests/gates.test.js says so where it applies.
// Both limits are properties of server rendering, not of this file.

import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { EngineProvider } from "../../lib/engine-context.js";
import { StoreProvider } from "../../lib/store.js";

// Every screen under test is mounted inside <EngineProvider><StoreProvider> in
// app/layout.js, so every render here is too. Rendering one without them would
// exercise a tree the app never mounts.
//
// `payload` is null, which is what app/layout.js passes in the DEFAULT static mode —
// the provider then serves `STATIC_ENGINE`, the file, out of lib/engine-source.js.
// This suite runs with NEXT_PUBLIC_VERT_API_URL unset (tests/engine-source.test.js
// asserts that outright), so every render below is a render of the static showpiece,
// including its read-only write controls.
export function render(Component, props = {}) {
  return renderToStaticMarkup(
    createElement(
      EngineProvider,
      { payload: null },
      createElement(StoreProvider, null, createElement(Component, props))
    )
  );
}

// Collapse markup to visible text, so an assertion about what a reviewer reads
// is not defeated by an element boundary landing mid-sentence.
export function textOf(html) {
  return html
    .replace(/<[^>]*>/g, " ")
    .replace(/&mdash;/g, "—")
    .replace(/&rsquo;/g, "’")
    .replace(/&middot;/g, "·")
    .replace(/&Sigma;/g, "Σ")
    .replace(/&darr;/g, "↓")
    .replace(/&amp;/g, "&")
    .replace(/&#x27;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

// ══════════════════════════════════════════════════════════════════════════════
// THE OTHER HALF OF THE PRODUCT — RENDERING A WRITE-ENABLED SCREEN
// ══════════════════════════════════════════════════════════════════════════════
//
// `render()` above renders the static showpiece, and until round 19 it was the only
// thing this file could do. That left a whole class of state untestable: every
// `writesEnabled`-gated branch — the live Approve button, the live Sync control, the
// panels whose "record" press is armed rather than greyed — had NO component-level
// coverage at all, because `EngineProvider` throws if it is handed a payload while
// `NEXT_PUBLIC_VERT_API_URL` is unset, and this suite runs with it unset on purpose
// (tests/engine-source.test.js asserts that outright, and that guard is NOT relaxed).
//
// The seam is the one the API-mode tests already use — tests/gst-direction-wire.js,
// tests/connections-transport.js, tests/writes.js: `SOURCE` in lib/engine-source.js
// is resolved at MODULE LOAD, and `node --test` gives every test FILE its own
// process, so a file that sets the variable before its first import of anything that
// reads it is genuinely in API mode for its whole life, and no other file is affected.
//
// What was missing was a renderer that would then hand a payload over. That is this.
// Use it ONLY from a file that has set NEXT_PUBLIC_VERT_API_URL before importing this
// module, and import this module dynamically (`await import(...)`) so the assignment
// happens first. `renderLive` refuses rather than silently rendering the static half
// if that discipline was not followed, because a test that believed it was exercising
// the write-enabled branch while actually exercising the read-only one would be worse
// than no test.
//
// The payload it hands over is the caller's. Passing STATIC_ENGINE is legitimate and
// is what most callers want: the figures are not what is under test, the GATE is.
export async function renderLive(Component, props = {}, payload = undefined) {
  const { SOURCE, STATIC_ENGINE } = await import("../../lib/engine-source.js");
  if (SOURCE !== "api") {
    throw new Error(
      "renderLive() was called in a process that is NOT in API mode, so it would have " +
        "rendered the read-only showpiece under a name that says otherwise. Set " +
        "process.env.NEXT_PUBLIC_VERT_API_URL at the TOP of the test file, before the " +
        "first import of this harness, and import this harness with `await import(...)`."
    );
  }
  return renderToStaticMarkup(
    createElement(
      EngineProvider,
      { payload: payload === undefined ? STATIC_ENGINE : payload },
      createElement(StoreProvider, null, createElement(Component, props))
    )
  );
}
