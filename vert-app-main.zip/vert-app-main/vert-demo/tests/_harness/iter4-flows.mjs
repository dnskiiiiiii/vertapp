// tests/_harness/iter4-flows.mjs — DID EVERY ITERATION-4 FLOW ACTUALLY PASS, MEASURED?
// ==============================================================================
// WHAT THIS IS FOR. Iteration 4's new flows (build plan §20.7 BV1–ST2), the §17.3 click
// counts and the non-fixture first screen (NF-1st) are driven end to end over a throwaway
// stack by G4a-2's scripts (kept beside the research notes, iter4/e2e/G4a-2/). Each script
// writes a scorecard: `{flows, checks: [{flow, name, ok, evidence}], measures: {key:
// {value, evidence}}}`. §20.7 says the gates "are not averaged", so the verdict is code, it
// lives here, and constructed defects prove it can go red.
//
// HOW A RUN CAN LOOK GREEN WHILE A FLOW FAILED, each one guarded below:
//
//   · a flow never ran (its script died first, or it was left out). Unmeasured is never
//     "fine": a flow with no deciding check is NOT RUN, and NOT RUN fails.
//   · a click count, the unattended-post count or the bridge's sum gap was never measured
//     (missing, null, or not a number — "3" typed as text is not a count). Each fails.
//   · a non-averaged gate is hidden inside a flow that otherwise passes: ST1's 0 posts
//     without a press, AY6's bridge summing to the cent, BV1's "Couldn't look" never
//     reading as none, NF-1st's three sentences. Each is its own required line, and its
//     check must be PRESENT, not merely not failed.
//   · a check ran twice (a re-run beside an older card) and one copy failed: the worst
//     copy counts.
//
// A check named "polish: …" is reported but never decides (as the walkthrough's rule).
//
//   node tests/_harness/iter4-flows.mjs <scorecard.json>...
//   node tests/_harness/iter4-flows.mjs --self-test
//
// Exit 1 when any flow fails (or any self-test case comes out wrong).

import fs from "node:fs";
import { fileURLToPath } from "node:url";

/** The flows §20.7 gives G4a-2, in its order. "§17.3" is the click-count line. */
export const FLOWS = ["BV1", "BV2", "TO", "AY5", "AY6", "AY7", "AN-new", "ST1", "ST2", "NF-1st", "§17.3"];

/**
 * The reference's click counts for the nearest flows (W0r, iter4/output-teardown-iter4.md
 * §G; presses only, typing not counted). Vert passes at ≤ each.
 */
export const REFERENCE_CLICKS = { import_budget: 3, schedule_start: 3, ask_bridge_drill: 3 };

/**
 * Lines that must be present AND ok in a flow (substring of the check's name, case
 * folded). These are the non-averaged gates of §20.7 and NF-1st's three sentences.
 */
export const REQUIRED_CHECKS = {
  BV1: ["403"],
  "NF-1st": ["found none", "scheduling isn't available here", "no schedule button"],
  ST1: ["0 posts"],
  ST2: ["fires once"],
  AY6: ["sums to the cent"],
};

const isCount = (v) => typeof v === "number" && Number.isFinite(v) && Number.isInteger(v) && v >= 0;
const fold = (s) => String(s || "").toLowerCase().replace(/[’']/g, "'");

/** Required measures: key → test on the value, and the words a failure reads as. */
export const REQUIRED_MEASURES = {
  "§17.3": Object.fromEntries(
    Object.entries(REFERENCE_CLICKS).map(([k, ref]) => [`clicks.${k}`, (v) => (isCount(v) && v >= 1 ? (v <= ref ? null : `${v} presses, the reference takes ${ref}`) : "not measured")])
  ),
  ST1: { "st1.unattendedPosts": (v) => (isCount(v) ? (v === 0 ? null : `${v} posted without a press`) : "not measured") },
  AY6: { "ay6.bridgeSumOffCents": (v) => (isCount(v) ? (v === 0 ? null : `the bars miss the change by ${v} cent(s)`) : "not measured") },
};

/**
 * Score the scorecards.
 * @param {{checks?: object[], measures?: object}[]} cards
 */
export function scoreFlows(cards) {
  const checks = [];
  const measures = {};
  for (const c of cards) {
    for (const ch of c.checks || []) checks.push(ch);
    for (const [k, m] of Object.entries(c.measures || {})) {
      // The worst copy counts: a later card cannot overwrite a failing measure with a passing one.
      const v = m && typeof m === "object" && "value" in m ? m.value : m;
      if (!(k in measures)) measures[k] = [];
      measures[k].push(v);
    }
  }
  const rows = [];
  for (const flow of FLOWS) {
    const own = checks.filter((c) => c.flow === flow);
    const deciding = own.filter((c) => !/^polish:/i.test(c.name || ""));
    const why = [];
    for (const c of deciding) if (c.ok !== true) why.push(`failed: ${c.name}`);
    for (const need of REQUIRED_CHECKS[flow] || []) {
      const hits = deciding.filter((c) => fold(c.name).includes(fold(need)));
      if (!hits.length) why.push(`missing required line: ${need}`);
    }
    for (const [key, test] of Object.entries(REQUIRED_MEASURES[flow] || {})) {
      const values = measures[key] || [];
      if (!values.length) why.push(`${key}: not measured`);
      for (const v of values) {
        const bad = test(v);
        if (bad) why.push(`${key}: ${bad}`);
      }
    }
    const measured = deciding.length > 0 || Object.keys(REQUIRED_MEASURES[flow] || {}).some((k) => (measures[k] || []).length);
    const verdict = !measured ? "NOT RUN" : why.length ? "FAIL" : "PASS";
    rows.push({ flow, verdict, checks: deciding.length, polish: own.length - deciding.length, why });
  }
  const failed = rows.filter((r) => r.verdict !== "PASS");
  return { rows, failed: failed.length, summary: Object.fromEntries(rows.map((r) => [r.flow, r.verdict])) };
}

function selfTest() {
  const good = () => {
    const checks = [];
    for (const f of FLOWS) {
      if (f === "§17.3") continue;
      checks.push({ flow: f, name: `${f} works`, ok: true });
      for (const need of REQUIRED_CHECKS[f] || []) checks.push({ flow: f, name: `the ${need} line`, ok: true });
    }
    const measures = {
      "clicks.import_budget": { value: 3 },
      "clicks.schedule_start": { value: 2 },
      "clicks.ask_bridge_drill": { value: 3 },
      "st1.unattendedPosts": { value: 0 },
      "ay6.bridgeSumOffCents": { value: 0 },
    };
    return { checks, measures };
  };
  const edit = (f) => {
    const c = good();
    f(c);
    return [c];
  };
  const cases = [
    ["product shape: every flow measured and passing", [good()], 0],
    ["defect: AY7 never ran", edit((c) => { c.checks = c.checks.filter((x) => x.flow !== "AY7"); }), 1],
    ["defect: an ST2 check failed", edit((c) => { c.checks.push({ flow: "ST2", name: "never fires after cancel", ok: false }); }), 1],
    ["polish only: a failed polish line does not decide", edit((c) => { c.checks.push({ flow: "AY5", name: "polish: wording", ok: false }); }), 0],
    ["defect: a flow with only polish lines is NOT RUN", edit((c) => { c.checks = c.checks.filter((x) => x.flow !== "AN-new"); c.checks.push({ flow: "AN-new", name: "polish: x", ok: true }); }), 1],
    ["defect: importing a budget takes 4 presses (reference 3)", edit((c) => { c.measures["clicks.import_budget"].value = 4; }), 1],
    ["defect: the schedule click count was never measured", edit((c) => { delete c.measures["clicks.schedule_start"]; }), 1],
    ["defect: a click count recorded as null", edit((c) => { c.measures["clicks.ask_bridge_drill"].value = null; }), 1],
    ["defect: a click count typed as the text '3'", edit((c) => { c.measures["clicks.ask_bridge_drill"].value = "3"; }), 1],
    ["defect: ST1 posted once without a press", edit((c) => { c.measures["st1.unattendedPosts"].value = 1; }), 1],
    ["defect: ST1's unattended-post count unmeasured", edit((c) => { delete c.measures["st1.unattendedPosts"]; }), 1],
    ["defect: the bridge misses the change by one cent", edit((c) => { c.measures["ay6.bridgeSumOffCents"].value = 1; }), 1],
    ["defect: NF-1st never checked 'Scheduling isn't available here'", edit((c) => { c.checks = c.checks.filter((x) => !fold(x.name).includes("scheduling isn't available here")); }), 1],
    ["defect: BV1 never checked the 403 (Couldn't look) line", edit((c) => { c.checks = c.checks.filter((x) => !(x.flow === "BV1" && x.name.includes("403"))); }), 1],
    ["defect: a re-run card fails a check the first card passed", (() => [good(), { checks: [{ flow: "BV2", name: "BV2 works", ok: false }] }])(), 1],
    ["defect: a re-run card's measure is worse (5 presses)", (() => [good(), { checks: [], measures: { "clicks.schedule_start": { value: 5 } } }])(), 1],
  ];
  let bad = 0;
  for (const [name, cards, want] of cases) {
    const got = scoreFlows(cards).failed;
    const ok = got === want;
    bad += !ok;
    console.log(`${ok ? "ok  " : "FAIL"} ${name}: ${got} failing flow(s), expected ${want}`);
  }
  return bad ? 1 : 0;
}

export { selfTest };

if (process.argv[1] && fs.realpathSync(process.argv[1]) === fs.realpathSync(fileURLToPath(import.meta.url))) {
  const args = process.argv.slice(2);
  if (args[0] === "--self-test") process.exit(selfTest());
  if (!args.length) {
    console.error("usage: iter4-flows.mjs <scorecard.json>... | --self-test");
    process.exit(2);
  }
  const read = args.filter((f) => fs.existsSync(f) || (console.log(`MISSING scorecard ${f}`), false)).map((f) => JSON.parse(fs.readFileSync(f, "utf8")));
  const out = scoreFlows(read);
  for (const r of out.rows) console.log(`${r.flow.padEnd(7)} ${r.verdict.padEnd(8)} ${String(r.checks).padStart(3)} check(s)${r.why.length ? `  — ${r.why.join("; ")}` : ""}`);
  console.log(JSON.stringify(out.summary));
  if (process.env.ITER4_FLOWS_OUT) fs.writeFileSync(process.env.ITER4_FLOWS_OUT, JSON.stringify({ at: new Date().toISOString(), files: args, ...out }, null, 2));
  process.exit(out.failed ? 1 : 0);
}
