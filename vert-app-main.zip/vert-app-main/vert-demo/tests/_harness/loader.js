// tests/_harness/loader.js — LET NODE READ THIS APP'S SOURCE, UNMODIFIED
// ==============================================================================
// WHY THIS EXISTS. The demo's central claim — a payout that does not tie is
// BLOCKED — lives in three places, and two of them are inside React component
// bodies (`components/reconcile/ReconcileScreen.js`, `components/approvals/
// ApprovalDetail.js`). A test that only re-implemented their predicates would be
// testing itself. To assert the real thing, `node --test` has to be able to
// IMPORT those files, and they are `.js` files containing JSX, `@/` path aliases
// and JSON import attributes that plain Node refuses.
//
// WHAT IT DOES NOT DO: add a dependency. The transform below is Next's own
// bundled SWC — `next/dist/build/swc`, the exact compiler `next build` uses,
// already present in node_modules because `next` is a dependency. No vitest, no
// jest, no babel, no esbuild, no jsdom. The demo's runtime dependency surface
// stays at three packages and its dev surface stays at zero, which matters on a
// product whose brief treats every added package as supply-chain surface.
//
// FOUR THINGS NODE CANNOT DO ALONE, and the hook that fixes each:
//
//   1. JSX in a .js file            -> load(): SWC transform, automatic runtime.
//   2. `@/lib/x` path alias         -> resolve(): jsconfig.json's baseUrl, by hand.
//   3. `import J from "./x.json"    -> load(): SWC strips the `with { type: ... }`
//      with { type: "json" }`          attribute (verified: both
//                                      preserveImportAssertions and
//                                      preserveImportAttributes still drop it),
//                                      so Node would reject the bare specifier.
//                                      JSON is therefore served as a synthetic
//                                      ES module instead of relying on the
//                                      attribute surviving.
//   4. `next/link`, `next/navigation`, `next/cache`, `*.css`
//                                   -> resolve(): redirected to the inert stubs
//                                      in ./stubs/. These are app-shell
//                                      concerns (routing, fonts, styling) that
//                                      no gate depends on; stubbing them keeps
//                                      a render test from becoming a Next.js
//                                      integration test.
//
// THE ONE PIECE OF INSTRUMENTATION, stated plainly rather than hidden: a
// specifier may carry `?expose=a,b`, and the load hook appends an export
// statement for those names to the END of the transformed source. Gate 3 —
// `lib/store.js`'s RECORD_APPROVAL no-op, the gate V1-STATUS.md §2.8 calls "the
// one that matters, because it is the only one that holds if gates 1 and 2 are
// both wrong" — is a module-private `reducer`. Exposing it here tests the REAL
// reducer out of the REAL file; the alternative was editing lib/store.js, and
// the brief says tests only. Nothing is written to disk and the app's own
// import graph is untouched: `?expose=` is only ever spelled inside tests/.
//
// Registered by tests/_harness/register.js, which every test file imports first.

import { createRequire } from "node:module";
import { existsSync, readFileSync, statSync } from "node:fs";
import { fileURLToPath, pathToFileURL } from "node:url";
import path from "node:path";

const require = createRequire(import.meta.url);
const { transformSync } = require("next/dist/build/swc");

const HERE = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(HERE, "..", "..");

const STUBS = {
  "next/link": path.join(HERE, "stubs", "next-link.js"),
  "next/navigation": path.join(HERE, "stubs", "next-navigation.js"),
  // Reached because lib/decisions.js imports the Server Actions in lib/actions.js,
  // which call revalidatePath after a successful write. Routing and cache
  // invalidation are app-shell concerns; no gate depends on either.
  "next/cache": path.join(HERE, "stubs", "next-cache.js"),
  // Reached because lib/engine-server.js and lib/actions.js import lib/session.js,
  // which reads the session cookie. The stub is an EMPTY jar, so anything that
  // touches this path in a test behaves as an anonymous request rather than as a
  // fabricated signed-in one — see the stub's own header for why that direction
  // matters. The session's real properties are asserted in tests/session.test.js
  // against lib/session-seal.js, which imports nothing from Next.
  "next/headers": path.join(HERE, "stubs", "next-headers.js"),
  // `import "server-only"` in lib/session.js. A bundle-time guard with nothing to
  // guard under `node --test`, and NOT installed as its own package. Stubbed rather
  // than removed from the source, so `next build` still enforces it.
  "server-only": path.join(HERE, "stubs", "server-only.js"),
  // The one stub that is NOT inert. proxy.js — the sign-in gate — is imported and
  // CALLED by tests/session.test.js, so NextResponse has to report what it decided.
  // See the stub's header.
  "next/server": path.join(HERE, "stubs", "next-server.js"),
};

// Only the app's own source is transformed. Anything under node_modules is
// already valid JavaScript and must be left alone — running React itself
// through a JSX transform would be both pointless and slow.
function isAppSource(filePath) {
  return (
    filePath.startsWith(ROOT + path.sep) &&
    !filePath.includes(`${path.sep}node_modules${path.sep}`)
  );
}

// Bundler-style extensionless resolution. `lib/payoutStatus.js` says
// `import { PAYOUTS } from "./data"` — legal to Next, not to Node's ESM
// resolver. Rather than "fix" the app's imports (the brief says tests only),
// the extension is supplied here, exactly as the bundler would.
const EXT_CANDIDATES = ["", ".js", ".mjs", ".json", "/index.js"];

function firstExisting(basePath) {
  for (const ext of EXT_CANDIDATES) {
    const candidate = basePath + ext;
    if (existsSync(candidate) && statSync(candidate).isFile()) return candidate;
  }
  return null;
}

export function resolve(specifier, context, nextResolve) {
  if (STUBS[specifier]) {
    return { url: pathToFileURL(STUBS[specifier]).href, format: "module", shortCircuit: true };
  }

  if (specifier.endsWith(".css")) {
    return {
      url: pathToFileURL(path.join(HERE, "stubs", "empty.css.js")).href,
      format: "module",
      shortCircuit: true,
    };
  }

  // jsconfig.json: { "paths": { "@/*": ["./*"] } }. Next resolves this through
  // its bundler; outside Next nothing does, so it is done here.
  if (specifier.startsWith("@/")) {
    const hit = firstExisting(path.join(ROOT, specifier.slice(2)));
    if (hit) return { url: pathToFileURL(hit).href, format: "module", shortCircuit: true };
  }

  if (specifier.startsWith("./") || specifier.startsWith("../")) {
    const [bare, query = ""] = specifier.split("?");
    const parentPath = context.parentURL && context.parentURL.startsWith("file:")
      ? fileURLToPath(new URL(new URL(context.parentURL).pathname, "file:"))
      : null;
    if (parentPath) {
      const hit = firstExisting(path.resolve(path.dirname(parentPath), bare));
      if (hit && isAppSource(hit)) {
        const url = pathToFileURL(hit);
        if (query) url.search = query;
        return { url: url.href, format: "module", shortCircuit: true };
      }
    }
  }

  return nextResolve(specifier, context);
}

export function load(url, context, nextLoad) {
  if (!url.startsWith("file:")) return nextLoad(url, context);

  const parsed = new URL(url);
  const filePath = fileURLToPath(new URL(parsed.pathname, "file:"));

  // JSON as a synthetic ES module — see note 3 above.
  if (filePath.endsWith(".json") && isAppSource(filePath)) {
    const raw = readFileSync(filePath, "utf8");
    return { format: "module", shortCircuit: true, source: `export default ${raw};` };
  }

  if (!filePath.endsWith(".js") || !isAppSource(filePath)) return nextLoad(url, context);

  const source = readFileSync(filePath, "utf8");
  const out = transformSync(source, {
    filename: filePath,
    jsc: {
      parser: { syntax: "ecmascript", jsx: true },
      target: "es2022",
      transform: { react: { runtime: "automatic" } },
    },
    module: { type: "es6" },
    isModule: true,
  });

  let code = out.code;
  const expose = parsed.searchParams.get("expose");
  if (expose) {
    const names = expose
      .split(",")
      .map((n) => n.trim())
      .filter(Boolean);
    // Appended, never substituted: if one of these bindings is renamed or
    // deleted the import fails loudly rather than silently testing nothing.
    code += `\nexport { ${names.join(", ")} };\n`;
  }

  return { format: "module", shortCircuit: true, source: code };
}
