// tests/_harness/routes.js — DOES THE APP SERVE THIS PATH?
// ==============================================================================
// A link is an affordance: "press this and you get the thing". A link whose path no
// route answers is a control that does nothing, and it is worse than a missing one,
// because the person pressing it is told the product has the thing and then gets a
// 404 page (eval 9.3.F-8, 30 Sep: the bank reconciliation's own Download Excel link
// was `/reconciliations/bank.xlsx`, an API path, rendered verbatim on the app's origin;
// the app serves that workbook at `/reconciliation/bank/xlsx`).
//
// `servedBy(path)` answers from what is ON DISK: an `app/**/page.js` or `route.js`
// whose segments match (a `[param]` directory matches any one segment, a `(group)`
// directory is transparent), or a redirect `source` in next.config.mjs. It does not
// ask the running app, so it cannot be fooled by a catch-all 404 page that answers
// 200, and it runs in the static suite with no server.
//
// The oracle is checked separately (tests/no-false-affordance.test.js): it must accept
// routes known to exist and refuse the path that r1 found dead, or it is a check that
// shares the defect.

import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import path from "node:path";
import { ROOT } from "./loader.js";

const APP = path.join(ROOT, "app");

// Redirect sources, read from next.config.mjs as text: importing the config would run
// its build-time code, and only the literal `source:` strings matter here.
function redirectSources() {
  const text = readFileSync(path.join(ROOT, "next.config.mjs"), "utf8");
  return [...text.matchAll(/source:\s*"([^"]+)"/g)].map((m) => m[1]);
}

function dirs(abs) {
  try {
    return readdirSync(abs).filter((n) => statSync(path.join(abs, n)).isDirectory());
  } catch {
    return [];
  }
}

// Depth-first over app/, consuming one URL segment per directory, groups for free.
function match(abs, segments) {
  if (!segments.length) {
    if (existsSync(path.join(abs, "page.js")) || existsSync(path.join(abs, "route.js"))) return path.relative(ROOT, abs) || "app";
    for (const g of dirs(abs).filter((d) => /^\(.+\)$/.test(d))) {
      const hit = match(path.join(abs, g), segments);
      if (hit) return hit;
    }
    return null;
  }
  const [head, ...rest] = segments;
  for (const d of dirs(abs)) {
    const next = path.join(abs, d);
    if (/^\(.+\)$/.test(d)) {
      const hit = match(next, segments);
      if (hit) return hit;
    } else if (d === head || /^\[[^.\]]+\]$/.test(d)) {
      const hit = match(next, rest);
      if (hit) return hit;
    }
  }
  return null;
}

/**
 * Which route file (or redirect) serves `href` on the app's own origin, or null.
 * An absolute URL to another origin, a fragment or a mailto is not the app's to serve
 * and answers `"external"`.
 */
export function servedBy(href) {
  const raw = String(href || "");
  if (!raw) return null;
  if (/^(https?:|mailto:|tel:|#)/.test(raw)) return "external";
  const pathname = decodeURIComponent(raw.split(/[?#]/)[0]);
  if (!pathname.startsWith("/")) return null;
  if (redirectSources().includes(pathname)) return `redirect ${pathname}`;
  const segments = pathname.split("/").filter(Boolean);
  return match(APP, segments);
}
