// tests/_harness/red-files-reporter.mjs — WHICH TEST FILES WENT RED, NOT WHETHER ANY DID
// ==============================================================================
// The negative-anchor probe used to ask the suite one bit: green or not green. That bit
// is not enough, and the gap it left was measured on 2026-08-30: the probe's verdict is
// PER PATTERN, and anchoring is PER ASSERTION SITE. `/padding/` was recorded `anchored`
// on the strength of a test file going red that does not assert `/padding/` anywhere —
// blanking the phrase across the app reddened somebody else's POSITIVE assertion, and
// the guard forbidding it was never exercised at all. That is the probe's own subject
// committed by the probe: a green that was true and meant nothing.
//
// Closing it needs the identity of the red files, and node's TAP output does not carry
// it — over a glob the runner flattens every file's tests into one numbered list with no
// file names. The reporter API does carry it: every event has `data.file`, the absolute
// path of the file the test was defined in. So this reporter throws away everything
// except that, and prints one JSON line the caller parses.
//
//   node --test --test-reporter=./tests/_harness/red-files-reporter.mjs "tests/**/*.test.js"
//
// A file that fails to LOAD — which is what a sentinel does when it lands in the middle
// of syntax — is reported too: node emits `test:fail` for the file itself, so the file
// that could not import the mutated module is named, which is the correct attribution.
export default async function* redFilesReporter(source) {
  const red = new Set();
  let counted = 0;
  for await (const event of source) {
    // A failing `todo` (a ledgered known-red, e.g. month-all-cards' S4 guard) does not
    // fail the run, so it is not red here either: counting it made the exit code and
    // this report disagree, and the probe refused every run while a todo was ledgered.
    if (event.type === "test:fail" && !event.data?.todo) {
      counted++;
      if (event.data?.file) red.add(event.data.file);
    }
  }
  // `counted` is reported beside the set so a caller can tell "nothing failed" from
  // "something failed and carried no file" — the second is a hole in this reporter and
  // must not be read as the first.
  yield JSON.stringify({ redFiles: [...red].sort(), failures: counted }) + "\n";
}
