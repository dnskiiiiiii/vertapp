// tests/_harness/corpus.js — WHICH PAYOUTS CAME FROM THE EXPORT, AND WHICH A TEST ADDED
// =============================================================================
// THE PROBLEM THIS SOLVES
//
// `STATIC_ENGINE` is a singleton — one object, read from lib/engine-output.json, and
// the very object `EngineProvider` serves in static mode. A test that needs a payout
// the committed corpus does not contain (an abstention, a model that never answered)
// therefore cannot use a `structuredClone`: the component under test reads
// `useEngine()`, gets the shared object, and never sees the clone. The only way to put
// a payout in front of a real call site is to add it to the shared payload. Two files
// do exactly that, deliberately, and say so at length:
//
//   tests/abstention.test.js         one payout,  SP-ABSTAIN
//   tests/absent-is-not-clean.test.js  four payouts, SP-SILENT / SP-DOWN / SP-OPEN /
//                                      SP-DECIDED
//
// The addition is permanent. Nothing takes it back out, and nothing can: the payout has
// to still be there when the tests that render it run. That is fine. What is NOT fine is
// the consequence — every enumeration in that file, `ENGINE.payoutIds` and
// `allPayoutIds(ENGINE)` alike, now yields a corpus with test scaffolding in it, and a
// test that means "every payout the export shipped" silently means something else.
//
// Both files were already coping with that BY HAND:
//
//     ENGINE.payoutIds.filter((id) => id !== ABSTAIN_PAYOUT)
//
// which is correct for exactly as long as there is one injected payout and somebody
// remembers to extend the filter on the day there are two. The file next door already
// has four and no filter at all. A hand-maintained exclusion list is the same shape of
// defect as a hand-maintained route list — it is right on the day it is written and
// wrong on the day the thing it lists changes, which is the shape this project has been
// burned by repeatedly.
//
// WHY A SNAPSHOT IS RELIABLE HERE, AND NOT A RACE
//
// `COMMITTED_PAYOUT_IDS` is taken in this module's body. That is not a hopeful ordering:
// ES module evaluation runs an imported module to completion BEFORE the first statement
// of the module that imports it. A test file's top-level `installBuiltPayout()` is a
// statement in the test file's body, so it cannot run until every module it imports —
// this one included — has finished initialising. The snapshot is therefore the corpus as
// committed, on every import path, in every order, guaranteed by the language rather
// than by a comment asking people to be careful.
//
// (Node's test runner also gives every test FILE its own process, so no injection can
// reach another file. That is what keeps this a latent trap rather than a live one, and
// it is not something to rely on: it is a property of how the suite happens to be
// invoked, not of the code.)
//
// WHAT TO USE
//
//   committedPayoutIds(ENGINE)  every payout the export shipped, in export order, with
//                               nothing a test added. This is what "the corpus" means.
//   injectedPayoutIds(ENGINE)   the complement — what this process's tests added.
//
// Neither restores anything, because restoring is not what is wanted. What is wanted is
// that a question about the export gets an answer about the export.

import { STATIC_ENGINE } from "../../lib/engine-source.js";

/**
 * The payout ids in lib/engine-output.json, frozen, taken before any test file body has
 * run. See the note above on why the ordering is guaranteed and not lucky.
 */
export const COMMITTED_PAYOUT_IDS = Object.freeze([...STATIC_ENGINE.payoutIds]);

const COMMITTED = new Set(COMMITTED_PAYOUT_IDS);

/**
 * Every payout the export shipped, in export order — never one a test installed.
 *
 * Takes the payload as an argument rather than closing over `STATIC_ENGINE` so it reads
 * like the `lib/` functions beside it (`allPayoutIds(engine)`, `payoutStatus(engine,
 * id)`) and so a test holding a different payload gets an answer about that payload.
 */
export function committedPayoutIds(engine) {
  return engine.payoutIds.filter((id) => COMMITTED.has(id));
}

/**
 * What this process's tests added to the shared payload — the complement of
 * :func:`committedPayoutIds`, in the order it was pushed.
 *
 * Worth having as an export rather than a private detail: a file that injects can assert
 * over exactly what it injected, which is how the guard in tests/harness.test.js notices
 * an injection that nobody accounted for.
 */
export function injectedPayoutIds(engine) {
  return engine.payoutIds.filter((id) => !COMMITTED.has(id));
}

/* ── THE PAYOUTS THE ENGINE ITSELF COULD NOT TIE TO THE BANK ──────────────────
 *
 * Until 2026-09-30 the committed export held exactly one blocked payout, SP-BROKEN, and
 * a dozen guards were written as "SP-BROKEN, and nothing else". G1 regenerated the export
 * from the merged engine, whose corpus had meanwhile gained four July payouts built to
 * open panels nothing else could reach (vert-engine c5499dd, 7a2cd44):
 *
 *   po_14Pv, po_15Qw   paid, and TWO deposits fit each (tie `ambiguous`)
 *   po_16Rx            paid, and NO deposit fits (tie `unmatched`)
 *   po_13Nt            paid and tied, but its GST is undetermined
 *
 * The first three are refused by lib/verifier.js check 5 (`deposit_ties_to_declared`),
 * which is that check doing its job: a landed payout with no single deposit is not
 * approvable. So "the only blocked payout is SP-BROKEN" became false for a reason that
 * is itself a correct refusal, and every guard that said it now says the precise thing
 * instead: SP-BROKEN is the only INTEGRITY break, and every other refusal is one of the
 * engine's own `bank_unmatched` payouts, refused on the deposit check alone.
 *
 * Derived from the export, not listed by hand, and pinned by tests/verifier.test.js to
 * the three ids above, so a fourth one arriving is a visible change and not a silent one.
 */
export function bankUnmatchedPayoutIds(engine) {
  return committedPayoutIds(engine).filter((id) => {
    const r = engine.reconciliations[id];
    return Boolean(r && Array.isArray(r.exceptions) && r.exceptions.some((e) => e && e.type === "bank_unmatched"));
  });
}
