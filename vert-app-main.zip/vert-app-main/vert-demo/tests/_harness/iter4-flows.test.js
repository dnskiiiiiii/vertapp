// tests/_harness/iter4-flows.test.js — THE ITERATION-4 FLOW GATE, HELD IN `npm test`
// ==============================================================================
// iter4-flows.mjs decides whether G4a-2's end-to-end run passed (§20.7 BV1–ST2, the §17.3
// click counts, NF-1st). A gate that cannot go red is a check that shares the defect, so
// each way a run can look green while a flow failed is constructed here and must score
// red; the product shape must score green. The run's own scorecards live in research
// (iter4/e2e/G4a-2/) and are scored by the CLI; this file needs none of them.

import test from "node:test";
import assert from "node:assert/strict";
import { FLOWS, REFERENCE_CLICKS, REQUIRED_CHECKS, scoreFlows } from "./iter4-flows.mjs";

function passing() {
  const checks = [];
  for (const f of FLOWS) {
    if (f === "§17.3") continue;
    checks.push({ flow: f, name: `${f} works`, ok: true });
    for (const need of REQUIRED_CHECKS[f] || []) checks.push({ flow: f, name: `the ${need} line`, ok: true });
  }
  const measures = {
    "st1.unattendedPosts": { value: 0 },
    "ay6.bridgeSumOffCents": { value: 0 },
    ...Object.fromEntries(Object.entries(REFERENCE_CLICKS).map(([k, v]) => [`clicks.${k}`, { value: v }])),
  };
  return { checks, measures };
}

const failing = (cards) => scoreFlows(cards).rows.filter((r) => r.verdict !== "PASS").map((r) => r.flow);

test("the product shape scores every flow PASS", () => {
  assert.deepEqual(failing([passing()]), []);
});

test("the reference click counts are W0r's: 3 presses each", () => {
  assert.deepEqual(REFERENCE_CLICKS, { import_budget: 3, schedule_start: 3, ask_bridge_drill: 3 });
});

const defects = [
  ["a flow that never ran is NOT RUN, and fails", (c) => { c.checks = c.checks.filter((x) => x.flow !== "AY7"); }, ["AY7"]],
  ["a deciding check that failed fails its flow", (c) => { c.checks.push({ flow: "ST2", name: "never after cancel", ok: false }); }, ["ST2"]],
  ["a click count above the reference fails §17.3", (c) => { c.measures["clicks.import_budget"].value = 4; }, ["§17.3"]],
  ["an unmeasured click count fails §17.3", (c) => { delete c.measures["clicks.schedule_start"]; }, ["§17.3"]],
  ["a click count given as text is not a count", (c) => { c.measures["clicks.ask_bridge_drill"].value = "3"; }, ["§17.3"]],
  ["one post without a press fails ST1", (c) => { c.measures["st1.unattendedPosts"].value = 1; }, ["ST1"]],
  ["an unmeasured post count fails ST1", (c) => { delete c.measures["st1.unattendedPosts"]; }, ["ST1"]],
  ["a bridge one cent off fails AY6", (c) => { c.measures["ay6.bridgeSumOffCents"].value = 1; }, ["AY6"]],
  ["NF-1st without its 'Scheduling isn't available here' line fails", (c) => { c.checks = c.checks.filter((x) => !/scheduling isn't available here/i.test(x.name)); }, ["NF-1st"]],
  ["BV1 without its 403 line fails", (c) => { c.checks = c.checks.filter((x) => !(x.flow === "BV1" && /403/.test(x.name))); }, ["BV1"]],
];

for (const [name, mutate, want] of defects) {
  test(`constructed defect: ${name}`, () => {
    const c = passing();
    mutate(c);
    assert.deepEqual(failing([c]), want);
  });
}

test("a failed polish line never decides a flow", () => {
  const c = passing();
  c.checks.push({ flow: "AY5", name: "polish: wording", ok: false });
  assert.deepEqual(failing([c]), []);
});

test("the worst copy counts when a check or a measure is recorded twice", () => {
  assert.deepEqual(failing([passing(), { checks: [{ flow: "BV2", name: "BV2 works", ok: false }] }]), ["BV2"]);
  assert.deepEqual(failing([passing(), { checks: [], measures: { "clicks.import_budget": { value: 9 } } }]), ["§17.3"]);
  // ...in either order: a later passing card never overwrites an earlier failing measure.
  assert.deepEqual(failing([{ checks: [], measures: { "clicks.import_budget": { value: 9 } } }, passing()]), ["§17.3"]);
});
