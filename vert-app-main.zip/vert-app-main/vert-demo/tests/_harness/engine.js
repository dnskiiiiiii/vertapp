// tests/_harness/engine.js — THE PAYLOAD EVERY TEST DERIVES FROM, NAMED ONCE
// ==============================================================================
// The engine payload used to be a module-scope constant that `lib/data.js` derived
// `PAYOUTS` / `PAYOUT_TXNS` / `PAYOUT_BANK` from, and a test imported those three
// names directly. It is a per-request value now (see lib/engine-server.js), so every
// derivation takes it as an argument and a test has to say which payload it means.
//
// This file says it once. `ENGINE` is `STATIC_ENGINE` — lib/engine-output.json, read
// through the one module allowed to read it — which is exactly what the app itself
// uses in the default static mode, so a test asserting over these feeds is asserting
// over the same objects the deployed showpiece renders.
//
// Nothing here fetches, and nothing here can: the suite runs with
// NEXT_PUBLIC_VERT_API_URL unset and tests/engine-source.test.js asserts that.

import { STATIC_ENGINE } from "../../lib/engine-source.js";
import { feedsFor } from "../../lib/feeds.js";

export const ENGINE = STATIC_ENGINE;

export const { PAYOUTS, PAYOUT_TXNS, PAYOUT_BANK } = feedsFor(ENGINE);
