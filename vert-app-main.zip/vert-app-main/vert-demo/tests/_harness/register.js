// tests/_harness/register.js — install the loader hooks, once, synchronously.
// Every test file's FIRST import. `registerHooks` (Node >=22.15) is synchronous
// and in-thread, so the hooks are live before the static imports that follow in
// the importing module are resolved.
import { registerHooks } from "node:module";
import { load, resolve } from "./loader.js";

registerHooks({ resolve, load });
