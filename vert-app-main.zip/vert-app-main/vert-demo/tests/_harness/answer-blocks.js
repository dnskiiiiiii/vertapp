// tests/_harness/answer-blocks.js — AN ANSWER'S DIRECT VISIBLE CHILDREN, WITH NO DOM
// ==============================================================================
// The walker tests/chat-answer-shape.test.js counts the answer's blocks with (Q05 AN9:
// "≤ 4 visible blocks"), shared so the engine-shape tests count them the same way.

const VOID = new Set(["area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr"]);

/** The opening tags of the direct children of the first element whose tag matches `open`. */
export function directChildren(html, open) {
  const m = open.exec(html);
  if (!m) throw new Error(`no element matches ${open}`);
  const re = /<(\/?)([a-zA-Z][\w-]*)\b[^>]*?(\/?)>/g;
  re.lastIndex = m.index + m[0].length;
  const out = [];
  let depth = 0;
  for (let t = re.exec(html); t; t = re.exec(html)) {
    const [tag, closing, name, selfClosing] = t;
    if (closing) {
      if (depth === 0) return out;
      depth -= 1;
      continue;
    }
    if (depth === 0) out.push(tag);
    if (!selfClosing && !VOID.has(name.toLowerCase())) depth += 1;
  }
  return out;
}

/** The visible direct children of the LAST answer in `html`. */
export function lastAnswerBlocks(html) {
  const open = () => /<div class="chat-answer" data-message="assistant_text"[^>]*>/g;
  const re = open();
  let last = null;
  for (let m = re.exec(html); m; m = re.exec(html)) last = m.index;
  if (last === null) throw new Error("no answer was drawn");
  return directChildren(html.slice(last), open()).filter((tag) => !/\shidden(=|\s|>)/.test(tag));
}
