// tests/_harness/mutate.mjs — RESTORE A MUTATED FILE FROM A BACKUP, NEVER FROM GIT
// ==============================================================================
// WHAT THIS IS FOR. Thirteen guards in this suite have been found blind to their own
// subject, and every one was found the same way: put back the thing the guard forbids,
// run the guard, and watch it pass. That procedure — mutate, run, restore — is how this
// project proves a test can fail, and it is run dozens of times a round.
//
// WHY IT IS NOT `git checkout --`. Rounds 10 and 11 drove that loop by editing a source
// file and then running `git checkout -- <path>` to put it back, and TWICE it silently
// destroyed uncommitted work that had nothing to do with the mutation. `git checkout --`
// does not restore what was there a second ago; it restores what is in the index. If the
// file carried an unstaged edit — a half-written fix, a comment being drafted, a test
// being added — that edit is gone, with no diff, no reflog entry and no message. A tool
// whose job is to verify the work must not be able to delete the work.
//
// THE RULE HERE: the ONLY thing that ever restores a file is a byte-for-byte copy this
// process took immediately before mutating it. Git is never invoked. The backup lives in
// a directory this process owns, the restore runs in a `finally`, on every fatal signal,
// and on an uncaught throw, and the restore is VERIFIED by hash before the process is
// allowed to report success. If a restore cannot be verified, the exit code is non-zero
// and the message names the backup path so a human can put it back by hand.
//
//   node tests/_harness/mutate.mjs <spec.json>
//   node tests/_harness/mutate.mjs --self-test
//
// A spec is a JSON array of mutations:
//
//   [{ "name": "...",              // what is being put back, in words
//      "file": "lib/store.js",     // ROOT-relative, one file (or "files": [...])
//      "find": "…", "replace": "…",// literal, must occur exactly once
//      "test": "tests/gates.test.js",
//      "expect": "fail" }]         // "fail" = the guard MUST go red under the mutation
//
// `expect: "fail"` is the normal case and the whole point: a mutation that leaves the
// suite green is a guard that cannot see its own subject, and this harness reports that
// as SURVIVED rather than as a pass.

import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");

const sha = (buf) => createHash("sha256").update(buf).digest("hex");

/**
 * Hold the exact bytes of a set of files, and put them back on demand.
 *
 * The backup is BOTH in memory and on disk. In memory is what the restore uses, so a
 * restore works even if the temp directory has been swept out from under it; on disk is
 * the copy a human can reach for if this process dies in a way that runs no handler at
 * all (SIGKILL, a power loss). Neither is git, which is the point.
 */
/* ── WHERE THE PARKED COPY LIVES, AND WHY IT MOVED INTO THE REPO ─────────────
 *
 * FOUND 2026-08-31, by being on the receiving end of it. A `mutate.mjs` run was killed
 * mid-cycle. It left components/ai-rail/ContextDrop.js carrying R24-H's mutation, and
 * the backup was GONE — nothing under `tests/_harness/`, nothing under the system temp
 * directory. The header above claims the on-disk copy is "the copy a human can reach
 * for if this process dies in a way that runs no handler at all". That claim had never
 * been true in the case it names: the copy lived in `mkdtemp` under `tmpdir()`, so its
 * name was random and nothing printed it unless a restore had already failed, and no
 * later run looked for it. The only reason the tree was repaired is that the spec still
 * held the `find`/`replace` pair, so the mutation could be reversed by hand.
 *
 * negative-anchor.mjs solved exactly this on 2026-08-30 and said why, at length: "IN
 * THE REPO, NOT IN A TEMP DIRECTORY WITH A RANDOM NAME. A human coming back to a
 * mutated tree has to be able to FIND this without knowing what it is called, and the
 * next probe run has to find it without being told." This file borrowed the "both in
 * memory and on disk" half of that design and not the half that makes the disk copy
 * reachable. Two tools, one hazard, one of them fixed.
 *
 * So the park directory is `tests/_harness/.mutate-pending`, it is `.gitignore`d, and
 * `recoverPending()` runs before any mutation on every invocation — including
 * `--self-test`, because a tree left mutated makes every result below meaningless.
 */
const PENDING = path.join(ROOT, "tests", "_harness", ".mutate-pending");

/** Put back anything a previous run left mutated, and say so. Silent when clean. */
export function recoverPending(dir = PENDING) {
  if (!existsSync(dir)) return [];
  const recovered = [];
  for (const f of readdirSync(dir).filter((n) => n.endsWith(".orig"))) {
    const rel = f.slice(0, -".orig".length).replace(/__/g, "/");
    const abs = path.join(ROOT, rel);
    const bytes = readFileSync(path.join(dir, f));
    try {
      if (!existsSync(abs) || !readFileSync(abs).equals(bytes)) {
        writeFileSync(abs, bytes);
        recovered.push(rel);
      }
    } catch {
      /* a file that cannot be written is reported by the caller, not swallowed here */
    }
  }
  rmSync(dir, { recursive: true, force: true });
  return recovered;
}

export class Backup {
  constructor(relPaths, dir = PENDING) {
    this.dir = dir;
    this.entries = relPaths.map((rel) => {
      const abs = path.join(ROOT, rel);
      const bytes = readFileSync(abs);
      const copy = path.join(dir, `${rel.replace(/[\\/]/g, "__")}.orig`);
      mkdirSync(path.dirname(copy), { recursive: true });
      copyFileSync(abs, copy);
      return { rel, abs, bytes, hash: sha(bytes), copy };
    });
    this.restored = false;
  }

  /** Put every file back byte-for-byte and PROVE it. Safe to call more than once. */
  restore() {
    const failures = [];
    for (const e of this.entries) {
      try {
        writeFileSync(e.abs, e.bytes);
        const now = sha(readFileSync(e.abs));
        if (now !== e.hash) failures.push(`${e.rel}: hash ${now} != ${e.hash}`);
      } catch (err) {
        failures.push(`${e.rel}: ${err.message}`);
      }
    }
    this.restored = failures.length === 0;
    if (failures.length) {
      // Never swallow this. The backup path is in the message because at this point a
      // human putting the file back by hand is the remaining recovery.
      const where = this.entries.map((e) => `  ${e.rel}  <-  ${e.copy}`).join("\n");
      throw new Error(
        `RESTORE FAILED — the working tree may still hold a mutation.\n` +
          `${failures.join("\n")}\n` +
          `The untouched originals are on disk here; copy them back by hand:\n${where}`
      );
    }
    return true;
  }

  /** Drop the on-disk copies. Only ever called after a verified restore. */
  discard() {
    if (!this.restored) return; // keep the evidence
    rmSync(this.dir, { recursive: true, force: true });
  }
}

/**
 * Run `fn` with `files` mutated, and restore them no matter how it ends.
 *
 * The restore is wired to `finally` AND to the fatal signals, because the loop this
 * serves is one a person interrupts with ctrl-C when a test hangs — and an interrupt
 * that leaves a mutation in the tree is exactly the silent corruption this file exists
 * to prevent.
 */
export function withMutation(edits, fn) {
  const backup = new Backup(edits.map((e) => e.file));
  let onSignal = null;
  try {
    onSignal = (sig) => {
      try {
        backup.restore();
      } finally {
        process.removeAllListeners(sig);
        process.kill(process.pid, sig);
      }
    };
    for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) process.on(sig, onSignal);

    for (const edit of edits) {
      const abs = path.join(ROOT, edit.file);
      const before = readFileSync(abs, "utf8");
      const occurrences = before.split(edit.find).length - 1;
      if (occurrences !== 1) {
        throw new Error(
          `${edit.file}: the text to mutate occurs ${occurrences} times, expected exactly 1.\n` +
            `A mutation that lands in the wrong place, or in no place, proves nothing.\n` +
            `  looking for: ${JSON.stringify(edit.find)}`
        );
      }
      writeFileSync(abs, before.replace(edit.find, edit.replace));
    }
    return fn();
  } finally {
    if (onSignal) for (const sig of ["SIGINT", "SIGTERM", "SIGHUP"]) process.off(sig, onSignal);
    backup.restore();
    backup.discard();
  }
}

/** Run one test file. Returns { pass, fail, ok, output }. Never throws on a red suite. */
export function runTest(testPath) {
  let output = "";
  let ok = true;
  try {
    output = execFileSync(
      process.execPath,
      ["--import", "./tests/_harness/register.js", "--test", testPath],
      { cwd: ROOT, encoding: "utf8", stdio: ["ignore", "pipe", "pipe"] }
    );
  } catch (err) {
    ok = false;
    output = `${err.stdout || ""}${err.stderr || ""}`;
  }
  const num = (label) => {
    const m = output.match(new RegExp(`^# ?${label} (\\d+)$`, "m")) || output.match(new RegExp(`${label} (\\d+)`));
    return m ? Number(m[1]) : null;
  };
  return { ok, pass: num("pass"), fail: num("fail"), output };
}

/** The whole loop for one spec entry. */
export function driveMutation(m) {
  const edits = m.files || [{ file: m.file, find: m.find, replace: m.replace }];
  const result = withMutation(edits, () => runTest(m.test));
  const wanted = m.expect === "pass";
  const caught = !result.ok;
  return {
    name: m.name,
    test: m.test,
    caught,
    survived: wanted ? false : !caught,
    pass: result.pass,
    fail: result.fail,
    output: result.output,
  };
}

/* ------------------------------------------------------------------ *
 * CLI                                                                 *
 * ------------------------------------------------------------------ */
function main(argv) {
  // BEFORE ANYTHING ELSE, INCLUDING BEFORE `--self-test`. A tree left mutated by a run
  // that died without a handler makes every result below meaningless — the suite would
  // be judging a sentinel. See the block above `Backup`.
  const recovered = recoverPending();
  for (const rel of recovered) {
    console.error(`recovered ${rel} — a previous mutation run was interrupted mid-cycle`);
  }
  if (argv.includes("--self-test")) return selfTest();
  const specPath = argv.find((a) => !a.startsWith("--"));
  if (!specPath) {
    console.error("usage: node tests/_harness/mutate.mjs <spec.json> | --self-test");
    return 2;
  }
  const spec = JSON.parse(readFileSync(specPath, "utf8"));
  const results = [];
  for (const m of spec) {
    const r = driveMutation(m);
    results.push(r);
    const verdict = r.survived ? "SURVIVED" : "caught";
    console.log(`${verdict.padEnd(9)} ${r.name}  [${r.test}]  pass=${r.pass} fail=${r.fail}`);
    if (r.survived) console.log(r.output.split("\n").slice(-12).join("\n"));
  }
  const survivors = results.filter((r) => r.survived);
  console.log(`\n${results.length - survivors.length}/${results.length} mutations caught.`);
  if (survivors.length) {
    console.log(`SURVIVED — these guards cannot see their own subject:`);
    for (const s of survivors) console.log(`  ${s.name}  [${s.test}]`);
  }
  return survivors.length ? 1 : 0;
}

/**
 * The property that matters, checked against the real filesystem: an UNCOMMITTED edit
 * survives a mutation cycle. This is the exact thing `git checkout --` destroyed twice.
 */
function selfTest() {
  const rel = "tests/_harness/.mutate-self-test.tmp";
  const abs = path.join(ROOT, rel);
  const uncommitted = "uncommitted work nobody has staged\n";
  writeFileSync(abs, uncommitted);
  try {
    withMutation([{ file: rel, find: "uncommitted", replace: "MUTATED" }], () => {
      const during = readFileSync(abs, "utf8");
      if (!during.startsWith("MUTATED")) throw new Error("the mutation was not applied");
    });
    const after = readFileSync(abs, "utf8");
    if (after !== uncommitted) {
      console.error(`SELF-TEST FAILED: restored ${JSON.stringify(after)}, expected ${JSON.stringify(uncommitted)}`);
      return 1;
    }
    // And it restores through a throw, which is when a real run most often ends.
    try {
      withMutation([{ file: rel, find: "uncommitted", replace: "MUTATED" }], () => {
        throw new Error("the test blew up");
      });
    } catch {
      /* expected */
    }
    if (readFileSync(abs, "utf8") !== uncommitted) {
      console.error("SELF-TEST FAILED: a throw left the mutation in the tree");
      return 1;
    }
    console.log("self-test ok — an uncommitted edit survives a mutation cycle, and a throw restores it too");
    return 0;
  } finally {
    rmSync(abs, { force: true });
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  process.exit(main(process.argv.slice(2)));
}
