// Inert stand-in for `next/cache`. `revalidatePath` only means anything inside a
// Next request — it tells the router which cached segments to discard after a write.
// The Server Actions in lib/actions.js call it on success; a gate test that renders a
// component which merely IMPORTS that module must not be a Next.js integration test.
//
// It is a no-op and not a spy on purpose: nothing in this suite asserts that a
// revalidation happened. What a write does is asserted against the API contract in
// tests/writes.test.js, over lib/engine-source.js postToApi, which is the only place
// a request is actually formed.
export function revalidatePath() {}
export function revalidateTag() {}
export function unstable_cache(fn) {
  return fn;
}
