// Inert stand-in for `next/link`. Outside a Next.js request `next/link` drags in
// the router, prefetching and app-router context — none of which any gate under
// test depends on. It renders as the anchor it becomes anyway, so markup
// assertions still see a real <a href>.
import { jsx } from "react/jsx-runtime";

export default function Link({ href, children, ...rest }) {
  return jsx("a", { href: typeof href === "string" ? href : "#", ...rest, children });
}
