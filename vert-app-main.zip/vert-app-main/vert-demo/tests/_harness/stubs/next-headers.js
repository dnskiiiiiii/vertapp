// Inert stand-in for `next/headers`.
//
// Reached because lib/actions.js and lib/engine-server.js import lib/session.js, which
// reads the session cookie through `cookies()`. A gate test that renders a component
// whose module graph merely TOUCHES that import must not become a Next.js integration
// test — the same reason next-cache.js and next-navigation.js exist.
//
// AN EMPTY COOKIE JAR IS THE HONEST STAND-IN, AND IT IS THE SAFE ONE.
//
// With no cookie, `readSession()` returns null and `authHeaders()` returns null, so
// any test that accidentally exercised a code path expecting a credential gets the
// ANONYMOUS behaviour rather than a fabricated signed-in one. That is the right way
// round: a stub that handed out a fake session would let a test pass while asserting
// something about a session this suite never established, which is how a gate test
// starts covering a fiction.
//
// The session's own properties — sealing, expiry, tampering — are asserted in
// tests/session.test.js against lib/session-seal.js, which imports nothing from Next
// and therefore needs no stub at all. That split is deliberate: the security logic
// lives in the module a test can import for real.

const EMPTY_JAR = {
  get() {
    return undefined;
  },
  getAll() {
    return [];
  },
  has() {
    return false;
  },
  // Writes are refused loudly rather than silently swallowed. A test that reached a
  // sign-in or sign-out path would otherwise appear to succeed while setting nothing,
  // and the message says where the real coverage is.
  set() {
    throw new Error(
      "tests/_harness/stubs/next-headers.js: a cookie was set during a test. Session " +
        "writes belong to a real request — assert them against lib/session-seal.js in " +
        "tests/session.test.js, or drive the running app."
    );
  },
  delete() {
    throw new Error(
      "tests/_harness/stubs/next-headers.js: a cookie was deleted during a test. See set()."
    );
  },
};

export async function cookies() {
  return EMPTY_JAR;
}

export async function headers() {
  return new Headers();
}

export async function draftMode() {
  return { isEnabled: false, enable() {}, disable() {} };
}
