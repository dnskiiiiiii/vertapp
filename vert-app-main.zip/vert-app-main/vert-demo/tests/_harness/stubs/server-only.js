// Inert stand-in for the `server-only` package.
//
// `lib/session.js` opens with `import "server-only"` — a real guard, and one worth
// keeping: that module unseals a live API key, and the failure it prevents (a client
// component importing it, the bundler including it, the credential shipping to a
// browser) is silent. In `next build` the package resolves to a module that throws if
// it is ever pulled into a client bundle, which is exactly the build error wanted.
//
// Under `node --test` there is no client bundle and no bundler, so the guard has
// nothing to guard and the real package is not installed (it arrives with Next's own
// dependency tree, not the app's). Stubbing it to nothing keeps the module importable
// here WITHOUT weakening it where it matters: the import statement stays in the
// source, so the real build still enforces it.
//
// Stated plainly because it is the shape of thing that deserves suspicion: this does
// not disable a check to make a test pass. The check runs at bundle time, this suite
// does not bundle, and removing the import from lib/session.js to satisfy Node would
// have been the version that weakened something.
