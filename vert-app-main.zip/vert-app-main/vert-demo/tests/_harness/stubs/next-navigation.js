// Inert stand-in for `next/navigation`. `usePathname()` reads app-router context
// that only exists inside a Next request; a component that only uses it to mark
// the active tab must not be the reason a gate test cannot run.
export function usePathname() {
  return "/payouts";
}
export function useSearchParams() {
  return new URLSearchParams();
}
export function useRouter() {
  return { push() {}, replace() {}, back() {}, forward() {}, refresh() {}, prefetch() {} };
}
export function redirect(url) {
  throw new Error(`redirect(${url})`);
}

// `unstable_rethrow` is Next's "is this error mine? then give it back" predicate. The
// real one recognises redirects, not-found, the static-generation bail-out and a few
// private prerender signals, and rethrows those while letting every other error fall
// through to the caller's catch.
//
// The stub mirrors that contract for the one signal this suite can actually produce —
// `redirect()` above, which throws a plain Error whose message starts "redirect(". A
// genuine data-source failure must fall straight through, because that is the whole
// property the callers depend on: `lib/engine-source.js` and `lib/engine-server.js`
// call this FIRST in their catch blocks, and if it swallowed real errors it would turn
// an unreachable API into an unhandled throw.
export function unstable_rethrow(error) {
  const digest = error && typeof error === "object" ? error.digest : null;
  const isNextSignal =
    (typeof digest === "string" && (digest.startsWith("NEXT_") || digest === "DYNAMIC_SERVER_USAGE")) ||
    (error instanceof Error && /^redirect\(/.test(error.message));
  if (isNextSignal) throw error;
}
