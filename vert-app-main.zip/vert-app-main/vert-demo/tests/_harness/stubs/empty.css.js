// A stylesheet import is a bundler affordance, not a module. Nothing under test
// reads a class name back out of CSS, so an empty module is the whole truth.
export default {};
