// Stand-in for `next/server` — the minimum `proxy.js` actually uses.
//
// NOT inert, unlike the other stubs in this directory. next-link.js and
// next-cache.js exist so that a component which merely IMPORTS a Next module can be
// rendered; this one exists so that `proxy.js` can be CALLED, and its answers
// inspected. The proxy is the sign-in gate — it decides whether an anonymous request
// reaches a customer's close or the sign-in screen, and whether an aged session is
// let through — and a gate nothing exercises is the shape of defect this repo has
// shipped repeatedly.
//
// So the two things a test needs to read are modelled honestly:
//
//   · what kind of response it is — a pass-through (`next`) or a redirect, and to
//     where;
//   · what it did to the session cookie — set, cleared, or left alone.
//
// Everything else Next puts on NextResponse is absent on purpose. A fuller fake would
// be a fake of a framework, which is a thing to maintain and be wrong about; if the
// proxy starts using more of the API, this file should grow one method at a time and
// each addition should be visible in a diff.

class ResponseCookies {
  constructor() {
    this.entries = new Map();
  }
  set(name, value, options = {}) {
    this.entries.set(name, { name, value, ...options });
    return this;
  }
  get(name) {
    return this.entries.get(name);
  }
  delete(name) {
    this.entries.delete(name);
    return this;
  }
}

class FakeResponse {
  constructor(kind, destination = null, init = undefined) {
    /** "next" (pass the request through) or "redirect". */
    this.kind = kind;
    /** A URL for a redirect, null otherwise. */
    this.destination = destination ? String(destination) : null;
    this.cookies = new ResponseCookies();
    this.status = kind === "redirect" ? 307 : 200;
    /**
     * The REQUEST headers the proxy rewrote on its way through, as a plain object.
     *
     * Grown here — one method at a time, as this file's header asks — because
     * `NextResponse.next({ request: { headers } })` is how the proxy tells the root
     * layout that a request is for a public legal document, and a test that could not
     * read it would be asserting the proxy "passed the request through" while the
     * thing being passed was the part that mattered. Empty for an ordinary
     * pass-through, which is what every other caller produces.
     */
    this.requestHeaders = {};
    const headers = init?.request?.headers;
    if (headers) {
      for (const [k, v] of headers.entries()) this.requestHeaders[k.toLowerCase()] = v;
    }
  }
}

export const NextResponse = {
  next(init) {
    return new FakeResponse("next", null, init);
  },
  redirect(url) {
    return new FakeResponse("redirect", url);
  },
};

/**
 * A request shaped the way `proxy.js` reads one: `nextUrl` (a real URL, so `.clone()`
 * and `.protocol` behave), `cookies.get(name)`, and `headers.get(name)`.
 *
 * Exported from the stub rather than written in the test file so there is one
 * definition of "what the proxy is handed" — the proxy reading a field this does not
 * provide should fail loudly here rather than being quietly undefined in one case.
 */
export function makeRequest(url, { cookies = {}, headers = {} } = {}) {
  const parsed = new URL(url);
  // `clone()` is what the proxy calls before rewriting pathname/search.
  parsed.clone = () => {
    const copy = new URL(parsed.href);
    copy.clone = parsed.clone;
    return copy;
  };
  // A REAL `Headers`, not a `{ get }` shape. `.get()` behaves identically — which is
  // all the basic-auth branch ever wanted — but the proxy also does
  // `new Headers(request.headers)` to copy the set before adding one, and that
  // constructor needs something iterable. A hand-rolled object satisfied the reads and
  // threw on the copy, which is precisely the "quietly undefined in one case" this
  // helper's docstring exists to prevent.
  return {
    nextUrl: parsed,
    cookies: {
      get(name) {
        return name in cookies ? { name, value: cookies[name] } : undefined;
      },
    },
    headers: new Headers(headers),
  };
}

/**
 * `connection()` — Next's "this render needs a real request" signal.
 *
 * A NO-OP HERE, AND THAT IS THE HONEST MODEL. In the app it throws a control-flow
 * signal during PRERENDERING and does nothing at all during a real request; nothing
 * in this harness prerenders, so "does nothing" is the branch every test is in.
 * Grown one method at a time, as this file's header asks: `lib/engine-server.js`
 * awaits it at the top of every read, so a test that drives `readChartGaps` against
 * a stubbed API cannot import the module without it.
 */
export async function connection() {}
