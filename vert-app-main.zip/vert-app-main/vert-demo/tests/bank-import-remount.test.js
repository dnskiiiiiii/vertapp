// tests/bank-import-remount.test.js — A NEW UPLOAD MUST BE A NEW FORM
// ==============================================================================
// `BankStatementMapping` seeds its answers ONCE, from the service's proposal, with a
// `useState` initialiser. React reuses a component instance across renders of the
// same position, so without a key a SECOND upload keeps the FIRST upload's answers —
// and if the first was seeded before a proposal existed, every dropdown stays blank
// while the sentence underneath reads "Proposed by the service: Date".
//
// Reported from the deployed site: seven fields to pick by hand, all of which the
// service had already worked out. That is the difference between a form a merchant
// accepts and a form a merchant fills in, and it is the kind of thing that decides
// whether somebody finishes an import at all.
//
// Asserted structurally, over the source, because the failure is about component
// IDENTITY across renders and the render harness produces static HTML — it has no
// second render to reuse an instance across. This codebase already scans its own
// source for claims of exactly this shape (tests/_harness/source.js).

import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";

const SRC = readFileSync(
  new URL("../components/settings/BankStatementImport.js", import.meta.url),
  "utf8"
);

test("the mapping form is keyed on the inspection it is for", () => {
  const mount = SRC.match(/<BankStatementMapping[\s\S]*?\/>/);
  assert.ok(mount, "the import screen must still render the mapping form");
  assert.match(
    mount[0],
    /key=\{[^}]*inspectionId[^}]*\}/,
    "without a key on the inspection id, a second upload reuses the first upload's " +
    "state and the proposal is never applied — every dropdown renders blank"
  );
});

test("the form still receives the inspection and the file name", () => {
  // A key that replaced a prop would be a different bug with the same symptom.
  const mount = SRC.match(/<BankStatementMapping[\s\S]*?\/>/)[0];
  assert.match(mount, /inspection=\{/);
  assert.match(mount, /fileName=\{/);
});
