// tests/bank-rec-receipts.test.js — A RECEIPT ON THE BANK LINE IT PAYS
// ==============================================================================
// Close list step 1 "supplier/customer receipts" (29 Oct 2026): on a bank rec or cash
// coding line, "Attach receipt" uploads a file or picks one Vert holds and files it against
// the bank line (`POST /documents/{id}/links {targetKind: "bank_line", targetId: row.id}`).
// The engine lists a line's receipts as `receipts: [{documentId, name}]`; the line shows
// them, and says they are kept in Vert, not in Xero, until Vert may write bank transactions.
// Recording expenses (card reimbursements, petty cash) goes through the same coding, and
// expense claims are said to be out of reach in words.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { render, textOf } from "./_harness/render.js";
import { ROOT, read } from "./_harness/source.js";
import BankRecRows from "../components/chat/answer/BankRecRows.js";
import { bankRecOf, receiptsOf } from "../components/chat/answer/bank-rec.js";

const FIX = JSON.parse(readFileSync(path.join(ROOT, "tests", "fixtures", "bank-rec-shape.json"), "utf8"));
const WITH = FIX.withStatement;
const DOC = "0b6f0b2e-5a8f-4d8e-9a77-3c1f4e2a9b10";

/** The fixture with `receipts` laid on rows by id. */
function withReceipts(byRow, extra = {}) {
  return {
    ...WITH,
    sections: WITH.sections.map((s) => ({ ...s, rows: s.rows.map((r) => (byRow[r.id] ? { ...r, receipts: byRow[r.id], ...(extra[r.id] || {}) } : { ...r, ...(extra[r.id] || {}) })) })),
  };
}

// Product copy is set with curly apostrophes (tests/design-fix-2.test.js); compared straight.
const straight = (t) => t.replace(/\u2019/g, "'");

function rowHtml(html, rowId) {
  const at = html.indexOf(`data-row="${rowId}"`);
  assert.ok(at >= 0, `no row ${rowId}`);
  const start = html.lastIndexOf('class="bankrec-row"', at);
  const next = html.indexOf('class="bankrec-row"', at);
  return html.slice(start, next < 0 ? html.length : next);
}

test("a row's receipts are the engine's documents, and nothing else", () => {
  assert.deepEqual(receiptsOf([{ documentId: DOC, name: "officeworks.pdf" }, { documentId: "nope", name: "x" }, { documentId: DOC }, null]), [{ documentId: DOC, name: "officeworks.pdf" }]);
  assert.deepEqual(receiptsOf(undefined), []);
  const view = bankRecOf(withReceipts({ "csv:e:5": [{ documentId: DOC, name: "officeworks.pdf" }] }));
  const row = view.sections.flatMap((s) => s.rows).find((r) => r.id === "csv:e:5");
  assert.deepEqual(row.receipts, [{ documentId: DOC, name: "officeworks.pdf" }]);
});

test("a line with a receipt shows it, opening the file, and says it's kept in Vert", () => {
  const html = render(BankRecRows, { bankRec: withReceipts({ "csv:e:5": [{ documentId: DOC, name: "officeworks.pdf" }] }), ledgerName: "Xero" });
  const row = rowHtml(html, "csv:e:5");
  const text = straight(textOf(row));
  assert.ok(text.includes("officeworks.pdf"));
  assert.match(row, new RegExp(`href="/api/documents/${DOC}/file"`));
  assert.ok(text.includes("Kept in Vert. Not attached in Xero yet: Vert doesn't write bank transactions to Xero until that permission is granted."));
});

test("every bank line offers Attach receipt, without adding a button to the row", () => {
  const html = render(BankRecRows, { bankRec: WITH, ledgerName: "Xero" });
  const row = rowHtml(html, "csv:e:6");
  assert.ok(textOf(row).includes("Attach receipt"));
  // A disclosure's summary, so the rows' own presses (Approve, Change, Copy) stay the only buttons.
  assert.match(row, /<summary[^>]*>[\s\S]*Attach receipt/);
  // A line that is not on the statement has no bank line to file against.
  const notOn = rowHtml(html, "x:u2");
  assert.ok(!textOf(notOn).includes("Attach receipt"));
});

test("a superseded run shows receipts but offers no attach", () => {
  // Folded until asked for (founder's walk, 8 Nov 2026); opened, its rows are read-only.
  const folded = render(BankRecRows, { bankRec: withReceipts({ "csv:e:5": [{ documentId: DOC, name: "officeworks.pdf" }] }), ledgerName: "Xero", superseded: { seq: 4 } });
  assert.ok(!textOf(folded).includes("officeworks.pdf"), "an earlier run's rows are folded");
  assert.match(textOf(folded), /An earlier run, redone below/);
  const html = render(BankRecRows, { bankRec: withReceipts({ "csv:e:5": [{ documentId: DOC, name: "officeworks.pdf" }] }), ledgerName: "Xero", superseded: { seq: 4 }, initial: { showEarlier: true } });
  const row = rowHtml(html, "csv:e:5");
  assert.ok(textOf(row).includes("officeworks.pdf"));
  assert.ok(!textOf(row).includes("Attach receipt"));
});

test("the receipt is filed against the bank line, through the engine's links route", () => {
  const src = read("lib/documents.js");
  const at = src.indexOf("export async function attachToBankLine");
  assert.ok(at >= 0, "no attachToBankLine");
  const body = src.slice(at, src.indexOf("\n}\n", at));
  assert.match(body, /\/documents\/\$\{encodeURIComponent\(documentId\)\}\/links/);
  assert.match(body, /targetKind: "bank_line"/);
  assert.match(body, /targetId: lineId/);
  // The row's press reads Vert's files with a GET, never a Server Action on arrival.
  const rows = read("components/chat/answer/BankRecRows.js");
  assert.match(rows, /fetch\("\/api\/documents"/);
});

test("an approved coding doesn't repeat the expenses note on its row", () => {
  const FIELDS = [{ label: "Bank account", value: "1010 Everyday" }, { label: "Transaction", value: "Spend Money" }, { label: "Amount", value: "65.50", amountCents: 6550 }];
  const settled = { id: "a-1", kind: "coding_approve", state: "settled", outcome: "approved", words: "Approved: enter these in {{ledger}}", fields: FIELDS };
  const html = render(BankRecRows, { bankRec: withReceipts({}, { "csv:e:5": { decision: settled } }), ledgerName: "Xero" });
  const text = straight(textOf(html));
  // Founder, 8 Nov 2026: the two-paragraph note was printed under every approved line.
  assert.ok(!text.includes("Card reimbursements and petty cash: code them here"));
  assert.ok(!text.includes("Employee expense claims: Vert can't read or create"));
  // The row still says what it did, and its fields are one press away.
  assert.ok(text.includes("Approved: enter these in Xero"));
  assert.ok(text.includes("Fields to enter"));
});
