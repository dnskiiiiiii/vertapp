// tests/bank-import.test.js — A FIELD THE SERVER WOULD NOT GUESS IS A QUESTION,
// NEVER A DEFAULT
// ==============================================================================
// This is the single most important behaviour on the settings screen, and it is worth
// saying why in figures rather than in principle. A statement CSV has columns like
// `Debit`, `Credit`, `Amount`, `Balance`. Pick `Balance` as the amount column and
// every line imports: the file parses, the dates are fine, the descriptions are fine,
// the numbers are plausible money. What follows is a bank statement that is
// confidently wrong — and the deposit tie is an exact integer comparison, so every
// payout either fails to match (a refusal, which is survivable) or matches the wrong
// deposit (which is not). Nothing downstream can detect it, because nothing
// downstream has the file.
//
// The server therefore proposes what it can and stays silent where it cannot, and the
// silence is load-bearing. THE CLAIMS:
//
//   1. WHERE THE SERVER PROPOSED NOTHING, NOTHING IS SELECTED and the control says
//      "You must choose" in words. Asserted on the real rendered markup, by finding
//      which <option> carries `selected` — the browser's own answer to "what would be
//      submitted if this were sent now".
//   2. WHERE IT DID PROPOSE, the proposal is selected AND labelled as a proposal, so
//      a person knows a machine read it and can overrule it.
//   3. A PROPOSAL THAT IS NOT A REAL COLUMN IS NOT A PROPOSAL — otherwise the control
//      falls back to its first option, silently, which is the same defect by another
//      route.
//   4. THE SIGN CONVENTION AND THE CURRENCY ARE NEVER PROPOSED, whatever the server
//      sends, because neither is knowable from a file.
//   5. THE SIGN CONVENTION IS ECHOED IN ENGLISH before the confirm button.
//   6. THE CONFIRM WILL NOT SUBMIT while anything is unstated, and says which.
//   7. BOTH NUMBERS ON SUCCESS; THE REMEDY AND THE ROW NUMBER ON A REFUSAL.
//
// MUTATION-CHECKED. Claim 1 was verified by deleting the refusal — making
// `mappingChoices` fall back to the first column when the server proposed nothing —
// and confirming that the tests below go red. See the report in the commit.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { render, textOf } from "./_harness/render.js";
import { read, stripComments } from "./_harness/source.js";

import {
  CURRENCIES,
  DATE_FORMATS,
  EXPIRED_CODE,
  MAPPING_FIELDS,
  NOT_CONFIRMED_CODE,
  confirmBody,
  confirmFormData,
  importGate,
  importGateView,
  importRefusal,
  importRefusalLine,
  importRefusalReason,
  importedLine,
  initialMapping,
  inspectionSummary,
  mappingChoices,
  mappingComplete,
  reviewInForce,
  signConventionSentence,
  unstatedFields,
} from "../lib/bank-import.js";
import BankStatementMapping from "../components/settings/BankStatementMapping.js";
import BankImportGate from "../components/settings/BankImportGate.js";
import BankImportOutcome, { ImportRefusal, importFailureView, isOperatorText } from "../components/settings/BankImportOutcome.js";

/* ══════════════════════════════════════════════════════════════════════════ *
 * Fixtures, shaped exactly as spec §3.8 pins POST /bank-statements.
 * ══════════════════════════════════════════════════════════════════════════ */

// The file that makes the problem real: FOUR plausible money columns and a server
// that will not choose between them. `Balance` is the trap — it parses, it is money,
// and it is the running total rather than the transaction.
const COLUMNS = ["Date", "Narration", "Debit", "Credit", "Amount", "Balance"];

// THE PROPOSAL IS KEYED AS THE CONFIRM BODY IS KEYED, and `date_format` is a strftime
// format. Both of those are the service's actual wire, verified by curl against a
// running vert_connect on 2026-08-14:
//
//   "proposal": {"date_column": "Date", "description_column": "Description",
//                "amount_column": "Amount", "date_format": null}
//
// These fixtures previously carried `{date, description, amount}` and "DD/MM/YYYY",
// which is an earlier draft the service withdrew — its own module docstring gives the
// reason: "a rename a client gets wrong is a mapping stated against the wrong column".
// A fixture in the withdrawn shape is a test that passes against a client that can
// never read a real proposal, which is exactly what was shipped.
const AMBIGUOUS = {
  inspection_id: "insp_9f2c",
  columns: COLUMNS,
  row_count: 1184,
  // NO `amount_column`. The server read the file and refused to pick between Debit,
  // Credit, Amount and Balance — which is the correct answer, and the whole reason
  // this screen exists in this shape. `date_format` is null for the same reason: the
  // dates parse equally well two ways and only the bank can say which.
  proposal: { date_column: "Date", description_column: "Narration", date_format: "%d/%m/%Y" },
  accepted_currencies: ["AUD", "NZD", "USD", "GBP", "EUR", "CAD"],
  expires_in_seconds: 1800,
  warnings: ["Four columns could hold the amount. Vert will not choose between them."],
};

const CONFIDENT = {
  inspection_id: "insp_1a1a",
  columns: ["Date", "Description", "Amount"],
  row_count: 42,
  proposal: {
    date_column: "Date",
    description_column: "Description",
    amount_column: "Amount",
    date_format: "%Y-%m-%d",
  },
  accepted_currencies: ["AUD", "NZD", "USD", "GBP", "EUR", "CAD"],
  expires_in_seconds: 1800,
  warnings: [],
};

// A complete set of answers, for the tests about what is SENT rather than what is
// shown. `account_id` is the seventh: the service refuses without it.
const ANSWERED = {
  date_column: "Date",
  description_column: "Narration",
  amount_column: "Amount",
  date_format: "%d/%m/%Y",
  deposits_are_positive: "yes",
  currency: "AUD",
  account_id: "anz-cheque",
};

const summary = (raw) => inspectionSummary(raw);
const choiceFor = (raw, key) => mappingChoices(summary(raw)).find((c) => c.key === key);

// Which <option> a browser would submit for a given <select>: the one carrying
// `selected`. Reading the markup rather than the component's state, because the
// claim is about what would be SENT, not about what a variable holds.
function selectedOptionIn(html, selectId) {
  const at = html.indexOf(`id="${selectId}"`);
  assert.notEqual(at, -1, `no <select> with id ${selectId} was rendered`);
  const start = html.lastIndexOf("<select", at);
  const end = html.indexOf("</select>", at);
  assert.ok(start !== -1 && end !== -1, `the ${selectId} select is not closed`);
  const block = html.slice(start, end);
  const options = [...block.matchAll(/<option value="([^"]*)"([^>]*)>/g)];
  assert.ok(options.length > 1, `the ${selectId} select has no options`);
  const chosen = options.filter(([, , attrs]) => /\bselected\b/.test(attrs));
  assert.ok(chosen.length <= 1, `${selectId} has ${chosen.length} options selected at once`);
  return chosen.length ? chosen[0][1] : null;
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * 1 — NO PROPOSAL, NO DEFAULT. THE ONE THAT MATTERS.
 * ══════════════════════════════════════════════════════════════════════════ */

test("a field the server proposed nothing for is a required CHOICE, not a default", () => {
  const amount = choiceFor(AMBIGUOUS, "amount_column");
  assert.equal(amount.proposed, null, "a proposal was invented for a field the server left silent");
  assert.equal(amount.mustChoose, true);

  // And it reaches the form as the empty string — not the first column, not the only
  // money-shaped column, not undefined.
  const mapping = initialMapping(mappingChoices(summary(AMBIGUOUS)));
  assert.equal(mapping.amount_column, "", `the amount column was defaulted to ${JSON.stringify(mapping.amount_column)}`);
});

test("on screen, the unproposed amount column has NOTHING selected and says you must choose", () => {
  const html = render(BankStatementMapping, { inspection: summary(AMBIGUOUS), fileName: "westpac-jan.csv" });

  // What the browser would submit: the placeholder, which is the empty string, which
  // the confirm action refuses. Not "Date", not "Debit", not "Balance".
  assert.equal(
    selectedOptionIn(html, "amount_column"),
    "",
    "a column was pre-selected for a field the server refused to guess"
  );

  const text = textOf(html);
  // Verify pass 1 SM4: short field help in a bookkeeper's words, not the design's case.
  assert.match(text, /Choose one\./);
  assert.doesNotMatch(text, /refusal to guess|not an oversight|Stated rather than defaulted/);
});

test("the wrong-column consequence is stated where the choice is made, not in a footnote", () => {
  const text = textOf(render(BankStatementMapping, { inspection: summary(AMBIGUOUS) }));
  assert.match(text, /the wrong column still adds up/);
  // And the server's own warning about this file survives onto the screen.
  assert.match(text, /Four columns could hold the amount/);
});

test("a proposal that is not one of the file's columns is NOT a proposal", () => {
  // The silent version of the same defect: a select whose value is not among its
  // options resolves, in every browser, to the first option. That would put "Date" in
  // the amount column with nobody having chosen anything.
  const stale = { ...CONFIDENT, proposal: { ...CONFIDENT.proposal, amount_column: "Transaction Amount" } };
  const amount = choiceFor(stale, "amount_column");
  assert.equal(amount.proposed, null);
  assert.equal(amount.mustChoose, true);

  const html = render(BankStatementMapping, { inspection: summary(stale) });
  assert.equal(selectedOptionIn(html, "amount_column"), "");
});

test("nothing in lib/bank-import.js falls back to a column when the proposal is silent", () => {
  // The structural half. The mutation this guards is one line — `?? columns[0]`, or
  // an `.includes("amount")` sniff — and it would look entirely reasonable in review.
  const src = stripComments(read("lib/bank-import.js"));
  assert.doesNotMatch(src, /columns\[0\]/, "a first-column fallback was added");
  assert.doesNotMatch(src, /\.find\(\s*\(?c\)?\s*=>\s*\/.*\/i?\.test/, "a column-name sniff was added");
  assert.match(src, /proposed = candidate/, "the proposal is no longer taken from the server's own field");
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 1b — THE DATE FORMAT ON THE WIRE IS STRFTIME. THE REGRESSION THAT BREAKS
 *      EVERY IMPORT, AND MUST NOT BE REINTRODUCIBLE IN SILENCE.
 *
 * This shipped wrong. `DATE_FORMATS` carried "YYYY-MM-DD" and "DD/MM/YYYY" as WIRE
 * VALUES, and `vert_engine.ingestion.bank_csv.check_date_format` refuses anything
 * without `%Y` — naming `%d/%m/%Y`, `%m/%d/%Y` and `%Y-%m-%d` in its own refusal.
 * So every import failed, at the confirm, after the person had answered everything.
 *
 * It failed twice over: the service PROPOSES a strftime format, so a client holding a
 * friendly vocabulary could not recognise its own suggestion and rendered "you must
 * choose" at a field the service had already answered.
 *
 * The friendly labels are the point of the picker and they stay — a bookkeeper reads
 * "DD/MM/YYYY — 01/02/2026 is 1 February 2026" and never sees a percent sign. What
 * changed is which half goes on the wire.
 * ══════════════════════════════════════════════════════════════════════════ */

test("every date format SENT is a strftime format the service will accept", () => {
  assert.ok(DATE_FORMATS.length >= 3);
  for (const { value } of DATE_FORMATS) {
    // The service's own three rules, applied here so a bad option cannot be offered.
    assert.match(value, /%/, `${JSON.stringify(value)} is not a strftime format — this is the friendly token, which the service refuses`);
    assert.ok(value.includes("%Y"),
      `${value} names no four-digit year, so every line would import into 1900 and every one would parse`);
    assert.ok(!value.replace(/%%/g, "").includes("%y"),
      `${value} uses a two-digit year, which the service refuses outright`);
  }
});

test("the friendly token is the LABEL and never the value", () => {
  for (const { value, label } of DATE_FORMATS) {
    assert.doesNotMatch(value, /YYYY|MM|DD|MMM/,
      `${JSON.stringify(value)} is a friendly token on the wire — this is the defect that broke every import`);
    // And the worked example survives, because it is the only thing that tells the two
    // ambiguous formats apart.
    assert.match(label, /\d{4}/, `${label} carries no worked example`);
  }
  // The two that cannot be told apart by shape, told apart by the same day written out.
  const byValue = new Map(DATE_FORMATS.map((f) => [f.value, f.label]));
  assert.match(byValue.get("%d/%m/%Y"), /01\/02\/2026 is 1 February 2026/);
  assert.match(byValue.get("%m/%d/%Y"), /01\/02\/2026 is 2 January 2026/);
});

test("a strftime format the service proposed is RECOGNISED, not rendered as a question", () => {
  // The second half of the same defect. `%Y-%m-%d` is what the live service proposes;
  // a client that only knew "YYYY-MM-DD" discarded it and drew "You must choose" at a
  // field that had been answered — training people to ignore that sentence, which is
  // the one sentence on this screen that has to keep its force.
  const format = choiceFor(CONFIDENT, "date_format");
  assert.equal(format.proposed, "%Y-%m-%d");
  assert.equal(format.mustChoose, false, "the service's own proposal was not recognised as one");
});

test("what reaches the wire for the date format is the strftime string", () => {
  const body = confirmBody({ ...ANSWERED, date_format: "%m/%d/%Y" });
  assert.equal(body.date_format, "%m/%d/%Y");
  assert.doesNotMatch(body.date_format, /YYYY|MM|DD/,
    "a friendly token reached the confirm body — the service refuses this and no import can succeed");
});

test("no friendly token can be a date_format value in the source", () => {
  // The structural half, guarding the exact edit that would reintroduce it: somebody
  // "tidying" the picker back to readable values. A value-level test alone would be
  // satisfied by a translation layer added elsewhere; this asserts the source itself.
  // RAW source, not `stripNonCode`, because the claim is about string LITERALS and
  // that helper blanks every one of them.
  const src = read("lib/bank-import.js");
  assert.doesNotMatch(src, /value:\s*"(YYYY|DD|MM)[^"]*"/,
    "a friendly token was restored as a date_format wire value");
  assert.match(src, /value:\s*"%/, "the date format values are no longer strftime");
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 1c — THE PROPOSAL COMES BACK UNDER THE NAMES IT GOES BACK IN UNDER.
 * ══════════════════════════════════════════════════════════════════════════ */

test("the proposal is read under the confirm body's own key names", () => {
  // The service returns `date_column`/`description_column`/`amount_column` — the exact
  // names it takes back. A client remapping `date_column` → `date` (which this one
  // did, against a withdrawn draft) finds nothing under either name and discards every
  // proposal the service makes.
  assert.equal(choiceFor(CONFIDENT, "date_column").proposed, "Date");
  assert.equal(choiceFor(CONFIDENT, "description_column").proposed, "Description");
  assert.equal(choiceFor(CONFIDENT, "amount_column").proposed, "Amount");
  for (const key of ["date_column", "description_column", "amount_column"]) {
    assert.equal(choiceFor(CONFIDENT, key).mustChoose, false, `${key}'s proposal was discarded`);
  }
});

test("the withdrawn proposal keys are NOT read, so a stale service cannot half-work", () => {
  // A response in the old shape proposes nothing this client understands, and the
  // screen correctly says so rather than reading three fields and silently missing the
  // fourth. Failing whole is legible; failing partially is not.
  const old = {
    inspection_id: "insp_old",
    columns: ["Date", "Description", "Amount"],
    row_count: 3,
    proposal: { date: "Date", description: "Description", amount: "Amount", date_format: "%Y-%m-%d" },
  };
  for (const key of ["date_column", "description_column", "amount_column"]) {
    assert.equal(choiceFor(old, key).proposed, null, `${key} was read from a withdrawn key name`);
    assert.equal(choiceFor(old, key).mustChoose, true);
  }
});

test("no remapping layer survives in the source, in either direction", () => {
  // `stripComments`, NOT `stripNonCode`. The second assertion is about a returned
  // string LITERAL, which `stripNonCode` blanks — so it read source with every
  // `return "date"` already erased. Measured 2026-08-25 by restoring a
  // `keyFor(i) { … return "date"; … }` translation to lib/bank-import.js: this file
  // passed 63/63. The first assertion is about an identifier and worked either way;
  // they now read the same source, so neither can be the one that silently stopped.
  const src = stripComments(read("lib/bank-import.js"));
  assert.doesNotMatch(src, /proposalKeyFor/, "the remapping layer is back");
  assert.doesNotMatch(src, /return\s+"(date|description|amount)"/,
    "a confirm key is being translated to a withdrawn proposal key");
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 1d — THE CURRENCY SET IS THE SERVICE'S, NOT THIS APP'S OPINION OF IT.
 * ══════════════════════════════════════════════════════════════════════════ */

test("the currency list matches the service's published set exactly", () => {
  // ACCEPTED_CURRENCIES in vert_api/routers/bank_statements.py, read from the running
  // service on 2026-08-14. A code offered here and refused there is a picker that
  // produces a guaranteed failure after every other answer has been given.
  assert.deepEqual(CURRENCIES, ["AUD", "NZD", "USD", "GBP", "EUR", "CAD"]);
  assert.ok(!CURRENCIES.includes("SGD"),
    "SGD is offered and the service refuses it — choosing it cannot import anything");
});

test("the service's own published set wins over this app's copy", () => {
  const grown = { ...CONFIDENT, accepted_currencies: ["AUD", "SGD"] };
  assert.deepEqual(choiceFor(grown, "currency").options, ["AUD", "SGD"],
    "the picker ignored the set the service published with this very inspection");
  // Still never selected for the person, whatever the service sends.
  assert.equal(choiceFor(grown, "currency").proposed, null);

  // And a response that published none falls back rather than offering an open set.
  const silent = { ...CONFIDENT, accepted_currencies: undefined };
  assert.deepEqual(choiceFor(silent, "currency").options, CURRENCIES);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 2 — WHERE THERE IS A PROPOSAL, IT IS SELECTED AND LABELLED AS ONE.
 * ══════════════════════════════════════════════════════════════════════════ */

test("a proposed column is selected, and is labelled as the machine's reading", () => {
  const html = render(BankStatementMapping, { inspection: summary(CONFIDENT) });
  assert.equal(selectedOptionIn(html, "amount_column"), "Amount");
  assert.equal(selectedOptionIn(html, "date_column"), "Date");
  // THE STRFTIME VALUE, which is what the service proposed and what it takes back.
  assert.equal(selectedOptionIn(html, "date_format"), "%Y-%m-%d");

  const text = textOf(html);
  assert.match(text, /Vert suggests Amount\. Check it\./);
  assert.match(text, /Vert suggests Amount\. Check it\./,
    "a proposal is presented as a fact rather than as a suggestion to check");
});

test("a proposed date format is still shown with a worked example of an ambiguous date", () => {
  // 01/02/2026 is the 1st of February here and the 2nd of January in the US, and no
  // file says which. The options carry the same day written both ways so the choice
  // cannot be made by recognising a shape.
  const text = textOf(render(BankStatementMapping, { inspection: summary(AMBIGUOUS) }));
  assert.match(text, /DD\/MM\/YYYY: 01\/02\/2026 is 1 February 2026/);
  assert.match(text, /MM\/DD\/YYYY: 01\/02\/2026 is 2 January 2026/);
  assert.ok(DATE_FORMATS.length >= 3);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 3 — TWO FIELDS ARE NEVER PROPOSED, WHATEVER ARRIVES.
 * ══════════════════════════════════════════════════════════════════════════ */

test("currency is never defaulted — not to AUD, and not from a server proposal", () => {
  // `bank_lines.currency` defaults to AUD in the schema, so a USD statement that
  // accepts a default puts a US$916.15 line one integer comparison away from an
  // A$916.15 payout. The proposal is ignored ON PURPOSE, which is why this asserts
  // against a response that HAS one.
  const pushy = { ...CONFIDENT, proposal: { ...CONFIDENT.proposal, currency: "AUD" } };
  const currency = choiceFor(pushy, "currency");
  assert.equal(currency.proposed, null);
  assert.equal(currency.mustChoose, true);

  const html = render(BankStatementMapping, { inspection: summary(pushy) });
  assert.equal(selectedOptionIn(html, "currency"), "", "a currency was chosen for the person");
  assert.ok(CURRENCIES.includes("AUD") && CURRENCIES.includes("USD"), "the currency list is not usable");
});

test("the sign convention starts unstated — neither radio is checked", () => {
  const html = render(BankStatementMapping, { inspection: summary(CONFIDENT) });
  const radios = [...html.matchAll(/<input type="radio"[^>]*name="deposits_are_positive"[^>]*>/g)];
  assert.equal(radios.length, 2, "the sign question is not a two-way choice");
  for (const [tag] of radios) {
    assert.ok(!/\bchecked\b/.test(tag), `a sign convention was pre-selected: ${tag}`);
  }
  // A checkbox would have made "unstated" unrepresentable — its unchecked position
  // would silently mean "deposits are negative", a claim nobody made.
  assert.ok(!/name="deposits_are_positive"[^>]*type="checkbox"/.test(html));
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 4 — THE SIGN CONVENTION, ECHOED IN ENGLISH BEFORE THE BUTTON.
 * ══════════════════════════════════════════════════════════════════════════ */

test("nothing is echoed until the sign convention is stated", () => {
  assert.equal(signConventionSentence({}), null);
  assert.equal(signConventionSentence({ deposits_are_positive: "" }), null);
  const text = textOf(render(BankStatementMapping, { inspection: summary(CONFIDENT) }));
  assert.match(text, /Choose how a deposit is written and this says what will be imported/);
});

test("stating it echoes back what it MEANS, in the file's own column, both ways round", () => {
  const positive = signConventionSentence({ deposits_are_positive: "yes", amount_column: "Amount" });
  // Sentence case, not shouted (verify pass 3, S-E2E-4); the sign is still the word that matters.
  assert.match(positive, /in Amount, money arriving in the account is written as a positive number/);
  assert.match(positive, /A payout landing will be positive; a bank fee will be negative/);

  const negative = signConventionSentence({ deposits_are_positive: "no", amount_column: "Amount" });
  assert.match(negative, /written as a negative number/);
  assert.match(negative, /Every line will have its sign inverted on import/);

  // The two must not read the same. An echo that said "the sign convention is set" in
  // both cases would be a control that confirms itself.
  assert.notEqual(positive, negative);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 5 — NOTHING IS SENT UNTIL ALL SIX ARE STATED.
 * ══════════════════════════════════════════════════════════════════════════ */

test("the confirm is disabled while anything is unstated, and names what is missing", () => {
  const html = render(BankStatementMapping, { inspection: summary(AMBIGUOUS) });
  assert.match(html, /<button type="submit"[^>]*disabled=""/, "the import button is pressable with the amount column unstated");
  const text = textOf(html);
  assert.match(text, /Still to choose: Amount column, Sign convention, Currency, Account this file is a statement of\./);
});

test("the confirm is pressable only when the file's proposal covers everything AND the person answered the rest", () => {
  // The contrast case: even the confident inspection leaves two fields unstated,
  // because two of the six are never proposed. So the button is still disabled — and
  // that is the correct behaviour, not a bug.
  const html = render(BankStatementMapping, { inspection: summary(CONFIDENT) });
  assert.match(html, /<button type="submit"[^>]*disabled=""/);
  assert.deepEqual(unstatedFields(initialMapping(mappingChoices(summary(CONFIDENT)))), [
    "Sign convention",
    "Currency",
    "Account this file is a statement of",
  ]);
});

test("mappingComplete refuses a blank, a space and a missing key alike", () => {
  const full = { ...ANSWERED };
  assert.equal(mappingComplete(full), true);
  for (const field of MAPPING_FIELDS) {
    assert.equal(mappingComplete({ ...full, [field.key]: "" }), false, `${field.key} blank was accepted`);
    assert.equal(mappingComplete({ ...full, [field.key]: "   " }), false, `${field.key} whitespace was accepted`);
    const without = { ...full };
    delete without[field.key];
    assert.equal(mappingComplete(without), false, `a missing ${field.key} was accepted`);
  }
  // SEVEN, not six. `account_id` is required by the service and absent from the pinned
  // contract's confirm body: without it two accounts importing a transaction with the
  // same date, amount and description collapse into ONE bank line, and one account's
  // statement silently absorbs the other's. A build that did not ask for it could not
  // import anything at all — verified against the live service, which refuses the
  // six-field body by name.
  assert.equal(MAPPING_FIELDS.length, 7, "the required answers have changed in number");
});

test("the confirm body is the contract's shape, with the sign as a real boolean", () => {
  const body = confirmBody({ ...ANSWERED, deposits_are_positive: "no", currency: "USD" });
  assert.deepEqual(body, {
    date_column: "Date",
    description_column: "Narration",
    amount_column: "Amount",
    date_format: "%d/%m/%Y",
    // "no" must become `false`, never the truthy string "no" — which would invert a
    // whole statement while looking like it worked.
    deposits_are_positive: false,
    currency: "USD",
    account_id: "anz-cheque",
  });
  assert.equal(confirmBody({ date_column: "Date" }), null, "an incomplete mapping produced a body");

  // NO TOKEN UNLESS ONE WAS ISSUED. The key must be absent, not present-and-empty: a
  // service reading `confirmation: ""` would be reading an agreement nobody made.
  assert.equal("confirmation" in body, false, "a confirmation token was sent on the preview pass");
  assert.equal("confirmation" in confirmBody(ANSWERED, ""), false);
  assert.equal("confirmation" in confirmBody(ANSWERED, "   "), false);
  assert.equal(confirmBody(ANSWERED, "confirm:abc123").confirmation, "confirm:abc123");
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 6 — WHAT THE IMPORT DID, AND WHY IT DID NOT.
 * ══════════════════════════════════════════════════════════════════════════ */

test("both numbers are reported — imported AND duplicates skipped", () => {
  const text = textOf(
    render(BankImportOutcome, {
      outcome: { ok: true, imported: 1129, duplicates_skipped: 55, importId: "imp_77aa" },
    })
  );
  assert.match(text, /1129 lines imported/);
  assert.match(text, /55 lines skipped as already present/,
    "the skipped count is missing, so a half-failed file reads as a clean one");
  // The id is Vert's key, not words (UI walk D10, 30 Oct 2026): the plate says each line
  // carries it, and does not print it.
  assert.match(text, /Every line carries this import, its file and its row number/);
  assert.equal(text.includes("imp_77aa"), false, "the import's raw id is on the plate");
});

test("no duplicates says so, rather than leaving the reader to infer it", () => {
  assert.match(importedLine({ imported: 42, duplicates_skipped: 0 }), /42 lines imported\. No duplicates were skipped\./);
  assert.match(importedLine({ imported: 1, duplicates_skipped: 1 }), /^1 line imported\. 1 line skipped/);
  // Counts the service did not send are not invented as zero — zero is a claim.
  assert.match(importedLine({ imported: 5 }), /did not report how many lines it wrote/);
});

test("a row-specific refusal renders the remedy AND the row number", () => {
  const refusal = importRefusal({
    error: "bank_amount_unparseable",
    remedy: "Row 412 holds “1,203.4-” in Amount, which is not a number Vert will round or coerce. Fix the row and import again.",
    row_number: 412,
  });
  assert.equal(refusal.rowNumber, 412);
  assert.match(importRefusalLine(refusal), /^Row 412: /);

  const text = textOf(render(BankImportOutcome, { outcome: { ok: false, ...refusal } }));
  assert.match(text, /Nothing was imported/);
  assert.match(text, /Row 412/);
  assert.match(text, /not a number Vert will round or coerce/);
  // The slug is for a log. A bookkeeper reading it has to guess what to do.
  assert.ok(!text.includes("bank_amount_unparseable"));
});

test("a file-level refusal invents no row number", () => {
  const refusal = importRefusal({ error: "bank_file_empty", remedy: "The file has no rows under its header. Export the statement again." });
  assert.equal(refusal.rowNumber, null);
  assert.equal(importRefusalLine(refusal), "The file has no rows under its header. Export the statement again.");
});

/* ── ELEMENT-LEVEL READING, NOT PAGE-LEVEL ─────────────────────────────────────
 *
 * `textOf` flattens a whole render to one string, and a regex over that string is
 * satisfied by ANY sentence anywhere in it. That is how a mutation survives its first
 * test: the assertion passes because some other block happens to contain the words.
 *
 * These two read structure instead. `findAlert` returns the markup of the one element
 * carrying role="alert" — the refusal box and nothing else on the screen — and
 * `bodyLines` returns its `.v-body` children as separate strings, so a test can say
 * "one of these lines IS the diagnosis" rather than "these words occur somewhere".
 */
function findAlert(html) {
  const open = html.indexOf('role="alert"');
  if (open === -1) return null;
  const start = html.lastIndexOf("<div", open);
  // Walk div boundaries from `start` until the tag that opened the alert closes.
  let depth = 0;
  const tag = /<(\/?)div\b[^>]*>/g;
  tag.lastIndex = start;
  let match;
  while ((match = tag.exec(html)) !== null) {
    depth += match[1] ? -1 : 1;
    if (depth === 0) return html.slice(start, tag.lastIndex);
  }
  return null;
}

function bodyLines(html) {
  if (!html) return [];
  const out = [];
  const body = /<div class="v-body">([\s\S]*?)<\/div>/g;
  let match;
  while ((match = body.exec(html)) !== null) out.push(textOf(match[1]));
  return out;
}

/* ── THE DIAGNOSIS AND THE REMEDY ARE TWO FACTS ─────────────────────────────── *
 *
 * MEASURED, 2026-08-23, driving a real four-row statement with separate Debit and
 * Credit columns through /connections in a browser against a live API. The service
 * refused the confirm with BOTH halves of the story; the screen printed only the
 * second, because `importRefusal` joined them with `||`. What a person saw was
 * "Row 4: Correct the mapping, the date format, the sign convention or the currency"
 * — four things to check on a file where the service had already said, in the reply
 * this app threw away, that one named cell in one named column was empty.
 *
 * The bytes below are the API's own response, copied from that run.
 */
const EMPTY_CELL_REFUSAL = {
  error: {
    code: "statement_refused",
    message:
      "Row 4, column 'Credit': the cell is empty. A dated statement line with no " +
      "amount is not a line this module will invent a figure for. Nothing was " +
      "imported — the row was not skipped, because a statement line dropped for " +
      "being unreadable is a deposit the register says never happened.",
    detail: {
      remedy:
        "Correct the mapping, the date format, the sign convention or the currency " +
        "and submit again. Nothing was imported — the parse completes before the " +
        "first row is offered to the store, so a statement is never half-written.",
      row_number: 4,
    },
  },
};

test("a refusal carrying BOTH a diagnosis and a remedy keeps both", () => {
  const refusal = importRefusal(EMPTY_CELL_REFUSAL);
  assert.match(refusal.reason, /column 'Credit': the cell is empty/);
  assert.match(refusal.remedy, /^Correct the mapping/);
  assert.equal(refusal.rowNumber, 4);
});

test("the diagnosis reaches the screen, not just the instruction", () => {
  const refusal = importRefusal(EMPTY_CELL_REFUSAL);
  const node = render(BankImportOutcome, { outcome: { ok: false, ...refusal } });

  // ASSERTED ON THE ELEMENT, NOT ON THE PAGE. A page-wide regex for "the cell is
  // empty" would also be satisfied by the remedy sentence being widened one day to
  // mention it, and by any other block on a settings screen that happens to say the
  // same words — which is how seventeen mutations on this project survived their
  // first test. What is asserted is that the alert box drawn for this refusal
  // contains a body line that IS the diagnosis.
  const alert = findAlert(node);
  assert.ok(alert, "no role=alert was rendered for a refusal");
  const bodies = bodyLines(alert);
  assert.ok(
    bodies.some((line) => /column 'Credit': the cell is empty/.test(line)),
    `the service's diagnosis reached no line of the alert. Lines were: ${JSON.stringify(bodies)}`
  );
  assert.ok(
    bodies.some((line) => /^Correct the mapping/.test(line)),
    `the remedy reached no line of the alert. Lines were: ${JSON.stringify(bodies)}`
  );
});

test("the row is stamped once, on the diagnosis, and not again on the remedy", () => {
  const refusal = importRefusal(EMPTY_CELL_REFUSAL);
  // The service's own sentence opens "Row 4, column 'Credit'", so this app adds
  // nothing — and the instruction is left bare rather than prefixed a second time.
  assert.equal(importRefusalReason(refusal), refusal.reason);
  assert.equal(importRefusalLine(refusal), refusal.remedy);
  assert.ok(!importRefusalLine(refusal).startsWith("Row 4:"));
});

test("a diagnosis that names no row is given the one the service reported", () => {
  const refusal = importRefusal({
    error: {
      code: "statement_refused",
      message: "The amount could not be read as a number.",
      detail: { remedy: "Fix it and submit again.", row_number: 412 },
    },
  });
  assert.equal(importRefusalReason(refusal), "Row 412: The amount could not be read as a number.");
});

test("a refusal that carried only a message states it once, not twice", () => {
  // The message is promoted into `remedy` exactly as it always was, and `reason` is
  // null — a screen that drew the same sentence under two headings would be inventing
  // a distinction the service never made.
  const refusal = importRefusal({
    error: { code: "not_found", message: "'netsuite' is not a provider this build can service." },
  });
  assert.equal(refusal.reason, null);
  assert.match(refusal.remedy, /not a provider this build can service/);
  assert.equal(importRefusalReason(refusal), null);

  const bodies = bodyLines(findAlert(render(BankImportOutcome, { outcome: { ok: false, ...refusal } })));
  assert.equal(
    bodies.filter((line) => /not a provider this build can service/.test(line)).length,
    1,
    "the one sentence the service sent was rendered more than once"
  );
});

test("a refusal with no remedy is still a sentence, not an empty box", () => {
  const text = textOf(render(BankImportOutcome, { outcome: { ok: false, remedy: null, rowNumber: null } }));
  // One sentence, and it no longer sends a bookkeeper to "tell whoever runs Vert"
  // (spec §3.6): the whole alert is the heading and that sentence.
  assert.equal(textOf(findAlert(render(BankImportOutcome, { outcome: { ok: false, remedy: null, rowNumber: null } }))), "Nothing was imported Vert refused the file and didn't say what would fix it.");
  assert.match(text, /didn't say what would fix it/);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * A FAILURE ON VERT'S SIDE IS ONE PLAIN LINE, WITH THE SERVICE'S WORDS UNDER DETAILS
 *
 * Eval r1, tester j2b (e2e-iter1/r1/j2b-results.json): a statement imported against a
 * service started without its connections port put this on the sheet's face —
 * "Run the API through `vert_connect.serve`, which builds the connections port and
 * holds the credential encryption key. `vert_api.main:app` deliberately never does".
 * Rubric S6 and C7. The bytes below are the shape of that reply.
 * ══════════════════════════════════════════════════════════════════════════ */

const J2B_REFUSAL = {
  error: {
    code: "connections_unavailable",
    message:
      "This service was started without the connections port, and this one was started " +
      "without it. Run the API through `vert_connect.serve`, which builds the connections " +
      "port and holds the credential encryption key. `vert_api.main:app` deliberately never does.",
  },
};

/** The alert without its Details region: what a person reads without pressing anything. */
function alertFace(html) {
  return textOf(findAlert(html).replace(/<div class="disclosure-region"[\s\S]*?<\/div><\/div>/g, " "));
}

test("J2B: the service's operator text is under Details, and the face is one plain line", () => {
  for (const status of [503, 500, 409]) {
    const outcome = { ok: false, kind: "refused", status, ...importRefusal(J2B_REFUSAL) };
    const html = render(BankImportOutcome, { outcome });
    const face = alertFace(html);
    assert.equal(face, "Vert can't import statements right now. Nothing was imported. Details", `status ${status}: ${face}`);
    assert.doesNotMatch(face, /vert_connect|vert_api|`|connections port/);
    // Nothing the service said is lost: it is one press down.
    assert.match(textOf(html), /Details\s*This service was started without the connections port/);
    assert.equal(importFailureView(outcome).serviceSide, true);
  }
});

test("J2B: the file read shows the same plain line, from the same decision", () => {
  const html = render(ImportRefusal, { outcome: { ok: false, kind: "refused", status: 503, ...importRefusal(J2B_REFUSAL) }, title: "The file was not read" });
  assert.match(alertFace(html), /^Vert can't import statements right now\. Nothing was imported\./);
  // And the file-read sheet renders its refusals through it, not a copy of its own.
  const src = stripComments(read("components/settings/BankStatementImport.js"));
  assert.match(src, /<ImportRefusal outcome=\{state\} title="The file was not read" \/>/);
  assert.doesNotMatch(src, /importRefusalLine|importRefusalReason/, "the file-read sheet composes a refusal of its own again");
});

test("a service that never answered, or a build with none, reads the same way", () => {
  for (const outcome of [
    { ok: false, kind: "unreachable", status: 0, remedy: "POST /bank-statements could not be completed (TypeError). The service is not answering — try again, or tell whoever runs it.", reason: null, rowNumber: null },
    { ok: false, kind: "unavailable", status: 0, remedy: "This build has no Vert service behind it. Start vert_api and rebuild with NEXT_PUBLIC_VERT_API_URL set.", reason: null, rowNumber: null },
    { ok: false, kind: "refused", status: 401, remedy: "Sign in again.", reason: null, rowNumber: null },
  ]) {
    // The whole face, exactly: the transport's and the build's operator sentences are
    // under Details and nowhere else.
    const face = alertFace(render(BankImportOutcome, { outcome }));
    assert.equal(face, "Vert can't import statements right now. Nothing was imported. Details", `${outcome.kind} ${outcome.status}`);
  }
});

test("a refusal about the FILE is untouched: its diagnosis and remedy stay on the face", () => {
  // The contrast, in one variable: the same component, a 422 about a cell. Without this
  // the tests above pass on a component that hides every refusal under Details.
  const outcome = { ok: false, kind: "refused", status: 422, ...importRefusal(EMPTY_CELL_REFUSAL) };
  assert.equal(importFailureView(outcome).serviceSide, false);
  const face = alertFace(render(BankImportOutcome, { outcome }));
  assert.match(face, /^Nothing was imported/);
  assert.match(face, /column 'Credit': the cell is empty/);
  assert.match(face, /Correct the mapping/);
  assert.doesNotMatch(face, /Vert can't import statements right now/);
});

test("the operator-text backstop fires on what it exists for, and not on a bookkeeper's sentence", () => {
  for (const bad of ["Run `vert_connect.serve`", "Start vert_api", "at http://127.0.0.1:8000", "the connections port", "NEXT_PUBLIC_VERT_API_URL", "tell whoever runs it"]) {
    assert.ok(isOperatorText(bad), `not caught: ${bad}`);
  }
  for (const fine of [
    "Row 412 holds “1,203.4-” in Amount, which is not a number Vert will round or coerce. Fix the row and import again.",
    "The file has no rows under its header. Export the statement again.",
    "'netsuite' is not a provider this build can service.",
  ]) {
    assert.equal(isOperatorText(fine), false, `a bookkeeper's sentence was hidden: ${fine}`);
  }
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 7 — THE SUMMARY CARRIES THE SILENCE THROUGH.
 * ══════════════════════════════════════════════════════════════════════════ */

test("inspectionSummary carries the proposal raw, absences and all", () => {
  const s = summary(AMBIGUOUS);
  assert.equal(s.inspectionId, "insp_9f2c");
  assert.equal(s.rowCount, 1184);
  assert.deepEqual(s.columns, COLUMNS);
  assert.equal("amount" in s.proposal, false, "an amount proposal was manufactured on the way through");
  // A response with no proposal object at all is the same silence, not a crash.
  assert.deepEqual(summary({ inspection_id: "x", columns: ["A"] }).proposal, {});
  assert.equal(mappingChoices(summary({ inspection_id: "x", columns: ["A"] })).every((c) => c.mustChoose), true);
});

test("the confirm body carries the inspection id, so a confirm cannot land on nothing", () => {
  // THE CLAIM IS ABOUT THE BODY, NOT ABOUT A HIDDEN INPUT. It used to be asserted on
  // the markup, because the id travelled as `<input type="hidden">`. It no longer
  // does — see `confirmFormData`, and BankStatementMapping's own header for the
  // browser run that moved it — and the claim is unchanged: a confirm without an
  // inspection behind it is a confirm the service can only refuse.
  const body = confirmFormData(ANSWERED, { inspectionId: "insp_9f2c" });
  assert.equal(body.get("inspection_id"), "insp_9f2c");
});

/* ── THE ANSWERS SURVIVE THE ROUND TRIP ─────────────────────────────────────── *
 *
 * MEASURED IN A BROWSER, 2026-08-23, against a live API. The import could not be
 * completed at all: React 19 resets a `<form action={fn}>` once the action settles,
 * a controlled `<select value={…}>` has no default for a reset to restore, and so
 * every dropdown blanked the moment the service returned its echo. `mapping` state
 * was untouched — the echo and the token kept rendering — so the second press sent
 * six empty answers, the service refused, and the screen redrew identically with the
 * button still enabled and no message on it. There was no sequence of presses that
 * imported the file. See lib/bank-import.js `confirmFormData` for the full finding.
 *
 * Two invariants keep it fixed, and both are needed. The first is that the form does
 * not hand React an `action` prop, which is what stops the reset and keeps the
 * answers ON SCREEN. The second is that what is SENT is built from the stated
 * answers rather than read back out of the controls.
 */
test("the mapping form does not hand React an action prop, so React never resets it", () => {
  const src = stripComments(read("components/settings/BankStatementMapping.js"));
  // Asserted on the FORM ELEMENT, not on the file: `action=` occurs in this file for
  // other reasons, and a page-wide match is how a mutation survives its first test.
  const form = src.match(/<form[^>]*>/);
  assert.ok(form, "no <form> element was found in BankStatementMapping");
  assert.doesNotMatch(
    form[0],
    /\baction\s*=/,
    "the mapping <form> takes an action prop again; React will reset it and blank every answer"
  );
  assert.match(form[0], /onSubmit\s*=/, "the mapping <form> submits through nothing at all");
});

test("the confirm body is built from the stated answers, not read back out of the DOM", () => {
  const body = confirmFormData(ANSWERED, { inspectionId: "insp_9f2c", confirmation: "confirm:abc" });
  for (const field of MAPPING_FIELDS) {
    assert.equal(body.get(field.key), ANSWERED[field.key], `${field.key} did not reach the body`);
  }
  assert.equal(body.get("confirmation"), "confirm:abc");
});

test("an unstated answer is sent as an empty string, so the service refuses it BY NAME", () => {
  // Never dropped from the body: a field the server does not receive is a field the
  // server gets to pick, which is the whole defect this screen is arranged against.
  const body = confirmFormData({ ...ANSWERED, currency: "" }, { inspectionId: "insp_9f2c" });
  assert.equal(body.get("currency"), "");
  assert.ok(body.has("currency"), "an unanswered field was omitted rather than sent empty");
});

test("no token is sent on the first press — that is what makes it a preview", () => {
  const body = confirmFormData(ANSWERED, { inspectionId: "insp_9f2c", confirmation: "" });
  assert.equal(body.has("confirmation"), false);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 8 — THE FORM IS USABLE BY SOMEBODY WHO CANNOT SEE IT.
 * ══════════════════════════════════════════════════════════════════════════ */

test("every control has a real label and its requirement is announced, not just shown", () => {
  const html = render(BankStatementMapping, { inspection: summary(AMBIGUOUS) });
  for (const field of MAPPING_FIELDS) {
    if (field.kind === "sign") {
      assert.match(html, /<legend class="sr-only">Sign convention<\/legend>/);
      continue;
    }
    assert.match(html, new RegExp(`<label[^>]*for="${field.key}"`), `${field.key} has no <label for>`);
    // The "you must choose" line and the help text are the described-by target, so a
    // screen reader hears the requirement when the control takes focus.
    assert.match(html, new RegExp(`id="${field.key}"[^>]*aria-describedby="${field.key}-help"`),
      `${field.key} is not described by its requirement`);
    assert.match(html, new RegExp(`id="${field.key}-help"`));
  }
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 9 — THE ACTION REFUSES BEFORE THE WIRE, AND NEVER SILENTLY DROPS A FIELD.
 *
 * The subtle version of the defect this whole file guards: an unstated field that is
 * simply left OUT of the confirm body, so the server picks. These drive the real
 * Server Action with a real FormData; no network is reached, because every one of
 * them is refused before a request is formed.
 * ══════════════════════════════════════════════════════════════════════════ */

const { confirmStatementAction } = await import("../components/settings/actions.js");

function form(fields) {
  const data = new FormData();
  for (const [key, value] of Object.entries(fields)) data.append(key, value);
  return data;
}

const STATED = { inspection_id: "insp_9f2c", ...ANSWERED };

test("a field left out of the submission is refused BY NAME, not sent as an absence", async () => {
  for (const key of MAPPING_FIELDS.map((f) => f.key)) {
    const without = { ...STATED };
    delete without[key];
    const outcome = await confirmStatementAction(null, form(without));
    assert.equal(outcome.ok, false, `a mapping missing ${key} was sent to the service`);
    assert.match(outcome.remedy, new RegExp(key.replace(/_/g, " ")),
      `the refusal does not say which field is missing (${key})`);
    assert.match(outcome.remedy, /Nothing was imported/);
    // AND THE WORDS THE OTHER HALF OF THIS RULE FORBIDS, ASSERTED HERE AS PRESENT.
    // The guard below — "a complete mapping was refused as incomplete" — watches for
    // `not stated` on a submission that stated everything, and until this line nothing
    // in the suite had ever seen the phrase produced. A guard whose forbidden phrase is
    // never observed being emitted is green on the day it is written and green on the
    // day the branch it watches stops working. Triaged 2026-08-30.
    assert.match(outcome.remedy, /not stated/,
      `the refusal for a missing ${key} no longer says the field was not stated`);
  }
});

test("a confirm with no inspection behind it is refused rather than sent", async () => {
  const outcome = await confirmStatementAction(null, form({ ...STATED, inspection_id: "" }));
  assert.equal(outcome.ok, false);
  assert.match(outcome.remedy, /Upload the file again/);
});

test("the action reaches the service only when all of them are stated — and then it is unreachable, not silent", async () => {
  // The contrast case, in one variable: the same submission WITH every field stated
  // gets past the refusal above and out to the transport, which in this build has no
  // service and says so. What must never happen is a submission passing quietly with
  // a field missing.
  const outcome = await confirmStatementAction(null, form(STATED));
  assert.equal(outcome.ok, false);
  assert.doesNotMatch(outcome.remedy, /not stated/, "a complete mapping was refused as incomplete");
  assert.match(outcome.remedy, /no Vert service behind it/);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 9 — THE ACCOUNT THE FILE IS A STATEMENT OF. REQUIRED, AND NEVER GUESSED.
 *
 * Not in the pinned contract's confirm body, and the service refuses without it —
 * verified against the live service, which answers the six-field body with "No account
 * was named for this statement". So the build that did not ask for it could not import
 * anything at all, and every test that said the import worked was testing a request
 * that had never been sent.
 *
 * A bank line's id is derived from its content, so two accounts importing a
 * transaction with the same date, amount and description produce ONE line, and one
 * account's statement silently absorbs the other's.
 * ══════════════════════════════════════════════════════════════════════════ */

test("the account is one of the required answers, and nothing proposes it", () => {
  const account = MAPPING_FIELDS.find((f) => f.key === "account_id");
  assert.ok(account, "the service requires account_id and this form does not ask for it");
  const choice = choiceFor(CONFIDENT, "account_id");
  assert.equal(choice.proposed, null);
  assert.equal(choice.mustChoose, true);
  assert.deepEqual(choice.options, [], "a picker was offered for a fact only the person knows");
  assert.equal(initialMapping(mappingChoices(summary(CONFIDENT))).account_id, "");
});

test("the account is a real text input, empty, with no answer sitting in it", () => {
  const html = render(BankStatementMapping, { inspection: summary(CONFIDENT), fileName: "westpac-jan.csv" });
  assert.match(html, /<input[^>]*id="account_id"[^>]*>/, "the account field is not rendered");
  const at = html.indexOf('id="account_id"');
  const tag = html.slice(html.lastIndexOf("<input", at), html.indexOf(">", at));
  assert.match(tag, /value=""/, "the account field arrived with something already in it");
  assert.match(tag, /required/);
  assert.match(html, /<label[^>]*for="account_id"/, "the account field has no label");
});

test("the account is NEVER seeded from the file name", () => {
  // The one guess that must not be made. File identity is deliberately excluded from
  // the line's identity — a re-export of the same period and two overlapping download
  // windows are the two cases that actually happen, and both would double the
  // statement — so routing the file name in through the account re-opens exactly the
  // double-import that exclusion exists to close. And a person who accepts a
  // pre-filled account is a person who never chose one.
  const html = render(BankStatementMapping, { inspection: summary(CONFIDENT), fileName: "westpac-jan.csv" });
  const at = html.indexOf('id="account_id"');
  const tag = html.slice(html.lastIndexOf("<input", at), html.indexOf(">", at));
  assert.ok(!tag.includes("westpac"), "the account was seeded from the file name");

  // And no module wires the file name into the account field.
  for (const file of ["lib/bank-import.js", "components/settings/BankStatementMapping.js"]) {
    const src = read(file);
    assert.doesNotMatch(src, /account_id[^\n]*fileName|fileName[^\n]*account_id/,
      `${file} routes the file name into the account`);
  }
});

test("the account reaches the wire under the service's own field name", () => {
  assert.equal(confirmBody(ANSWERED).account_id, "anz-cheque");
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 10 — THE GATE. NOTHING IS WRITTEN UNTIL A PERSON HAS READ WHAT WILL BE.
 *
 * The service will not commit without a token that digests the exact facts it echoed.
 * Submitted without one it parses everything, applies every refusal, mints every line
 * and writes NOTHING, answering 422 with the echo and the token.
 *
 * The build being fixed rendered that 422 as "Nothing was imported" in a red alert and
 * offered no way to agree — so the import could never complete. The opposite failure
 * is worse and is what these tests mostly guard: handing the token straight back
 * automatically would turn the gate into decoration while leaving every "importing
 * works" test green.
 * ══════════════════════════════════════════════════════════════════════════ */

const GATE_BODY = {
  error: {
    code: NOT_CONFIRMED_CODE,
    message: "This import has not been confirmed, so nothing was written.",
    detail: {
      remedy: "Show the echo to the person importing this file, then submit again with confirmation set to the token below.",
      echo: "3 statement line(s) for account 'anz-cheque', in AUD. YOU SAID DEPOSITS ARE POSITIVE in this file, so 2 line(s) are being recorded as money coming in and 1 as money going out. Dates were read as %d/%m/%Y. Nothing has been written yet.",
      confirmation: "confirm:c7b3660ab177d3c0",
    },
  },
};

test("the preview carries the echo and the token out of the service's refusal", () => {
  const gate = importGate(GATE_BODY);
  assert.ok(gate, "the service's echo was not recognised, so the import can never be agreed to");
  assert.match(gate.echo, /YOU SAID DEPOSITS ARE POSITIVE/);
  assert.equal(gate.confirmation, "confirm:c7b3660ab177d3c0");
});

test("only THAT refusal is a gate — every other one stays a refusal", () => {
  assert.equal(importGate({ error: { code: "statement_refused", detail: { remedy: "Fix the mapping." } } }), null);
  assert.equal(importGate({ error: { code: EXPIRED_CODE, detail: { remedy: "Upload it again." } } }), null);
  assert.equal(importGate(null), null);
  assert.equal(importGate({}), null);
});

test("an echo with no token, or a token with no echo, is NOT a gate", () => {
  // A token with no echo is a button that commits something unread — the exact thing
  // the gate exists to prevent, arriving by the back door. An echo with no token is a
  // sentence nobody can act on.
  const noToken = { error: { code: NOT_CONFIRMED_CODE, detail: { echo: "…", confirmation: "" } } };
  const noEcho = { error: { code: NOT_CONFIRMED_CODE, detail: { echo: "", confirmation: "confirm:x" } } };
  assert.equal(importGate(noToken), null);
  assert.equal(importGate(noEcho), null);
});

test("the preview renders the service's echo, and is NOT dressed as a failure", () => {
  const review = { ok: false, stage: "review", echo: GATE_BODY.error.detail.echo, confirmation: "confirm:c7b3660ab177d3c0" };
  const text = textOf(render(BankImportOutcome, { outcome: review }));
  assert.equal(text.trim(), "", "the preview rendered as a red 'nothing was imported' alert");

  const html = render(BankStatementMapping, { inspection: summary(CONFIDENT) });
  // Without a review in hand the form's own button offers the preview, never a commit.
  assert.match(textOf(html), /Review this import/);
  assert.doesNotMatch(textOf(html), /Yes, import these lines/);

  // THE SECOND ARM IS NO LONGER MISSING. Round 18 recorded it as unclosable here: the
  // commit label needed `reviewIsCurrent`, which needed `outcome` — `useActionState`'s
  // value, not a prop, so null under `renderToStaticMarkup` — and dropping the whole
  // staleness comparison left this file green. It is closed by moving the decision out
  // of the component: `importGateView` (lib/bank-import.js) is a pure function of the
  // outcome and the answers on screen, and `BankImportGate` renders it from a prop, so
  // both halves of the gate are now driven directly below.
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE TWO-PRESS GATE ITSELF — BOTH HALVES, DRIVEN
 *
 * This is the only control in the product that writes rows into a bookkeeper's bank
 * statement, and until round 19 nothing in this suite had ever rendered it armed.
 * ══════════════════════════════════════════════════════════════════════════ */

// The review as the server action hands it back: the service's echo, the token that
// digests it, and the answers the request actually carried.
const REVIEW = {
  ok: false,
  stage: "review",
  kind: "refused",
  status: 422,
  echo: GATE_BODY.error.detail.echo,
  confirmation: "confirm:c7b3660ab177d3c0",
  stated: { ...ANSWERED },
};

test("with no outcome at all the press PREVIEWS, and says nothing is written", () => {
  const view = importGateView(null, ANSWERED, {});
  assert.equal(view.armed, false);
  assert.equal(view.label, "Review this import");
  assert.equal(view.confirmation, "", "a token went out on the first press");
  assert.match(view.sentence, /Nothing is written until you have read that and said yes to it/);
});

test("with the service's review in hand the press WRITES, and says so", () => {
  const view = importGateView(REVIEW, ANSWERED, {});
  assert.equal(view.armed, true);
  assert.equal(view.label, "Yes, import these lines");
  assert.equal(view.confirmation, "confirm:c7b3660ab177d3c0");
  assert.match(view.sentence, /Pressing this writes the lines above/);
});

test("CHANGING ANY ANSWER RETRACTS THE AGREEMENT — the gate, in one assertion", () => {
  // THE FAILURE THIS PREVENTS: the token digests the exact facts in the echo, so a
  // token held across an edit is a token for a DIFFERENT import. The service refuses a
  // stale one and that is the real lock — but a screen that went on showing the old
  // echo beside newly changed answers would be asking somebody to agree, in good
  // faith, to a sentence that had stopped describing what they had said.
  for (const field of MAPPING_FIELDS) {
    const edited = { ...ANSWERED, [field.key]: field.key === "deposits_are_positive" ? "no" : "CHANGED" };
    const view = importGateView(REVIEW, edited, {});
    assert.equal(view.armed, false, `editing ${field.key} left the old review in force`);
    assert.equal(view.confirmation, "", `a stale token was still being sent after editing ${field.key}`);
    assert.equal(view.label, "Review this import", `the commit label survived editing ${field.key}`);
  }
});

test("a review that does not say what it was produced from is NOT in force", () => {
  // The one shape that would turn the staleness check into decoration: an outcome with
  // an echo and a token and no record of the answers behind them. Nothing can be
  // compared, so nothing may be agreed to.
  const { stated, ...noStated } = REVIEW;
  assert.equal(reviewInForce(noStated, ANSWERED), null);
  assert.equal(reviewInForce({ ...REVIEW, stated: null }, ANSWERED), null);
});

test("a token with no echo does not arm the gate, whatever else agrees", () => {
  // A token with no sentence beside it is a button that commits something unread —
  // the exact thing the gate exists to prevent, arriving by the back door.
  assert.equal(reviewInForce({ ...REVIEW, echo: "" }, ANSWERED), null);
  assert.equal(reviewInForce({ ...REVIEW, confirmation: "" }, ANSWERED), null);
});

test("an ordinary refusal is not a review and never arms the press", () => {
  const refusal = { ok: false, kind: "refused", status: 400, remedy: "Fix the mapping.", stated: { ...ANSWERED } };
  assert.equal(reviewInForce(refusal, ANSWERED), null);
  assert.equal(importGateView(refusal, ANSWERED, {}).label, "Review this import");
});

test("an unanswered field disables the press in BOTH halves of the gate", () => {
  // Armed or not: the button that writes must not be pressable while a column is
  // unstated, and the reason has to be beside it.
  const half = { ...ANSWERED, currency: "" };
  for (const [name, outcome] of [["first press", null], ["armed", { ...REVIEW, stated: half }]]) {
    const view = importGateView(outcome, half, {});
    assert.equal(view.disabled, true, `${name}: the press was live with an unstated field`);
    assert.match(view.sentence, /Still to choose: .*Currency/, `${name}: no reason beside the disabled press`);
  }
});

test("the press says what it is waiting for, and WHICH wait it is", () => {
  // A control that greys out and keeps its old label is a control that looks broken.
  // Two different waits, and they are not interchangeable: the first press is reading
  // the file and writes nothing, the second is importing. Somebody who pressed commit
  // and reads "Reading the file…" has been told the write did not start.
  assert.equal(importGateView(null, ANSWERED, { pending: true }).label, "Reading the file…");
  assert.equal(importGateView(REVIEW, ANSWERED, { pending: true }).label, "Importing…");
});

test("the press is dead while the request is out, in BOTH halves", () => {
  // THE DEFECT: two presses is two imports, on the one control in this product that
  // writes rows into somebody's bank statement.
  assert.equal(importGateView(null, ANSWERED, { pending: true }).disabled, true);
  assert.equal(importGateView(REVIEW, ANSWERED, { pending: true }).disabled, true);
  // And it is live again when nothing is out and everything is answered, or the
  // assertions above would hold over a button that never works.
  assert.equal(importGateView(REVIEW, ANSWERED, { pending: false }).disabled, false);
});

test("THE ARMED GATE, RENDERED — the echo, the commit label and the warning", () => {
  // The half no test had ever rendered. `BankImportGate` takes the view as a prop, so
  // this is the real component drawing the real armed state.
  const html = render(BankImportGate, { view: importGateView(REVIEW, ANSWERED, {}) });
  const text = textOf(html);
  // Said once (UI walk 2, N7): the service's echo ends with it, so the heading doesn't.
  assert.match(text, /Read this before importing\./);
  assert.equal(text.split("Nothing has been written yet").length - 1, 1, text);
  // The service's sentence, not summarised, its notation in words (UI walk D10).
  assert.ok(text.includes("You said money arriving is a positive number in this file, so 2 lines are being recorded as money coming in and 1 as money going out"), "the service's echo is not on screen");
  assert.ok(text.includes("Dates were read as DD/MM/YYYY"), "the echo's date format is not on screen");
  assert.match(text, /Yes, import these lines/);
  assert.match(text, /Pressing this writes the lines above/);
  const button = html.match(/<button[^>]*>/)[0];
  assert.ok(!button.includes("disabled"), "the commit press was disabled with every answer stated");
});

test("THE UNARMED GATE, RENDERED — no echo panel, and no commit label", () => {
  const text = textOf(render(BankImportGate, { view: importGateView(null, ANSWERED, {}) }));
  assert.doesNotMatch(text, /Nothing has been written yet/, "an echo panel was drawn with no echo");
  assert.doesNotMatch(text, /Yes, import these lines/);
  assert.match(text, /Review this import/);
});

test("THE CALL SITE — the mapping screen renders the gate from the shared view", () => {
  // The mutation this catches: the component going back to deciding for itself, which
  // is the state in which the whole gate was invisible to this file.
  const src = stripComments(read("components/settings/BankStatementMapping.js"));
  assert.match(src, /importGateView\(outcome, mapping/, "the mapping screen no longer asks for the gate view");
  assert.match(src, /<BankImportGate view=\{gate\}/, "the mapping screen no longer renders the gate");
  assert.match(src, /confirmation: gate\.confirmation/, "the token sent is no longer the one the gate decided");
  // And the server action still says what its review was produced from, which is what
  // makes the staleness comparison possible at all.
  assert.match(stripComments(read("components/settings/actions.js")), /stage: "review"[\s\S]{0,600}?\n\s*stated,/,
    "the review outcome no longer carries the answers it was produced from");
});

test("NOTHING IN THIS APP MINTS A CONFIRMATION TOKEN", () => {
  // The single line that would destroy the safety property: calling the service twice,
  // once to obtain a token and once to hand it straight back. It would look reasonable
  // in review and it would leave every "importing works" test green.
  for (const file of ["lib/bank-import.js", "components/settings/actions.js", "components/settings/BankStatementMapping.js"]) {
    // RAW source for the literal, stripped source for the call.
    assert.doesNotMatch(read(file), /confirmation:\s*["'`]confirm/, `${file} spells a token literal`);
    assert.doesNotMatch(stripComments(read(file)), /createHash|randomUUID|md5|sha256/,
      `${file} computes something token-shaped`);
  }
  // And the body carries no token unless one was handed in from a service refusal.
  assert.equal("confirmation" in confirmBody(ANSWERED), false);
});

test("a blank or whitespace token is an ABSENT key, never an empty agreement", () => {
  // `confirmation: ""` would be an agreement nobody made, sent under the name of one.
  // The key must not be present at all.
  for (const nothing of [null, undefined, "", "   ", "\n"]) {
    assert.equal("confirmation" in confirmBody(ANSWERED, nothing), false,
      `${JSON.stringify(nothing)} was sent as a confirmation`);
  }
  assert.equal(confirmBody(ANSWERED, "  confirm:abc  ").confirmation, "confirm:abc");
});

test("an expired upload is a different instruction from an unknown one", () => {
  // Same status, opposite advice: "you did the right thing, just slowly — do it again"
  // against "this is not the preview you think it is". A client that could not tell
  // them apart would send somebody to retry an id that was never going to work.
  const expired = importRefusal({ error: { code: EXPIRED_CODE, message: "…", detail: { remedy: "Upload the same file again — nothing about it was wrong." } } });
  const unknown = importRefusal({ error: { code: "statement_refused", message: "…", detail: { remedy: "Upload the statement file again and confirm on the new inspection id." } } });
  assert.equal(expired.code, EXPIRED_CODE);
  assert.notEqual(unknown.code, EXPIRED_CODE);
  assert.notEqual(expired.remedy, unknown.remedy);
});

test("a refusal that carried no remedy falls back to the service's message, never its code", () => {
  // Not every refusal on this service carries a remedy — a 404 for an unknown provider
  // has `detail: {subject, subjectId}` and nothing else. Read only `remedy` and that
  // renders as an empty alert box, which is a screen saying nothing at all.
  const refusal = importRefusal({
    error: { code: "not_found", message: "'netsuite' is not a provider this build can service.", detail: {} },
  });
  assert.match(refusal.remedy, /not a provider this build can service/);
  assert.ok(!refusal.remedy.includes("not_found"), "the slug reached the sentence a person reads");
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 11 — THE INSPECTION'S NEW FACTS ARE CARRIED, NOT DROPPED.
 * ══════════════════════════════════════════════════════════════════════════ */

test("the summary carries how long the upload stays confirmable, and the accepted set", () => {
  const s = summary(CONFIDENT);
  assert.equal(s.expiresInSeconds, 1800);
  assert.deepEqual(s.acceptedCurrencies, ["AUD", "NZD", "USD", "GBP", "EUR", "CAD"]);
  // A response that published neither says so with null and [], never with a guess.
  const bare = summary({ inspection_id: "x", columns: ["A"] });
  assert.equal(bare.expiresInSeconds, null);
  assert.deepEqual(bare.acceptedCurrencies, []);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 12 — CHOOSING THE FILE IS READING THE FILE. THE STEP THAT LOST THE ATTACHMENT.
 *
 * The importer asked for a file with a picker and then asked for a second press on a
 * button labelled "Inspect the file". No work happened between them and nothing on
 * screen in between could be checked — and on 2026-08-17 the founder, importing a real
 * statement, could not get past it: the attachment did not survive to the second press
 * and the screen went back to asking for a file.
 *
 * A step that exists only to be pressed adds no safety and is a place for the payload
 * to be lost. The split that IS the safety — read the file and write nothing, then
 * write only against six stated answers and an echo the person read — is untouched and
 * is asserted by sections 1 through 11 above.
 * ══════════════════════════════════════════════════════════════════════════ */

const { inspectStatementAction } = await import("../components/settings/actions.js");

function csv(name = "anz-june.csv") {
  return new File([`${COLUMNS.join(",")}\n2026-06-01,Stripe,,950.00,950.00,950.00\n`], name, {
    type: "text/csv",
  });
}

test("a chosen file survives the boundary and reaches the service", async () => {
  // THE BUG, AT THE ONE SEAM THIS SUITE CAN DRIVE. A FormData carrying a real file
  // must get PAST the "no file" refusal and out to the transport, which in this build
  // has no service and says so. If the attachment were lost on the way in, the action
  // would answer with the picker's own refusal instead — which is exactly what the
  // screen did.
  const data = new FormData();
  data.append("file", csv(), "anz-june.csv");
  const outcome = await inspectStatementAction(null, data);

  assert.equal(outcome.ok, false);
  assert.doesNotMatch(outcome.remedy, /Choose a CSV file/, "the file was dropped before the request was built");
  assert.match(outcome.remedy, /no Vert service behind it/, "the file never reached the transport");
});

test("the file is forwarded whole, under the field name the service reads", () => {
  // The other half of the claim above, and the half the transport's own refusal cannot
  // prove: getting past the picker's check is not the same as being SENT. THE MUTATION
  // THIS CATCHES: dropping the append, which leaves an empty multipart body going out
  // and a screen that says the service could not read the file.
  const src = stripComments(read("components/settings/actions.js"));
  assert.match(src, /forward\.append\([^)]*file, file\.name\)/,
    "the chosen file is not appended to the request the service receives");
});

test("no file is still refused, by name, before the wire is spent", async () => {
  // The contrast case. Without it the assertion above proves only that something
  // happened.
  const outcome = await inspectStatementAction(null, new FormData());
  assert.equal(outcome.ok, false);
  assert.match(outcome.remedy, /Choose a CSV file/);
  // And the remedy no longer names a control that does not exist. It used to end
  // "then press Inspect", which sent somebody looking for a button this screen removed.
  assert.doesNotMatch(outcome.remedy, /press Inspect/);
});

test("choosing a file submits the form that contains it, in the same interaction", () => {
  // ONE SUBMISSION PATH. `requestSubmit()` runs the form's own action with its own
  // FormData — the same code path the button takes — rather than assembling a request
  // out of `event.target.files`, which is the version where a picker and a payload can
  // come apart. THE MUTATION THIS CATCHES: deleting the onChange, which restores the
  // two-press flow the file was lost in.
  const src = stripComments(read("components/settings/BankStatementImport.js"));
  assert.match(src, /onChange=\{readImmediately\}/, "choosing a file no longer reads it");
  assert.match(src, /form\.requestSubmit\(\)/, "the read is not driven by the form that holds the file");
  // Raw source for the quoted attribute: stripNonCode blanks string literals, and the
  // field's name IS one. The action reads `formData.get("file")` and a renamed field
  // would arrive as no file at all.
  assert.match(read("components/settings/BankStatementImport.js"), /name="file"/,
    "the field the action reads by name is gone");
  // The button remains — for the keyboard, and for the seconds before this component
  // hydrates — but it is the same submission and not a second step.
  assert.match(read("components/settings/BankStatementImport.js"), /type="submit"/);
  // Stripped, because this file's own header records the label it replaced and a scan
  // that could not tell prose from code would fail on the sentence describing the fix.
  assert.doesNotMatch(src, /Inspect the file/, "the second step survived under its old label");
});

test("the file's own name travels to the mapping screen, where the lines are attributed to it", () => {
  // Provenance is the reason the name is carried at all: every imported line records
  // the file it came from and its row number. A flow that lost the attachment lost
  // that too, and the mapping screen would be describing a file nobody could name.
  const text = textOf(render(BankStatementMapping, { inspection: CONFIDENT, fileName: "anz-june.csv" }));
  assert.match(text, /anz-june\.csv/);
  assert.match(text, /rows read/);
});
