// tests/bank-rec-rows.test.js — THE BANK REC READS LIKE XERO'S RECONCILE SCREEN
// ==============================================================================
// The co-founder's ask (23 Oct 2026): the bank line on the left, what it matches or how
// to code it on the right, in sections with counts; a word on every row; the plan; the
// statement against the books. Driven by tests/fixtures/bank-rec-shape.json, which the
// ENGINE wrote (_bank_rec_rows.build, validated against agent_events.ShapeBankRec), so
// the screen is held to what the engine really sends.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";

import { render, textOf } from "./_harness/render.js";
import { ROOT } from "./_harness/source.js";
import BankRecRows from "../components/chat/answer/BankRecRows.js";
import ShapeBlocks from "../components/chat/answer/ShapeBlocks.js";
import { bankRecOf, toneOf } from "../components/chat/answer/bank-rec.js";
import { shapeOf } from "../components/chat/answer/shape.js";
import { formatMoney } from "../lib/format.js";

const FIX = JSON.parse(readFileSync(path.join(ROOT, "tests", "fixtures", "bank-rec-shape.json"), "utf8"));
const WITH = FIX.withStatement;
const NONE = FIX.noStatement;

const draw = (bankRec, ledgerName = "Xero") => render(BankRecRows, { bankRec, ledgerName });

/** The markup of one section, from its opening tag to the next section's. */
function sectionHtml(html, key) {
  const start = html.indexOf(`data-section="${key}"`);
  assert.ok(start >= 0, `no ${key} section`);
  const next = html.indexOf('data-section="', start + 20);
  const plan = html.indexOf("data-bankrec-plan", start);
  const ends = [next, plan, html.length].filter((i) => i > start);
  return html.slice(start, Math.min(...ends));
}

test("the sections come in Xero's order, each titled with the ledger and its count", () => {
  const html = draw(WITH);
  const keys = [...html.matchAll(/data-section="([a-z_]+)" data-count="(\d+)"/g)].map((m) => [m[1], Number(m[2])]);
  assert.deepEqual(keys, WITH.sections.map((s) => [s.key, s.count]));
  const text = textOf(html);
  for (const title of ["Already reconciled in Xero", "In Xero, not yet reconciled", "On the bank statement, not in Xero", "Can't resolve yet"]) {
    assert.ok(text.includes(title), title);
  }
  assert.ok(!text.includes("{{ledger}}"), "the ledger placeholder is filled");
});

test("already reconciled is folded away, its count and total still on the face", () => {
  const html = draw(WITH);
  const a = sectionHtml(html, "reconciled");
  const sec = WITH.sections[0];
  assert.match(a, /aria-expanded="false"/);
  assert.match(a, /inert=""/);
  assert.ok(textOf(a).includes(`Show the ${sec.count} lines`));
  assert.ok(textOf(a).includes(formatMoney(sec.totalCents)), "the engine's total, formatted");
  // Only it is folded: the page holds exactly one fold, and the open sections draw rows.
  assert.equal(html.split("disclosure-toggle").length - 1, 1);
  assert.match(sectionHtml(html, "unreconciled"), /class="bankrec-table" role="list"/);
});

test("a row is the bank line on the left and the proposal on the right, with its status word", () => {
  const html = draw(WITH);
  const rows = [...html.matchAll(/class="bankrec-row" role="listitem" data-status="([a-z_]+)" data-tone="([a-z]+)"/g)];
  const all = WITH.sections.flatMap((s) => s.rows);
  assert.equal(rows.length, all.length, "every row the engine sent is drawn");
  for (const r of all) {
    const at = html.indexOf(`data-status="${r.status}"`);
    assert.ok(at >= 0, r.status);
    assert.ok(textOf(html).includes(r.statusWords), `${r.status} says "${r.statusWords}" in words`);
  }
  // Xero's own column words, never colour alone, for the direction.
  const text = textOf(sectionHtml(html, "unreconciled"));
  assert.ok(text.includes("Received") && text.includes("SMITH CO"));
  assert.ok(text.includes("Not on this statement"), "a book entry with no statement line says so on the left");
});

test("one row per status: invoice, coding, entry, and each reason Vert can't resolve", () => {
  const text = textOf(draw(WITH));
  // matched → the invoice by number and contact, linked to Xero
  assert.ok(text.includes("Invoice INV-0042 · Bluebird Cafe"));
  assert.match(draw(WITH), /href="https:\/\/go\.xero\.com\/AccRec\/View\.aspx\?InvoiceID=inv-42"/);
  // coded → account, tax, contact
  assert.ok(text.includes("429 · General Expenses") && text.includes("GST on Expenses · Officeworks"));
  assert.ok(text.includes("Or: 461 Printing & Stationery"));
  // entry → the drafted adjusting entry
  assert.ok(text.includes("A bank-fee adjusting entry, drafted for you to approve"));
  // can't resolve → reason and what to do
  for (const r of WITH.sections[3].rows) {
    assert.ok(text.includes(r.reason.replace(/\{\{ledger\}\}/g, "Xero")), r.status);
    // What to do is said on the row, without a "What you can do:" label (8 Nov 2026).
    if (r.action) assert.ok(text.includes(r.action.replace(/\{\{ledger\}\}/g, "Xero")), `${r.status}: no way on`);
  }
  assert.ok(text.includes("Several matches") && text.includes("Amount differs") && text.includes("Pick the account"));
  assert.ok(text.includes(`Differs by ${formatMoney(250)}`), "the engine's difference, not one worked out here");
});

test("the plan is numbered and its amounts are the engine's", () => {
  const html = draw(WITH);
  const plan = html.slice(html.indexOf("data-bankrec-plan"));
  const steps = [...plan.matchAll(/<li data-step="([a-z_]+)">/g)].map((m) => m[1]);
  assert.deepEqual(steps, WITH.plan.map((s) => s.kind));
  assert.match(plan, /<ol class="bankrec-steps">/);
  const entry = WITH.plan.find((s) => s.kind === "approve_entries");
  assert.ok(textOf(plan).includes(`Approve the bank-fee adjusting entry ${formatMoney(entry.amountCents)}`));
  assert.ok(textOf(plan).includes("In Xero, click OK on"));
});

test("the tie-out shows the difference unexplained, with its word, never plugged", () => {
  const html = draw(WITH);
  const tie = html.slice(html.indexOf("data-tie-status"));
  assert.match(tie, /data-tie-status="unexplained"/);
  const text = textOf(tie);
  assert.ok(text.includes(formatMoney(WITH.tieOut.differenceCents)));
  assert.ok(text.includes("Unexplained") && text.includes("isn't plugged"));
});

test("with no statement, Xero's two sections are shown and the statement's need is said", () => {
  const html = draw(NONE);
  assert.match(html, /data-statement="missing"/);
  const keys = [...html.matchAll(/data-section="([a-z_]+)"/g)].map((m) => m[1]);
  assert.deepEqual(keys, ["reconciled", "unreconciled"]);
  const text = textOf(html);
  assert.ok(text.includes("Xero doesn't share unreconciled bank statement lines through its API"));
  assert.ok(text.includes("Needs the bank statement") && text.includes("Waiting for the statement"));
  const steps = [...html.matchAll(/<li data-step="([a-z_]+)">/g)].map((m) => m[1]);
  assert.deepEqual(steps, ["upload_statement"], "the upload is the one step");
  assert.match(html, /data-tie-status="not_measured"/);
  assert.ok(text.includes("Not worked out"), "an unread difference is words, never $0.00");
});

test("an empty section teaches instead of drawing an empty box", () => {
  const empty = { ...WITH, sections: WITH.sections.map((s) => (s.key === "unresolved" ? { ...s, count: 0, rows: [], totalCents: 0 } : s)) };
  const text = textOf(sectionHtml(draw(empty), "unresolved"));
  assert.ok(text.includes("Nothing left that Vert can't propose for."));
});

test("the shape carries bankRec through shapeOf, and ShapeBlocks draws it in place of the work table", () => {
  const shape = shapeOf({ bankRec: WITH, work: { artifactId: "a1", title: "T", sheet: "Reconciling items", columns: [{ key: "item", label: "Item", kind: "text" }], rows: [], shown: 0, of: 0 } });
  assert.ok(shape && shape.bankRec, "bankRec survives the reader");
  const html = render(ShapeBlocks, { shape, figures: {}, ledgerName: "Xero" });
  // The rows ARE the work: the shape block is exactly the rows, with no table or roll beside them.
  const ids = (h) => h.replace(/_R_[A-Za-z0-9]+_/g, "_ID_");
  assert.equal(ids(html), ids(`<div class="chat-shape" data-answer-shape="">${draw(WITH)}</div>`));
  // A shape with ONLY bankRec (no statement yet) is still a shape.
  assert.ok(shapeOf({ bankRec: NONE }));
});

test("a payload that isn't the contract is dropped whole, never half-drawn", () => {
  assert.equal(bankRecOf(null), null);
  assert.equal(bankRecOf({ statement: true, sections: [{ key: "nope", title: "x", count: 0 }] }), null);
  assert.equal(draw({ sections: [] }), "");
  assert.equal(toneOf("pick_account"), "attention");
  assert.equal(toneOf("reconciled"), "done");
});

test("9 Nov 2026: a card's tie-out reads as owed, and its reconciling items take the statement to the books", () => {
  const card = { ...WITH, tieOut: { status: "ties", words: "Ties to the cent.", statementCents: 24639, booksCents: 7920, differenceCents: 0, itemsCents: 16719, owed: true } };
  const tie = html => html.slice(html.indexOf("data-tie-status"));
  const text = textOf(tie(draw(card)));
  assert.ok(text.includes("Owed per card statement") && text.includes("Owed per Xero"), text);
  assert.ok(text.includes(`Reconciling items${formatMoney(16719)}`) || text.includes(formatMoney(16719)), text);
  assert.ok(text.includes("Xero and the bank reconciliation report show it as a minus"));
  // A bank account keeps its words; no items row when nothing takes one to the other.
  const bank = textOf(tie(draw({ ...WITH, tieOut: { ...WITH.tieOut, itemsCents: 0 } })));
  assert.ok(bank.includes("Statement balance") && !bank.includes("Owed per") && !bank.includes("Reconciling items"));
});
