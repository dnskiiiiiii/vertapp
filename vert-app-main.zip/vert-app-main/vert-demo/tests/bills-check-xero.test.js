// tests/bills-check-xero.test.js — RETRYING A SEND THAT MAY HAVE LANDED: CHECK XERO FIRST
// ==============================================================================
// Verification review (28 Oct 2026), against the engine's revised contract. An
// "unconfirmed" item carries needsConfirm: true, confirmKind "check_ledger", confirmWords and
// sometimes `candidates` (bills in Xero that might be it). It is retried one at a time,
// only after an explicit "I've checked Xero" step, which alone sends {"checkedLedger": true};
// a possible duplicate (confirmKind "duplicate") still sends {"confirmDuplicate": true}.
// Bulk approve never includes either. The engine's 409 reasons (check_ledger,
// check_candidates, read_failed, contact_choose, confirm_duplicate) reach the page.
// The page half is in tests/bills-confirm-screen.test.js (static mode, for rendering).

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { ID, ID2, ID3, item, json, recordingFetch } from "./bills-fixtures.js";

process.env.NEXT_PUBLIC_VERT_API_URL = "http://vert-api.invalid:8000";
const bills = await import("../lib/bills.js");
const api = await import("../lib/bills-client.js");
const model = await import("../lib/bills-model.js");
const approveRoute = await import("../app/api/bills/[id]/approve/route.js");

async function withFetch(reply, run) {
  const real = globalThis.fetch;
  const rec = recordingFetch(reply);
  globalThis.fetch = rec.fetchImpl;
  try {
    return await run(rec.calls);
  } finally {
    globalThis.fetch = real;
  }
}

const UNCONFIRMED_ITEM = (extra = {}) =>
  item({
    status: "unconfirmed",
    statusWords: "Couldn't confirm: check Xero",
    needsConfirm: true,
    confirmKind: "check_ledger",
    confirmWords: "The last send may have reached Xero. Look for Acme's INV-1043 in Xero before sending again.",
    candidates: [],
    ...extra,
  });

test("an unconfirmed item's approve leads to the check-Xero step, with its words; a duplicate's to its own", () => {
  const a = model.approvalOf(UNCONFIRMED_ITEM());
  assert.equal(a.can, true);
  assert.equal(a.confirmKind, "check_ledger");
  assert.match(a.confirm, /may have reached Xero/);
  // Unconfirmed without the engine's flags still asks to check Xero.
  assert.equal(model.approvalOf(item({ status: "unconfirmed" })).confirmKind, "check_ledger");
  const d = model.approvalOf(item({ needsConfirm: true, confirmKind: "duplicate", confirmWords: "Maybe a duplicate." }));
  assert.deepEqual([d.confirmKind, d.confirm], ["duplicate", "Maybe a duplicate."]);
  assert.equal(model.approvalOf(item()).confirmKind, null);
});

test("bulk excludes every unconfirmed and every needsConfirm item", () => {
  const items = [UNCONFIRMED_ITEM(), item({ id: ID2, status: "unconfirmed", needsConfirm: false }), item({ id: ID3, needsConfirm: true, confirmKind: "duplicate" })];
  const out = model.bulkOf([...items, item({ id: "6ba7b810-9dad-41d1-80b4-00c04fd430c8" })], [ID, ID2, ID3, "6ba7b810-9dad-41d1-80b4-00c04fd430c8"]);
  assert.deepEqual(out.ready, ["6ba7b810-9dad-41d1-80b4-00c04fd430c8"]);
  assert.deepEqual(out.held.sort(), [ID, ID2, ID3].sort());
  assert.deepEqual(out.checkXero.sort(), [ID, ID2].sort());
  assert.deepEqual(out.confirm, [ID3]);
  assert.equal(model.CHECK_XERO_IN_REVIEW_WORDS, "Open it and check Xero before sending it again");
});

test("candidates are listed with Open in Xero links only on https xero.com", () => {
  const it = UNCONFIRMED_ITEM({
    candidates: [
      { invoiceId: "x1", invoiceNumber: "INV-1043", status: "DRAFT", xeroUrl: "https://go.xero.com/AccountsPayable/Edit.aspx?InvoiceID=x1" },
      { invoiceId: "x2", invoiceNumber: "INV-1043A", status: "AUTHORISED", xeroUrl: "https://evil.example/x2" },
      { invoiceId: "x3", invoiceNumber: null, status: null, xeroUrl: null },
      null,
    ],
  });
  assert.deepEqual(model.candidatesOf(it), [
    { id: "x1", words: "INV-1043, draft", url: "https://go.xero.com/AccountsPayable/Edit.aspx?InvoiceID=x1" },
    { id: "x2", words: "INV-1043A, authorised", url: null },
    { id: "x3", words: "A bill with no number", url: null },
  ]);
});

test("the check-Xero retry sends {checkedLedger: true} only when asked; the route passes only a literal true", async () => {
  const ok = { item: item({ status: "sent" }), outcome: { status: "sent", words: "", xeroUrl: null, manualFields: [] } };
  await withFetch(() => json(ok), async (calls) => {
    await bills.approveBill(ID, { checkedLedger: true });
    await bills.approveBill(ID, { checkedLedger: "yes" });
    await bills.approveBill(ID, { confirmDuplicate: true });
    assert.deepEqual(calls.map((c) => JSON.parse(c.init.body)), [{ checkedLedger: true }, {}, { confirmDuplicate: true }]);
    const req = (b) => new Request(`http://h/api/bills/${ID}/approve`, { method: "POST", headers: { host: "h", origin: "http://h", "sec-fetch-site": "same-origin", "content-type": "application/json" }, body: b });
    await approveRoute.POST(req(JSON.stringify({ checkedLedger: true })), { params: Promise.resolve({ id: ID }) });
    await approveRoute.POST(req(JSON.stringify({ checkedLedger: 1, confirmDuplicate: "true" })), { params: Promise.resolve({ id: ID }) });
    assert.deepEqual(calls.slice(3).map((c) => JSON.parse(c.init.body)), [{ checkedLedger: true }, {}]);
  });
  const { calls, fetchImpl } = recordingFetch(() => json({ ok: true, ...ok }));
  await api.approve(ID, { checkedLedger: true, fetchImpl });
  assert.deepEqual(JSON.parse(calls[0].init.body), { checkedLedger: true });
});

test("each 409 reason a retry can answer comes back marked, with the engine's words as written", async () => {
  for (const [reason, message] of [
    ["check_ledger", "Check Xero for INV-1043 first."],
    ["check_candidates", "Vert found 2 bills in Xero that might be this one."],
    ["read_failed", "Vert couldn't read Xero; nothing was written. Try again."],
    ["contact_choose", "Choose which Acme this is."],
    ["confirm_duplicate", "This may already be in Xero."],
  ]) {
    await withFetch(() => json({ error: { code: "approve_refused", message, detail: { reason } } }, 409), async () => {
      const out = await bills.approveBill(ID, { checkedLedger: true });
      assert.deepEqual([out.kind, out.reason, out.message], ["blocked", reason, message]);
    });
  }
});

test("the page knows what each reason asks for", () => {
  assert.equal(model.retryStepOf("check_ledger"), "check_ledger");
  assert.equal(model.retryStepOf("check_candidates"), "check_ledger");
  assert.equal(model.retryStepOf("confirm_duplicate"), "duplicate");
  assert.equal(model.retryStepOf("read_failed"), null);
  assert.equal(model.retryStepOf("contact_choose"), null);
  assert.equal(model.retryStepOf(null), null);
});
