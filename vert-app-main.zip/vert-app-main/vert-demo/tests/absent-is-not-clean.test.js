// tests/absent-is-not-clean.test.js — SEVEN WIRE FIELDS, AND THE SCREEN THAT OWES THEM
// =============================================================================
// THE STANDING RULE, AND THE THIRD ROUND OF FINDING IT BROKEN.
//
// A field that reaches the wire and does not reach the screen is the same defect as
// not having the field. The round before this one found the shape exactly: the agent's
// abstention was carefully composed on the engine side and rendered nowhere but a
// printable working paper. So this file is not "the new fields parse". It is: for each
// of the seven, a person looking at the surface can read the fact, and — the half that
// keeps being lost — an ABSENT field renders as unknown IN WORDS and never as clean,
// zero or silence.
//
// THE FOUR SURFACES AND WHAT EACH ONE OWED
//
//   1. /exceptions `chartGapsUnmeasuredReason` — the register's "Missing accounts"
//      block was an empty list under a heading whenever the deployment could not look.
//      `chartGapsMeasured: false` was already read, but a boolean renders as nothing;
//      the sentence naming WHICH absence it is (no scoped read, or no `assertions`
//      relation at all) was on the wire and on no screen.
//   2. POST /reconcile `criticConfigured|Reviewed|Unavailable|Reading` — the four
//      facts that `criticNotesQueued: 0` collapsed into one integer. This app rendered
//      none of them: the re-reconcile notice said "re-reconciled" and stopped, so a
//      person on a build with NO CRITIC IN IT read exactly what a person on a fully
//      reviewed run read.
//   3. GET /payouts/{id} `agent.modelReached` / `unreachableReason`, and
//      `proposals[].critic.reviewed` / `.reading` — a payout whose model call never
//      landed was drawn with the sentence "A model was consulted on this payout and
//      returned no proposal", which is a sentence about a model that answered.
//   4. `proseProvenance.markedIn` and `echoes[].fieldLabel` — the location of borrowed
//      wording, said in an accountant's words by the engine rather than reconstructed
//      here, on a card whose header promises "no JSON, no tool names".
//
// AND ONE RESIDUAL THE DETAIL PANES HAD ALREADY CLOSED: the approvals QUEUE CARD said
// "1 proposal awaiting review" for a payout with one and said NOTHING for a payout the
// agent abstained on — so a reviewer scanning thirty cards could not tell "a model
// looked and declined" from "no model was ever asked".
//
// TWO KINDS OF ASSERTION, AND THE SECOND IS THE ONE THIS REPO KEEPS NEEDING. Fifteen
// mutations have survived their first test on this project, and the recurring shape is
// a mutation that DELETES A CALL SITE while leaving a perfect function behind. Every
// section below therefore asserts the rendered output of the real component, and where
// the wiring runs through a server component or a Server Action that cannot be
// rendered here, asserts the CALL SITE in the source as well.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { render, textOf } from "./_harness/render.js";
import { ROOT, listAppSources, read, stripComments } from "./_harness/source.js";
// STATIC_ENGINE DIRECTLY, NOT `_harness/engine.js`. That module calls `feedsFor()`
// at import time, which memoises the payout feeds against this payload in a WeakMap —
// so a payout installed afterwards exists in `reconciliations` and never reaches
// `PAYOUTS`, and `payoutStatus` returns null for it. tests/abstention.test.js takes
// the same import for the same reason.
import { STATIC_ENGINE as ENGINE } from "../lib/engine-source.js";
import { OVERLAYS_UNAPPLIED_REASON } from "../lib/engine-server.js";

import { criticRunView } from "../lib/assertions.js";
// The one authority on which statuses the engine refuses an approval from — read
// here rather than restated, so the test and the pane cannot drift apart.
import { notYetApprovableReason } from "../lib/feeds.js";
import {
  abstentionView,
  agentQueueLine,
  criticView,
  modelReachView,
  undecidedProposals,
  viewProposal,
  wordingView,
} from "../lib/proposal-view.js";
import { agentFor } from "../lib/proposals.js";
import { payoutStatus } from "../lib/payoutStatus.js";
import { COMMITTED_PAYOUT_IDS, committedPayoutIds, injectedPayoutIds } from "./_harness/corpus.js";
import { buildPayoutRun } from "../lib/trace/build.js";

/* ══════════════════════════════════════════════════════════════════════════ *
 * 1 — /exceptions chartGapsUnmeasuredReason
 * ══════════════════════════════════════════════════════════════════════════ */

// `lib/engine-server.js` decides SOURCE from the environment at module load, and this
// suite runs with NEXT_PUBLIC_VERT_API_URL unset on purpose (tests/engine-source.test.js
// asserts that outright) so that every render is a render of the static showpiece. The
// API branch therefore cannot be reached in this process, and the honest way to drive
// it is a child node with the variable set and `fetch` replaced — the real module, the
// real read, a scripted body. A source scan would not have caught a `readChartGaps`
// that dropped the field on the floor after reading it.
function readChartGapsAgainst(body) {
  const script = `
    globalThis.fetch = async () => ({
      ok: true,
      status: 200,
      headers: { get: () => "application/json" },
      json: async () => (${JSON.stringify(body)}),
      text: async () => ${JSON.stringify(JSON.stringify(body))},
    });
    const m = await import("./lib/engine-server.js");
    process.stdout.write(JSON.stringify(await m.readChartGaps()));
  `;
  const out = execFileSync(
    process.execPath,
    ["--import", "./tests/_harness/register.js", "--input-type=module", "-e", script],
    { cwd: ROOT, env: { ...process.env, NEXT_PUBLIC_VERT_API_URL: "http://127.0.0.1:9/api" }, encoding: "utf8" }
  );
  return JSON.parse(out);
}

const NO_TABLE =
  "This database has no `assertions` relation: migration 0004 has not been applied " +
  "here. No chart gap was looked for, so the empty list beside this means NOT " +
  "LOOKED AT rather than none filed. Apply the migrations to close it.";

test("the API's reason for not looking survives the read, verbatim", () => {
  const { gaps, measured, unmeasuredReason } = readChartGapsAgainst({
    chartGaps: [],
    chartGapsMeasured: false,
    chartGapsUnmeasuredReason: NO_TABLE,
  });
  assert.deepEqual(gaps, []);
  assert.equal(measured, false);
  // Verbatim. A read that paraphrased would be this app writing the engine's words for
  // it, and the words are the actionable part — they name the migration.
  assert.equal(unmeasuredReason, NO_TABLE);
});

test("a deployment that DID look carries no reason, so no surface can print one", () => {
  const { measured, unmeasuredReason } = readChartGapsAgainst({
    chartGaps: [],
    chartGapsMeasured: true,
    chartGapsUnmeasuredReason: null,
  });
  assert.equal(measured, true);
  assert.equal(unmeasuredReason, null);
});

test("a truthy chartGapsMeasured does not promote itself into a measured read", () => {
  // The rule that has been broken twice on this project. `"true"` is a string.
  const { measured, unmeasuredReason } = readChartGapsAgainst({
    chartGaps: [],
    chartGapsMeasured: "true",
    chartGapsUnmeasuredReason: NO_TABLE,
  });
  assert.equal(measured, false, "the string \"true\" was read as a measured read");
  assert.equal(unmeasuredReason, NO_TABLE);
});

test("an API that could not look and said nothing about why leaves a null, not a guess", () => {
  const { measured, unmeasuredReason } = readChartGapsAgainst({
    chartGaps: [],
    chartGapsMeasured: false,
  });
  assert.equal(measured, false);
  assert.equal(unmeasuredReason, null, "a reason was manufactured for a build that gave none");
});

// RETIRED BY G1, 2026-09-30 — these rendered or read surfaces the agent workspace
// deleted (spec §12.1): the missing-accounts queue and the exceptions page, the outcome
// notice (DecisionNotice), the AI rail's abstention block and proposal card, the
// proposal decision control, the approvals queue card and pane, the register row and
// panel. Every lib-level three-state case is kept: absent is still unknown, in words, at
// the function. FINDINGS, named in G1's handoff: no screen says whether a critic
// reviewed a write, whether the model was reached, or that a chart-gap read did not
// happen. Count ledger:
//   · the register prints the deployment's own reason for not look
//   · no reason given is still said in words, never as an unqualif
//   · THE CALL SITE — the exceptions page carries the reason fro
//   · THE CALL SITE — the register carries the caveat, above the
//   · the notice a person actually reads carries the critic's stat
//   · THE CALL SITE — every successful write is asked whether a 
//   · an unreachable model is drawn as an unreachable model, on th
//   · a payload that says nothing about reach says THAT, and claim
//   · a model that WAS reached still reads exactly as it did
//   · THE CALL SITE — the card reads the reach view rather than 
//   · the engine's own finished sentence for WHERE the marks are r
//   · ONE NAMING AUTHORITY PER CARD — markedIn never contradicts
//   · NO DOTTED PATH REACHES THE CARD, whatever the engine sends
//   · an older payload with no markedIn still says where the marks
//   · THE CALL SITE — the card prints markedIn rather than only 
//   · a proposal card knows which payout a decision would be writt
//   · with no payout to write against, the controls are absent and
//   · THE CALL SITE — both panes tell the card which payout it i
//   · the queue card itself distinguishes an abstention from a pay
//   · a payout WITH a proposal still says so, in the same slot
//   · THE CALL SITE — the queue card asks the agent block, not j
//   · THE FOURTH SURFACE DISAGREEMENT — a dismissed proposal rea
//   · THE REGISTER ROW — the pill stops saying a decided proposa
//   · the destination row does not call a rejected entry ready to 
//   · and an entry nobody has decided is still ready to stage
//   · THE REGISTER ROW — a rejected entry is not called Staged, 
//   · and an entry nobody has decided is still Staged, and still o
//   · a status this build has never heard of is not given either c

/* ══════════════════════════════════════════════════════════════════════════ *
 * 1b — THE SAME ABSENCE, ABOUT THE REGISTER RATHER THAN ABOUT THE LIST.
 *
 * `chartGapsMeasured: false` says the API could not read this tenant's `assertions`
 * relation. That relation is not only where chart gaps live — it is where EVERY answer
 * a reviewer has recorded lives, and `store_repository` applies those answers to every
 * read route in the engine. When it cannot be read the overlays are off for the whole
 * request, so every figure on the exceptions register is the PRE-ASSERTION answer: a
 * transaction somebody classified reads unmapped again, and the payout that answer
 * unblocked reads blocked again.
 *
 * MEASURED ON A LIVE TENANT AGAINST POSTGRES, 2026-08-23, with `assertions` renamed
 * away. The Missing accounts block correctly said it had not been measured. Directly
 * above it the register listed a classified transaction as "Transaction type not
 * mapped", counted it in "4 open exceptions across 3 categories", and said nothing
 * anywhere about the reviewer's answer not having been read. Honest about the small
 * report and silently wrong about the big one — which is the same defect this file is
 * named for, one block up the page.
 * ══════════════════════════════════════════════════════════════════════════ */

test("an API that could not read the answers marks the whole register unapplied", () => {
  // THE MUTATION THIS CATCHES: dropping `overlaysUnapplied` from the read. The Missing
  // accounts block goes on being honest and the register goes on being silently
  // pre-assertion — which is exactly the state this was found in.
  const { overlaysUnapplied } = readChartGapsAgainst({
    chartGaps: [],
    chartGapsMeasured: false,
    chartGapsUnmeasuredReason: NO_TABLE,
  });
  assert.equal(overlaysUnapplied, true);
});

test("an API that DID read them leaves the register uncaveated", () => {
  // The other side of the pair, and it is a DIFFERENT input rather than the same one
  // read twice: a caveat printed on every deployment is a caveat nobody reads, and it
  // would be false on the one where everything worked.
  const { overlaysUnapplied } = readChartGapsAgainst({
    chartGaps: [],
    chartGapsMeasured: true,
    chartGapsUnmeasuredReason: null,
  });
  assert.equal(overlaysUnapplied, false);
});

test("a read that did not complete is unapplied too — unknown is not clean", () => {
  // The fetch threw, so whether the answers were applied was never established. Unknown
  // is reported the same way as known-bad on purpose: the rule is that an unread state
  // is never published as a measured one.
  const script = `
    globalThis.fetch = async () => { throw new Error("connect ECONNREFUSED"); };
    const m = await import("./lib/engine-server.js");
    process.stdout.write(JSON.stringify(await m.readChartGaps()));
  `;
  const out = execFileSync(
    process.execPath,
    ["--import", "./tests/_harness/register.js", "--input-type=module", "-e", script],
    { cwd: ROOT, env: { ...process.env, NEXT_PUBLIC_VERT_API_URL: "http://127.0.0.1:9/api" }, encoding: "utf8" }
  );
  const answer = JSON.parse(out);
  assert.equal(answer.measured, false);
  assert.equal(answer.overlaysUnapplied, true);
});

test("the static showpiece is not caveated — it has no overlay to be missing", () => {
  // `measured` is false here too, and it must NOT drag the caveat along: the showpiece
  // holds its decisions in lib/store.js and there is no assertions table anywhere in
  // the picture. This is why the fact is carried as its own field rather than the
  // register reading `!measured` for itself.
  const script = `
    const m = await import("./lib/engine-server.js");
    process.stdout.write(JSON.stringify(await m.readChartGaps()));
  `;
  const out = execFileSync(
    process.execPath,
    ["--import", "./tests/_harness/register.js", "--input-type=module", "-e", script],
    { cwd: ROOT, encoding: "utf8" }
  );
  const answer = JSON.parse(out);
  assert.equal(answer.measured, false, "the showpiece claimed a measured read");
  assert.equal(answer.overlaysUnapplied, false, "the showpiece caveated a register with no API behind it");
});

test("the sentence says what is wrong with the figures, not that nobody answered", () => {
  // Two different facts, and the caveat must not be readable as the second. "Nobody has
  // classified anything" is a claim about the books; this is a claim about the read.
  assert.match(OVERLAYS_UNAPPLIED_REASON, /No answer any reviewer has recorded could be read/);
  assert.match(OVERLAYS_UNAPPLIED_REASON, /This is not a claim that nobody answered/);
  // And it names what a reader will actually see, so they can recognise it.
  assert.match(OVERLAYS_UNAPPLIED_REASON, /will read as unmapped/);
  assert.match(OVERLAYS_UNAPPLIED_REASON, /will read as blocked/);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 2 — POST /reconcile: the four critic states, in a sentence
 * ══════════════════════════════════════════════════════════════════════════ */

const READINGS = {
  unconfigured:
    "No critic is configured on this deployment, so nothing on this run has had a " +
    "second opinion. The count beside this is a question nobody asked, not a review " +
    "that found nothing wrong.",
  unreviewed:
    "The critic was not asked about anything on this run: no new proposal was " +
    "recorded for it to review.",
  unavailable: "The critic could not be reached on 1 of the 2 proposals it was shown.",
  reviewed: "The critic reviewed 2 proposals and raised nothing about either.",
};

function runBody(fields) {
  return { run: { payoutId: "po_1", outcome: "clean", state: "reconciled", changed: true, ...fields } };
}

test("the four critic outcomes are four states, not one integer", () => {
  const cases = [
    ["unconfigured", { criticConfigured: false, criticReviewed: 0, criticUnavailable: 0, criticNotesQueued: 0, criticReading: READINGS.unconfigured }],
    ["unreviewed", { criticConfigured: true, criticReviewed: 0, criticUnavailable: 0, criticNotesQueued: 0, criticReading: READINGS.unreviewed }],
    ["unavailable", { criticConfigured: true, criticReviewed: 2, criticUnavailable: 1, criticNotesQueued: 0, criticReading: READINGS.unavailable }],
    ["reviewed", { criticConfigured: true, criticReviewed: 2, criticUnavailable: 0, criticNotesQueued: 0, criticReading: READINGS.reviewed }],
  ];
  const seen = new Set();
  for (const [expected, fields] of cases) {
    const view = criticRunView(runBody(fields));
    assert.equal(view.state, expected);
    // THE SENTENCE IS THE ENGINE'S, selected and never composed. All four of these
    // carry `criticNotesQueued: 0`, which is the whole point: the integer is identical
    // and the four readings are not.
    assert.equal(view.sentence, READINGS[expected]);
    seen.add(view.sentence);
  }
  assert.equal(seen.size, 4, "two of the four critic outcomes read the same on screen");
});

test("a run with no critic fields reads as unrecorded, never as reviewed and clean", () => {
  const view = criticRunView(runBody({}));
  assert.equal(view.state, "unreported");
  assert.match(view.sentence, /gap in the record/);
  assert.doesNotMatch(view.sentence, /raised nothing/i);

});

test("a truthy criticConfigured cannot manufacture a configured critic", () => {
  for (const truthy of ["true", 1, "yes"]) {
    const view = criticRunView(runBody({ criticConfigured: truthy, criticReviewed: 2, criticUnavailable: 0, criticReading: READINGS.reviewed }));
    assert.equal(view.state, "unconfigured", `criticConfigured = ${JSON.stringify(truthy)} was read as a critic`);
  }
});

test("an action that runs no pipeline describes no critic at all", () => {
  // Approve, reject and post carry no `run` block. A sentence about a second opinion
  // on those would be describing a review that was never even possible.
  assert.equal(criticRunView({ state: { status: "approved" } }), null);
  assert.equal(criticRunView(null), null);
});

test('every export of a "use server" module is async, or the whole app 500s', () => {
  // FOUND IN A BROWSER, BY 500 ON EVERY ROUTE, WITH 932 TESTS GREEN.
  //
  // `criticRunView` was first written into lib/actions.js, beside the `decide()` that
  // calls it. That module opens with `"use server"`, which makes every export a Server
  // Action and requires every one of them to be async — a synchronous export is not a
  // lint complaint, it is `Ecmascript file had an error` and a 500 on every page that
  // transitively imports it. This suite compiles the file with SWC directly and had
  // nothing to say; the first real request said it immediately.
  //
  // Asserted over EVERY such module rather than the one that broke, because the next
  // pure helper somebody writes will be put next to its caller for the same good
  // reason, and the error message names a line number rather than the rule.
  const modules = listAppSources("lib", "components", "app").filter((rel) => {
    const head = read(rel).slice(0, 400);
    return /^\s*["']use server["']\s*;/m.test(head);
  });
  assert.ok(modules.length > 0, "no \"use server\" module was found — this scan has stopped scanning");
  for (const rel of modules) {
    const code = stripComments(read(rel));
    // `export function f`, `export const f = (…) =>`, `export const f = function`.
    const offenders = [];
    for (const m of code.matchAll(/export\s+(?:async\s+)?function\s+(\w+)/g)) {
      if (!/export\s+async\s+function/.test(m[0])) offenders.push(m[1]);
    }
    for (const m of code.matchAll(/export\s+const\s+(\w+)\s*=\s*(async\s*)?[({]/g)) {
      if (!m[2]) offenders.push(m[1]);
    }
    assert.deepEqual(
      offenders,
      [],
      `${rel} carries "use server" and exports ${offenders.join(", ")} synchronously — ` +
        `every export of a Server Action module must be async or Next refuses to compile it`
    );
  }
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 3 — GET /payouts/{id}: modelReached and unreachableReason
 * ══════════════════════════════════════════════════════════════════════════ */

const UNREACHABLE =
  "The model could not be reached: the provider returned 401 on every attempt, so " +
  "this payout carries no proposal.";

function abstaining(overrides = {}) {
  return {
    live: true,
    model: "anthropic/claude-sonnet-5",
    criticModel: "anthropic/claude-haiku-5",
    attempts: 3,
    proposals: [],
    noProposalReason: "The records do not tell the two deposits apart.",
    resolvedFigures: {},
    ...overrides,
  };
}

test("reached, unreachable and unrecorded are three answers and three sentences", () => {
  const reached = modelReachView(abstaining({ modelReached: true, unreachableReason: null }));
  assert.equal(reached.state, "reached");
  assert.match(reached.sentence, /A model was consulted/);

  const failed = modelReachView(abstaining({ modelReached: false, unreachableReason: UNREACHABLE }));
  assert.equal(failed.state, "unreachable");
  assert.equal(failed.sentence, UNREACHABLE, "the engine's own reason was replaced by this app's");

  const silent = modelReachView(abstaining());
  assert.equal(silent.state, "unrecorded");
  assert.match(silent.sentence, /Nothing recorded whether a model was reached/);

  const sentences = new Set([reached.sentence, failed.sentence, silent.sentence]);
  assert.equal(sentences.size, 3);
  // The one thing none of the other two may say.
  for (const view of [failed, silent]) {
    assert.doesNotMatch(view.sentence, /A model was consulted on this payout and returned no proposal/);
  }
});

test("a model that did not answer is never described as having been consulted", () => {
  for (const truthy of ["true", 1, "yes"]) {
    const view = modelReachView(abstaining({ modelReached: truthy }));
    assert.equal(view.state, "unrecorded", `modelReached = ${JSON.stringify(truthy)} was read as reached`);
  }
  assert.equal(abstentionView(abstaining({ modelReached: false, unreachableReason: UNREACHABLE })).consulted, false);
  assert.equal(abstentionView(abstaining()).consulted, false);
  assert.equal(abstentionView(abstaining({ modelReached: true })).consulted, true);
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 4 — proseProvenance.markedIn and echoes[].fieldLabel
 * ══════════════════════════════════════════════════════════════════════════ */

const PROSE = "The descriptor says settlement for invoice 4471, which I cannot verify.";
const RUN = "settlement for invoice 4471";

function scanned({ fieldLabel, markedIn, field = "reasoning" } = {}) {
  const start = PROSE.indexOf(RUN);
  return {
    kind: "explain_integrity_break",
    kindLabel: "Why the parts do not sum",
    reasoning: PROSE,
    confidence: "suggest",
    status: "queued",
    evidence: [{ recordId: "btx_1", relevance: "the deposit", quote: RUN }],
    proseProvenance: {
      measured: true,
      notMeasuredReason: "",
      method: "Literal comparison.",
      limits: "This finds repeated WORDING and nothing else.",
      reading: "One span of this text repeats wording that arrived in payer-supplied fields.",
      markedIn,
      sources: [{ recordId: "btx_1", field: "descriptor", text: RUN, why: "A bank descriptor." }],
      echoes: [
        {
          field,
          fieldLabel,
          start: field === "reasoning" ? start : 0,
          end: field === "reasoning" ? start + RUN.length : RUN.length,
          text: RUN,
          sourceRecordId: "btx_1",
          sourceField: "descriptor",
          detector: "phrase",
        },
      ],
    },
  };
}

test("the engine's per-field label names a field this app has never heard of", () => {
  // THE UPGRADE `fieldLabel` EXISTS FOR. A prose field shipped after this file was
  // written would otherwise print as "a field this screen has no name for
  // (suspected_root_cause)". The engine knows its own vocabulary; this takes its word.
  const labelled = wordingView(scanned({ field: "suspected_root_cause", fieldLabel: "the suspected root cause" }));
  assert.deepEqual(labelled.fieldsLabelled.map((f) => f.label), ["the suspected root cause"]);
  assert.deepEqual(labelled.marked.map((m) => m.label), ["the suspected root cause"]);
});

test("an unmeasured block has no location to print at all", () => {
  const view = wordingView({ proseProvenance: { measured: false, notMeasuredReason: "Nobody looked." } });
  assert.equal(view.state, "unchecked");
  assert.equal(view.markedIn, "");
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 4b — A CONTROL WITH NOTHING TO SEND IS NOT A CONTROL
 * ══════════════════════════════════════════════════════════════════════════ */

/* ══════════════════════════════════════════════════════════════════════════ *
 * 5 — THE RESIDUAL: the approvals QUEUE CARD, not just the detail pane
 * ══════════════════════════════════════════════════════════════════════════ */

test("a queue card says what the agent did about this payout, on every card", () => {
  assert.equal(agentQueueLine(null).state, "not-asked");
  assert.match(agentQueueLine(null).text, /No model was asked/);
  assert.equal(agentQueueLine(abstaining({ proposals: [{}] })).text, "1 proposal awaiting review");
  assert.equal(agentQueueLine(abstaining({ proposals: [{}, {}] })).text, "2 proposals awaiting review");
  assert.match(agentQueueLine(abstaining({ modelReached: true })).text, /looked and proposed nothing/);
  assert.match(agentQueueLine(abstaining({ modelReached: false })).text, /could not be reached/);
  assert.match(agentQueueLine(abstaining()).text, /whether it answered is not recorded/);

  // FIVE ANSWERS, NONE OF THEM SILENCE, AND NO TWO THE SAME. The residual was that two
  // of these — "a model looked and declined" and "no model was ever asked" — were both
  // rendered as an absent phrase.
  const texts = [
    agentQueueLine(null).text,
    agentQueueLine(abstaining({ proposals: [{}] })).text,
    agentQueueLine(abstaining({ modelReached: true })).text,
    agentQueueLine(abstaining({ modelReached: false })).text,
    agentQueueLine(abstaining()).text,
  ];
  assert.equal(new Set(texts).size, 5, "two of the five queue-card answers read the same");
  for (const t of texts) assert.ok(t && t.trim().length > 0, "a queue card answer was left blank");
});

/**
 * AN ABSTAINING PAYOUT, BUILT INTO THE PAYLOAD THE CARD ACTUALLY READS.
 *
 * The committed export contains no abstention — tests/abstention.test.js asserts that
 * outright and builds its own for the same reason. `EngineProvider` refuses an
 * injected payload in static mode (lib/engine-context.js), so `ENGINE` here IS the
 * object the provider serves and the payout is added to it in this file's own process;
 * node's runner gives every file its own.
 *
 * That is what makes the assertions below run through the card's REAL call site —
 * `agentQueueLine(agentFor(useEngine(), payout.id))` — rather than through a prop a
 * test handed it. A mutation that deletes the call site and leaves `agentQueueLine`
 * perfect keeps the unit test above green. It does not survive this one.
 */
const OPEN_PROPOSAL = {
  proposalId: 1,
  kind: "explain_integrity_break",
  kindLabel: "Why the parts do not sum",
  status: "queued",
  reasoning: "A reading of the records.",
  evidence: [],
};
const DISMISSED_PROPOSAL = { ...OPEN_PROPOSAL, status: "dismissed" };

function installAbstainingPayout(id, agent) {
  const donor = ENGINE.reconciliations[ENGINE.payoutIds[0]];
  const recon = structuredClone(donor);
  recon.payout = { ...recon.payout, id, currency: "AUD", amount: 550000, status: "paid" };
  const a = `${id}_bp_1`;
  const b = `${id}_bp_2`;
  recon.tie = { status: "ambiguous", candidates: [a, b] };
  recon.exceptions = [
    {
      type: "bank_unmatched",
      severity: "needs_action",
      detail: "Paid, but 2 deposits match equally well.",
      suggestedAction: "Pick the correct deposit.",
    },
  ];
  recon.agent = agent;
  ENGINE.reconciliations[id] = recon;
  ENGINE.payoutIds.push(id);
  // The two deposits the tie is ambiguous BETWEEN. Without them `payoutStatus` builds
  // no queue entry for this payout at all, and the card under test never renders.
  ENGINE.bankLines.push(
    { id: a, date: "2026-08-07", amount: 550000, description: "TRANSFER FROM ACME PTY LTD REF 88213", matchedPayoutId: null },
    { id: b, date: "2026-08-08", amount: 550000, description: "DEPOSIT REF 88213 ACME", matchedPayoutId: null }
  );
}

installAbstainingPayout("SP-SILENT", abstaining({ live: false }));
installAbstainingPayout("SP-DOWN", abstaining({ live: false, modelReached: false, unreachableReason: UNREACHABLE }));
// The same payout twice over, with its one proposal open on the first and DECIDED on
// the second. Installed here with the others because `feedsFor()` memoises the payout
// feeds against this payload the first time anything renders, so a payout added after
// the first render exists in `reconciliations` and never reaches `PAYOUTS`.
installAbstainingPayout("SP-OPEN", abstaining({ live: false, proposals: [OPEN_PROPOSAL] }));
installAbstainingPayout("SP-DECIDED", abstaining({ live: false, proposals: [DISMISSED_PROPOSAL] }));

/**
 * THE FOUR PAYOUTS ABOVE ARE SCAFFOLDING, AND EVERY QUESTION THIS FILE ASKS ABOUT "THE
 * EXPORT" HAS TO EXCLUDE THEM.
 *
 * They are pushed onto the SHARED payload — `STATIC_ENGINE`, the object the provider
 * serves — because a clone never reaches the component's `useEngine()` call. Nothing
 * removes them afterwards and nothing should: they have to still be there when the
 * tests below render them.
 *
 * The cost is that `allPayoutIds(ENGINE)` stops meaning "the corpus" in this file from
 * line 772 onward. Three enumerations here mean the corpus — the payout with no agent
 * block, the payout with a proposal, and REJECTABLE — and all three now ask
 * `committedPayoutIds`, which answers from a snapshot taken before this file's body ran
 * (tests/_harness/corpus.js). They read correctly today by luck: `.find` returns the
 * first match and the injected ids are appended last, so the real corpus is reached
 * first. Luck about ordering is not a property worth depending on, and the sibling file
 * was maintaining the same exclusion BY HAND against a single id.
 *
 * This test is the positive control for that snapshot. It fails the moment an injected
 * payout reaches an enumeration that means the export.
 */
test("PRECONDITION: this file's injected payouts are not part of the committed corpus", () => {
  const injected = injectedPayoutIds(ENGINE);
  assert.deepEqual(
    [...injected].sort(),
    ["SP-DECIDED", "SP-DOWN", "SP-OPEN", "SP-SILENT"],
    "this file injected a payout the corpus guard does not know about — add it here, and " +
      "check every enumeration below that means the export"
  );

  const corpus = committedPayoutIds(ENGINE);
  assert.equal(
    corpus.length,
    COMMITTED_PAYOUT_IDS.length,
    "the corpus enumeration lost or gained a payout"
  );
  assert.equal(
    ENGINE.payoutIds.length,
    corpus.length + injected.length,
    "a payout is neither committed nor injected, which cannot happen"
  );
  for (const id of injected) {
    assert.ok(!corpus.includes(id), `${id} was installed by this file and is being counted as the export`);
  }
  // Export ORDER is preserved, not just membership — `.find()` on the corpus has to
  // return what it returned before anything was injected.
  assert.deepEqual(corpus, [...COMMITTED_PAYOUT_IDS], "the corpus came back reordered");
});

/* ══════════════════════════════════════════════════════════════════════════ *
 * 6 — A DECIDED PROPOSAL IS NOT AN OPEN ONE, ON ALL FOUR SURFACES
 * ══════════════════════════════════════════════════════════════════════════ */

test("a recorded decision is a decision, and null is not one", () => {
  // `isDecidable` is NOT this question inverted. It answers "may a control be
  // offered" and is true only of a durable `queued` row; the committed export's
  // proposals carry `status: null`, because a replayed transcript has no queue row
  // behind it, and those are proposals NOBODY HAS DECIDED. Reading them as decided
  // would empty the showpiece's queue with a shrug.
  const of = (...statuses) => undecidedProposals(statuses.map((status) => ({ status })));
  assert.equal(of("queued").length, 1);
  assert.equal(of(null).length, 1, "an undecided proposal with no status was counted as decided");
  assert.equal(of(undefined).length, 1);
  assert.equal(of("something-a-store-invented").length, 1, "an unknown status invented a decision");
  assert.equal(of("accepted").length, 0);
  assert.equal(of("dismissed").length, 0);
  assert.equal(of("queued", "dismissed", "accepted", null).length, 2);
  assert.deepEqual(undecidedProposals(null), []);
});

// ─────────────────────────────────────────────────────────────────────────────
// A WITHDRAWN ENTRY IS NOT ONE THAT IS READY TO GO
// ─────────────────────────────────────────────────────────────────────────────
// FOUND IN A BROWSER, SIGNED IN AGAINST THE API, 2026-08-23. A payout was rejected
// from this pane. The verdict plate said "Rejected — the draft entry was withdrawn".
// The ERP tab on the SAME PANE, under the heading "State", said "Ready to stage".
//
// `rejected` was already computed at the top of ApprovalDetail and already read by
// the plate; the destination chain simply had no branch for it and fell through to
// its default. The recurring shape on this project exactly: a perfect value, and a
// call site that does not consult it.
//
// THE CHECKPOINT IS ADDED TO THE SHARED PAYLOAD AND TAKEN OFF AGAIN. A structuredClone
// does not work here and the reason is worth writing down: `ps` would come from the
// clone but the component reads `useEngine()`, which under the render harness is
// STATIC_ENGINE — so the clone's `state` never reaches `recorded` and the test passes
// against unchanged code. It cost a green run to notice.

// ─────────────────────────────────────────────────────────────────────────────
// AND THE REGISTER'S OWN EXPANDED ROW SAID NEITHER OF THOSE THINGS
// ─────────────────────────────────────────────────────────────────────────────
// THE SAME DEFECT AGAIN, ONE SURFACE OVER, FOUND IN A BROWSER SIGNED IN AGAINST THE
// API ON 2026-08-25. The two tests above fixed the approvals PANE. /payouts — the
// register, the surface every exception row's "View payout" link opens — had no branch
// for a rejection at all, on either of the two things it says:
//
//   · "Recent Activity → Draft entry" read "Staged", because `activityRows` computed it
//     from `verdict.ok` alone and `verdict` does not know about people. All six
//     deterministic checks pass on a rejected payout — rejection is a decision about
//     the entry, not a fault in it.
//   · The action slot offered a live, enabled "Approve & stage".
//
// Measured against a control on the live tenant: the expanded row of a payout the
// register recorded as `rejected` was BYTE-IDENTICAL to an untouched one, and the word
// "rejected" appeared nowhere on the page. Pressing the button sent
// `POST /approvals/SP-9002/approve` and the engine answered 409 — "payout 'SP-9002'
// cannot move 'rejected' → 'approved'. Legal from 'rejected': (none — terminal state)".
// The outcome strip reported that refusal correctly and in full, which is exactly the
// trap: a well-worded refusal is not the same as the button being right, and a reviewer
// only sees it after pressing.

// ─────────────────────────────────────────────────────────────────────────────
// AND NEITHER IS AN ENTRY THE ENGINE WILL NOT ACCEPT AN APPROVAL FOR
// ─────────────────────────────────────────────────────────────────────────────
// THE SAME DEFECT AS THE ONE ABOVE, ONE STATE OVER, FOUND THE ROUND AFTER IT.
// In a browser, signed in against the API, 2026-08-23: SP-9002 is `ingested`, which
// is where the sync worker leaves every payout it writes and which
// `PAYOUT_TRANSITIONS` does not permit `→ approved` from. The approve slot on that
// pane says so, in the sentence `notYetApprovableReason` returns — "there is no
// checked draft entry to sign … Approving now is not something the engine will
// accept" — and the ERP tab on the same pane, under "State", said "Ready to stage".
//
// That row is the one a reader checks before sending an entry to a ledger, so of the
// two claims the pane made about one entry, the wrong one was the load-bearing one.
// `notApprovableYet` was already computed at the top of the component and already
// read by the approve slot; the destination chain had no branch for it. A perfect
// value and a call site that does not consult it — the third time this exact shape
// has been found on this pane.
//
// The checkpoint is installed on the SHARED payload and removed in a `finally`, for
// the reason `asRejected` above gives: under the render harness `useEngine()` serves
// STATIC_ENGINE regardless, so a structuredClone never reaches the component.

// The loop "the destination row does not call a ${status} entry ready to stage" (two
// cases) rendered the approvals pane's destination row, deleted with the queue by G1
// (2026-09-30). The approve card withholds both states with lib/feeds.js's own sentence
// (tests/approve-affordance.test.js "CARD: the two states that reached the control…").
