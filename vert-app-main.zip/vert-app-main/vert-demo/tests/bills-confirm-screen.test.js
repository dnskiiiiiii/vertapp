// tests/bills-confirm-screen.test.js — WHAT THE REVIEW DRAWS FOR AN UNCONFIRMED SEND AND A POSSIBLE DUPLICATE
// ==============================================================================
// The page half of tests/bills-unconfirmed.test.js, rendered in static mode (the render
// harness mounts the static engine payload). An unconfirmed item invites approving again
// and never entry by hand; an unconfirmed outcome shows its words and no Xero link unless
// one was sent; an adopted earlier send reads like a send, with its link; a possible
// duplicate says why before its approve, which asks for a second press (the second press
// itself is a click, which server rendering cannot drive: its request is held in
// tests/bills-unconfirmed.test.js, and its wiring by the source check below).

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { render, textOf } from "./_harness/render.js";
import { read, stripComments } from "./_harness/source.js";
import BillReview from "../components/bills/BillReview.js";
import BillsScreen from "../components/bills/BillsScreen.js";
import { outcomeView, settledOutcome } from "../lib/bills-model.js";
import { ID, ID2, XERO_WRITES, item } from "./bills-fixtures.js";

const review = (it, outcome = null) => render(BillReview, { item: it, xero: XERO_WRITES, outcome, onItem() {}, onBack() {} });
const said = (text, re) => assert.match(text.replace(/’/g, "'"), re);

test("an unconfirmed item says so, invites approving again, and never entry by hand", () => {
  const it = item({ status: "unconfirmed", statusWords: "Couldn't confirm: check Xero", manualFields: [] });
  const text = textOf(review(it, settledOutcome(it)));
  said(text, /Couldn't confirm: check Xero/);
  said(text, /We couldn't confirm whether it reached Xero\. Check Xero before trying again\./);
  said(text, /Approving again looks in Xero first/);
  assert.match(text, /Approve and send to Xero as a draft/);
  assert.doesNotMatch(text, /enter (these|it) in Xero|by hand/i);
});

test("an unconfirmed outcome shows its words as written, with no Xero link unless one was sent", () => {
  const view = outcomeView({ status: "unconfirmed", words: "Xero didn't answer in time.", xeroUrl: null, manualFields: [] });
  const html = review(item({ status: "unconfirmed" }), view);
  said(textOf(html), /Xero didn't answer in time\./);
  assert.doesNotMatch(html, />Open in Xero/);
});

test("an earlier send found in Xero reads like a send, with its link", () => {
  const view = outcomeView({ status: "already_in_xero", words: "", xeroUrl: "https://go.xero.com/found", manualFields: [] });
  const html = review(item({ status: "sent" }), view);
  assert.match(textOf(html), /Sent to Xero as a draft/);
  assert.match(html, /href="https:\/\/go\.xero\.com\/found"[^>]*>Open in Xero/);
});

test("a possible duplicate says why before its approve, and its approve leads to a second press", () => {
  const it = item({ needsConfirm: true, confirmWords: "Acme's INV-1043 for $1,100.00 may already be in Xero." });
  const text = textOf(review(it));
  said(text, /Acme's INV-1043 for \$1,100\.00 may already be in Xero\./);
  assert.match(text, /Approve and send to Xero as a draft/);
  const src = stripComments(read("components/bills/BillReview.js"));
  // The second press's words say what will happen (live check, 29 Oct 2026); they are
  // lib/bills-model.js confirmStepOf's, drawn by BillReview.
  assert.match(src, /confirmStepOf\(confirming\.kind, xero\)\.button/);
  assert.match(src, /api\.approve\(item\.id, \{ confirmDuplicate: true, remember \}\)/);
  // The confirmed call is only in the second press's handler.
  const at = src.indexOf("api.approve(item.id, { confirmDuplicate: true, remember })");
  assert.equal(/async function (\w+)\(/.exec(src.slice(src.lastIndexOf("async function", at)))[1], "approveConfirmed");
  assert.match(src, /onClick=\{approveConfirmed\}/);
});

test("bulk leaves a possible duplicate out, and says to open it", () => {
  const list = { ok: true, items: [item({ needsConfirm: true, confirmWords: "Maybe a duplicate." }), item({ id: ID2 })], counts: {}, xero: XERO_WRITES, unreadable: 0 };
  const src = stripComments(read("components/bills/BillsScreen.js"));
  assert.match(src, /CONFIRM_IN_REVIEW_WORDS/);
  assert.match(src, /bulk\.confirm\.length/);
  assert.ok(textOf(render(BillsScreen, { initial: list })).length > 0);
  assert.equal(ID.length, 36);
});

/* ── verification review: check Xero before a retry ──────────────────────────── */

test("an unconfirmed item shows its check-Xero words and candidates, and its retry is an explicit 'I've checked Xero'", () => {
  const it = item({
    status: "unconfirmed",
    statusWords: "Couldn't confirm: check Xero",
    needsConfirm: true,
    confirmKind: "check_ledger",
    confirmWords: "The last send may have reached Xero. Look for INV-1043 before sending again.",
    candidates: [
      { invoiceId: "x1", invoiceNumber: "INV-1043", status: "DRAFT", xeroUrl: "https://go.xero.com/AccountsPayable/Edit.aspx?InvoiceID=x1" },
      { invoiceId: "x2", invoiceNumber: "INV-1043A", status: "DRAFT", xeroUrl: "https://evil.example/x2" },
    ],
  });
  const html = review(it, settledOutcome(it));
  const text = textOf(html);
  said(text, /The last send may have reached Xero\. Look for INV-1043 before sending again\./);
  assert.match(text, /INV-1043, draft/);
  assert.match(html, /href="https:\/\/go\.xero\.com\/AccountsPayable\/Edit\.aspx\?InvoiceID=x1"[^>]*>Open in Xero/);
  assert.doesNotMatch(html, /evil\.example/);
  const src = stripComments(read("components/bills/BillReview.js"));
  assert.match(src, /confirmStepOf\(confirming\.kind, xero\)\.button/);
  assert.match(read("lib/bills-model.js"), /I've checked Xero/);
  assert.match(src, /api\.approve\(item\.id, \{ checkedLedger: true, remember \}\)/);
  const at = src.indexOf("api.approve(item.id, { checkedLedger: true, remember })");
  assert.equal(/async function (\w+)\(/.exec(src.slice(src.lastIndexOf("async function", at)))[1], "approveConfirmed");
});

test("bulk leaves unconfirmed items out and says to check Xero", () => {
  const src = stripComments(read("components/bills/BillsScreen.js"));
  assert.match(src, /CHECK_XERO_IN_REVIEW_WORDS/);
  assert.match(src, /bulk\.checkXero\.length/);
});
