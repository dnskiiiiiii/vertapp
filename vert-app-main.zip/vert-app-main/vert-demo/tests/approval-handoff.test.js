// tests/approval-handoff.test.js — THE WALK BACK TO THE PAYOUT ON SCREEN
// ==============================================================================
// MEASURED IN A BROWSER, signed in as a live tenant against a real vert_connect on
// PostgreSQL, 2026-08-27. Resolving `unclassified_txn` on po_8Hm cost seven presses.
// Getting from there to the posted entry cost four more, and THREE of those four were
// the reviewer walking back to a record the product had never stopped knowing about:
// rail → Approvals, Next page, find the row, click it. The panel had just said, by
// name, "the close register now records this payout as awaiting approval" — and then
// offered no way to go and approve it.
//
// `approvalHandoff` is the fact that removes that walk. What it must NOT do is remove
// a signature, so every test below is about the two questions it asks before it
// answers, and about the one thing it is not allowed to become.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { approvalHandoff } from "../lib/assertions.js";
import { read, stripComments } from "./_harness/source.js";

// The engine's own state vocabulary, from `vert_engine/state/store.py`
// PAYOUT_TRANSITIONS. Approval is legal from exactly one of them — the same single
// state lib/feeds.js `notYetApprovableReason` is built around.
const ENGINE_STATES = [
  "ingested",
  "reconciled",
  "blocked",
  "awaiting_approval",
  "approved",
  "rejected",
  "posted",
];

const CLEAR_RUN = { state: "awaiting_approval", escalatedKinds: [] };

test("a payout the engine left awaiting approval, with nothing escalating, gets a route", () => {
  const route = approvalHandoff(CLEAR_RUN, "po_8Hm");
  assert.ok(route, "the one case this exists for produced no route");
  assert.equal(route.payoutId, "po_8Hm");
  assert.match(route.href, /^\/approvals\?payout=po_8Hm$/);
});

test("no other engine state gets a route, including the ones that look finished", () => {
  for (const state of ENGINE_STATES) {
    const route = approvalHandoff({ state, escalatedKinds: [] }, "po_8Hm");
    if (state === "awaiting_approval") {
      assert.ok(route, "the one approvable state was refused a route");
      continue;
    }
    assert.equal(route, null, `'${state}' was offered a route to an approval screen`);
  }
});

// THE UNREAD ZERO, in the one place where getting it wrong sends somebody to sign.
// A response that omits `escalatedKinds` has not said the payout is clear; it has said
// nothing. Reading absence as empty is this codebase's commonest false figure and this
// is the surface where it would end in a signature.
test("an ABSENT escalation list is not an empty one, and gets no route", () => {
  for (const run of [
    { state: "awaiting_approval" },
    { state: "awaiting_approval", escalatedKinds: null },
    { state: "awaiting_approval", escalatedKinds: undefined },
    { state: "awaiting_approval", escalatedKinds: "none" },
    { state: "awaiting_approval", escalatedKinds: 0 },
    { state: "awaiting_approval", escalatedKinds: {} },
  ]) {
    assert.equal(
      approvalHandoff(run, "po_8Hm"),
      null,
      `an unread escalation list (${JSON.stringify(run.escalatedKinds)}) was read as clear`
    );
  }
});

test("a payout still escalating something gets no route, however approvable its state reads", () => {
  for (const kinds of [["bank_unmatched"], ["gst_undetermined", "unclassified_txn"]]) {
    assert.equal(
      approvalHandoff({ state: "awaiting_approval", escalatedKinds: kinds }, "po_8Hm"),
      null,
      `a payout still escalating ${kinds.join(", ")} was offered a route`
    );
  }
});

test("a missing or unusable payout id gets no route rather than a link to nowhere", () => {
  for (const id of [null, undefined, "", "   ", 7, {}, []]) {
    assert.equal(approvalHandoff(CLEAR_RUN, id), null, `${JSON.stringify(id)} produced a route`);
  }
});

test("a missing run gets no route — a 200 on the assertion is not a fact about the payout", () => {
  for (const run of [null, undefined, "awaiting_approval", 1]) {
    assert.equal(approvalHandoff(run, "po_8Hm"), null, `${JSON.stringify(run)} produced a route`);
  }
});

test("the payout id is encoded into the href rather than concatenated raw", () => {
  const route = approvalHandoff(CLEAR_RUN, "po 8&Hm=x");
  assert.ok(route);
  assert.match(route.href, /^\/approvals\?payout=po%208%26Hm%3Dx$/);
  // The query must carry exactly one key. A smuggled second parameter is how a link
  // that only selects becomes a link that does something else.
  assert.equal(route.href.split("?")[1].split("&").length, 1);
});

// ── what the link is, and what it must never become ──────────────────────────

/* RE-POINTED BY G1, 2026-09-30. The three cases that read the drawing side —
 * components/exceptions/AssertionOutcome.js (the panel that drew the link),
 * components/approvals/ApprovalsScreen.js (which took `?payout=` as a request) and
 * app/approvals/page.js (which refused a repeated key) — retired with those files. The
 * agent workspace deleted the exceptions rail and the approvals queue (spec §12.1), and
 * `/approvals` is a config redirect to `/records?tab=entries`, which carries the query
 * string, so `approvalHandoff`'s href still lands on the entry's record sheet.
 *
 * What the three cases held is held again below, on the screen the link now lands on:
 * a requested id is a request (it opens a sheet only when the list has that payout),
 * and the landing screen can decide nothing (Records is evidence; no write reaches it). */

test("Records treats a requested payout id as a request, not an instruction", () => {
  const src = stripComments(read("components/records/RecordsScreen.js"));
  // The sheet opens on arrival only for an id the list itself contains.
  // Since P19 (DEMO-MONTH-u1) the list searched is every month's rows (a memo's
  // back-link names an entry of any month), through model.js deepLinkScope, which finds
  // the id among them or reports it not found; only a found row's id opens a sheet.
  assert.match(src, /const openOnArrival = linked\.found \? linked\.rowId : null;/,
    "a requested id is no longer checked against the list before it opens a sheet");
  assert.match(src, /useState\(\(\) => openOnArrival\)/);
  const model = stripComments(read("components/records/model.js"));
  assert.match(model, /const row = \(rows \|\| \[\]\)\.find\(\(r\) => r && \(r\.id === id \|\| r\.entryId === id\)\);\s*if \(!row\) return \{ period, moved: false, found: false \};/);
  const page = stripComments(read("app/records/page.js"));
  // A repeated ?payout= arrives as an array; only a single string is read.
  assert.match(page, /typeof value === "string" && value \? value : null/,
    "a repeated query key is no longer refused");
});

test("the screen the route lands on can decide nothing", () => {
  // The whole safety argument for shortening this path is that the signature itself was
  // not shortened. Records draws evidence; approving happens on a card in Month-end or a
  // conversation, one press, with its own gates.
  for (const file of ["components/records/RecordsScreen.js", "components/records/PayoutDetail.js", "app/records/page.js"]) {
    const src = stripComments(read(file));
    for (const verb of ["approveDraftEntry", "approveDraftEntries", "recordApproval", "postToApi", "useCardCommit", "lib/actions"]) {
      assert.doesNotMatch(src, new RegExp(verb.replace("/", "\\/")), `${file} has grown '${verb}' — the landing screen must stay read-only`);
    }
  }
});
