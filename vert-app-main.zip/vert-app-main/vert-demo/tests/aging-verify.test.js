// tests/aging-verify.test.js — THE VERIFICATION REVIEW OF THE REMINDERS (28 Oct 2026)
// ==============================================================================
// From the reviewer's probe (scratchpad aging_verify2.mjs) and items C, E and F:
//   C. a result comes back under the draft's own id, so it always finds its draft;
//   E. when the engine asks to confirm the recipient, the next press sends the yes even
//      if the address matches the draft's stored one, so the ask can't loop;
//   F. a test email that may have gone is "may have been sent", never an error.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { emailOf, resultKey, yesesNeeded } from "../components/chat/answer/reminders.js";
import { postEmailTest } from "../app/api/reminders/shared.js";

const DRAFT = {
  draftId: "r-1a2b3c4d5e6f7a8b", contactId: "c-acme", contactName: "Acme", currency: "AUD",
  to: "ap@acme.example", ledgerAddress: "ap@acme.example", subject: "s", intro: "i", closing: "c",
  invoices: [{ id: "1" }], needsConfirm: false, editable: true,
};

test("E: the engine's recipient ask is answered on the next press, whatever the stored address", () => {
  // The engine answered needs_confirm/recipient with the ledger's address now unknown.
  const asked = { ...DRAFT, ledgerAddress: null, mustConfirmRecipient: true };
  assert.equal(emailOf(asked, {}, { confirmRecipient: true }).confirmRecipient, true);
  // Even when the stored address still matches what is being sent to.
  const same = { ...DRAFT, mustConfirmRecipient: true };
  assert.equal(emailOf(same, {}, { confirmRecipient: true }).confirmRecipient, true);
  assert.equal(yesesNeeded(same, {}, { recipientOk: true }).recipient, false);
  // Without the engine's ask and with an unchanged recipient, no yes is sent.
  assert.equal(emailOf(DRAFT, {}, { confirmRecipient: true }).confirmRecipient, undefined);
});

test("C: a result under the draft's own id finds its draft; another id finds none", () => {
  assert.equal(resultKey({ draftId: DRAFT.draftId, contactId: "c-acme", currency: "AUD", status: "sent" }, [DRAFT]), DRAFT.draftId);
  assert.equal(resultKey({ draftId: "r-ffffffffffffffff", contactId: "c-acme", currency: "AUD", status: "sent" }, [DRAFT]), null);
  assert.equal(emailOf(DRAFT).draftId, DRAFT.draftId, "the draft's id goes back to the engine");
});

test("F: a test email the server didn't confirm is 'may have been sent'", async () => {
  const fetchImpl = async () => new Response(JSON.stringify({ status: "unknown", to: "books@demo.example", messageId: null, words: "The mail server didn't confirm the email; it may have been sent." }), { status: 200, headers: { "content-type": "application/json" } });
  const got = await postEmailTest({ base: "http://e", headers: {}, fetchImpl });
  assert.equal(got.ok, true);
  assert.equal(got.test.status, "unknown");
  assert.match(got.test.words, /may have been sent/);
});

test("D: Sent reminders says which drafted invoices were left out, in the engine's words", async () => {
  const { render, textOf } = await import("./_harness/render.js");
  const { default: SentReminders } = await import("../components/chat/answer/SentReminders.js");
  const html = render(SentReminders, { sends: { sends: [{ sendId: "s-1", contactId: "c-acme", contactName: "Acme", invoiceIds: ["1", "3"], dropped: [{ id: "2", why: "paid, or no longer overdue, in Xero since the draft" }], currency: "AUD", to: "ap@acme.example", ledgerAddress: "ap@acme.example", recipientEdited: false, bodyEdited: false, backend: "smtp", status: "sent", messageId: "m", words: "Left out 1 invoice paid, or no longer overdue, in Xero since the draft.", sentBy: "Sam", sentAt: "2026-10-28T09:00:00+00:00", subject: "s" }] } });
  assert.match(textOf(html), /Left out 1 invoice paid/);
});

test("390px: the Email for reminders sheet is lifted into <body>, above the phone top bar", async () => {
  // Live check, 29 Oct 2026: at 390 px the sheet's title and close sat under the top bar,
  // because the section it is drawn in is a stacking context (the `.skel-in` arrival
  // animation) that no z-index inside it can rise out of. components/ui/Portal.js is the
  // design-fix-2 answer (DA2-001): the sheet renders into <body>, on the one z scale.
  const { read, stripComments } = await import("./_harness/source.js");
  const src = stripComments(read("components/setup/ReminderEmail.js"));
  assert.match(src, /import \{[^}]*\bPortal\b[^}]*\} from "@\/components\/ui"/);
  assert.match(src, /<Portal>\s*<Sheet\b[^\n]*title="Email for reminders"[\s\S]*?<\/Sheet>\s*<\/Portal>/);
});

test("390px: every sheet on the Connections page is lifted into <body>, and no comment claims one is when it isn't", async () => {
  // The same cause as the Email for reminders sheet: every Connections sheet was drawn
  // inside a `.skel-in` section (app/connections/page.js), a stacking context the phone
  // top bar sits above. Each <Sheet> on the page now sits directly inside a <Portal>.
  const { read, stripComments } = await import("./_harness/source.js");
  for (const file of ["components/setup/ConnectionsList.js", "components/setup/ReminderEmail.js"]) {
    const src = stripComments(read(file));
    const sheets = (src.match(/<Sheet\b/g) || []).length;
    // A sheet drawn from a list carries its key on the Portal, the outermost element.
    const portalled = (src.match(/<Portal(?: key=\{[^\n]*\})?>\s*<Sheet\b/g) || []).length;
    assert.ok(sheets > 0, `${file} draws no sheet; this check covers nothing there`);
    assert.equal(portalled, sheets, `${file}: ${sheets - portalled} of its ${sheets} sheets are not portalled`);
    assert.equal((src.match(/<\/Sheet>\s*<\/Portal>/g) || []).length, sheets, `${file}: a <Portal> doesn't close right after its sheet`);
  }
  const titles = stripComments(read("components/setup/ConnectionsList.js"));
  for (const title of ['title="Connect Stripe"', "Reconnect", "Approved entries in", 'title="Bank account"', 'title="Import a bank statement"']) {
    assert.ok(titles.includes(title), `the sheet titled ${title} is gone; the check above no longer covers it`);
  }
  const css = read("components/setup/connections.css");
  assert.doesNotMatch(css, /which is portalled outside \.conn\. \*\//, "the stale 'portalled' comment is back");
});
