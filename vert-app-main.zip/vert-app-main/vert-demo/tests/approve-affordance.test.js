// tests/approve-affordance.test.js — THE APPROVE CONTROL, ON A PAYOUT THAT CANNOT BE
// ==============================================================================
// FOUND IN A BROWSER, SIGNED IN AS A LIVE TENANT AGAINST A REAL vert_connect ON
// POSTGRES, 2026-08-23. The approvals queue header read "0 approvable · 26 cannot be
// signed here" and the pane beside it offered "Approve draft entry", ENABLED. Pressing
// it produced, in front of a bookkeeper:
//
//     'SP-9002' cannot move 'ingested' → 'approved'.
//     Legal from 'ingested': ['blocked', 'reconciled'].
//
// A state-machine diagnostic with a Python list in it, from a press the same screen
// had already counted as impossible.
//
// THIS IS `blockedForDisplay`'s DEFECT, ONE STATE FURTHER ALONG. That function was
// added because a control was offered on a payout the engine had already blocked, and
// its fix was to let the database's `blocked` withhold it. But `vert_engine/state/
// store.py PAYOUT_TRANSITIONS` permits `→ approved` from exactly one state,
// `awaiting_approval`. `blocked`, `approved`, `rejected` and `posted` each had a
// branch on the pane; `ingested` and `reconciled` had none and fell through to a
// button.
//
// AND IT IS NOT A SEEDING ARTIFACT, which is the first thing this project asks of a
// finding. `ingested` is where `vert_connect/sync.py` leaves every payout it writes —
// reconciliation is a separate pass — so between a sync and a reconcile, an ordinary
// window on any live deployment, every payout in the queue sits in the state this
// control was offered in and refused from.

import "./_harness/register.js";
import test from "node:test";
import assert from "node:assert/strict";

import { blockedForDisplay, notYetApprovableReason } from "../lib/feeds.js";
import { read, stripComments } from "./_harness/source.js";

// Every payout state the engine has, from PAYOUT_TRANSITIONS. Approval is legal from
// exactly one of them.
const ENGINE_STATES = [
  "ingested",
  "reconciled",
  "blocked",
  "awaiting_approval",
  "approved",
  "rejected",
  "posted",
];

test("the two states that reached the control and could not use it now withhold it", () => {
  // THE REGRESSION, named by the exact status the live 409 carried.
  for (const status of ["ingested", "reconciled"]) {
    const reason = notYetApprovableReason({ status });
    assert.ok(reason, `a payout in '${status}' still reaches an approve control`);
    assert.ok(reason.length > 60, `'${status}' is withheld with no usable sentence`);
    // The sentence is for a bookkeeper, not a log. None of the engine's vocabulary.
    assert.doesNotMatch(reason, /awaiting_approval|→|\bLegal from\b|\[.*\]/, `'${status}' leaks the state machine`);
    assert.doesNotMatch(reason, new RegExp(`'${status}'`), `'${status}' quotes its own slug at the reader`);
  }
});

test("the one state an approval is legal from is not withheld", () => {
  // The mirror. A fix that withheld everything would be a product with no approve
  // control at all, which passes a "no false affordance" test and ships nothing.
  assert.equal(
    notYetApprovableReason({ status: "awaiting_approval" }),
    null,
    "the only approvable state was withheld — the control can never be reached"
  );
});

test("a status with its own branch on the pane is not given a second explanation", () => {
  // `blocked`, `approved`, `rejected` and `posted` are each rendered by their own
  // branch above this one. Returning a sentence for them would put two answers about
  // one payout on one pane, which is the surfaces-disagreeing failure.
  for (const status of ["blocked", "approved", "rejected", "posted"]) {
    assert.equal(
      notYetApprovableReason({ status }),
      null,
      `'${status}' has a branch of its own and was given a competing sentence`
    );
  }
});

test("every engine state is decided — none falls through unconsidered", () => {
  // A state added to the engine and not to the map is a state that gets an enabled
  // button again. This does not assert WHICH answer each gets; it asserts each was
  // thought about, by pinning the whole vocabulary against the two lists.
  const withheld = ENGINE_STATES.filter((s) => notYetApprovableReason({ status: s }));
  assert.deepEqual(
    withheld,
    ["ingested", "reconciled"],
    "the set of states that withhold the control has drifted from the engine's table"
  );
});

test("an unread status withholds nothing — absence is not a refusal", () => {
  // The static showpiece has no checkpoint at all. Withholding a control on a status
  // nobody fetched would be an unread absence rendered as a fact, which is the failure
  // this file's neighbours exist to prevent in the other direction.
  assert.equal(notYetApprovableReason(null), null);
  assert.equal(notYetApprovableReason(undefined), null);
  assert.equal(notYetApprovableReason({}), null);
  assert.equal(notYetApprovableReason({ status: null }), null);
  // And a word this build has never met is not given an invented explanation.
  assert.equal(notYetApprovableReason({ status: "quarantined" }), null);
});

test("the gate this replaces still holds — a blocked payout is still blocked", () => {
  // notYetApprovableReason must not have quietly taken over blockedForDisplay's job.
  assert.equal(blockedForDisplay({ status: "blocked" }, { blocked: false }), true);
  assert.equal(blockedForDisplay(null, { blocked: true }), true);
  assert.equal(blockedForDisplay({ status: "awaiting_approval" }, { blocked: false }), false);
});

// "the pane actually consults the gate before drawing the control" read
// components/approvals/ApprovalDetail.js, which G1 deleted on 2026-09-30 with the
// approvals queue (spec §12.1). Its assertion — the gate is asked, and asked before the
// control is drawn — is "CARD: the gate is consulted BEFORE the control is drawn" below,
// on the card that replaced the pane (count ledger: 1 case retired, covered).

/* ══════════════════════════════════════════════════════════════════════════ *
 * RE-POINTED AT THE DECISION CARDS (agent workspace, build plan §3 F3 acceptance 1).
 *
 * The approvals pane was superseded by components/cards/ApproveCard.js, and G1 deleted
 * the pane. The card must consult the same gate, and it must print the reason where the
 * control would have been (UI-014).
 * ══════════════════════════════════════════════════════════════════════════ */

import { render, textOf } from "./_harness/render.js";
import ApproveCard, { approveBlockedReason } from "../components/cards/ApproveCard.js";
import { STATIC_ENGINE } from "../lib/engine-source.js";
import { SAMPLE_REASON } from "../components/cards/words.js";
import * as CF from "./card-fixtures.js";

// A payload whose one payout carries a recorded checkpoint, as the API's register does.
function withRecorded(status) {
  const id = CF.OK_ID;
  const recon = { ...STATIC_ENGINE.reconciliations[id], state: { status } };
  return { engine: { ...STATIC_ENGINE, reconciliations: { ...STATIC_ENGINE.reconciliations, [id]: recon } }, id };
}

test("CARD: the two states that reached the control are withheld on the approve card too", () => {
  for (const status of ["ingested", "reconciled"]) {
    const { engine, id } = withRecorded(status);
    const reason = approveBlockedReason(engine, id);
    assert.equal(reason, notYetApprovableReason({ status }), `'${status}' is not withheld by the card`);
  }
  const { engine, id } = withRecorded("awaiting_approval");
  assert.equal(approveBlockedReason(engine, id), null, "the only approvable state was withheld on the card");
});

test("CARD: a withheld card draws no approve control and prints the reason in its place", () => {
  // The card is drawn from the static payload, so the gate is driven through the
  // verifier's own block: SP-BROKEN, $150.00 short.
  const html = render(ApproveCard, { action: CF.approveBroken() });
  const card = html.slice(html.indexOf("<article"), html.indexOf("</article>"));
  assert.ok(!card.includes("btn-commit"), "the approve control is drawn on a blocked payout");
  assert.match(textOf(card), /Can't approve until the \$150\.00 gap is explained\./);
});

test("CARD: the gate is consulted BEFORE the control is drawn", () => {
  const code = stripComments(read("components/cards/ApproveCard.js"));
  assert.match(code, /return notYetApprovableReason\(ps\.recorded\);/, "the card never asks");
  const gate = code.indexOf("actions={\n          blocked ? null");
  const button = code.indexOf('busyLabel="Approving…"');
  assert.ok(gate > 0 && button > gate, "the approve control is drawn outside the gate");
});

test("CARD, STATIC MODE: approve is disabled with its reason, never silently", () => {
  const html = render(ApproveCard, { action: CF.approve() });
  const button = html.match(/<button[^>]*btn-commit[^>]*>/);
  assert.ok(button, "the static card has no approve control at all");
  assert.match(button[0], /aria-disabled="true"/, "the static approve control is live");
  assert.doesNotMatch(button[0], /\sdisabled=""/, "native disabled hides the reason from keyboard and touch (UI-014)");
  assert.ok(textOf(html).includes(SAMPLE_REASON), "the disabled control carries no reason");
});
