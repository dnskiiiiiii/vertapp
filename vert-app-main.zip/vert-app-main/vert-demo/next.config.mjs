/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // The dev-tools badge sits in the same bottom-left corner as the sidebar's account
  // menu and renders under `next start` as well as `next dev` — off, full stop, on a
  // demo where that corner is meant to read as the client's own workspace.
  devIndicators: false,

  // THE UPLOAD LIMIT IS THE ENGINE'S, NOT THE PROXY'S (D37). Next 16 buffers every
  // request body that passes proxy.js and cuts it at 10 MB by default
  // (`proxyClientMaxBodySize`), so an 11.6 MB scanned PDF reached /api/documents
  // truncated, its multipart could not be parsed, and the composer said "Choose a file
  // to attach." The engine takes 25 MB (vert_engine/documents/intake.py
  // MAX_UPLOAD_BYTES; lib/documents.js refuses past it in words). 26 MB leaves room for
  // the multipart framing around a 25 MB file.
  experimental: {
    proxyClientMaxBodySize: "26mb",
  },

  // THE WORKING PAPER READS tokens.css (ui-pass-1 output-ui #29). lib/working-paper-html.js
  // inlines the theme's colours into the file it hands over, and reads them from
  // app/styles/tokens.css — the one place a colour is spelled — rather than keeping a
  // copy. A stylesheet is not something a route imports, so the server bundle's file
  // tracing is told to carry it with the paper's route.
  outputFileTracingIncludes: {
    "/reconciliation/papers/**": ["./app/styles/tokens.css"],
  },

  // WHERE THE OLD ADDRESSES GO (spec §12.2).
  // ------------------------------------------------------------------
  // The agent workspace has one destination, Month-end at `/`, plus the conversations,
  // with Records and Connections as evidence and a setting. Every address the earlier
  // builds served is still out in the world — in bookmarks, in a printed first-run
  // guide, in `?payout=<id>` deep links — so NOTHING MAY 404, and each old path is
  // redirected rather than dropped.
  //
  // EACH ONE GOES STRAIGHT TO ITS FINAL DESTINATION. The earlier list sent
  // /reconciliation to /payouts, which is itself redirected now; left alone that is a
  // chain of two hops, and a chain is how a loop gets written one edit later.
  // tests/redirects.test.js fails if any destination is itself a source.
  //
  // PERMANENT (308), not temporary: a 308 tells the browser and every crawler that
  // the resource MOVED, and it preserves the method and the query string — which is
  // what keeps /payouts?payout=<id> opening that payout's record in Records. A
  // destination that carries its own query (`?tab=entries`) has the incoming query
  // merged into it by Next, so `?payout=` survives there too.
  //
  // The list is EXACT, never a wildcard. There are still real routes under
  // /reconciliation — the working paper (`papers/[payoutId]`, with its workbook) and
  // the bank rec workbook (`bank/xlsx`) — and a wildcard would swallow them
  // (tests/config-surface.test.js).
  //
  // /chat and /close used to redirect from their own page files with `redirect("/")`.
  // That was a bounce, not a redirect: the root app/loading.js wraps every page in a
  // Suspense boundary, so the call was STREAMED — the browser got a 200 for /close,
  // hydrated, and was navigated to `/` on the client one to four seconds later. A
  // page.goto() issued in that window was "interrupted by another navigation to /"
  // (round-3 D6). Here they are real 308s answered before any page renders, and the
  // page files are gone so nothing can shadow or duplicate them.
  async redirects() {
    return [
      // The five register areas, and the setup errand.
      { source: "/payouts", destination: "/records", permanent: true },
      { source: "/approvals", destination: "/records?tab=entries", permanent: true },
      { source: "/exceptions", destination: "/records?filter=needs-you", permanent: true },
      // The bank rec form became a task on Month-end: the row opens there.
      // Month-end's close list carries the bank rec's row (route audit, 8 Nov 2026): `?task=` was read by nothing.
      { source: "/reconciliation/bank", destination: "/", permanent: true },
      { source: "/setup", destination: "/connections", permanent: true },
      // The old Close page is Month-end; there is no conversation index (spec §2.1).
      { source: "/close", destination: "/", permanent: true },
      { source: "/chat", destination: "/", permanent: true },
      // Pages the new shell deleted: they go to the one page there is.
      { source: "/command", destination: "/", permanent: true },
      { source: "/insights", destination: "/", permanent: true },
      { source: "/checklist", destination: "/", permanent: true },
      // The older generation (2026-08-18), rewritten to the final destination.
      { source: "/reconciliation", destination: "/records", permanent: true },
      { source: "/reconciliation/payments", destination: "/records", permanent: true },
      { source: "/reconciliation/approvals", destination: "/records?tab=entries", permanent: true },
      { source: "/reconciliation/exceptions", destination: "/records?filter=needs-you", permanent: true },
      { source: "/settings", destination: "/connections", permanent: true },
      // SCHEDULED (scheduled-spec.md, founder approved 31 Oct 2026): Bills & invoices and
      // Journals stopped being modules. The inbox is the Bills & invoices task's sheet;
      // one bill's review stays at /bills/<id>, so an old `?item=<id>` link (the chat's)
      // goes straight there. Journal entries are Records' Journal entries view.
      { source: "/bills", has: [{ type: "query", key: "item", value: "(?<item>[0-9a-fA-F-]{36})" }], destination: "/bills/:item", permanent: true },
      { source: "/bills", destination: "/scheduled?task=bills", permanent: true },
      { source: "/journals", destination: "/records?tab=entries", permanent: true },
    ];
  },
};

export default nextConfig;
