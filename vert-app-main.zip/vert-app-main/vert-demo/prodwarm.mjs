import { chromium } from 'playwright';
const KEY = process.argv[2], BASE = 'https://vert-platform.vercel.app';
const b = await chromium.launch(); const p = await b.newPage();
const errs=[]; p.on('pageerror',e=>errs.push(e.message.slice(0,90)));
await p.goto(BASE+'/login',{waitUntil:'domcontentloaded'});
await p.fill('input[name="apiKey"]', KEY);
const t0=Date.now();
await Promise.all([p.waitForURL(u=>!u.pathname.includes('login'),{timeout:120000}), p.click('button[type="submit"]')]);
console.log(`  sign in                          ${((Date.now()-t0)/1000).toFixed(1)}s`);
const paths=['/payouts','/approvals','/exceptions','/connections'];
for (const path of paths) await p.goto(BASE+path,{waitUntil:'domcontentloaded',timeout:120000});
console.log('  --- warm ---');
for (const path of paths) {
  const t=Date.now();
  await p.goto(BASE+path,{waitUntil:'domcontentloaded',timeout:120000});
  await p.waitForLoadState('networkidle',{timeout:60000}).catch(()=>{});
  console.log(`  ${path.padEnd(32)} ${((Date.now()-t)/1000).toFixed(1)}s`);
}
console.log('  errors:', errs.length? errs.slice(0,3) : 'none');
await b.close();
