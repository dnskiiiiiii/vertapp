# Product

## Register

product

## Users

Finance managers, controllers and bookkeepers at Australian e-commerce and CPG
brands turning over $1M–$50M. They sell through Shopify, take payment via
Shopify Payments, Stripe, PayPal and BNPL, and keep their books in **Xero first**,
then QuickBooks Online (NetSuite/Sage later).

> **Changed 2026-10-17: approved entries are POSTED in Xero by default.** Founder
> decision, per client, and it amends the "arrives as a draft" fact below. On
> Connections, the connected Xero row's sheet asks "When you approve an entry": "Post
> it to Xero" (the default: in the reports straight away; a correction is Vert's
> reversing entry, never a void) or "Send it as a draft" (someone in Xero approves it
> first, which is the 2026-10-16 behaviour). The engine stores it on the connection
> (`postMode`) and `/approvals/ledger`'s `createsDraft` and `postingEffect` follow it,
> so every post action is labelled from `createsDraft` — "Post to <ledger>" when false,
> "Send to <ledger> as draft" when true — with `postingEffect` beside the button.
> Never hard-code "Post to <ledger>".
>
> **Changed 2026-10-16: Xero is Vert's first ledger.** Founder decision, and it
> supersedes the Xero half of the 2026-08-06 note below, which took Xero out of the V1
> path. QuickBooks Online stays supported, and a tenant connects one ledger or the
> other, never both. Where a screen offers a choice of ledger, Xero is listed first. Two Xero
> facts every screen must keep straight, in plain words: a journal Vert sends to Xero
> arrives as a **draft** that someone in Xero approves before it reaches the reports;
> and Vert **cannot reconcile bank lines in Xero** (Xero allows no third-party app to),
> so Vert prepares the match and a person confirms it in Xero. Never write "automated
> bank reconciliation". The upmarket-ICP half of the 2026-08-06 note is untouched by
> this decision and is still open.
> One ledger per tenant is the engine's rule too: pressing Connect on the second ledger
> is refused before any consent starts, and the screen says which ledger is connected and
> the engine's way out (disconnect it first), calmly, as a fact about the books and not an
> error. Wherever a screen names "the ledger" (the budget sheet's Import, its "only read"
> line) it names the connected one, never QuickBooks by default.
>
> **Changed 2026-08-06, and it moves this section's own premise.** The team decided
> Xero is out of the V1 path (superseded 2026-10-16, above) and **the ICP moves upmarket** — so the "$1M–$50M Shopify
> brand" framing above is the *old* ICP and is now under revision. It has been left in
> place rather than rewritten on one agent's guess, because who the customer is, is a
> founder's call and not a documentation edit. **Whoever owns positioning should
> resolve this paragraph deliberately.**
>
> The design consequences below (density, alignment, reading down a column of figures)
> are unaffected — they follow from the *job*, not from company size, and hold at any
> point on that range.

Their context is month-end close, days three to seven, usually late. The job:
a payout landed in the bank and it does not equal sales. Someone has to prove
where every cent went — fees, refunds, chargebacks, reserves, GST — and draft
the entry that books it. Today that is spreadsheets, one processor at a time.

They read down a column of figures. Alignment, density and precision are
functional requirements, not taste.

## Product Purpose

Decompose each payout, prove the parts sum to the deposit to the cent, draft
the journal entry, and surface only what genuinely could not be resolved.

The product's boundary is deliberate and must be legible in the UI: Vert
decomposes, proves, drafts and stages. A person decides, and only then does an
entry reach the ledger.

### Where the gate sits, and why it moved (2026-08-06)

> **2026-10-16:** with Xero first again, both halves below are live, one per ledger.
> On a Xero tenant the ledger carries the second gate (the DRAFT); on a QuickBooks
> tenant the approval in Vert is the only gate. The screens read which from the API's
> `createsDraft` on `/approvals/ledger`, never from the vendor's name.
> **2026-10-17:** on Xero the second gate is now the client's choice, and off by default
> (post mode, above): a Xero client on "post" has the QuickBooks half, the approval in
> Vert as the only gate. Still read from `createsDraft`, never from the vendor's name.

This used to read "Xero permanently blocks third parties from completing bank
reconciliation, so … a human clicks reconcile inside the ledger." That sentence
described a *safety model*, not just a vendor, and the safety model does not
survive the swap to QuickBooks. Restating it with the noun changed would be the
worst available outcome, so here is the difference in full.

**Xero** holds anything a connected application creates as a **DRAFT**. A human
still has to approve it inside the books, so the ledger itself carries a second
gate behind ours (`vert_engine/posting/xero.py` writes `Status: DRAFT` as a
constant, and refuses a response that says anything else).

**QuickBooks has no draft state.** A created `JournalEntry` is in the customer's
trial balance immediately; there is no flag to set and no header to send that
changes it. Measured against the live sandbox, and it is why
`vert_engine/posting/quickbooks.py` returns `status="posted"` rather than
`"draft"` — reporting a QBO write as a draft would tell a reviewer a human
gatekeeper exists where none does.

**What replaces the in-ledger DRAFT is structural, and it is weaker.** The live
poster (`QuickBooksJournalPoster`) is unreachable by default and cannot be
constructed without an HTTP client and an account mapping, so nothing arrives at
a live post by flipping a boolean; and the entry is idempotent on a
content-derived tag in `DocNumber`, searched for before every create, so a re-run
returns the existing entry instead of compounding a mistake. That is a guard
against *duplication and accident*, not a second human review. The UI has to say
so rather than paper over it.

So the requirement on the screens is unchanged but its content is not: the
boundary between "Vert proved it" and "a person filed it" must stay legible,
**and on QuickBooks the approval in Vert is the only gate there is.**

**Not researched, do not assert:** whether QuickBooks restricts a third party
from completing a bank reconciliation. The restriction we know of is Xero's
(`IsReconciled` is read-only, formally confirmed with that vendor) and it stays
with Xero.

**AU GST does not reach the ledger, and no screen may imply it does.** The engine
splits GST onto its own journal line, and that line books like any other mapped
liability. QuickBooks' own tax machinery — `GlobalTaxCalculation` and per-line
`TaxCodeRef` — is not implemented and is never sent: the sandbox the poster was
proven against is a US company, so no AU treatment could be exercised, and rather
than ship an untested guess the poster **refuses outright** any draft carrying a
`tax_ref` (`QuickBooksTaxUnsupported`). Nothing here touches a BAS or a GST
return.

**Name the vendor only where the vendor is the fact.** Everywhere else the copy
says *your ledger*. The `Poster` seam is one method so that the ledger is
replaceable (Xero first, then QuickBooks Online, then NetSuite/Sage); wording that
has to be re-edited on each swap is wording that is wrong in between.

Success is the accountant trusting a number without re-deriving it, and the
exception queue being short enough to work through.

## Brand Personality

Precise, plain-spoken, unhurried. Explains in the language an accountant
already uses, never in the language of the system that produced it.

The product should read as an instrument, not an assistant. It states what it
found and what it could not resolve. It does not celebrate, hedge, or narrate
its own cleverness.

## Anti-references

- **Developer tooling.** Monospace as a default, JSON on screen, tool-name
  chips, method columns, architecture diagrams in the workflow. The product's
  internals are not the product. This is the current build's worst failure.
- **Enterprise accounting software** (BlackLine, FloQast). Density without
  hierarchy, grey on grey, every element the same weight.
- **Generic AI product.** Purple gradients, sparkle icons, chat framing,
  "thinking" shimmer. Reads as a demo rather than an instrument.
- **Consumer fintech.** Oversized numbers, playful illustration, one fact per
  card, whitespace where density belongs.

## Design Principles

1. **The result leads; the method follows.** Show the decomposition, the
   tie-out and the entry first. How it was worked out is available, never in
   the way.
2. **Say it in one sentence before saying it in a table.** Every screen opens
   with the finding in plain English, then substantiates it.
3. **Speak accounting, not architecture.** "Ties out to the cent", not
   "6 checks replayed". Never surface a tool name, a step count, or a
   confidence weight to a user who did not ask.
4. **Refusal is a feature, and must read as care.** When an entry does not
   balance, say what is unexplained and what to do about it. Never a wall of
   red.
5. **Figures are the interface.** Tabular numerals, right-aligned, columns
   aligned down the page. Nothing decorative competes with a number.

## Accessibility & Inclusion

WCAG 2.1 AA. Body text ≥4.5:1, large text ≥3:1 — the current build fails this
on citation chips and step meta at 2.96:1.

Status must never be carried by colour alone; pair every state with a label.
Full keyboard reach on the approval path. All motion honours
`prefers-reduced-motion`, including the streaming trace.
