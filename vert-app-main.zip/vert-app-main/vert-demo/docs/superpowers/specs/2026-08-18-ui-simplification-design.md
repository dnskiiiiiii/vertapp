# Vert platform UI — simplification design

**Date:** 2026-08-18
**Status:** approved (approach B — recompose screens, keep the parts)
**Branch:** `ui-redesign` · revert point: tag `pre-ui-redesign`

## The problem

The complaint is five weeks old and has been made three times:

- 2026-07-29 — "the ui is very bad right now and cognitive heavy, we need to simplify
  things and make them more straightforward"
- 2026-08-15 — "everything should be in the ui right, why is it still living in
  separate places... the product is everything in one place with visible value"
- 2026-08-17 — "why do i have to select all these", "it is asking me to fill in
  everything. it is too much work for a real client", "a non technical client
  wouldnt be doing all this would they"

It has never been actioned. This document is the design that actions it.

## What is NOT the problem

`DESIGN.md` is a rigorous, pixel-sampled system derived from 38 reference screens, and
the styling honours it. The leaf components — `PayoutRow`, `PayoutTable`,
`AccountingFigure`, `JournalEntry`, the pills, the confidence bar — are good work.

**None of that is being rewritten.** `DESIGN.md` remains the visual authority. Every
value in it (true-black rail, white ground, `#4F1FE8`, 46–48px rows, green = a human
verified / violet = the machine completed) is preserved. Anything below that appears to
conflict with `DESIGN.md` is a defect in this document, not a licence to change tokens.

## What IS the problem

Screen-level composition and information architecture. Evidence, captured from
`vert-platform.vercel.app` on 2026-08-18 against tenant `vansh-live`:

1. **The app opens on its emptiest surface.** `/reconciliation` renders a clearing
   table whose second row is entirely blank, then "No trial balance is shown" and a
   three-line apology. The real work — 5 KPIs and 3 payouts — is the third tab.
2. **Four of five nav areas are empty.** Command, Insights, Checklist, Chat render a
   centred sentence on a blank page. The rail's most prominent control, the white
   `+ New Chat` plate, leads to one of them.
3. **Numbers contradict each other on one screen.** Approvals reads "3 draft journal
   entries" (header), "Approval queue 1" (panel), "1—1 of 1" (pager), over chips
   reading Pending(1) High risk(2) JE(3) Recs(1) Payments(0) Me(0) Confident(1).
4. **Rendering bugs are live in production.** Body text overlaps the "Post to
   QuickBooks Online" button; the Similar-approvals card collides ID and amount into
   `po_1U3Q3yFmEcBJEdOP$1,058.29`; a ~500px void sits mid-page.
5. **Chrome overwhelms content.** Exceptions puts 3 rows behind 5 dropdowns, a filter
   icon, an export icon, a search field, bulk checkboxes and a pager.
6. **Four navigation levels to one decision.** rail → tabs → filter chips → evidence
   sub-tabs.
7. **Settings is undeclared onboarding.** One 1800px scroll containing connections,
   six free-text "start typing an account name" boxes, a two-step CSV upload, a
   *duplicate* Connections section, and a raw `HTTP 500` string. Nothing points a new
   user to it.
8. **The code has drifted from itself.** `ReconcileTabs.js:9-13` states in prose that
   Payments was removed and scope is three tabs; the array below renders four.

## Decisions taken

| # | Decision | Chosen |
|---|---|---|
| 1 | The four empty nav areas | **Keep, visibly disabled.** Roadmap stays legible for pitching; dead clicks stop. |
| 2 | Reconciliation tabs | **Three tabs, Payouts first.** Drop Reconcile; rename Payments → Payouts; it becomes the landing tab. |
| 3 | Approvals detail density | **Verdict first, evidence on demand.** Decision above the fold; workings collapse into one openable section. |
| 4 | Settings / onboarding | **Guided setup, then a quiet Settings.** Three gated steps; account dropdowns from the QBO chart, not free text. |
| 5 | Who we optimise for | **Both, tester-first.** A product that works cleanly demos well by itself. |

## Design

### 1. The rail

Five items become four live destinations plus a disabled group.

```
  Payouts          3        ← live, carries the exception counter
  Approvals        1        ← live
  Exceptions       3        ← live
  Connections               ← live (was Settings)
  ─────────────────────
  Coming later
  Command          ·        ← disabled, not a link
  Insights         ·
  Checklist        ·
  Chat             ·
```

- Disabled items render as `<span>`, never `<a>` — not a link with
  `pointer-events: none`, which still reaches the keyboard. `aria-disabled="true"`,
  removed from tab order, with `title` carrying the one-sentence description already
  written in `ia.js` `AREAS`. Those sentences are kept verbatim; they are good copy and
  they are the roadmap story.
- **`+ New Chat` is removed.** It is the rail's single most prominent control and it
  leads to an unbuilt surface. It returns when Chat is built.
- `ia.js` stays the single source of the IA. It gains a `status: "live" | "later"`
  field; the rail, the routes and the placeholder pages all read it, so the drift in
  item 8 above cannot recur.
- The `⌘K` search chrome is removed. Nothing stands behind it.
- The user block shows the tenant as primary text. `USER.name` ("Alex Morgan") is
  authored demo data appearing on a live tenant; where a session exists, the tenant is
  the truth and is shown first.

### 2. Routes

| Now | After | Why |
|---|---|---|
| `/` → `/reconciliation` | `/` → `/payouts` (or `/setup` when unconfigured) | Land on work, or on the thing that unblocks work |
| `/reconciliation` (Reconcile) | **removed** | It needs a general ledger the build does not read; it can only apologise |
| `/reconciliation/payments` | `/payouts` | The real register, promoted to landing |
| `/reconciliation/approvals` | `/approvals` | |
| `/reconciliation/exceptions` | `/exceptions` | |
| `/settings` | `/connections` | Says what it is |
| — | `/setup` | New: the guided first run |
| `/command` `/insights` `/checklist` `/chat` | kept, unreachable from the rail | Direct URLs still resolve; they explain themselves |

Old paths issue permanent redirects to their new homes so the tester's existing links,
the PDF first-run guide, and `walk.mjs` do not break.

The tab strip disappears: four rail destinations replace rail-plus-tabs, removing one
whole navigation level. The clearing-account tie-out from the deleted Reconcile tab
moves onto `/payouts` as a summary strip above the register — the figures survive, the
apology does not.

### 3. `/payouts` — the landing surface

Keeps its current structure, which is the strongest screen in the product. Changes:

- The 5 KPI cards are cut to 3: **Payouts**, **Unexplained**, **Awaiting you**.
  "Reconciled 1 of 3" and "Confirmed at bank" are restated inside the register's own
  Status column and variance figures; a KPI that repeats the table below it is chrome.
- Filters (search, processor, status, view toggle, filter icon) render **only when the
  register exceeds 10 rows**. Three rows need no filtering apparatus. The pager and
  per-page control follow the same rule.
- The clearing-account strip sits above the register, and the "$2,481.20 sits in Stripe
  Clearing that the transaction detail cannot account for" sentence keeps its link.
- Empty state (a configured tenant with no payouts yet) states what will appear and
  when the next sync runs — never a bare "No data".

### 4. `/approvals` — verdict first

The queue pane keeps the 3-pane model from `design-refs/approvals.jpg`, with the seven
filter chips cut to three: **Awaiting you · Blocked · Done**. Chips whose count is zero
are not rendered. The queue heading, the pager and the page header state **one** count,
computed once and threaded — the contradiction in item 3 is a state bug, not a copy bug,
and is fixed at the source.

The detail pane is restructured so the decision is above the fold:

```
Stripe payout — po_1U1FWY…                      [ ⋯ ]
──────────────────────────────────────────────────────
  ✓ Balances to the cent. All 6 checks agree.
    99% confidence · drafted by Vert

    Stripe Clearing            $916.15
    Payment Processing Fees     $33.85
    Product Revenue                      $950.00
    ──────────────────────────────────────────
                   Σ $950.00   Σ $950.00

    [ Post to QuickBooks Online ]

  ▸ Show the workings
      6 checks · financial impact · 2 transactions
      · ERP · attachments · audit trail
```

- Confidence is stated **once**. It currently appears three times.
- The 7 "Vert's checks" bullets, each reading "agrees", collapse to one line —
  "All 6 checks agree" — expanding to the full list inside the workings. Nothing is
  deleted; the audit trail stays complete and reachable. Any check that does **not**
  agree is promoted out of the collapsed section and shown at the top, because that is
  the case a human must act on.
- The 5-tab evidence drawer moves inside the workings section, so the page has one
  navigation level, not two.
- The QuickBooks explanation ("QBO has no draft state…") moves to a hover/expand on the
  post button rather than three paragraphs beneath it. It is important and it is not
  what a returning user reads every time.
- **Layout bugs fixed:** the overlap on the post button, the ID/amount collision in
  Similar approvals, and the mid-page void.

### 5. `/exceptions`

Same rule as `/payouts`: filter chrome renders only above 10 rows. Three exceptions
render as three rows with a search field and nothing else. The "Ledger and bank-feed
exceptions are not listed" note is kept — it is honest — but set as a single muted line,
not a three-line paragraph competing with the table.

### 6. `/setup` — guided first run

Three steps, gated, resumable, each writing through the existing `components/settings/`
actions. No new server behaviour: this is a new composition over `actions.js`,
`ProviderCard`, `ChartMapping` and `StripeConnectForm`, which already work.

```
Set up Vert                                  Step 2 of 3
─────────────────────────────────────────────────────────
 ✓ 1. Connect Stripe                     acct_1U1CTb…
 ● 2. Connect QuickBooks
       → sends you to Intuit and comes back
   3. Map your accounts                  0 of 3 required
```

- **Step 3 replaces six free-text boxes with dropdowns populated from the connected
  QuickBooks chart of accounts,** pre-selected on exact name match. This is the direct
  answer to "it is asking me to fill in everything. it is too much work for a real
  client". Only the three required lines (Stripe Clearing, Product Revenue, Payment
  Processing Fees) gate completion; GST / Refunds / Chargebacks stay optional and are
  labelled as such.
- Bank statement CSV import is **not** in setup. It moves to `/connections` as a
  fallback, and its two-step "Choose file" → "Inspect the file" flow — which lost the
  attached file, the bug hit on 2026-08-17 — becomes one step: choosing a file parses it
  and shows the column mapping immediately.
- Setup is reachable at any time from `/connections` but never appears again once
  complete.
- A tenant that is not fully configured is redirected from `/` to `/setup`.

### 7. `/connections`

The 1800px scroll becomes three blocks with the duplicate Connections section removed:
**Connected services · Account mapping · Bank statement import**.

Raw transport errors (`The sync worker answered HTTP 500 with no error envelope`) are
replaced by a stated outcome and a retry. The existing `DataSourceDown` component
already does this well elsewhere and is reused. Raw identifiers (`bank_unmatched`) are
replaced in prose by what they mean; the code stays available in the audit trail.

### 8. Cross-cutting

- **No dead ends.** Every empty state names what will fill it and offers the action
  that does so.
- **One count per fact.** A figure shown twice on a screen is computed once and
  threaded.
- **No raw errors.** No HTTP status codes, stack traces or internal identifiers in
  prose.

## Constraints — binding on every change

These come from `HANDOFF.md` and the code's own comments, and they outrank anything in
this document:

1. **Never weaken a guard, loosen a schema, delete an assertion, or skip a test to get
   green.** A guard that rejects is a guard working.
2. **The three blocked-approval gates in `ApprovalsScreen.js:70-86` are load-bearing**
   and stay: the disabled button, `store.js` RECORD_APPROVAL's no-op, and the mount
   effect that arms it. Derived pruning of the bulk selection
   (`ApprovalsScreen.js:132-138`) is not to be replaced with an effect.
3. **The model never computes or writes a number.** No arithmetic moves into a
   component. `tests/no-arithmetic.test.js` enforces this.
4. **`DESIGN.md` is the visual authority.** No new tokens, faces, greys or gradients.
   Green means a human verified; violet means the machine completed. Never collapse
   those.
5. **The bans in `DESIGN.md` hold**: no monospace face, no JSON on screen, no grey
   content backdrop, no status carried by colour alone.
6. Rationale comments explaining *why* are preserved through any move. Where a comment
   describes behaviour this design changes, the comment is rewritten to describe the new
   behaviour — never left to rot, as `ReconcileTabs.js:9-13` was.

## Testing

- **614 tests pass at `pre-ui-redesign` and must pass at every commit.** Suites naming
  removed routes are updated to the new routes, never deleted.
- New tests are required for: the disabled nav items being unreachable by keyboard; the
  redirect from `/` to `/setup` when unconfigured; setup step gating; the account
  dropdowns being populated from the QBO chart rather than free text; conditional filter
  chrome above/below the 10-row threshold; and the single-count invariant on Approvals.
- Every new test must **bite** — revert the behaviour, watch it fail, restore it.
- `walk.mjs` is updated to the new routes and run against the deployment before this is
  called done.
- Visual verification at 1600×1000 and 1280×800 on every changed surface, checking
  specifically for the overlap and collision defects listed above.

## Out of scope

Building Command, Insights, Checklist or Chat. Any engine, API or schema change. Billing.
Shopify, which is blocked on a Protected Customer Data approval that has not been filed.
Dark theme, which `DESIGN.md` defers.
