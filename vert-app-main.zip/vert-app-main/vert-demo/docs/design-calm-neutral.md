---
name: Vert
description: Chat-first AI month-end close for accounting firms. Calm neutral, finance-grade, one deep accent that means "this writes". Amended by design-fix-2 (10 Oct 2026).
colors:
  paper: "#FFFFFF"
  paper-inset: "#F8F9F9"
  desk: "#F2F5F4"
  desk-hover: "#E8EBEA"
  desk-pressed: "#E0E4E3"
  select: "#EDF1F0"
  hairline: "#EAECEC"
  edge: "#DDE0DF"
  control-edge: "#7C8280"
  ink: "#151A18"
  ink-body: "#2A2F2D"
  ink-muted: "#555D5A"
  ink-faint: "#636B68"
  vert-green: "#146353"
  vert-green-hover: "#125748"
  vert-green-pressed: "#164A3E"
  vert-green-tint: "#F0FAF7"
  vert-green-ink: "#194C41"
  vert-green-halo: "#C6E6DD"
  logo: "navy mark image (public/brand/vert-mark-navy-*.webp), no colour token"
  attention-ink: "#8F520D"
  attention-soft: "#FFF5E3"
  working-ink: "#2C5FA9"
  working-soft: "#EEF5FF"
  done-ink: "#434947"
  done-soft: "#F2F5F4"
  done-bar: "#555D5A"
  attention-bar: "#C7A475"
  fav: "#8A918F"
  unfav: "#AC312C"
  bar-total: "#CDD2D0"
  chat-ground: "#FBFCFC"
  waiting-ink: "#5B6260"
  waiting-soft: "#EDF1F0"
  problem-ink: "#AC312C"
  problem-soft: "#FDEFEE"
  debit: "#2B5C97"
  credit: "#8D5416"
typography:
  display:
    fontFamily: "Archivo, Inter, system-ui, sans-serif"
    fontSize: "2rem"
    fontWeight: 600
    lineHeight: 1.1
    letterSpacing: "-0.025em"
  title-1:
    fontFamily: "Archivo, Inter, system-ui, sans-serif"
    fontSize: "1.75rem"
    fontWeight: 600
    lineHeight: 1.15
    letterSpacing: "-0.022em"
  title-2:
    fontFamily: "Archivo, Inter, system-ui, sans-serif"
    fontSize: "1.375rem"
    fontWeight: 600
    lineHeight: 1.2
    letterSpacing: "-0.016em"
  title-3:
    fontFamily: "Archivo, Inter, system-ui, sans-serif"
    fontSize: "1.125rem"
    fontWeight: 600
    lineHeight: 1.3
    letterSpacing: "-0.01em"
  callout:
    fontFamily: "Inter, system-ui, sans-serif"
    fontSize: "1rem"
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: "-0.011em"
  body:
    fontFamily: "Inter, system-ui, sans-serif"
    fontSize: "0.875rem"
    fontWeight: 400
    lineHeight: 1.5
    letterSpacing: "-0.006em"
  footnote:
    fontFamily: "Inter, system-ui, sans-serif"
    fontSize: "0.8125rem"
    fontWeight: 400
    lineHeight: 1.4
    letterSpacing: "-0.003em"
  caption:
    fontFamily: "Inter, system-ui, sans-serif"
    fontSize: "0.75rem"
    fontWeight: 500
    lineHeight: 1.35
    letterSpacing: "0.005em"
  wordmark:
    fontFamily: "Archivo, Inter, system-ui, sans-serif"
    fontSize: "1.25rem"
    fontWeight: 500
    lineHeight: 1
    letterSpacing: "-0.02em"
rounded:
  xs: "4px"
  inner: "6px"
  sm: "8px"
  md: "12px"
  card: "14px"
  prompt: "14px"
  lg: "16px"
  pill: "999px"
spacing:
  s-1: "0.25rem"
  s-2: "0.5rem"
  s-3: "0.75rem"
  s-4: "1rem"
  pad-card: "1.25rem"
  s-5: "1.5rem"
  s-6: "2rem"
  s-7: "3rem"
  s-8: "4rem"
components:
  button-commit:
    backgroundColor: "{colors.vert-green}"
    textColor: "{colors.paper}"
    typography: "{typography.body}"
    rounded: "{rounded.sm}"
    padding: "0 1rem"
    height: "2.25rem"
  button-commit-hover:
    backgroundColor: "{colors.vert-green-hover}"
  button-commit-pressed:
    backgroundColor: "{colors.vert-green-pressed}"
  button-secondary:
    backgroundColor: "{colors.desk}"
    textColor: "{colors.ink}"
    rounded: "{rounded.sm}"
    padding: "0 1rem"
    height: "2.25rem"
  button-secondary-pressed:
    backgroundColor: "{colors.desk-pressed}"
  button-quiet:
    backgroundColor: "transparent"
    textColor: "{colors.ink-muted}"
    rounded: "{rounded.sm}"
    padding: "0 0.5rem"
    height: "2.25rem"
  button-send:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.paper}"
    rounded: "{rounded.pill}"
    size: "2rem"
  field:
    backgroundColor: "{colors.paper}"
    textColor: "{colors.ink}"
    rounded: "{rounded.sm}"
    height: "2.5rem"
    padding: "0 0.75rem"
  composer:
    backgroundColor: "{colors.paper}"
    textColor: "{colors.ink}"
    typography: "{typography.callout}"
    rounded: "{rounded.prompt}"
    height: "3.25rem"
  decision-card:
    backgroundColor: "{colors.paper}"
    rounded: "{rounded.card}"
    padding: "1.25rem"
  status-mark-needs-you:
    backgroundColor: "transparent"
    textColor: "{colors.attention-ink}"
    typography: "{typography.caption}"
    height: "1.25rem"
  status-mark-done:
    backgroundColor: "transparent"
    textColor: "{colors.done-ink}"
    typography: "{typography.caption}"
    height: "1.25rem"
  nav-row:
    backgroundColor: "transparent"
    textColor: "{colors.ink}"
    typography: "{typography.body}"
    rounded: "{rounded.sm}"
    height: "2rem"
  nav-row-active:
    backgroundColor: "{colors.paper}"
    textColor: "{colors.ink}"
  sidebar:
    backgroundColor: "{colors.desk}"
    width: "15.5rem"
---

# Design System: Vert

The normative detail behind this file lives in `spec.md` in the same folder:
- motion tokens and springs;
- materials;
- the per-interaction table;
- the per-component specs;
- the contrast table;
- the guard changes.

The design-pass screens are `screens.json`, with before and after shots. The palette's canonical values are OKLCH (spec §3.1); the hex values in the frontmatter are their sRGB fallbacks.

**Amended 10 Oct 2026 by design-fix-2** (`../design-fix-2/spec.md`, the founder's decisions D1 to D10). Where this page and that spec disagree, the spec wins. The website is out of scope for this pass (D8).

## 1. Overview

**Creative North Star: "The ledger on a quiet desk"**

- Vert is white paper for the work, laid on a soft cool-grey desk, written in near-black ink.
- There is one colour with an opinion, **Vert green**, Vert's deliberate product colour beside the website's navy mark (D1/D3: kept, not retinted). It appears only where a person commits something to the books, and as the focus ring. Its rarity is the point: in this product, green under your pointer means *this writes*. It never means Done, Posted, Balanced or favourable.
- Everything else is quiet. Status is a glyph and a word in the status's ink, with no fill. Depth is one hairline and an ink-tinted shadow. Motion is critically damped and short.

**Density** follows the reference agent-workspace product:
- one prompt, one progress bar and one decision queue on home;
- a task is a chat;
- plans, workbooks, bridges and commentary open in a pane beside the conversation;
- tables carry real numbers at 40 px rows.

Hierarchy comes from order, space and weight, not from boxes. The decision card is the only raised surface on home.

**It rejects:**
- the old true-black rail and violet;
- the generic AI product (purple, sparkle, shimmer, glass as decoration);
- enterprise accounting software's equal-weight grey density;
- developer-tool monospace and JSON;
- consumer fintech's oversized numbers;
- the fintech reflex of navy and gold.

**Key Characteristics:**
- A light page, always. There is no automatic dark mode, and `color-scheme` is pinned to light.
- One accent, on 10% or less of any screen: the commit and the focus ring.
- Archivo for headings, display figures and the wordmark; Inter for the interface and all figures, tabular.
- Tabular figures, right-aligned, never wrapping between sign and amount.
- Glass only for floating chrome: bars content scrolls under, sheets and popovers.
- Every surface enters and leaves by one path, and can be caught mid-flight.

## 2. Colors: The Calm Neutral Palette

One cool neutral family is tinted toward the accent's hue (175, at chroma 0.01 or less), with one deep evergreen and five quiet status inks.

### Primary
- **Vert green** (#146353 / oklch(0.45 0.078 175)):
  - The commit fill: Post entry, Approve and post, Start now, Create task, Use this one, Sign in.
  - The 2 px focus ring on controls.
  - A focused field: its border in green plus a 3 px halo (#C6E6DD), not the ring.
  - Hover #125748, pressed #164A3E.
  - White on it measures 7.1:1. It measures 6.5:1 on the desk grey, so one ring serves everywhere.
- **Vert green tint** (#F0FAF7): a file drop target while dragging, and nothing else. Never a selection, never a Vert-added row (those are paper inset with "Added by Vert").
- **The logo** is the website's navy mark, an image. It takes no colour token.
- **Chat ground** (#FBFCFC): the conversation rail's ground while a result pane is open, so the split is a change of material, not a line.

### Neutral
- **Paper** (#FFFFFF): the content panel, cards, sheets, popovers.
- **Paper inset** (#F8F9F9): table header bands, sunken tracks, kbd.
- **Desk** (#F2F5F4): the sidebar and the frame around the content panel; the sign-in ground.
- **Desk hover / pressed** (#E8EBEA / #E0E4E3): sidebar row states; the segmented-control track.
- **Select** (#EDF1F0): a selected option or row (neutral, with a check glyph).
- **Hairline** (#EAECEC): rules inside tables and lists.
- **Edge** (#DDE0DF): the one hairline around a surface (card, panel, inset table, secondary button).
- **Control edge** (#7C8280): input and composer borders, 3:1 or better on every ground.
- **Ink** (#151A18): titles, figures, primary text. 17.6:1 on paper.
- **Ink body** (#2A2F2D): running prose.
- **Ink muted** (#555D5A): meta, labels, quiet buttons. 6.8:1.
- **Ink faint** (#636B68): captions and placeholders. 5.5:1 on paper.

### Named Rules
- **The One Writer Rule** (design-fix-2 §2.2). Evergreen fill: only the one commit of a view (Post entry, Approve and post, Start now, Use this one, Create task, Import, Sign in). Evergreen line: the focus ring and a focused field. Never evergreen: Done, Posted, Balanced, "It balances", favourable bars, Vert-added rows, links, tabs, selection, the send button (ink: sending is not a write), progress segments, icons, badges, the command menu's selection.
- **The Word-and-Glyph Rule** (design-fix-2 §2.3). Each status is a Phosphor glyph and a caption-500 word in the status's ink, with NO fill and no border:
  - Needs you: #8F520D, a filled 8 px dot.
  - Vert's working: #2C5FA9, a dashed ring that turns once per 1.2 s (still under reduced motion).
  - Waiting: #5B6260, a hollow ring.
  - Done or Posted: #434947 (a quiet neutral, 9.2:1), a filled tick.

  The soft tints are for notices only. A thing that is not a task's status ("Not checked", "Draft", "Not started") is a Meta: plain secondary ink. Colour alone never carries a state; favourable and unfavourable are said in signed words beside their bars (favourable #8A918F, unfavourable the problem ink).
- **The Amber Budget** (design-fix-2 §2.4). At most five amber marks in a 1440 x 900 viewport. No cream chips, pills or badges; the progress bar's attention segment is a quiet sand (#C7A475). Progress: 6 px, 3 px radius, 2 px gaps, no track; Done #555D5A, Vert's working, Needs you, Waiting #DDE0DF.
- **The Red-Is-Data Rule.** Problem red (#AC312C on #FDEFEE) marks a line that does not balance or a failed read. It is never a button fill and never a status.

## 3. Typography

(Replaced by design-fix-2 spec §3, founder decision D2.)

**Display / heading face:** Archivo (variable, via next/font), on h1 to h3, the top four steps of the scale and the "Vert" wordmark (500, -0.02em). Never below 18 px except the wordmark; never on a button, label, input, menu, table or meta line.
**UI face:** Inter (variable, via next/font), for every other word and every figure, with tabular, lining numerals for money.
**Mono:** none on screen (kbd is the UI face; error codes only inside a notice's Details).

### The scale (8 steps, about 1.2)
- **Display** (Archivo 600, 2rem, 1.1, -0.025em): the one hero figure per result (workbook closing, bridge Actual, the post sheet's total).
- **Title 1** (Archivo 600, 1.75rem, 1.15, -0.022em): page titles: "July 2026", Clients, Connections.
- **Title 2** (Archivo 600, 1.375rem, 1.2, -0.016em): document and sheet titles, the sign-in title, Home's "2 / 12".
- **Title 3** (Archivo 600, 1.125rem, 1.3, -0.01em): card titles and the decision question, the conversation title, pane titles, document sections.
- **Callout** (Inter 400, 500 as a label; 1rem, 1.5, -0.011em): the answer's lead, composer text, the post sheet's summary sentence.
- **Body** (Inter 400, 500 for buttons and the selected option; 0.875rem, 1.5, -0.006em): UI text, table cells, option labels, menu items.
- **Footnote** (Inter 400 / 500 / 600; 0.8125rem, 1.4, -0.003em): meta, field labels, table headers (500), section heads (600, muted ink).
- **Caption** (Inter 500, 0.75rem, 1.35, +0.005em): status words, ages, kbd, "Suggested". 12 px is the floor.

### Named Rules
- **The No-Seven-Hundred Rule.** No weight above 600 anywhere.
- **The Hierarchy Rule.** Option and row labels are 14/400 (500 when selected) under a title-3 question. Section heads are footnote 600 in muted ink, with 3rem above: space separates sections, not size. Answer leads are callout 400. One hero figure per result, never a row of KPI tiles.
- **The Figures Rule.** Every amount, table count, column date and account code is tabular and lining, right-aligned in columns and unbroken between sign and amount. An account reads "6700 Utilities", no middle dot. Minus is a true minus.
- **The Copy Rule.** Sentence case, no uppercase eyebrows, curly quotes, no em or en dash in any visible string (an en dash only as the accounting zero), non-breaking spaces in "1 of 13", "5 s", "11:34 am" and after a currency sign, "…" on every label that opens a dialog, one middle dot per line at most, `translate="no"` on figures and names.
- **Wrapping.** `text-wrap: balance` on h1 and h2 only; `pretty` on card titles, h3 and prose. Prose stops at 42rem.

## 4. Elevation

The system is hybrid: three materials, with shadows only for surfaces that genuinely sit above others.
- **The desk** (the sidebar and frame) is solid. Nothing scrolls under it.
- **Paper** (the panel, cards, the pane) is lifted by one hairline drawn as a shadow, plus a soft shadow sized to the surface.
- **Glass** is only for floating chrome:
  - Sticky bars: white at 82%, blur 20 px, saturate 140%.
  - Popovers: 90%, with a bright top edge.
  - Sheets: 96%, blur 32 px, unsaturated.

A float never sits on a float. Every glass turns solid under reduced transparency or more contrast. Sticky bars draw **no rule at rest**: a 12 px scroll-edge fade and a hairline shadow appear only when content passes beneath. All shadows are ink-tinted (`rgb(21 26 24 / a)`) from one light source above.

### Layers (design-fix-2 §8.1)
One z scale, tokens only (a numeric z-index anywhere else fails the guard): base 0 · sticky 100 · pane head 110 · phone top bar 120 · dropdown 200 · backdrop 300 · sheet 400 (the phone pane, side and bottom sheets, the drawer) · modal 450 (cmd-K, confirm dialogs, New task) · popover 500 (a popover inside a sheet or modal) · toast 600 · tooltip 700. Below 1024 px the phone pane and sheets render into `<body>`, so the top bar never covers them.

### Shadow Vocabulary
- **Edge** (`box-shadow: 0 0 0 1px #DDE0DF`): the hairline around every paper surface.
- **XS** (`box-shadow: 0 1px 1px rgb(21 26 24 / .05)`): raised controls, such as a secondary button, the segmented thumb or the active nav pill.
- **One** (`box-shadow: 0 1px 2px rgb(21 26 24 / .05), 0 2px 8px rgb(21 26 24 / .04)`): the content panel, the decision card, the composer at rest.
- **Two** (`box-shadow: 0 4px 16px rgb(21 26 24 / .08), 0 1px 3px rgb(21 26 24 / .06)`): popovers, menus, the focused composer.
- **Three** (`box-shadow: 0 24px 48px rgb(21 26 24 / .14), 0 4px 12px rgb(21 26 24 / .06)`): sheets, the modal, the phone's full-screen pane.

### Named Rules
- **The One Raised Surface Rule.** On home, only the decision card is raised (paper, shadow One, no edge hairline, 14 px radius). Everything else groups by space. Progress, the checklist and section heads sit on the paper, unboxed. Nested cards are never allowed.
- **The Scroll-Edge Rule.** No permanent 1 px rule under a sticky header. Content fades as it passes under glass.
- **The Dim-to-Focus Rule.** A modal decision (post, task create) dims the page with an ink scrim at 22%. A parallel pane (plan, workbook, bridge, skill) never does.

## 5. Components

### Buttons
- **Shape:** gently squared (8px), 36 px high (44 px on touch). Labels are 500, on one line, in three words or fewer.
- **Commit:** Vert green fill with a white label, padding 0 1rem. One per view.
- **Hover / Focus:**
  - Hover darkens one step (120 ms).
  - Pointer-down shows the pressed fill plus `scale(.97)` within 100 ms.
  - Focus is a 2 px green ring at 2 px offset.
- **Secondary** (design-fix-2 §5.3): the desk fill (#F2F5F4) in ink, no outline and no shadow. Hover desk-hover, pressed desk-pressed plus `scale(.97)`.
- **Quiet:** no fill, in muted ink. Hover fill is the hover grey; pressed desk-pressed. A destructive action is a quiet button in the problem ink (Reject…, Reverse…), never a red fill.
- **Send:** an ink circle, 32 px. Sending is not a write, so it is never green. Disabled send: line fill, faint arrow, no press.
- **Disabled:** the quiet look at 45% opacity, still focusable and pressable (the press does nothing), with its reason printed beside it. It is never `pointer-events: none` and never looks enabled.
- **Icons:** one set, Phosphor regular (D7), imported from `components/ui/icons.js`: 16 px default, 14 px in buttons and rows, 12 px for a trailing caret, 20 px in the sidebar. No typed glyph (› ‹ ✓ × ⌄ ⇕ ▶ ⚠) where an icon belongs.
- **Press** (§5.4): buttons, chips and icon buttons scale to .97; a row wider than 300 px presses with its fill only.

### Chips
- **Status:** a glyph and a caption-500 word in the status ink, 20 px tall, no fill and no border; not pressable.
- **Property** (task sheet: assignee, due day, approver, repeats): 32 px, 8px radius, edge plus XS. A leading glyph, then a value in ink or a placeholder in muted ink. Toggle chips use `aria-pressed` with a check.
- **Context** (client and month): a quiet button with a chevron, no dot.

### Cards / Containers
- **Corner Style:** 14px (card). An inset table inside is 6px. The radius ladder: 4 (kbd, badges) · 6 (phrase chips, inline tags, inset tables, cmd-K items) · 8 (buttons, inputs, rows) · 12 (popovers, menus) · 14 (cards, the panel, the composer, cmd-K) · 16 (sheets, modals).
- **Background:** paper.
- **Shadow Strategy:** edge plus One (see Elevation). Only the decision card and the JE card use it.
- **Border:** none beyond the edge shadow. Nothing inside a card draws a border except an inset table.
- **Internal Padding:** 1.25rem, with 0.75rem between blocks. The head has the title (title 3) and, on the right, the pager ("1 of 13 ‹ ›"). The one commit sits in the foot, at the right.

### Inputs / Fields
- **Style:** paper, a 1 px control edge (#7C8280, 3:1 or better), 8px radius, 40 px high (32 px in the JE editor's compact grid). The label sits above (footnote 500, muted ink) and the hint below.
- **Focus** (design-fix-2 §5.3): the border turns green and gains a 3 px halo (#C6E6DD). No outline ring on a text field, so an autofocused field on first paint is not a heavy double ring.
- **Error / Disabled:**
  - Error: a problem-red border and an inline message below (`role="alert"`). A failed submit moves focus to the field. One line is reserved under a field that can fail, so nothing moves.
  - Disabled: an inset fill with faint ink.
- **Composer:** 14px radius, control edge, One shadow, callout text. On focus the border goes muted, the green ring appears and the shadow becomes Two. In a thread it docks in a glass bar.

### Navigation
- **Sidebar:** the desk material, 15.5rem. Brand row (the navy mark plus Archivo "Vert"), a Search row (MagnifyingGlass, "Search", ⌘K) and a New chat row, then the client switcher (client over month, one row), the primary nav (Month-end, Clients), the conversations and the account row.
  - Rows are 32 px (44 px on touch), body 400 ink, with a 16 px muted glyph.
  - Hover is desk-hover; pressed is desk-pressed.
  - **Active:** a white pill with an XS shadow and a 500 label. Lifted, never green.
  - Conversation rows show a status glyph only for Needs you and Vert's working, plus an age in faint caption.
- **Mobile:** a 44 px glass top bar (menu, then the title, which doubles as the context switcher). The sidebar becomes a left sheet that leaves the way it came, over a scrim.
- **Conversation head:** a single glass row at the pane head's height (3.25rem), so the two hairlines share one y across the split.
- **Command menu (cmd-K, D6):** ⌘K on a Mac, Ctrl+K elsewhere, from anywhere. A 35rem glass dialog at 16vh, radius 14, over the scrim: a 48 px search row, groups (Actions, Clients, Months, Conversations, Tasks), 40 px items whose selection is the hover grey, never green, and a footer of kbd hints. Behaviour and data in `components/shell/command/`; the UI is `components/shell/CommandMenu.js`.

### The Decision Card (signature)
- The one raised surface on home, as in the reference's "Needs your attention" queue:
  - the title, with the pager in the head;
  - a two-line reason;
  - an evidence table;
  - full-width option rows (a number badge, callout-500 label and "Best guess" caption), with the selected option on the neutral select fill and a check;
  - the foot (design-fix-2 §7.2, D10): select-then-commit everywhere. Kbd hints on the left (on focus only), then Open in chat (Home), Skip (quiet) and "Use this one" (the commit). Esc only dismisses; Skip happens only by its button, with a 5 s "Skipped. Undo" toast.
- On a desk, the keyboard hint lives in the foot.
- A decided card collapses to its line on the snappy spring, and the next one rises into place.

### How Vert did this (D9)
- An agent turn leads with its answer. Timings, model names, skill versions and tool steps live in one quiet "How Vert did this" disclosure on the turn's identity row (20 px navy mark, "Vert", time). A turn with no output has no disclosure.

### The Result Pane (signature)
- The plan, workbook, bridge, commentary, skill and budgets open as a paper pane to the left of the conversation. The chat flows into a right rail that keeps its own composer.
- The pane slides in from the conversation's edge on a critically damped spring and leaves the same way.
- **Head** (glass): a type glyph, title 3, tools and close.
- **Foot** (glass): secondary actions on the left, the one commit on the right.
- **The plan's foot** reads: Save changes (when edited), Reject, Schedule (a popover anchored to it), Start now.

## 6. Do's and Don'ts

### Do:
- **Do** keep the page light under every system appearance: `color-scheme: light`, no `prefers-color-scheme: dark` block, no `[data-theme="dark"]`.
- **Do** spend Vert green (#146353) only on the one commit per view and the focus ring.
- **Do** draw the sidebar as the soft desk grey (#F2F5F4) with near-black ink, and the active row as a lifted white pill.
- **Do** pair every status with its glyph and word, in its ink, with no fill.
- **Do** set every amount in tabular figures, right-aligned. Say "not read" in words; never show an unread $0.00.
- **Do** use transitions, not keyframes, for anything that opens or closes, and send every surface out the way it came in.
- **Do** honour reduced motion (150 ms cross-fades), reduced transparency (solid) and more contrast (solid, with stronger edges).
- **Do** print a disabled commit's reason beside it before the press: "Drafted by you, so a reviewer posts it".
- **Do** fade content under sticky glass with a 12 px scroll-edge mask instead of a rule.

### Don't:
- **Don't** bring back the true-black sidebar (#000000) or the violet accent (#4F1FE8). No purple survives; the logo is the navy mark.
- **Don't** use purple or violet gradients, sparkle icons, a "thinking" shimmer or glass for its own sake (PRODUCT anti-reference: the generic AI product).
- **Don't** use monospace on screen, JSON, tool-name chips, method columns, step counters or millisecond timings (PRODUCT anti-reference: developer tooling).
- **Don't** stack outlined boxes or nest cards. Density without hierarchy, grey on grey and every element at the same weight are the enterprise-accounting failure.
- **Don't** use oversized numbers, one fact per card, or KPI tiles in a row (PRODUCT anti-reference: consumer fintech; the hero-metric template).
- **Don't** use a `border-left` or inset box-shadow stripe wider than 1px as an accent on rows, quotes or callouts.
- **Don't** colour links, tabs, selection, the send button or "Show all" green.
- **Don't** use 700 weight, captions under 12 px, uppercase eyebrows, or an em-dash in any visible string.
- **Don't** let a commit label wrap or overflow. "Post entry", not "Post to QuickBooks Online (recording, nothing is sent)".
- **Don't** lock input while a surface closes (`pointer-events: none` on a closing pane).
- **Don't** draw a permanent 1px divider under a sticky header.
- **Don't** colour Done, Posted, Balanced or favourable green.
- **Don't** put a fill behind a status word.
- **Don't** show timings, model names or versions outside "How Vert did this".
- **Don't** use a typed glyph where an icon belongs.
- **Don't** use Archivo below 18 px except the wordmark.

### Notes
- Sentence-case tabs are a deliberate deviation from the Web Interface Guidelines' title case.
- The website is out of scope for this pass (D8); in-app nouns follow DA2-081 ("Decision", "Clients", "Delivered").
