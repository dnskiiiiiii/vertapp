# Vert agent workspace — design spec

**Date:** 30 Sep 2026 (revision 2)
**Status:** proposed, for build in three iterations (the build plan is kept outside the repo)
**Replaces:** the five-area register UI (Payouts, Approvals, Exceptions, Bank rec, Connections) and the four "Coming later" areas.
**Supersedes:** the visual tokens in `DESIGN.md` (true-black rail, white-on-white surfaces, Satoshi body type). `DESIGN.md` gets a banner pointing here when iteration 1 merges.

---

## 0. The idea in one paragraph

A bookkeeper opens Vert and sees one page for the month: a box to ask Vert anything or tell it what to do, how far the month has got, and the decisions that need them, the first one already open. Pressing **Start September** runs every check that needs no human. The bookkeeper comes back only to decisions. Anything typed in the box can start any piece of work, and that work carries on as a conversation. Every figure opens its source. Nothing reaches the books until a person says so.

### Design targets (each one is measured; see §15)

| Target | Measure | Today |
|---|---|---|
| Understood in 5 seconds | A first-time reader names the screen, the state and the next step from a screenshot | Fails on 6 of 8 screens |
| Few places to go | 1 navigation item (Month-end) plus your conversations | 9 (4 of them do nothing) |
| Little to read | ≤ 120 words above the fold on Month-end | 344 on the landing page |
| One thing to do | One filled button above the fold per view | Up to 28 buttons, 3 filled |
| Few steps | Fix a payout break with Vert's suggested deposit in 1 click from Month-end | About 7, with the answer re-typed by hand |
| One way to count | Every "need you" number on screen counts the same unit (decisions) and agrees | 5 different units |

### What does not change

- The engine owns every figure. The screen never adds, subtracts or rounds money, and neither does the model.
- Something Vert has not read is shown in words ("No September bank statement yet"), never as $0.00.
- A person approves before anything is saved to a client's books.
- Every write goes through the existing API routes and their gates.

---

## 1. Principles

1. **Chat is where work happens. One page shows the month.** Every task runs as a conversation. Month-end is the only destination; everything else is evidence you reach from a figure, or a setting in the account menu.
2. **Only what needs you.** Vert brings back decisions, not inventories. "4 payouts need you. 27 match the bank." The 27 are one click away, never on the main path.
3. **Four status words, one unit.** Everything is *Needs you*, *Vert's working*, *Waiting* or *Done*. Every "need you" count counts **decisions**: the badge, the progress line, the group header and each task row (UI-001). A failure is not a fifth status: it is a Problem line with Retry on a *Needs you* row.
4. **Two actors: Vert and you.** Exact results are unmarked, because exact is the default. Only a model's reading is marked: "Vert's best guess — check this". Model names and engine stages live behind "How this was produced" (UI-006).
5. **Verdict first.** A card or answer starts with its conclusion in one line, then at most three facts, then one action. The rest sits behind "Details" (UI-021, UI-023).
6. **Lead with the transaction, not the id.** "Stripe payout · 2 Jul · $7,000.00". Ids live in Details. Fixture and engineering names never render.
7. **The button says what happens.** "Use this deposit", "Approve $9,350.73", "Post $9,631.75 to QuickBooks". Never "Record pin" or "Submit" (UI-042).
8. **Forgiving by default, firm where it matters.** Undo for what can be undone. A confirmation sheet only for posting to a ledger and for rejecting (UI-003, UI-004, UI-009).
9. **Nothing looks clickable unless it works, and nothing is listed unless it is built.** No attach control until files are read for real; no task in the checklist until its work exists; no settings page with nothing to set (UI-066 lesson).
10. **Purpose before craft.** Motion and material serve feedback and orientation. Effort on gesture physics waits for the phone pass, where gestures happen (apple-design §16.1).

---

## 2. Information architecture

### 2.1 Sidebar

```
┌───────────────────────────┐
│ ◉ Vert                    │
│                           │
│ Northwind Trading         │  ← client: a plain label until the firm layer (§2.3)
│ September 2026   ▾        │  ← the visible month (§2.2); hidden ▾ if only one month
│                           │
│ ▣  Month-end        29    │  ← the one nav item; badge = decisions that need you
│                           │
│ Conversations             │  ← this month's; scrolls; not navigation
│ ● Bank reconciliation     │  ← amber dot = needs you (listed first)
│ ● Resolve payout breaks   │
│ ◌ Ask: GST on refunds     │  ← dotted = Vert's working
│ ✓ Check payouts           │
│ ┌───────────────────────┐ │
│ │ Bank rec needs you    │ │  ← background notice (§4.5), anchored here,
│ │                 Open ›│ │     aria-live="polite"; no sound, no modal
│ └───────────────────────┘ │
│ ───────────────────────── │
│ (V) Vansh            ⋯    │  ← account menu: Connections · Sign out
└───────────────────────────┘      (+ Notes Vert keeps in iteration 2)
```

| Place | Route | Reached from | Contains |
|---|---|---|---|
| **Month-end** | `/` | The nav item; "‹ September" in a conversation | Ask box, progress, the checklist grouped by status with *Needs you* first and open; first-run setup when nothing is connected |
| **Conversation** | `/chat/[id]` | A task row, the ask box, the Conversations list, "Ask Vert about this ›" on a record | One piece of work, start to finish |
| **Records** | `/records` | A figure's source sheet ("See all payouts ›") and a task row's "See all ›". **Not in the nav**: it is evidence, not a destination | Payouts, Journal entries, Bank lines |
| **Connections** | `/connections` | The account menu; a source line in the context sheet. Before setup is done, its content is Month-end's first-run state | Stripe, Shopify, bank statements, QuickBooks/Xero |

There is no "New chat" button (the ask box starts one), no "Show all" and no conversation index page (the list scrolls). The skill's rule "name nav items for their contents, not 'Home'" gives the one nav item its name: Month-end.

Removed from navigation: Payouts, Approvals, Exceptions, Bank rec, Records and Connections, plus Command, Insights, Checklist and Chat as placeholders (UI-066). Old URLs redirect (§12.2).

**Wayfinding.** Where am I: the page title and the active nav item (`aria-current`); in a conversation, the title plus "‹ September". Where can I go: one nav item and the conversation list. What's here: a verdict line under the title. How do I get out: sheets close on Esc and with a close control top-right; conversations have "‹ September". The first Tab stop is "Skip to main content" (UI-055).

### 2.2 The visible month

- One control, under the client name. It scopes Month-end, Records and the Conversations list, and it is hidden when the engine has data for only one month (`GET /close/periods`).
- A conversation is pinned to its month. **Opening a conversation sets the visible month to that conversation's month**, so the sidebar never says October over September figures.
- **Switching month while inside a conversation leaves it**: Vert goes to that month's Month-end and shows a notice, "This chat is about September. Open it ›".

### 2.3 Client

One access code is one client, so the client name is a label, not a control (no false affordance). The firm layer (iteration 3) turns it into a switcher and adds a **Clients** view: one row per client with the month, the progress bar and "N decisions need you", in the same words (§8).

### 2.4 The nouns a bookkeeper sees

```
Client ─┬─ Month ── Task ── Conversation ── Decisions · Results · Questions
        ├─ Sources (Connections)
        └─ Notes (iteration 2)                         Records = the evidence
```

Five nouns on the main path: **month, task, conversation, decision, record**. There is no "playbook", "session", "run" or "brief" anywhere a bookkeeper looks.

---

## 3. Screens

Wireframes are 1440×900 unless marked. `[■ Label]` is the one filled (commit) button in the view. `[ Label ]` is secondary. `Label ›` is a quiet link. Every `$` figure is an engine figure and opens its source (§9.3).

### 3.1 Sign in (`/login`)

```
                          ◉ Vert

                    Sign in to your books

   Your Vert access code  ┌──────────────────────────────────┐
                          │ ••••••••••••••••••••••••         │  ← masked, show/hide eye
                          └──────────────────────────────────┘
                          [■ Sign in                          ]

                          Where do I find it? ›
```

- No card chrome. The wordmark is at title-2 (UI-074 lesson).
- At most 30 words (today: 154). The key's technical prefix is never shown or asked for; the field accepts the full code as pasted.
- A wrong code keeps the value, marks the field and puts the message under it; the message clears on input (UI-052).
- Email with a magic link for people is a founder decision (see the plan's open questions). Access codes stay for integrations either way.

### 3.2 Month-end (`/`)

**Running month:**

```
┌──────────┬──────────────────────────────────────────────────────────────────────┐
│ sidebar  │  September 2026                                                      │
│          │  1 of 5 done · 29 decisions need you                                 │
│          │  ████████████████████░░░░░░░░░░░░░░░░░░░                            │
│          │                                                                      │
│          │  ┌────────────────────────────────────────────────────────────────┐  │
│          │  │ Ask Vert, or tell it what to do…                         (↑)   │  │
│          │  └────────────────────────────────────────────────────────────────┘  │
│          │                                                                      │
│          │  Needs you                                                           │
│          │  Resolve payout breaks · 4 decisions                                 │
│          │  ┌────────────────────────────────────────────────────────────────┐  │
│          │  │ Stripe payout · 2 Jul · $7,000.00                              │  │
│          │  │ Use the 1 Jul deposit of $7,000.00?                            │  │
│          │  │ Same amount, and the reference matches.                        │  │
│          │  │ Vert's best guess — check this                                 │  │
│          │  │ [■ Use this deposit]   [ Pick another ]                        │  │
│          │  └────────────────────────────────────────────────────────────────┘  │
│          │  ▸ Stripe payout · 9 Jul · $6,000.00 — no deposit found              │
│          │  ▸ 2 more                                                            │
│          │  ▸ Approve journal entries · 24 decisions · $412,380.10              │
│          │  ▸ Reconcile the bank account · 1 question                           │
│          │                                                                      │
│          │  Waiting                                                             │
│          │  ▸ Build workpapers · after the payout breaks and the bank rec       │
│          │  Done · 1 ▾                                                          │
│          │                                                                      │
│          │  Stripe synced 2 hours ago · Shopify synced 2 hours ago ·            │
│          │  bank statement to 30 Sep                                            │
└──────────┴──────────────────────────────────────────────────────────────────────┘
```

- **One page, not two.** The ask box, the progress line and the checklist grouped by status share one screen. There is no separate Close page repeating the bar and counts.
- **The one filled button** is the open decision's commit. The ask box's send icon fills only once text is typed.
- **Needs you is listed, not paged.** The first decision is open. Every other decision is a one-line row that opens in place (the open one collapses to its row). A task with many decisions shows its first row and "N more", which expands in place. Order is the engine's priority: money that can't be explained first, then value.
- **Counts are decisions**, from `GET /close/{period}`. The header's "29", the sidebar badge and the sum of the task rows are the same number from the same payload; the screen adds nothing.
- **Only built tasks are listed.** In iteration 1 there are five (§6.3), so the bar says "of 5".
- **Waiting** carries its reason in words ("after the payout breaks and the bank rec", "Waiting for the September bank statement").
- **Sources** are one quiet line of freshness words at the foot. Syncing is automatic (§6.4); a stale or failed source becomes a *Needs you* row with a reason and "Sync now".
- **A task in trouble** stays under *Needs you* with a Problem line: "Couldn't finish: the bank statement didn't open. Retry".
- Budget: 120 words above the fold. No greeting.

**Month not started:**

```
│  September 2026                                                      │
│  September hasn't started.                                           │
│  Vert will check payouts, find breaks, gather entries for approval   │
│  and start the bank rec. You'll come back to decisions only.         │
│  [■ Start September]                                                 │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ Ask Vert, or tell it what to do…                         (↑)   │  │
│  └────────────────────────────────────────────────────────────────┘  │
```

One press opens the month **and runs every task that needs no human**. While they run, rows show "Vert's working" with a live label; when they finish, the page is the running state above. There is no per-task "Start".

**First run (nothing connected):** the page is the Connections list (§3.6) under the heading "Connect your books to start". Once one payment source and the bank are in, it becomes "September hasn't started".

**Everything done:** "September is done. 5 of 5." plus the Done group open and `Download workpapers`. An empty state never claims success unless the engine said so (the empty-states guard).

### 3.3 Conversation (`/chat/[id]`)

```
┌──────────┬──────────────────────────────────────────────────────────────────────┐
│ sidebar  │ ‹ September                                                          │
│          │ Resolve 4 payout breaks                              ● Needs you     │
│          │ Northwind · September ▾                                              │
│          │ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ (scroll edge) ─ ─ │
│          │                                                                      │
│          │ Checked 31 payouts against Stripe, Shopify and your September        │
│          │ bank statement ▾                                                     │
│          │                                                                      │
│          │ 4 payouts don't match the bank yet. 27 do.                           │
│          │ • Stripe payout · 2 Jul · $7,000.00 — two deposits could be it       │
│          │ • Stripe payout · 9 Jul · $6,000.00 — no deposit found               │
│          │ • Shopify payout · 15 Jun · $150.00 — $150.00 short                  │
│          │ • Stripe payout · 12 Jul · $2,310.40 — no account for a fee          │
│          │                                                                      │
│          │ ┌──────────────────────────────────────────────────────────────┐    │
│          │ │ Stripe payout · 2 Jul · $7,000.00                            │    │
│          │ │ Use the 1 Jul deposit of $7,000.00?                          │    │
│          │ │ Same amount, and the reference matches.                      │    │
│          │ │ Vert's best guess — check this                               │    │
│          │ │ [■ Use this deposit]   [ Pick another ]   [ Skip ]  Details ▾│    │
│          │ └──────────────────────────────────────────────────────────────┘    │
│          │                                                                      │
│          │ ┌──────────────────────────────────────────────────────────────────┐ │
│          │ │ Ask a follow-up…                                           (↑)   │ │
│          │ └──────────────────────────────────────────────────────────────────┘ │
└──────────┴──────────────────────────────────────────────────────────────────────┘
```

- **Header.** "‹ September" returns to Month-end. The title and subtitle say what this conversation is for; there is no bubble in your voice that you never wrote. The context chip reads "Northwind · September" (§7).
- **What Vert did** is one sentence before the answer, naming what was read. It expands to one line per step in accountant words. No durations, no stage names, no separate "Used" row (UI-016, UI-020).
- **The 2 Jul card has a winner, so it says so with one reason.** When two deposits really do tie, the card has no suggestion: "Two deposits of $7,000.00 on 1 Jul and 3 Jul. Which one is this payout?" with both as options. It never says both.
- **Composer:** fixed to the bottom and always reachable, phone included (UI-038). Enter sends; Shift+Enter adds a line. No attach control until iteration 3.
- **Scroll edge:** a gradient mask where the thread passes under the header and the composer, never a hard rule (UI-057).

**With a result open (≥ 1280 px),** the result takes the main pane and the chat becomes a right rail:

```
┌──────────┬─────────────────────────────────────────────┬────────────────────────┐
│ sidebar  │ Bank reconciliation · Operating account     │ ‹ September            │
│          │ Doesn't reconcile yet: $112.50 unexplained  │ Reconcile the bank     │
│          │                                             │ account   ● Needs you  │
│          │  Statement closing balance   $84,120.33     │                        │
│          │  Books closing balance       $83,707.83     │ Read your September    │
│          │  Explained                      $300.00     │ statement and the      │
│          │  Unexplained                    $112.50     │ books ▾                │
│          │                                             │                        │
│          │  What explains the gap                      │ $300.00 is a deposit   │
│          │  3 Sep  Deposit on its way      $300.00     │ on its way. $112.50    │
│          │                                             │ isn't explained yet.   │
│          │                                             │ ┌ The $112.50 on ───┐  │
│          │                                             │ │ 28 Sep: what is it?│ │
│          │                                             │ │ 1 Bank fee         │ │
│          │                                             │ │ 2 Owner drawing    │ │
│          │                                             │ │ 3 Something else…  │ │
│          │                                             │ │            Skip    │ │
│          │                                             │ └────────────────────┘ │
│          │                                             │ [Ask a follow-up…  (↑)]│
└──────────┴─────────────────────────────────────────────┴────────────────────────┘
```

- **One decision area per view.** The question in the rail is the only thing to act on. The result pane has no commit button: the engine's verdict closes the task when the gap is explained. `Download Excel` sits in the result's header as a quiet link.
- **The result pane** opens beside the chat at ≥ 1280 px. From 700 to 1279 px it is a right-edge sheet over the thread, in floating material with no scrim. Below 700 px it is a bottom sheet. Wherever it opens, it is inside the viewport and takes focus (UI-005, UI-017).
- **Sticky decision bar:** a translucent footer on long cards keeps the commit and its evidence on screen together (UI-019).

### 3.4 Context sheet (from the context chip)

```
                                        ┌──────────────────────────────────┐
                                        │ Northwind · September         ✕  │
                                        │                                  │
                                        │ Sources                          │
                                        │ Stripe        synced 2 hours ago │
                                        │ Shopify       synced 2 hours ago │
                                        │ Bank          statement to 30 Sep│
                                        │ QuickBooks    not connected      │
                                        │                   Connections ›  │
                                        │                                  │
                                        │ Notes Vert used      (iter. 2)   │
                                        │ Rent goes to 6120       Forget   │
                                        └──────────────────────────────────┘
```

- Two things only: what Vert can see (sources with freshness, in words) and the notes it applied (iteration 2), each with **Forget**.
- No task or playbook name, no model name, no second list of what was read (that is the "What Vert did" line, per turn).
- "Not connected" and "not read yet" are words, never blank space or zero.

### 3.5 Records (`/records`)

```
┌──────────┬──────────────────────────────────────────────────────────────────────┐
│ sidebar  │  ‹ September                                                         │
│          │  Payouts · September                                                 │
│          │  Payouts   Journal entries   Bank lines                              │
│          │  31 payouts · Needs you (4)                              Search ⌕    │
│          │  ┌────────────────────────────────────────────────────────────────┐  │
│          │  │ Stripe payout    2 Jul    $7,000.00    ● Needs you           › │  │
│          │  │ Shopify payout  15 Jun      $150.00    ● Needs you           › │  │
│          │  │ Stripe payout   29 Jun    $9,350.73    ○ Waiting             › │  │
│          │  │ Shopify payout   1 Jul   $40,641.20    ✓ Done                › │  │
│          │  └────────────────────────────────────────────────────────────────┘  │
└──────────┴──────────────────────────────────────────────────────────────────────┘
```

- Evidence views, reached from figures and task rows. One status column in the four words (UI-001, UI-007); no confidence percentages or risk chips.
- "Needs you (4)" is the only filter, a toggle. There is no "Open items" tab; problems are the *Needs you* filter on Payouts.
- No filter chrome at 10 rows or fewer (the register-chrome guard). Above 10 rows, one search field.
- A row opens the **record sheet**: the breakdown, the evidence, ids under Details, and `Ask Vert about this ›`, which starts a conversation scoped to that record.
- Below 700 px, rows become stacked records with amount and status first (UI-031).

### 3.6 Connections (`/connections`, from the account menu)

```
┌──────────┬──────────────────────────────────────────────────────────────────────┐
│ sidebar  │  Connections                                                         │
│          │  QuickBooks isn't connected, so entries can't be posted yet.         │
│          │                                                                      │
│          │  Stripe          Connected · synced 2 hours ago        Sync now ›    │
│          │  Shopify         Connected · synced 2 hours ago                      │
│          │  Bank statement  September imported on 3 Oct        Import another › │
│          │  QuickBooks      Not connected                      [■ Connect]      │
└──────────┴──────────────────────────────────────────────────────────────────────┘
```

- Providers are rows on one surface. "Connect" and "Import" open sheets (UI-061, UI-067). The first-run state of this list is Month-end's empty state (§3.2), not a second screen.
- Sync names only what is connected and shows freshness in words (UI-062). A failed sync prints a sentence and Retry (UI-011).
- There is no AI assistant row and no operator or CLI text. Vert supplies and runs the assistant; its health is an operator concern, reported by the API (§10).
- A permission list is rendered from its data, and any count is computed from that same list (UI-037).

### 3.7 Post confirmation (the one modal)

```
          ░░░░░░░░░░░░░░░░░░░░░░ dimmed scrim ░░░░░░░░░░░░░░░░░░░░░░░░░
          ░   ┌──────────────────────────────────────────────────┐    ░
          ░   │ Post to QuickBooks?                              │    ░
          ░   │ This creates a journal in Northwind's QuickBooks │    ░
          ░   │ file. You can reverse it there, not here.        │    ░
          ░   │                                                  │    ░
          ░   │ Stripe payout · 30 Jun 2026                      │    ░
          ░   │ Stripe Clearing         Dr          $9,350.73    │    ░
          ░   │ Merchant Fees           Dr            $281.02    │    ░
          ░   │ Sales                          Cr   $9,631.75    │    ░
          ░   │ Total                   $9,631.75   $9,631.75    │    ░
          ░   │                                                  │    ░
          ░   │ [ Cancel ]         [■ Post $9,631.75 to QuickBooks]  ░
          ░   └──────────────────────────────────────────────────┘    ░
```

- The only modal (UI-004). It restates the journal from the engine's lines and the API's `postingEffect` sentence; the commit names the amount and the ledger (the ledger name comes from `/approvals/ledger`, never from hard-coded text).
- With no ledger connected there is no Post control anywhere; an approved entry's line reads "Approved · ready to post when QuickBooks is connected. Connect ›".
- **Reject** uses a smaller sheet with a one-line reason: "Reject this entry? It can't be reopened." Reject is visually subordinate to Approve (UI-003).

### 3.8 Phone (390 px)

```
┌────────────────────────────────┐
│ ≡  Northwind · September       │ ← 44 px fixed translucent bar (UI-038)
├────────────────────────────────┤
│ ‹ September                    │
│ Resolve 4 payout breaks        │
│ ● Needs you                    │
│                                │
│ 4 payouts don't match yet.     │
│ ┌────────────────────────────┐ │
│ │ Stripe payout · 2 Jul      │ │
│ │ $7,000.00                  │ │
│ │ Use the 1 Jul deposit?     │ │
│ │ [■ Use this deposit]       │ │
│ │ [ Pick another ]           │ │
│ └────────────────────────────┘ │
├────────────────────────────────┤
│ Ask a follow-up…          (↑)  │ ← always visible, above the keyboard
└────────────────────────────────┘
```

- ≡ opens the sidebar as a left sheet. Results open as bottom sheets with a grabber. No screen scrolls sideways (the mobile-overflow guard).
- Drag-to-dismiss that follows the finger arrives with the phone pass in iteration 2 (§11.4). In iteration 1 the grabber and a close control dismiss the sheet.

---

## 4. Conversation model

### 4.1 Where a conversation starts

All routes create the same conversation object, pinned to the visible month:

1. **From a task row** on Month-end: the conversation belongs to the task. Its title is the task's title with its count ("Resolve 4 payout breaks").
2. **From the ask box** (Month-end, or any conversation's composer for follow-ups): Vert decides what the words ask for.
   - **With the assistant available**, the model reads the request and either answers it or starts the matching task with its `run_task` tool. "Can you sort out the Stripe stuff for August" starts payout breaks for August, and the conversation continues as that work. Vert says only "Doing the payout breaks for August."
   - **Without the assistant** (§10), a deterministic match against task names and synonyms is the fallback: one clear match runs it; otherwise Vert offers the tasks it can do as buttons.
3. **From a record** ("Ask Vert about this ›"): scoped to one payout, entry or bank line.

A task has one conversation. Opening the task again returns to it. `Run again` is a visible secondary button in the header of a finished task's conversation.

### 4.2 Message types

A fixed vocabulary. Nothing else renders in the thread. Each type is one component under `components/chat/messages/`. Wire names are in brackets.

| # | Type | Looks like | Author | Notes |
|---|---|---|---|---|
| 1 | **Your message** (`user_message`) | Right-aligned grey bubble | you | Only text you typed. Vert never writes in your voice. |
| 2 | **What Vert did** (`run_state`, `tool_call`, `tool_result`) | One sentence, secondary ink, with ▾. While running: "Checking 31 payouts…" with the working indicator. When finished: "Checked 31 payouts against Stripe, Shopify and your September bank statement ▾" | Vert | Expanded: one line per step in accountant words. A source that could not be read is named in the sentence ("…and found no September bank statement"). No durations, no stage names (UI-016, UI-020). |
| 3 | **Answer** (`assistant_text`) | Plain text, no bubble: a verdict line in weight 600, then at most 3 facts | Vert | Figures are bound to engine values (§9.2). Budget: 60 words before "More ▾". A model's reading carries "Vert's best guess — check this" under the verdict; an exact answer carries nothing. |
| 4 | **Question** (`clarification`) | A card: the question, one-line why, numbered options, "Something else…", Skip | Vert | Keys: ↑↓, Enter, Esc to skip. Answered, it collapses to "The $112.50 → Bank fee". Several questions are listed, not paged: the first open, the rest as rows. |
| 5 | **Decision** (`action_request`) | The card of §5: transaction line, the proposal in one sentence, one reason, one commit, quiet options | Vert | One press, pre-filled (UI-018). After deciding it collapses to one line: "You used the 1 Jul deposit · 10:42 · Undo". |
| 6 | **Result** (`artifact`) | A card: verdict line, 2–3 key figures, `Open`, and `Download Excel` where one exists | Vert | Opens in the result pane. Kinds: payout list, payout breakdown, journal entry, bank reconciliation, workpaper; schedule in iteration 2. |
| 7 | **Couldn't tell** (`abstention`) | A neutral note: what Vert couldn't establish and why, in one line, plus what would settle it | Vert | A first-class outcome, not an error. |
| 8 | **Problem** (`error`) | Inline notice: what happened, **what was and wasn't recorded**, Retry, Details ▾ | Vert | "Not sent. Nothing was recorded. Try again." The shell never disappears (UI-002, UI-051). Replaces the old "Stuck" status. |
| 9 | **Can do now** (`assistant_unavailable`) | A quiet note plus task buttons: "I can't answer questions right now. I can do these now: [Bank rec] [Payout breaks]" | Vert | Shown only when the assistant is unavailable. Never names a provider, a key or a setting (§10). |
| 10 | **Plan** (`plan`) | Iteration 2. A card with 3–6 numbered steps and `[■ Start]` | Vert | Only for model-run work longer than 3 steps. Rules-only work never asks. |
| 11 | **Note used** (`memory_used`) | Iteration 2. A chip under the answer: "Used your note: rent goes to 6120 · Forget" | Vert | Memory is never silent. |

Each Vert turn has a copy button and a ⋯ menu with "How this was produced" (rules only or the model's id, live or replayed, the task version, token use) and, in iteration 2, "This was wrong".

### 4.3 While Vert is working

- Rules-only work finishes in seconds. **In iteration 1, while it runs, the composer is disabled with its reason printed**: "Vert is checking payouts. You can type when it's done." There is no queue that promises something nobody will do.
- When the assistant is available and a model turn is running, a message you send is held and shown with "Will answer when this finishes." It is sent to the model at the turn's end (iteration 2 adds redirect mid-run).
- **Stop** replaces send while a model turn runs. Stopping keeps what is done and records "Stopped by you".

### 4.4 Status (one vocabulary everywhere)

| Word | Means | Mark | Applies to |
|---|---|---|---|
| **Needs you** | A decision or question is open, or a problem needs Retry | ● amber | tasks, conversations, items |
| **Vert's working** | Vert is running something now | ◌ blue, animated dotted ring (static under reduced motion) | tasks, conversations |
| **Waiting** | On money in transit, or on a source that hasn't arrived; the reason is always printed | ○ grey | tasks, items |
| **Done** | Nothing open | ✓ green | tasks, conversations, items |

- A task that has not run yet does not exist as a state: starting the month runs them.
- "Approved", "Posted", "Rejected" are not statuses. They are the text of a decision's collapsed line: "Approved by Vansh · 10:42", "Posted to QuickBooks · 11:05".
- Old engine distinctions map as follows, computed once in the engine (`workflows/status.py`): blocked → Needs you with a reason; awaiting approval → Needs you; in transit → Waiting; approved (no ledger step yet), posted, reconciled → Done; a failed or silent run → Needs you with a Problem line.

### 4.5 Several conversations at once

Several conversations can run at once, each on its own; nothing is modal across them. When a conversation you are not looking at starts needing you, **one quiet notice appears anchored to the Conversations list**: "Bank rec needs you · Open ›". It is announced with `aria-live="polite"`, stays until opened or dismissed, and never uses sound or a modal. Only one notice shows at a time; a second one replaces its text ("2 conversations need you · Open ›").

---

## 5. Cards (shared by Month-end and the chat)

### 5.1 Anatomy

```
┌───────────────────────────────────────────────────────────────┐
│ Stripe payout · 2 Jul · $7,000.00                             │  ← the transaction, never an id
│ Use the 1 Jul deposit of $7,000.00?                           │  ← the proposal, one sentence
│ Same amount, and the reference matches.                       │  ← one reason, footnote size
│ Vert's best guess — check this                                │  ← only when a model suggested it
│ [■ Use this deposit]  [ Pick another ]  [ Skip ]   Details ▾  │  ← one commit, then quiet options
└───────────────────────────────────────────────────────────────┘
```

- At most 25 words above Details. The card above is 21.
- No status badge inside a card on Month-end (the group heading already says *Needs you*); in Records the row carries the one badge (UI-007).
- No percentages, no "Checked" tag, no "no model was asked" line. Exact is unmarked; a model's reading is marked (UI-008).
- Details holds the ids, the bank line in full (`$7,000.00 · 1 Jul · STRIPE AU PAYOUT 7K2M`, from one formatter in `lib/format.js`, UI-039) and the workings, collapsed to "6 of 6 checks agree ▾" with no-change blocks omitted (UI-065).
- Captions about state are derived, never literal: "Will match the deposit when it lands" appears only when the engine says the payout is in transit (UI-036).
- Labels name their contents: "Other Stripe payouts", not "Similar approvals"; "Key facts", not "Recent Activity" (UI-060).

### 5.2 Decision behaviour

- **Press:** the button darkens and scales to 0.97 on pointer-down within 100 ms (UI-013). The label becomes "Using…" with `aria-busy`, at full opacity (UI-012).
- **Success:** the card collapses to a one-line past-tense plate built from the API's accepted result, before any refresh (UI-012, UI-024). The approver comes from `approverLabel()`: the recorded actor, then the signed-in person, then "you", plus the time. Undo stays in the plate for 10 s and afterwards on the record until the entry is posted (UI-009).
- **Failure:** the card stays open with the input intact. Under the button: "Not sent. Nothing was recorded." and Retry (UI-002).
- **Disabled:** never `pointer-events: none`. The control is `aria-disabled` and the reason is printed beside it: "Can't approve until the $150.00 gap is explained" (UI-014).
- **Forms inside cards** (closing balance, GST treatment, account) use the shared field kit: validate on blur, mark the field with its own message on submit, map the API's `detail.errors` to fields (UI-015). Money is typed in dollars, months are picked, accounts are chosen from imported accounts. No cents, no `YYYY-MM`, no `csv:` names (UI-034).

### 5.3 The card set in iteration 1 (re-homed from today's panels)

| Card | Replaces | Commit label | API route (unchanged unless noted) |
|---|---|---|---|
| Use this deposit | `BankPinPanel`, `CandidateList`, proposal Accept/Dismiss (UI-018) | Use this deposit | `POST /payouts/{id}/assertions` (bank pin) |
| GST treatment | `GstResolvePanel` | Save GST treatment | `POST /payouts/{id}/assertions` (gst) |
| What is this transaction? | `ClassifyPanel` | Save as {category} | `POST /payouts/{id}/assertions` (txn class) |
| Missing account | `ChartGapPanel` | Use {account} | `POST /payouts/{id}/assertions` (chart gap) |
| Approve entry | `ApprovalDetail`, `JournalEntry` | Approve $9,350.73 | `POST /approvals/{id}/approve` |
| Approve many | the `ApprovalQueue` bulk bar (UI-010) | Approve 24 · $412,380.10, which opens a preview list, then one commit | `POST /approvals/approve` |
| Post entry | Post in `ApprovalDetail` | opens the §3.7 sheet (only with a ledger connected) | `POST /approvals/{id}/post` |
| Reject entry | Reject in `ApprovalDetail` | Reject (reason sheet) | `POST /approvals/{id}/reject` |
| Exception decision | `ExceptionDetailRail` decisions | named by outcome | `POST /exception-queue/{id}/decisions` |
| Sync | `SyncButton` | Sync Stripe and Shopify (names only what is connected) | the existing sync action |
| Undo approve | none (new) | Undo | `POST /approvals/{id}/withdraw` (new) |

Bank rec inputs (account, closing balance, month) are **questions**, not decisions: answering one continues the bank rec. It never writes anything.

---

## 6. Workflows and tasks

### 6.1 Model

```
Task template (versioned; how a job is done — internal name "playbook", never shown)
   │ instantiated per month as
Task (month, title, status, decisions count)
   │ runs as
Conversation (append-only events; pinned to month and template version)
   │ produces
Decisions (action requests) · Results · Questions
```

- A **template** has an id, a title, synonyms, a one-line purpose, the records it may read, the decisions it may propose, what it produces, `needs_model`, and `model_tier: standard|hard`. Templates ship with the product.
- A **task** is one template in one month. Its status and decision count are computed by the engine from stored state, not stored; the API returns them computed and the screen never counts.
- A **conversation** is an append-only list of events (§4.2).

### 6.2 Rules first

Every iteration-1 task runs **without a model**: a sequence of engine reads that emits the same message types. The model is used where judgement is needed: understanding free-form requests (and starting tasks from them), answering questions over the records, suggestions on blocked payouts (the existing proposing job), and, later, explaining movement between months and drafting a question for the client. Vert is fully useful with the assistant unavailable (§10).

Tasks read stored state only. Reconciling happens when sources sync (the sync job ingests and reconciles); re-running reconciliation or syncing is offered as a card through the existing routes, pressed by a person. No task writes to the books or to engine state.

### 6.3 The monthly close template (AU)

| # | Task | Template | Needs model | Iteration |
|---|---|---|---|---|
| 1 | Check payouts | `payout_check` | no | 1 |
| 2 | Resolve payout breaks | `resolve_breaks` | no (stored model suggestions prefill cards when present) | 1 |
| 3 | Approve journal entries | `approve_entries` | no | 1 |
| 4 | Reconcile the bank account | `bank_reconciliation` | no | 1 |
| 5 | Build workpapers | `workpapers` | no | 1 |
| 6 | Prepaid expenses | `prepaid_schedule` | no | 2 |
| 7 | Post approved entries | `post_entries` | no | 2 (only when a ledger is connected) |
| 8 | Sign off and lock | manual | no | 2 |
| 9 | Review the month | `month_review` | yes | 3 (needs the GL feed) |

A task appears in the checklist and the progress bar only in the iteration that builds it. Syncing is not a task (§6.4).

### 6.4 What each iteration-1 task does

| Task | "What Vert did" line | Brings back |
|---|---|---|
| Check payouts | Checked 31 payouts against Stripe, Shopify and your September bank statement | "27 match the bank. 4 need you (see Resolve payout breaks). 2 are on their way." A Result card (payout list). Done once it has reported; payouts on their way are *Waiting* items in the list, not a reason to hold the task |
| Resolve payout breaks | Looked at 4 payouts that don't match | One decision per break, in engine priority. A stored model suggestion pre-fills the card and marks it "Vert's best guess — check this" |
| Approve journal entries | Gathered 24 entries ready to approve | "24 entries are ready: $412,380.10." An Approve-many card, plus one row per entry that opens its Approve card in place |
| Reconcile the bank account | Read your September statement and the books | Questions for any missing input, then the Result, verdict first: "Reconciles to the cent" / "$112.50 unexplained" / "Can't reconcile yet: 2 things missing" plus that checklist (UI-035). `Download Excel` |
| Build workpapers | Prepared the payout and bank rec workpapers | Waiting until payout breaks and the bank rec are done, with that reason. Then Result cards with `Download Excel` |
| Explain (any record) | none | The payout breakdown and the engine's own narration |

**Syncing is plumbing.** The existing scheduled sweep keeps sources fresh. Pressing Start also asks the existing sync action to refresh any connected source older than 24 hours. Freshness shows as words on Month-end and in the context sheet. A failed or stale source becomes a *Needs you* row: "Stripe hasn't synced since 3 Sep. Sync now".

---

## 7. Context

**Context is shown once per place, and never repeated.**

| Context | Where it's set | Where it's shown |
|---|---|---|
| Client | the access code (the firm switcher arrives in iteration 3) | sidebar label; the context chip |
| Month | the sidebar control; pinned per conversation (§2.2) | sidebar; the context chip |
| Sources and freshness | Connections | the foot of Month-end; the context sheet |
| What Vert read | automatic, from each step's citations | that turn's "What Vert did" line, expanded |
| Notes (iteration 2) | suggested by Vert after you correct it, active only once you accept | a "Used your note" chip on the answer that used it; the context sheet; "Notes Vert keeps" in the account menu. The one action is **Forget** |
| Files (iteration 3) | the composer's attach control, once documents are read for real | file chips in the thread; the context sheet |

Rules:

- Memory is never silent. A note that shaped an answer shows as a chip on that answer.
- A note can never widen what a task may read or do.
- Text from documents, memos and payer references is untrusted. It is never treated as instructions and never becomes a note without a person accepting it.

---

## 8. Approvals and autonomy

### 8.1 Gates

| Gate | When | Control |
|---|---|---|
| Decision | Any change to state in Vert (assertions, approvals, exception decisions, a sync) | The card's commit, one press; Undo where the engine allows it |
| Post | Anything written to the client's ledger | The §3.7 modal, restating the journal and the amount |
| Reject | Withdrawing a drafted entry, which can't be reopened | The reason sheet |
| Plan (iteration 2) | Model-run work of more than 3 steps | The Plan card |

Reading never asks, and neither does starting a task (tasks only read). Confirmation fatigue is a defect too.

### 8.2 Who did it

A person's press is recorded as that person through the existing actor rule. Vert's own work is recorded as Vert on behalf of the person who started the conversation, and it never uses a person's signature. Every decision line and every audit line names the actor (UI-024).

### 8.3 Autonomy (later, and not shown until it is a control)

There is no autonomy text on screen in iterations 1 and 2: Vert simply asks before anything is saved, and says so on the Post sheet. In iteration 3 a **"How Vert does this"** page per task appears, because it then has something to change:

1. **Ask me first** (default). Vert proposes; you press.
2. **Prepare, then ask.** Vert may stage drafts and assertions it is sure of; you approve in batches.
3. **Post routine entries** (later still). Only for tasks that passed their evaluation gate, under value caps, with a kill switch and a pre-computed reversal. It drops itself to (2) and says why whenever a cap trips.

---

## 9. Honesty and traceability (quiet but present)

### 9.1 Marking the exception, not the rule

- Exact results computed from the records carry no tag.
- A model's reading carries "Vert's best guess — check this" (the `basis: suggested` field). Nothing else is ever marked.

### 9.2 Figures are bound, never written

- Every money figure rendered anywhere, chat included, is a value the engine emitted (the no-arithmetic guard extends to chat).
- A model answer refers to figures by reference (`{{fig:payout/<id>/amount}}`); the server resolves each one from a cited tool result. A money-like number in model text that is not bound to a citation turns that answer into a Couldn't-tell note, and the reason is recorded. The model never does arithmetic that reaches the screen.
- One money formatter (parentheses for negatives in tables, a leading − in prose) and one date formatter ("15 Jun 2026"). ISO only in exports (UI-041).

### 9.3 Every figure opens its source

A `<Figure>` renders engine cents with tabular numerals. It is focusable, and on press it opens the **source sheet**: the rows behind the number with their source, ids under Details, and "See all payouts ›" to Records. The affordance is quiet: an underline on hover and focus only.

### 9.4 Unmeasured is never zero

A value the engine did not read renders as words: "Not read yet", "No September bank statement yet", "QuickBooks not connected". Absence of evidence is never $0.00 and never a green state. One gap figure per card (the absent-is-not-clean and one-gap-figure guards).

### 9.5 Replay is labelled

A conversation that is a recording (the static demo) carries a band: "Sample conversation, replayed. Not your books." Its answers are never captioned as live, and its composer is disabled with that reason.

---

## 10. When the assistant is unavailable

Vert supplies and runs the assistant. A bookkeeper never sees setup text, provider names, keys or settings. The API reports the real state (`GET /agent/status`) for operators and for the readiness check.

| State (API) | Meaning | What the bookkeeper sees |
|---|---|---|
| `live` | A worker for this client is running, and its last model call succeeded | Nothing extra |
| `not_verified` | A worker is running and configured but has never completed a call | Nothing extra; the request goes to the model, and a failure becomes a Problem line |
| `failing` | The last error is newer than the last success | Can do now |
| `off` | The worker is running without a configured provider | Can do now |
| `not_set_up` | No worker has ever reported for this client (for example, a deployment that runs no worker) | Can do now |
| `offline` | A worker reported before but not in the last 60 s | Can do now |

**Can do now** is the quiet fallback of the ask box:

- One clear match to a task: Vert runs it. "Doing the bank rec."
- Several matches, or none: "I can't answer questions right now. I can do these now:" followed by up to three task buttons, matched to the words where possible and otherwise the tasks that need you.

Rules:

- The fallback is decided when the message is sent, so a message is never left "Working" with nobody to answer it. A worker never answers a message that was queued before it came back.
- Vert never falls back silently to a canned reply or to another provider. It never presents the fallback as an answer to the question.
- Every task in §6.4 runs fully in every state.
- The operator remedy (which provider, which key reference) comes from the worker's own report and is shown only by the API and the readiness check.

**Provider wiring (engine).** The model runs only in the agent worker, never in the API process, through the existing provider seam: `VERT_MODEL_PROVIDER`, `VERT_MODEL_NAME` (standard), `VERT_MODEL_HARD_NAME` (hard tasks, and suggestions on payouts with rival deposits) and `VERT_MODEL_KEY_REF`. Supported pairs include Anthropic (`claude-sonnet-5` standard, `claude-opus-5` hard, key reference `env://ANTHROPIC_API_KEY`) and OpenAI. The build plan fixes which pair is used for development and tests.

---

## 11. Design system

This implements the apple-design standard (`~/.claude/skills/apple-design/SKILL.md`, cited as §n). Every value below is a token defined once, under `:root` in `app/styles/tokens.css`. A test bans raw hex and px font sizes outside that file (UI-043, UI-044).

### 11.1 Type (§15; UI-025 to UI-028, UI-046, UI-047, UI-070, UI-071)

`html { font-size: 100% }`. Every size and space is in rem, so the user's text size is respected. The face is `system-ui, -apple-system, "Segoe UI", Roboto, sans-serif` with `font-optical-sizing: auto`; figures use `font-variant-numeric: tabular-nums`. Satoshi is retired from the UI; the wordmark is an SVG.

| Token | Size | Leading | Tracking | Weight | Use |
|---|---|---|---|---|---|
| `--t-title-1` | 1.75rem | 1.15 | −0.02em | 700 | Page title (one per page) |
| `--t-title-2` | 1.5rem | 1.2 | −0.015em | 600 | Key figure on a result; sign-in wordmark size |
| `--t-title-3` | 1.25rem | 1.25 | −0.01em | 600 | Conversation title, sheet title |
| `--t-callout` | 1rem | 1.45 | −0.005em | 500/600 | Verdict lines, the card's proposal sentence |
| `--t-body` | 0.875rem | 1.5 | 0 | 400 | Everything else |
| `--t-footnote` | 0.75rem | 1.4 | +0.005em | 500 | Reasons, "What Vert did", table headers (sentence case, 600) |
| `--t-caption` | 0.6875rem | 1.4 | +0.01em | 500 | Timestamps, the best-guess mark. The floor: nothing is smaller |

Headings are never smaller than the body they head. A bare `h1`–`h4` without a scale class fails a test. No uppercase eyebrows: one sentence-case footnote-600 label style.

### 11.2 Colour (UI-029, UI-030, UI-040, UI-043, UI-045, UI-053, UI-054, UI-059)

Each colour has exactly one meaning.

| Token | Light | Dark | Meaning |
|---|---|---|---|
| `--ground` | #F4F5F7 | #0E0F12 | App background |
| `--surface` | #FFFFFF | #17191D | Cards, tables |
| `--surface-inset` | #F9FAFB | #1D2025 | Wells inside a surface (journal lines) |
| `--float` | rgba(255,255,255,.72) + blur 24px saturate 180% | rgba(28,30,35,.72) + same | Sheets, sticky bars, the phone top bar, the background notice |
| `--sidebar` | #EEF0F3 | #121418 | Sidebar (a quiet structural material, not black) |
| `--ink` | #15171B | #F2F3F5 | Primary text |
| `--ink-2` | #474D57 | #B9BEC7 | Secondary text, "What Vert did" (≥ 7:1) |
| `--ink-3` | #676D78 | #8E949E | Captions (≥ 4.5:1 on surface and on selected rows) |
| `--line` | #E5E7EB | #2A2E35 | Dividers in tables of 5 rows or more, only |
| `--line-control` | #8A90A0 | #6E7482 | Borders of inputs, selects, secondary buttons (≥ 3:1) |
| `--accent` | #4F1FE8 | #8F7BFF | **Commit only**: buttons that write (Use this deposit, Approve, Post, Start September, Connect) plus the focus ring |
| `--status-attention` | ink #8A5300, soft #FDF3E1 | ink #F2B45A, soft #3A2A10 | Needs you |
| `--status-working` | ink #1D5FD6, soft #E8F0FE | ink #7FA8F5, soft #14243F | Vert's working |
| `--status-neutral` | ink #5B616C, soft #EEF0F3 | ink #A3A9B3, soft #24272D | Waiting |
| `--status-done` | ink #16794A, soft #E7F5EC | ink #5BCB8E, soft #11301F | Done |
| `--problem` | ink #B42318, soft #FDECEA | ink #F97066, soft #3D1714 | Problem lines and errors (not a status) |

- Focus: a 2 px `--accent` ring offset 2 px on every focusable control, including `:focus-within` on fields and the composer.
- `forced-colors: active`: selected, active and commit states get a 2 px `CanvasText` outline; status marks use `forced-color-adjust: none` and always carry their word.
- `prefers-contrast: more`: `--line-control` and `--ink-3` darken one step; floats become solid.
- `prefers-color-scheme: dark` switches the token set, the working paper included, with a 200 ms colour cross-fade.
- Naming: the accent's tints are called a "tint scale" in code and comments.

### 11.3 Space, shape and materials (UI-029, UI-044, UI-058)

- A 4 px scale in rem: `--s-1` 0.25rem, `--s-2` 0.5rem, `--s-3` 0.75rem, `--s-4` 1rem, `--s-5` 1.5rem, `--s-6` 2rem, `--s-7` 3rem, `--s-8` 4rem. No inline `style={{margin|padding|gap}}` in new components.
- Radii: `--r-sm` 6px (controls), `--r-md` 10px (cards), `--r-lg` 16px (sheets, composer), `--r-pill`.
- Three materials: **ground**, **surface** (`--shadow-1: 0 1px 2px rgb(16 24 40 / .06), 0 2px 6px rgb(16 24 40 / .04)`) and **float** (blur plus `--shadow-pop: 0 12px 32px rgb(16 24 40 / .14)`). Nothing on a surface draws a border; boxes never nest more than two deep; a light float never sits on another float (§12).
- Key-value groups use spacing and weight, not hairlines. Rules appear only in tables of 5 rows or more.
- Scroll edges: a 12 px gradient mask under the sticky header, above the composer and in sheets, shown only while content is underneath (§12; UI-057).
- `prefers-reduced-transparency: reduce`: floats become solid `--surface`.

### 11.4 Motion (§1, §3, §7, §14; UI-013, UI-016, UI-017, UI-049, UI-050, UI-072)

Motion is feedback and orientation, nothing more (§16.1, Purpose).

**Iteration 1:**

| Token | Value | Use |
|---|---|---|
| Press | `:active { transform: scale(.97) }` plus darken, 100 ms ease-out, on pointer-down | Every pressable control: buttons, rows, chips, cards |
| Hover | Colour only, 120 ms, no delay, `@media (hover:hover)` | Pointer devices |
| `--ease-spring` | a CSS `linear()` curve equivalent to damping 1.0, response 0.35 s | Sheets and panels entering and leaving, disclosure height, card entry |
| `--ease-spring-snappy` | the same, response 0.25 s | A card collapsing to its decision line |
| Cross-fade | 120 ms opacity | Swapping the result in the pane, keyed by id (UI-072); theme (200 ms) |

- **Sheets** are CSS transitions on `transform` and `opacity`. A CSS transition reverses from its current value, so a sheet closed mid-open turns back without a jump (§3). A sheet enters from its own edge and leaves along the same path (§7); one opened from a control has its `transform-origin` at that control. Opening never reflows the page or moves the trigger. Focus goes to the sheet title, Esc closes, focus returns to the trigger (UI-017).
- **Disclosures** animate height with `grid-template-rows: 0fr → 1fr` and scroll the opened content into view (UI-050).
- **Working indicator:** the dotted ring rotates once per 1.2 s. Under reduced motion it is static and the words carry the state.
- **Reduced motion** (`prefers-reduced-motion: reduce`): every transition becomes a 150 ms opacity cross-fade with no transform; the feedback itself stays.
- **Latency:** the nav active state moves on pointer-down; every route segment has a `loading.js` skeleton; nothing on the input path waits on a timer (§1; UI-016).

**Iteration 2, the phone pass:** a small spring primitive (`lib/ui/spring.js`) for the bottom sheet and the nav sheet only: 1:1 drag with 10 px hysteresis and pointer capture (§2), velocity handed to the spring on release (§5), the rest point projected and snapped to a detent (§6), rubber-banding past the top detent (§9), starting from the presentation value (§3). Desktop never needs it.

### 11.5 Feedback (§13; §16 "Feedback comes in four kinds")

| Kind | Pattern | Example |
|---|---|---|
| Status | The "What Vert did" line while running; skeletons; "Approving…" on the pressed button with `aria-busy`; "Preparing Excel…" on file links | "Checking 31 payouts…" |
| Completion | The card collapses to a past-tense line naming who, what and when, with Undo; an `aria-live="polite"` announcement; the background notice for other conversations | "You approved $9,350.73 · 10:42 · Undo" |
| Warning | Before a problem, beside the control it concerns, in `--status-attention` | "QuickBooks isn't connected. Approving keeps it ready." |
| Error | A plain sentence, what was and wasn't recorded, Retry, and Details ▾ with the code. Input is never discarded | "Not sent. Nothing was recorded. Try again." |

No sound and no haptics on the web. No feedback fires on a frame other than its cause's (§13).

### 11.6 Components (`components/ui/`)

`Button` (commit, secondary, quiet; `aria-disabled` plus a reason), `IconButton`, `Field` / `MoneyField` / `MonthField` / `SelectField` (the validation kit), `Sheet` (side, bottom, modal), `Disclosure`, `StatusMark` (reads `lib/status.js`: four words), `Figure`, `SourceSheet`, `Notice` (the four kinds plus the anchored background notice), `Skeleton`, `ProgressBar` (values from the API), `Table` (roving tabindex, stacked below 700 px, right-edge fade on overflow), `BestGuess` (the one mark), `Kbd`.

---

## 12. What is removed, and where it went

### 12.1 Removed

| Removed | Why | Where the value went |
|---|---|---|
| The 9-item black rail and "Coming later" group | Half of it did nothing (UI-066, UI-059) | One nav item plus the Conversations list |
| Separate Today and Close pages | They repeated the same bar, counts and needs-you list | Month-end |
| Records and Connections as nav items | Evidence and settings, not destinations | Figures and task rows; the account menu |
| Payouts landing page, KPI strip, clearing table as a page | Organised by engine object (UI-063) | Month-end; Records › Payouts; the clearing roll-forward as a Result |
| The Vert AI rail (`AiRail`, `Stepper`, `ModelControl`, `ContextDrop`) | The agent lived on one screen, closed by default (UI-032) | The conversation; "What I did" becomes the one "What Vert did" line; context becomes the context sheet |
| Approvals queue page and 170 px cards | 3 of 24 visible; four badges each (UI-064, UI-007) | Approve and Approve-many cards; Records › Journal entries |
| Exceptions page and the 280 px investigation rail | 1,300–2,100 words per decision (UI-021, UI-033) | Resolve payout breaks, one card per break |
| Bank rec form | Cents, `csv:` names, broken styling (UI-034) | The bank rec task, asking in words |
| Setup as a separate page | It duplicated Connections (UI-061) | Month-end's first-run state |
| Confidence %, risk chips, "No model was asked", "Checked" tags | False precision; noise on every element (UI-007, UI-008) | The one "Vert's best guess" mark on model readings |
| Per-task "Start", the sync task | A click per task for work that needs no human; syncing is plumbing | "Start September" runs everything rules-only; automatic sync with freshness in words |
| Paging ("1 of 3 ‹ ›") | Hides how much is waiting | The needs-you list |
| The "brief" bubble, Used chips, durations | Blurred who said what; four lines before every answer | Conversation title; one "What Vert did" line |
| Payout ids and fixture names on the main path | Engineering names | Transaction lines; ids under Details |
| Greeting, "Open items", "Show all", New chat, the conversation index page | Words that don't earn their place | Nothing; the Needs-you filter; the scrolling list; the ask box |
| AI assistant row, "For your Vert admin", setup text, model and task-version names on screen | Not actionable by a bookkeeper (UI-020, UI-051) | The API status and readiness; "How this was produced" |
| Priority, days open, sub-ledger, the audit placeholder, provenance paragraphs | Noise on the main path | Details ▾ |
| Density toggle, filter chrome on short lists | Chrome over content | Nothing |
| Satoshi body type, 27 px sizes, px units | No scale (UI-025, UI-026) | §11.1 |

### 12.2 Redirects

`/payouts` → `/records`, `/approvals` → `/records?tab=entries`, `/exceptions` → `/records?filter=needs-you`, `/reconciliation/bank` → `/` (bank rec row open), `/setup` → `/connections`, `/close` → `/`, `/chat` → `/`, `/command` → `/`, `/insights` → `/`, `/checklist` → `/`. The older redirects in `next.config.mjs` (`/reconciliation`, `/reconciliation/payments`, `/reconciliation/approvals`, `/reconciliation/exceptions`, `/settings`) are rewritten to point at the final destination directly, so nothing chains. `/reconciliation/papers/[id]` stays, restyled with the shared tokens, a verdict band and a "‹ September" link (UI-022, UI-023, UI-048).

---

## 13. Copy principles

1. **Two actors.** "Vert" and "you". Never "the engine", "the verifier", "the agent", "a second agent", "the assistant" or "Vert AI" on the main path (UI-006).
2. **Accountant words.** A test enforces this glossary on rendered text:

| Don't say | Say |
|---|---|
| Parts net, decomposition | Transactions total, breakdown |
| Rolls forward / does not roll forward; tie / ties | Clears / doesn't clear; matches the bank |
| Record pin, bank pin | Use this deposit |
| Ground, assertion | How do you know?, your answer |
| Σ DEBITS | Total debits |
| Tenant | Client |
| Register | List (or omit) |
| Draft entry staged | Entry ready to approve |
| `gl_account`, `csv:<name>`, cents, YYYY-MM | Account, bank account name, dollars, month |
| Supersede | Replace |
| Abstained | Couldn't tell |
| ERP | QuickBooks / Xero (by name, from the API) |
| Playbook, brief, session, run | (nothing: say what Vert is doing) |
| Checked, Suggested | (nothing), Vert's best guess — check this |
| Blocked, Stuck, In transit, To do, Working, Approved (as a status) | Needs you (+ reason), Needs you (+ Problem line), Waiting (+ "on its way to the bank"), (not a state), Vert's working, Done |
| API key, `vk_live_` | Your Vert access code |
| Entries | Journal entries |
| Open items | Needs you |
| Start over | Run again |

3. **Verdict first; one line each.** A screen header is one line. A card is at most 25 words before Details. An answer is at most 60 words before More.
4. **Say what is, not what isn't.** "Covers Stripe and Shopify payouts. What's included ›", not "This is not a report that…". A negative stays only where it is the finding ("No deposit found").
5. **Never contradict yourself in one card.** If Vert suggests something, give one reason. If it can't choose, ask, and suggest nothing.
6. **Transactions, not ids.** "Stripe payout · 2 Jul · $7,000.00". Ids and fixture names appear only under Details, and fixture names never render at all.
7. **One format for numbers and dates** (§9.2).
8. **Specific labels.** A label names its contents (UI-060). The nav item names its destination.
9. **No counts beside derived lists.** Compute the count from the list, or leave it out (UI-037). Every "need you" count counts decisions.
10. **Plain errors.** What happened, what was recorded, what to do. Codes under Details.
11. **The chat's voice** is a competent senior bookkeeper: specific, calm, no celebration, no hedging, no architecture. "Doing the bank rec." "I" only for work Vert did. Rules-only results are stated as facts.

---

## 14. Engine and API surface (summary; the build plan holds the field-level contract)

- **One migration (028):** `close_months`, `agent_sessions`, `agent_events` (append-only), `agent_turns` (the worker queue), `agent_actions`, `agent_worker_status`. All are tenant tables built on the 027 pattern: `vert_current_tenant()` policies, forced RLS, `REFERENCES tenants`, composite foreign keys, named vocabulary constraints, append-only triggers where rows never change, and column-level grants where they do. The same migration widens `approvals_decision_vocabulary` to add `withdraw` and allows a payout's approved → awaiting-approval transition (Undo approve).
- **New routes:** `GET /close/periods`, `GET /close/{period}`, `POST /close/{period}` (open the month and run the rules-only tasks), `POST /agent/sessions`, `GET /agent/sessions`, `GET /agent/sessions/{id}`, `GET /agent/sessions/{id}/events` (SSE, short-lived, resumable by `seq`), `POST /agent/sessions/{id}/messages`, `POST /agent/sessions/{id}/cancel`, `POST /agent/actions/{id}/settle`, `POST /agent/actions/{id}/decline`, `GET /agent/status`, `POST /approvals/{id}/withdraw`.
- **One write road.** Decisions execute through the existing routes via the existing server actions (gates, idempotency, the actor rule). The conversation then records a *settled* action, which the API verifies by reading the target back, and re-verifies whenever it lists pending actions. Neither the agent worker nor a task ever writes to the books.
- **Where things run.** Rules-only tasks run inside the request that starts them, each until its first decision or its end, with a time cap. Model turns run only in the agent worker, which has no API code on disk and serves a fixed list of clients.

---

## 15. How this spec is judged

The build plan holds the scoreable rubric. Headline thresholds:

- **Simplicity.** 1 nav item (2 with the firm layer). Words above the fold: sign in ≤ 30, Month-end ≤ 120, a conversation after a result ≤ 150, Records ≤ 150, Connections ≤ 100. At most 5 concepts above the fold per screen. Exactly one filled button above the fold per view with an action. At most 4 distinct status words across the product. Every "need you" count on a screen agrees. Clicks from Month-end: start the month 1, fix a break with the suggestion 1, approve one entry ≤ 2, approve a batch ≤ 3, bank rec ≤ 3 plus one typed amount, trace a figure 1, start any task by typing 0 plus Enter.
- **Apple-design checks.** Press feedback within 100 ms. Rem type that scales with the browser's size. 7 type sizes. Sheets in the viewport with focus, Esc and focus return at 1024 and 390 px; reversible mid-flight without a jump. Reduced motion, reduced transparency, forced colours and dark mode. No horizontal scroll at 390 px. A skip link.
- **Honesty and correctness.** Every sampled figure equals the API's cents and opens its source. No unread value shown as $0.00. One status word per item across all surfaces. Nothing posts without the modal. A network failure leaves the shell standing and says what was recorded. With the assistant unavailable, the ask box still starts work and never shows setup or provider words. No task is shown that isn't built. No id or fixture name on the main path. The static demo labels its replay.
