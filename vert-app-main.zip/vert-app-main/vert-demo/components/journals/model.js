// components/journals/model.js — THE JOURNALS PAGE, AS DATA (W3 feature 2). Pure.
// ==============================================================================
// Every journal entry by its type and where it stands, the recurring entries, the
// schedules and the asset register. Nothing here is fetched or written: app/journals
// reads the engine, components/journals draws, and this file turns one into the other.
//
// THE KIND IS THE ENGINE'S (`entryKind` on every GET /journal row): the kind the person
// said when they wrote it, else the engine's inference. It is never worked out here.
//
// WHERE AN ENTRY STANDS uses the ledger-status rule of the rest of the app: a posted
// entry the ledger holds as a DRAFT is "Sent to {ledger} as a draft", never "Posted"
// (components/cards/words.js ledgerStatusTerm). An entry the engine set aside (edited,
// rejected, withdrawn) is listed under "Set aside", never as posted.

import { ledgerStatusTerm } from "@/components/cards/words";
import { closeMonthOf, isPeriod, shiftMonth, shownMonth } from "@/lib/period";

/**
 * THE PAGE'S MONTH IS THE SIDEBAR'S (live check, 29 Oct 2026). The page read the browser's
 * month choice alone, so New entry dated itself in 30 Sep on one open and 31 Jul on the
 * next while the sidebar said July. This is the sidebar's own rule (lib/period.js
 * shownMonth over the months listing, the choice and the close month): a month named in
 * the address, else the month the sidebar shows, else the choice, else the close month.
 */
export function journalsMonth({ requested = null, listed = null, chosen = null, now = new Date() } = {}) {
  if (isPeriod(requested)) return requested;
  const close = closeMonthOf(now);
  return shownMonth(listed, chosen, close) || (isPeriod(chosen) ? chosen : null) || close;
}
import { MONTHS_LONG, formatDate, typeset } from "@/lib/format";

//: The furthest New entry looks past the page's month for one that isn't signed off.
export const OPEN_MONTH_REACH = 12;

/**
 * THE MONTH NEW ENTRY DATES ITSELF IN (UI walk D4, 30 Oct 2026): the page's month, or
 * when that month is signed off, the first month after it that isn't. With September
 * signed off the editor opened on 30 Sep, and Save was refused for the closed month.
 * `signedOff` maps a month to the engine's `signedOff` (GET /close/{period}/lock), true,
 * false or unread (absent); only a month READ as signed off is stepped past, so an
 * unread lock leaves the month as it was and the engine decides on Save. Pure.
 */
export function firstOpenMonth(period, signedOff) {
  if (!isPeriod(period)) return null;
  const read = signedOff instanceof Map ? signedOff : new Map();
  let month = period;
  for (let i = 0; i < OPEN_MONTH_REACH && read.get(month) === true; i += 1) month = shiftMonth(month, 1);
  return month;
}

/** Every kind a person may say an entry is (vert_engine MANUAL_ENTRY_KINDS), in the
 *  order the picker offers them, with the words a screen shows. */
export const ENTRY_TYPES = Object.freeze([
  { value: "adjusting", label: "Adjusting" },
  { value: "accrual", label: "Accrual" },
  { value: "payroll", label: "Payroll" },
  { value: "reclass", label: "Reclass" },
  { value: "prepaid_release", label: "Prepaid release" },
  { value: "amortisation", label: "Amortisation" },
  { value: "depreciation", label: "Depreciation" },
  { value: "reversal", label: "Reversal" },
  { value: "other", label: "Other" },
]);

/** The words for every kind the engine reports (posting/effects ENTRY_NOUNS' keys). */
export const KIND_LABELS = Object.freeze({
  ...Object.fromEntries(ENTRY_TYPES.map((t) => [t.value, t.label])),
  revenue_release: "Revenue release",
  payout: "Payout",
  bank_rec: "Bank reconciliation",
  recurring: "Recurring",
});

export function kindLabel(kind) {
  return (typeof kind === "string" && KIND_LABELS[kind]) || null;
}

/** The type filter's options: All, then each kind actually listed (in a stable order),
 *  then Recurring when any entry was drafted by a recurring template. */
export function typeOptions(rows) {
  const present = new Set((rows || []).map((r) => r.kind).filter(Boolean));
  const order = Object.keys(KIND_LABELS);
  const kinds = order.filter((k) => k !== "recurring" && present.has(k));
  const opts = [{ value: "all", label: "All types" }, ...kinds.map((k) => ({ value: k, label: KIND_LABELS[k] }))];
  if ((rows || []).some((r) => r.recurring)) opts.push({ value: "recurring", label: "Recurring" });
  return opts;
}

/** Where an entry stands, one of STATUS_FILTERS' values, from the engine's own fields. */
export function standingOf(entry) {
  const e = entry && typeof entry === "object" ? entry : {};
  const state = e.approvalState;
  if (state === "posted" || e.status === "posted") {
    if (e.ledgerStatus === "draft") return "sent_as_draft";
    return "posted";
  }
  if (state === "approved") return "approved";
  if (state === "rejected" || state === "discarded" || e.status === "discarded") return "set_aside";
  if (state === "blocked") return "blocked";
  return "awaiting";
}

/** The status filter's options. The ledger is named as the API names it. */
export function statusFilters(ledgerName = null) {
  return [
    { value: "all", label: "Every status" },
    { value: "awaiting", label: "Draft, awaiting approval" },
    { value: "approved", label: "Approved, not posted" },
    { value: "sent_as_draft", label: ledgerStatusTerm("draft", ledgerName) },
    { value: "posted", label: "Posted" },
    { value: "set_aside", label: "Set aside" },
  ];
}

/** The words for where an entry stands. A ledger draft names its ledger, never "Posted". */
export function standingWords(entry, ledgerName = null) {
  const standing = standingOf(entry);
  if (standing === "sent_as_draft") return ledgerStatusTerm("draft", ledgerName);
  if (standing === "posted") return entry && entry.ledgerStatus === "recorded" ? "Kept in a recording ledger" : ledgerStatusTerm("posted", ledgerName);
  if (standing === "approved") return "Approved, not posted";
  if (standing === "set_aside") return "Set aside, not posted";
  if (standing === "blocked") return "Blocked";
  return "Draft, awaiting approval";
}

function text(...values) {
  for (const v of values) if (typeof v === "string" && v.trim()) return v.trim();
  return null;
}

/** "period ending 2026-10-31" → "period ending 31 Oct 2026": engine prose, typeset. Pure. */
function daysInWords(memo) {
  return memo ? typeset(memo) : memo;
}

/**
 * THE DATE CELL (staging browser walk 1, D17): the entry's own date; else, for an entry
 * the engine sends no date for, what is known — "Not dated · posted 31 Oct 2026", or
 * "Not dated yet". Never a bare "No date" over an entry posted in the ledger. Pure.
 */
function dateWords(date, entry) {
  if (date) {
    try {
      return formatDate(date);
    } catch {
      return date;
    }
  }
  const posted = entry && (entry.status === "posted" || entry.approvalState === "posted") && typeof entry.postedAt === "string" ? entry.postedAt : null;
  if (posted) {
    try {
      return `Not dated · posted ${formatDate(posted)}`;
    } catch {
      return "Not dated";
    }
  }
  return "Not dated yet";
}

/** GET /journal's body → the Entries tab's rows. Null when the list was not read. */
export function entryRows(journal) {
  const entries = journal && Array.isArray(journal.entries) ? journal.entries : null;
  if (!entries) return null;
  const ledgerName = journal.ledger && typeof journal.ledger === "object" ? text(journal.ledger.displayName) : null;
  return entries.map((e) => {
    const manual = e.manual && typeof e.manual === "object" ? e.manual : null;
    const kind = text(e.entryKind) || null;
    const recurring = e.recurring && typeof e.recurring === "object" ? e.recurring : null;
    const date = text(e.entryDate, manual && manual.entryDate, e.date);
    return {
      id: text(e.externalId),
      // An ISO day in the engine's memo reads as a day ("period ending 31 Oct 2026").
      memo: daysInWords(text(e.memo)) || "Journal entry",
      dateWords: dateWords(date, e),
      kind,
      kindLabel: recurring ? `${kindLabel(kind) || "Entry"} · recurring` : kindLabel(kind) || "Entry",
      recurring,
      stated: Boolean(manual && manual.entryKind),
      date,
      period: text(e.period, manual && manual.period),
      cents: Number.isInteger(e.sumDr) ? e.sumDr : null,
      standing: standingOf(e),
      standingWords: standingWords(e, ledgerName),
      autoReverseOn: text(manual && manual.autoReverseOn),
      href: e.externalId ? `/records?tab=entries&entry=${encodeURIComponent(e.externalId)}` : null,
    };
  });
}

/** The rows a type and a status filter keep. */
export function filterEntries(rows, { type = "all", status = "all" } = {}) {
  return (rows || []).filter((r) => {
    if (type === "recurring" && !r.recurring) return false;
    if (type !== "all" && type !== "recurring" && r.kind !== type) return false;
    if (status !== "all" && r.standing !== status) return false;
    return true;
  });
}

// ─────────────────────────── recurring ───────────────────────────

export const REPEAT_OPTIONS = Object.freeze([
  { value: "off", label: "Off" },
  { value: "monthly", label: "Monthly" },
  { value: "quarterly", label: "Quarterly" },
  { value: "annually", label: "Annually" },
]);

export const STATUS_LABELS = Object.freeze({ proposed: "Not started", active: "Repeating", paused: "Paused", ended: "Ended" });

/** GET /recurring-journals' body → the Recurring tab's rows. Null when not read. */
export function recurringRows(body) {
  const list = body && Array.isArray(body.templates) ? body.templates : null;
  if (!list) return null;
  return list.map((t) => ({
    id: t.id,
    memo: t.memo,
    kindLabel: kindLabel(t.entryKind) || "Entry",
    cents: Number.isInteger(t.totalCents) ? t.totalCents : null,
    status: t.status,
    statusLabel: STATUS_LABELS[t.status] || t.status,
    scheduleWords: t.scheduleWords || "",
    nextRun: t.nextRun || null,
    nextRunWords: t.nextRunWords || "",
    drafted: Array.isArray(t.drafted) ? t.drafted.length : 0,
    // The months it will never draft, and why (a closed month, a refused line, a month
    // that fell while it was paused): the engine's own words.
    skipped: Array.isArray(t.skipped) ? t.skipped.map((x) => x && x.words).filter(Boolean) : [],
    // What a person may press, by the template's state.
    actions: t.status === "active" ? ["generate", "pause", "end"] : t.status === "paused" ? ["resume", "end"] : t.status === "proposed" ? ["resume", "end"] : [],
  }));
}

export const ACTION_LABELS = Object.freeze({ generate: "Draft due now", pause: "Pause", resume: "Resume", end: "End" });

/** The Resume button says Start for a template nobody has started yet. */
export function actionLabel(action, status) {
  if (action === "resume" && status === "proposed") return "Start";
  return ACTION_LABELS[action] || action;
}

function lastDayOf(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || ""));
  if (!m) return false;
  const last = new Date(Date.UTC(Number(m[1]), Number(m[2]), 0)).getUTCDate();
  return Number(m[3]) === last;
}

/**
 * The editor's state → `POST /recurring-journals` (vert_api TemplateBody). The first
 * draft is dated the editor's date; it repeats on that day of the month, or on the last
 * day when the date is a month's last. The end is a date or a count, never both.
 * `lines` are journal-model.js draftBody's lines.
 */
export function recurringBody(state, lines) {
  const s = state || {};
  const body = {
    memo: String(s.memo || "").trim(),
    lines,
    frequency: s.repeat,
    startOn: s.date,
    autoReverse: false,
  };
  // THE REVERSAL IS THE PERSON'S, AS A RULE (review fix, 28 Oct 2026): a repeating
  // entry reverses on the same day of the month after each one. The day they chose is
  // sent (`reverseOnDay`), never dropped for "the 1st"; a day outside the next month is
  // held by repeatGate, never quietly moved.
  const reverseDay = repeatReverseDay(s);
  if (reverseDay) {
    body.autoReverse = true;
    body.reverseOnDay = reverseDay;
  }
  if (s.entryKind) body.entryKind = s.entryKind;
  if (!lastDayOf(s.date)) {
    const day = Number(String(s.date || "").slice(8, 10));
    if (day >= 1 && day <= 31) body.dayOfMonth = day;
  }
  if (s.repeatEnd === "on" && /^\d{4}-\d{2}-\d{2}$/.test(String(s.repeatUntil || ""))) body.endOn = s.repeatUntil;
  if (s.repeatEnd === "after") {
    const n = Number.parseInt(String(s.repeatCount || ""), 10);
    if (Number.isInteger(n) && n >= 1) body.maxOccurrences = n;
  }
  return body;
}


/** The month after `iso`'s, as `YYYY-MM`, or null. */
function nextMonthOf(iso) {
  const m = /^(\d{4})-(\d{2})-\d{2}$/.exec(String(iso || ""));
  if (!m) return null;
  const y = Number(m[1]) + (Number(m[2]) === 12 ? 1 : 0);
  const mo = Number(m[2]) === 12 ? 1 : Number(m[2]) + 1;
  return `${y}-${String(mo).padStart(2, "0")}`;
}

/** The day of the next month a repeating entry reverses on, from the date the person
 *  chose, or null when it doesn't reverse (or the date isn't in the next month). */
export function repeatReverseDay(state) {
  const s = state || {};
  const on = String(s.autoReverseOn || "");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(on)) return null;
  if (on.slice(0, 7) !== nextMonthOf(s.date)) return null;
  return Number(on.slice(8, 10));
}

/** What the repeat's reversal will do, in words, or null when it doesn't reverse. */
export function reversalRuleWords(state) {
  const day = repeatReverseDay(state);
  if (!day) return null;
  return day === 1 ? "Each one reverses on the 1st of the month after it." : `Each one reverses on day ${day} of the month after it.`;
}

/** Why the repeat cannot be saved yet, in words, or null. */
export function repeatGate(state) {
  const s = state || {};
  if (!s.repeat || s.repeat === "off") return null;
  if (s.repeatEnd === "on" && !/^\d{4}-\d{2}-\d{2}$/.test(String(s.repeatUntil || ""))) return "Choose the day it stops repeating.";
  if (s.repeatEnd === "on" && s.date && s.repeatUntil < s.date) return "It stops before its first date.";
  if (s.repeatEnd === "after") {
    const n = Number.parseInt(String(s.repeatCount || ""), 10);
    if (!(Number.isInteger(n) && n >= 1)) return "Say how many times it happens.";
  }
  if (s.autoReverseOn && !repeatReverseDay(s)) {
    const next = nextMonthOf(s.date);
    const name = next ? `${MONTHS_LONG[Number(next.slice(5, 7)) - 1]} ${next.slice(0, 4)}` : "the next month";
    return `A repeating entry reverses in the month after each one: choose a day in ${name}.`;
  }
  return null;
}

// ─────────────────────────── schedules ───────────────────────────

const SCHEDULE_KIND_LABELS = Object.freeze({ accrual: "Accrual", amortisation: "Amortisation", deferred_revenue: "Deferred revenue", prepaid: "Prepaid expense" });

/** A schedule's state in the product's status words (lib/status.js), with what it
 *  means. Never the engine's lowercase token. */
const SCHEDULE_STATUS_WORDS = Object.freeze({
  proposed: "Needs you · not approved yet",
  active: "Waiting · releasing each month",
  completed: "Done",
  cancelled: "Done · stopped early",
  terminated: "Done · stopped early",
  superseded: "Done · replaced",
});

export function scheduleStatusWords(status) {
  return (typeof status === "string" && SCHEDULE_STATUS_WORDS[status]) || "Not said";
}

/** The first period not yet drawn: its end date, or null. */
function nextRelease(periods) {
  const list = Array.isArray(periods) ? periods : [];
  const next = list.find((p) => p && !p.entryExternalId);
  return next ? next.periodEnd || null : null;
}

/**
 * The Schedules tab's rows from each schedule as its OWN read reports it (GET
 * /schedules/{id}, /prepaid/schedules/{id}: the entries read, so remaining is measured).
 * A schedule whose detail was not read says so: its remaining is null with words, never
 * $0.00 (an unread zero is not a measured zero).
 */
export function scheduleRows({ generic = null, prepaid = null } = {}) {
  const rows = [];
  for (const s of generic || []) {
    if (!s || typeof s !== "object") continue;
    const measured = s.measured === true;
    rows.push({
      id: s.scheduleId,
      kind: s.kind,
      kindLabel: SCHEDULE_KIND_LABELS[s.kind] || s.kind || "Schedule",
      subject: text(s.subject) || SCHEDULE_KIND_LABELS[s.kind] || "Schedule",
      status: s.status || null,
      statusWords: scheduleStatusWords(s.status),
      totalCents: Number.isInteger(s.baseMinor) ? s.baseMinor : null,
      remainingCents: measured && Number.isInteger(s.remainingMinor) ? s.remainingMinor : null,
      remainingWords: measured ? null : "Not read yet",
      nextRelease: measured ? nextRelease(s.periods) : null,
      startDate: s.startDate || null,
      endDate: s.endDate || null,
    });
  }
  for (const s of prepaid || []) {
    if (!s || typeof s !== "object") continue;
    const measured = s.measured === true;
    rows.push({
      id: s.scheduleId,
      kind: "prepaid",
      kindLabel: SCHEDULE_KIND_LABELS.prepaid,
      subject: text(s.vendor) ? `Prepaid · ${s.vendor}` : "Prepaid expense",
      status: s.status || null,
      statusWords: scheduleStatusWords(s.status),
      totalCents: Number.isInteger(s.amortisableMinor) ? s.amortisableMinor : null,
      remainingCents: measured && Number.isInteger(s.remainingMinor) ? s.remainingMinor : null,
      remainingWords: measured ? null : "Not read yet",
      nextRelease: measured ? nextRelease(s.releases) : null,
      startDate: s.startDate || null,
      endDate: s.endDate || null,
    });
  }
  return rows;
}

/** The schedule form → `POST /schedules` (vert_api ScheduleBody). Money in cents. */
export function scheduleBody(form) {
  const f = form || {};
  const body = {
    kind: f.kind,
    amountMinor: Number.isInteger(f.amountCents) ? f.amountCents : undefined,
    startDate: f.startDate || undefined,
    termMonths: Number.parseInt(String(f.termMonths || ""), 10) || undefined,
    rule: "straight_line",
    weighting: "equal",
    recognitionAccount: String(f.recognitionAccount || "").trim() || undefined,
    subject: String(f.subject || "").trim(),
    // The GST inside the amount: none unless said, which is a stated zero.
    taxKnown: true,
    taxMinor: 0,
  };
  if (f.kind === "amortisation") {
    body.carrierAccount = String(f.carrierAccount || "").trim() || undefined;
    if (String(f.openingCounterAccount || "").trim()) body.openingCounterAccount = f.openingCounterAccount.trim();
  }
  for (const k of Object.keys(body)) if (body[k] === undefined) delete body[k];
  return body;
}

// ─────────────────────────── fixed assets ───────────────────────────

export function assetRows(body) {
  const list = body && Array.isArray(body.assets) ? body.assets : null;
  if (!list) return null;
  return list.map((a) => ({
    id: a.assetId,
    name: text(a.description) || text(a.assetNumber) || "Asset",
    assetClass: text(a.assetClass),
    status: a.status || null,
    costCents: Number.isInteger(a.costMinor) ? a.costMinor : null,
    inService: a.inServiceDate || null,
    method: a.method || null,
    lifeMonths: Number.isInteger(a.usefulLifeMonths) ? a.usefulLifeMonths : null,
  }));
}

/** The month's last day, `YYYY-MM-DD`, for "draft this month's depreciation". */
export function monthEnd(period) {
  const m = /^(\d{4})-(0[1-9]|1[0-2])$/.exec(String(period || ""));
  if (!m) return null;
  const last = new Date(Date.UTC(Number(m[1]), Number(m[2]), 0)).getUTCDate();
  return `${m[1]}-${m[2]}-${String(last).padStart(2, "0")}`;
}

export const TABS = Object.freeze([
  { value: "entries", label: "Entries" },
  { value: "recurring", label: "Recurring" },
  { value: "schedules", label: "Schedules" },
  { value: "assets", label: "Fixed assets" },
]);

export function tabFrom(value) {
  return TABS.some((t) => t.value === value) ? value : "entries";
}
