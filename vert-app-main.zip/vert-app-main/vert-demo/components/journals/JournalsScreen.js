"use client";

// components/journals/JournalsScreen.js — JOURNALS: EVERY ENTRY, WHAT REPEATS, SCHEDULES
// ==============================================================================
// W3 feature 2 (27 Oct 2026). Co-founder: "the base is already set up; the real changes
// are more to do with the UI". Writing an entry by hand used to be reachable only from
// inside a conversation; this page is a sidebar destination with:
//
//   Journals                                                    [+ New entry]
//   Entries   Recurring   Schedules   Fixed assets
//   [All types ⌄] [Every status ⌄]
//   Office rent        Adjusting · recurring   31 Aug   $4,000.00   Draft, awaiting approval
//
// NEW ENTRY opens the hand-written editor (JournalEditor `create`) in a sheet, with its
// type, the day it reverses on, and Repeat. Saving drafts — nothing here approves or
// posts; the draft waits on its card for someone other than its drafter.
//
// THE STATUS WORDS ARE THE LEDGER'S (model.js standingWords): an entry the ledger holds as a
// draft reads "Sent to {the ledger} as a draft", never "Posted". A list that wasn't read says
// so in words; it is never drawn as an empty list.

import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";

import { Button, DateField, Figure, MoneyField, Notice, Segmented, Sheet, Table } from "@/components/ui";
import JournalEditor from "@/components/cards/JournalEditor";
import { callSafely } from "@/lib/decisions";
import { useWritesEnabled } from "@/lib/engine-context";
import { formatDate, metaLine } from "@/lib/format";
import { monthName } from "@/lib/period";
import { createSchedule, draftDepreciation, generateRecurring, setRecurring } from "@/lib/journal";
import { IconAdd } from "@/components/ui/icons";
import "./journals.css";

import {
  statusFilters,
  TABS,
  actionLabel,
  assetRows,
  entryRows,
  filterEntries,
  monthEnd,
  recurringRows,
  scheduleBody,
  scheduleRows,
  typeOptions,
} from "./model";

function day(value) {
  return value ? formatDate(value) : "No date";
}

function money(cents, id, unread = "Not read yet") {
  return <Figure cents={cents} measured={Number.isInteger(cents)} unread={unread} style="table" figure={`journals/${id}`} />;
}

function NotRead({ what }) {
  return (
    <Notice kind="warning" recorded="nothing">
      Vert couldn&apos;t read {what} just now, so nothing is listed. That doesn&apos;t mean there are none.
    </Notice>
  );
}

function Result({ result }) {
  if (!result) return null;
  if (!result.ok) {
    return (
      <Notice kind="error" recorded="nothing">
        {result.message || "Vert couldn't do that. Nothing was changed."}
      </Notice>
    );
  }
  const words = result.body && typeof result.body.words === "string" ? result.body.words : "Done.";
  return <Notice kind="completion">{words}</Notice>;
}

// ─────────────────────────── entries ───────────────────────────

function EntriesTab({ journal }) {
  const rows = useMemo(() => entryRows(journal), [journal]);
  const [type, setType] = useState("all");
  const [status, setStatus] = useState("all");
  if (!rows) return <NotRead what="your journal entries" />;
  const shown = filterEntries(rows, { type, status });
  const columns = [
    { key: "memo", label: "Entry for" },
    { key: "kind", label: "Type" },
    { key: "date", label: "Date" },
    { key: "total", label: "Total", numeric: true },
    { key: "status", label: "Status" },
  ];
  return (
    <section className="journals-section" aria-label="Journal entries">
      <div className="journals-filters">
        <label className="field">
          <span className="field-label">Type</span>
          <select className="field-input" name="type-filter" autoComplete="off" value={type} onChange={(e) => setType(e.target.value)}>
            {typeOptions(rows).map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span className="field-label">Status</span>
          <select className="field-input" name="status-filter" autoComplete="off" value={status} onChange={(e) => setStatus(e.target.value)}>
            {statusFilters(journal && journal.ledger ? journal.ledger.displayName : null).map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        </label>
        <p className="t-footnote ink-2 journals-count" aria-live="polite">
          {shown.length === rows.length ? `${rows.length} entr${rows.length === 1 ? "y" : "ies"}` : `${shown.length} of ${rows.length} entries`}
        </p>
      </div>
      <Table
        caption="Journal entries"
        columns={columns}
        empty={rows.length ? "No entries match these filters." : "No journal entries yet. New entry writes one."}
        rows={shown.map((r) => ({
          id: r.id,
          href: r.href,
          cells: {
            memo: r.memo,
            kind: r.kindLabel,
            date: r.dateWords || day(r.date),
            total: money(r.cents, r.id),
            status: <span data-standing={r.standing}>{r.standingWords}</span>,
          },
        }))}
      />
    </section>
  );
}

// ─────────────────────────── recurring ───────────────────────────

function RecurringTab({ recurring, period }) {
  const router = useRouter();
  const writes = useWritesEnabled();
  const rows = useMemo(() => recurringRows(recurring), [recurring]);
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(null);
  const [, startTransition] = useTransition();
  if (!rows) return <NotRead what="your recurring entries" />;

  async function press(row, action) {
    setBusy(`${row.id}:${action}`);
    const answer = action === "generate" ? await callSafely(generateRecurring, { id: row.id, through: period }) : await callSafely(setRecurring, { id: row.id, verb: action });
    setBusy(null);
    setResult(answer);
    if (answer && answer.ok) startTransition(() => router.refresh());
  }

  const columns = [
    { key: "memo", label: "Entry" },
    { key: "schedule", label: "Repeats" },
    { key: "next", label: "Next draft" },
    { key: "total", label: "Each time", numeric: true },
    { key: "status", label: "Status" },
    { key: "actions", label: "Actions" },
  ];
  return (
    <section className="journals-section" aria-label="Recurring entries">
      <Result result={result} />
      <Table
        caption="Recurring entries"
        columns={columns}
        empty="Nothing repeats yet. Turn on Repeat when you write a new entry."
        rows={rows.map((r) => ({
          id: r.id,
          cells: {
            memo: (
              <span>
                {r.memo}
                <span className="t-footnote ink-2 journals-sub">{r.kindLabel}</span>
              </span>
            ),
            schedule: <span className="t-footnote">{r.scheduleWords}</span>,
            next: (
              <span className="t-footnote">
                {r.nextRunWords}
                {r.skipped.length ? <span className="journals-sub ink-2">Skipped: {metaLine(r.skipped, { joiner: "; " })}</span> : null}
              </span>
            ),
            total: money(r.cents, r.id),
            status: r.statusLabel,
            actions: (
              <span className="journals-actions">
                {r.actions.map((a) => (
                  <Button key={a} size="sm" variant={a === "generate" || (a === "resume" && r.status === "proposed") ? "secondary" : "quiet"} busy={busy === `${r.id}:${a}`} disabledReason={writes ? undefined : "This is a sample month, so nothing can be changed."} onClick={() => press(r, a)}>
                    {a === "generate" ? `Draft due through ${monthName(period)}` : actionLabel(a, r.status)}
                  </Button>
                ))}
              </span>
            ),
          },
        }))}
      />
    </section>
  );
}

// ─────────────────────────── schedules ───────────────────────────

const SCHEDULE_START = Object.freeze({ kind: "accrual", subject: "", amountCents: null, startDate: "", termMonths: "12", recognitionAccount: "", carrierAccount: "", openingCounterAccount: "" });

function ScheduleForm({ onDone }) {
  const router = useRouter();
  const writes = useWritesEnabled();
  const [form, setForm] = useState(SCHEDULE_START);
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (name, value) => setForm((f) => ({ ...f, [name]: value }));
  const gate = !Number.isInteger(form.amountCents) ? "Enter the amount." : !form.startDate ? "Choose the first day it covers." : !(Number.parseInt(form.termMonths, 10) >= 1) ? "Say how many months it runs." : !form.recognitionAccount.trim() ? "Name the account each month goes to." : form.kind === "amortisation" && !form.carrierAccount.trim() ? "Name the account it is carried in." : null;

  async function save(event) {
    event.preventDefault();
    if (gate || busy) return;
    setBusy(true);
    const answer = await callSafely(createSchedule, scheduleBody(form));
    setBusy(false);
    setResult(answer);
    if (answer && answer.ok) {
      router.refresh();
      if (onDone) onDone();
    }
  }

  return (
    <form className="journals-form" onSubmit={save} data-form="schedule">
      <Segmented
        label="Schedule kind"
        options={[
          { value: "accrual", label: "Accrual" },
          { value: "amortisation", label: "Amortisation" },
        ]}
        value={form.kind}
        onChange={(v) => set("kind", v)}
      />
      <label className="field">
        <span className="field-label">What it is for</span>
        <input className="field-input" name="subject" autoComplete="off" placeholder="Annual audit fee…" value={form.subject} onChange={(e) => set("subject", e.target.value)} />
      </label>
      <MoneyField label="Amount" name="amount" value={form.amountText ?? ""} onValueChange={({ text, cents }) => setForm((f) => ({ ...f, amountText: text, amountCents: cents }))} />
      <DateField label="First day it covers" name="start" value={form.startDate} onChange={(v) => set("startDate", v)} />
      <label className="field">
        <span className="field-label">Months</span>
        <input className="field-input num" inputMode="numeric" name="term" autoComplete="off" value={form.termMonths} onChange={(e) => set("termMonths", e.target.value)} />
      </label>
      <label className="field">
        <span className="field-label">{form.kind === "accrual" ? "Expense account (by code or name)" : "Expense account each month (by code or name)"}</span>
        <input className="field-input" name="recognition" autoComplete="off" placeholder="6400" value={form.recognitionAccount} onChange={(e) => set("recognitionAccount", e.target.value)} />
      </label>
      {form.kind === "amortisation" ? (
        <>
          <label className="field">
            <span className="field-label">Carried in (asset account)</span>
            <input className="field-input" name="carrier" autoComplete="off" placeholder="1700" value={form.carrierAccount} onChange={(e) => set("carrierAccount", e.target.value)} />
          </label>
          <label className="field">
            <span className="field-label">Booked to first (optional)</span>
            <input className="field-input" name="opening" autoComplete="off" value={form.openingCounterAccount} onChange={(e) => set("openingCounterAccount", e.target.value)} />
          </label>
        </>
      ) : null}
      <p className="t-footnote ink-2">Saved as proposed: it drafts nothing until someone approves its figures. Each month&apos;s entry is then a draft for approval.</p>
      <Result result={result} />
      <div className="jeditor-actions">
        <Button variant="commit" type="submit" busy={busy} busyLabel="Saving…" disabledReason={gate || (writes ? undefined : "This is a sample month, so nothing can be saved.")}>
          Save schedule
        </Button>
      </div>
    </form>
  );
}

function SchedulesTab({ schedules }) {
  const [open, setOpen] = useState(false);
  if (!schedules || !schedules.read) return <NotRead what="your schedules" />;
  const rows = scheduleRows(schedules);
  const columns = [
    { key: "subject", label: "Schedule" },
    { key: "kind", label: "Kind" },
    { key: "runs", label: "Runs" },
    { key: "remaining", label: "Remaining", numeric: true },
    { key: "next", label: "Next release" },
    { key: "status", label: "Status" },
  ];
  return (
    <section className="journals-section" aria-label="Schedules">
      <div className="journals-section-head">
        <p className="t-footnote ink-2">Accruals, prepaid expenses, amortisation and deferred revenue spread over months.</p>
        <Button size="sm" icon={<IconAdd size={14} />} onClick={() => setOpen(true)}>
          New schedule
        </Button>
      </div>
      <Table
        caption="Schedules"
        columns={columns}
        empty="No schedules yet."
        rows={rows.map((r) => ({
          id: `${r.kind}:${r.id}`,
          cells: {
            subject: r.subject,
            kind: r.kindLabel,
            runs: r.startDate && r.endDate ? `${day(r.startDate)} to ${day(r.endDate)}` : "Not said",
            remaining: money(r.remainingCents, r.id, r.remainingWords || "Not read yet"),
            next: r.nextRelease ? day(r.nextRelease) : r.remainingWords ? "Not read yet" : "None left",
            status: r.statusWords,
          },
        }))}
      />
      <Sheet open={open} onClose={() => setOpen(false)} title="New schedule">
        <ScheduleForm onDone={() => setOpen(false)} />
      </Sheet>
    </section>
  );
}

// ─────────────────────────── fixed assets ───────────────────────────

function AssetsTab({ assets, period }) {
  const router = useRouter();
  const writes = useWritesEnabled();
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(false);
  const rows = assetRows(assets);
  if (!rows) return <NotRead what="the asset register" />;
  const through = monthEnd(period);

  async function draft() {
    if (!through) return;
    setBusy(true);
    const answer = await callSafely(draftDepreciation, { through });
    setBusy(false);
    setResult(answer);
    if (answer && answer.ok) router.refresh();
  }

  return (
    <section className="journals-section" aria-label="Fixed assets">
      <div className="journals-section-head">
        <p className="t-footnote ink-2">The asset register. Depreciation is drafted from it, one draft per asset per month, for approval.</p>
        {/* An empty register has nothing to depreciate, and the table under it says so
            once (UI walk 2, N7: "There are no assets in the register." above "No assets
            in the register yet."), so no press is drawn for it. */}
        {rows.length ? (
          <Button size="sm" busy={busy} busyLabel="Drafting…" disabledReason={!through ? "Choose a month first." : writes ? undefined : "This is a sample month, so nothing can be drafted."} onClick={draft}>
            Draft {monthName(period)} depreciation
          </Button>
        ) : null}
      </div>
      <Result result={result} />
      <Table
        caption="Fixed assets"
        columns={[
          { key: "name", label: "Asset" },
          { key: "class", label: "Class" },
          { key: "inService", label: "In service" },
          { key: "cost", label: "Cost", numeric: true },
          { key: "status", label: "Status" },
        ]}
        empty="No assets in the register yet. Ask Vert to roll forward the fixed assets to add them."
        rows={rows.map((a) => ({
          id: a.id,
          cells: { name: a.name, class: a.assetClass || "Not said", inService: day(a.inService), cost: money(a.costCents, a.id), status: a.status || "Not said" },
        }))}
      />
    </section>
  );
}

// ─────────────────────────── the page ───────────────────────────

// `entryPeriod`: the month New entry dates itself in, the first one not signed off
// (app/journals/page.js; UI walk D4). The page's month when it wasn't read.
export default function JournalsScreen({ tab = "entries", period = null, entryPeriod = null, journal = null, recurring = null, schedules = null, assets = null }) {
  const router = useRouter();
  const [writing, setWriting] = useState(false);
  const [saved, setSaved] = useState(null);

  function go(next) {
    router.push(next === "entries" ? "/journals" : `/journals?tab=${next}`);
  }

  return (
    <div className="page journals-page">
      <header className="page-head">
        <div>
          <h1 className="t-title-1">Journals</h1>
          <p className="page-head-sub">Every journal entry, what repeats, and what is spread over months.</p>
        </div>
        <Button variant="commit" icon={<IconAdd size={14} />} onClick={() => setWriting(true)} data-journals-new="">
          New entry
        </Button>
      </header>
      {saved ? (
        <Notice kind="completion" onDismiss={() => setSaved(null)}>
          {saved}
        </Notice>
      ) : null}
      <Segmented label="Journals view" options={TABS} value={tab} onChange={go} />
      {tab === "entries" ? <EntriesTab journal={journal} /> : null}
      {tab === "recurring" ? <RecurringTab recurring={recurring} period={period} /> : null}
      {tab === "schedules" ? <SchedulesTab schedules={schedules} /> : null}
      {tab === "assets" ? <AssetsTab assets={assets} period={period} /> : null}
      <Sheet open={writing} onClose={() => setWriting(false)} title="New journal entry" className="journals-editor-sheet">
        {writing ? (
          <JournalEditor
            create={{ period: entryPeriod || period }}
            onDone={() => setWriting(false)}
            onSaved={(made) => {
              setWriting(false);
              const words = made && made.body && typeof made.body.words === "string" ? made.body.words : "Saved as a draft. Nothing is posted until someone approves it.";
              setSaved(words);
              router.refresh();
            }}
          />
        ) : null}
      </Sheet>
    </div>
  );
}
