// components/je/icons.js — THE CONVERSATION'S GLYPHS, NOW PHOSPHOR
// ==============================================================================
// Founder decision D7 (10 Oct 2026); design-fix-2 spec §4. Re-exports of the one icon set
// (components/ui/icons.js) under the names the journal and conversation call sites use.
// Owners move their imports to "@/components/ui/icons"; then this file is deleted.

import {
  IconAdd,
  IconBlocked as UiBlocked,
  IconCaretDown,
  IconCaretLeft,
  IconCaretRight,
  IconCheck as UiCheck,
  IconClose,
  IconExternal,
  IconFile,
  IconLedger,
  IconMore,
  IconSend,
  IconWarning,
} from "@/components/ui/icons";

export function IconCheck(props) {
  return <UiCheck size={14} {...props} />;
}
export function IconBlocked(props) {
  return <UiBlocked size={14} {...props} />;
}
export function GlyphChevronDown(props) {
  return <IconCaretDown size={16} {...props} />;
}
export function GlyphChevronLeft(props) {
  return <IconCaretLeft size={16} {...props} />;
}
export function GlyphChevronRight(props) {
  return <IconCaretRight size={16} {...props} />;
}
export const GlyphLedger = IconLedger;
export const GlyphFile = IconFile;
export const GlyphTick = UiCheck;
export const GlyphTriangle = IconWarning;
export const GlyphPlus = IconAdd;
export const GlyphArrowUp = IconSend;
export const GlyphClose = IconClose;
export const GlyphExternal = IconExternal;
export const GlyphMore = IconMore;
