"use client";

// components/skills/TaskMenu.js — A TASK ROW'S "⋯": OPEN SKILL
// ==============================================================================
// Build plan §19.6 F-BRAIN: a task bound to a skill opens it from its row's menu. The
// row itself opens the conversation (the work), so the skill sits one press inside a
// small disclosure at the row's end rather than as a second link on every row, which
// would double what a checklist of twenty rows asks the eye to read.
//
// A disclosure, not an ARIA menu, for the reason components/shell/AccountMenu.js gives:
// one item does not need a menu's key model. Esc and a press outside close it.

import { useEffect, useId, useRef, useState } from "react";
import { IconMore } from "@/components/shell/icons";
import OpenSkill from "./OpenSkill";

export default function TaskMenu({ template, title, client = null }) {
  const [open, setOpen] = useState(false);
  const id = useId();
  const root = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    const onPointer = (e) => {
      if (root.current && !root.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onPointer);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onPointer);
    };
  }, [open]);
  if (!template) return null;
  return (
    <span className="task-menu" ref={root}>
      <button type="button" className="task-menu-toggle" aria-expanded={open ? "true" : "false"} aria-controls={id} aria-label={`More for ${title}`} onClick={() => setOpen((v) => !v)}>
        <IconMore width="16" height="16" aria-hidden="true" />
      </button>
      <span className="task-menu-list" id={id} hidden={!open}>
        <OpenSkill template={template} title={title} client={client} className="row menu-item skill-open">
          Edit how Vert does this
        </OpenSkill>
      </span>
    </span>
  );
}
