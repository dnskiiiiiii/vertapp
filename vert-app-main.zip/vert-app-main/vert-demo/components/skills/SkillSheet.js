"use client";

// components/skills/SkillSheet.js — A TASK'S SKILL, AS A PLAIN DOCUMENT
// ==============================================================================
// Build plan §19.0.5, §19.6 F-BRAIN. Opens in the pane, at the right, from three places:
// the Thoughts load line, the task row's "Open skill", and the answered question's
// "Saved to the skill". It is a document on the document type scale, with no card
// chrome, in this order:
//
//   1. The SOP, with each setting written into it as a phrase you can change in place
//      ("Capitalise anything over $2,500.00"), then the checkpoint sentence.
//   2. "What Vert knows about this client": each saved answer, where it was given, and
//      Forget. Forget is read back before the answer leaves the list.
//   3. The versions, newest first, and "changed from the firm's version" when it is.
//   4. For a firm skill a client has changed, the firm's version with each client's own
//      version indented beneath it (§19.9 F-FIRM) — drawn only once a fork exists.
//
// ONE COMMIT: SAVE, AND ONLY WHEN THERE IS SOMETHING TO SAVE (design-fix-2 DA2-055).
// Saving writes version n+1 (append-only), so it is the sheet's one commit. At rest the
// foot shows Edit alone (a disabled Save with "Nothing has changed yet." beside it was an
// action shown before it was available); once the prose is open or a setting has changed
// it shows Cancel and Save. The head carries a quiet "Built in" tag (never "v0"), the
// SOP's first heading is dropped when it only repeats the title, the engine's "gl lines"
// reads "GL lines", and a "Label: value" settings list is a grid grouped Accounts /
// Useful lives / Method. A setting is a real <button> drawn as an inline chip with a
// pencil on hover (DA2-065), the same chip as the plan's.
//
// NOTHING HERE CAN ADD A READ, A TOOL OR A WRITE (§19.0.5). A setting is changed only
// to a value of its declared kind (components/skills/model.js `checkSetting`), and the
// engine checks again; prose guides the model only.

import { useCallback, useEffect, useState } from "react";
import { Button, Meta, MoneyField } from "@/components/ui";
import { IconEdit } from "@/components/ui/icons";
import { decisionKindsInWords } from "@/components/cards/words";
import { saveSkillVersion } from "@/lib/skills";
import { forgetAnswer } from "@/lib/memory";
import {
  SOP_LIMIT,
  SOP_LIMIT_WORDS,
  bodyForEditing,
  bodyFromEditing,
  changedFromFirm,
  changedSettings,
  accountWords,
  checkSetting,
  displayText,
  knowsList,
  settingGroups,
  sheetBlocks,
  settingWords,
  skillTitle,
  sopBlocks,
  startModeLine,
  bodyWithoutStartLead,
  unphrasedSettings,
  versionRows,
  versionTag,
  withoutAnswer,
} from "./model";
import { fetchFirmSkills, firmWords, forkWords, forksOf } from "./firm-model";
import "./forks.css";
import PaneOrSheet from "@/components/chat/results/DeskPane";

// "Skill" is the engine's word; the person reads "steps" (bug bash 10 Oct 2026).
const COULD_NOT_READ = "Vert couldn't read these steps just now. Close this and try again.";

/** Read the skill through the app's own route (app/api/skills). Never throws. */
export async function fetchSkill(template, fetchImpl = globalThis.fetch) {
  try {
    const res = await fetchImpl(`/api/skills?template=${encodeURIComponent(template)}`, { cache: "no-store" });
    const body = await res.json();
    return body && body.ok && body.skill ? { ok: true, skill: body.skill } : { ok: false };
  } catch {
    return { ok: false };
  }
}

/**
 * Forget one saved answer and, only when the engine read the forget back, take it out
 * of the list. Returns `{knows, error}`: the list as it now stands and, on a refusal,
 * the words that say nothing changed.
 */
export async function forgetAndDrop(knows, memoryId, forget = forgetAnswer) {
  let result;
  try {
    result = await forget(memoryId);
  } catch {
    result = null;
  }
  if (!result || !result.ok) return { knows, error: (result && result.message) || "Not forgotten. Nothing was changed. Try again." };
  return { knows: withoutAnswer(knows, memoryId), error: null };
}

export default function SkillSheet({ open = true, template, title = null, skill: given = null, origin = null, onClose, client = null, firm: givenFirm, readFirmImpl = fetchFirmSkills }) {
  const [skill, setSkill] = useState(given);
  const [failed, setFailed] = useState(false);
  const [firmRead, setFirmRead] = useState(null);

  // The firm's skills, for the indented client rows. Any refusal (a tenant key, no
  // service, FORK's route not there) draws nothing: the rows exist only once a fork does.
  useEffect(() => {
    if (!open || givenFirm !== undefined) return undefined;
    let live = true;
    readFirmImpl().then((r) => live && r && r.ok && setFirmRead(r.body));
    return () => {
      live = false;
    };
  }, [open, givenFirm, readFirmImpl]);
  const firm = forksOf(givenFirm !== undefined ? givenFirm : firmRead, template || (skill && skill.template));

  useEffect(() => {
    if (!open || given || !template) return undefined;
    let live = true;
    fetchSkill(template).then((r) => {
      if (!live) return;
      if (r.ok) setSkill(r.skill);
      else setFailed(true);
    });
    return () => {
      live = false;
    };
  }, [open, given, template]);

  const name = skillTitle(template || (skill && skill.template), (skill && skill.title) || title);
  const draft = useSkillDraft(skill, template || (skill && skill.template), setSkill);
  return (
    // THE KIT'S PANEL IS THE SHEET, AND IT IS OPAQUE (eval r2, skill-1-sheet.png). r1
    // moved the title and Close into the kit's header; r2 still saw the conversation's
    // text through the panel, the header off-screen and Edit/Save floating mid-sheet.
    // So: the layer is named (`skill-sheet-layer`) and skills.css gives its panel the
    // solid page surface with no backdrop blur, because this is a document you read and
    // edit, not a glance over the work; OpenSkill portals it to <body>, so no
    // transformed or stacked ancestor (the chat pane) clips its header under the top
    // bar; and Edit/Save live in the kit's footer, docked under the scroller, so the
    // sheet's one write is always in the same place.
    // On a desk, inside a conversation, this is a result pane beside the rail instead
    // (design-pass spec §6.11; PaneOrSheet), with the same body and the same foot.
    <PaneOrSheet
      open={open}
      side="right"
      body="skill"
      title={`${name}: steps`}
      onClose={onClose}
      origin={origin || undefined}
      className="skill-sheet-layer"
      footer={skill ? <SkillActions draft={draft} /> : null}
    >
      <div className="skill-sheet" data-skill-sheet={template || ""}>
        {skill ? (
          <>
            <SkillBody skill={skill} client={client} draft={draft} name={name} />
            <FirmForks firm={firm} />
          </>
        ) : failed ? (
          <p className="chat-sheet-note">{COULD_NOT_READ}</p>
        ) : (
          <p className="chat-sheet-note">Reading the steps…</p>
        )}
      </div>
    </PaneOrSheet>
  );
}

/**
 * The unsaved edit to a skill: the prose being rewritten, the settings changed in
 * place, and the one Save. It lives above the body because the body scrolls and the
 * Save row does not: the footer and the document read and write the same draft.
 * Safe with no skill yet (everything is empty and Save has nothing to send).
 */
export function useSkillDraft(skill, template, onSaved) {
  const settings = skill && Array.isArray(skill.settings) ? skill.settings.filter((s) => s && s.key) : [];
  const [edits, setEdits] = useState({});
  const [prose, setProse] = useState(null);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState(null);
  const body = !skill ? "" : typeof skill.body === "string" ? skill.body : typeof skill.bodyMd === "string" ? skill.bodyMd : "";
  const shown = settings.map((s) => (Object.prototype.hasOwnProperty.call(edits, s.key) ? { ...s, value: edits[s.key], phrase: null } : s));
  const changed = changedSettings(settings, edits);
  // The editor shows settings by name ("[Capitalisation threshold]"); what is saved,
  // counted and compared is the body with the engine's tokens back in (W05).
  const stored = prose === null ? null : bodyFromEditing(prose, settings, body);
  const proseChanged = stored !== null && stored !== body;
  const dirty = proseChanged || Object.keys(changed).length > 0;
  const tooLong = stored !== null && stored.length > SOP_LIMIT;
  const reason = tooLong ? `The steps can be at most ${SOP_LIMIT_WORDS} characters.` : !dirty ? "Nothing has changed yet." : null;

  const setSetting = useCallback((key, value) => setEdits((was) => ({ ...was, [key]: value })), []);

  async function save() {
    if (!skill || reason) return;
    setSaving(true);
    setMessage(null);
    const result = await saveSkillVersion(template, proseChanged ? stored : null, Object.keys(changed).length ? changed : null, {
      fromVersion: Number.isInteger(skill.version) ? skill.version : null,
    });
    setSaving(false);
    if (!result || !result.ok) {
      setMessage((result && result.message) || "Not saved. Nothing was changed.");
      return;
    }
    setEdits({});
    setProse(null);
    setMessage("Saved. Vert follows these steps from next time.");
    onSaved(result.skill);
  }

  const reset = useCallback(() => {
    setEdits({});
    setProse(null);
  }, []);

  const startEdit = useCallback(() => setProse(bodyForEditing(body, settings)), [body, settings]);
  return { body, shown, prose, stored, setProse, startEdit, setSetting, saving, message, reason, save, dirty, reset };
}

/**
 * Edit (or Cancel) and Save, docked in the kit's footer, with what the last save did
 * on the left. Save's disabled reason is drawn beside it by the kit's Button.
 */
function SkillActions({ draft }) {
  const editing = draft.prose !== null || draft.dirty;
  return (
    <div className="skill-actions" data-skill-actions="">
      {draft.message ? (
        <p className="skill-message t-footnote" role="status">
          {draft.message}
        </p>
      ) : null}
      {editing ? (
        <>
          <Button variant="quiet" size="sm" onClick={draft.reset}>
            Cancel
          </Button>
          <Button variant="commit" size="sm" onClick={draft.save} busy={draft.saving} busyLabel="Saving…" disabledReason={draft.reason}>
            Save
          </Button>
        </>
      ) : (
        <Button variant="secondary" size="sm" icon={<IconEdit size={14} aria-hidden="true" />} onClick={draft.startEdit}>
          Edit
        </Button>
      )}
    </div>
  );
}

/** The firm's version, and each client's own version indented beneath it. Nothing without a fork. */
function FirmForks({ firm }) {
  if (!firm || !firm.forks.length) return null;
  return (
    <section className="skill-forks" aria-labelledby="skill-forks-title" data-skill-forks="">
      <h3 className="skill-h" id="skill-forks-title">
        Clients
      </h3>
      <ul className="skill-fork-list t-footnote">
        <li className="skill-fork-firm">{firmWords(firm.firm)}</li>
        {firm.forks.map((f) => (
          <li key={f.tenantId} className="skill-fork" data-fork={f.tenantId}>
            {forkWords(f)}
          </li>
        ))}
      </ul>
    </section>
  );
}

/** Whether the editor's words name any setting in brackets. */
function settingNamesIn(text, settings) {
  if (typeof text !== "string" || !Array.isArray(settings)) return false;
  return settings.some((s) => s && typeof s.label === "string" && text.toLowerCase().includes(`[${s.label.trim().toLowerCase()}]`));
}

function SkillBody({ skill, client, draft, name }) {
  const { body, shown, prose, setProse, setSetting } = draft;
  const [knows, setKnows] = useState(() => knowsList(skill.knows));
  const [forgetError, setForgetError] = useState(null);
  const tag = versionTag(skill);

  async function forget(memoryId) {
    setForgetError(null);
    const next = await forgetAndDrop(knows, memoryId);
    setKnows(next.knows);
    if (next.error) setForgetError(next.error);
  }

  return (
    <div className="skill-doc">
      {tag || changedFromFirm(skill) ? (
        <p className="skill-meta">
          {tag ? <Meta className="skill-tag" data-skill-version={skill.version}>{tag}</Meta> : null}
          {changedFromFirm(skill) ? <Meta>Changed from the firm's version</Meta> : null}
        </p>
      ) : null}

      <section className="skill-sop" aria-label="How Vert does this task">
        {prose !== null ? (
          <label className="skill-prose-edit">
            <span className="chat-visually-hidden">The steps, in your words</span>
            <textarea className="skill-prose-field" name="skill-prose" autoComplete="off" value={prose} rows={12} onChange={(e) => setProse(e.target.value)} />
            <span className="skill-count t-caption">
              {`${(draft.stored || prose).length} of ${SOP_LIMIT_WORDS} characters`}
              {settingNamesIn(prose, shown) ? " · Words in [brackets] are this task's settings." : ""}
            </span>
          </label>
        ) : (
          <Sop body={decisionKindsInWords(startModeLine(body, shown, skill.checkpoints && skill.checkpoints.sentence).setting ? bodyWithoutStartLead(body) : body)} settings={shown} onSet={setSetting} name={name} />
        )}
        {unphrasedSettings(body, shown).length ? (
          <ul className="skill-settings">
            {unphrasedSettings(body, shown).map((s) => (
              <li key={s.key}>
                {s.label}: <Phrase setting={s} onSet={setSetting} />
              </li>
            ))}
          </ul>
        ) : null}
        <StartSentence body={body} settings={shown} checkpoint={skill.checkpoints && skill.checkpoints.sentence} onSet={setSetting} />
      </section>

      <section className="skill-knows" aria-labelledby="skill-knows-title">
        <h3 className="skill-h" id="skill-knows-title">
          What Vert knows about {client || "this client"}
        </h3>
        {!knows.measured ? (
          <p className="chat-sheet-note">Vert couldn't read what it knows just now.</p>
        ) : !knows.answers.length ? (
          <p className="skill-note t-footnote">Nothing saved yet. Your answers to this task's questions are kept here.</p>
        ) : (
          <ul className="skill-knows-list">
            {knows.answers.map((a) => (
              <li key={a.memoryId} data-memory={a.memoryId}>
                <span className="skill-knows-words">{a.words}</span>
                <span className="skill-knows-from t-footnote">
                  {a.href ? <a href={a.href}>{a.source}</a> : a.source}
                  {" · "}
                  <button type="button" className="chat-quiet skill-forget" onClick={() => forget(a.memoryId)}>
                    Forget
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}
        {forgetError ? (
          <p className="chat-inline-error" role="alert">
            {forgetError}
          </p>
        ) : null}
      </section>

      {versionRows(skill.versions).length ? (
        <section className="skill-versions" aria-labelledby="skill-versions-title">
          <h3 className="skill-h" id="skill-versions-title">
            Versions
          </h3>
          <ol className="skill-version-list t-footnote">
            {versionRows(skill.versions).map((r) => (
              <li key={r.version}>{r.words}</li>
            ))}
          </ol>
        </section>
      ) : null}
    </div>
  );
}

/**
 * When the task starts, then the checkpoint: "Ask me before starting. Pause if a
 * difference is over $500.00." (iteration 4, §20.0 decision 9). Once the skill declares
 * `start_mode`, the first clause is a phrase changed in place ("Start when nothing is
 * new; otherwise ask me"), saved with the sheet's one Save; until then it is words, and
 * Ask me is the default. Nothing here starts a task, and an auto-start still only drafts.
 */
function StartSentence({ body, settings, checkpoint, onSet }) {
  const line = startModeLine(body, settings, checkpoint);
  if (!line.words && !line.rest) return null;
  if (!line.setting) {
    const text = [line.words ? `${line.words}.` : null, line.rest].filter(Boolean).join(" ");
    return (
      <p className="skill-checkpoint" data-skill-start-mode={line.mode || ""}>
        {text}
      </p>
    );
  }
  return (
    <p className="skill-checkpoint" data-skill-start-mode={line.mode}>
      <Phrase setting={line.setting} onSet={onSet} />.{line.rest ? ` ${line.rest}` : null}
    </p>
  );
}

/** The SOP: paragraphs, headings and lists, with each setting as a phrase in place. */
function Sop({ body, settings, onSet, name = null }) {
  const byKey = new Map(settings.map((s) => [s.key, s]));
  const blocks = sheetBlocks(sopBlocks(body, settings), name);
  if (!blocks.length) return <p className="chat-sheet-note">No steps are written down for this task yet.</p>;
  const line = (segs) =>
    segs.map((seg, i) => (seg.setting ? <Phrase key={i} setting={byKey.get(seg.setting)} onSet={onSet} /> : <span key={i}>{displayText(seg.text)}</span>));
  return blocks.map((b, i) => {
    if (b.kind === "heading") return <h3 key={i} className="skill-h">{line(b.segments)}</h3>;
    if (b.kind === "list") {
      const groups = settingGroups(b.items, settings);
      if (groups)
        return (
          <div key={i} className="skill-grid" data-skill-settings="">
            {groups.map((g) => (
              <section key={g.group} className="skill-grid-group" aria-label={g.group}>
                <h4 className="skill-grid-head">{g.group}</h4>
                <dl className="skill-grid-list">
                  {g.rows.map((r) => (
                    <div key={r.key} className="skill-grid-row">
                      <dt className="skill-grid-label">{r.label}</dt>
                      <dd className="skill-grid-value">
                        <Phrase setting={byKey.get(r.key)} onSet={onSet} />
                      </dd>
                    </div>
                  ))}
                </dl>
              </section>
            ))}
          </div>
        );
      return (
        <ul key={i} className="skill-list">
          {b.items.map((segs, j) => (
            <li key={j}>{line(segs)}</li>
          ))}
        </ul>
      );
    }
    return <p key={i}>{line(b.segments)}</p>;
  });
}

/**
 * One setting, written into the sentence. Pressed, it becomes the field its kind takes
 * (money in dollars, a list of options, a percentage), in place; a value outside the
 * kind is refused in words and never sent.
 */
function Phrase({ setting, onSet }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState(null);
  if (!setting) return null;
  const words = accountWords(settingWords(setting));
  if (!editing) {
    const start = () => {
      setDraft(setting.value != null ? String(setting.value) : "");
      setError(null);
      setEditing(true);
    };
    // DA2-065: a real <button>, drawn as an inline chip (footnote 500 ink on the inset
    // ground, the inner radius, a pencil on hover), never a dashed underline on a span with
    // hand-rolled keys. A long phrase wraps inside its own chip (skills.css).
    return (
      <button type="button" className="skill-phrase" data-setting={setting.key} aria-label={`${setting.label}: ${words}. Change`} onClick={start}>
        <span className="skill-phrase-words">{words}</span>
        <IconEdit className="skill-phrase-pencil" size={12} aria-hidden="true" />
      </button>
    );
  }
  const commit = (value) => {
    const typed = setting.kind === "accounts" && typeof value === "string" ? value.split(",").map((a) => a.trim()).filter(Boolean) : value;
    const checked = checkSetting(setting, typed);
    if (!checked.ok) {
      setError(checked.message);
      return;
    }
    onSet(setting.key, checked.value);
    setEditing(false);
  };
  const options = Array.isArray(setting.options) ? setting.options.map((o) => (o && typeof o === "object" ? { id: o.id ?? o.value, label: o.label || String(o.id ?? o.value) } : { id: o, label: String(o) })) : [];
  return (
    <span className="skill-phrase-edit" data-setting-edit={setting.key}>
      {setting.kind === "money" ? (
        <MoneyField
          label={setting.label}
          defaultValue=""
          onValueChange={({ cents }) => setDraft(cents)}
          onKeyDown={(e) => {
            if (e.key === "Enter") commit(draft);
          }}
        />
      ) : setting.kind === "choice" || setting.kind === "account" ? (
        <select className="field-input" name={`setting-${setting.key}`} autoComplete="off" aria-label={setting.label} defaultValue={setting.value ?? ""} onChange={(e) => commit(e.target.value)}>
          <option value="" disabled>
            Choose…
          </option>
          {options.map((o) => (
            <option key={o.id} value={o.id}>
              {o.label}
            </option>
          ))}
        </select>
      ) : setting.kind === "bool" ? (
        <select className="field-input" name={`setting-${setting.key}`} autoComplete="off" aria-label={setting.label} defaultValue={setting.value ? "yes" : "no"} onChange={(e) => commit(e.target.value === "yes")}>
          <option value="yes">yes</option>
          <option value="no">no</option>
        </select>
      ) : (
        <input
          className="field-input"
          name={`setting-${setting.key}`}
          autoComplete="off"
          aria-label={setting.label}
          value={draft}
          inputMode={setting.kind === "percent" ? "decimal" : undefined}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") commit(draft);
          }}
        />
      )}
      {setting.kind === "money" || setting.kind === "percent" || setting.kind === "text" ? (
        <button type="button" className="chat-quiet" onClick={() => commit(draft)}>
          Use this
        </button>
      ) : null}
      <button type="button" className="chat-quiet" onClick={() => setEditing(false)}>
        Cancel
      </button>
      {error ? (
        <span className="chat-inline-error" role="alert">
          {error}
        </span>
      ) : null}
    </span>
  );
}
