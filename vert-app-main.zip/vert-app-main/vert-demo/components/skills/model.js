// components/skills/model.js — THE SKILL AND WHAT VERT KNOWS, AS WORDS
// ==============================================================================
// Build plan §19.0.4, §19.0.5, §19.6 F-BRAIN. Pure functions only: no React, no fetch.
// Everything a person reads about a skill is decided here, so the sheet, the Thoughts
// lines, the answered question and the account menu cannot word the same fact two ways.
//
// THE WORDS ARE FIXED (§19.0.5 "Public words"). The UI says "skill" and "what Vert
// knows"; the word for the engine's table of saved answers never reaches a screen. "Skill"
// appears only on the load line, on the sheet, and on the "Saved to the skill" line.
//
// THE THREE THOUGHTS LINES (§19.6 F-BRAIN, in this order):
//   1. "Checked what Vert knows about Northwind · Prepaid schedule: 2 answers from
//      earlier months" — or "nothing saved yet". Every run says it, because a recall
//      that shows only when it found something cannot be told from one that never ran.
//   2. The routing line, when the engine routed a task: "This looks like the Deferred
//      revenue task, so I loaded its skill".
//   3. "Loaded the Prepaid schedule skill (v3, edited by Sam on 2 Sep)"; version 0 is
//      the built-in one nobody has edited, and says so.
//
// THE SHEET'S CONTRACT (`GET /skills/{template}`, §19.2), read tolerantly because SKL
// builds the route in the same wave:
//   { template, title?, version, scope, editedBy?, editedAt?, changedFromFirm?,
//     body (the SOP, ≤ 3,000 characters, with `{{key}}` where a setting is phrased),
//     settings: [{key, label, kind, options?, value?, default?}],
//     checkpoints?: {sentence}, versions: [{version, scope, author, reason, createdAt}],
//     knows?: {measured, answers: [GET /memory's rows]} }
// A field that is absent is said to be absent, never drawn as an empty claim.

import { formatMoney, metaLine, MONTHS } from "@/lib/format";

export const SOP_LIMIT = 3000;
/** The limit as a person reads it (a count, not money; written once, not formatted). */
export const SOP_LIMIT_WORDS = "3,000";

/** The reserved tenant-wide skill that holds Pause Vert (§19.0.6). */
export const TENANT_SKILL = "_tenant";

/**
 * Each template's own title, as the engine's registry names it (vert_engine/workflows/
 * registry.py TEMPLATES[id].title; pinned to it by tests/skills-sheet.test.js against
 * the engine checkout and the export's replays).
 *
 * WHY THE DEMO HOLDS A COPY (eval r1 W1, iteration 4): neither `memory_used.skill` nor
 * `GET /skills/{template}` carries the title, so a skill was named by humanising its id,
 * and the bridge's own screens said "Waterfall" three times ("Checked what Vert knows ·
 * Waterfall: nothing saved yet", "Loaded the Waterfall skill", the "Waterfall skill"
 * sheet) although the template is called "Bridge". An id is an engine word; the title
 * is the one a person was shown when they asked.
 */
export const TEMPLATE_TITLES = Object.freeze({
  payout_check: "Check payouts",
  resolve_breaks: "Resolve payout breaks",
  approve_entries: "Approve journal entries",
  bank_reconciliation: "Reconcile the bank account",
  workpapers: "Build workpapers",
  prepaid_schedule: "Prepaid schedules",
  gl_reconciliation: "GL reconciliations",
  accrual_schedule: "Accruals",
  amortization_schedule: "Amortisation schedules",
  balance_sheet_rollforward: "Balance sheet roll-forwards",
  budget_import: "Import a budget",
  budget_vs_actual: "Budget vs actual",
  card_reconciliation: "Credit card reconciliation",
  clearing_accounts: "Clear suspense and clearing accounts",
  deferred_revenue: "Deferred revenue",
  draft_entry: "Draft an entry",
  expense_analysis: "Expense analysis",
  fixed_asset_rollforward: "Fixed assets",
  flux_analysis: "Compare with last month",
  management_commentary: "Management commentary",
  misclassification_scan: "Misclassification scan",
  modify_workbook: "Modify a workbook",
  payroll_accrual: "Payroll",
  payroll_reconciliation: "Payroll reconciliation",
  payroll_journal: "Pay run journal",
  pnl_trend: "P&L trend",
  revenue_analysis: "Revenue analysis",
  reverse_entry: "Reverse an entry",
  waterfall: "Bridge",
  // The close list's Step 4 checks (w4/checks).
  unusual_balances: "Trial balance review",
  integration_feeds: "Integration feeds",
});

/**
 * "waterfall" → "Bridge": the title sent with the skill wins, then the template's own
 * title, and only a template this table has never heard of is humanised from its id
 * ("new_thing" → "New thing"), so a new template still reads as words.
 */
export function skillTitle(template, title = null) {
  if (typeof title === "string" && title.trim()) return title.trim();
  if (typeof template === "string" && Object.hasOwn(TEMPLATE_TITLES, template)) return TEMPLATE_TITLES[template];
  const t = typeof template === "string" ? template.replace(/^_+/, "").replace(/_/g, " ").trim() : "";
  if (!t) return "This task";
  return t.charAt(0).toUpperCase() + t.slice(1);
}


/** "2026-09-02" or an ISO instant → "2 Sep"; anything else → null (never a guess). */
export function shortDay(value) {
  const m = typeof value === "string" ? /^(\d{4})-(\d{2})-(\d{2})/.exec(value) : null;
  if (!m) return null;
  const month = Number.parseInt(m[2], 10);
  const day = Number.parseInt(m[3], 10);
  if (!(month >= 1 && month <= 12) || !(day >= 1 && day <= 31)) return null;
  return `${day} ${MONTHS[month - 1]}`;
}

/** "Sam Lee" → "Sam". A key label ("key: founder test") is not a first name. */
export function firstName(person) {
  const p = typeof person === "string" ? person.trim() : "";
  if (!p || p.includes(":")) return p || null;
  return p.split(/\s+/)[0];
}

/** "1 answer" / "2 answers". */
function answers(n) {
  return `${n} ${n === 1 ? "answer" : "answers"}`;
}

/**
 * "(v3, edited by Sam on 2 Sep)" for a saved version; "(built in, not edited yet)" for
 * version 0. The person and the day are the engine's; a missing one is left out, not
 * invented.
 */
export function versionWords(skill) {
  const s = skill || {};
  const v = Number.isInteger(s.version) ? s.version : null;
  if (v === null) return null;
  if (v === 0) return "built in, not edited yet";
  const who = firstName(s.editedBy);
  const day = shortDay(s.editedAt);
  // WHOSE VERSION (D44): the firm's own skill, or this client's copy of it, as the
  // engine's line says it ("the firm's v1, …", "this client's copy, v3, …"). `client`
  // and an absent scope read as before.
  const parts = [s.scope === "firm" ? `the firm's v${v}` : s.scope === "client_copy" ? `this client's copy, v${v}` : `v${v}`];
  if (who && day) parts.push(`edited by ${who} on ${day}`);
  else if (who) parts.push(`edited by ${who}`);
  else if (day) parts.push(`edited on ${day}`);
  return parts.join(", ");
}

/**
 * Who changed the steps last, without the version number: "edited by Sam on 2 Sep",
 * "the firm's steps, edited by Sam", or null. A "v3" is Vert's bookkeeping, not words a
 * bookkeeper reads on the line (bug bash 10 Oct 2026).
 */
function editedWords(skill) {
  const s = skill || {};
  if (!Number.isInteger(s.version) || s.version === 0) return null;
  const who = firstName(s.editedBy);
  const day = shortDay(s.editedAt);
  const parts = [s.scope === "firm" ? "the firm's steps" : s.scope === "client_copy" ? "this client's own steps" : null];
  if (who && day) parts.push(`edited by ${who} on ${day}`);
  else if (who) parts.push(`edited by ${who}`);
  else if (day) parts.push(`edited on ${day}`);
  return parts.filter(Boolean).join(", ") || null;
}

/**
 * "Followed the saved steps for Prepaid schedule (edited by Sam on 2 Sep)". It said
 * "Loaded the Prepaid schedule skill (v3, …)", the engine's word for the steps a task
 * follows; a bookkeeper calls them steps (bug bash 10 Oct 2026). The built-in version
 * (AN4) still says it was never edited: "Followed the standard steps for …".
 */
export function loadLine(skill, title = null) {
  const s = skill || {};
  const name = skillTitle(s.template, title);
  if (s.version === 0) return `Followed the standard steps for ${name} (not edited yet)`;
  const edited = editedWords(s);
  return edited ? `Followed the saved steps for ${name} (${edited})` : `Followed the saved steps for ${name}`;
}

/** "This looks like Deferred revenue, so Vert followed its saved steps". */
export function routedLine(routed, title = null) {
  if (!routed || typeof routed.template !== "string" || !routed.template) return null;
  return `This looks like ${skillTitle(routed.template, title)}, so Vert followed its saved steps`;
}

/**
 * "Checked what Vert knows about Northwind · Prepaid schedule: 2 answers from earlier
 * months". Nothing saved is said in words ("nothing saved yet"), never as a zero.
 */
export function checkedLine(memoryUsed, { client = null, title = null } = {}) {
  const m = memoryUsed || {};
  const list = Array.isArray(m.answers) ? m.answers.filter((a) => a && a.words) : [];
  const about = typeof client === "string" && client.trim() ? ` about ${client.trim()}` : "";
  const task = m.skill && m.skill.template ? ` · ${skillTitle(m.skill.template, title)}` : "";
  // A READ recall that found nothing is a measured zero (AN4, ENG-AGENT-e2: the engine
  // reads `answers`, so an empty list is a count), said as one; an answers field that
  // never came is unknown, and says so rather than counting it. In words a bookkeeper
  // reads, not "0 saved answers" / "not read" (bug bash 10 Oct 2026).
  const found = list.length ? `${answers(list.length)} from earlier months` : Array.isArray(m.answers) ? "nothing saved yet" : "Vert couldn't see its saved answers";
  return `Checked what Vert knows${about}${task}: ${found}`;
}

/**
 * The opening Thoughts lines for one run's `memory_used` payload, in the order §19.6
 * sets. Each line carries what it opens: the load line opens the skill sheet.
 * Returns [] for no payload (a run that did not check, which the engine says by not
 * emitting the event; nothing is invented here).
 */
export function brainLines(memoryUsed, { client = null, title = null } = {}) {
  if (!memoryUsed || typeof memoryUsed !== "object" || !memoryUsed.skill) return [];
  const template = memoryUsed.skill.template;
  const lines = [{ kind: "checked", text: checkedLine(memoryUsed, { client, title }), template }];
  const routed = routedLine(memoryUsed.routed, title);
  if (routed) lines.push({ kind: "routed", text: routed, template: memoryUsed.routed.template });
  lines.push({ kind: "loaded", text: loadLine(memoryUsed.skill, title), template, opens: "skill" });
  const recalled = Array.isArray(memoryUsed.answers) ? memoryUsed.answers.filter((a) => a && a.words) : [];
  for (const a of recalled) lines.push({ kind: "recalled", text: a.words, template, from: a.from || null, memoryId: a.memoryId || null });
  return lines;
}

/**
 * The answered question's tail: "Saved for next time · Forget" when the engine kept it
 * ("Saved to the skill" until bug bash 10 Oct 2026: the engine's word, not yours).
 */
export function savedWords(remembered) {
  return remembered && remembered.memoryId ? "Saved for next time" : null;
}

/* ── the SOP, as a document with phrases in it ──────────────────────────────── */

// The engine writes a setting into the SOP as `{{setting:key}}` (vert_engine/skills/
// sop.py TOKEN); the plan's fixture wrote `{{key}}`. Both are read, so a built-in skill
// never shows a raw placeholder ("Capitalisation threshold: {{setting:…}}", eval r1).
const TOKEN = /\{\{\s*(?:setting:\s*)?([a-z][a-z0-9_]*)\s*\}\}/g;

/* ── the steps editor: settings in words, tokens on save (verify pass 4, W05) ──── */

// WHY W05 KEPT FAILING: the sheet READ the steps with each setting as a phrase, but
// Edit put the raw body in a textarea, so the accountant edited
// "{{setting:capitalisation_threshold}}" (pass 3 F22, pass 4 F13). In the editor each
// setting this skill declares is its name in brackets, "[Capitalisation threshold]", and
// Save writes the engine's token back in the form the body used. A bracket that names no
// setting is left as the person wrote it; a token naming no declared setting is left raw
// (there is nothing to name it by).

function settingLabel(s) {
  return s && typeof s.label === "string" && s.label.trim() ? s.label.trim() : s && s.key ? String(s.key).replace(/_/g, " ") : "";
}

/** The body as the editor shows it: each declared setting's token is `[Its label]`. */
export function bodyForEditing(body, settings) {
  const byKey = new Map((Array.isArray(settings) ? settings : []).filter((s) => s && s.key).map((s) => [s.key, s]));
  return (typeof body === "string" ? body : "").replace(TOKEN, (whole, key) => (byKey.has(key) ? `[${settingLabel(byKey.get(key))}]` : whole));
}

/**
 * The editor's words back as the body the engine stores: `[Its label]` becomes the
 * setting's token again, written the way `body` wrote it (`{{setting:key}}` or
 * `{{key}}`; `{{setting:key}}` for a setting the body never phrased).
 */
export function bodyFromEditing(text, settings, body = "") {
  const list = (Array.isArray(settings) ? settings : []).filter((s) => s && s.key);
  const form = new Map();
  for (const m of (typeof body === "string" ? body : "").matchAll(TOKEN)) {
    if (!form.has(m[1])) form.set(m[1], /\{\{\s*setting:/.test(m[0]) ? "setting" : "bare");
  }
  const byLabel = new Map(list.map((s) => [settingLabel(s).toLowerCase(), s.key]));
  return (typeof text === "string" ? text : "").replace(/\[([^\[\]\n]{1,80})\]/g, (whole, label) => {
    const key = byLabel.get(label.trim().toLowerCase());
    if (!key) return whole;
    return form.get(key) === "bare" ? `{{${key}}}` : `{{setting:${key}}}`;
  });
}

/**
 * A setting's value in words: "$2,500.00", "5%", "1500 · Plant & equipment",
 * "monthly". Money is integer cents (house style); an unset value says "not set".
 */
export function settingWords(setting) {
  const s = setting || {};
  // The engine's own words for the stored value win (`phrase`, sop.py): it alone knows
  // its units (a percent is basis points there) and what an unset setting does. An
  // edit not yet saved drops the phrase (SkillSheet) and is worded here.
  if (typeof s.phrase === "string" && s.phrase.trim()) return s.phrase.trim();
  const v = s.value !== undefined && s.value !== null ? s.value : s.default;
  if (v === undefined || v === null || v === "") return "not set";
  switch (s.kind) {
    case "money":
      return Number.isSafeInteger(v) ? formatMoney(v) : "not set";
    case "percent":
      return `${v}%`;
    case "bool":
      return v ? "yes" : "no";
    case "accounts":
      return Array.isArray(v) && v.length ? v.map((a) => optionLabel(s, a)).join(", ") : "not set";
    case "account":
    case "choice":
      return optionLabel(s, v);
    default:
      return String(v);
  }
}

function optionLabel(setting, value) {
  const opts = Array.isArray(setting.options) ? setting.options : [];
  const hit = opts.find((o) => (o && typeof o === "object" ? o.id ?? o.value : o) === value);
  if (hit && typeof hit === "object") return hit.label || String(value);
  return String(value);
}

/**
 * The SOP split into paragraphs, each a list of segments: `{text}` or
 * `{setting: key}`. `# ` lines are headings and `- ` lines list items; nothing else of
 * markdown is interpreted (a plain document, §19.6). A token naming no declared
 * setting stays as the words it was written as, never a blank.
 */
export function sopBlocks(body, settings) {
  const known = new Set((Array.isArray(settings) ? settings : []).map((s) => s && s.key).filter(Boolean));
  const text = typeof body === "string" ? body : "";
  const blocks = [];
  for (const raw of text.split(/\n{2,}/)) {
    let lines = raw.split("\n").filter((l) => l.trim());
    // A heading is its own block even when the paragraph under it follows directly.
    while (lines.length > 1 && /^#{1,3}\s+/.test(lines[0])) {
      blocks.push({ kind: "heading", segments: segments(lines[0].replace(/^#{1,3}\s+/, ""), known) });
      lines = lines.slice(1);
    }
    if (!lines.length) continue;
    if (lines.every((l) => /^\s*[-*]\s+/.test(l))) {
      blocks.push({ kind: "list", items: lines.map((l) => segments(l.replace(/^\s*[-*]\s+/, ""), known)) });
    } else if (lines.length === 1 && /^#{1,3}\s+/.test(lines[0])) {
      blocks.push({ kind: "heading", segments: segments(lines[0].replace(/^#{1,3}\s+/, ""), known) });
    } else {
      blocks.push({ kind: "para", segments: segments(lines.join(" "), known) });
    }
  }
  return blocks;
}

function segments(line, known) {
  const out = [];
  let at = 0;
  for (const m of line.matchAll(TOKEN)) {
    if (m.index > at) out.push({ text: line.slice(at, m.index) });
    out.push(known.has(m[1]) ? { setting: m[1] } : { text: m[0] });
    at = m.index + m[0].length;
  }
  if (at < line.length) out.push({ text: line.slice(at) });
  return out;
}

/**
 * The SOP as the sheet draws it (design-fix-2 DA2-055). The engine's generated SOP opens
 * with "# Fixed assets" under a pane titled "Fixed assets skill": the title said twice, so
 * a first heading that only repeats the skill's name is dropped. Nothing else changes.
 */
export function sheetBlocks(blocks, name) {
  const list = Array.isArray(blocks) ? blocks : [];
  const first = list[0];
  const words = (segs) => segs.map((g) => g.text || "").join("").trim().toLowerCase();
  if (first && first.kind === "heading" && name && words(first.segments) === String(name).trim().toLowerCase()) return list.slice(1);
  return list;
}

/** Display words for the engine's prose: its table names said as an accountant says them. */
export function displayText(text) {
  return typeof text === "string" ? text.replace(/\bgl lines\b/gi, "GL lines") : text;
}

/** "1500 · Plant & equipment" as the house writes an account: "1500 Plant & equipment" (design-fix-2 §3.4). */
export function accountWords(text) {
  return typeof text === "string" ? text.replace(/\b(\d{3,6}) \u00b7 /g, "$1 ") : text;
}

export const SETTING_GROUPS = Object.freeze(["Accounts", "Useful lives", "Method"]);

/**
 * A list of "Label: {{setting}}" items as a grouped definition grid (design-fix-2
 * DA2-055: nine "Label: value" bullets read as a form dump). Each item becomes
 * `{label, key}`; an account setting goes under Accounts, a "Useful life: …" under Useful
 * lives (labelled by what it is the life of), the rest under Method. Returns null when
 * any item is not exactly one label and one setting, so a list of prose stays a list.
 */
export function settingGroups(items, settings) {
  const byKey = new Map((Array.isArray(settings) ? settings : []).filter((s) => s && s.key).map((s) => [s.key, s]));
  if (!Array.isArray(items) || !items.length) return null;
  const rows = [];
  for (const segs of items) {
    if (!Array.isArray(segs) || segs.length !== 2 || typeof segs[0].text !== "string" || !segs[1].setting) return null;
    const m = /^\s*(.+?):\s*$/.exec(segs[0].text);
    const setting = byKey.get(segs[1].setting);
    if (!m || !setting) return null;
    const label = m[1];
    const life = /^useful life:?\s*(.+)$/i.exec(label);
    const group = setting.kind === "account" || setting.kind === "accounts" ? "Accounts" : life ? "Useful lives" : "Method";
    const shown = life ? life[1].charAt(0).toUpperCase() + life[1].slice(1) : label;
    rows.push({ group, label: shown, key: setting.key });
  }
  return SETTING_GROUPS.map((g) => ({ group: g, rows: rows.filter((r) => r.group === g) })).filter((g) => g.rows.length);
}

/**
 * The quiet tag the sheet carries for where the skill stands (DA2-055): "Built in" for a
 * skill nobody has edited (never "v0"), otherwise its version words with a capital.
 */
export function versionTag(skill) {
  const s = skill || {};
  if (s.version === 0) return "Built in";
  const v = versionWords(s);
  return v ? v.charAt(0).toUpperCase() + v.slice(1) : null;
}

/**
 * Settings the SOP does not phrase inline: listed under the SOP so none is hidden. The
 * start mode is not among them: it has its own sentence (startModeLine), so it is never
 * said twice.
 */
export function unphrasedSettings(body, settings) {
  const used = new Set([...(typeof body === "string" ? body : "").matchAll(TOKEN)].map((m) => m[1]));
  return (Array.isArray(settings) ? settings : []).filter((s) => s && s.key && s.key !== START_MODE_KEY && !used.has(s.key));
}

/* ── when the task starts (iteration 4, §20.0 decision 9) ─────────────────── */

/** The start-mode setting's key (PSTART's; the plan's Triggers section sends the same). */
export const START_MODE_KEY = "start_mode";

/**
 * The start mode in the skill's own words (decision 9's skill-sheet phrase). The plan's
 * Triggers section says the same two modes in its own place (components/chat/plan/
 * triggers-model.js START_MODES).
 */
export const SKILL_START_WORDS = Object.freeze({
  ask: "Ask me before starting",
  when_nothing_new: "Start when nothing is new; otherwise ask me",
});

const START_LEAD = /^\s*(Ask me before starting|Start when nothing is new; otherwise ask me)\.?\s*/;

/**
 * The skill's start sentence: the start mode, then the rest of the engine's checkpoint
 * sentence ("Pause if a difference is over $500.00."). Returns `{setting, words, mode,
 * rest}`:
 *   · `setting` — the declared `start_mode` setting, its options in the words above, to
 *     draw as a phrase changed in place; null until the task's skill declares it, and
 *     then the start mode is words only, never an edit the engine would refuse;
 *   · `words` — the mode in words (the default, "Ask me before starting", when nothing
 *     says otherwise; decision 9 keeps Ask me the default);
 *   · `rest` — the checkpoint sentence without its own start-mode lead, or null.
 * The SOP may phrase the start mode inline (`{{start_mode}}`); then this says nothing of
 * it (`words: null`), and only the rest of the checkpoint is drawn.
 */
const START_WORDS_ANYWHERE = /(Ask me before starting|Start when nothing is new; otherwise ask me)\.?[ \t]*/g;

/** Whether the steps already say the start mode in plain words (W05). Pure. */
export function bodySaysStart(body) {
  return new RegExp(START_WORDS_ANYWHERE.source).test(typeof body === "string" ? body : "");
}

/**
 * The steps without their plain start-mode words, for a sheet that draws the start mode
 * as its own switchable phrase under them (verify pass 3, W05: "Ask me before starting."
 * was the SOP's Checkpoints line and then the phrase again under it). Pure.
 */
export function bodyWithoutStartLead(body) {
  return typeof body === "string" ? body.replace(START_WORDS_ANYWHERE, "") : body;
}

/** Whether the steps already carry the checkpoint's own sentence (its words up to the first figure). */
function bodySaysRest(body, rest) {
  if (typeof body !== "string" || typeof rest !== "string") return false;
  const cut = rest.search(/[$\d{]/);
  const head = (cut < 0 ? rest : rest.slice(0, cut)).trim();
  return head.length >= 8 && body.includes(head);
}

export function startModeLine(body, settings, checkpoint) {
  const sentence = typeof checkpoint === "string" && checkpoint.trim() ? checkpoint.trim() : null;
  // A checkpoint sentence the steps already say is not drawn twice (W05).
  const restRaw = sentence ? sentence.replace(START_LEAD, "").trim() || null : null;
  const rest = restRaw && !bodySaysRest(body, restRaw) ? restRaw : null;
  const used = new Set([...(typeof body === "string" ? body : "").matchAll(TOKEN)].map((m) => m[1]));
  const declared = (Array.isArray(settings) ? settings : []).find((s) => s && s.key === START_MODE_KEY) || null;
  if (used.has(START_MODE_KEY)) return { setting: null, words: null, mode: null, rest };
  const lead = sentence ? START_LEAD.exec(sentence) : null;
  const fromSentence = lead ? (lead[1] === SKILL_START_WORDS.ask ? "ask" : "when_nothing_new") : null;
  const raw = declared ? (declared.value !== undefined && declared.value !== null ? declared.value : declared.default) : null;
  const mode = Object.hasOwn(SKILL_START_WORDS, raw) ? raw : fromSentence || "ask";
  const setting = declared
    ? {
        ...declared,
        kind: "choice",
        value: mode,
        phrase: null,
        options: Object.entries(SKILL_START_WORDS).map(([id, label]) => ({ id, label })),
      }
    : null;
  // The steps say the start mode in words already: with nothing to switch, the words are
  // not said again (W05); with the declared setting, the phrase is drawn and the sheet
  // drops the plain words from the steps (bodyWithoutStartLead).
  if (!setting && bodySaysStart(body)) return { setting: null, words: null, mode, rest };
  return { setting, words: SKILL_START_WORDS[mode], mode, rest };
}

/**
 * A typed edit to one setting, checked against its declared kind, as the engine will
 * check it (§19.0.5: "a value outside its schema is refused, not coerced"). Returns
 * `{ok, value}` or `{ok: false, message}`. Money arrives already as integer cents (the
 * kit's MoneyField parses it); nothing here converts a figure.
 */
export function checkSetting(setting, value) {
  const s = setting || {};
  const opts = Array.isArray(s.options) ? s.options.map((o) => (o && typeof o === "object" ? o.id ?? o.value : o)) : null;
  switch (s.kind) {
    case "money":
      return Number.isSafeInteger(value) && value >= 0 ? { ok: true, value } : { ok: false, message: "Enter an amount in dollars, like 2,500." };
    case "percent": {
      const n = typeof value === "string" ? Number(value.trim()) : value;
      return typeof n === "number" && Number.isFinite(n) && n >= 0 && n <= 100 && String(value).trim() !== ""
        ? { ok: true, value: n }
        : { ok: false, message: "Enter a percentage between 0 and 100." };
    }
    case "bool":
      return typeof value === "boolean" ? { ok: true, value } : { ok: false, message: "Choose yes or no." };
    case "account":
    case "choice":
      return opts && opts.includes(value) ? { ok: true, value } : { ok: false, message: "Choose one of the listed options." };
    case "accounts":
      return Array.isArray(value) && value.length && opts && value.every((v) => opts.includes(v))
        ? { ok: true, value }
        : { ok: false, message: "Choose one or more of the listed accounts." };
    case "text":
      return typeof value === "string" && value.trim() ? { ok: true, value: value.trim() } : { ok: false, message: "This can't be empty." };
    default:
      return { ok: false, message: "This setting can't be changed here." };
  }
}

/** The settings that changed, as `{key: value}`: what a Save sends, and nothing else. */
export function changedSettings(settings, edits) {
  const out = {};
  for (const s of Array.isArray(settings) ? settings : []) {
    if (!s || !s.key || !edits || !Object.prototype.hasOwnProperty.call(edits, s.key)) continue;
    const before = s.value !== undefined && s.value !== null ? s.value : s.default;
    if (JSON.stringify(before) !== JSON.stringify(edits[s.key])) out[s.key] = edits[s.key];
  }
  return out;
}

/* ── versions and what Vert knows ───────────────────────────────────────────── */

/** "v3 · Sam Lee · 2 Sep · Raised the threshold". Newest first. */
export function versionRows(versions) {
  const list = (Array.isArray(versions) ? versions : []).filter((v) => v && Number.isInteger(v.version));
  return [...list].sort((a, b) => b.version - a.version).map((v) => ({
    version: v.version,
    words: metaLine([`v${v.version}`, v.author || null, shortDay(v.createdAt) || null, v.reason || null]),
    scope: v.scope || null,
  }));
}

/** True when this client's version differs from the firm's (the engine says so). */
export function changedFromFirm(skill) {
  return Boolean(skill && skill.changedFromFirm === true);
}

/**
 * The live saved answers, oldest first, each with where it was given. `measured`
 * false means the list could not be read, which is said in words, never as an empty
 * list ("nothing saved yet" is a claim only a read can make).
 */
export function knowsList(knows) {
  // The engine's skill route sends a bare array of GET /memory's rows (a list it read,
  // so measured); lib/skills.js normalises it, and this accepts it too, so a sheet
  // handed the route's body directly cannot fall back to "couldn't read" (eval r1 LRN).
  const given = Array.isArray(knows) ? { measured: true, answers: knows } : knows;
  if (!given || given.measured === false || !Array.isArray(given.answers)) return { measured: false, answers: [] };
  const answers = given.answers
    .filter((a) => a && a.memoryId && a.words && !a.forgottenAt)
    .map((a) => ({
      memoryId: a.memoryId,
      words: a.words,
      href: a.from && a.from.sessionId ? `/chat/${encodeURIComponent(a.from.sessionId)}` : null,
      source: sourceWords(a.from),
    }));
  return { measured: true, answers };
}

/**
 * What Vert knows, as `{measured, answers}`, from a /memory read (lib/memory.js
 * `listWhatVertKnows`'s outcome) and what the skill route carried (`skill.knows`).
 *
 * The engine's skill route sends a BARE ARRAY of GET /memory's rows
 * (vert_api/routers/skills.py `skill_view`). /memory is the store's own answer and wins;
 * when it could not be read, the route's array stands, and is measured, because it is
 * a list the engine read. Anything else is unmeasured, which the sheet says in words;
 * it is never shown as "nothing saved yet".
 */
export function knowsFrom(read, carried = null) {
  if (read && read.ok && read.knows && Array.isArray(read.knows.answers)) return { measured: true, answers: read.knows.answers };
  if (Array.isArray(carried)) return { measured: true, answers: carried };
  if (carried && typeof carried === "object" && carried.measured !== false && Array.isArray(carried.answers)) return { measured: true, answers: carried.answers };
  return { measured: false, answers: [] };
}

/** "Sam Lee answered on 3 Sep" — the link text of a saved answer's source. */
export function sourceWords(from) {
  if (!from) return null;
  const day = shortDay(from.at);
  if (from.by && day) return `${from.by} answered on ${day}`;
  if (from.by) return `${from.by} answered`;
  if (day) return `Answered on ${day}`;
  return "Where it was answered";
}

/** A list with one answer taken out (after Forget is read back). */
export function withoutAnswer(knows, memoryId) {
  if (!knows || !Array.isArray(knows.answers)) return knows;
  return { ...knows, answers: knows.answers.filter((a) => a && a.memoryId !== memoryId) };
}

/* ── Pause Vert ─────────────────────────────────────────────────────────────── */

/** Whether the tenant skill says Vert is paused; null when it could not be read. */
export function pausedOf(tenantSkill) {
  if (!tenantSkill || typeof tenantSkill !== "object") return null;
  const settings = tenantSkill.settings;
  if (Array.isArray(settings)) {
    const s = settings.find((x) => x && x.key === "paused");
    if (s) return Boolean(s.value !== undefined && s.value !== null ? s.value : s.default);
  } else if (settings && typeof settings === "object" && "paused" in settings) {
    return Boolean(settings.paused);
  }
  return false;
}

/** The menu's words, with the consequence stated (§19.6: "its consequence in words"). */
export function pauseWords(paused) {
  if (paused === true) {
    return {
      label: "Resume Vert",
      state: "Vert is paused. It asks you before starting any task, and nothing posts without your press.",
    };
  }
  if (paused === false) {
    return {
      label: "Pause Vert",
      state: "Pausing makes Vert ask you before it starts any task, for everyone on this client.",
    };
  }
  return { label: null, state: "Vert couldn't read whether it is paused just now." };
}

/* ── the sheet grows from what opened it ────────────────────────────────────── */

/** The right sheet's width in px (kit.css `.sheet-right .sheet`: min(36rem, 100%)). */
export const SHEET_WIDTH = 576;

/**
 * The transform-origin, in the right panel's own coordinates, that puts its growth
 * point on the control that opened it (apple-design §7: anchored to the trigger, and
 * it leaves the way it came). Null when the trigger was not measured.
 */
export function sheetOrigin(rect, viewport, width = SHEET_WIDTH) {
  if (!rect || !viewport || ![rect.left, rect.top, rect.width, rect.height, viewport.width, viewport.height].every(Number.isFinite)) return null;
  const w = Math.min(width, viewport.width);
  const left = viewport.width - w;
  const x = Math.min(Math.max(Math.round(rect.left + rect.width / 2 - left), 0), w);
  const y = Math.min(Math.max(Math.round(rect.top + rect.height / 2), 0), viewport.height);
  return `${x}px ${y}px`;
}
