"use client";

// components/skills/OpenSkill.js — ANY CONTROL THAT OPENS A TASK'S SKILL
// ==============================================================================
// Build plan §19.6 F-BRAIN: the skill sheet opens from three places (the Thoughts load
// line, a task row's "Open skill", the answered question's "Saved to the skill"), and
// all three open it the same way: the sheet grows out of the control that was pressed
// and goes back into it (apple-design §7; reduced motion is the Sheet's cross-fade).
// One component, so the three cannot drift into three sheets.
//
// It is a way to a page, not a write: quiet, never the accent.
//
// THE SHEET IS PORTALLED TO <body> (eval r2, skill-1-sheet.png). Drawn where the control
// is, inside the chat pane, the kit's `position: fixed` layer was laid out against the
// pane (a transformed / stacked ancestor), not the viewport: its header slid under the
// conversation's top bar and the pane's own stacking put the panel below it. From <body>
// it is the viewport's, as EventFigure's source sheet already is, and the origin the
// control measured (viewport coordinates) is the right one. No document (a server
// render) means no portal and no sheet: it only ever opens on a press.

import { useState } from "react";
import { createPortal } from "react-dom";
import SkillSheet from "./SkillSheet";
import { sheetOrigin } from "./model";

export default function OpenSkill({ template, title = null, client = null, className = "chat-quiet skill-open", children, skill = null, initiallyOpen = false }) {
  const [open, setOpen] = useState(initiallyOpen);
  const [origin, setOrigin] = useState(null);
  if (!template) return null;
  return (
    <>
      <button
        type="button"
        className={className}
        data-open-skill={template}
        aria-haspopup="dialog"
        onClick={(event) => {
          const el = event.currentTarget;
          if (el && typeof el.getBoundingClientRect === "function" && typeof window !== "undefined") {
            setOrigin(sheetOrigin(el.getBoundingClientRect(), { width: window.innerWidth, height: window.innerHeight }));
          }
          setOpen(true);
        }}
      >
        {children}
      </button>
      {open ? inBody(<SkillSheet open template={template} title={title} client={client} skill={skill} origin={origin} onClose={() => setOpen(false)} />) : null}
    </>
  );
}

/** Draw `node` at the end of <body>, out of every pane's layout and stacking. */
export function inBody(node, doc = typeof document === "undefined" ? null : document) {
  return doc && doc.body ? createPortal(node, doc.body) : null;
}
