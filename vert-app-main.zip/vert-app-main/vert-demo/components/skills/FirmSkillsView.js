"use client";

// components/skills/FirmSkillsView.js — THE FIRM'S SKILLS, AND EACH CLIENT AGAINST THEM (verify pass 2, D44)
// ==============================================================================
// The D44 trigger could not be performed in the product: the fork existed only as an API
// route and an uncalled server action. This view lists every skill the firm has written
// with each client's state under it (uses the firm's version / its own version / not
// given it yet), an Edit for the firm's version, and "Fork for <client>" for each client
// that does not yet have its own copy. Both writes say what happened only once the
// engine's own list reads it back (lib/firm.js forkFirmSkill, lib/firm-skills.js).

import Link from "next/link";
import { useState } from "react";

import { Button } from "@/components/ui";
import { CLIENTS_HREF } from "@/components/shell/ia";
import { IconCaretLeft } from "@/components/ui/icons";
import { forkFirmSkill } from "@/lib/firm";
import { saveFirmSkill } from "@/lib/firm-skills";

import { FIRM_STEPS_TITLE, firmSkillRows, firmVersionWords, forkReadBack } from "./firm-skills-model";
import "./forks.css";

function FirmEditor({ row, onSaved, onCancel }) {
  const [body, setBody] = useState(row.body);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState(null);

  async function save(event) {
    event.preventDefault();
    setBusy(true);
    setProblem(null);
    const result = await saveFirmSkill(row.template, { body, reason, parentVersion: row.version || 0, settings: row.settings });
    setBusy(false);
    if (!result || !result.ok) {
      setProblem((result && result.message) || "Not saved. Nothing was changed.");
      return;
    }
    onSaved(result);
  }

  return (
    <form className="firm-skill-editor" onSubmit={save} aria-label={`Edit the firm's ${row.title}`}>
      <label className="firm-skill-label" htmlFor={`firm-body-${row.template}`}>
        The firm&rsquo;s steps
      </label>
      <textarea id={`firm-body-${row.template}`} name="firmSkillBody" autoComplete="off" className="firm-skill-text" value={body} onChange={(e) => setBody(e.target.value)} rows={10} required />
      <label className="firm-skill-label" htmlFor={`firm-reason-${row.template}`}>
        Why you changed it
      </label>
      <input id={`firm-reason-${row.template}`} name="firmSkillReason" autoComplete="off" className="firm-skill-reason" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} required />
      <p className="firm-skill-note t-footnote">
        Saving gives every client that uses the firm&rsquo;s version the new one. A client with its own version keeps it.
      </p>
      {problem ? (
        <p className="firm-skill-problem t-footnote" role="alert">
          {problem}
        </p>
      ) : null}
      <div className="firm-skill-actions">
        <Button type="button" variant="quiet" onClick={onCancel} disabled={busy}>
          Cancel
        </Button>
        <Button type="submit" variant="commit" disabled={busy || !reason.trim() || !body.trim()}>
          {busy ? "Saving…" : "Save"}
        </Button>
      </div>
    </form>
  );
}

function SkillRow({ row, onBody, setNotice }) {
  const [editing, setEditing] = useState(false);
  const [forking, setForking] = useState(null);
  const [problem, setProblem] = useState(null);

  async function fork(client) {
    setForking(client.tenantId);
    setProblem(null);
    const result = await forkFirmSkill(row.template, client.tenantId);
    setForking(null);
    if (!result || !result.ok) {
      setProblem((result && result.message) || "Not added. Nothing was changed.");
      return;
    }
    onBody(result.skills);
    if (forkReadBack(result.skills, row.template, client.tenantId)) {
      setNotice(`${client.name} now has its own copy of ${row.title}. Later firm changes leave it alone.`);
    } else {
      setProblem("Vert couldn't confirm the copy. Open the firm's skills again to check.");
    }
  }

  return (
    <li className="firm-skill" data-firm-skill={row.template}>
      <div className="firm-skill-head">
        <div className="firm-skill-words">
          <h2 className="t-headline firm-skill-title">{row.title}</h2>
          <p className="t-footnote firm-skill-version">{firmVersionWords(row)}</p>
        </div>
        {editing ? null : (
          <Button variant="secondary" size="sm" onClick={() => setEditing(true)} aria-label={`Edit the firm's ${row.title}`}>
            Edit
          </Button>
        )}
      </div>
      {editing ? (
        <FirmEditor
          row={row}
          onCancel={() => setEditing(false)}
          onSaved={(result) => {
            setEditing(false);
            onBody(result.skills);
            const kept = result.clients.filter((c) => c && c.outcome === "forked").length;
            setNotice(`Saved as the firm's version ${result.version} of ${row.title}.${kept ? ` ${kept === 1 ? "1 client keeps its own version" : `${kept} clients keep their own versions`}.` : ""}`);
          }}
        />
      ) : null}
      {problem ? (
        <p className="firm-skill-problem t-footnote" role="alert">
          {problem}
        </p>
      ) : null}
      {row.clients.length ? (
        <ul className="firm-skill-clients" aria-label={`Clients and ${row.title}`}>
          {row.clients.map((c) => (
            <li key={c.tenantId} className="firm-skill-client" data-client-state={c.state || "unread"}>
              <span className="firm-skill-client-name" translate="no" title={c.name}>
                {c.name}
              </span>
              <span className="firm-skill-client-state t-footnote">{c.words}</span>
              {c.canFork ? (
                <Button variant="quiet" size="sm" onClick={() => fork(c)} disabled={forking !== null}>
                  {forking === c.tenantId ? "Copying…" : `Fork for ${c.name}`}
                </Button>
              ) : (
                <span />
              )}
            </li>
          ))}
        </ul>
      ) : (
        <p className="t-footnote firm-skill-none">No client is engaged with this firm yet.</p>
      )}
    </li>
  );
}

export default function FirmSkillsView({ answer }) {
  const [body, setBody] = useState(answer && answer.ok ? answer.skills : null);
  const [notice, setNotice] = useState(null);
  const view = firmSkillRows(body);

  return (
    <div className="page firm-skills" data-firm-skills="">
      <header className="page-head">
        <Link href={CLIENTS_HREF} className="records-back">
          <IconCaretLeft className="caret-leading" />
          Clients
        </Link>
        <div className="page-head-words">
          <h1 className="t-title-1">{FIRM_STEPS_TITLE}</h1>
          <p className="page-head-sub">The steps your firm wrote once and uses for every client. A client can have its own copy.</p>
        </div>
      </header>
      <p className="firm-skills-notice t-footnote" role="status" aria-live="polite">
        {notice}
      </p>
      {!answer || !answer.ok ? (
        <p className="t-callout">{(answer && answer.message) || "Vert couldn't read the firm's skills just now."}</p>
      ) : !view.read ? (
        <p className="t-callout">Vert couldn&rsquo;t read the firm&rsquo;s skills just now.</p>
      ) : view.rows.length ? (
        <ul className="firm-skills-list">
          {view.rows.map((row) => (
            <SkillRow key={row.template} row={row} onBody={setBody} setNotice={setNotice} />
          ))}
        </ul>
      ) : (
        <p className="t-callout">Your firm hasn&rsquo;t written its own version of any skill yet. Open a task&rsquo;s skill from a conversation to change how Vert does it.</p>
      )}
    </div>
  );
}
