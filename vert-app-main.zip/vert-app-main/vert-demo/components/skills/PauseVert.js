"use client";

// components/skills/PauseVert.js — THE KILL SWITCH, IN THE ACCOUNT MENU
// ==============================================================================
// Build plan §19.0.6, §19.6 F-BRAIN. Pause Vert writes the reserved `_tenant` skill
// (`paused: true`), which makes every task ask before it starts, for everyone on this
// client. Its consequence is said in words beside it, before and after the press:
// a switch whose effect is a guess is not a switch anyone will trust in a hurry.
//
// THE STATE SHOWN IS THE ENGINE'S. It is read when the menu opens, and after a press
// lib/skills.js reads it back; the line changes only when the read-back agrees. While
// the state is unknown the button is not drawn (no press into an unknown state).
// Posting is not a setting: nothing posts without a person's press either way.
//
// Not purple: it is a setting, not the view's commit (§13, one purple per view).

import { useEffect, useState } from "react";
import { pauseVert } from "@/lib/skills";
import { pauseWords } from "./model";

/** Read whether Vert is paused through the app's route. `null` when unread. */
export async function fetchPaused(fetchImpl = globalThis.fetch) {
  try {
    const res = await fetchImpl("/api/skills?template=_tenant", { cache: "no-store" });
    const body = await res.json();
    return body && body.ok && typeof body.paused === "boolean" ? body.paused : null;
  } catch {
    return null;
  }
}

export default function PauseVert({ open = true, initial = undefined, toggle = pauseVert }) {
  const [paused, setPaused] = useState(initial === undefined ? null : initial);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    if (!open || initial !== undefined) return undefined;
    let live = true;
    fetchPaused().then((p) => {
      if (live) setPaused(p);
    });
    return () => {
      live = false;
    };
  }, [open, initial]);

  const words = pauseWords(paused);
  async function press() {
    setBusy(true);
    setMessage(null);
    let result = null;
    try {
      result = await toggle(!paused);
    } catch {
      result = null;
    }
    setBusy(false);
    if (result && result.ok) setPaused(result.paused);
    else setMessage((result && result.message) || "Nothing was changed. Try again.");
  }

  return (
    <div className="pause-vert" data-paused={paused === null ? "unknown" : String(paused)}>
      {words.label ? (
        <button type="button" className="row menu-item pause-vert-toggle" aria-describedby="pause-vert-state" disabled={busy} onClick={press}>
          <span>{busy ? (paused ? "Resuming…" : "Pausing…") : words.label}</span>
        </button>
      ) : null}
      <p className="pause-vert-state t-footnote" id="pause-vert-state" role="status">
        {words.state}
      </p>
      {message ? (
        <p className="chat-inline-error t-footnote" role="alert">
          {message}
        </p>
      ) : null}
    </div>
  );
}
