// components/skills/firm-model.js — A FIRM SKILL'S CLIENT FORKS, READ ONE WAY
// ==============================================================================
// Build plan §19.9 F-FIRM, FORK. The firm's skills (`GET /firm/skills`) are published to
// every engaged client, and a client that changed one has its own version, which wins
// for that client. The skill sheet shows those client versions as indented rows under
// the firm's, ONLY ONCE A FORK EXISTS (§19.16 P3): a firm skill nobody has changed is
// just the skill, and a "Clients: none" section would be furniture.
//
// TOLERANT OF THE TWO SHAPES THE ROUTE MAY TAKE. FORK writes the route in parallel with
// this file, so the reader accepts `{ skills: [...] }` or a bare list, a fork keyed
// `tenantId` or `tenant`, and drops anything it cannot name rather than inventing a
// row. Every word on a row comes from the payload; nothing is computed.

function list(value) {
  return Array.isArray(value) ? value : [];
}

/** The firm skills a `GET /firm/skills` body lists. */
export function firmSkills(body) {
  if (Array.isArray(body)) return body;
  return list(body && (body.skills || body.items));
}

/** `{ firm: { version }, forks: [{ tenantId, name, version, by, at }] }` for one template; forks may be empty. */
export function forksOf(body, template) {
  const skill = firmSkills(body).find((s) => s && (s.template === template || s.id === template));
  if (!skill) return { firm: null, forks: [] };
  const forks = list(skill.forks || skill.clients)
    .map((f) => {
      const tenantId = f && (f.tenantId || f.tenant);
      if (typeof tenantId !== "string" || !tenantId) return null;
      return {
        tenantId,
        name: typeof f.name === "string" && f.name.trim() ? f.name.trim() : tenantId,
        version: Number.isInteger(f.version) ? f.version : null,
        by: typeof f.editedBy === "string" && f.editedBy ? f.editedBy : typeof f.by === "string" && f.by ? f.by : null,
        at: typeof f.editedAt === "string" ? f.editedAt : typeof f.at === "string" ? f.at : null,
      };
    })
    .filter(Boolean);
  return { firm: { version: Number.isInteger(skill.version) ? skill.version : null }, forks };
}

/** "Northwind Trading · its own version (v5), changed by Sam Lee" — the payload's words, joined. */
export function forkWords(fork) {
  const parts = [fork.version != null ? `its own version (v${fork.version})` : "its own version"];
  if (fork.by) parts.push(`changed by ${fork.by}`);
  return `${fork.name} · ${parts.join(", ")}`;
}

/** "The firm's version (v3)" for the parent row. */
export function firmWords(firm) {
  return firm && firm.version != null ? `The firm's version (v${firm.version})` : "The firm's version";
}

/** Read the firm's skills through the app. `{ ok, body }`, or `{ ok: false }` for any refusal. Never throws. */
export async function fetchFirmSkills(fetchImpl = globalThis.fetch) {
  try {
    const res = await fetchImpl("/api/firm?view=skills", { cache: "no-store" });
    if (!res.ok) return { ok: false };
    const body = await res.json().catch(() => null);
    return body && body.ok ? { ok: true, body: body.skills } : { ok: false };
  } catch {
    return { ok: false };
  }
}
