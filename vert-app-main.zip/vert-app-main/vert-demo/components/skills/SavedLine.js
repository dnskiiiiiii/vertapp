"use client";

// components/skills/SavedLine.js — "SAVED TO THE SKILL · FORGET", UNDER AN ANSWER
// ==============================================================================
// Build plan §19.0.4, §19.6 F-BRAIN. When the template's question says its answer may
// be kept (`remember` client or subject), the engine keeps it and marks the answered
// line (`clarification_answered.remembered`). The line says so in the open, with the
// two things a person can do about it: open the skill it was saved to, and Forget.
//
// FORGET IS READ BACK (lib/memory.js): the line says "Forgotten" only when the engine
// confirmed it; a refusal says nothing changed. Nothing is deleted, and the question
// is asked again next time, which is what the words promise.

import { useState } from "react";
import { forgetAnswer } from "@/lib/memory";
import OpenSkill from "./OpenSkill";
import { savedWords } from "./model";

export default function SavedLine({ remembered, template = null, client = null, forget = forgetAnswer }) {
  const [state, setState] = useState({ phase: "kept", message: null });
  const words = savedWords(remembered);
  if (!words) return null;
  if (state.phase === "forgotten") {
    return (
      <p className="skill-saved t-footnote" data-saved="forgotten" role="status">
        Forgotten. Vert will ask this again next time.
      </p>
    );
  }
  async function press() {
    setState({ phase: "busy", message: null });
    let result = null;
    try {
      result = await forget(remembered.memoryId);
    } catch {
      result = null;
    }
    if (result && result.ok) setState({ phase: "forgotten", message: null });
    else setState({ phase: "kept", message: (result && result.message) || "Not forgotten. Nothing was changed. Try again." });
  }
  return (
    <p className="skill-saved t-footnote" data-saved={remembered.memoryId}>
      {template ? (
        <OpenSkill template={template} client={client} className="chat-quiet skill-open">
          {words}
        </OpenSkill>
      ) : (
        <span>{words}</span>
      )}
      {" · "}
      <button type="button" className="chat-quiet skill-forget" disabled={state.phase === "busy"} onClick={press}>
        {state.phase === "busy" ? "Forgetting…" : "Forget"}
      </button>
      {state.message ? (
        <span className="chat-inline-error" role="alert">
          {" "}
          {state.message}
        </span>
      ) : null}
    </p>
  );
}
