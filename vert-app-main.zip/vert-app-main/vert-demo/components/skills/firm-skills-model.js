// components/skills/firm-skills-model.js — THE FIRM SKILLS VIEW, READ ONE WAY (verify pass 2, D44)
// ==============================================================================
// `GET /firm/skills` lists each skill the firm has written (its latest version) and every
// engaged client's relation to it. This turns that body into rows; every word is the
// engine's state said in a bookkeeper's words, and nothing is computed but which client
// can still be forked.
//
//   follows        "Uses the firm's version"
//   behind         "On an older firm version"       (a publish never reached it)
//   forked         "Its own version (v5)"           (the client's edit wins there)
//   not_published  "Not given the firm's version yet"
//   (unread)       "Couldn't read this client"      (never one of the four)

import { skillTitle } from "./model";

/**
 * The firm view's name, on its heading and on the Clients link to it (verify pass 4,
 * U65): what the page is to the person, without the word "skill", which the words
 * rule keeps to the load line, the skill sheet and the skill-update card.
 */
export const FIRM_STEPS_TITLE = "How Vert does each task";

export const STATE_WORDS = Object.freeze({
  follows: "Uses the firm's version",
  behind: "On an older firm version",
  forked: "Its own version",
  not_published: "Not given the firm's version yet",
});

function text(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

/** One client's line under a firm skill. */
export function clientLine(c) {
  const tenantId = text(c && c.tenantId);
  if (!tenantId) return null;
  const name = text(c.name) || tenantId;
  const state = Object.hasOwn(STATE_WORDS, c.state) ? c.state : null;
  if (!state) return { tenantId, name, state: null, words: text(c.unread) || "Couldn't read this client", canFork: false, own: false };
  const version = Number.isInteger(c.version) && c.version > 0 ? c.version : null;
  const words = state === "forked" ? `${STATE_WORDS.forked}${version ? ` (v${version})` : ""}${text(c.editedBy) ? `, changed by ${text(c.editedBy).replace(/^user:/, "")}` : ""}` : STATE_WORDS[state];
  return { tenantId, name, state, words, canFork: state !== "forked", own: state === "forked" };
}

/** `{ read, rows }` from a `GET /firm/skills` body (or `{ skills: body }` from the app route). Pure. */
export function firmSkillRows(body) {
  const inner = body && typeof body === "object" && body.skills && !Array.isArray(body.skills) && typeof body.skills === "object" ? body.skills : body;
  const list = inner && Array.isArray(inner.skills) ? inner.skills : Array.isArray(inner) ? inner : null;
  if (!list) return { read: false, rows: [] };
  const rows = list
    .filter((s) => s && typeof s.template === "string" && s.template)
    .map((s) => ({
      template: s.template,
      title: skillTitle(s.template, s.title),
      version: Number.isInteger(s.version) ? s.version : null,
      body: typeof s.body === "string" ? s.body : "",
      settings: s.settings && typeof s.settings === "object" ? s.settings : {},
      editedBy: text(s.editedBy) ? text(s.editedBy).replace(/^user:/, "") : null,
      editedAt: text(s.editedAt),
      clients: (Array.isArray(s.clients) ? s.clients : []).map(clientLine).filter(Boolean),
    }));
  return { read: true, rows };
}

/** "The firm's version 3, changed by Sam Lee on 14 Oct" — the head of a skill's row. */
export function firmVersionWords(row) {
  const parts = [row.version != null ? `The firm's version ${row.version}` : "The firm's version"];
  if (row.editedBy) parts.push(`changed by ${row.editedBy}`);
  return parts.join(", ");
}

/** Whether a fork read back: the client now runs its own version. Pure. */
export function forkReadBack(body, template, tenantId) {
  const { rows } = firmSkillRows(body);
  const row = rows.find((r) => r.template === template);
  const line = row && row.clients.find((c) => c.tenantId === tenantId);
  return Boolean(line && line.state === "forked");
}
