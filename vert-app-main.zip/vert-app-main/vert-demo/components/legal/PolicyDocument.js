// components/legal/PolicyDocument.js — A DRAFT LEGAL DOCUMENT, SHOWING ITS GAPS
// ==============================================================================
// Renders the block tree from lib/policy-doc.js. It is a server component with no
// state, no effects and no client bundle: these two pages are read by a vendor
// reviewer who is not signed in, and there is nothing on them worth shipping React to
// the browser for.
//
// ────────────────────────────────────────────────────────────────────────────
// THE ONE RULE THIS COMPONENT EXISTS TO ENFORCE
// ────────────────────────────────────────────────────────────────────────────
//
// A policy that silently reads as final while containing invented facts is far worse
// than one that shows its gaps. Vert has no registered entity name on file, no ABN, no
// support address and no privacy address; a plausible-looking "Vert Pty Ltd (ABN 12 345
// 678 901)" would be a false statement about a legal person, sitting on a public URL
// that a vendor reviewer has been given as evidence.
//
// So every unresolved fact renders as `<mark>` with the words NOT YET ESTABLISHED in
// it. Not a blank, not an ellipsis, not a grey box a skim reads past: a phrase that
// cannot be mistaken for prose, carrying the description of what is missing so the
// reader knows which fact it is. The page also opens by counting them, because a
// reviewer deciding whether this document is usable needs that number before the first
// clause rather than after the last one.
//
// ────────────────────────────────────────────────────────────────────────────
// WHAT A BLOCKQUOTE IS IN THESE DOCUMENTS
// ────────────────────────────────────────────────────────────────────────────
//
// Never a pull-quote. Every one is an aside written TO the drafter — "do not publish
// this clause until the export exists", "the earlier wording said 'as drafts' and that
// was false". They are kept, because deleting the sentences that say which clauses are
// not ready would make the page read more finished than it is, and they are labelled so
// nobody reads one as a term of the contract.
//
// They are NOT drawn with a coloured left stripe. A stripe is the reflex for a
// blockquote and it is on this project's ban list; these are bounded boxes with a
// stated label, which is what actually tells a reader what they are looking at.

import { outline, parseDocument, slug, unresolvedCount } from "@/lib/policy-doc";

/* ── inline ─────────────────────────────────────────────────────────────── */

function Runs({ runs }) {
  return runs.map((run, i) => {
    if (run.type === "fill") return <Fill key={i} hint={run.hint} />;
    if (run.type === "strong")
      return (
        <strong key={i}>
          <Runs runs={run.runs} />
        </strong>
      );
    if (run.type === "code") return <code key={i}>{run.value}</code>;
    if (run.type === "link")
      return (
        <a key={i} href={run.href} rel="noreferrer">
          <Runs runs={run.runs} />
        </a>
      );
    return <span key={i}>{run.value}</span>;
  });
}

/**
 * A fact nobody has established, inline, in the middle of a sentence.
 *
 * `<mark>` rather than a styled span: the semantics are right (this is marked text
 * requiring the reader's attention) and it survives a stylesheet that fails to load,
 * which a `background-color` alone does not. The literal words "NOT YET ESTABLISHED"
 * are inside the element rather than supplied by CSS `::before`, for the same reason
 * and one more — CSS-generated text is not in the accessibility tree reliably, is not
 * copied when a reviewer copies the paragraph, and is not in the markup a test reads.
 */
function Fill({ hint }) {
  return (
    <mark className="fill">
      <span className="fill-tag">Not yet established</span>
      {hint ? <span className="fill-hint">{hint}</span> : null}
    </mark>
  );
}

/* ── blocks ─────────────────────────────────────────────────────────────── */

function Block({ block }) {
  switch (block.type) {
    case "heading": {
      // The document's own levels, unshifted. `#` is the title and is lifted out of
      // the body by PolicyDocument below, so `##` is the top level that reaches here
      // and it must render as <h2> — shifting it to <h3> left the page with an <h1>
      // and no <h2>, and the contents list pointing at anchors on the wrong elements.
      const Tag = `h${Math.min(Math.max(block.level, 2), 6)}`;
      const id = block.text ? slug(block.text) : undefined;
      return (
        <Tag id={id}>
          <Runs runs={block.runs} />
        </Tag>
      );
    }

    case "para":
      return (
        <p>
          <Runs runs={block.runs} />
        </p>
      );

    case "list":
      return (
        <ul>
          {block.items.map((item, i) => (
            <li key={i}>
              <Runs runs={item} />
            </li>
          ))}
        </ul>
      );

    case "table":
      // Wrapped in its own scroll region. The sub-processor table has three columns of
      // prose and a phone is 390px wide; a table that cannot shrink must scroll INSIDE
      // its own box rather than push the whole document sideways.
      return (
        <div className="policy-table-scroll">
          <table className="policy-table">
            <thead>
              <tr>
                {block.head.map((cell, i) => (
                  <th key={i} scope="col">
                    <Runs runs={cell} />
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {block.rows.map((row, r) => (
                <tr key={r}>
                  {row.map((cell, c) => (
                    <td key={c}>
                      <Runs runs={cell} />
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );

    case "note":
      return (
        <aside className="policy-note" aria-label="Drafting note">
          <p className="policy-note-label">Drafting note: not part of this document</p>
          {block.blocks.map((b, i) => (
            <Block key={i} block={b} />
          ))}
        </aside>
      );

    case "fill": {
      // A whole clause that has not been written. §11 of the terms — limitation of
      // liability — is this, and rendering it as prose would be the single most
      // misleading thing this page could do.
      //
      // The note's own bullets are kept as bullets. Lifting the span out of the
      // document collapsed its line breaks (it has to: a placeholder is one fact, not
      // one per line), which turned the four facts a drafter needs into a single
      // run-on with stray "-" characters in the middle of it. Split back apart on the
      // list markers, so the clause that most needs a lawyer to read it is legible.
      const [lede, ...points] = block.hint.split(/\s+-\s+/);
      return (
        <div className="policy-fill-block" role="note">
          <p className="policy-fill-block-label">This clause is not written yet</p>
          <p className="policy-fill-block-body">{lede}</p>
          {points.length ? (
            <ul className="policy-fill-block-points">
              {points.map((point, i) => (
                <li key={i}>{point}</li>
              ))}
            </ul>
          ) : null}
        </div>
      );
    }

    case "rule":
      return <hr />;

    default:
      return null;
  }
}

/* ── the page ───────────────────────────────────────────────────────────── */

export default function PolicyDocument({ source, updated = null }) {
  const blocks = parseDocument(source);
  const unresolved = unresolvedCount(source);
  const sections = outline(blocks);

  // The document's own H1 is lifted out and drawn as the page title, so the banner can
  // sit directly beneath it rather than after the first clause. Everything else renders
  // in source order, unedited.
  const titleBlock = blocks.find((b) => b.type === "heading" && b.level === 1);
  const body = blocks.filter((b) => b !== titleBlock);

  return (
    <main className="policy" id="main">
      <article className="policy-doc">
        <header className="policy-head">
          <p className="policy-kicker">Vert</p>
          {titleBlock ? (
            <h1>
              <Runs runs={titleBlock.runs} />
            </h1>
          ) : null}

          {/* THE BANNER. First thing under the title, before any clause, because a
              reviewer deciding whether this document can be relied on needs the answer
              before they start reading rather than after. It states the count: "19
              facts" is checkable against the page, and a reader who finds nineteen
              marks knows the banner is telling the truth. */}
          <div className="policy-draft" role="note">
            <p className="policy-draft-title">
              This is a working draft, not a published policy
            </p>
            <p className="policy-draft-body">
              It has not been reviewed by a lawyer.{" "}
              <strong>
                {unresolved} {unresolved === 1 ? "fact is" : "facts are"} not yet
                established
              </strong>
              : the legal entity, its ABN and registered address, the contact addresses,
              and several retention periods among them. Every one of them is marked in
              place below, like this: <Fill hint="an example" />. Nothing has been
              guessed at or filled in with a placeholder that reads as real.
            </p>
            {updated ? <p className="policy-draft-meta">Last updated {updated}</p> : null}
          </div>
        </header>

        {sections.length > 2 ? (
          <nav className="policy-toc" aria-label="Contents">
            <p className="policy-toc-label">Contents</p>
            {/* UNNUMBERED, because every heading in these documents already carries its
                own section number. An <ol> rendered "1. 1. What these terms cover", and
                the second number is the one a reader needs — it is the number the
                document itself uses when §3 refers to §11. */}
            <ul>
              {sections.map((s) => (
                <li key={s.id}>
                  <a href={`#${s.id}`}>{s.text}</a>
                </li>
              ))}
            </ul>
          </nav>
        ) : null}

        <div className="policy-body">
          {body.map((b, i) => (
            <Block key={i} block={b} />
          ))}
        </div>
      </article>
    </main>
  );
}
