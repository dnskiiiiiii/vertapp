"use server";

// components/sync/actions.js — PRESSING THE BUTTON, AND WATCHING WHAT IT DID
// ==============================================================================
// Two Server Actions, and they are Server Actions rather than browser fetches for a
// reason that is stronger here than it is for the approve/reject pair next door in
// lib/actions.js: the worker's bearer token must never reach a browser. A client-side
// fetch would need the credential in the page, and there is no arrangement of CORS
// and origins that makes that safe. Keeping the call on the server means the viewer
// learns neither the worker's address nor its key — they see sentences.
//
// The three reasons lib/actions.js gives all apply as well: the worker ships no CORS
// configuration (correctly — it is not a public endpoint), the base URL stays server
// side, and after a run the page has to re-render from the DATABASE rather than from
// what this browser hoped, which `router.refresh()` in the caller does.
//
// WHAT THESE RETURN, AND WHAT THEY REFUSE TO RETURN
//
// Everything is a plain described outcome; nothing throws. `run.report` is the
// worker's narration — sentences written by vert_connect/sync.py narrate(), which
// quotes the engine's and the vendor's own words and never a slug. This module does
// not compose a single sentence of its own about a close, and it must not start:
// the moment a second place words "what stopped and why", the two disagree.

import { revalidatePath } from "next/cache";
import { API_BASE_URL } from "@/lib/engine-source";
import { engineFetch } from "@/lib/engine-gate";
import { authHeaders, readSession } from "@/lib/session";
import { readConnections } from "@/lib/connections";
import { startPlannedSync, syncToday } from "@/lib/sync-plan";
import {
  requestLatestRun,
  requestRun,
  requestRunStatus,
  requestBankAccounts,
  chooseBankAccount,
} from "./worker-transport";

// After a run the durable state has moved — the register's rows, the status column,
// the sidebar's exception badge — so everything rendered from it is stale. The layout
// is the common ancestor of all of them, which is why the scope is "layout". Called
// only when a run FINISHED and reported that it changed something: a poll that
// returns "still running" must not invalidate the page under the reader every second.
function refresh() {
  revalidatePath("/", "layout");
}

/**
 * Start a sync.
 *
 * Safe to call twice. The worker joins an in-flight run for the same tenant rather
 * than starting a second one, and answers with the run already going; below that,
 * ingestion itself is idempotent (content-addressed evidence, ON CONFLICT DO NOTHING,
 * a pipeline that asks the database before every step). So the two failure modes a
 * double press could have — two sets of vendor calls, or two sets of rows — are both
 * closed, and by different mechanisms.
 */

/** Whose books this request may sync, taken from the signed-in session.
 *
 * WHOSE BOOKS WAS A DEPLOYMENT SETTING UNTIL NOW. `VERT_SYNC_TENANT` named one tenant
 * for the whole server, so every viewer who pressed Sync started a run against that
 * one — a merchant could press a button labelled with their own company and pull
 * somebody else's Stripe account into somebody else's books. Nothing on screen would
 * have said so; the run would simply have reported figures they did not recognise.
 *
 * The session is the right source because it is the only thing that knows who is
 * asking. It is sealed (AES-GCM, `lib/session-seal.js`), so the tenant in it cannot be
 * edited by the browser, and the worker checks its own allowlist on top — this is the
 * outer of two gates, not the only one.
 *
 * Returns a described refusal rather than throwing, like every other action here: an
 * unauthenticated caller is an ordinary state, not a fault.
 */
async function tenantOfViewer() {
  const session = await readSession();
  const tenant = session && typeof session.tenant === "string" ? session.tenant.trim() : "";
  if (!tenant) {
    return {
      ok: false,
      kind: "refused",
      code: "unauthenticated",
      message:
        "Sign in before syncing. A sync reads a vendor account and writes into one " +
        "set of books, and which ones comes from who you are signed in as; there is " +
        "no default. Nothing was sent.",
    };
  }
  return { ok: true, tenant };
}

/*
 * WHAT ONE PRESS ASKS FOR IS DECIDED HERE, FROM WHAT IS CONNECTED (30 Oct 2026).
 *
 * This sent `{stripe: true, shopify: true}` on every press. A client whose books are
 * Xero and who has no Stripe (northwind, on staging) got a FAILED run with the engine's
 * "no stripe connection" sentence, and the bank lines and ledger the press was for were
 * never read. Now lib/sync-plan.js plans the run from `GET /connections` and the
 * ledger's last complete window (`GET /ledger/coverage`): a payment platform only when
 * it is connected, and with a ledger connected every bank and card register from the
 * first of last month and the general ledger from its last complete read's first day,
 * both through today. The plan's words travel back with the run so the screen can say
 * what was read.
 */
export async function startSync() {
  const who = await tenantOfViewer();
  if (!who.ok) return who;
  const result = await startPlannedSync({
    tenant: who.tenant,
    today: syncToday(),
    readConnections: () => readConnections(),
    readCoverage: () => ledgerCoverage(),
    requestRun: (body) => requestRun(body),
  });
  if (!result.ok) return { ok: false, ...strip(result) };
  return { ok: true, run: result.run, joined: result.joined, plan: result.plan };
}

/**
 * The window the general ledger was last read over COMPLETELY, from `GET
 * /ledger/coverage` (vert_api/routers/ledger.py coverage): `{ ok, measured, window }`.
 * `ok: false` when it could not be asked, which the plan reads as "don't read the
 * ledger" — reading a guessed, shorter window would leave earlier dates unread.
 * Authenticated like every tenant-scoped read here. Never throws.
 */
async function ledgerCoverage() {
  if (!API_BASE_URL) return { ok: false };
  try {
    const response = await engineFetch(globalThis.fetch, `${API_BASE_URL}/ledger/coverage`, {
      headers: { accept: "application/json", ...((await authHeaders()) || {}) },
      cache: "no-store",
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) return { ok: false, status: response.status };
    const body = await response.json();
    if (!body || typeof body !== "object") return { ok: false };
    const window = body.window && typeof body.window === "object" ? { dateFrom: body.window.dateFrom, dateTo: body.window.dateTo } : null;
    return { ok: true, measured: body.measured === true, window };
  } catch {
    return { ok: false };
  }
}

/**
 * Where a run has got to.
 *
 * Called on a timer by the control while `status === "running"`. Returns the whole
 * snapshot every time rather than a delta: the progress list is a handful of
 * sentences, a delta protocol would need a cursor, and a client that missed one
 * update would silently render a gap in the account of what happened.
 */
export async function pollSync(runId) {
  if (typeof runId !== "string" || !runId.trim()) {
    return {
      ok: false,
      kind: "refused",
      code: "invalid_request",
      message: "No run id to check. Nothing was sent to the worker.",
    };
  }
  const result = await requestRunStatus(runId.trim());
  if (!result.ok) return { ok: false, ...strip(result) };

  const run = result.body;
  // Re-read the books only once the work is over and only if it moved them. A
  // revalidate on every poll would re-render the whole register once a second while
  // the run is still going, which is both wasteful and confusing to read.
  if (run && run.status !== "running" && run.report && run.report.changed) refresh();
  return { ok: true, run };
}

/**
 * The tenant's most recent run, or null.
 *
 * Exists so that reloading the page during a thirty-payout sync reattaches to it
 * instead of showing an idle button beside a register that is quietly changing. A
 * progress display that a refresh can lose is one nobody trusts mid-run.
 */
export async function latestSync() {
  const who = await tenantOfViewer();
  if (!who.ok) return who;
  const result = await requestLatestRun({ tenant: who.tenant });
  if (!result.ok) return { ok: false, ...strip(result) };
  return { ok: true, run: (result.body && result.body.run) || null };
}

/**
 * How fresh the close register is, read from the BOOKS rather than from the worker.
 *
 * THIS IS THE SECOND READING OF THE GAUGE, AND THAT IS THE ONLY REASON IT EXISTS.
 * The worker's report says what a run did; this says what the database now holds. A
 * screen that only ever shows the first is a screen that believes whatever the thing
 * claiming to have changed the books says about it — which is exactly the shape of
 * the defect this app removed when Approve stopped being a React reducer.
 *
 * It goes to `vert_api`, not to the worker: the worker has no tenant-scoped read path
 * and must not grow one, while the API already reads the store under row-level
 * security. `API_BASE_URL` is imported rather than read from `process.env` because
 * lib/engine-source.js is the one module in this app that knows where the API lives,
 * and two places knowing it is how they come to disagree.
 *
 * Returns `{ ok: true, register }` or `{ ok: false, ... }`. Never throws, and a
 * failure here is deliberately quiet at the call site — a missing "last updated" line
 * is a smaller problem than an error card about a line nobody asked for.
 *
 * THE CREDENTIAL IS SENT, AND FOR A WHILE IT WAS NOT.
 * ------------------------------------------------------------------
 * FOUND IN A BROWSER, SIGNED IN AS A LIVE TENANT, 2026-08-23. This fetch carried only
 * an `accept` header. `/sync/status` is tenant-scoped — the tenant comes from the key
 * and there is no default — so it answered **401 on every call, for every tenant,
 * always**, and the register's freshness line has never once been drawn on an
 * authenticated deployment.
 *
 * It was known and written down, in the wrong place and as a fact rather than a bug:
 * `lib/connections.js registerSummary` says of ITSELF "THE CREDENTIAL IS SENT, and
 * that is the difference from the other caller — `registerFreshness` in
 * components/sync/actions.js fetches this route with no Authorization header;
 * `/sync/status` is tenant-scoped and answers 401 without one." A note describing a
 * sibling's permanent failure is a bug report, and it sat next to the working copy of
 * the same read.
 *
 * AND THE QUIETNESS ABOVE IS WHY NOBODY NOTICED. A failure here is deliberately silent
 * at the call site, which is the right call for an occasional outage and the reason a
 * total one went unseen: the line was simply never there, on every deployment, and
 * absence looks the same as "this build has no register behind it".
 *
 * `authHeaders()` is the same helper every other authenticated read in this app uses
 * (lib/actions.js, lib/connections.js). It returns null when nobody is signed in, and
 * the route then answers 401 — which is the correct outcome for a signed-out viewer
 * and is not what this fixes.
 */
export async function registerFreshness() {
  if (!API_BASE_URL) {
    return {
      ok: false,
      kind: "unavailable",
      code: "no_api_configured",
      message: "This build reads a saved export and has no register behind it.",
    };
  }
  try {
    const response = await engineFetch(globalThis.fetch, `${API_BASE_URL}/sync/status`, {
      headers: { accept: "application/json", ...((await authHeaders()) || {}) },
      cache: "no-store",
      signal: AbortSignal.timeout(10000),
    });
    if (!response.ok) {
      return { ok: false, kind: "refused", code: `http_${response.status}`, message: "" };
    }
    const body = await response.json();
    return { ok: true, register: body.register };
  } catch {
    return { ok: false, kind: "unreachable", code: "unreachable", message: "" };
  }
}

// A refusal, reduced to what a person reading the screen needs. THE URL IS DROPPED
// HERE ON PURPOSE, even though the transport carries it: lib/actions.js keeps the
// API's base URL on the server so a viewer of the deployed demo learns nothing about
// where it lives, and the worker is the service where that matters most — it is the
// one holding the payment credentials, and an address is the first half of reaching
// it. The message names the remedy without naming the host; the full failure is in
// the server's own log, which is where an operator looks.
function strip(result) {
  return { kind: result.kind, code: result.code, message: result.message };
}


/** The bank accounts on the connected company, for the picker. */
export async function listBankAccountsAction() {
  const who = await tenantOfViewer();
  if (!who.ok) return who;
  const answer = await requestBankAccounts({ tenant: who.tenant });
  if (!answer.ok) {
    // `kind` IS CARRIED, AND IT IS THE ONLY FIELD ADDED HERE. Without it the caller
    // has two very different outcomes in one shape — the worker's own sentence about
    // this tenant, and a transport that never reached the worker — and its only way to
    // tell them apart is to read the English. So the panel printed both the same way,
    // which is how "The sync worker answered HTTP 500 with no error envelope" ended up
    // on a customer's settings page as though it were advice. This module still words
    // no sentence of its own; it says which of the two kinds it is holding.
    return { ok: false, kind: answer.kind, message: answer.message, accounts: [], chosen: null };
  }
  // The worker answers 200 with `ok:false` and a sentence when there is nothing to
  // list — no connection, no credential. That is a state, not a failure, and the
  // screen renders the sentence rather than an error.
  const body = answer.body || {};
  return {
    ok: Boolean(body.ok),
    kind: null,
    message: body.refused || null,
    accounts: Array.isArray(body.accounts) ? body.accounts : [],
    chosen: body.chosen || null,
  };
}

/** Record which account the bank tie reads. */
export async function chooseBankAccountAction(accountId) {
  if (!accountId) {
    return { ok: false, message: "Choose an account before saving." };
  }
  const who = await tenantOfViewer();
  if (!who.ok) return who;
  const answer = await chooseBankAccount(accountId, { tenant: who.tenant });
  // Same distinction as the read above, for the same reason: "the worker refused this
  // account" and "nothing answered" are different sentences and only one of them is
  // worth retrying.
  if (!answer.ok) return { ok: false, kind: answer.kind, message: answer.message };
  const body = answer.body || {};
  return {
    ok: Boolean(body.ok),
    message: body.refused || null,
    accountId: body.accountId || null,
    accountName: body.accountName || null,
    currency: body.currency || null,
  };
}
