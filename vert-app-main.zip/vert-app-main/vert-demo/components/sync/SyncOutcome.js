"use client";

// components/sync/SyncOutcome.js — WHAT A "SYNC NOW" READ, SAID WHERE IT WAS PRESSED
// ==============================================================================
// Month-end's sources line and its popover, and the connected ledger's row on
// Connections, each carry a Sync now. Both used to answer a press with "Sync started."
// whatever happened — which, once the staging worker began running each sync inside the
// request (30 Oct 2026), was said over runs that had already FINISHED, and over runs
// that had failed ("northwind has no stripe connection").
//
// SHORT (staging browser walk 1, 31 Oct 2026, D10). The answer then became the engine's
// log, ~200 words with a raw account id, ISO ranges and "does NOT tie". Now it is
// lib/sync-plan.js syncOutcomeWords: one headline ("Synced 3 bank accounts and the
// general ledger from Xero."), one line per account and the ledger, and the engine's
// own sentences one press down under Details. Nothing here composes a figure.
//
// `useSyncPress` is the one press all three places make (startSync, the Server Action),
// and `SyncPressResult` the one answer they draw under it.

import { useState } from "react";
import { Disclosure, Notice } from "@/components/ui";
import { failureDetails, failureSentence } from "@/components/cards/words";
import { startSync } from "@/components/sync/actions";
import { callSafely } from "@/lib/decisions";
import { syncOutcomeWords } from "@/lib/sync-plan";

export default function SyncOutcome({ result, className = null }) {
  if (!result) return null;
  const words = syncOutcomeWords(result);
  const kind = words.tone === "problem" ? "error" : words.tone === "running" ? "status" : "completion";
  return (
    <div className={className || undefined} data-sync-outcome={words.tone}>
      <Notice kind={kind} recorded={kind === "error" ? "partial" : undefined}>
        {words.text}
      </Notice>
      {words.lines.length ? (
        <ul className="t-footnote sync-read-lines">
          {words.lines.map((line, index) => (
            <li key={index}>{line}</li>
          ))}
        </ul>
      ) : null}
      {words.details && words.details.length ? (
        <div className="sync-read-details" data-sync-details="">
          <Disclosure summary="Details">
            {words.details.map((line, index) => (
              <p key={index} className="t-footnote">
                {line}
              </p>
            ))}
          </Disclosure>
        </div>
      ) : null}
    </div>
  );
}

/** The one Sync now press: `{ state: idle|busy|done|failed, outcome, failure, press }`. */
export function useSyncPress() {
  const [state, setState] = useState("idle");
  const [failure, setFailure] = useState(null);
  const [outcome, setOutcome] = useState(null);
  async function press() {
    setState("busy");
    const result = await callSafely(startSync);
    setFailure(result.ok ? null : result);
    setOutcome(result.ok ? result : null);
    setState(result.ok ? "done" : "failed");
  }
  return { state, outcome, failure, press };
}

/** What the press came back with: the outcome, or the failure in words. */
export function SyncPressResult({ sync, className = null }) {
  if (sync.state === "done") return <SyncOutcome result={sync.outcome} className={className} />;
  if (sync.state === "failed") {
    return (
      <Notice kind="error" recorded="nothing" details={failureDetails(sync.failure)}>
        {failureSentence(sync.failure, { source: null })}
      </Notice>
    );
  }
  return null;
}
