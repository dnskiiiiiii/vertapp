"use client";

// components/sync/sync-read.js — THE SYNC'S READS, MADE WITH A GET
// ==============================================================================
// Staging walkthrough, 28 Oct 2026 (northwind): opening Connections sent two Server
// Action POSTs before anyone pressed anything. useSync's mount effect read the register's
// freshness (`registerFreshness`) and the tenant's latest run (`latestSync`) by calling
// Server Actions, and a run found still going was polled with a third (`pollSync`). Reads
// on the engine's side, writes on the wire, each riding back with a fresh render of the
// page. The bank-account sheet read its list the same way (`listBankAccountsAction`).
//
// Now each is a GET to app/api/sync, which calls the same functions on the server, so
// the worker's address and token still never reach a browser. Only the press (`startSync`)
// and the bank account's save (`chooseBankAccountAction`) remain Server Actions.
//
// What comes back is the route's body as the action would have answered it. A read that
// never came back is the network sentence (SyncReport adds that nothing was recorded),
// never a guess at an empty register or an idle worker.

// What a person reads when the request never came back.
export const NETWORK_SENTENCE = "Vert couldn't reach the sync just now.";

const lost = () => ({ ok: false, kind: "network", code: "network", message: NETWORK_SENTENCE });

function browserFetch() {
  return typeof window !== "undefined" && typeof window.fetch === "function" ? window.fetch.bind(window) : null;
}

async function ask(query, fetchImpl) {
  const doFetch = fetchImpl || browserFetch();
  if (!doFetch) return lost();
  try {
    const response = await doFetch(`/api/sync?${query}`, {
      method: "GET",
      headers: { accept: "application/json" },
      cache: "no-store",
      credentials: "same-origin",
    });
    const body = response && typeof response.json === "function" ? await response.json().catch(() => null) : null;
    return body && typeof body === "object" && typeof body.ok === "boolean" ? body : lost();
  } catch {
    return lost();
  }
}

/** `{ ok, run }`: the tenant's most recent run, or null (lib: latestSync). Never throws. */
export function readLatestRun(fetchImpl = null) {
  return ask("latest", fetchImpl);
}

/** `{ ok, register }`: how fresh the books are (lib: registerFreshness). Never throws. */
export function readRegisterFreshness(fetchImpl = null) {
  return ask("register", fetchImpl);
}

/** `{ ok, run }`: where one run has got to (lib: pollSync). Never throws. */
export function readRunStatus(runId, fetchImpl = null) {
  return ask(`run=${encodeURIComponent(typeof runId === "string" ? runId : "")}`, fetchImpl);
}

/**
 * `{ ok, kind, message, accounts, chosen }`: the ledger's bank accounts for the picker
 * (lib: listBankAccountsAction). A read that never came back is a transport failure the
 * panel offers Retry on (`kind: "unreachable"`), never an empty list.
 */
export async function readBankAccounts(fetchImpl = null) {
  const answer = await ask("accounts", fetchImpl);
  if (answer.kind === "network") return { ok: false, kind: "unreachable", message: NETWORK_SENTENCE, accounts: [], chosen: null };
  return answer;
}
