"use client";

// components/sync/useSync.js — ONE PLACE A SYNC IS STARTED AND WATCHED
// ==============================================================================
// The control and the result live in two different parts of the page — the button
// belongs in the head's action row beside "Open your ledger", the report is a
// paragraph and belongs under the head where a decision notice goes (it read "under
// the tabs" until the tab strip was removed on 2026-08-18; the slot is the same one,
// it simply has nothing above it now). Two components,
// one run. So the state is a hook the screen holds, exactly the way `useDecisions()`
// is held by ReconcileScreen and handed to the bulk bar and the row at once.
//
// WHY IT POLLS INSTEAD OF AWAITING
//
// A real month is thirty settlements and several vendor round trips, so `POST /runs`
// answers immediately with a run id and the work continues on the worker. This asks
// "where has it got to" once a second and the report renders the sentences as they
// arrive. A sixty-second spinner with no output is not acceptable for the primary
// action in the product, and the alternative — one awaited Server Action — is that
// spinner plus a request that times out somewhere in the middle of a close.
//
// The timer is deliberately dumb: a fixed interval, cleared on completion and on
// unmount. No backoff, no websocket, no streaming. A run is tens of seconds and a
// poll is one small JSON body; every extra mechanism is another way for what is on
// screen to disagree with what the worker is doing.
//
// WHY A RELOAD DOES NOT LOSE THE RUN
//
// `latestSync()` on mount reattaches to whatever this tenant already has in flight.
// Progress a refresh can lose is progress nobody trusts mid-run — and reattaching is
// possible only because this hook holds no state the worker does not also hold.
//
// EVERY READ HERE IS A GET, AND ONLY THE PRESS IS A SERVER ACTION (staging walkthrough,
// 28 Oct 2026). The mount read the register and the latest run by calling Server Actions,
// so opening Connections sent two POSTs nobody pressed for, and a run found going was
// polled with a third every second. The reads now go through app/api/sync
// (./sync-read.js); `startSync` is called from `press` alone
// (tests/p0-quiet-page-load.test.js follows every helper an effect calls).
//
// STATIC MODE MAKES NO REQUEST. `useWritesEnabled()` is false on the showpiece and
// the mount effect returns before it calls anything, which is what keeps
// tests/static-mode.test.js's "render with `fetch` removed" honest.

import { safeRefresh } from "@/components/shared/safeRefresh";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { READ_ONLY_REASON, useWritesEnabled } from "@/lib/engine-context";
import { startSync } from "./actions";
import { NETWORK_SENTENCE, readLatestRun, readRegisterFreshness, readRunStatus } from "./sync-read";

// One second: fast enough that the phase sentences read as progress, slow enough
// that a thirty-payout run is thirty requests rather than three hundred.
export const POLL_MS = 1000;

// A WATCH THAT ENDS (Vercel CPU, 4 Nov 2026). Every second for the first POLL_FAST_READS
// reads, then every POLL_SLOW_MS, and none at all after POLL_MAX_READS (about ten minutes;
// staging's slowest run in a week took 88 s), so a run the worker never finishes cannot
// keep an open tab asking forever. A hidden tab asks nothing; the read after it comes back
// says where the run got to.
export const POLL_FAST_READS = 30;
export const POLL_SLOW_MS = 5000;
export const POLL_MAX_READS = 150;

/** The wait before poll number `n` (0-based), or null when the watch is over. Pure. */
export function pollDelay(n) {
  if (!Number.isInteger(n) || n < 0 || n >= POLL_MAX_READS) return null;
  return n < POLL_FAST_READS ? POLL_MS : POLL_SLOW_MS;
}

// What a person reads when the request never came back (./sync-read.js). SyncReport adds
// that nothing was recorded and offers Retry; pressing again is safe, because a sync
// brings in only what is not already here.
export { NETWORK_SENTENCE };

export default function useSync() {
  const router = useRouter();
  const writesEnabled = useWritesEnabled();

  const [run, setRun] = useState(null);
  const [refusal, setRefusal] = useState(null);
  const [starting, setStarting] = useState(false);
  // The press's plan in words ("Reading every bank and card account in Xero from …"),
  // from startSync, for the report to say what this run reads.
  const [asked, setAsked] = useState(null);
  // What the BOOKS say, as distinct from what the worker says it did. Read once on
  // mount and again when a run ends, so the effect of a press is legible as a
  // difference between two readings of the same gauge — taken from the database
  // rather than from the process claiming to have changed it.
  const [register, setRegister] = useState(null);
  const timer = useRef(null);
  // Every await below can resolve after a navigation. Setting state on an unmounted
  // tree is how a "still running" panel reappears on a screen the reader has left.
  const alive = useRef(true);

  const readRegister = useCallback(async () => {
    const result = await readRegisterFreshness();
    if (!alive.current) return;
    // Quiet on failure. A missing "last updated" line is a smaller problem than an
    // error card about a line nobody asked for — and the sync's own refusals, which
    // somebody IS waiting on, are reported loudly a few lines down.
    setRegister(result.ok ? result.register : null);
  }, []);

  const stopPolling = useCallback(() => {
    if (timer.current) {
      clearTimeout(timer.current);
      timer.current = null;
    }
  }, []);

  // One place decides what a poll result means, so the mount path and the press path
  // cannot interpret the same body two different ways.
  const absorb = useCallback(
    (result) => {
      if (!alive.current) return;
      if (!result.ok) {
        setRefusal(result);
        stopPolling();
        return;
      }
      setRefusal(null);
      setRun(result.run);
      if (!result.run || result.run.status !== "running") {
        stopPolling();
        readRegister();
        // The books have moved. Re-run the server components so the register, the
        // KPI strip and the sidebar badge come back saying what the DATABASE says
        // rather than what this browser hoped. Same discipline as lib/decisions.js.
        if (result.run && result.run.report && result.run.report.changed) safeRefresh(router);
      }
    },
    [readRegister, router, stopPolling]
  );

  const watch = useCallback(
    (runId) => {
      stopPolling();
      let n = 0;
      const next = () => {
        const wait = pollDelay(n);
        if (wait === null) {
          timer.current = null;
          return;
        }
        timer.current = setTimeout(tick, wait);
      };
      const tick = async () => {
        if (typeof document !== "undefined" && document.visibilityState !== "visible") {
          next();
          return;
        }
        n += 1;
        const mine = timer.current;
        let result;
        try {
          result = await readRunStatus(runId);
        } catch {
          // The same rule while polling: a lost connection stops the watch and says so.
          result = { ok: false, kind: "network", code: "network", message: NETWORK_SENTENCE };
        }
        absorb(result);
        // absorb stops the watch when the run is over (or the read refused); otherwise,
        // and unless another watch replaced this one, the next read is scheduled.
        if (timer.current === mine && timer.current !== null) next();
      };
      next();
    },
    [absorb, stopPolling]
  );

  useEffect(() => {
    alive.current = true;
    if (!writesEnabled) return undefined;
    let cancelled = false;
    readRegister();
    (async () => {
      const result = await readLatestRun();
      if (cancelled || !alive.current) return;
      // A refusal on MOUNT is not shown. Nobody asked for anything yet, and an
      // unconfigured worker is a fact about the deployment rather than a finding
      // about this close — it belongs on the press, where somebody is waiting.
      if (!result.ok || !result.run) return;
      setRun(result.run);
      if (result.run.status === "running") watch(result.run.runId);
    })();
    return () => {
      cancelled = true;
      alive.current = false;
      stopPolling();
    };
  }, [readRegister, stopPolling, watch, writesEnabled]);

  const press = useCallback(async () => {
    if (!writesEnabled) {
      // Not thrown and not silent. The control is disabled in this build, so getting
      // here means one slipped through; say the sentence the disabled control
      // carries rather than doing nothing.
      setRefusal({ kind: "unavailable", code: "no_api_configured", message: READ_ONLY_REASON });
      return;
    }
    setStarting(true);
    setRefusal(null);
    // The last run's report is put away while this one is out, so the waiting card is
    // not read as this press's answer.
    setRun(null);
    stopPolling();
    try {
      const result = await startSync();
      if (!alive.current) return;
      if (!result.ok) {
        setRefusal(result);
        return;
      }
      setAsked(result.plan && typeof result.plan.asked === "string" ? result.plan.asked : null);
      setRun(result.run);
      // A second press while a run is in flight comes back JOINED to the first run,
      // carrying its id — so this simply starts watching the run already going. No
      // second set of vendor calls was made and no second row can be written.
      if (result.run.status === "running") watch(result.run.runId);
      else absorb({ ok: true, run: result.run });
    } catch {
      // A FAILED SYNC IS NEVER SILENT (UI-011). The server action itself can fail — the
      // network drops, the deployment restarts mid-request — and this used to be a
      // try/finally with no catch: the label reverted and nothing said a thing, so a
      // failure read as a success. It is a refusal like any other now, in the refusal
      // slot, with Retry beside it (SyncReport).
      if (alive.current) setRefusal({ kind: "network", code: "network", message: NETWORK_SENTENCE });
    } finally {
      if (alive.current) setStarting(false);
    }
  }, [absorb, stopPolling, watch, writesEnabled]);

  return {
    run,
    refusal,
    press,
    // `{ payouts, lastUpdatedAt, byState, bySource }` from GET /sync/status, or null
    // when this build has no register behind it or the read failed.
    register,
    // True from the moment of the press until the run stops, so the button reads
    // "Syncing…" for the whole of it and not only while the POST is open.
    busy: starting || Boolean(run && run.status === "running"),
    // The press is out and nothing has come back yet: the staging worker runs the sync
    // inside the request, so this can last the whole run (15–30 s for a ledger).
    pending: starting,
    asked,
    enabled: writesEnabled,
    // The sentence a disabled control carries, or null when there is nothing to
    // explain. A control disabled with no reason is a control that looks broken.
    disabledReason: writesEnabled ? null : READ_ONLY_REASON,
  };
}
