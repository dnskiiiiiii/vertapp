// components/sync/worker-transport.js — THE ONE PLACE THAT KNOWS WHERE THE WORKER IS
// ==============================================================================
// SERVER ONLY. Nothing in this file may ever be imported from a client component,
// and the reason is the second constant below: `VERT_SYNC_TOKEN` is a shared secret
// that lets its holder make a live process spend a customer's Stripe credential. It
// has NO `NEXT_PUBLIC_` prefix, which is what keeps Next from inlining it into the
// browser bundle — but that protection only holds while the module stays out of the
// client graph, so this file is imported by components/sync/actions.js ("use server")
// and by nothing else. tests/sync.test.js asserts the prefix is absent, because a
// well-meaning rename to NEXT_PUBLIC_VERT_SYNC_TOKEN would publish it to every
// viewer with no other symptom.
//
// WHY THIS IS NOT lib/engine-source.js
//
// That module knows where the API is. This one knows where the WORKER is, and they
// are two different services on purpose (see vert_api/routers/sync.py): the API
// answers reads from PostgreSQL and holds no credential; the worker holds the vendor
// credentials and makes the outbound calls. Merging the two configurations here would
// be the first step in merging the two services, and the separation is the point.
//
// SHAPED LIKE postToApi, DELIBERATELY. Every function returns a described outcome and
// never throws — a Server Action that throws reaches the browser as an opaque digest
// and Next's generic error overlay, which is the "silent no-op or generic error toast"
// this whole feature exists to remove. Same `{ ok, kind, code, message }` shape as
// lib/engine-source.js so the screen has one thing to render.

const WORKER_URL = normalise(process.env.VERT_SYNC_WORKER_URL);
const WORKER_TOKEN = (process.env.VERT_SYNC_TOKEN || "").trim();
// WHOSE BOOKS IS NO LONGER A DEPLOYMENT SETTING, AND IT SHOULD NEVER HAVE BEEN ONE.
//
// This used to read VERT_SYNC_TENANT, a single tenant fixed for the whole server, and
// every function below sent it regardless of who was signed in. On a one-customer
// deployment that is invisible. On this one it means a merchant pressing Sync starts a
// run against WHOEVER THE DEPLOYMENT NAMES — reading another company's Stripe account
// into another company's books, from a button labelled with their own name.
//
// The tenant now travels as an argument from the Server Action, which reads it off the
// signed-in session (components/sync/actions.js). The env var is gone rather than kept
// as a fallback: a fallback here is the same bug, waiting for the day somebody forgets
// to pass the argument.
//
// The worker still checks its own allowlist and still scopes every write by the tenant
// it is given, so this is the outer of two gates rather than the only one.

// How long a single call to the worker may take. Generous compared with the API's
// 15s because a poll can land while the process is busy.
export const TIMEOUT_MS = 20000;

// HOW LONG STARTING A RUN MAY TAKE, AND WHY IT IS NOT THE SAME CAP (30 Oct 2026). The
// staging worker runs each sync INSIDE the request (api/sync_staging.py: a serverless
// process is frozen once it answers, so a thread would never finish) and answers
// `POST /runs` when the run is over. A Xero bank-and-ledger run took 15.5 s there, so
// the 20 s cap above would cut a slow day off as "did not answer" while the run went
// on and finished on the worker. The worker's own limit is 300 s, and so is the limit
// of every page this press is made from (app/page.js, app/connections/page.js,
// app/chat/[id]/page.js), so this stays inside both. A worker that answers "running"
// at once (the threaded one) answers well inside it, and the screen polls as before.
export const RUN_TIMEOUT_MS = 280000;

/** Refuse rather than send a run with no tenant on it.
 *
 * A THROW, not a default. Every other refusal in this file is a returned outcome
 * because a Server Action that throws reaches the browser as an opaque digest — but
 * this one is a programming error, not a condition a viewer can be in: the actions
 * read the tenant off the session and cannot call these without one. Defaulting to
 * anything would reintroduce exactly the bug this argument exists to remove.
 */
function requiredTenant(tenant) {
  const named = typeof tenant === "string" ? tenant.trim() : "";
  if (!named) {
    throw new Error(
      "worker-transport: no tenant. Whose books a sync reads is not a deployment " +
        "setting: it comes from the signed-in session. See components/sync/actions.js."
    );
  }
  return named;
}

function normalise(raw) {
  const trimmed = typeof raw === "string" ? raw.trim() : "";
  return trimmed ? trimmed.replace(/\/+$/, "") : null;
}

/** Whether this deployment has a worker at all. Read by the actions, never shipped. */
export const WORKER_CONFIGURED = Boolean(WORKER_URL && WORKER_TOKEN);

// The sentence a viewer sees when the button is pressed on a build with no worker
// behind it. It names the three variables rather than saying "not configured",
// because the person reading it is the person who has to set them — and it does NOT
// name their values.
export const NO_WORKER_REASON =
  "This build has no sync worker behind it. Reading your ledger, bank accounts and payment platforms needs a " +
  "process that holds those credentials, and it is a separate service from the API " +
  "on purpose: the API never dials out. Set VERT_SYNC_WORKER_URL and VERT_SYNC_TOKEN " +
  "on this server and restart it. Nothing was sent.";

function unavailable() {
  return {
    ok: false,
    kind: "unavailable",
    code: "no_worker_configured",
    message: NO_WORKER_REASON,
  };
}

// `fetchImpl` is an argument rather than a closed-over `fetch` for the same reason
// lib/engine-source.js takes one: the test suite drives these functions against
// recorded responses without opening a socket, and a transport that can only be
// exercised through a running worker is a transport nobody exercises.
async function call(path, { method = "GET", body = null, timeout = TIMEOUT_MS, fetchImpl = globalThis.fetch } = {}) {
  if (!WORKER_CONFIGURED) return unavailable();

  const url = `${WORKER_URL}${path}`;
  let response;
  try {
    response = await fetchImpl(url, {
      method,
      headers: {
        accept: "application/json",
        ...(body ? { "content-type": "application/json" } : {}),
        // The credential. Never logged here and never returned to the caller: the
        // outcome objects below carry `url` for a diagnosis and nothing else.
        authorization: `Bearer ${WORKER_TOKEN}`,
      },
      body: body ? JSON.stringify(body) : undefined,
      cache: "no-store",
      signal: AbortSignal.timeout(timeout),
    });
  } catch (cause) {
    // A WAIT THAT RAN OUT IS NOT A WORKER THAT NEVER HEARD. The request reached it, so
    // the run may well finish there; saying "nothing has changed" would be a guess.
    if (cause && cause.name === "TimeoutError") {
      return {
        ok: false,
        kind: "unreachable",
        code: "timeout",
        message:
          `The sync worker didn't answer within ${Math.round(timeout / 1000)} seconds. The sync may still finish ` +
          `on its own; sync again in a minute to see what it read. Pressing again writes nothing twice.`,
        url,
      };
    }
    return {
      ok: false,
      kind: "unreachable",
      code: "unreachable",
      message:
        `The sync worker did not answer (${cause && cause.name ? cause.name : "unknown error"}). ` +
        `Nothing was read and nothing in your books has changed. ` +
        `Start the worker (python -m vert_connect.worker) and try again.`,
      url,
    };
  }

  let payload = null;
  try {
    payload = await response.json();
  } catch {
    payload = null;
  }

  if (response.ok) return { ok: true, status: response.status, body: payload };

  // WHICH OF THE TWO KINDS THIS IS, DECIDED BY WHETHER THE WORKER SPOKE.
  //
  // This used to read `status === 401 || status === 403 ? "refused" : "refused"` — a
  // ternary with one answer, left behind by a distinction that was thought about and
  // then dropped — so EVERY non-2xx was a "refusal", including a 500 from whatever
  // happens to be listening on that address. A refusal is the worker's own sentence
  // about this tenant and belongs on screen; a body-less 500 is not a sentence, and
  // BankAccountPanel's `unreachable` branch (which routes to ServiceUnavailable) never
  // matched it, so "The sync worker answered HTTP 500 with no error envelope" reached a
  // customer's screen in the slot reserved for advice. That exact sentence is what
  // components/shell/ServiceUnavailable.js was written to end, and spec §8 bans a status
  // code in prose outright.
  //
  // An error ENVELOPE is the test, not the status. The worker words its own refusals
  // (`{error: {code, message}}`) whatever code it returns them under; a response with no
  // envelope did not come from something speaking as the worker, which is the same fact
  // "nothing answered" states and gets the same kind. The status is not lost — it is
  // still on `code` as `http_500`, which is a field for a log and never rendered.
  const error = (payload && payload.error) || {};
  const spoke = Boolean(error.message);
  return {
    ok: false,
    kind: spoke ? "refused" : "unreachable",
    code: error.code || `http_${response.status}`,
    message: spoke
      ? error.message
      : `Something answered at the sync worker's address but did not answer as the ` +
        `worker. Nothing was read and nothing in your books has changed.`,
    url,
  };
}

/** Start a run. 202 with a run id, or — if one is already going — that run.
 *
 * `bank` and `ledger` are the worker's own flags (vert_connect/worker.py
 * StartRunRequest), each with the inclusive ISO window it requires and will not default:
 * `startDate`/`endDate` for every bank and card register, `ledgerFrom`/`ledgerTo` for
 * the general ledger. Which ones a press asks for is lib/sync-plan.js's decision; this
 * only carries them, and sends a window only with the flag it belongs to.
 */
export function requestRun({
  tenant,
  stripe = true,
  shopify = true,
  bank = false,
  startDate,
  endDate,
  ledger = false,
  ledgerFrom,
  ledgerTo,
  fetchImpl,
} = {}) {
  if (!WORKER_CONFIGURED) return unavailable();
  const body = { tenant: requiredTenant(tenant), stripe, shopify };
  if (bank) Object.assign(body, { bank: true, startDate, endDate });
  if (ledger) Object.assign(body, { ledger: true, ledgerFrom, ledgerTo });
  body.useAgent = false;
  return call("/runs", { method: "POST", body, timeout: RUN_TIMEOUT_MS, fetchImpl });
}

/** One run's progress and, once it has finished, its report. */
export function requestRunStatus(runId, { fetchImpl } = {}) {
  return call(`/runs/${encodeURIComponent(runId)}`, { fetchImpl });
}

/** The most recent run for this tenant, so a reload can reattach to one in flight. */
export function requestLatestRun({ tenant, fetchImpl } = {}) {
  if (!WORKER_CONFIGURED) return unavailable();
  return call(`/runs?tenant=${encodeURIComponent(requiredTenant(tenant))}`, { fetchImpl });
}

/** The bank accounts on the tenant's connected company, for the picker.
 *
 * A REFUSAL IS AN ORDINARY ANSWER HERE, not an error. "No QuickBooks connection yet"
 * is the state most tenants are in, and a settings screen exists precisely to say so
 * — the worker returns 200 with a sentence and this passes it through unchanged.
 */
export function requestBankAccounts({ tenant, fetchImpl } = {}) {
  if (!WORKER_CONFIGURED) return unavailable();
  return call(`/bank-accounts?tenant=${encodeURIComponent(requiredTenant(tenant))}`, { fetchImpl });
}

/** Record which account the bank tie reads.
 *
 * The id is validated against the LIVE chart by the worker, not here: an account this
 * company does not have produces an empty register, which reads on screen as "no
 * deposits found" — indistinguishable from a merchant who genuinely has none, and
 * wrong in the direction that keeps a real payout blocked forever.
 */
export function chooseBankAccount(accountId, { tenant, fetchImpl } = {}) {
  if (!WORKER_CONFIGURED) return unavailable();
  return call("/bank-account", {
    method: "POST",
    body: { tenant: requiredTenant(tenant), accountId },
    fetchImpl,
  });
}
