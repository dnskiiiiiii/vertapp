"use client";

// components/sync/SyncFreshness.js — WHEN THE BOOKS LAST MOVED, ACCORDING TO THE BOOKS
// ==============================================================================
// One line under the page head: how many settlements are in this tenant's register and
// when one of them was last written. It comes from `GET /sync/status` — the DATABASE
// — and not from the worker's report of what it just did.
//
// That distinction is the whole point of the line existing. The report says "1
// settlement brought in"; this says what the register now holds. A screen that only
// ever showed the first would be believing the process that claims to have changed
// the books, which is the shape of the defect this app removed when Approve stopped
// being a React reducer. Two readings, one gauge, and only one of them is taken from
// the thing doing the changing.
//
// NO ARITHMETIC AND NO CLOCK. It does not say "4 minutes ago": that needs a running
// clock, it re-renders to a different string every minute, and it is a computation
// this layer has no business doing. The stored instant is printed as the store wrote
// it — `utc_now_iso()`, always UTC, always the same shape — sliced into a date and a
// time. A slice is not a calculation.
//
// `.constraint-line` is globals.css's own slot for "a standing fact rather than a
// finding", which is exactly what this is. No new CSS.

// "2026-08-06T02:55:00+00:00" -> "2026-08-06 02:55 UTC".
//
// A hard shape check first, and a passthrough rather than a guess if it does not
// match. The store writes `utc_now_iso()` and nothing else, so this holds — but a
// timestamp reformatted on an assumption that stopped being true is a wrong time
// printed confidently, and the raw string is never wrong.
import { formatDate } from "@/lib/format";

const ISO_UTC = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2}):\d{2}(?:\.\d+)?(?:\+00:00|Z)$/;

export function readableInstant(iso) {
  const match = typeof iso === "string" ? iso.match(ISO_UTC) : null;
  return match ? `${match[1]} ${match[2]} UTC` : iso;
}

function providers(bySource) {
  const names = Object.keys(bySource || {})
    .map((s) => (s === "stripe" ? "Stripe" : s === "shopify_payments" ? "Shopify" : s))
    .sort();
  if (names.length === 0) return "";
  if (names.length === 1) return ` from ${names[0]}`;
  return ` from ${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
}

/** "2026-08-06T02:55:00+00:00" → "6 Aug 2026", the app's one date format (UI-041), or
 *  the raw string when it is not an instant this can read. */
function readableDay(iso) {
  try {
    return formatDate(iso);
  } catch {
    return readableInstant(iso);
  }
}

// IN THE BOOKKEEPER'S WORDS (spec §13.2): payouts, not "settlements in the register";
// the day, not a UTC clock. It names only the sources that actually sent something
// (UI-062), because a line promising Shopify on a client with no Shopify connection
// is a line about a service that isn't there.
export default function SyncFreshness({ register }) {
  if (!register) return null;

  if (register.payouts === 0) {
    return <p className="conn-note sync-freshness">Nothing has been brought in yet. Sync now to start.</p>;
  }

  const count = register.payouts;
  return (
    <p className="conn-note sync-freshness">
      {count} payout{count === 1 ? "" : "s"} brought in
      {providers(register.bySource)}
      {register.lastUpdatedAt ? `, last on ${readableDay(register.lastUpdatedAt)}.` : "."}
    </p>
  );
}
