"use client";

// components/sync/SyncReport.js — WHAT THE SYNC DID, IN SENTENCES
// ==============================================================================
// This component renders the worker's narration and writes no sentence of its own
// about a close. Every line of prose below came from vert_connect/sync.py narrate(),
// which in turn quotes the ENGINE's own `ExceptionItem.detail` /
// `suggested_action` and the VENDOR's own refusal, verbatim. That is not a stylistic
// preference — PRODUCT.md names developer-tooling register ("escalated=
// [gst_undetermined]") as the worst failure this product can make, and the only way
// to be sure the screen never shows it is for the screen to have no vocabulary of
// its own to fall back on. Grep this file for a word about GST or a bank match and
// you will not find one.
//
// THE EXCEPTIONS, AND WHY (30 Oct 2026). A press for a Xero client reads the bank
// registers and the ledger, and the engine's headline counts payment settlements only,
// so it said "Nothing came back from your payment providers" over 141 bank entries and
// a ledger read. lib/sync-plan.js words that headline from the engine's own per-step
// sentences, and words the two states that are not the engine's at all: a press still
// waiting on a worker that answers when the run is over, and a run refused only because
// a platform isn't connected (not a failed sync). The per-account lines stay the engine's.
//
// THE FOUR SECTIONS ARE ALWAYS RENDERED, INCLUDING THE EMPTY ONES. `empty` is a
// sentence, not a blank: "Nothing was left out. Everything the providers reported is
// in the close." is a result a bookkeeper needs stated. A report that silently drops
// its "what was left out" heading looks identical to one that was never asked.
//
// NO NEW CSS. `.card`, `.card-head`, `.card-title`, `.badge`, `.card-pad`,
// `.pnl-sub`, `.exc-steps`, `.verify`, `.constraint-line` and `.spin` are the app's
// existing vocabulary; DESIGN.md and globals.css are deliberate and this surface did
// not need a colour or a component that was not already there.

import { IconSpinner } from "@/components/reconcile/icons";
import { IconBlocked, IconCheck } from "@/components/je/icons";
import { booksHeadline, heldHeadline, notConnectedOnly, readsBooks } from "@/lib/sync-plan";
import { withoutVendorNoise } from "@/lib/raw-ids";

// The pill beside the title. Three states and no fourth: running, finished, refused.
// "Finished" splits on whether the report says anything stopped or was left out —
// green means a human can stop reading, and a close with money held out of it is not
// that.
function statusPill(run, refusal, pending) {
  if (refusal) return { tone: "blocked", label: "Not run" };
  if (pending && !run) return { tone: "info", label: "Running" };
  if (!run) return { tone: "idle", label: "Idle" };
  if (run.status === "running") return { tone: "info", label: "Running" };
  // A run the worker refused only because a platform isn't connected read nothing and
  // broke nothing: it is not a failed sync (30 Oct 2026, northwind has no Stripe).
  if (notConnectedOnly(run)) return { tone: "idle", label: "Nothing to read" };
  if (run.status === "failed") return { tone: "blocked", label: "Failed" };
  if (needsAttention(run)) return { tone: "pending", label: "Finished" };
  return hasWait(run) || quiet(run) ? { tone: "idle", label: "Finished" } : { tone: "ok", label: "Finished" };
}

// A finished run needs a person when the report has any line under the two sections
// that mean "not done": what stopped, and what was left out. Read off the report's
// own structure rather than off a status string, so a new section cannot be added
// upstream and quietly render as clean here.
const ATTENTION_SECTIONS = new Set(["What stopped, and why", "What was left out, and why"]);

function needsAttention(run) {
  const sections = (run && run.report && run.report.sections) || [];
  return sections.some((s) => ATTENTION_SECTIONS.has(s.title) && s.lines.some((line) => !isWait(line)));
}

// A WAIT IS NOT A STOP (staging browser walk 5, W5-2; w19 contract). Stripe publishes its
// tax data some hours behind, and the engine now says so as a wait: "…later payouts wait
// for the next sync", or, with nothing published yet, next step "Nothing to do; sync
// again later." Nothing failed and nothing is for a person to do, so it is drawn plain:
// never the red stopped plate, never the green done one.
export function isWait(line) {
  const text = line && typeof line.text === "string" ? line.text : "";
  const next = line && typeof line.nextStep === "string" ? line.nextStep.trim() : "";
  return /\bwaits? for the next sync\b/i.test(text) || /^Nothing to do; sync again later\.?$/i.test(next);
}

// NOTHING NEW AND NOTHING WRONG IS NEUTRAL (staging browser walk 6). A sync that brought
// nothing in is not a stop and not a piece of work done: plain, like a wait.
function quiet(run) {
  return Boolean(run && run.report && run.report.changed === false);
}

function hasWait(run) {
  const sections = (run && run.report && run.report.sections) || [];
  return sections.some((s) => s.lines.some(isWait));
}

// A Python identifier leading the worker's failure text, e.g. "SystemExit: ",
// "UndefinedTable: ", "psycopg.errors.InsufficientPrivilege: ". The worker no longer
// sends one — it keeps the class name in the operator's log and serves the
// exception's own sentence — but this component renders a string produced by a
// SEPARATE PROCESS, which may be an older build or a different deployment's worker.
// A class name is the one part of that string that means nothing to the person
// reading it, so it is removed here as well as there. Only a leading identifier
// followed by a colon; the vendor's own sentence, including any colon of its own,
// survives byte for byte.
const PY_CLASS = /^(?:[A-Za-z_][\w]*\.)*[A-Z][A-Za-z0-9_]*(?:Error|Exit|Exception|Warning|Table|Privilege|Violation|Failure)?:\s+/;

function withoutTheClassName(error) {
  const text = typeof error === "string" ? error.trim() : "";
  if (!text) return text;
  const stripped = text.replace(PY_CLASS, "");
  // If stripping left nothing, the whole message WAS the identifier; keep the
  // original rather than render an empty failure card.
  return stripped.trim() || text;
}

// A FAILURE IS A SENTENCE AND RETRY (UI-011; spec §11.5). `onRetry` is the same press
// that started the run: a sync brings in only what is not already here, so pressing
// again is always safe, and an error with no next step is a dead end with a message on it.
function RetryButton({ onRetry }) {
  if (!onRetry) return null;
  return (
    <button type="button" className="btn btn-secondary btn-sm sync-retry" onClick={onRetry}>
      Try again
    </button>
  );
}

// `asked` is the press's own plan in words (lib/sync-plan.js: "Reading every bank and card
// account in Xero from 1 Sep 2026 to 30 Oct 2026 and the general ledger from …"), when
// this browser made the press. `pending` is true while the press is waiting on a worker
// that runs the sync inside the request and answers only when it is over.
export default function SyncReport({ run, refusal, onRetry = null, asked = null, pending = false }) {
  if (!run && !refusal && !pending) return null;

  const pill = statusPill(run, refusal, pending);
  const report = run && run.report;
  // "Reading no sources." is the engine's line about payment platforms on a run that
  // asked for none (a ledger client's press): true, and not news, beside the bank and
  // ledger lines that follow it.
  const progress = ((run && run.progress) || []).filter((e) => !(e && e.phase === "reading" && /^Reading no sources\.?$/.test(e.message || "")));
  const running = Boolean(run && run.status === "running");
  const missing = notConnectedOnly(run);
  const books = readsBooks(run);
  const headline = (report && booksHeadline(run)) || (report && report.headline);
  // The red plate's headline names what it is red for (walk 6: "53 settlements are on
  // hold."), and the read and the engine's count follow it.
  const held = report && needsAttention(run) ? heldHeadline(run) : null;
  const plateBody = report ? (
    <div>
      <div className="v-title">{held || withoutVendorNoise(headline)}</div>
      {held ? <div className="v-body">{withoutVendorNoise(headline)}</div> : null}
      {!report.changed && (
        <div className="v-body">
          {books
            ? "No new bank lines came in. Running this again is always safe: it brings in only what is not already here."
            : "Nothing was written. Running this again is always safe: it brings in only what is not already here."}
        </div>
      )}
    </div>
  ) : null;

  return (
    <div className="card sec-card" role="region" aria-label="Sync result">
      <div className="card-head">
        <div className="card-title">
          {running ? (
            <IconSpinner className="spin" aria-hidden="true" />
          ) : pill.tone === "ok" ? (
            <IconCheck aria-hidden="true" />
          ) : pill.tone === "idle" ? null : (
            // A stop icon only for a stop: a wait or a quiet run is not one (walk 6).
            <IconBlocked aria-hidden="true" />
          )}
          Sync
        </div>
        <span className={`badge ${pill.tone}`}>{pill.label}</span>
      </div>

      <div className="card-pad">
        {/* A refusal is the worker's or this server's own sentence — never
            "Something went wrong", which is the message that sends a bookkeeper to a
            developer instead of to a setting. */}
        {refusal && (
          <div className="verify blocked" role="alert">
            <IconBlocked aria-hidden="true" />
            <div>
              <div className="v-title">The sync did not run</div>
              <div className="v-body">{refusal.message} Nothing was recorded.</div>
              <RetryButton onRetry={onRetry} />
            </div>
          </div>
        )}

        {/* While it is going: the sentences as they arrive, newest last, with the
            count when the phase has one. Not a percentage — see SyncEvent's own
            docstring for why a bar would be a number nobody can defend. */}
        {pending && !run && !refusal && (
          <div className="constraint-line" aria-live="polite">
            Reading what&rsquo;s connected: your ledger&rsquo;s bank and card accounts and general
            ledger, and any payment platform. This can take up to half a minute; you can leave
            this page and it keeps going.
          </div>
        )}

        {running && (
          <>
            <ul className="exc-steps" aria-live="polite">
              {progress.map((event, index) => (
                <li key={`${event.phase}-${index}`}>
                  {withoutVendorNoise(event.message)}
                  {event.total > 0 ? ` (${event.done} of ${event.total})` : ""}
                </li>
              ))}
            </ul>
            <div className="constraint-line">
              {asked
                ? `${asked} You can leave this page; it keeps going.`
                : "This reads what's connected and writes what it finds into your books. You can leave this page; it keeps going."}
            </div>
          </>
        )}

        {missing && (
          <div className="verify" role="status">
            <div>
              <div className="v-title">{`${missing} isn't connected, so there was nothing to read from it.`}</div>
              <div className="v-body">
                Nothing was read and nothing in your books changed. Sync again to read what is
                connected.
              </div>
              <RetryButton onRetry={onRetry} />
            </div>
          </div>
        )}

        {run && run.status === "failed" && !missing && (
          <div className="verify blocked" role="alert">
            <IconBlocked aria-hidden="true" />
            <div>
              <div className="v-title">The sync stopped part way</div>
              <div className="v-body">
                {withoutVendorNoise(withoutTheClassName(run.error))}
                {" Whatever had already been brought in is saved: each settlement is " +
                  "written on its own. Pressing the button again picks up what is missing " +
                  "and writes nothing twice."}
              </div>
              <RetryButton onRetry={onRetry} />
            </div>
          </div>
        )}

        {report && (
          <>
            {/* One plate per state, each spelled out: stopped (red), a wait (plain, W5-2),
                nothing new (plain, walk 6), or done (green). */}
            {needsAttention(run) ? (
              <div className="verify blocked" role="status">
                <IconBlocked aria-hidden="true" />
                {plateBody}
              </div>
            ) : hasWait(run) ? (
              <div className="verify" role="status" data-sync-wait="">
                {plateBody}
              </div>
            ) : quiet(run) ? (
              <div className="verify" role="status" data-sync-quiet="">
                {plateBody}
              </div>
            ) : (
              <div className="verify ok" role="status">
                <IconCheck aria-hidden="true" />
                {plateBody}
              </div>
            )}

            {report.sections.map((section) => (
              <div key={section.title}>
                {/* The app's existing 24px-margin hairline, rather than a margin of
                    this component's own. Four headed sections run together
                    otherwise, and a rule is what globals.css already uses to
                    separate stacked sections inside one panel. */}
                <div className="pnl-rule" />
                <h3 className="pnl-sub">{section.title}</h3>
                {section.lines.length === 0 ? (
                  <div className="constraint-line">{section.empty}</div>
                ) : (
                  <ul className="exc-steps">
                    {section.lines.map((line, index) => (
                      <li key={`${section.title}-${index}`} data-sync-wait={isWait(line) ? "" : undefined}>
                        {/* The engine's prose, without its raw ids (walk 4, W4-9) or a
                            vendor's URL, request id or JSON body (walk 5, W5-2). */}
                        {withoutVendorNoise(line.text)}
                        {line.nextStep ? (
                          // The engine's own suggested action, kept visually
                          // subordinate to the finding it belongs to. Muted and on
                          // its own line: it is what to DO, not another thing that
                          // happened.
                          <div className="src">{withoutVendorNoise(line.nextStep)}</div>
                        ) : null}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
