"use client";

// components/chat/ConversationHeader.js — WHERE AM I, WHAT IS THIS FOR, HOW IS IT GOING
// ==============================================================================
// Spec §3.3. "‹ September" back to Month-end; the conversation's title and subtitle
// (a `task_started` retitles it, so a typed request becomes the task it asked for);
// the status in one of the four words; and the context chip. There is no bubble in
// your voice for anything you did not type: the title says what the conversation is
// for.
//
// The title and subtitle are template text, which names the ledger only as `{{ledger}}`
// (build plan §2.2); they go through `withLedger` like every other event string, or the
// header printed the placeholder itself: "July 2026 entries ready for {{ledger}}"
// (eval C6, 30 Sep).
//
// "Run again" is the one extra control, and only on a finished task (spec §4.1): done,
// waiting after a run, or a result the engine reads as stale (offersRunAgain).
//
// THE FILE COUNT (build plan §19.8 F-FILES). When the conversation holds files — sent
// with a message, uploaded into a question, or shown by a result — the header says how
// many ("2 files"), and pressing it opens the data and sources panel, where they are
// listed. No files, no count: never "0 files", which would read as a list somebody
// checked.
//
// SOURCES (p1 chat, 23 Oct 2026). The head's "Sources" opens the side panel on the whole
// conversation's data and sources (SourcesPanel.js); each turn's own Open opens it on that
// turn's. The old More popover (what Vert can see, files, activity) is gone: Activity is
// not data, and the sources and files are the panel's. More is left only for Run again
// where the head is too narrow to show it.

import Link from "next/link";
import { forwardRef, useEffect, useId, useRef, useState } from "react";
import { Button, IconButton, Meta, StatusMark } from "@/components/ui";
import { monthName } from "@/lib/agent/words";
import { offersRunAgain, runAgainLabel, withLedger } from "@/lib/agent/events";
import { fileCountWords, filesOfThread } from "./results/DocumentView";
import { IconCaretLeft, IconMore, IconRows, IconRunAgain, IconSkill } from "@/components/ui/icons";
import OpenSkill from "@/components/skills/OpenSkill";

// "EDIT HOW VERT DOES THIS" (founders, 22 Oct 2026). A task's procedure is customised
// from the task, as in Ramp: a run's head opens its skill (SkillSheet) in one press. It
// is drawn on a conversation with a skill and a signed-in viewer (only a live service
// can read or save one; `canEditSkill`). START sits where Run again would on a task made
// with Create (`thread.held`): it has not run, so there is nothing to run again.
//
// DESIGN-FIX-2 (10 Oct 2026; DA2-038, DA2-058, DA2-011, DA2-031). The head runs the full
// width of the conversation with a 1.5rem inset: the way back and the title (with its
// status) on the left, the tools on the right. It sits OVER the thread on the glass bar,
// so the thread scrolls under it and nothing is cut mid-glyph at its edge. The
// "Northwind · July" chip is gone on a desk: the sidebar already says the client and the
// month (spec §7.4). What it opened (the sources, the files, who did what) now opens from
// the head's one More button as an anchored popover, not a full-height sheet with a card
// inside it. "Run again" is a quiet button with its icon; in a narrow head it moves into
// that popover. While Vert can't be reached, the head says so in a quiet Meta line.

/**
 * WHERE FOCUS GOES WHEN THE MORE POPOVER OPENS (verify passes 1-4, U36): its first
 * control, else the popover itself. At 1440 and 1024 Run again sits in the head, so the
 * popover held only words (what Vert can see, files, activity) and nothing matched the
 * control query: focus stayed on More, four passes running. The popover is
 * `tabIndex={-1}` so it can always take focus. Pure over the element, for the tests.
 */
export function focusTargetIn(panel) {
  if (!panel || typeof panel.querySelector !== "function") return null;
  // THE FIRST CONTROL THAT CAN TAKE FOCUS (verify pass 5, U36): the first match was often
  // inside a closed disclosure (display: none), where focus() does nothing, so focus
  // stayed on More at 1440 and 1024 though the code "moved" it. A control that draws no
  // box is skipped; with none, the popover itself.
  const query = "button:not([disabled]), a[href], [tabindex]:not([tabindex='-1'])";
  const all = typeof panel.querySelectorAll === "function" ? [...panel.querySelectorAll(query)] : [panel.querySelector(query)].filter(Boolean);
  const shown = all.find((el) => !el.closest || !el.closest("[hidden], details:not([open]) > :not(summary)")) || null;
  const drawn = shown && typeof shown.getClientRects === "function" && shown.getClientRects().length === 0 ? all.find((el) => typeof el.getClientRects !== "function" || el.getClientRects().length > 0) || null : shown;
  return drawn || panel;
}

/** Focus `target`, and the popover itself if the browser would not take it there. */
export function focusInside(target, panel) {
  if (!target) return;
  target.focus();
  if (panel && typeof document !== "undefined" && document.activeElement !== target && typeof panel.focus === "function") panel.focus();
}

/**
 * The More popover: Run again where the head is too narrow to show it,
 * anchored under the DotsThree button, top-right origin, on the snappy spring. Esc,
 * a press outside, or Tab out of it closes it and returns focus to the button.
 */
function MorePopover({ title, context, runAgain, runAgainWords, runAgainDisabledReason, open, setOpen }) {
  const popId = useId();
  const reasonId = useId();
  const root = useRef(null);
  const toggle = useRef(null);
  const panel = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    focusInside(focusTargetIn(panel.current), panel.current);
    function onKey(event) {
      if (event.key === "Escape") {
        event.stopPropagation();
        setOpen(false);
        if (toggle.current) toggle.current.focus();
      }
    }
    function onPointer(event) {
      if (root.current && !root.current.contains(event.target)) setOpen(false);
    }
    function onFocusOut(event) {
      if (root.current && event.relatedTarget && !root.current.contains(event.relatedTarget)) setOpen(false);
    }
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onPointer);
    const node = root.current;
    if (node) node.addEventListener("focusout", onFocusOut);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onPointer);
      if (node) node.removeEventListener("focusout", onFocusOut);
    };
  }, [open, setOpen]);

  return (
    <div className="chat-head-more" ref={root}>
      <IconButton
        ref={toggle}
        label="More"
        className="chat-more-btn"
        data-tip="More"
        aria-haspopup="dialog"
        aria-expanded={open ? "true" : "false"}
        aria-controls={popId}
        onClick={() => setOpen((was) => !was)}
      >
        <IconMore size={16} />
      </IconButton>
      <div className="popover chat-more-menu chat-context-pop" id={popId} role="dialog" aria-label={title || "This conversation"} ref={panel} tabIndex={-1} hidden={!open} data-open={open ? "true" : "false"}>
        {runAgain ? (
          <div className="chat-pop-actions">
            <Button
              variant="quiet"
              size="sm"
              icon={<IconRunAgain size={14} />}
              disabled={Boolean(runAgainDisabledReason)}
              aria-describedby={runAgainDisabledReason ? reasonId : undefined}
              onClick={
                runAgainDisabledReason
                  ? undefined
                  : () => {
                      setOpen(false);
                      runAgain();
                    }
              }
              data-run-again=""
            >
              {runAgainWords || "Run again"}
            </Button>
            {runAgainDisabledReason ? (
              <span className="chat-more-item-note" id={reasonId}>
                {runAgainDisabledReason}
              </span>
            ) : null}
          </div>
        ) : null}
        {open ? context : null}
      </div>
    </div>
  );
}

/** How much taller than its base the head is drawn (px, never negative). Pure. */
export function headExtra(height, base) {
  const h = Number(height);
  const b = Number(base);
  if (!Number.isFinite(h) || !Number.isFinite(b)) return 0;
  return Math.max(0, Math.round(h - b));
}

const ConversationHeader = forwardRef(function ConversationHeader(
  { thread, clientName, ledgerName = null, onOpenSources = null, sourcesOpen = false, onRunAgain, runAgainDisabledReason = null, offline = false, canEditSkill = false, onStartHeld = null, startingHeld = false, startHeldFailure = null },
  _ref
) {
  const subtitleId = useId();
  const month = monthName(thread.period);
  const where = [clientName, month].filter(Boolean).join(" · ");
  // One line, ellipsized in a narrow rail (app/styles/chat.css), so the whole title is
  // also the element's `title`: the cut text is never the only way to read it.
  const title = withLedger(thread.title, ledgerName) || "Conversation";
  const fileCount = fileCountWords(filesOfThread(thread));
  const subtitle = thread.subtitle ? withLedger(thread.subtitle, ledgerName) : null;
  // One rule with the engine's (lib/agent/events.js offersRunAgain): any finished task,
  // done or waiting after a run, and any result the engine reads as stale.
  const canRunAgain = Boolean(offersRunAgain(thread) && typeof onRunAgain === "function");
  // "Run again with Vert's updated steps" beside a question Vert's older steps asked
  // (p1/fix7): running again takes it down and asks what today's steps need.
  const runAgainWords = runAgainLabel(thread);
  const [moreOpen, setMoreOpen] = useState(false);
  const canSources = typeof onOpenSources === "function";
  // THE HEAD GROWS WITH ITS REASON, AND THE THREAD MOVES DOWN WITH IT (verify pass 2,
  // D44): in the rail a three-line "Waiting" reason ran out of the fixed-height head and
  // over "Earlier: 4 answered". The head is at least --chat-head-h tall; whatever its
  // reason adds is published on the conversation as --chat-head-extra, which the thread's
  // top padding, scroll padding and top fade add (app/styles/chat.css).
  const headRef = useRef(null);
  useEffect(() => {
    const el = headRef.current;
    const chat = el && el.closest(".chat");
    if (!el || !chat || typeof ResizeObserver !== "function") return undefined;
    const publish = () => chat.style.setProperty("--chat-head-extra", `${headExtra(el.offsetHeight, parseFloat(window.getComputedStyle(el).minBlockSize))}px`);
    const seen = new ResizeObserver(publish);
    seen.observe(el);
    publish();
    return () => {
      seen.disconnect();
      chat.style.removeProperty("--chat-head-extra");
    };
  }, []);
  return (
    <header className="chat-head" ref={headRef} aria-describedby={subtitle ? subtitleId : undefined}>
      <div className="chat-head-row">
        {/* The way back to the month: a chevron and the month's word ("‹ July" to a
            reader of text), quiet, before the title it leads away from. */}
        <Link href="/" className="chat-back">
          <IconCaretLeft className="chat-back-glyph" size={16} />
          <span className="chat-back-word">{month || "Month-end"}</span>
        </Link>
        <div className="chat-head-titles">
          <h1 className="chat-title" title={title}>{title}</h1>
          {thread.word ? <StatusMark word={thread.word} /> : null}
          {offline ? (
            <Meta className="chat-offline" data-offline="">
              Offline, retrying
            </Meta>
          ) : null}
        </div>
        <div className="chat-head-tools">
          {fileCount && canSources ? (
            <Button variant="quiet" size="sm" className="chat-file-count" data-file-count="" onClick={() => onOpenSources()}>
              {fileCount}
            </Button>
          ) : null}

          {canRunAgain ? (
            <Button variant="quiet" size="sm" icon={<IconRunAgain size={14} />} disabled={Boolean(runAgainDisabledReason)} onClick={runAgainDisabledReason ? undefined : onRunAgain} data-run-again="">
              {runAgainWords}
            </Button>
          ) : null}
        </div>
        {thread.held && thread.taskId && typeof onStartHeld === "function" ? (
          // Not in the tools, which fold into More on a narrow head: Start is the one
          // thing a waiting task asks for, at every width.
          <Button variant="secondary" size="sm" busy={startingHeld} busyLabel="Starting…" onClick={onStartHeld} className="chat-start-held" data-start-held="">
            Start
          </Button>
        ) : null}
        {thread.template && canEditSkill ? (
          // At every width, like Sources: the way to the task's steps is never folded.
          <OpenSkill template={thread.template} title={title} className="btn btn-quiet btn-sm chat-skill-btn">
            <IconSkill size={14} aria-hidden="true" />
            <span className="chat-skill-words">Edit how Vert does this</span>
          </OpenSkill>
        ) : null}
        {canSources ? (
          // THE WHOLE CONVERSATION'S DATA AND SOURCES, at every width (the tools above
          // fold into More on a narrow head; this does not).
          <Button
            variant="quiet"
            size="sm"
            icon={<IconRows size={14} />}
            className="chat-sources-btn"
            aria-haspopup="dialog"
            aria-expanded={sourcesOpen ? "true" : "false"}
            onClick={() => onOpenSources()}
            data-open-all-sources=""
          >
            Sources
          </Button>
        ) : null}
        {canRunAgain ? (
          <MorePopover
            title={where}
            context={null}
            runAgain={onRunAgain}
            runAgainWords={runAgainWords}
            runAgainDisabledReason={runAgainDisabledReason}
            open={moreOpen}
            setOpen={setMoreOpen}
          />
        ) : null}
      </div>
      {/* WHY THE WORD IS WHAT IT IS (bug bash 10 Oct 2026). A conversation that handed
          work to a task that is stuck ends "Waiting" or "Needs you" with the engine's own
          sentence; it is drawn as text under the row, never only a tooltip, so the word
          is never a bare claim. */}
      {thread.word && thread.reason && !thread.reasonSaid ? (
        <p className="chat-head-reason" data-run-reason="" title={withLedger(thread.reason, ledgerName)}>
          {withLedger(thread.reason, ledgerName)}
        </p>
      ) : null}
      {startHeldFailure ? (
        <p className="chat-head-reason" role="alert" data-start-held-failed="">
          {startHeldFailure}
        </p>
      ) : null}
      {/* A RESULT BUILT FROM INPUTS THAT HAVE SINCE CHANGED SAYS SO (p1 e2e, 24 Oct
          2026): the engine's reason, in words, beside Run again. */}
      {thread.stale ? (
        <p className="chat-head-reason" data-stale="">
          Out of date: {thread.stale.reason}. Run again to bring it up to date.
        </p>
      ) : null}
      {subtitle ? (
        <p className="chat-subtitle chat-visually-hidden" id={subtitleId}>
          {subtitle}
        </p>
      ) : null}
    </header>
  );
});

export default ConversationHeader;
