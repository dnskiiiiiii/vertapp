"use client";

// components/chat/results/useUnsavedWarning.js — DON'T LOSE AN EDIT TO A RELOAD
// ==============================================================================
// Design-pass spec §8 (Web Interface Guidelines, forms): "Unsaved edits (JE editor,
// commentary, plan) warn before navigation." While `dirty` is true, leaving the page
// (reload, close, typing a new address) asks the browser's own "Leave site?" question.
// Nothing is said in-app and nothing is saved: the person decides. In-app moves keep the
// pane where it is, so they need no guard. Off the moment the edit is saved or dropped.

import { useContext, useEffect } from "react";

import { SheetOpen } from "@/components/ui/sheet-open";

export default function useUnsavedWarning(dirty) {
  // An edit inside a sheet that was closed was dropped (walk 3, N10): no guard.
  const open = useContext(SheetOpen);
  const guard = Boolean(dirty && open);
  useEffect(() => {
    if (!guard || typeof window === "undefined") return undefined;
    const warn = (event) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [guard]);
}
