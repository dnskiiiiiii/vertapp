"use client";

// components/chat/results/PayoutBreakdown.js — ONE PAYOUT, WORKED
// ==============================================================================
// Where the old Vert AI rail's narration lives now (build plan §3 F2). The words come
// from lib/trace/breakdown.js, which keeps every honesty rule the rail learned on live
// tenants: nothing read is "not read" and never $0.00, a stage that established
// nothing is not ticked, an excess is never called a shortfall, an undrafted entry has
// neither balanced nor failed to.
//
// The payout is looked up in the payload this page already holds (useEngine), so the
// figures are the engine's own, cent for cent. A payout the payload does not carry is
// said to be unavailable in words; nothing is reconstructed from the artifact.

import Link from "next/link";
import { useEngine } from "@/lib/engine-context";
import { buildPayoutRun } from "@/lib/trace/build";
import { breakdownView } from "@/lib/trace/breakdown";
import { transactionLine } from "@/lib/agent/words";
import AccountingFigure from "@/components/shared/AccountingFigure";
import VerdictBand from "./VerdictBand";
import KeyFigures from "./KeyFigures";
import { payoutIdOf } from "./subject";

import { IconCaretRight, IconCheck, IconProblem } from "@/components/ui/icons";
// Design-fix-2 D7: Phosphor marks, never typed glyphs (the tick was "✓").
const GLYPH = { ok: <IconCheck size={12} />, off: <IconProblem size={12} />, none: "–" };

export function BreakdownBody({ run }) {
  const view = breakdownView(run);
  return (
    <>
      <VerdictBand text={view.verdict} ok={view.ok} />
      <p className="chat-result-line">{transactionLine(view.line)}</p>
      <ul className="chat-breakdown-facts">
        {view.facts.map((fact, i) => (
          <li key={i} data-tone={fact.tone}>
            <span className={`chat-tone chat-tone-${fact.tone}`} aria-hidden="true">
              {GLYPH[fact.tone]}
            </span>
            {fact.text}
          </li>
        ))}
      </ul>
      {view.rows.length ? (
        <div className="chat-table-wrap">
        <table className="chat-table">
          <thead>
            <tr>
              <th scope="col">Transactions</th>
              <th scope="col" className="num">Count</th>
              <th scope="col" className="num">Gross</th>
              <th scope="col" className="num">Fees</th>
              <th scope="col" className="num">Net</th>
            </tr>
          </thead>
          <tbody>
            {view.rows.map((row) => (
              <tr key={row.key}>
                <th scope="row">{row.label}</th>
                <td className="num">{row.count}</td>
                <td className="num"><AccountingFigure cents={row.gross} /></td>
                <td className="num"><AccountingFigure cents={row.fee} /></td>
                <td className="num"><AccountingFigure cents={row.net} /></td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      ) : (
        <p className="chat-sheet-note">No transactions have been read for this payout yet.</p>
      )}
      {view.totals ? (
        <dl className="chat-keyfigs chat-keyfigs-wide">
          <div>
            <dt>Transactions total</dt>
            <dd><AccountingFigure cents={view.totals.transactions} /></dd>
          </div>
          <div>
            <dt>Deposit</dt>
            <dd><AccountingFigure cents={view.totals.deposit} /></dd>
          </div>
        </dl>
      ) : null}
      <details className="chat-details">
        <summary>Details</summary>
        <span className="chat-id">{run.id}</span>
      </details>
    </>
  );
}

export default function PayoutBreakdown({ artifact, ledgerName }) {
  const engine = useEngine();
  const id = payoutIdOf(artifact);
  const run = id ? buildPayoutRun(engine, id) : null;
  return (
    <div className="chat-result-body-inner">
      {run ? (
        <BreakdownBody run={run} />
      ) : (
        <>
          <VerdictBand text={artifact.verdict || "This payout's workings aren't available here."} figures={artifact.figures} ledgerName={ledgerName} />
          <KeyFigures figures={artifact.figures} />
        </>
      )}
      <p className="chat-sheet-link">
        <Link href="/records">See all payouts<IconCaretRight className="caret-trailing" /></Link>
      </p>
    </div>
  );
}
