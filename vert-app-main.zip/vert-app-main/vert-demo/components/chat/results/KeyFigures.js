// components/chat/results/KeyFigures.js — THE LABELLED ENGINE FIGURES OF A RESULT
// ==============================================================================
// Key-value pairs grouped by spacing and weight, not hairlines (spec §11.3). Only
// figures the engine labelled are drawn; each opens its source.

import EventFigure from "../EventFigure";
import { labelledFigures } from "../messages/Result";

export default function KeyFigures({ figures, limit = 8 }) {
  const list = labelledFigures(figures, limit);
  if (!list.length) return null;
  return (
    <dl className="chat-keyfigs chat-keyfigs-wide">
      {list.map(({ ref, figure }) => (
        <div key={ref}>
          <dt>{figure.label}</dt>
          <dd>
            <EventFigure figure={figure} figureRef={ref} />
          </dd>
        </div>
      ))}
    </dl>
  );
}
