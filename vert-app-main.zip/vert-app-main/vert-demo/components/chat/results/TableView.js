"use client";

// components/chat/results/TableView.js — ONE TABLE, DRAWN THE WAY THE WORKBOOK WRITES IT
// ==============================================================================
// ONE TABLE, THREE READERS (build plan §4.0.3). Every result in iteration 2 carries
// `artifact.table` (vert_engine/agent_events.py ResultTable): 2–4 summary figures, then
// sheets whose names ARE the workbook's tab names. The engine builds the workbook from
// that table (`result_book`), and this draws the same table, every cell through
// lib/format.js `formatAccounting`, so the pane and the xlsx cannot disagree about a
// figure. Each drawn cell carries `data-col` (its column key) and each row
// `data-row` (its index), so the pane-vs-workbook check can compare cell by cell.
//
// WHAT IS ON SCREEN, top to bottom (§4.4 FP 1; visual spec §5):
//   · the verdict, one line;
//   · the summary figures, each the engine's own figure with its source;
//   · the sheet tabs, named exactly as the workbook's tabs, in the same order;
//   · the selected sheet as a grid: header row on the inset fill, numbers right-aligned
//     in tabular figures, subtotal and total rows bold, a Source column naming each
//     figure row's record — or, for an unmeasured row, what is missing, in words.
//
// NOT THE ACCENT. A tab chooses what to read; it writes nothing, so the selected tab is
// marked in ink, never filled purple (§4.0.9).
//
// A CELL ITS COLUMN CANNOT HOLD is not drawn as a guess. `formatAccounting` refuses a
// float in a money column; the cell then says "not shown" and the defect is logged,
// rather than the whole pane failing or a rounded number appearing as the engine's.
//
// A HIGHLIGHTED ROW is the one a figure in the chat pointed at (lib/agent/pane.js
// `locateFigure`): its sheet is selected, the row is tinted and scrolled into view, and
// it is marked `aria-current` so a screen reader hears which line was meant.
//
// IN-PANE EDITING (§19.10 F-EDIT, CellEditor.js). On a live build, a result whose
// artifact lists `editable` cells draws each listed row's value cell as an input, and a
// bar under the grid carries Discard and the one purple, "Save changes · Download". No
// other cell becomes an input: formula cells are never listed, and a cell the engine
// did not list is drawn as text. A row Vert added to someone's workbook (`row.added`) is
// tinted as the file tints it, with a legend in words.
//
// A WORKBOOK VERT GENERATED lists no cells, so its pane offers "Edit cells" instead
// (eval r2 #7): the engine reads the workbook's input cells, the pane swaps to them
// (one row per cell, the value an input, the same save bar), and "Done" swaps back.

import { entriesPaneSheets, ENTRIES_SHEET } from "../answer/shape";
import { PaneEntries } from "../answer/ShapeBlocks";
import { useEffect, useId, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button } from "@/components/ui/Button";
import { IconCaretRight, IconWarning } from "@/components/ui/icons";
import { sheetLabel } from "./analysis-views";
import { formatAccounting, formatMoney } from "@/lib/format";
import { withoutRawIds } from "@/lib/raw-ids";
import { opensOnOf, sheetNamed } from "@/lib/agent/pane";
import { isReadFigure } from "@/lib/agent/figure-source";
import { useMoreToTheRight, useStripEdges } from "./useMoreToTheRight";
import BoundText from "../BoundText";
import EventFigure from "../EventFigure";
import useUnsavedWarning from "./useUnsavedWarning";
import CellEditor, { AddedRowsLegend, EditCellsBar, InputsGrid, InputsHead, SaveBar, VALUE_COLUMN, editableRows, hasAddedRows, inputsArtifact, pendingEdits, useCanEdit, useCanOpenInputs, useInputCells, useWorkbookEdits } from "./CellEditor";

const NUMERIC = new Set(["money", "percent", "count"]);

/** A cell as the workbook writes it, or null when its column cannot hold the value. */
export function cellText(value, kind) {
  try {
    return formatAccounting(value === undefined ? null : value, { kind });
  } catch (error) {
    if (typeof console !== "undefined" && typeof console.warn === "function") {
      console.warn(`[vert] a ${kind} cell was not drawn: ${error && error.message}`);
    }
    return null;
  }
}

/**
 * A CELL IN A CARD IN THE CONVERSATION (verify pass 2, S-UI-11). The bank-rec question
 * said "overdrawn by −$387,463.90" and the table under it said "($387,463.90)": one
 * balance, two signs, on one card. A card sits among sentences, and a sentence writes a
 * negative with the minus sign, so a card's table does too. The pane keeps `cellText`
 * (the workbook's brackets, cell for cell, held by the cell-equality check) and says
 * that convention once in its own foot. Everything but money is `cellText`. Pure.
 */
export function screenCellText(value, kind) {
  if (value === null || value === undefined || !Number.isInteger(value)) return cellText(value, kind);
  if (kind === "money") return formatMoney(value);
  // A NEGATIVE PERCENTAGE TOO (verify pass 8, S-BK-3): the flux row read "−$2,966.67
  // (98.9%)", the money in the minus and its share in the workbook's brackets.
  if (kind === "percent" && value < 0) return `−${cellText(-value, kind)}`;
  return cellText(value, kind);
}

// THE FILE'S RULES FOR AN EMPTY CELL, held equal to the workbook writer
// (vert_engine/workpapers/style.py, and result_book `_row_texts_from_table`, the twin the
// cell-equality check reads). The pane once sent every empty cell through
// `formatAccounting`, which knows only the column: a section header's empty percent
// became "N/A", and an unmeasured account's balances became blank — where the file
// says "not measured" (eval PR6, round 2). A blank asserts nothing; "N/A" asserts a
// change on a zero base; "not measured" says a figure was looked for and not read.
// Those are three different claims, so the row decides which, exactly as the file does:
//
//   · a cell a row does not carry at all, or any empty cell of a non-figure row
//     (a header, a subtotal, a note): blank — nothing is claimed there;
//   · an empty number cell of a figure row the engine marked `missing`: "Not worked out
//     yet", its reason said once in the row's Source column;
//   · anything else: `formatAccounting` (so a measured row's empty percent is "N/A").
const UNMEASURED_KINDS = new Set(["money", "count", "percent"]);
// "not measured" was the engine's word; a bookkeeper reads "Not worked out yet", and
// the reason follows as one sentence (bug bash 10 Oct 2026).
export const NOT_MEASURED = "Not worked out yet";

/**
 * The engine's reason for a figure it did not work out, as the end of one plain
 * sentence, or null when it gives none. A reason that only repeats the engine's own
 * label ("not read yet", "not measured") is no reason: printed after "Not worked out
 * yet" it read "Not measured: not read yet", two internal words and nothing learned.
 */
export function missingReason(missing) {
  const text = typeof missing === "string" ? missing.trim().replace(/\.+$/, "") : "";
  if (!text || /^not (?:read|measured)(?: yet)?$/i.test(text)) return null;
  return `${text.charAt(0).toUpperCase()}${text.slice(1)}.`;
}

function isUnmeasured(row) {
  return Boolean(row && row.role === "figure" && row.missing !== null && row.missing !== undefined);
}

/**
 * One body cell's text as the workbook writes it, or null when its column cannot hold
 * the value. `{ text, unmeasured }`: `unmeasured` marks the words "Not worked out yet", which
 * are drawn as a note rather than as a figure.
 */
export function rowCellText(row, column, { screen = false } = {}) {
  const cells = row && row.cells && typeof row.cells === "object" ? row.cells : {};
  const present = Object.prototype.hasOwnProperty.call(cells, column.key);
  const value = present ? cells[column.key] : null;
  if ((value === null || value === undefined) && (!row || row.role !== "figure" || !present)) return { text: "", unmeasured: false };
  if ((value === null || value === undefined) && isUnmeasured(row) && UNMEASURED_KINDS.has(column.kind)) return { text: NOT_MEASURED, unmeasured: true };
  const text = (screen ? screenCellText : cellText)(value, column.kind);
  if (text === null) return null;
  // On screen, an engine's words carry no raw id ("Posted as journal 5179f49e-…", walk 5).
  return { text: screen ? withoutRawIds(text) : text, unmeasured: false };
}

/**
 * A total cell as the workbook writes it. A money or count total over a column in
 * which any figure row was not measured is not a total of that column, and the file
 * says so in words rather than showing a sum of the rows it could read.
 */
export function totalCellText(sheet, column, { screen = false } = {}) {
  const totals = sheet && sheet.totals && typeof sheet.totals === "object" ? sheet.totals : {};
  const value = Object.prototype.hasOwnProperty.call(totals, column.key) ? totals[column.key] : null;
  if ((column.kind === "money" || column.kind === "count") && Number.isInteger(value)) {
    const figures = (Array.isArray(sheet.rows) ? sheet.rows : []).filter((r) => r && r.role === "figure");
    const missing = figures.filter((r) => isUnmeasured(r) && (r.cells || {})[column.key] == null);
    if (missing.length) return { text: `No total yet: ${missing.length} of ${figures.length} amounts in this column aren't worked out yet`, unmeasured: true };
    if (!figures.length) return { text: "no rows to total", unmeasured: true };
  }
  if (value === null || value === undefined) return { text: "", unmeasured: false };
  const text = (screen ? screenCellText : cellText)(value, column.kind);
  return text === null ? null : { text, unmeasured: false };
}

/**
 * The Source column's words for a row, as the file writes them.
 *
 * A WORKED-OUT ROW SAYS WHERE IT IS WORKED OUT (verify pass 3, Q17). The workbook writes
 * "Worked out on the Reconciliation tab" in the Source cell of a subtotal that names no
 * record (vert_engine style.worked_sources); the pane drew it blank. The engine's
 * sentence rides on the row as `workedSource` and is drawn as it came. With none, the
 * cell stays blank rather than guessing which tab a formula reads.
 */
export function sourceText(row) {
  if (row && row.source && row.source.label) return row.source.label;
  // A worked-out row may carry a `source` with no label (a derived total: kind, id and
  // inputs, verify pass 5 Q17: "Reconciling items" and "Difference" drew a blank Source
  // beside the file's "Worked out on the Reconciliation tab"); its sentence still stands.
  if (row && (!row.source || !row.source.label) && typeof row.workedSource === "string" && row.workedSource.trim()) return row.workedSource.trim();
  if (isUnmeasured(row)) {
    const why = missingReason(row.missing);
    return why ? `${NOT_MEASURED}: ${why}` : `${NOT_MEASURED}.`;
  }
  return "";
}

// The workbook writes a Source column on any sheet with a figure row.
function hasSourceColumn(sheet) {
  return (sheet.rows || []).some((r) => r && r.role === "figure");
}

// Account codes, assets and vendor or bank names are proper names: a translating
// browser must leave them alone (WIG G20).
const NO_TRANSLATE_COLUMN = /^(account|account_name|asset|vendor|payee|customer|counterparty|bank|source_account)$/i;

/** Whether `column` is a sheet's machine Id column (hidden in the workbook). Pure. */
export function isIdColumn(sheet, column) {
  return Boolean(column && column.key === "id" && column.kind === "text" && sheet && typeof sheet.name === "string" && /^sources$/i.test(sheet.name.trim()));
}

// An engine record id ("je:90cdf5de9482", "mj:03bee8959d8ed9a4"): a key for software,
// never words for a person (U63, pass 2: the draft-entry pane's Sources read
// "je:90cdf5de9482"). The pane says what the record is; the id stays on the cell as
// data-engine-id for anyone who needs it.
const ENGINE_ID = /^(je|mj|glrec|po|pp|dr|fa|doc)[:_][0-9a-z]{6,64}$/i;
const ENGINE_ID_WORDS = { je: "A journal entry in Vert", mj: "A journal entry in Vert" };

/** The words for an engine id shown in a text cell, or null when the text is not one. Pure. */
export function engineIdWords(text) {
  const m = typeof text === "string" ? ENGINE_ID.exec(text.trim()) : null;
  if (!m) return null;
  return ENGINE_ID_WORDS[m[1].toLowerCase()] || "A record in Vert";
}

function Cell({ column, shown, header = false, blank = false, focused = false }) {
  const raw = shown ? shown.text : null;
  const idWords = column.kind === "text" ? engineIdWords(raw) : null;
  const text = idWords || raw;
  const className = [NUMERIC.has(column.kind) ? "num" : column.kind === "date" ? "pane-date" : null, text === null ? "pane-cell-invalid" : null, shown && shown.unmeasured ? "pane-missing" : null].filter(Boolean).join(" ") || undefined;
  const Tag = header ? "th" : "td";
  return (
    <Tag className={className} data-col={column.key} data-blank={blank ? "" : undefined} data-focused-cell={focused ? "true" : undefined} data-engine-id={idWords ? raw : undefined} {...(header ? { scope: "row" } : {})} {...(NO_TRANSLATE_COLUMN.test(String(column.key || "")) ? { translate: "no" } : {})}>
      {text === null ? "not shown" : text}
    </Tag>
  );
}

/**
 * "summary" for a sheet read as a statement (the Summary & Flags tab: horizontal
 * hairlines, flags as attention lines), "sheet" for a working sheet drawn as the
 * spreadsheet it downloads as (cell rules, frozen header row and first column).
 * Design-pass spec §6.18. Styling only: every cell is drawn either way.
 */
export function sheetKind(sheet) {
  return sheet && typeof sheet.name === "string" && /^summary\b/i.test(sheet.name.trim()) ? "summary" : "sheet";
}

/**
 * The key of the column in `row` that holds `cents`, the number a person pressed, or
 * null (verify pass 3, Q07/Q09). The first money column holding it; a row that holds it
 * nowhere marks no cell and keeps its row highlight. Pure.
 */
export function focusedColumn(sheet, row, cents) {
  if (!Number.isInteger(cents) || !row || !row.cells || typeof row.cells !== "object") return null;
  const cols = (Array.isArray(sheet && sheet.columns) ? sheet.columns : []).filter((c) => c && NUMERIC.has(c.kind) && c.kind !== "count" && c.kind !== "percent");
  // A figure said as a size ("$4,003.47 unfavourable") lights the signed cell that holds
  // it when no cell holds it as written (Q09 H3).
  const hit = cols.find((c) => row.cells[c.key] === cents) || (cents !== 0 ? cols.find((c) => row.cells[c.key] === -cents) : null);
  return hit ? hit.key : null;
}

function SheetGrid({ sheet, highlightRow, highlightCents = null, panelId, tabId, editRows = null, edits = null, invalid = {} }) {
  const rowRef = useRef(null);
  // Columns past the pane's edge are said by a fade at the right (W07: "Opening a…" sat
  // cut at the edge with nothing saying the sheet went on), as the plan's tables do.
  const wrapRef = useRef(null);
  const more = useMoreToTheRight(wrapRef);
  const kind = sheetKind(sheet);
  const columns = Array.isArray(sheet.columns) ? sheet.columns : [];
  const rows = Array.isArray(sheet.rows) ? sheet.rows : [];
  const withSource = hasSourceColumn(sheet);
  // DESIGN-FIX-2 DA2-015. A column no row fills is not drawn (the summary's empty Count);
  // its cells stay in the markup, hidden, so the pane-vs-workbook check still reads every
  // cell. A summary's flag rows move to "Things to check" under the grid (the rows stay,
  // hidden, for the same reason), so the grid reads as figures only.
  const checks = kind === "summary" ? checkRows(sheet) : [];
  const moved = new Set(checks.filter((c) => c.index !== highlightRow).map((c) => c.index));
  const blank = blankColumns(sheet, moved);
  useEffect(() => {
    const row = rowRef.current;
    if (!row || typeof row.scrollIntoView !== "function") return;
    const reduce = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    row.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" });
  }, [highlightRow, sheet.name]);
  return (
    <>
    <div ref={wrapRef} className="pane-grid-wrap" data-kind={kind} data-more={more ? "right" : undefined} role="tabpanel" id={panelId} aria-labelledby={tabId} tabIndex={0}>
      <table className="pane-grid" data-sheet={sheet.name} data-kind={kind}>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} scope="col" className={NUMERIC.has(c.kind) ? "num" : undefined} data-col={c.key} data-blank={blank.has(c.key) ? "" : undefined}>
                {c.label}
              </th>
            ))}
            {withSource ? <th scope="col" className="pane-source-col">Source</th> : null}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => {
            const lit = i === highlightRow;
            const focused = lit ? focusedColumn(sheet, row, highlightCents) : null;
            const words = sourceText(row);
            return (
              <tr
                key={i}
                ref={lit ? rowRef : undefined}
                data-row={i}
                data-role={row.role}
                data-highlight={lit ? "true" : undefined}
                data-added={row.added === true ? "true" : undefined}
                data-moved={moved.has(i) ? "checks" : undefined}
                aria-current={lit ? "true" : undefined}
              >
                {columns.map((c) => {
                  const input = editRows && edits && c.key === VALUE_COLUMN ? editRows[i] : null;
                  if (input) {
                    const label = [row.cells && row.cells.label, row.cells && row.cells.heading].filter((v) => typeof v === "string" && v).join(", ");
                    return (
                      <td key={c.key} data-col={c.key} data-editable="true">
                        <CellEditor cell={input.cell} current={input.current} label={label} edits={edits} invalid={invalid[input.cell] || null} />
                      </td>
                    );
                  }
                  return <Cell key={c.key} column={c} shown={rowCellText(row, c)} blank={blank.has(c.key)} focused={focused === c.key} />;
                })}
                {withSource ? (
                  <td className="pane-source-col">
                    {(row.source && row.source.label) || (!row.source && row.workedSource) ? words : words ? <span className="pane-missing">{words}</span> : null}
                  </td>
                ) : null}
              </tr>
            );
          })}
        </tbody>
        {sheet.totals && typeof sheet.totals === "object" ? (
          <tfoot>
            <tr data-role="total">
              {columns.map((c) => (
                <Cell key={c.key} column={c} shown={totalCellText(sheet, c)} blank={blank.has(c.key)} />
              ))}
              {withSource ? <td className="pane-source-col" /> : null}
            </tr>
          </tfoot>
        ) : null}
      </table>
      {hasAddedRows(sheet) ? <AddedRowsLegend /> : null}
      {hasNegativeMoney(sheet) ? (
        <p className="added-legend" data-legend="negatives">
          {NEGATIVES_LEGEND}
        </p>
      ) : null}
    </div>
    {checks.length ? <ThingsToCheck checks={checks} /> : null}
    </>
  );
}

// The pane's one statement of the workbook's sign convention (verify pass 2, S-UI-11):
// a card writes −$150.00; the pane and the file write ($150.00), and say so once.
export const NEGATIVES_LEGEND = "Amounts in brackets are negative, as in the workbook.";

/** Whether a sheet shows a negative amount (a row or its total) the pane writes in brackets. Pure. */
export function hasNegativeMoney(sheet) {
  const columns = sheet && Array.isArray(sheet.columns) ? sheet.columns.filter((c) => c && c.kind === "money") : [];
  if (!columns.length) return false;
  const lines = [...(Array.isArray(sheet.rows) ? sheet.rows.map((r) => r && r.cells) : []), sheet.totals];
  return lines.some((cells) => cells && typeof cells === "object" && columns.some((c) => Number.isInteger(cells[c.key]) && cells[c.key] < 0));
}

/**
 * The keys of the columns no row (and no total) fills. The first column names the line
 * and is never blank.
 */
export function blankColumns(sheet, skip = new Set()) {
  const columns = Array.isArray(sheet && sheet.columns) ? sheet.columns : [];
  const rows = Array.isArray(sheet && sheet.rows) ? sheet.rows : [];
  const out = new Set();
  if (!rows.length) return out;
  columns.forEach((c, i) => {
    if (i === 0) return;
    // The Sources sheet's machine Id column is hidden in the workbook (engine
    // sources_sheet: "the workbook keeps in its hidden Id column"); the pane hides it too
    // (U63). Its cells stay in the markup, as every hidden column's do.
    if (isIdColumn(sheet, c)) {
      out.add(c.key);
      return;
    }
    const empty = rows.every((r, at) => {
      if (skip.has(at)) return true;
      const shown = rowCellText(r, c);
      return shown !== null && shown.text === "";
    });
    const total = sheet.totals && typeof sheet.totals === "object" ? totalCellText(sheet, c) : { text: "" };
    if (empty && total && total.text === "") out.add(c.key);
  });
  return out;
}

/**
 * A summary's flag rows as things to check: `[{index, words}]`, the words being the row's
 * own cells (the flag and what to do), the "Flag" label left out. Nothing is written here.
 */
export const NOTHING_FLAGGED = /^\s*(?:none|nothing(?: to (?:flag|check|report))?|no flags?|n\/a)\s*[.!]?\s*$/i;

export function checkRows(sheet) {
  const columns = Array.isArray(sheet && sheet.columns) ? sheet.columns : [];
  const rows = Array.isArray(sheet && sheet.rows) ? sheet.rows : [];
  const out = [];
  rows.forEach((row, index) => {
    if (!row || row.role !== "note") return;
    const texts = columns.map((c) => {
      const shown = rowCellText(row, c);
      return shown ? shown.text.trim() : "";
    });
    const rest = texts.slice(1).filter(Boolean).join(" ");
    const words = rest || texts[0] || "";
    // A flag row that says there is nothing ("None.", "Nothing to flag.") is not a thing
    // to check (verify pass 1, D34: "1 thing to check" over "None.").
    if (words && !NOTHING_FLAGGED.test(words)) out.push({ index, words });
  });
  return out;
}

const DECISION_CARD = ".chat-question, [data-decision-card], .decision-card";

/** The open question in the conversation beside the pane, if there is one. */
function findDecision() {
  if (typeof document === "undefined") return null;
  return document.querySelector(DECISION_CARD);
}

/**
 * "2 things to check": each flag as one line, the Warning icon in ink-2 (the head's
 * "Needs you" is the view's one attention mark; critic r1 F12), the message in ink, and where the conversation holds the question
 * that settles it, a link that takes focus to it.
 */
function ThingsToCheck({ checks }) {
  const [decision, setDecision] = useState(false);
  useEffect(() => {
    setDecision(Boolean(findDecision()));
  }, []);
  const go = () => {
    const card = findDecision();
    if (!card) return;
    const reduce = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (typeof card.scrollIntoView === "function") card.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" });
    const target = card.querySelector("[aria-checked='true'], [aria-selected='true'], button, [tabindex]") || card;
    if (typeof target.focus === "function") target.focus({ preventScroll: true });
  };
  const n = checks.length;
  return (
    <section className="pane-checks" aria-label="Things to check" data-pane-checks={n}>
      <h3 className="pane-checks-h">{n === 1 ? "1 thing to check" : `${n} things to check`}</h3>
      <ul className="pane-checks-list">
        {checks.map((c) => (
          <li key={c.index} className="pane-check" data-row={c.index}>
            <IconWarning className="pane-check-icon" size={16} aria-hidden="true" />
            <span className="pane-check-words">{c.words}</span>
            {decision ? (
              <button type="button" className="pane-check-go" onClick={go}>
                {/account/i.test(c.words) ? "Choose account" : "Go to the question"}
                <IconCaretRight aria-hidden="true" />
              </button>
            ) : null}
          </li>
        ))}
      </ul>
    </section>
  );
}

/**
 * One summary item's value. An item is a money figure (`figureRef`, drawn by
 * EventFigure so it opens its source) OR a plain count (`count`, an integer the engine
 * counted: "Accounts checked 5"), exactly one of the two (agent_events.SummaryFigure).
 * A count is drawn through `formatAccounting` as the workbook's count column draws it,
 * so the pane and the xlsx agree (PR6). Only an item that is neither, or names a figure
 * the result does not carry, says "not in this result": a count is never that.
 */
export function summaryText(item, figures) {
  if (!item || typeof item !== "object") return null;
  if (typeof item.figureRef === "string" && item.figureRef) {
    return figures && Object.prototype.hasOwnProperty.call(figures, item.figureRef) ? { figureRef: item.figureRef } : null;
  }
  if (Number.isInteger(item.count) && item.count >= 0) {
    const text = cellText(item.count, "count");
    return text === null ? null : { count: text };
  }
  return null;
}

// THE SUMMARY AS ONE HERO AND ONE LINE (design-fix-2 DA2-015; spec §3.3 "one hero figure
// per result"). The four tiles repeated the first four rows of the grid in a KPI strip
// (the hero-metric template IMP bans). Now the last figure (the closing, the difference,
// the result's answer) is the display figure with its label above it, and the others sit
// in one quiet line under it. A roll-forward (Opening, Additions, Releases, Closing) reads
// as the statement it is: "Opening $1,200.00 + Additions $0.00 − Releases $200.00". The
// signs are words between figures the engine wrote; nothing is added up here.
const ROLL_FORWARD = [/^opening\b/i, /^(additions?|added|purchases?)\b/i, /^(releases?|released|depreciation|disposals?|amorti[sz]ation)\b/i, /^closing\b/i];

/** `{hero, rest: [{item, op}]}`: the summary's hero (its last figure) and the line under it. */
export function summaryShape(summary) {
  const list = Array.isArray(summary) ? summary.filter((s) => s && typeof s === "object") : [];
  if (!list.length) return { hero: null, rest: [], shape: "none" };
  const roll = list.length === 4 && ROLL_FORWARD.every((re, i) => re.test(String(list[i].label || "").trim()));
  const ops = roll ? [null, "+", "\u2212"] : [];
  // The hero is the last money figure; a summary of counts alone has no hero, only its line.
  let at = -1;
  list.forEach((s, i) => {
    if (typeof s.figureRef === "string" && s.figureRef) at = i;
  });
  if (roll) at = list.length - 1;
  return {
    hero: at >= 0 ? list[at] : null,
    rest: list.filter((_, i) => i !== at).map((item, i) => ({ item, op: ops[i] || null })),
    shape: roll ? "equation" : "list",
  };
}

function Summary({ summary, figures, highlight }) {
  const { hero, rest } = summaryShape(summary);
  const lit = (s) => (s.figureRef && highlight && highlight.summary === s.figureRef ? "true" : undefined);
  return (
    <dl className="pane-summary" data-summary={summary.length}>
      {hero ? (
        <div data-hero="" key={hero.figureRef || "hero"} className="pane-summary-item" data-highlight={lit(hero)}>
          <dt>{hero.label}</dt>
          <dd>
            <SummaryValue item={hero} figures={figures} />
          </dd>
        </div>
      ) : null}
      {rest.map(({ item, op }, i) => (
        <div data-op={op || undefined} key={item.figureRef || `count-${i}`} className="pane-summary-item" data-highlight={lit(item)}>
          <dt>{item.label}</dt>
          <dd>
            <SummaryValue item={item} figures={figures} />
          </dd>
        </div>
      ))}
    </dl>
  );
}

/** What a big-number slot says for a figure the engine didn't work out (W07). */
export const SLOT_UNREAD = "Not worked out";

function SummaryValue({ item, figures }) {
  const value = summaryText(item, figures);
  if (!value) return <span className="pane-missing">not in this result</span>;
  // AN UNWORKED FIGURE IN A BIG-NUMBER SLOT (W07). The engine's reason is a sentence
  // ("FA-001 Delivery van and FA-002 Laptops x3 are carried … so their life and method
  // aren't known"); drawn in title-2 on one line it ran into the next slot. The slot
  // says it plainly; the reason is the verdict's, above, and stays for a screen reader.
  if (value.figureRef && !isReadFigure(figures[value.figureRef])) {
    const f = figures[value.figureRef];
    const reason = f && typeof f.reason === "string" && f.reason.trim() ? f.reason.trim() : null;
    return (
      <span className="pane-unread" data-figure={value.figureRef} data-measured="false">
        {SLOT_UNREAD}
        {reason ? <span className="sr-only">: {reason}</span> : null}
      </span>
    );
  }
  if (value.figureRef) return <EventFigure figure={figures[value.figureRef]} figureRef={value.figureRef} />;
  return (
    <span className="figure num" data-count={String(item.count)}>
      {value.count}
    </span>
  );
}

/** The views (`[{view, label, open}]`) that have no sheet of their own: they lead the strip. Pure. */
export function viewTabsLeading(views, sheets) {
  const names = new Set((Array.isArray(sheets) ? sheets : []).map((s) => s && s.name));
  return (Array.isArray(views) ? views : []).filter((v) => v && typeof v.open === "function" && !names.has(v.label));
}

/** The view a sheet's tab opens instead of the sheet (its own sheet, "Bridge"), or null. Pure. */
export function viewForSheet(views, name) {
  return (Array.isArray(views) ? views : []).find((v) => v && typeof v.open === "function" && v.label === name) || null;
}

export default function TableView({ artifact, ledgerName = null, sheet = null, highlight = null, onSheet = null, initialEdits = null, save = undefined, initialInputs = null, read = undefined, views = null, entries = null }) {
  const a = artifact || {};
  const canOpen = useCanOpenInputs(a);
  const inputs = useInputCells(a, read ? { initial: initialInputs, read } : { initial: initialInputs });
  if (canOpen && inputs.status === "open" && inputs.loaded) {
    return (
      <div className="pane-inputs" data-view="inputs">
        <InputsHead inputs={inputs} title={inputsArtifact(a, inputs.loaded).title} />
        <InputsGrid key={(inputs.loaded && inputs.loaded.target) || "house"} artifact={inputsArtifact(a, inputs.loaded)} cells={inputs.loaded.cells} initialEdits={initialEdits} save={save} />
      </div>
    );
  }
  return <TableBody a={a} ledgerName={ledgerName} sheet={sheet} highlight={highlight} onSheet={onSheet} initialEdits={initialEdits} save={save} canOpen={canOpen} inputs={inputs} views={views} entries={entries} />;
}

function TableBody({ a, ledgerName, sheet, highlight, onSheet, initialEdits, save, canOpen, inputs, views = null, entries = null }) {
  const table = a.table || null;
  const [own, setOwn] = useState(sheet);
  const base = useId();
  const tabRefs = useRef([]);
  const stripRef = useRef(null);
  // DA2-062: on a phone the strip scrolls sideways; the chosen tab is always in view.
  useEffect(() => {
    const strip = stripRef.current;
    const on = strip && strip.querySelector('[aria-selected="true"]');
    if (!on || strip.scrollWidth <= strip.clientWidth) return;
    const left = on.offsetLeft - strip.offsetLeft;
    if (left < strip.scrollLeft || left + on.offsetWidth > strip.scrollLeft + strip.clientWidth) {
      strip.scrollLeft = Math.max(0, left - 24);
    }
  });
  // DA2-062 (critic r1 F15): the strip fades at an end that has more tabs past it,
  // measured, so the cue survives wherever animations are finished early.
  const stripEdges = useStripEdges(stripRef);
  // DA2-062: Edit is a tool in the pane's head, beside Download, not a stray in the tab
  // strip. Drawn in the strip until the head is found (the server render, a test), then
  // carried into the head.
  const [head, setHead] = useState(null);
  useEffect(() => {
    const strip = stripRef.current;
    const pane = strip && typeof strip.closest === "function" ? strip.closest(".chat-pane") : null;
    setHead((pane && pane.querySelector(":scope > .pane-head")) || null);
  }, []);
  const canEdit = useCanEdit(a);
  const edits = useWorkbookEdits(a, save ? { initial: initialEdits, save } : { initial: initialEdits });
  // A typed cell not yet saved: leaving the page asks first (WIG).
  useUnsavedWarning(Object.keys(edits.drafts || {}).length > 0);
  if (!table || !Array.isArray(table.sheets) || !table.sheets.length) return null;
  // AN ENTRIES PANE OPENS ON THE ENTRIES (founder, 17 Oct 2026; answer/shape.js): its
  // summary sheet, which only repeated the tiles, is not a tab, and it opens on Entries.
  const paneSheets = entriesPaneSheets(a, entries);
  const sheets = paneSheets.sheets;
  const chosen = typeof onSheet === "function" ? sheet : own;
  // No sheet asked for: the tab the template opens on (the comparison, the bridge, the
  // commentary), not Summary & Flags (G4 eval r2, OQ line 7).
  const active = sheetNamed({ sheets }, chosen || paneSheets.opensOn || opensOnOf(a));
  const activeIndex = sheets.indexOf(active);
  const select = (name) => (typeof onSheet === "function" ? onSheet(name) : setOwn(name));
  const figures = a.figures && typeof a.figures === "object" ? a.figures : {};
  const summary = Array.isArray(table.summary) ? table.summary : [];
  const highlightRow = highlight && highlight.sheet === active.name && Number.isInteger(highlight.row) ? highlight.row : null;
  const tabId = (i) => `${base}-tab-${i}`;
  const panelId = `${base}-panel`;
  // Every editable row across the sheets, so a change typed on one tab is still saved
  // from another; the active sheet's rows are the ones drawn as inputs.
  const allRows = {};
  if (canEdit) {
    for (const s of sheets) for (const r of Object.values(editableRows(a, s))) allRows[r.cell] = r;
  }
  const activeRows = canEdit ? editableRows(a, active) : null;
  const pending = canEdit ? pendingEdits(edits, allRows) : { ready: [], invalid: {} };
  const listed = Array.isArray(a.editable) && a.editable.length > 0;

  // Arrow keys move between tabs and select (the tablist pattern), Home and End jump.
  const onKeyDown = (event) => {
    const n = sheets.length;
    const to = { ArrowRight: activeIndex + 1, ArrowLeft: activeIndex - 1, Home: 0, End: n - 1 }[event.key];
    if (to === undefined) return;
    event.preventDefault();
    const next = (to + n) % n;
    select(sheets[next].name);
    const el = tabRefs.current[next];
    if (el && typeof el.focus === "function") el.focus();
  };

  return (
    <div className="pane-table" data-view="table">
      {a.verdict ? (
        <p className="pane-verdict">
          <BoundText text={a.verdict} figures={figures} ledgerName={ledgerName} />
        </p>
      ) : null}
      {summary.length ? <Summary summary={summary} figures={figures} highlight={highlight} /> : null}
      <div className="pane-sheets-bar">
      <div ref={stripRef} className="pane-sheets" role="tablist" aria-label="Sheets" onKeyDown={onKeyDown} data-edges={stripEdges || undefined}>
        {/* THE VIEW STAYS IN THE STRIP (verify passes 1-4, Q10 line 5): a bar's drill
            opened the workbook at Detail and the Bridge tab left the strip, so there was
            no way back to the chart but closing the pane. A view this workbook has
            (`views`, from ResultPane) is a tab here too: its own sheet's tab opens the
            view, and a view with no sheet of its own leads the strip. */}
        {viewTabsLeading(views, sheets).map((v) => (
          <button key={`view-${v.label}`} type="button" role="tab" className="pane-sheet-tab" aria-selected="false" tabIndex={-1} onClick={v.open} data-opens-view={v.view}>
            {v.label}
          </button>
        ))}
        {sheets.map((s, i) => {
          const asView = viewForSheet(views, s.name);
          return (
            <button
              key={s.name}
              type="button"
              role="tab"
              id={tabId(i)}
              ref={(el) => {
                tabRefs.current[i] = el;
              }}
              className="pane-sheet-tab"
              aria-selected={i === activeIndex ? "true" : "false"}
              aria-controls={panelId}
              tabIndex={i === activeIndex ? 0 : -1}
              onClick={asView ? asView.open : () => select(s.name)}
              data-sheet-name={s.name}
              data-opens-view={asView ? asView.view : undefined}
            >
              {sheetLabel(s.name)}
            </button>
          );
        })}
      </div>
      {canOpen && !head ? (
        <div className="pane-sheets-tools">
          <EditCellsBar inputs={inputs} />
        </div>
      ) : null}
      </div>
      {canOpen && head
        ? createPortal(
            <div className="pane-head-tools">
              <EditCellsBar inputs={inputs} />
            </div>,
            head
          )
        : null}
      {canOpen && head && inputs.error ? (
        <p className="edit-note" role="status">
          {inputs.error}
        </p>
      ) : null}
      {entries && entries.items && entries.items.length && active.name === ENTRIES_SHEET ? (
        // Every entry as its own numbered card with its lines (the sheet's rows stay in
        // the workbook): what the person approves is on screen, not a count of it.
        <div role="tabpanel" id={panelId} aria-labelledby={tabId(activeIndex)} className="pane-entries" data-pane-entries={entries.items.length}>
          <PaneEntries entries={entries} ledgerName={ledgerName} />
        </div>
      ) : (
      <SheetGrid key={active.name} sheet={active} highlightRow={highlightRow} highlightCents={highlightRow !== null && highlight && Number.isInteger(highlight.cents) ? highlight.cents : null} panelId={panelId} tabId={tabId(activeIndex)} editRows={activeRows} edits={canEdit ? edits : null} invalid={pending.invalid} />
      )}
      {canEdit ? <SaveBar edits={edits} pending={pending} /> : null}
      {listed && !canEdit ? <p className="edit-note">This is a saved sample, so its cells can&rsquo;t be changed here.</p> : null}
    </div>
  );
}
