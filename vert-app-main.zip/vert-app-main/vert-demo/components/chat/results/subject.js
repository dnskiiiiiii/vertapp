// components/chat/results/subject.js — WHICH PAYOUT A RESULT IS ABOUT
// ==============================================================================
// A payout breakdown or a journal result is about one payout. The artifact names it
// in `subject` when the engine sends one, and otherwise in the source of its figures.
// The id is used to look the payout up and is shown only under Details.

export function payoutIdOf(artifact) {
  const a = artifact || {};
  if (a.subject && a.subject.kind === "payout" && typeof a.subject.id === "string") return a.subject.id;
  const figures = a.figures && typeof a.figures === "object" ? Object.values(a.figures) : [];
  for (const f of figures) {
    if (f && f.source && f.source.kind === "payout" && typeof f.source.id === "string") return f.source.id;
  }
  return null;
}
