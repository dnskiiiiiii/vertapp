"use client";

// components/chat/results/ShownInPane.js — THE RAIL DOESN'T SAY THE PANE AGAIN
// ==============================================================================
// Design-fix-2 DA2-039 (spec §9; critic r1 F5). With the management commentary open in the
// pane, the conversation beside it still drew the whole document again as bullets
// (Revenue, Expenses, Profit, Cash, Against budget), so the screen said everything twice.
// While the result an answer delivered is the one open in the pane, that answer keeps its
// lead sentence (the verdict, drawn by the answer itself) and its body collapses to one
// quiet line: "Shown in the pane", with "Show here too" to expand it in place.
//
// The conversation's pane says which result it shows (`usePane().shownId`); with no pane
// (Month-end, Records, a test rendering one message) or another result open, the body is
// drawn as it always was.

import { useEffect, useState } from "react";
import { usePane } from "./paneContext";

export const SHOWN_IN_PANE = "Shown in the pane";
export const SHOW_HERE = "Show here too";
export const HIDE_HERE = "Hide";

/** True when `pane` reports `artifactId` as the result it is showing. */
export function shownInPane(pane, artifactId) {
  return Boolean(pane && artifactId && pane.shownId && pane.shownId === artifactId);
}

export default function ShownInPane({ artifactId, children }) {
  const pane = usePane();
  const shown = shownInPane(pane, artifactId);
  const [here, setHere] = useState(false);
  // Closing the pane (or opening another result) puts the rail back as it was, so the
  // next open collapses it again.
  useEffect(() => {
    if (!shown) setHere(false);
  }, [shown]);
  if (!shown) return children;
  return (
    <div className="shown-in-pane" data-shown-in-pane={artifactId} data-open={here ? "true" : undefined}>
      <p className="shown-in-pane-note">
        <span>{SHOWN_IN_PANE}</span>
        <button type="button" className="shown-in-pane-toggle" aria-expanded={here ? "true" : "false"} onClick={() => setHere((v) => !v)}>
          {here ? HIDE_HERE : SHOW_HERE}
        </button>
      </p>
      {here ? children : null}
    </div>
  );
}
