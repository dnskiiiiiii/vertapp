// components/chat/results/BankRec.js — THE BANK RECONCILIATION, VERDICT FIRST
// ==============================================================================
// Spec §3.3 and UI-035: the verdict ("Doesn't reconcile yet: $112.50 unexplained"),
// the four figures, what explains the gap, and a checklist of any input still missing.
// NO COMMIT BUTTON: the engine's verdict closes the task when the gap is explained,
// and nothing here marks a reconciliation done (build plan §3 E2). Download Excel is a
// quiet link in the header, where the engine built a workbook.

import BoundText from "../BoundText";
import EventFigure from "../EventFigure";
import VerdictBand from "./VerdictBand";
import KeyFigures from "./KeyFigures";
import { shortDate } from "@/lib/agent/words";

export default function BankRec({ artifact, ledgerName }) {
  const explains = Array.isArray(artifact.explains) ? artifact.explains.filter((e) => e && e.label) : [];
  const missing = Array.isArray(artifact.missing) ? artifact.missing.filter((m) => typeof m === "string" && m) : [];
  return (
    <div className="chat-result-body-inner">
      <VerdictBand text={artifact.verdict || "Not reconciled yet."} ok={artifact.ok ?? null} figures={artifact.figures} ledgerName={ledgerName} />
      <KeyFigures figures={artifact.figures} />
      {explains.length ? (
        <>
          <p className="chat-sheet-label">What explains the gap</p>
          <dl className="chat-keyfigs chat-keyfigs-wide">
            {explains.map((e, i) => (
              <div key={i}>
                <dt>
                  {shortDate(e.date) ? `${shortDate(e.date)} ` : ""}
                  <BoundText text={e.label} figures={{}} ledgerName={ledgerName} />
                </dt>
                <dd>
                  <EventFigure figure={e.figure || null} />
                </dd>
              </div>
            ))}
          </dl>
        </>
      ) : null}
      {missing.length ? (
        <>
          <p className="chat-sheet-label">Still needed</p>
          <ul className="chat-missing">
            {missing.map((m, i) => (
              <li key={i}>{m}</li>
            ))}
          </ul>
        </>
      ) : null}
    </div>
  );
}
