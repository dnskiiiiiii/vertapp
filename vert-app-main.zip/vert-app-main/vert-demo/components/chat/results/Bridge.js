"use client";

// components/chat/results/Bridge.js — THE BRIDGE, AS AN SVG IN THE PANE
// ==============================================================================
// Build plan §20.0 decisions 6 and 7, §20.3 F-BUD. Opened FROM the workbook card ("Open
// bridge"), never instead of it: the card is the primary artifact, so this view always
// offers the way back ("Open workbook").
//
// WHY IT IS DRAWN AS ROWS, ONE BAR PER ROW. A bridge read left to right needs its labels
// under the columns, rotated or truncated as soon as there are more than four of them,
// and at 390 px they collide. Drawn top to bottom, each step is a row: the label is HTML
// and wraps like any sentence, the bar floats in its own track at the running position,
// and the words sit beside it. Nothing scrolls sideways at any width (§20.3 acceptance).
// Each track is a small SVG whose x positions are percentages of one shared scale, so
// every row's bar lines up with the one above it: the dashed tick at the start of a bar
// is where the previous bar ended.
//
// COLOUR IS NEVER THE ONLY CARRIER (decision 6; WCAG 1.4.1; the dataviz skill). A bar's
// favourable or unfavourable state takes Vert's status tokens (done ink and problem ink),
// and every bar also prints its sign and the word, exactly as the engine wrote it
// (`bar.words`, "−$4,615.00 unfavourable"). Labelled directly like that, the chart needs
// no legend (design-pass spec §6.19). "Everything else" has no single direction, so it
// is drawn in the control grey and says what it is: the net of the accounts it holds.
// Start and end are totals, drawn from zero in ink-2, so the scale never begins
// part-way up and a small change cannot be made to look large.
//
// THE ARITHMETIC HERE IS GEOMETRY, AND IT NEVER REACHES THE SCREEN AS A FIGURE. To float
// a bar the view needs where the previous one ended, which is a running total of the
// engine's cents. Those running positions become percentages of a track and nothing
// else: no running total is printed, in the chart or in the table, and every amount on
// screen is a field the engine emitted. The same pass checks that the bars reach the end
// to the cent (start + bars + everything else = end), the engine's own guard repeated at
// the last moment before drawing. A bridge that does not sum is not drawn: a chart of
// numbers that disagree with each other is worse than no chart, and the workbook has
// every figure.
//
// DRILL-DOWN. Each bar names its Detail rows (`drillRef`, "Detail!6500"). When the pane
// can open them, every bar is a button that does; when it cannot, no bar pretends to be
// pressable (no false affordance) and the table names the rows instead. `drillTarget`
// turns a ref into the sheet and row key. In a conversation (F-WIRE) the pane is reached
// through PaneContext: a bar opens its workbook (`bridge.workbookRef`) at that row,
// highlighted, and is a button only when that workbook in this conversation has the
// sheet the ref names (analysis-views.js drillRow). `onDrill` replaces that road (tests).
//
// MOTION. Nothing here animates on its own. Hover and press feedback come from the kit's
// row styles, and app/styles/bridge.css turns transitions off under reduced motion.

import EventFigure from "../EventFigure";
import { bindFigures } from "@/lib/agent/events";
import { formatMoney } from "@/lib/format";
import { Disclosure } from "@/components/ui";
import { IconCaretRight } from "@/components/ui/icons";
import usePhone from "../plan/usePhone";
import { usePane } from "./paneContext";
import { drillRow, workbookOf } from "./analysis-views";

/** The two totals' names, by the bridge's mode (§20.1 step 0b item 6). */
const ENDS = Object.freeze({
  budget: { start: "Budget", end: "Actual" },
  month: { start: "Last month", end: "This month" },
  balance: { start: "Opening balance", end: "Closing balance" },
});

const NOT_DRAWN = "Every figure is in the workbook.";

function isCents(value) {
  return typeof value === "number" && Number.isInteger(value);
}

function readFigure(figures, ref) {
  const figure = figures && typeof ref === "string" && Object.hasOwn(figures, ref) ? figures[ref] : null;
  if (!figure || figure.measured === false || !isCents(figure.cents)) return null;
  return figure;
}

/**
 * "Detail!6500" → `{sheet: "Detail", row: "6500"}`, the tab and row the pane opens
 * highlighted. Null for a ref that names no sheet, so a bar never opens a guess.
 */
export function drillTarget(drillRef, label = null) {
  if (typeof drillRef !== "string") return null;
  const at = drillRef.indexOf("!");
  if (at < 1 || at === drillRef.length - 1) return null;
  const sheet = drillRef.slice(0, at);
  const row = drillRef.slice(at + 1);
  // THE ENGINE NAMES A CELL RANGE, not a row key (verify passes 1-4, Q10 line 4). Its
  // bars carry `Detail!A6:F8`, the bar's block on the Detail tab (vert_engine/analysis/
  // waterfall.py with_drill_refs); this read `A6:F8` as a row key, matched nothing, and
  // every bar opened Detail with no row lit and no lines, beside its own hint "Press a row
  // to open its lines". The tests stayed green on a fixture of the older `Detail!6500`
  // form. A range's block begins with the bar's own header row ("6500 · Repairs &
  // maintenance"), which the bridge's Detail and the budget workbook's Detail both
  // write, so a range is found by the bar's label.
  if (RANGE.test(row)) return typeof label === "string" && label.trim() ? { sheet, row: label.trim(), range: row } : { sheet, row: null, range: row };
  return { sheet, row };
}

const RANGE = /^[A-Z]+[0-9]+:[A-Z]+[0-9]+$/;

/** The tone a bar is drawn in. Only an engine `true`/`false` is a direction. */
function toneOf(favourable) {
  if (favourable === true) return "favourable";
  if (favourable === false) return "unfavourable";
  return "neutral";
}

/**
 * "+$1.53" / "−$1.53" / "$0.00". Decision 6 puts a sign on every bar, and the engine's
 * own bars carry theirs in `bar.words`; "Everything else" has no words from the engine,
 * so its sign is written here. formatMoney already writes the minus; only the plus is
 * added, and zero has no direction to sign.
 */
function signedMoney(cents) {
  return cents > 0 ? `+${formatMoney(cents)}` : formatMoney(cents);
}

/** "4 other accounts" / "1 other account": the count the engine folded in. */
function othersWords(count) {
  if (!Number.isInteger(count) || count < 0) return "the other accounts";
  return count === 1 ? "1 other account" : `${count} other accounts`;
}

/**
 * The rows the view draws, or why it draws none. Pure, so the rules are tested without a
 * browser (tests/bridge.test.js):
 *
 *   `{ok: true, rows, zero}`: `rows` are start, each bar in the engine's order, then
 *   "Everything else", then end. Each row carries `x` and `width` (percent of the track),
 *   `tick` (where the previous bar ended, for the dashed connector), the engine's words,
 *   and its tone. `zero` is the baseline's position.
 *
 *   `{ok: false, words}`: the sentence that says why, in place of the chart.
 */
export function bridgeRows(artifact) {
  const bridge = artifact && artifact.bridge;
  if (!bridge || !Array.isArray(bridge.bars)) {
    return { ok: false, words: `This result carries no bridge. ${NOT_DRAWN}` };
  }
  const figures = artifact.figures || {};
  const start = readFigure(figures, bridge.start);
  const end = readFigure(figures, bridge.end);
  const names = ENDS[bridge.mode] || { start: "Start", end: "End" };
  if (!start || !end) {
    const missing = !start ? names.start.toLowerCase() : names.end.toLowerCase();
    return { ok: false, words: `The ${missing} wasn't read, so Vert can't draw the bridge. ${NOT_DRAWN}` };
  }
  const other = bridge.other;
  if (!other || !isCents(other.cents)) {
    return { ok: false, words: `The bridge came without its "Everything else" bar, so Vert won't draw it. ${NOT_DRAWN}` };
  }
  for (const bar of bridge.bars) {
    if (!bar || !isCents(bar.cents) || typeof bar.words !== "string" || !bar.words.trim()) {
      return { ok: false, words: `One bar came without its amount in words, so Vert won't draw the bridge. ${NOT_DRAWN}` };
    }
  }

  // The running position of each step's two ends, in cents: geometry only (see the head).
  const steps = [];
  let at = start.cents;
  for (const bar of bridge.bars) {
    steps.push({ from: at, to: at + bar.cents, bar });
    at += bar.cents;
  }
  steps.push({ from: at, to: at + other.cents, bar: null });
  at += other.cents;
  if (at !== end.cents) {
    return { ok: false, words: `The bars don't add up to the change, so Vert won't draw them. ${NOT_DRAWN}` };
  }

  // DESIGN-FIX-2 DA2-019: the scale runs from the lowest running position to the highest
  // (with a little air at each end), not from zero, so the moves are the chart's subject
  // and a $4,615 move is a bar, not a 3 px sliver beside two slabs. The two totals are
  // drawn from the track's start and carry a break mark, because their bars no longer
  // start at zero; their figures are printed beside them in full.
  const reach = [start.cents, end.cents, ...steps.map((s) => s.to)];
  const top = Math.max(...reach);
  const bottom = Math.min(...reach);
  const air = top > bottom ? Math.round((top - bottom) * 0.08) : Math.max(1, Math.round(Math.abs(top) * 0.08)) || 1;
  const lo = bottom - air;
  const hi = top + air;
  const span = hi > lo ? hi - lo : 1;
  const pct = (value) => Math.round(((value - lo) / span) * 10000) / 100;

  const total = (key, figure, label) => ({
    key,
    label,
    kind: "total",
    tone: "total",
    words: formatMoney(figure.cents),
    cents: figure.cents,
    figureRef: key === "start" ? bridge.start : bridge.end,
    drillRef: null,
    x: 0,
    width: pct(figure.cents),
    tick: null,
  });

  const rows = [total("start", start, names.start)];
  steps.forEach((step, i) => {
    const left = Math.min(pct(step.from), pct(step.to));
    const width = Math.round(Math.abs(pct(step.to) - pct(step.from)) * 100) / 100;
    if (step.bar) {
      rows.push({
        key: `bar-${i}`,
        label: step.bar.label || "Unnamed account",
        kind: "bar",
        tone: toneOf(step.bar.favourable),
        words: step.bar.words,
        cents: step.bar.cents,
        figureRef: step.bar.figureRef || null,
        drillRef: typeof step.bar.drillRef === "string" ? step.bar.drillRef : null,
        x: left,
        width,
        tick: pct(step.from),
      });
    } else {
      rows.push({
        key: "other",
        label: "Everything else",
        kind: "other",
        tone: "neutral",
        words: `${signedMoney(other.cents)} net of ${othersWords(other.count)}`,
        cents: other.cents,
        figureRef: null,
        drillRef: null,
        x: left,
        width,
        tick: pct(step.from),
      });
    }
  });
  rows.push(total("end", end, names.end));
  return { ok: true, rows, zero: lo <= 0 && hi >= 0 ? pct(0) : null };
}

/** The words a screen reader hears for one row, and what pressing it does. */
export function rowLabel(row, drillable) {
  const tail = drillable ? ". Opens its rows in the workbook" : "";
  return `${row.label}: ${row.words}${tail}`;
}

function Track({ row }) {
  // Floating 14 px bars on a 28 px track, radius 2 (SVG clamps it to half a narrow bar's
  // width), and a 2 px cap where each step lands so a move of a few cents still leaves a
  // mark. The dashed connector rises from where the previous step landed to this bar's
  // top. Every x is a percentage of the one shared scale.
  const capAt = row.kind === "total" || row.cents >= 0 ? row.x + row.width : row.x;
  return (
    <svg className="bridge-track" width="100%" height="28" aria-hidden="true" focusable="false">
      {row.tick !== null ? <line className="bridge-tick" x1={`${row.tick}%`} x2={`${row.tick}%`} y1="-19" y2="7" /> : null}
      <rect className={`bridge-bar bridge-${row.tone}`} x={`${row.x}%`} width={`${row.width}%`} y="7" height="14" rx="2" />
      <line className={`bridge-cap bridge-${row.tone}`} x1={`${capAt}%`} x2={`${capAt}%`} y1="7" y2="21" />
      {row.kind === "total" ? <line className="bridge-break" x1="1.2%" x2="1.2%" y1="5" y2="23" /> : null}
    </svg>
  );
}

/** "−$4,615.00 unfavourable" → the signed amount and its word, as the engine wrote them. */
export function splitWords(words) {
  const text = typeof words === "string" ? words.trim() : "";
  const at = text.search(/\s/);
  if (at < 0) return { amount: text, rest: "" };
  return { amount: text.slice(0, at), rest: text.slice(at + 1) };
}

/**
 * An account's name as the type rules write it (spec §3.4): the code tabular in ink-3, a
 * space, then the name, "6500 Repairs & maintenance", never "6500 · Repairs…".
 */
export function AccountLabel({ text }) {
  const m = /^(\d{3,6})(?:\s*\u00b7\s*|\s+)(.+)$/.exec(String(text || ""));
  if (!m) return text;
  return (
    <>
      <span className="bridge-code">{m[1]}</span> {m[2]}
    </>
  );
}

/** The chevron at the end of a row that opens its lines. Decorative: the row is named. */
function Chevron() {
  return <IconCaretRight className="bridge-chevron" size={12} aria-hidden="true" />;
}

function Verdict({ artifact }) {
  if (typeof artifact.verdict !== "string" || !artifact.verdict.trim()) return null;
  const parts = bindFigures(artifact.verdict, artifact.figures);
  return (
    <p className="bridge-verdict">
      {parts.map((part, i) =>
        part.t === "text" ? (
          <span key={i}>{part.v}</span>
        ) : (
          <EventFigure key={i} figure={part.figure} figureRef={part.ref} />
        )
      )}
    </p>
  );
}

/**
 * How a bar's drill is carried out here: `(drillRef) => target | null`, plus `go(target)`.
 * With `onDrill`, any ref naming a sheet; through the pane, only a ref whose sheet the
 * bridge's workbook in this conversation has.
 */
export function drillRoad(artifact, { onDrill = null, pane = null } = {}) {
  if (typeof onDrill === "function") {
    return { at: (ref, label = null) => drillTarget(ref, label), go: (ref, target) => onDrill(ref, target) };
  }
  if (!pane || typeof pane.open !== "function" || typeof pane.artifact !== "function") return null;
  const workbook = pane.artifact(workbookOf(artifact, "bridge"));
  if (!workbook) return null;
  return {
    // A bar drills only when its row is found: a drill that opened the sheet with no row
    // lit is the false affordance the checker saw (Q10).
    at: (ref, label = null) => {
      const hit = drillRow(workbook, drillTarget(ref, label));
      return hit && Number.isInteger(hit.row) ? hit : null;
    },
    go: (ref, target, trigger) => pane.open({ artifactId: target.artifactId, sheet: target.sheet, row: target.row }, trigger),
  };
}

export default function Bridge({ artifact, onOpenWorkbook = null, onDrill = null }) {
  const drawn = bridgeRows(artifact);
  const road = drillRoad(artifact, { onDrill, pane: usePane() });
  // DA2-019: on a phone the steps are read as a table first; the chart is one press away.
  const phone = usePhone();
  const back =
    typeof onOpenWorkbook === "function" ? (
      <button type="button" className="btn btn-secondary btn-sm bridge-back" onClick={onOpenWorkbook}>
        Open workbook
      </button>
    ) : null;

  if (!drawn.ok) {
    return (
      <div className="chat-sheet-note" data-view="bridge" data-drawn="false">
        <p>{drawn.words}</p>
        {back}
      </div>
    );
  }

  // Labelled directly, so there is no legend (spec §6.19): every bar prints its sign and
  // its word ("−$4,615.00 unfavourable") at the row's end, and colour only repeats it.
  const anyDrill = Boolean(road) && drawn.rows.some((row) => row.drillRef && road.at(row.drillRef, row.label));
  const end = drawn.rows[drawn.rows.length - 1];
  const tones = new Set(drawn.rows.map((r) => r.tone));
  return (
    <div className="bridge" data-view="bridge" data-drawn="true">
      <div className="bridge-head">
        {/* The one hero figure (spec §3.3): where the bridge lands, the engine's own end. */}
        <div className="bridge-hero">
          <p className="figure-hero-label">{end.label}</p>
          <p className="figure-hero num" data-figure={end.figureRef || undefined} translate="no">
            {end.words}
          </p>
        </div>
        {back ? <div className="bridge-tools">{back}</div> : null}
      </div>
      <Verdict artifact={artifact} />
      {/* ONE KEY (design-fix-2 DA2-019, the founder's decision) names the two colours
          above the rows; every bar still prints its sign and word, so colour is never
          alone. Verify pass 4 (F-24) asked to drop it: that reverses DA2-019, so it is
          left for the founder (needs_from_others), not changed here. */}
      <div className="bridge-key-row">
        <ul className="bridge-key" aria-label="Key">
          {tones.has("favourable") ? (
            <li><span className="bridge-swatch bridge-favourable" aria-hidden="true" />Favourable</li>
          ) : null}
          {tones.has("unfavourable") ? (
            <li><span className="bridge-swatch bridge-unfavourable" aria-hidden="true" />Unfavourable</li>
          ) : null}
        </ul>
        {anyDrill ? <p className="bridge-hint">Press a row to open its lines.</p> : null}
      </div>
      <ol className="bridge-rows" aria-label={`${artifact.title || "Bridge"}, step by step`}>
        {drawn.rows.map((row) => {
          const target = road && row.drillRef ? road.at(row.drillRef, row.label) : null;
          const drillable = Boolean(target);
          const inner = (
            <>
              <span className="bridge-label" translate="no">
                <AccountLabel text={row.label} />
              </span>
              <Track row={row} />
              <span className={`bridge-words bridge-words-${row.tone}`} data-figure={row.figureRef || undefined}>
                <span className="bridge-amount">{splitWords(row.words).amount}</span>
                {splitWords(row.words).rest ? <span className="bridge-word"> {splitWords(row.words).rest}</span> : null}
              </span>
              {anyDrill ? <span className="bridge-end">{drillable ? <Chevron /> : null}</span> : null}
            </>
          );
          return (
            <li key={row.key} className={`bridge-item bridge-item-${row.kind}`} data-tone={row.tone}>
              {drillable ? (
                <button
                  type="button"
                  className="bridge-row bridge-row-press"
                  aria-label={rowLabel(row, true)}
                  title={row.words}
                  onClick={(event) => road.go(row.drillRef, target, event.currentTarget)}
                >
                  {inner}
                </button>
              ) : (
                <div className="bridge-row" data-drill={anyDrill ? "row" : undefined} aria-label={rowLabel(row, false)} role="group" title={row.words}>
                  {inner}
                </div>
              )}
            </li>
          );
        })}
      </ol>
      <Disclosure key={phone ? "phone" : "desk"} summary="Show as a table" defaultOpen={phone} className="bridge-as-table">
        <table className="bridge-table" aria-label={`${artifact.title || "Bridge"}, as a table`}>
          <thead>
            <tr>
              <th scope="col">Step</th>
              <th scope="col">Amount</th>
              <th scope="col">Detail rows</th>
            </tr>
          </thead>
          <tbody>
            {drawn.rows.map((row) => (
              <tr key={row.key}>
                <th scope="row">
                  <AccountLabel text={row.label} />
                </th>
                <td>{row.words}</td>
                <td>{row.drillRef || "None named"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Disclosure>
    </div>
  );
}
