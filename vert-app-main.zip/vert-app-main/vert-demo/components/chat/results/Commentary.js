"use client";

// components/chat/results/Commentary.js — THE MANAGEMENT COMMENTARY, AS A DOCUMENT YOU EDIT
// ==============================================================================
// Build plan §20.0 decisions 7 and 8, §20.4 F-PLAN. Opened FROM the workbook card
// ("Edit commentary"), never instead of it: the workbook is the primary artifact, so
// this view always offers the way back ("Open workbook"). It reads as the plan document
// does, on the document type scale with no card chrome:
//
//   Management commentary Sep 2026                  Edit  [Open workbook]
//   Draft v1 · every figure is a cell in the workbook
//   Press any figure to see where it came from.
//   Headline       Net profit for September was $18,886.53.
//   Revenue        …
//   For you to add  The outlook and the decisions. Vert doesn't write these.
//   Not in this draft  Cash: the balance sheet wasn't read for September
//
// ONE FOOTER PER PANE (design-pass spec §6.11, audit §9). The pane's own foot carries
// Download Excel (the same file `downloadHref` names), so this view draws no second
// footer and no second Download. Its tools sit in its head: Edit and Open workbook at
// rest; while editing, a glass bar sticky to the top of the pane says so and holds
// Cancel · Save changes, so the save is in reach however far down the edit is.
//
// EVERY FIGURE IS A CELL. A `{{fig:ref}}` token is drawn as the engine's figure, never a
// number typed into prose: with `onOpenCell` it is a button that opens its Figures cell
// in the workbook; without it, the conversation's own figure (EventFigure: its source
// sheet, or its row in the pane). An unread figure says why, in words, never $0.00.
//
// VERT NEVER WRITES THE OUTLOOK. "For you to add" is an empty prompt until a person
// types into it, and a paragraph a person wrote (`addedBy`) says so: "added by Sam". A
// person may type numbers; they stay theirs and are not counted as Vert's claims (the
// engine re-scans the saved text, decision 8).
//
// EDIT → SAVE CHANGES → A NEW VERSION. Edit turns each paragraph into a field holding
// its words, figures written out as they read. Save changes sends every section's text
// back with each figure that is still there put back as its `{{fig:…}}` token
// (`rebind`), against the version opened (`baseVersion`; a stale one is the engine's
// 409). Nothing claims the save until the engine answers. Save changes is disabled with
// its reason until something changed. It is the secondary button, never the accent:
// saving a commentary writes a new version of the workbook, not the books (spec §3.2).
//
// WIRED (F-WIRE). Save changes is lib/workpapers.js `saveCommentary` (POST
// /workpapers/{artifactId}/commentary) unless a `save` is given. The engine appends the
// artifact again as v n+1; the conversation's stream brings it, the pane draws its latest
// copy (lib/agent/pane.js paneArtifacts), so the view shows v2 without a reload, and a
// reload reads v2 from the record. A figure opens its Figures cell through the pane
// (PaneContext), in this commentary's workbook (`commentary.workbookRef`), only where that
// workbook in this conversation has a Figures tab; `onOpenCell` replaces that road.
//
// MOTION. Nothing here animates on its own; app/styles/commentary.css adds only hover
// fills, and turns them off under reduced motion.

import { useState } from "react";
import EventFigure from "../EventFigure";
import { Button, Notice } from "@/components/ui";
import { IconEdit } from "@/components/ui/icons";
import { bindFigures } from "@/lib/agent/events";
import { formatMoney } from "@/lib/format";
import { appHref } from "@/lib/agent/links";
import { workbookHref } from "@/app/api/workpapers/shared";
import { saveCommentary } from "@/lib/workpapers";
import { usePane } from "./paneContext";
import useUnsavedWarning from "./useUnsavedWarning";
import { drillRow, workbookOf } from "./analysis-views";

/** The section Vert never writes (the engine's FOR_YOU_TO_ADD). */
export const FOR_YOU_TO_ADD = "for_you_to_add";

/** The prompt in the empty "For you to add" section. */
export const ADD_PROMPT = "The outlook, and the decisions behind these numbers. Vert doesn't write these; add them here.";

/** Said once, under the title: how a figure shows where it came from (spec §6.20). */
export const FIGURE_HINT = "Press any figure to see where it came from.";

/** Said beside a disabled Save changes. */
export const NOTHING_CHANGED = "Nothing has changed yet.";
export const NOT_CONNECTED = "Saving isn't connected here yet. Download Excel keeps the draft as Vert wrote it.";

const PARA_LIMIT = 4000;
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const FIG = /\{\{\s*fig:([^}]+?)\s*\}\}/g;

function readFigure(figures, ref) {
  const f = isObj(figures) && Object.hasOwn(figures, ref) ? figures[ref] : null;
  return isObj(f) && f.measured !== false && Number.isInteger(f.cents) ? f : null;
}

/** The commentary payload, or null when the artifact carries none. */
export function commentaryOf(artifact) {
  const c = isObj(artifact) && isObj(artifact.commentary) ? artifact.commentary : null;
  return c && Array.isArray(c.sections) && c.sections.length ? c : null;
}

/** A paragraph's key in the drafts: "section:index". */
const draftKey = (section, i) => `${section}:${i}`;

/**
 * A paragraph as a person edits it: each `{{fig:ref}}` written out as the figure reads
 * ("$18,886.53"). A token whose figure wasn't read stays as written, so nothing unread
 * turns into a number on the way through the editor.
 */
export function editableText(paragraph, figures) {
  const text = isObj(paragraph) && typeof paragraph.text === "string" ? paragraph.text : "";
  return text.replace(FIG, (whole, ref) => {
    const f = readFigure(figures, ref.trim());
    return f ? formatMoney(f.cents) : whole;
  });
}

/**
 * The edited words with every figure still in them put back as its token, in the order
 * the paragraph had them. A figure the person deleted is simply gone; a number they
 * typed stays as their text (the engine marks it "added by"). Never matches a figure
 * inside a longer number: "$1,500.00" is not found in "$11,500.00".
 */
export function rebind(text, paragraph, figures) {
  let out = typeof text === "string" ? text : "";
  const source = isObj(paragraph) && typeof paragraph.text === "string" ? paragraph.text : "";
  let from = 0;
  for (const m of source.matchAll(FIG)) {
    const ref = m[1].trim();
    const f = readFigure(figures, ref);
    if (!f) continue;
    const shown = formatMoney(f.cents);
    let at = out.indexOf(shown, from);
    while (at >= 0 && (/[\d.,$−-]/.test(out[at - 1] || "") || /\d/.test(out[at + shown.length] || ""))) at = out.indexOf(shown, at + 1);
    if (at < 0) continue;
    const token = `{{fig:${ref}}}`;
    out = out.slice(0, at) + token + out.slice(at + shown.length);
    from = at + token.length;
  }
  return out;
}

/** Every paragraph's editable words, keyed "section:index". */
export function startDrafts(commentary, figures) {
  const out = {};
  for (const s of commentaryOf({ commentary }) ? commentary.sections : []) {
    const paras = Array.isArray(s.paragraphs) ? s.paragraphs : [];
    paras.forEach((p, i) => {
      out[draftKey(s.key, i)] = editableText(p, figures);
    });
    if (!paras.length) out[draftKey(s.key, 0)] = "";
  }
  return out;
}

/** True when any draft differs from what Vert (or a person) last saved. */
export function draftsChanged(commentary, figures, drafts) {
  const before = startDrafts(commentary, figures);
  return Object.keys(drafts || {}).some((k) => (drafts[k] ?? "").trim() !== (before[k] ?? "").trim());
}

/**
 * The body `POST /workpapers/{artifactId}/commentary` takes (the engine's
 * CommentaryEdits): `{baseVersion, sections: [{key, paragraphs: [{text}]}]}`, every
 * section in order, figures rebound to their tokens, empty paragraphs dropped. Returns
 * `{ok: false, message}` for a body the engine would refuse, before anything is sent.
 */
export function commentaryEdits(commentary, figures, drafts) {
  const c = commentaryOf({ commentary });
  if (!c || !Number.isInteger(c.version) || c.version < 1) return { ok: false, message: "Vert can't tell which version this is. Nothing was saved." };
  const sections = c.sections.map((s) => {
    const paras = Array.isArray(s.paragraphs) && s.paragraphs.length ? s.paragraphs : [{ text: "", figs: [] }];
    const out = [];
    paras.forEach((p, i) => {
      const k = draftKey(s.key, i);
      const typed = drafts && Object.hasOwn(drafts, k) ? drafts[k] : editableText(p, figures);
      // "For you to add" is split into paragraphs at blank lines, as a person writes it.
      const pieces = s.key === FOR_YOU_TO_ADD ? String(typed).split(/\n\s*\n/) : [String(typed)];
      for (const piece of pieces) {
        const text = rebind(piece.trim(), p, figures);
        if (text) out.push({ text });
      }
    });
    return { key: s.key, paragraphs: out };
  });
  const long = sections.some((s) => s.paragraphs.some((p) => p.text.length > PARA_LIMIT));
  if (long) return { ok: false, message: "A paragraph is at most 4,000 characters. Nothing was saved." };
  return { ok: true, body: { baseVersion: c.version, sections } };
}

/** Where Download goes: the saved version's workbook, else the result's own file. */
export function downloadHref(artifact) {
  if (!isObj(artifact)) return null;
  if (typeof artifact.artifactId === "string" && Number.isInteger(artifact.version) && artifact.version > 0) return workbookHref(artifact.artifactId, artifact.version);
  return appHref(artifact.xlsxHref);
}

/**
 * A figure in whole dollars ("$39,000"), through the one formatter's own option: the
 * "Rounded" view (DA2-039), off by default, so a paragraph is not a wall of cents.
 * Display only: pressing it still opens the full cell.
 */
export function roundedWords(cents) {
  return formatMoney(cents, { showCents: false });
}

/**
 * A section's headline figure (DA2-039), or null: the CURRENT period's figure it cites.
 *
 * Verify pass 1 (Q11): the first figure cited was taken, and "Net profit fell from
 * {{fig:pl.net.last}} to {{fig:pl.net.this}}" made August's net profit the headline of
 * September's Profit section. The engine names a period's pair `.this` / `.last`; the
 * headline is the first `.this` cited, else the first that is not a prior period's.
 */
//
// AN EDITED SECTION KEEPS ITS FIGURE (verify passes 3-4, Q11 / output-ui F-23). Once a
// person edits a paragraph, the engine marks the whole paragraph "added by Sam Lee", and
// this skipped every `addedBy` paragraph: the Headline's one paragraph was edited, so v2
// drew the Headline with no figure line. A `{{fig:…}}` token is always the engine's cell
// (what a person types stays plain text, never a token: rebind only puts back figures
// the paragraph already cited), so an edited paragraph's tokens still count. Vert's own
// paragraphs are read first; an edited one's tokens are the fallback.
export function headlineRef(section, figures) {
  const paras = isObj(section) && Array.isArray(section.paragraphs) ? section.paragraphs : [];
  const citedIn = (keep) => {
    const cited = [];
    for (const p of paras) {
      if (!isObj(p) || typeof p.text !== "string" || !keep(p)) continue;
      for (const m of p.text.matchAll(FIG)) {
        const ref = m[1].trim();
        if (readFigure(figures, ref)) cited.push(ref);
      }
    }
    return cited.find((r) => /\.this$/.test(r)) || cited.find((r) => !PRIOR_PERIOD.test(r)) || cited[0] || null;
  };
  return citedIn((p) => !p.addedBy) || citedIn((p) => Boolean(p.addedBy));
}

/** A prior period's figure: "pl.net.last", "flux.a400.last". */
const PRIOR_PERIOD = /\.(?:last|prior|prev(?:ious)?)$/;

/** One figure in the prose. */
function Fig({ figure, figureRef, onOpenCell, rounded = false }) {
  const read = isObj(figure) && figure.measured !== false && Number.isInteger(figure.cents);
  if (read && rounded && typeof onOpenCell !== "function") {
    const binding = { "data-figure": figureRef, "data-cents": String(figure.cents), "data-measured": "true" };
    return (
      <span className="chat-fig" {...binding}>
        <span className="figure num commentary-fig" title={formatMoney(figure.cents)}>
          {roundedWords(figure.cents)}
        </span>
      </span>
    );
  }
  if (read && typeof onOpenCell === "function") {
    // Quoted keys, as EventFigure spells them: a hyphenated JSX attribute next to a money
    // name reads as a subtraction to tests/no-arithmetic.test.js, and there is none here.
    const binding = { "data-figure": figureRef, "data-cents": String(figure.cents), "data-measured": "true" };
    return (
      <span className="chat-fig" {...binding}>
        <button
          type="button"
          className="figure num figure-source commentary-fig"
          data-opens="cell"
          aria-label={`${formatMoney(figure.cents)}. Opens its cell in the workbook`}
          onClick={() => onOpenCell({ sheet: "Figures", figureRef, cellRef: typeof figure.cellRef === "string" ? figure.cellRef : null })}
        >
          {rounded ? roundedWords(figure.cents) : formatMoney(figure.cents)}
        </button>
      </span>
    );
  }
  return <EventFigure figure={figure} figureRef={figureRef} />;
}

/**
 * The paragraph's pieces with each parenthesised figure group ("($0.00 → $4,800.00)") held
 * together: a line never ends on "(" with its figures on the next (critique r1 #16; WIG
 * content). Returns a list of { t: "text" | "fig", ... } and { t: "group", parts: [...] }.
 * A "(" whose ")" never comes is left as it was, so no text is lost.
 */
export function groupFigures(parts) {
  const out = [];
  let group = null;
  for (const part of parts) {
    if (part.t !== "text") {
      (group ? group.parts : out).push(part);
      continue;
    }
    let rest = part.v;
    while (rest) {
      if (group) {
        const close = rest.indexOf(")");
        if (close === -1) {
          group.parts.push({ t: "text", v: rest });
          rest = "";
        } else {
          group.parts.push({ t: "text", v: rest.slice(0, close + 1) });
          out.push(group);
          group = null;
          rest = rest.slice(close + 1);
        }
        continue;
      }
      const open = rest.lastIndexOf("(");
      if (open === -1 || rest.indexOf(")", open) !== -1) {
        out.push({ t: "text", v: rest });
        rest = "";
      } else {
        if (open > 0) out.push({ t: "text", v: rest.slice(0, open) });
        group = { t: "group", parts: [{ t: "text", v: "(" }] };
        rest = rest.slice(open + 1);
      }
    }
  }
  if (group) out.push(...group.parts);
  return out;
}

/** A title's middle dot never starts a line: the space before it is a no-break space. */
export function keepDot(title) {
  return String(title).replace(/ \u00b7 /g, "\u00a0\u00b7 ");
}

function Paragraph({ paragraph, figures, onOpenCell, rounded = false }) {
  const parts = groupFigures(bindFigures(paragraph.text, figures));
  const draw = (part, i) =>
    part.t === "group" ? (
      <span key={i} className="commentary-figgroup">
        {part.parts.map(draw)}
      </span>
    ) : part.t === "text" ? (
      <span key={i}>{part.v}</span>
    ) : (
      <Fig key={i} figure={part.figure} figureRef={part.ref} onOpenCell={onOpenCell} rounded={rounded} />
    );
  return (
    <p className="commentary-p" data-added-by={paragraph.addedBy || undefined}>
      {parts.map(draw)}
      {paragraph.addedBy ? <span className="commentary-added t-footnote"> · added by {paragraph.addedBy}</span> : null}
    </p>
  );
}

/**
 * `artifact` carries `commentary` and `figures`; `onOpenWorkbook` goes back to the card;
 * `onOpenCell({sheet, figureRef, cellRef})` opens a figure's cell; `save(artifactId,
 * body)` sends the edits and resolves `{ok, version?, message?}` (F-WIRE's road; absent,
 * Save changes says it isn't connected). `initial` seeds `{editing, drafts}` for tests.
 */
/**
 * How a figure opens its Figures cell here, or null when it can't: `onOpenCell` when given,
 * else the pane, when this commentary's workbook in the conversation has a Figures tab.
 */
export function cellRoad(artifact, { onOpenCell = null, pane = null } = {}) {
  if (typeof onOpenCell === "function") return onOpenCell;
  if (!pane || typeof pane.open !== "function" || typeof pane.artifact !== "function") return null;
  const workbook = pane.artifact(workbookOf(artifact, "commentary"));
  if (!drillRow(workbook, { sheet: "Figures" })) return null;
  return ({ sheet, figureRef }) => {
    const at = drillRow(workbook, { sheet, key: figureRef });
    if (at) pane.open({ artifactId: at.artifactId, sheet: at.sheet, row: at.row });
  };
}

export default function Commentary({ artifact, onOpenWorkbook = null, onOpenCell: givenOpenCell = null, save = saveCommentary, initial = null }) {
  const onOpenCell = cellRoad(artifact, { onOpenCell: givenOpenCell, pane: usePane() });
  const commentary = commentaryOf(artifact);
  const figures = (artifact && artifact.figures) || {};
  const seed = isObj(initial) ? initial : {};
  const [editing, setEditing] = useState(seed.editing === true);
  const [drafts, setDrafts] = useState(() => (isObj(seed.drafts) ? { ...startDrafts(commentary, figures), ...seed.drafts } : startDrafts(commentary, figures)));
  const [busy, setBusy] = useState(false);
  const [outcome, setOutcome] = useState(null);
  // DA2-039: two quiet view toggles in the head, both off at rest. "Show sources" marks
  // every figure as the cell it is; "Rounded" writes figures short for reading.
  const [sources, setSources] = useState(false);
  const [rounded, setRounded] = useState(false);
  const dirty = Boolean(commentaryOf(artifact)) && editing && draftsChanged(commentaryOf(artifact), (artifact && artifact.figures) || {}, drafts);
  useUnsavedWarning(dirty);

  const back =
    typeof onOpenWorkbook === "function" ? (
      <button type="button" className="btn btn-secondary btn-sm commentary-back" onClick={onOpenWorkbook}>
        Open workbook
      </button>
    ) : null;

  if (!commentary) {
    return (
      <div className="chat-sheet-note" data-view="commentary" data-drawn="false">
        <p>This result carries no commentary. The draft is in the workbook.</p>
        {back}
      </div>
    );
  }

  const changed = editing && draftsChanged(commentary, figures, drafts);
  const saveReason = !changed ? NOTHING_CHANGED : typeof save !== "function" ? NOT_CONNECTED : null;
  const missing = Array.isArray(commentary.missing) ? commentary.missing.filter((m) => isObj(m) && typeof m.words === "string" && m.words.trim()) : [];

  async function send() {
    if (busy || saveReason) return;
    const built = commentaryEdits(commentary, figures, drafts);
    if (!built.ok) {
      setOutcome({ ok: false, message: built.message });
      return;
    }
    setBusy(true);
    setOutcome(null);
    let answer;
    try {
      answer = await save(artifact.artifactId, built.body);
    } catch {
      answer = null;
    }
    setBusy(false);
    if (answer && answer.ok) {
      setEditing(false);
      setOutcome({ ok: true, message: Number.isInteger(answer.version) ? `Saved as v${answer.version}. The workbook has the new version.` : "Saved. Vert will show the new version once the workbook is updated." });
      return;
    }
    setOutcome({ ok: false, message: (answer && answer.message) || "Not saved. Nothing was changed." });
  }

  const stopEditing = () => {
    setEditing(false);
    setDrafts(startDrafts(commentary, figures));
  };

  return (
    <article className="commentary" data-view="commentary" data-version={commentary.version} data-editing={editing ? "true" : "false"} data-sources={sources ? "on" : undefined}>
      {/* DA2-039: the title is the pane head's, said once; this head is the draft's
          state and the view's tools. */}
      <header className="commentary-head">
        <div className="commentary-heading">
          <p className="commentary-meta t-footnote">Draft v{commentary.version} · every figure is a cell in the workbook</p>
          {!editing ? <p className="commentary-hint t-footnote">{FIGURE_HINT}</p> : null}
        </div>
        {!editing ? (
          <div className="commentary-tools" data-commentary-tools="">
            <button type="button" className="commentary-toggle" aria-pressed={sources ? "true" : "false"} onClick={() => setSources((v) => !v)} data-commentary-toggle="sources">
              Show sources
            </button>
            <button type="button" className="commentary-toggle" aria-pressed={rounded ? "true" : "false"} onClick={() => setRounded((v) => !v)} data-commentary-toggle="rounded">
              Rounded
            </button>
            <Button variant="quiet" size="sm" icon={<IconEdit size={14} aria-hidden="true" />} onClick={() => setEditing(true)} data-commentary-press="edit">
              Edit
            </Button>
            {back}
          </div>
        ) : null}
      </header>

      {editing ? (
        <div className="commentary-editbar" role="group" aria-label="Editing the commentary" data-commentary-tools="">
          <p className="commentary-note t-footnote">Editing. Numbers you type stay yours: they show as added by you, and aren't counted as Vert's figures.</p>
          <span className="commentary-editbar-actions">
            <Button variant="quiet" size="sm" onClick={stopEditing} data-commentary-press="cancel">
              Cancel
            </Button>
            <Button variant="secondary" size="sm" onClick={send} busy={busy} busyLabel="Saving…" disabledReason={saveReason} data-commentary-press="save">
              Save changes
            </Button>
          </span>
        </div>
      ) : null}

      {outcome ? (
        <Notice kind={outcome.ok ? "completion" : "error"} recorded={outcome.ok ? undefined : "nothing"}>
          {outcome.message}
        </Notice>
      ) : null}

      {commentary.sections.map((s) => {
        const paras = Array.isArray(s.paragraphs) ? s.paragraphs : [];
        const yours = s.key === FOR_YOU_TO_ADD;
        return (
          <section key={s.key} className="commentary-section" data-commentary-section={s.key}>
            <div className="commentary-section-head">
              <h3 className="commentary-h t-title-3">{s.title}</h3>
              {!editing && headlineRef(s, figures) ? (
                <span className="commentary-headline">
                  <Fig figure={figures[headlineRef(s, figures)]} figureRef={headlineRef(s, figures)} onOpenCell={onOpenCell} rounded={rounded} />
                </span>
              ) : null}
            </div>
            {editing ? (
              (paras.length ? paras : [null]).map((p, i) => {
                const k = draftKey(s.key, i);
                return (
                  <label key={k} className="commentary-field">
                    <span className="chat-visually-hidden">{`${s.title}, paragraph ${i + 1}`}</span>
                    <textarea
                      className="field-input commentary-input"
                      name={`commentary-${k}`}
                      autoComplete="off"
                      rows={yours ? 4 : 3}
                      value={drafts[k] ?? ""}
                      placeholder={yours ? ADD_PROMPT : undefined}
                      onChange={(e) => {
                        const v = e.target.value;
                        setDrafts((d) => ({ ...d, [k]: v }));
                      }}
                    />
                  </label>
                );
              })
            ) : paras.length ? (
              paras.map((p, i) => <Paragraph key={i} paragraph={p} figures={figures} onOpenCell={onOpenCell} rounded={rounded} />)
            ) : yours ? (
              <p className="commentary-prompt" data-commentary-prompt="">
                {ADD_PROMPT}
              </p>
            ) : (
              <p className="commentary-prompt">Nothing in this section yet.</p>
            )}
          </section>
        );
      })}

      {missing.length ? (
        <section className="commentary-section commentary-missing" data-commentary-missing="">
          <h3 className="commentary-h t-title-3">Not in this draft</h3>
          <ul className="commentary-missing-list">
            {missing.map((m, i) => (
              <li key={i}>{m.words}</li>
            ))}
          </ul>
        </section>
      ) : null}
    </article>
  );
}
