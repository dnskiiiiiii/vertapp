"use client";

// components/chat/results/DocumentView.js — A FILE YOU GAVE VERT, OPEN IN THE PANE
// ==============================================================================
// Build plan §19.8 F-FILES, §19.2 (`artifact.document`). A file attached in the
// composer, uploaded into a file question, or read by a task is one chip; pressing the
// chip opens this view beside the conversation: the file's name, what Vert could read
// of it (every page, or which pages it could not, in words), each page as the engine
// rendered it with its text, or a workbook's sheets. "Open the file ↗" is the bytes as
// stored, through the app (app/api/documents/[id]/file).
//
// WHAT IS NOT HERE, ON PURPOSE. No merge and no split button and no chip menu: those
// are chat commands ("merge the two invoices", "split pages 3–5 out"), done by the
// chat's tools on DOCX's functions, so the pane has one job — showing the file — and
// no control whose result would have to be explained somewhere else (§19.0, F-FILES).
//
// UNREAD IS SAID, NEVER BLANK. A page the engine could not read carries its reason
// ("scanned, and this deployment has no OCR"), and a workbook whose reading was not
// recorded says so; an empty page list would read as "the file is empty", which is a
// claim nobody measured.
//
// The pure helpers below (the chip, the attachment line, the thread's files) are what
// the composer, the header and the context sheet share, so a file is named one way
// everywhere (tests/files-in-chat.test.js).

import { useEffect, useId, useState } from "react";
import { Sheet } from "@/components/ui";
import { anchorOrigin } from "@/lib/agent/pane";

/** What the composer and a widened file question take (§19.2 `FILE_ACCEPTS`). */
export const DOCUMENT_ACCEPT = ".csv,.xlsx,.pdf,.png,.jpg";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** pdf | xlsx | csv | image, from the stored type first and the name second. */
export function documentKind(mediaType, name = "") {
  const t = typeof mediaType === "string" ? mediaType.toLowerCase() : "";
  const n = typeof name === "string" ? name.toLowerCase() : "";
  if (t === "application/pdf") return "pdf";
  if (t.startsWith("image/")) return "image";
  if (t === "text/csv") return "csv";
  if (t.includes("spreadsheetml") || t.includes("ms-excel")) return "xlsx";
  if (/\.pdf$/.test(n)) return "pdf";
  if (/\.csv$/.test(n)) return "csv";
  if (/\.xls[xm]?$/.test(n)) return "xlsx";
  if (/\.(png|jpe?g|tiff?)$/.test(n)) return "image";
  return "pdf";
}

function plural(n, one, many = `${one}s`) {
  return `${n} ${n === 1 ? one : many}`;
}

/**
 * One file as a chip: `{ documentId, name, kind, detail }`, or null. `detail` is what
 * was read, in words ("3 pages", "2 of 3 pages read", "2 sheets"), or null when the
 * body did not say; never "0 pages" for a count nobody took.
 */
export function documentChip(doc) {
  if (!doc || typeof doc !== "object") return null;
  const documentId = typeof doc.documentId === "string" && UUID.test(doc.documentId) ? doc.documentId : null;
  const name = [doc.originalFilename, doc.name].find((v) => typeof v === "string" && v.trim());
  if (!documentId || !name) return null;
  const kind = ["pdf", "xlsx", "csv", "image"].includes(doc.kind) && doc.kind !== "pdf" ? doc.kind : documentKind(doc.mediaType, name);
  let detail = null;
  const sheets = doc.workbook && Array.isArray(doc.workbook.sheets) ? doc.workbook.sheets : null;
  const pages = Number.isInteger(doc.pageCount) ? doc.pageCount : Number.isInteger(doc.pages) ? doc.pages : null;
  const indexed = Number.isInteger(doc.indexedPageCount) ? doc.indexedPageCount : doc.reading && Number.isInteger(doc.reading.indexedPageCount) ? doc.reading.indexedPageCount : null;
  if (sheets) detail = plural(sheets.length, "sheet");
  else if (pages !== null && indexed !== null && indexed < pages) detail = `${indexed} of ${plural(pages, "page")} read`;
  else if (pages !== null) detail = plural(pages, "page");
  // A FILE VERT COULD NOT OPEN says so on its chip (verify pass 1, S-FL-1): a garbage or
  // truncated PDF attached as an ordinary chip, while the upload's own answer said it
  // "could not be opened" and that nothing about it can be concluded.
  const problem = unopenedSentence(doc, name.trim()) || unreadWorkbookSentence(doc, name.trim());
  if (problem) detail = unopenedSentence(doc, name.trim()) ? "Couldn't be opened" : "Not read";
  return { documentId, name: name.trim(), kind, detail, ...(problem ? { problem } : {}) };
}

/**
 * The sentence for an upload Vert could not open, with what to do, or null when it was
 * opened. Read from the upload's own answer: no page count measured and every extraction
 * failed (`failureReason`), or the reading says nothing was measured with no pages. Pure.
 */
export function unopenedSentence(doc, name = "This file") {
  if (!doc || typeof doc !== "object") return null;
  const ex = Array.isArray(doc.extractions) ? doc.extractions : [];
  const allFailed = ex.length > 0 && ex.every((e) => e && typeof e.failureReason === "string" && e.failureReason.trim() && !e.complete && !e.pagesExtracted);
  const reading = doc.reading && typeof doc.reading === "object" ? doc.reading : null;
  const noPages = doc.pageCount === null || doc.pageCount === undefined;
  const unmeasured = reading && reading.measured === false && noPages && !(Array.isArray(doc.workbook && doc.workbook.sheets) && doc.workbook.sheets.length);
  if (!(allFailed && noPages) && !(unmeasured && allFailed)) return null;
  return `Vert couldn't open ${name}, so nothing in it was read. Check that it opens on your computer, then export or scan it again and attach the new copy.`;
}

/**
 * A workbook Vert stored but did not read, said on its chip (verify pass 3, S-FL-5: the
 * cells-300k upload attached as an ordinary chip while the engine's answer said it was
 * "not measured: more than 250000 populated cells"). Null when it was read. Pure.
 */
export function unreadWorkbookSentence(doc, name = "This workbook") {
  const wb = doc && doc.workbook && typeof doc.workbook === "object" ? doc.workbook : null;
  if (!wb || wb.measured !== false) return null;
  const why = typeof wb.notMeasuredReason === "string" && wb.notMeasuredReason.trim() ? wb.notMeasuredReason.trim().replace(/[.]$/, "") : null;
  return `Vert stored ${name} but didn't read it${why ? `: ${why}` : ""}.`;
}

/** Where the stored bytes open, through the app (never the engine's own path). */
export function fileHref(documentId) {
  return `/api/documents/${encodeURIComponent(documentId)}/file`;
}

/* ── the attachment line: how a sent file travels with your message ───────────── */

const ATTACHED = /^Attached file: (.+) \(document ([0-9a-f-]{36})\)$/i;

/**
 * The lines a message carries for its attached files, one per file. Plain words, so
 * the person reads what was sent in their own turn and the chat's tools read the
 * document id from the same text: nothing about the file is hidden from either.
 */
export function attachmentLines(chips) {
  return (Array.isArray(chips) ? chips : []).filter((c) => c && UUID.test(c.documentId) && c.name).map((c) => `Attached file: ${c.name.replace(/[\r\n]+/g, " ")} (document ${c.documentId})`);
}

/** A message's own words and the files it carried, read back from its text. */
export function splitAttachments(text) {
  const lines = typeof text === "string" ? text.split("\n") : [];
  const files = [];
  const kept = [];
  for (const line of lines) {
    const m = ATTACHED.exec(line.trim());
    if (m && UUID.test(m[2])) files.push({ documentId: m[2].toLowerCase(), name: m[1], kind: documentKind(null, m[1]), detail: null });
    else kept.push(line);
  }
  return { text: kept.join("\n").trim(), files };
}

/**
 * Every file this conversation holds, once each, in the order it arrived: attached to
 * a message, uploaded into a file question, or shown by a result (`artifact.document`).
 * The header counts these and the context sheet lists them.
 */
export function filesOfThread(thread) {
  const items = thread && Array.isArray(thread.items) ? thread.items : [];
  const seen = new Map();
  const add = (chip) => {
    if (chip && !seen.has(chip.documentId)) seen.set(chip.documentId, chip);
  };
  for (const item of items) {
    if (!item) continue;
    if (item.kind === "you") splitAttachments(item.text).files.forEach(add);
    // What Vert made in the chat (a merge, a split, a tables workbook): filed under this
    // conversation, so the context sheet lists them, and the count must too (D39).
    else if (item.kind === "files" && Array.isArray(item.files)) item.files.forEach(add);
    // ...or delivered under the answer that made them (verify pass 3, D39).
    else if (item.kind === "answer" && Array.isArray(item.made)) item.made.forEach(add);
    else if (item.kind === "result" && item.artifact && item.artifact.document) add(documentChip(item.artifact.document));
    else if (item.kind === "question" && item.form && item.form.kind === "file" && item.answer) {
      const v = item.answer.value;
      const id = (v && typeof v === "object" && v.documentId) || item.answer.documentId;
      if (typeof id === "string" && UUID.test(id)) add({ documentId: id, name: (v && v.name) || "Uploaded file", kind: documentKind(null, (v && v.name) || ""), detail: null });
    }
  }
  return [...seen.values()];
}

/** "1 file", "3 files", or null when there are none (the header draws nothing then). */
export function fileCountWords(files) {
  const n = Array.isArray(files) ? files.length : 0;
  return n ? plural(n, "file") : null;
}

// vert_engine/documents/intake.py MAX_UPLOAD_BYTES, as lib/documents.js holds it.
export const MAX_ATTACH_BYTES = 25 * 1024 * 1024;

/** The conversation id in a `/chat/{id}` path, or null. */
export function sessionFromPath(pathname) {
  const m = typeof pathname === "string" ? /^\/chat\/([^/?#]+)/.exec(pathname) : null;
  return m ? decodeURIComponent(m[1]) : null;
}

/**
 * Send one file to the app's documents route. `{ ok, chip }` or `{ ok: false, message }`.
 * Never throws: a refusal is words under the box, and the box keeps what you typed.
 */
export async function uploadFile(file, { session = null, fetchImpl = globalThis.fetch } = {}) {
  if (!file || !file.name) return { ok: false, message: "Choose a file to attach." };
  // The engine's 25 MB limit, said before 25 MB is sent to be told so (D37).
  if (typeof file.size === "number" && file.size > MAX_ATTACH_BYTES) {
    return { ok: false, message: `${file.name} is larger than 25 MB, so it wasn't sent. Nothing was stored.` };
  }
  const form = new FormData();
  form.append("file", file, file.name);
  if (session) form.append("session", session);
  try {
    const response = await fetchImpl("/api/documents", { method: "POST", body: form });
    const body = await response.json().catch(() => null);
    const chip = body && body.ok ? documentChip(body.document) : null;
    if (response.ok && chip) return { ok: true, chip };
    return { ok: false, message: (body && body.message) || `${file.name} wasn't read. Nothing was stored.` };
  } catch {
    return { ok: false, message: `${file.name} didn't reach Vert. Nothing was stored.` };
  }
}

/* ── the chip and the view ─────────────────────────────────────────────────────── */

const GLYPH = { pdf: "PDF", xlsx: "XLS", csv: "CSV", image: "IMG" };

/** Where a pane opened from `el` grows from (apple-design: a sheet is anchored to its trigger). */
export function originOf(el) {
  if (!el || typeof el.getBoundingClientRect !== "function" || typeof window === "undefined") return null;
  return anchorOrigin(el.getBoundingClientRect(), { width: window.innerWidth, height: window.innerHeight });
}

/** A file chip: one press opens the file in the pane. Ink, never the accent. */
export function FileChip({ chip, onOpen, onRemove = null, busy = false }) {
  if (!chip) return null;
  return (
    <span className="chat-file-chip" data-file-chip={chip.documentId || ""} data-kind={chip.kind}>
      <button type="button" className="chat-file-chip-open" disabled={busy || typeof onOpen !== "function"} onClick={(event) => onOpen(chip, originOf(event.currentTarget))}>
        <span className="chat-file-chip-kind" aria-hidden="true">{GLYPH[chip.kind] || "FILE"}</span>
        <span className="chat-file-chip-name">{chip.name}</span>
        {chip.detail ? <span className="chat-file-chip-detail">{chip.detail}</span> : null}
      </button>
      {chip.problem ? (
        <span className="chat-file-chip-problem t-footnote" role="status" data-file-unopened="">
          {chip.problem}
        </span>
      ) : null}
      {typeof onRemove === "function" ? (
        <button type="button" className="chat-file-chip-remove" aria-label={`Remove ${chip.name}`} onClick={() => onRemove(chip)}>
          ✕
        </button>
      ) : null}
    </span>
  );
}

/** Read one document through the app. Never throws. */
export async function fetchDocument(documentId, fetchImpl = globalThis.fetch) {
  try {
    const response = await fetchImpl(`/api/documents/${encodeURIComponent(documentId)}`, { cache: "no-store" });
    const body = await response.json().catch(() => null);
    if (response.ok && body && body.ok && body.document) return { ok: true, document: body.document };
    return { ok: false, message: (body && body.message) || "Vert couldn't open that file just now." };
  } catch {
    return { ok: false, message: "Vert couldn't open that file just now." };
  }
}

/** What Vert read of the file, in one sentence; never a silent blank. */
export function readingWords(doc) {
  if (!doc) return null;
  if (doc.kind === "workbook") {
    const wb = doc.workbook;
    if (!wb || !wb.measured) return `Not opened yet: ${(wb && wb.notMeasuredReason) || "Vert has no record of opening this workbook"}.`;
    return `Read ${plural(Array.isArray(wb.sheets) ? wb.sheets.length : 0, "sheet")}.`;
  }
  if (!Number.isInteger(doc.pageCount)) return doc.pageCountNotMeasuredReason ? `Pages not counted: ${doc.pageCountNotMeasuredReason}` : "Its pages weren't counted.";
  const unread = doc.reading && Array.isArray(doc.reading.unreadPages) ? doc.reading.unreadPages : [];
  if (!unread.length) return `Read all ${plural(doc.pageCount, "page")}.`;
  return `Read ${doc.pageCount - unread.length} of ${plural(doc.pageCount, "page")}; page${unread.length === 1 ? "" : "s"} ${unread.join(", ")} couldn't be read.`;
}

/** The document's body, once fetched: pages with their text, or sheets. */
export function DocumentBody({ doc }) {
  if (!doc) return null;
  if (doc.kind === "workbook") {
    const sheets = doc.workbook && Array.isArray(doc.workbook.sheets) ? doc.workbook.sheets : [];
    return (
      <ul className="chat-doc-sheets">
        {sheets.map((s) => (
          <li key={s.index}>
            <span className="chat-doc-sheet-name">{s.name}</span>
            <span className="chat-doc-sheet-size">{Number.isInteger(s.maxRow) ? plural(s.maxRow, "row") : "size not read"}</span>
          </li>
        ))}
      </ul>
    );
  }
  const pages = Array.isArray(doc.pages) ? doc.pages : [];
  return (
    <ol className="chat-doc-pages">
      {pages.map((p) => (
        <li key={p.pageNumber} className="chat-doc-page" data-page={p.pageNumber}>
          <p className="chat-doc-page-label">Page {p.pageNumber}</p>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="chat-doc-page-image" src={`/api/documents/${encodeURIComponent(doc.documentId)}/pages/${p.pageNumber}/image`} alt={`Page ${p.pageNumber} of ${doc.originalFilename}`} loading="lazy" />
          {p.read ? null : <p className="chat-doc-page-unread">Not read: {p.notReadReason || "this page's text wasn't read"}.</p>}
        </li>
      ))}
    </ol>
  );
}

/**
 * The pane: `chip` names the file before its body arrives, so the title is there at
 * the first frame (A11: a pressed state within 100 ms, never a blank wait).
 */
export default function DocumentView({ chip, open = true, origin = null, onClose, load = fetchDocument }) {
  const titleId = useId();
  const [state, setState] = useState({ id: null, doc: null, error: null });
  const id = chip ? chip.documentId : null;
  useEffect(() => {
    if (!open || !id) return undefined;
    let live = true;
    load(id).then((r) => {
      if (live) setState(r.ok ? { id, doc: r.document, error: null } : { id, doc: null, error: r.message });
    });
    return () => {
      live = false;
    };
  }, [open, id, load]);
  if (!open || !chip) return null;
  const current = state.id === id ? state : { doc: null, error: null };
  return (
    <Sheet open side="right" labelledBy={titleId} onClose={onClose} origin={origin || undefined} className="chat-doc-sheet">
      <div className="chat-sheet chat-sheet-right chat-doc" data-document-view={id}>
        <div className="chat-sheet-head">
          <h2 className="chat-sheet-title" id={titleId} tabIndex={-1}>
            {chip.name}
          </h2>
          <button type="button" className="chat-close" aria-label="Close" onClick={onClose}>
            ✕
          </button>
        </div>
        <p className="chat-doc-reading">{current.doc ? readingWords(current.doc) : current.error || "Opening the file…"}</p>
        <p className="chat-sheet-link">
          <a href={fileHref(id)} target="_blank" rel="noreferrer">
            Open the file ↗
          </a>
        </p>
        <DocumentBody doc={current.doc} />
      </div>
    </Sheet>
  );
}
