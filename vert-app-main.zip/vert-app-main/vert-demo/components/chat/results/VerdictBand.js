// components/chat/results/VerdictBand.js — THE RESULT'S CONCLUSION, FIRST
// ==============================================================================
// Spec §1.5 and UI-023: a result leads with its verdict, in one line, before any
// table. The tone follows the engine's own `ok`; a result that did not say is neutral,
// never green.

import BoundText from "../BoundText";

export default function VerdictBand({ text, ok = null, figures, ledgerName }) {
  const tone = ok === true ? "done" : ok === false ? "attention" : "neutral";
  return (
    <p className="chat-verdict-band" data-tone={tone}>
      <BoundText text={text} figures={figures} ledgerName={ledgerName} />
    </p>
  );
}
