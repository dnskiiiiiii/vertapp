"use client";

// components/chat/results/Workpaper.js — THE MONTH'S WORKING PAPERS
// ==============================================================================
// The verdict, the engine's figures, and the two ways to take the paper away: open it
// on screen, or download the workbook the engine built. Both are links; neither
// decides anything. Each is drawn only when a route in this app serves it
// (lib/agent/links.js): the engine's own paths answer the app's 404 page.
//
// A SAVED VERSION DOWNLOADS AS ITSELF (§19.10 F-EDIT). Once a person has saved an edit
// (`artifact.version` ≥ 1) the house workbook would be a rebuild from the table that
// drops the edit, so Download fetches the latest version through the app's workpapers
// route instead.
//
// THE BINDER IS A ZIP WITH CONTENTS (verify pass 3, D35 / S-E2E-6). The month's binder
// result has no table and its href is `/workpapers/binder.zip`, which this app did not
// serve, so its pane was the verdict and nothing else: no download, no list. It now
// downloads through app/api/workpapers/binder and lists what the zip holds, read from
// the engine's index of the month's delivered workbooks.

import { useEffect, useState } from "react";
import VerdictBand from "./VerdictBand";
import KeyFigures from "./KeyFigures";
import { appHref } from "@/lib/agent/links";
import { workbookHref } from "@/app/api/workpapers/shared";

import { IconCaretRight } from "@/components/ui/icons";

const BINDER = /^\/workpapers\/binder\.zip\?(?:.*&)?period=([0-9]{4}-(?:0[1-9]|1[0-2]))(?:&|$)/;

/** The binder's month when this artifact is the month's binder, else null. Pure. */
export function binderPeriod(artifact) {
  const m = artifact && typeof artifact.xlsxHref === "string" ? BINDER.exec(artifact.xlsxHref) : null;
  return m ? m[1] : null;
}

function BinderContents({ period }) {
  const [state, setState] = useState({ status: "reading", contents: [] });
  useEffect(() => {
    let live = true;
    fetch(`/api/workpapers/binder?period=${period}&contents=1`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
      .then((body) => live && setState({ status: "read", contents: Array.isArray(body && body.contents) ? body.contents : [] }))
      .catch(() => live && setState({ status: "unread", contents: [] }));
    return () => {
      live = false;
    };
  }, [period]);
  if (state.status === "reading") return <p className="chat-sheet-note" aria-live="polite">Reading what the binder holds…</p>;
  if (state.status === "unread") return <p className="chat-sheet-note">Vert couldn’t read the binder’s contents list. The download still holds every workbook, with its own contents list.</p>;
  if (!state.contents.length) return <p className="chat-sheet-note">No workbook has been delivered for this month yet.</p>;
  return (
    <div className="binder-contents" data-binder-contents="">
      <p className="chat-sheet-note">In the zip, numbered in the order the month’s conversations ran:</p>
      <ol className="binder-list">
        {state.contents.map((title, i) => (
          <li key={`${i}-${title}`}>{title}</li>
        ))}
      </ol>
    </div>
  );
}

export default function Workpaper({ artifact, ledgerName }) {
  const href = appHref(artifact.href);
  const saved = Number.isInteger(artifact.version) && artifact.version > 0 && artifact.artifactId;
  const xlsx = saved ? workbookHref(artifact.artifactId, artifact.version) : appHref(artifact.xlsxHref);
  const binder = saved ? null : binderPeriod(artifact);
  return (
    <div className="chat-result-body-inner">
      <VerdictBand text={artifact.verdict || ""} ok={artifact.ok ?? null} figures={artifact.figures} ledgerName={ledgerName} />
      <KeyFigures figures={artifact.figures} />
      {binder ? <BinderContents period={binder} /> : null}
      <p className="chat-sheet-link">
        {href ? <a href={href}>Open the working paper<IconCaretRight className="caret-trailing" /></a> : null}
        {xlsx ? (
          <>
            {" "}
            <a href={xlsx} download={binder ? `${artifact.title || "Workpapers binder"}.zip` : undefined} data-binder-download={binder ? "" : undefined}>
              {binder ? "Download the binder" : "Download Excel"}
            </a>
          </>
        ) : null}
      </p>
    </div>
  );
}
