"use client";

// components/chat/results/useMoreToTheRight.js — IS A TABLE CUT AT ITS BOX'S RIGHT EDGE?
// ==============================================================================
// Shared by the plan's tables and the result pane's sheets (W07, critique r1 #5): the
// edge fades while columns sit beyond it, so a cut column is never silent.

import { useEffect, useState } from "react";

/**
 * True while a table's box has columns hidden to its right, so the right edge fades
 * (spec §6.5; critique r1 #5: "6500 Repairs & mainte" was cut with no hint). Measured,
 * not a scroll-driven animation: a screenshot or a reduced-motion setting that finishes
 * animations used to drop the fade with the columns still hidden.
 */
export function useMoreToTheRight(ref) {
  const [more, setMore] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof window === "undefined") return undefined;
    const measure = () => setMore(el.scrollWidth - el.clientWidth - el.scrollLeft > 1);
    measure();
    el.addEventListener("scroll", measure, { passive: true });
    const seen = typeof ResizeObserver === "function" ? new ResizeObserver(measure) : null;
    if (seen) seen.observe(el);
    return () => {
      el.removeEventListener("scroll", measure);
      if (seen) seen.disconnect();
    };
  }, [ref]);
  return more;
}

/**
 * Which ends of a sideways strip have something past them: "start", "end", "both" or
 * null. The phone's sheet tabs fade at an end that has more (DA2-062; critic r1 F15:
 * "Relea" and "Sourc" were cut with no fade, because the strip's scroll-driven fade is
 * finished, and so gone, wherever animations are finished early).
 */
export function useStripEdges(ref) {
  const [edges, setEdges] = useState(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof window === "undefined") return undefined;
    const measure = () => {
      const start = el.scrollLeft > 1;
      const end = el.scrollWidth - el.clientWidth - el.scrollLeft > 1;
      setEdges(start && end ? "both" : start ? "start" : end ? "end" : null);
    };
    measure();
    el.addEventListener("scroll", measure, { passive: true });
    const seen = typeof ResizeObserver === "function" ? new ResizeObserver(measure) : null;
    if (seen) seen.observe(el);
    return () => {
      el.removeEventListener("scroll", measure);
      if (seen) seen.disconnect();
    };
  }, [ref]);
  return edges;
}
