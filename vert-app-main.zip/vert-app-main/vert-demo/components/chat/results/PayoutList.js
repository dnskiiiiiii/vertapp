// components/chat/results/PayoutList.js — THE PAYOUTS A TASK LOOKED AT
// ==============================================================================
// Transaction line first, never an id (spec §1.6); the status in one of the four
// words with its reason. The full list is Records; this is the slice the task is
// about.

import Link from "next/link";
import { StatusMark } from "@/components/ui";
import VerdictBand from "./VerdictBand";
import KeyFigures from "./KeyFigures";
import { transactionLine } from "@/lib/agent/words";

import { IconCaretRight } from "@/components/ui/icons";
export default function PayoutList({ artifact, ledgerName }) {
  const items = Array.isArray(artifact.items) ? artifact.items.filter((i) => i && i.line) : [];
  return (
    <div className="chat-result-body-inner">
      <VerdictBand text={artifact.verdict || ""} ok={artifact.ok ?? null} figures={artifact.figures} ledgerName={ledgerName} />
      <KeyFigures figures={artifact.figures} />
      {items.length ? (
        <ul className="chat-payout-list">
          {items.map((item, i) => (
            <li key={i}>
              <span className="chat-payout-line">{transactionLine(item.line)}</span>
              {item.word ? <StatusMark word={item.word}>{item.word}</StatusMark> : null}
              {item.reason ? <span className="chat-payout-reason">{item.reason}</span> : null}
            </li>
          ))}
        </ul>
      ) : null}
      <p className="chat-sheet-link">
        <Link href="/records">See all payouts<IconCaretRight className="caret-trailing" /></Link>
      </p>
    </div>
  );
}
