"use client";

// components/chat/results/DeskPane.js — THE SKILL AND BUDGETS, AS ON-DEMAND SHEETS
// ==============================================================================
// p1 chat (founders' review, 23 Oct 2026). "What Vert knows" (the skill) and Budgets
// used to open as panes on a desk, in the conversation's pane slot beside a narrowed
// rail (design-pass spec §6.11). The side of the conversation now holds only the data and
// sources (components/chat/SourcesPanel.js), so these open on demand as the kit's sheets
// at every width, exactly as they always did on a phone and on Month-end.
//
//   PaneOrSheet   takes the kit Sheet's props and draws the Sheet, portalled to <body>
//                 so it sits above the top bar (DA2-001) and its Close is reachable at
//                 every Tab stop. Closing it puts focus back in the conversation (DA2-085).

import { Sheet } from "@/components/ui";
import { Portal } from "@/components/ui/Portal";

/**
 * DA2-085: where focus goes when a sheet in a conversation closes and nothing in the
 * conversation opened it (a sheet opened from its URL, say): the conversation's title,
 * else its composer, never a sidebar row or the page itself.
 */
export function focusConversation() {
  if (typeof document === "undefined") return;
  const chat = document.querySelector(".chat");
  if (!chat) return;
  const at = document.activeElement;
  if (at && at !== document.body && chat.contains(at)) return;
  const title = chat.querySelector(".chat-main h1");
  if (title) {
    if (!title.hasAttribute("tabindex")) title.setAttribute("tabindex", "-1");
    title.focus({ preventScroll: true });
    if (document.activeElement === title) return;
  }
  const composer = chat.querySelector(".chat-composer textarea, .chat-main textarea");
  if (composer && typeof composer.focus === "function") composer.focus({ preventScroll: true });
}

/** After a close settles, put focus somewhere in the conversation if it fell outside it:
 *  the next frame, once the sheet has unmounted and its own focus return has run. */
function afterClose() {
  if (typeof window === "undefined" || typeof window.requestAnimationFrame !== "function") return;
  window.requestAnimationFrame(() => window.requestAnimationFrame(focusConversation));
}

/** The kit Sheet, portalled, with the conversation's focus rule on close. */
export default function PaneOrSheet({ open = true, title, onClose, footer, children, body: _body, ...sheet }) {
  const close = typeof onClose === "function" ? () => {
    onClose();
    afterClose();
  } : onClose;
  return (
    <Portal>
      <Sheet open={open} title={title} onClose={close} footer={footer} {...sheet}>
        {children}
      </Sheet>
    </Portal>
  );
}
