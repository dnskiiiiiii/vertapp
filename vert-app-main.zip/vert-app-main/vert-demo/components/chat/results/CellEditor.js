"use client";

// components/chat/results/CellEditor.js — CHANGE AN INPUT CELL IN THE PANE, THEN SAVE
// ==============================================================================
// Build plan §19.0.10 and §19.10 F-EDIT. A person changes an input cell of a workbook
// in the pane, presses "Save changes · Download", and the engine re-writes the file
// (POST /workpapers/{id}/cells, through lib/workpapers.js) as a new version, which then
// downloads. Formula cells are read-only here, as they are in the engine.
//
// WHICH CELLS ARE EDITABLE, AND WHY ONLY THOSE. The engine lists them: `artifact.editable`
// is the workbook's input cells as references ("Prepaid!C7"), and it never lists a formula
// cell (modify_workbook `input_cells`). The pane's table names each row's cell in its
// "cell" column, and only the "value" cell of a row whose reference is listed becomes an
// input. Everything else — a formula, a cell on a row the engine did not list, a value
// that is itself a formula — is drawn as text, exactly as before. A cell drawn as an
// input that the engine then refused would be an affordance that lies; a pane that
// guessed which cells were inputs would be a second implementation of the engine's rule.
//
// WHAT A PERSON TYPES IS READ, NEVER ROUNDED. A cell whose value now is a number takes
// an amount, sent as integer cents parsed from the text (no float ever holds money); a
// cell of words takes words. A typed formula is refused inline, before any press, as is
// an amount past the cent or an emptied cell — each says why, beside the cell.
//
// THE ONE PURPLE. "Save changes · Download" is the only accent on the pane, and it
// appears only once something has changed: it writes a new version. Discard is quiet.
// After a save the new version downloads at once, and the bar keeps a plain link to
// download it again, because a browser may block or the person may miss the file.
//
// ROWS VERT ADDED. When Vert lays a month into someone's workbook it adds rows the file
// did not have, and the file tints them (vert_engine/workpapers/style.py ADDED_ROW_TINT,
// the palest step of the tint scale). The pane tints the same rows (`row.added`) and
// says so in a legend in words, because a tint alone is invisible to a reader who
// cannot tell the colour apart.
//
// A WORKBOOK VERT GENERATED (eval r2 #7). A generated result's table is the month's
// schedule, not a list of cells, so it names no cell to change and the engine lists
// `editable` only for a workbook a person uploaded: in round 2 no generated pane had a
// single input. Such a pane now carries a quiet "Edit cells" press. It asks the engine
// for the input cells of the workbook as it now stands (GET /workpapers/{id}/cells, the
// same `input_cells` rule), and draws them as modify_workbook's table draws them: one
// row per cell, its line, its column and its value now, the value an input. The version
// the cells were read from is the one a save is sent against.

import { useCallback, useMemo, useState } from "react";
import { Button } from "@/components/ui/Button";
import { IconEdit } from "@/components/ui/icons";
import { useWritesEnabled } from "@/lib/engine-context";
import { readInputCells, saveCells } from "@/lib/workpapers";
import "./workbook-edit.css";

/** The column naming a row's workbook cell, and the column that holds its value. */
export const REF_COLUMN = "cell";
export const VALUE_COLUMN = "value";
export const ADDED_ROWS_LEGEND = "Rows Vert added are tinted";

// A number as the engine's `input_cells` writes one: `str(value)` of an int or float.
const NUMBER_NOW = /^-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?$/;
// An amount as a person types one, once any parentheses are taken off: an optional
// sign, an optional $, digits with or without thousands commas, at most two decimals.
const AMOUNT = /^(-)?\$?((?:\d{1,3}(?:,\d{3})+)|\d+)(?:\.(\d{1,2}))?$/;
const MANY_DECIMALS = /^\(?-?\$?(?:(?:\d{1,3}(?:,\d{3})+)|\d+)\.\d{3,}\)?$/;

/**
 * Integer cents for a typed amount, or null when the text is not an amount to the cent.
 * Parsed from the string — "1,200.5" is 120050 — so no float ever holds money.
 * "(300)" is the accountant's minus, and "-(300)" is refused as ambiguous.
 */
export function toCents(text) {
  let s = String(text ?? "").trim();
  const parens = s.startsWith("(") && s.endsWith(")");
  if (parens) s = s.slice(1, -1).trim();
  if (s.includes("(") || s.includes(")")) return null;
  const m = AMOUNT.exec(s);
  if (!m || (parens && m[1])) return null;
  const digits = `${m[2].replace(/,/g, "")}${(m[3] || "").padEnd(2, "0")}`.replace(/^0+(?=\d)/, "");
  if (digits.length > 15) return null;
  // The sign is written into the text before it is read: no operator touches money.
  const cents = Number((parens || m[1]) && /[1-9]/.test(digits) ? `-${digits}` : digits);
  return Number.isSafeInteger(cents) ? cents : null;
}

/**
 * A number the engine wrote as `str(value)` ("36000.0", "-1250.5"), shown the way the
 * sheet shows an amount: "36,000.00" (verify pass 1, U15: the editor showed raw floats).
 * By string only, so no arithmetic touches money; anything else is returned as it is.
 */
export function amountText(raw) {
  const s = String(raw ?? "").trim();
  const m = /^(-?)(\d+)(?:\.(\d+))?$/.exec(s);
  if (!m) return s;
  const frac = (m[3] || "").replace(/0+$/, "");
  if (frac.length > 2) return s;
  const whole = m[2].replace(/^0+(?=\d)/, "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${m[1]}${whole}.${frac.padEnd(2, "0")}`;
}

function isNumberNow(current) {
  return current === "" || NUMBER_NOW.test(String(current ?? "").trim());
}

/**
 * What a person typed into `cell`, as the engine's edit — `{ ok, edit }` — or why it
 * cannot be sent, in words — `{ ok: false, message }`. `current` is the cell's value now
 * (the engine's "Value now"); it decides whether the cell takes an amount or words.
 */
export function cellEdit(cell, typed, current) {
  const text = String(typed ?? "");
  const trimmed = text.trim();
  if (!trimmed) return { ok: false, message: "Vert can't empty a cell from here." };
  if (trimmed.startsWith("=")) return { ok: false, message: "Formulas can't be typed here; the workbook's own formulas stay as they are." };
  const now = String(current ?? "").trim();
  if (isNumberNow(now) && now !== "") {
    if (MANY_DECIMALS.test(trimmed)) return { ok: false, message: "Amounts are written to the cent." };
    const cents = toCents(trimmed);
    if (cents === null) return { ok: false, message: "This cell holds an amount. Type a number, like 1,250.00." };
    return { ok: true, edit: { cell, cents } };
  }
  if (now === "") {
    // An empty input cell takes either; an amount to the cent is sent as one.
    if (MANY_DECIMALS.test(trimmed)) return { ok: false, message: "Amounts are written to the cent." };
    const cents = toCents(trimmed);
    if (cents !== null) return { ok: true, edit: { cell, cents } };
  }
  if (trimmed.length > 1000) return { ok: false, message: "At most 1,000 characters." };
  return { ok: true, edit: { cell, text: trimmed } };
}

/**
 * The value a saved amount reads as in the "Value now" column, as the engine's
 * `str(value)` writes it ("1250", "1250.5", "-0.07"). Written from the digits of the
 * integer cents by string, so no division ever touches money.
 */
export function shownAfterSave(edit) {
  if (!edit) return "";
  if (Number.isInteger(edit.cents)) {
    const text = String(edit.cents);
    const sign = text.startsWith("-") ? "-" : "";
    const digits = text.replace("-", "").padStart(3, "0");
    const whole = digits.slice(0, -2).replace(/^0+(?=\d)/, "");
    const frac = digits.slice(-2).replace(/0+$/, "");
    return `${sign}${whole}${frac ? `.${frac}` : ""}`;
  }
  return edit.text;
}

/**
 * {rowIndex: { cell, current }} for the rows of `sheet` whose value cell a person may
 * change: the row names its cell in the "cell" column, the engine listed that reference
 * in `artifact.editable`, and the value now is not itself a formula.
 */
export function editableRows(artifact, sheet) {
  const listed = new Set(Array.isArray(artifact && artifact.editable) ? artifact.editable.filter((c) => typeof c === "string") : []);
  const out = {};
  if (!listed.size || !sheet) return out;
  const columns = Array.isArray(sheet.columns) ? sheet.columns.map((c) => c && c.key) : [];
  if (!columns.includes(REF_COLUMN) || !columns.includes(VALUE_COLUMN)) return out;
  (Array.isArray(sheet.rows) ? sheet.rows : []).forEach((row, i) => {
    const cells = row && row.cells && typeof row.cells === "object" ? row.cells : {};
    const cell = cells[REF_COLUMN];
    if (typeof cell !== "string" || !listed.has(cell)) return;
    const current = cells[VALUE_COLUMN] === null || cells[VALUE_COLUMN] === undefined ? "" : String(cells[VALUE_COLUMN]);
    if (current.trim().startsWith("=")) return;
    out[i] = { cell, current };
  });
  return out;
}

/** True when any row of `sheet` is one Vert added (tinted in the file and here). */
export function hasAddedRows(sheet) {
  return Boolean(sheet && Array.isArray(sheet.rows) && sheet.rows.some((r) => r && r.added === true));
}

/**
 * The edits state for one artifact: drafts typed, values saved, the version to save
 * against. `initial` is the server-render seam ({ drafts, saved }), as the plan
 * document's `initial` is: a render cannot type.
 */
export function useWorkbookEdits(artifact, { initial = null, save = saveCells } = {}) {
  const [drafts, setDrafts] = useState(() => ({ ...((initial && initial.drafts) || {}) }));
  const [saved, setSaved] = useState(() => (initial && initial.saved) || null);
  const [state, setState] = useState({ busy: false, error: null });
  const version = Math.max(Number.isInteger(artifact && artifact.version) ? artifact.version : 0, saved && Number.isInteger(saved.version) ? saved.version : 0);

  const valueOf = useCallback(
    (cell, current) => {
      if (Object.prototype.hasOwnProperty.call(drafts, cell)) return drafts[cell];
      if (saved && saved.values && Object.prototype.hasOwnProperty.call(saved.values, cell)) return saved.values[cell];
      return current;
    },
    [drafts, saved]
  );
  const baseOf = useCallback(
    (cell, current) => (saved && saved.values && Object.prototype.hasOwnProperty.call(saved.values, cell) ? saved.values[cell] : current),
    [saved]
  );

  const setDraft = useCallback((cell, value) => {
    setState((s) => (s.error ? { ...s, error: null } : s));
    setDrafts((d) => ({ ...d, [cell]: value }));
  }, []);
  const revert = useCallback((cell) => setDrafts((d) => {
    const next = { ...d };
    delete next[cell];
    return next;
  }), []);
  const discard = useCallback(() => {
    setDrafts({});
    setState({ busy: false, error: null });
  }, []);

  const submit = useCallback(
    async (pending) => {
      if (state.busy || !pending.length) return;
      setState({ busy: true, error: null });
      const out = await saveEdits({ artifactId: artifact.artifactId, pending, version, saved, save, target: artifact.target || null });
      if (!out.ok) {
        setState({ busy: false, error: out.message });
        return;
      }
      setSaved(out.saved);
      setDrafts({});
      setState({ busy: false, error: null });
      startDownload(out.saved.download);
    },
    [artifact, save, saved, state.busy, version]
  );

  return { drafts, saved, state, version, valueOf, baseOf, setDraft, revert, discard, submit };
}

/**
 * One save: send the ready edits against `version`, and on the engine's word return the
 * new saved state — the version, its download and the values now in the file. A refusal
 * keeps nothing and says so; the drafts stay where the person typed them.
 */
export async function saveEdits({ artifactId, pending, version, saved = null, save = saveCells, target = null }) {
  let out;
  try {
    // The workbook the cells were read from (D43): a copy's edit goes to the copy.
    out = target ? await save(artifactId, pending.map((p) => p.edit), version, target) : await save(artifactId, pending.map((p) => p.edit), version);
  } catch {
    out = null;
  }
  if (!out || !out.ok) return { ok: false, message: (out && out.message) || "The change didn't reach Vert. Nothing was saved." };
  if (!Number.isInteger(out.version) || out.version <= version || typeof out.download !== "string") {
    return { ok: false, message: "Vert didn't confirm the new version. Reload the workbook before saving again." };
  }
  const values = { ...((saved && saved.values) || {}) };
  for (const p of pending) values[p.edit.cell] = shownAfterSave(p.edit);
  return { ok: true, saved: { version: out.version, download: out.download, uncached: out.uncached || [], recomputed: out.recomputed || [], said: Array.isArray(out.said) ? out.said : [], values } };
}

/** Start the download of the version just written, in the page, with no navigation. */
function startDownload(href) {
  if (typeof document === "undefined" || typeof href !== "string" || !href.startsWith("/api/workpapers/")) return;
  const a = document.createElement("a");
  a.href = href;
  a.download = "";
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

/**
 * The edits ready to send and the cells that cannot be sent yet: every draft that differs
 * from the value it replaces, read through `cellEdit`.
 */
export function pendingEdits(edits, rows) {
  const ready = [];
  const invalid = {};
  for (const { cell, current } of Object.values(rows)) {
    if (!Object.prototype.hasOwnProperty.call(edits.drafts, cell)) continue;
    const draft = edits.drafts[cell];
    const base = edits.baseOf(cell, current);
    if (String(draft).trim() === String(base).trim()) continue;
    // "36,000.00" typed over "36000.0" is the same amount: not a change.
    if (isNumberNow(String(base).trim()) && String(base).trim() !== "" && toCents(String(draft).trim()) !== null && toCents(String(draft).trim()) === toCents(amountText(base))) continue;
    const read = cellEdit(cell, draft, base);
    if (read.ok) ready.push(read);
    else invalid[cell] = read.message;
  }
  return { ready, invalid };
}

/** One input cell in the grid: an input that looks like the cell it changes. */
export default function CellEditor({ cell, current, label, edits, invalid = null }) {
  const base = edits.baseOf(cell, current);
  const drafted = Object.prototype.hasOwnProperty.call(edits.drafts || {}, cell);
  const amount = isNumberNow(String(base).trim()) && String(base).trim() !== "";
  // An amount reads as the sheet writes it until it is typed over.
  const value = drafted ? edits.valueOf(cell, current) : amount ? amountText(base) : edits.valueOf(cell, current);
  const changed = drafted && String(value).trim() !== String(base).trim() && !(amount && toCents(String(value).trim()) === toCents(amountText(base)));
  const errorId = `cell-error-${cell.replace(/[^A-Za-z0-9]/g, "-")}`;
  return (
    <>
      <input
        className="cell-input"
        type="text"
        inputMode={amount ? "decimal" : "text"}
        spellCheck={false}
        autoComplete="off"
        name={`cell-${cell}`}
        value={value}
        data-cell={cell}
        data-changed={changed ? "true" : undefined}
        aria-label={label ? `${label}, cell ${cell}` : `Cell ${cell}`}
        aria-invalid={invalid ? "true" : undefined}
        aria-describedby={invalid ? errorId : undefined}
        onChange={(e) => edits.setDraft(cell, e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Escape") {
            e.stopPropagation();
            edits.revert(cell);
          } else if (e.key === "Enter") {
            e.currentTarget.blur();
          }
        }}
      />
      {invalid ? (
        <span className="cell-error" id={errorId} role="status">
          {invalid}
        </span>
      ) : null}
    </>
  );
}

/** The legend for tinted rows: a swatch and the words, never the tint alone. */
export function AddedRowsLegend() {
  return (
    <p className="added-legend" data-legend="added-rows">
      <span className="added-swatch" aria-hidden="true" />
      {ADDED_ROWS_LEGEND}
    </p>
  );
}

function plural(n, one, many) {
  return `${n} ${n === 1 ? one : many}`;
}

/**
 * The bar under the grid: what changed, Discard, and "Save changes · Download". With
 * nothing changed it shows only the last save's version and its link. Saving a workbook
 * writes a new version of the file, not the books, so it is the secondary button, never
 * the accent (design-pass spec §3.2: the accent means "this writes to the ledger").
 */
export function SaveBar({ edits, pending, always = false }) {
  const { ready, invalid } = pending;
  const blocked = Object.keys(invalid).length;
  const count = ready.length + blocked;
  const saved = edits.saved;
  if (!count && !saved && !edits.state.error && !always) return null;
  if (!count && !saved && !edits.state.error) {
    // In the editor (InputsGrid), the way to save is on screen before the first change (verify pass 1, U15: the
    // editor offered only "Done"), held with its reason.
    return (
      <div className="save-bar" data-save-bar="" role="group" aria-label="Workbook changes">
        <p className="save-bar-status" role="status" aria-live="polite" />
        <div className="save-bar-actions">
          <Button variant="secondary" size="sm" disabledReason="Change a cell first." data-edit-press="save">
            Save changes
          </Button>
        </div>
      </div>
    );
  }
  return (
    <div className="save-bar" data-save-bar="" role="group" aria-label="Workbook changes">
      <p className="save-bar-status" role="status" aria-live="polite">
        {edits.state.error ? (
          <span className="save-bar-error">{edits.state.error}</span>
        ) : count ? (
          blocked ? `${plural(count, "change", "changes")} · ${plural(blocked, "cell needs", "cells need")} fixing` : plural(count, "change", "changes")
        ) : saved ? (
          <>
            Saved as version {saved.version}.{" "}
            {saved.recomputed && saved.recomputed.length ? `${plural(saved.recomputed.length, "total", "totals")} updated. ` : null}
            {saved.uncached && saved.uncached.length ? "Formulas update when the file opens in Excel. " : null}
            {saved.said && saved.said.length ? <span data-save-said="">{saved.said.join(" ")} </span> : null}
            <a className="save-bar-link" href={saved.download} download>
              Download version {saved.version}
            </a>
          </>
        ) : null}
      </p>
      {count ? (
        <div className="save-bar-actions">
          <Button variant="quiet" size="sm" onClick={edits.discard} data-edit-press="discard">
            Discard
          </Button>
          <Button
            variant="secondary"
            size="sm"
            busy={edits.state.busy}
            busyLabel="Saving…"
            disabledReason={blocked ? "Fix the marked cells first." : undefined}
            onClick={() => edits.submit(ready)}
            data-edit-press="save"
          >
            Save changes · Download
          </Button>
        </div>
      ) : null}
    </div>
  );
}

/** Whether this pane can take edits at all: a live build, and an artifact that lists cells. */
export function useCanEdit(artifact) {
  const writes = useWritesEnabled();
  return useMemo(() => Boolean(writes && artifact && artifact.artifactId && Array.isArray(artifact.editable) && artifact.editable.length), [writes, artifact]);
}

/** The table modify_workbook draws for a workbook's input cells (its CELL_COLUMNS). */
export const INPUT_COLUMNS = [
  { key: REF_COLUMN, label: "Cell", kind: "text" },
  { key: "label", label: "Line", kind: "text" },
  { key: "heading", label: "Column", kind: "text" },
  { key: VALUE_COLUMN, label: "Value now", kind: "text" },
];
export const INPUTS_SHEET = "Input cells";

/** True when some sheet of `artifact` draws at least one input (a listed cell row). */
export function drawsInputs(artifact) {
  const sheets = artifact && artifact.table && Array.isArray(artifact.table.sheets) ? artifact.table.sheets : [];
  return sheets.some((s) => Object.keys(editableRows(artifact, s)).length > 0);
}

/**
 * The artifact the pane edits once the engine has listed a generated workbook's input
 * cells (`loaded`, from app/api/workpapers/shared.js `inputCellsFrom`): the same id, the
 * version the cells were read from, `editable` naming exactly those cells, and one sheet
 * of them. A listed value that is a formula is left out here as well as on the wire.
 */
export function inputsArtifact(artifact, loaded) {
  const cells = (loaded && Array.isArray(loaded.cells) ? loaded.cells : []).filter(
    (c) => c && typeof c.cell === "string" && !String(c.value ?? "").trim().startsWith("=")
  );
  const rows = cells.map((c) => ({
    role: "figure",
    cells: { [REF_COLUMN]: c.cell, label: c.label || "", heading: c.heading || "", [VALUE_COLUMN]: c.value ?? "" },
    // As modify_workbook names each row's record: the workbook and the cell.
    source: { kind: "workbook", id: c.cell, label: `${artifact.title || "This workbook"}, ${c.cell}` },
  }));
  const count = { label: "Input cells", count: cells.length };
  const total = loaded && Number.isInteger(loaded.total) && loaded.total > cells.length ? loaded.total : null;
  return {
    artifactId: artifact.artifactId,
    kind: artifact.kind,
    // The workbook's own name from the engine (D43): the card's title, or the copy's
    // file name ("Prepaid schedule July 2026.xlsx").
    title: (loaded && loaded.title) || artifact.title,
    target: (loaded && loaded.target) || null,
    verdict: total
      ? `The first ${cells.length} of ${total} input cells are listed. Formula cells are read-only and recalculate when the file opens in Excel.`
      : `${plural(cells.length, "input cell", "input cells")} can be changed. Formula cells are read-only and recalculate when the file opens in Excel.`,
    version: loaded && Number.isInteger(loaded.version) ? loaded.version : 0,
    editable: cells.map((c) => c.cell),
    table: { summary: [count], sheets: [{ name: INPUTS_SHEET, columns: INPUT_COLUMNS, rows }] },
  };
}

/**
 * Whether a pane may offer "Edit cells": a live build, a result with an id and a table
 * (so the engine has a workbook to read), and no sheet that already draws inputs.
 */
export function useCanOpenInputs(artifact) {
  const writes = useWritesEnabled();
  return useMemo(
    () => Boolean(writes && artifact && artifact.artifactId && artifact.table && Array.isArray(artifact.table.sheets) && artifact.table.sheets.length && !drawsInputs(artifact)),
    [writes, artifact]
  );
}

/**
 * The "Edit cells" state for one generated workbook: closed, reading, open (with the
 * engine's list), or refused in words. `initial` is the server-render seam: a render
 * cannot press, so a test hands it the engine's answer.
 */
export function useInputCells(artifact, { initial = null, read = readInputCells } = {}) {
  const [state, setState] = useState(() => (initial && initial.ok ? { status: "open", loaded: initial, error: null } : { status: "closed", loaded: null, error: null }));
  const open = useCallback(async (target = null) => {
    if (state.status === "reading") return;
    setState({ status: "reading", loaded: null, error: null });
    let out;
    try {
      // `target` names the copy "In your format" (D43); none is Vert's own workbook.
      const named = typeof target === "string" ? target : null;
      out = named ? await read(artifact.artifactId, named) : await read(artifact.artifactId);
    } catch {
      out = null;
    }
    if (!out || !out.ok) {
      setState({ status: "closed", loaded: null, error: (out && out.message) || "Vert couldn't read this workbook's cells." });
      return;
    }
    if (!out.cells.length) {
      setState({ status: "closed", loaded: null, error: "This workbook has no input cells to change; every figure in it is a formula or a heading." });
      return;
    }
    setState({ status: "open", loaded: out, error: null });
  }, [artifact, read, state.status]);
  const close = useCallback(() => setState({ status: "closed", loaded: null, error: null }), []);
  return { ...state, open, close };
}

/** The quiet press that opens a generated workbook's input cells, and why it could not. */
export function EditCellsBar({ inputs }) {
  return (
    <div className="edit-cells-bar" data-edit-cells="">
      <Button variant="quiet" size="sm" icon={<IconEdit size={14} aria-hidden="true" />} busy={inputs.status === "reading"} busyLabel="Reading cells…" onClick={() => inputs.open()} aria-label="Edit cells" data-edit-press="open">
        Edit
      </Button>
      {inputs.error ? (
        <p className="edit-note" role="status">
          {inputs.error}
        </p>
      ) : null}
    </div>
  );
}

/** The other workbook a result has, to edit next (D43): `{target, label}` or null. */
export function otherTarget(loaded) {
  const targets = loaded && Array.isArray(loaded.targets) ? loaded.targets : [];
  if (targets.length < 2) return null;
  const here = loaded.target || "house";
  const other = targets.find((t) => t.target !== here);
  if (!other) return null;
  return { target: other.target, label: other.target === "yours" ? "Edit cells · In your format" : "Edit cells · Vert's workbook" };
}

/** The opened inputs' head: which workbook, Done, and the other workbook when there is one. */
export function InputsHead({ inputs, title = null }) {
  const other = otherTarget(inputs.loaded);
  return (
    <div className="edit-cells-bar edit-cells-head" data-edit-target={(inputs.loaded && inputs.loaded.target) || "house"}>
      {title ? <p className="edit-cells-title">Editing {title}</p> : null}
      {other ? (
        <Button variant="quiet" size="sm" busy={inputs.status === "reading"} busyLabel="Reading cells…" onClick={() => inputs.open(other.target)} data-edit-press="other-target">
          {other.label}
        </Button>
      ) : null}
      <Button variant="quiet" size="sm" onClick={inputs.close} data-edit-press="done">
        Done
      </Button>
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE INPUT CELLS AS A GRID (U15, ui-pass-1 output-ui #15)
 *
 * "Edit cells" replaced the sheet with an "Input cells" list: one row per cell, its
 * line, its column and its value, which read as a report about a workbook rather than
 * the workbook. Here the same engine list (`input_cells`, the one rule for what is an
 * input) is laid out as each sheet's grid: the lines down the side, the columns across
 * the top, each input in its own cell, and a formula bar above naming the cell in focus
 * and its value now ("Roll-forward!C7 · 36"). A cell the engine did not list is drawn
 * empty: nothing here guesses an input. Every sheet is drawn, one under the next.
 * ══════════════════════════════════════════════════════════════════════════ */

/** The engine's input cells grouped as grids: `[{sheet, lines, headings, at}]`. Pure. */
export function inputGrids(cells) {
  const grids = new Map();
  for (const c of Array.isArray(cells) ? cells : []) {
    if (!c || typeof c.cell !== "string" || !c.cell.includes("!")) continue;
    if (String(c.value ?? "").trim().startsWith("=")) continue;
    const sheet = c.cell.slice(0, c.cell.indexOf("!"));
    if (!grids.has(sheet)) grids.set(sheet, { sheet, lines: [], headings: [], at: new Map() });
    const g = grids.get(sheet);
    const line = c.label || c.cell.slice(c.cell.indexOf("!") + 1);
    const heading = c.heading || "Value";
    if (!g.lines.includes(line)) g.lines.push(line);
    if (!g.headings.includes(heading)) g.headings.push(heading);
    g.at.set(`${line}\u0000${heading}`, { cell: c.cell, current: c.value === null || c.value === undefined ? "" : String(c.value), line, heading });
  }
  return [...grids.values()];
}

/** The input cells, as grids with a formula bar, and the save bar under them. */
export function InputsGrid({ artifact, cells, initialEdits = null, save = undefined }) {
  const edits = useWorkbookEdits(artifact, save ? { initial: initialEdits, save } : { initial: initialEdits });
  const grids = inputGrids(cells);
  const rows = {};
  for (const g of grids) for (const v of g.at.values()) rows[v.cell] = { cell: v.cell, current: v.current };
  const pending = pendingEdits(edits, rows);
  const [focused, setFocused] = useState(null);
  const shown = focused && rows[focused] ? { cell: focused, value: edits.valueOf(focused, rows[focused].current) } : null;
  return (
    <div className="pane-table inputs-grid" data-view="inputs-grid">
      {artifact.verdict ? <p className="pane-verdict">{artifact.verdict}</p> : null}
      <p className="cells-bar t-footnote" data-formula-bar="" aria-live="polite">
        <span className="cells-bar-ref" translate="no">{shown ? shown.cell : "No cell selected"}</span>
        <span className="cells-bar-value">{shown ? amountText(shown.value) || "empty" : "Choose a cell to see its value"}</span>
      </p>
      {grids.map((g) => (
        <section key={g.sheet} className="inputs-sheet" data-input-sheet={g.sheet}>
          <h3 className="inputs-sheet-name t-footnote">{g.sheet}</h3>
          <div className="pane-grid-wrap" data-kind="sheet">
            <table
              className="pane-grid inputs-table"
              data-kind="sheet"
              onFocus={(event) => {
                const ref = event.target && event.target.getAttribute ? event.target.getAttribute("data-cell") : null;
                if (ref) setFocused(ref);
              }}
            >
              <thead>
                <tr>
                  <th scope="col">Line</th>
                  {g.headings.map((h) => (
                    <th key={h} scope="col">
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {g.lines.map((line) => (
                  <tr key={line}>
                    <th scope="row">{line}</th>
                    {g.headings.map((h) => {
                      const v = g.at.get(`${line}\u0000${h}`);
                      return v ? (
                        <td key={h} data-col={h} data-editable="true">
                          <CellEditor cell={v.cell} current={v.current} label={`${line}, ${h}`} edits={edits} invalid={pending.invalid[v.cell] || null} />
                        </td>
                      ) : (
                        <td key={h} data-col={h} />
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      ))}
      <SaveBar edits={edits} pending={pending} always />
    </div>
  );
}
