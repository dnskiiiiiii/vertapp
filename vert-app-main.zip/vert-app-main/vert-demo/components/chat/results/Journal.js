"use client";

// components/chat/results/Journal.js — THE DRAFTED JOURNAL ENTRY, AS THE ENGINE WROTE IT
// ==============================================================================
// Lines and totals are the engine's (`je.lines`, `je.sumDr`, `je.sumCr`); nothing is
// added up here. An entry with no lines has not been drafted, and says so, rather
// than printing totals of $0.00 under a heading that says it balances.

import { useEngine } from "@/lib/engine-context";
import AccountingFigure from "@/components/shared/AccountingFigure";
import VerdictBand from "./VerdictBand";
import KeyFigures from "./KeyFigures";
import { payoutIdOf } from "./subject";

export default function Journal({ artifact, ledgerName }) {
  const engine = useEngine();
  const id = payoutIdOf(artifact);
  const recon = id && engine && engine.reconciliations ? engine.reconciliations[id] : null;
  const je = recon && recon.je ? recon.je : null;
  const lines = je && Array.isArray(je.lines) ? je.lines : [];
  return (
    <div className="chat-result-body-inner">
      <VerdictBand
        text={artifact.verdict || (lines.length ? "Journal entry ready to approve." : "No journal entry drafted yet.")}
        ok={lines.length ? je.balanced === true : null}
        figures={artifact.figures}
        ledgerName={ledgerName}
      />
      {lines.length ? (
        <div className="chat-table-wrap">
        <table className="chat-table">
          <thead>
            <tr>
              <th scope="col">Account</th>
              <th scope="col" className="num">Debit</th>
              <th scope="col" className="num">Credit</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((line, i) => (
              <tr key={i}>
                <th scope="row">{line.account}</th>
                <td className="num">{line.dr ? <AccountingFigure cents={line.dr} /> : null}</td>
                <td className="num">{line.cr ? <AccountingFigure cents={line.cr} /> : null}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <th scope="row">Total debits and credits</th>
              <td className="num"><AccountingFigure cents={je.sumDr} /></td>
              <td className="num"><AccountingFigure cents={je.sumCr} /></td>
            </tr>
          </tfoot>
        </table>
        </div>
      ) : (
        <KeyFigures figures={artifact.figures} />
      )}
    </div>
  );
}
