// components/chat/results/analysis-views.js — WHICH VIEW A PRESS OPENS, AND WHERE A DRILL LANDS
// ==============================================================================
// Build plan §20.0 decisions 7 and 12, §20.5 F-WIRE. Pure functions, so the conversation
// (ConversationView), the workbook card (messages/Result.js) and the two views (Bridge,
// Commentary) decide these the same way, and tests/chat-pane-wire.test.js holds them
// without a browser.
//
// THE WORKBOOK CARD IS PRIMARY (decision 7). A result's Open draws its workbook (the
// table); the bridge and the commentary are views opened FROM it ("Open bridge", "Edit
// commentary") and from an answer's next action. A view is opened only for an artifact
// that carries its payload (`artifact.bridge`, `artifact.commentary`), so no control is
// drawn that would open nothing (no false affordance). When an answer delivers the
// workbook, the card is hidden and its chip draws these links instead (Delivered.js).
//
// TWO SHAPES OF ONE CONTRACT. The engine may put the view's payload on the workbook's
// own artifact (`workbookRef` names itself), or on a separate, table-less artifact whose
// `workbookRef` names the workbook card it opens from (the step-0b fixtures). Both are
// handled: a card offers the views that point at it, a view's "Open workbook" goes to
// its `workbookRef`, and a drill lands on that workbook's rows.
//
// A NEXT ACTION THAT OPENS A VIEW is the engine's `open_artifact` naming the artifact and,
// as its `sheet`, the view's word ("Bridge", "Commentary"). An artifact with no table
// opens its view whatever the sheet, since a view is all it has.

/** The views, by payload key, and the words a control that opens one says. */
export const VIEWS = Object.freeze({
  bridge: { label: "Open bridge", word: "bridge" },
  commentary: { label: "Edit commentary", word: "commentary" },
});

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

function hasTable(artifact) {
  return Boolean(isObj(artifact) && isObj(artifact.table) && Array.isArray(artifact.table.sheets) && artifact.table.sheets.length);
}

/** The payload keys of VIEWS this artifact carries, in VIEWS' order. */
export function viewsOf(artifact) {
  if (!isObj(artifact)) return [];
  return Object.keys(VIEWS).filter((k) => isObj(artifact[k]));
}

/**
 * The view a next action that STARTS a task means to open when it arrives, or null.
 * BvA's answer ends on "Open bridge", a `start_task` for the waterfall template: the
 * bridge lives in that task's conversation, so the press goes there. Arriving on its
 * answer, the person still had to press a second "Open bridge" to see the bars, which
 * made ask -> bridge -> drill four presses against the reference's three (G4 eval r1,
 * §17.3). The press says which view it was for, so the conversation it lands in opens
 * that view by itself (ConversationView `?view=`). An explicit `action.view` names it;
 * otherwise the label does, when it is one of VIEWS' own words ("Open bridge").
 */
export function viewToOpen(next) {
  if (!isObj(next)) return null;
  const a = isObj(next.action) ? next.action : {};
  if (typeof a.view === "string" && Object.prototype.hasOwnProperty.call(VIEWS, a.view)) return a.view;
  const label = typeof next.label === "string" ? next.label.replace(/[\s\u203a>]+$/u, "").trim().toLowerCase() : "";
  if (!label) return null;
  const hit = Object.keys(VIEWS).find((k) => VIEWS[k].label.toLowerCase() === label);
  return hit || null;
}

/**
 * The artifact a conversation opens `view` from on arrival: the latest one that carries
 * the view (`artifacts` is the pane's latest-copy list), or null while none does yet;
 * the task may still be running, so the caller waits for the next event.
 */
export function arrivalTarget(artifacts, view) {
  if (typeof view !== "string" || !Object.prototype.hasOwnProperty.call(VIEWS, view)) return null;
  const list = Array.isArray(artifacts) ? artifacts : [];
  for (let i = list.length - 1; i >= 0; i -= 1) {
    if (viewsOf(list[i]).includes(view) && typeof list[i].artifactId === "string") return list[i].artifactId;
  }
  return null;
}

/** The query a link uses to ask the conversation it opens to open a view on arrival. */
export const VIEW_PARAM = "view";

/**
 * The view to open for a press on `artifact` at `sheet`, or null for its workbook.
 * `sheet` naming a view ("Bridge") opens it when the artifact carries it; an artifact
 * with no table opens the one view it carries, since there is no workbook to draw.
 */
export function viewFor(artifact, sheet = null) {
  const carried = viewsOf(artifact);
  if (!carried.length) return null;
  const asked = typeof sheet === "string" ? sheet.trim().toLowerCase() : "";
  if (asked && carried.includes(asked)) return asked;
  if (!hasTable(artifact)) return carried[0];
  return null;
}

/** The artifact id the view's "Open workbook" goes back to: its `workbookRef`, else itself. */
export function workbookOf(artifact, view) {
  const payload = isObj(artifact) && isObj(artifact[view]) ? artifact[view] : null;
  const ref = payload && typeof payload.workbookRef === "string" && payload.workbookRef ? payload.workbookRef : null;
  return ref || (isObj(artifact) ? artifact.artifactId || null : null);
}

/**
 * The view controls each workbook card offers, by the card's artifact id:
 * `Map(cardId → [{view, artifactId, label}])`. A card offers a view it carries itself,
 * and a view another artifact carries that names this card as its workbook. Each view is
 * offered once per card, from the latest artifact that carries it (`artifacts` is the
 * pane's latest-copy list, lib/agent/pane.js paneArtifacts).
 */
export function viewLinks(artifacts) {
  const list = Array.isArray(artifacts) ? artifacts.filter((a) => isObj(a) && typeof a.artifactId === "string") : [];
  const ids = new Set(list.map((a) => a.artifactId));
  const out = new Map();
  const add = (cardId, view, artifactId) => {
    const links = out.get(cardId) || [];
    const at = links.findIndex((l) => l.view === view);
    const link = { view, artifactId, label: VIEWS[view].label };
    if (at >= 0) links[at] = link;
    else links.push(link);
    out.set(cardId, links);
  };
  for (const a of list) {
    for (const view of viewsOf(a)) {
      const card = workbookOf(a, view);
      // A view whose workbook isn't in this conversation is offered on its own card.
      add(card && ids.has(card) ? card : a.artifactId, view, a.artifactId);
    }
  }
  return out;
}

/**
 * The row a drill lands on: `{artifactId, sheet, row}` in the workbook `artifact`, for a
 * ref "Detail!6500" (or `{sheet, key}`). The row is the one whose record is `key`
 * (`source.id`), else the first whose first cell reads `key` or starts "`key` ". A sheet
 * the workbook doesn't have is null: a drill never opens a guess. A sheet it has with no
 * matching row opens the sheet without a highlight.
 */
export function drillRow(artifact, target) {
  if (!hasTable(artifact) || !isObj(target) || typeof target.sheet !== "string") return null;
  const sheet = artifact.table.sheets.find((s) => s && s.name === target.sheet);
  if (!sheet) return null;
  const key = typeof target.row === "string" ? target.row : typeof target.key === "string" ? target.key : null;
  const rows = Array.isArray(sheet.rows) ? sheet.rows : [];
  let row = -1;
  if (key) {
    row = rows.findIndex((r) => r && isObj(r.source) && r.source.id === key);
    if (row < 0) {
      row = rows.findIndex((r) => {
        const raw = r && isObj(r.cells) ? Object.values(r.cells)[0] : null;
        const first = typeof raw === "string" ? raw.trim() : null;
        return typeof first === "string" && (first === key || first.startsWith(`${key} `));
      });
    }
  }
  return { artifactId: artifact.artifactId, sheet: sheet.name, row: row >= 0 ? row : null };
}

/**
 * The files attached in this conversation, `[{documentId, name}]`, from the thread's
 * answered questions (a file answer carries `{documentId, name}`) and your messages'
 * attachments. The budget sheet offers an xlsx import only for one of these.
 */
export function attachedDocuments(items) {
  const out = [];
  const seen = new Set();
  const add = (d) => {
    if (!isObj(d) || typeof d.documentId !== "string" || !d.documentId || seen.has(d.documentId)) return;
    seen.add(d.documentId);
    out.push({ documentId: d.documentId, name: typeof d.name === "string" ? d.name : "" });
  };
  for (const item of Array.isArray(items) ? items : []) {
    if (!isObj(item)) continue;
    if (item.kind === "question" && isObj(item.answer) && isObj(item.answer.value)) add(item.answer.value);
    if (Array.isArray(item.attachments)) item.attachments.forEach(add);
  }
  return out;
}

/** The query a link uses to open the budget sheet in a conversation ("Choose a budget"). */
export const BUDGETS_SHEET = "budgets";

/**
 * True for a next action's href that opens the budget sheet: `/chat/{id}?sheet=budgets`.
 * The engine's next action is `{kind: "open", href}`; there is no budgets page (decision
 * 12: the sheet has no route and no nav entry), so the conversation opens the sheet.
 */
export function opensBudgets(href) {
  if (typeof href !== "string") return false;
  const m = /^\/chat\/[^/?#]+\?([^#]*)$/.exec(href);
  return Boolean(m && new URLSearchParams(m[1]).get("sheet") === BUDGETS_SHEET);
}

/**
 * A sheet's name as the pane's tab says it: VERBATIM, the workbook's own name (verify
 * pass 1, Q17). DA2-020 had the tab say "Summary and flags" over a file whose sheet is
 * "Summary & Flags", so the tab a person reads and the tab they find on download
 * differed. The one name, both places.
 */
export function sheetLabel(name) {
  return typeof name === "string" ? name.trim() : "";
}
