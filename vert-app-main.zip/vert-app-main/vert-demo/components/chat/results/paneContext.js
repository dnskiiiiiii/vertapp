"use client";

// components/chat/results/paneContext.js — HOW A FIGURE IN THE CHAT REACHES THE PANE
// ==============================================================================
// Build plan §4.4 FP 3: a figure link opens its source ROW in the result pane, with
// that row highlighted; never a new page, never a modal; the chat keeps its scroll.
//
// The conversation view provides `{ id, locate(figure, ref), open(target, trigger) }`.
// A figure asks `locate` whether a result in this conversation holds its row
// (lib/agent/pane.js `locateFigure`); when one does, pressing it calls `open`. Outside
// a conversation (Month-end, Records, a test rendering one message) there is no
// provider, `usePane()` is null, and a figure opens its source sheet as it always did.

import { createContext, useContext } from "react";

export const PaneContext = createContext(null);

/** The conversation's pane, or null where there is none. */
export function usePane() {
  return useContext(PaneContext);
}
