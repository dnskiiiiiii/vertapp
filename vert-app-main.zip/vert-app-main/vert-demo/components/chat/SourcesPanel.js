"use client";

// components/chat/SourcesPanel.js — THE DATA AND SOURCES, AND NOTHING ELSE
// ==============================================================================
// p1 chat (founders' review, 23 Oct 2026). The co-founder called the old side surfaces
// "non-intuitive and useless": a 60% result pane, a desk pane, and a context popover with
// sources, files and activity. The side of the conversation now holds ONE thing: what
// data a turn referenced and used, and the sources it came from, each a press away from
// the record itself. No plan, no activity, no result workbook: those are the answer's,
// inline in the thread.
//
//   A TURN'S DATA   opened by that turn's "Data fetched" Open (WorkedFor.js): what Vert
//                   read, grouped by source (your books, the bank statement, payouts,
//                   entries, files, workpapers, budgets, the checklist, what Vert knows),
//                   then the figures the answer used, each with where it came from.
//   ALL OF IT       opened by the head's Sources: every turn's, put together, with the
//                   files this conversation holds.
//   CONNECTED       last, always: the connected sources and how fresh each is, and the
//                   way to Connections.
//
// EVERY RECORD OPENS WHERE IT LIVES (lib/agent/turn-sources.js `recordLink`): a payout,
// a bank line, an entry or an account's lines in Records; an uploaded file in the file
// viewer; a task's conversation; the ledger's own page when the engine sent its address
// (opened in a new tab, said with ↗). A record with nowhere to go is plain text, never a
// dead link.
//
// THE ENGINE'S RECORD OF THE READS (p1 sources, `run_state.read`) is preferred over the
// inference: each source as the engine named it, when it was read ("read 2:14 pm") or
// how fresh the copy it read was ("synced 1 Jul"), how many records it held, and each
// record with its own date and amount, its page in Vert and "Open in" the connected ledger (its name from the API).
//
// WHAT IS NOT KNOWN IS SAID. A source read without naming its records says so; a read
// that failed says "couldn't be read"; a turn with nothing recorded says that in a
// sentence. An empty list would read as "Vert used nothing", a claim nobody measured.
//
// PLACEMENT. The kit's right Sheet: on a desk it slides in from the right beside the
// conversation, with no scrim (a parallel panel, apple-design §12), and leaves the same
// way; on a phone it is the whole screen. Esc and Close close it, focus goes to its
// title on open and back to the Open that opened it.

import Link from "next/link";
import { Suspense, use, useEffect, useId, useMemo, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { Sheet, SourceLogo } from "@/components/ui";
import DocumentView, { FileChip, documentChip, sessionFromPath, splitAttachments } from "./results/DocumentView";
import { useEngine } from "@/lib/engine-context";
import { figureSource, figureTitle, isReadFigure } from "@/lib/agent/figure-source";
import { fetchedSummary, groupLabel, mergeSources, recordsListHref, turnSources } from "@/lib/agent/turn-sources";
import { monthName } from "@/lib/agent/words";
import { sourceWords } from "@/components/month/model";
import { formatDay, formatMoney, formatTime, metaLine } from "@/lib/format";
import { workedForTurns } from "./answer/model";
import { brainLines } from "@/components/skills/model";
import OpenSkill from "@/components/skills/OpenSkill";
import { startedNote } from "./messages/YourMessage";
import { figureLabel } from "./Delivered";
import {
  IconBank,
  IconBudget,
  IconCaretRight,
  IconClose,
  IconExternal,
  IconFile,
  IconJournal,
  IconLedger,
  IconPayments,
  IconPlan,
  IconSkill,
  IconWorkbook,
} from "@/components/ui/icons";

/** The glyph each source group carries. */
export const GROUP_GLYPHS = Object.freeze({
  books: IconLedger,
  bank: IconBank,
  payouts: IconPayments,
  journal: IconJournal,
  documents: IconFile,
  workpapers: IconWorkbook,
  budgets: IconBudget,
  checklist: IconPlan,
  knows: IconSkill,
  invoices: IconJournal,
});

/**
 * When a source was read, in words: "read 2:14 pm" for a read made in the turn,
 * "synced 1 Jul" for the ledger copy Vert read from (its age is the data's). Pure.
 */
export function readAtWords(group) {
  const at = group && typeof group.readAt === "string" ? group.readAt : null;
  if (!at) return null;
  try {
    return group.synced ? `synced ${formatDay(at)}` : `read ${formatTime(at)}`;
  } catch {
    return null;
  }
}

/** The ledger a deep link opens, named as the API names the connected ledger
 *  (`ledgerName`, never a vendor typed here: tests/claims.test.js); else "the ledger". Pure. */
export function ledgerNameOf(ledgerName = null) {
  return typeof ledgerName === "string" && ledgerName.trim() ? ledgerName.trim() : "the ledger";
}

/**
 * The files Vert holds, read through the app: `{ state: "ok", files }`, `{ state: "off" }`
 * when the engine reads no files (no section), or `{ state: "failed" }`. Never throws.
 */
export async function readFiles(session, fetchImpl = globalThis.fetch) {
  try {
    const qs = session ? `?session=${encodeURIComponent(session)}` : "";
    const response = await fetchImpl(`/api/documents${qs}`, { cache: "no-store" });
    if (response.status === 501 || response.status === 503 || response.status === 409) return { state: "off" };
    const body = await response.json().catch(() => null);
    if (!response.ok || !body || !Array.isArray(body.items)) return { state: "failed" };
    return { state: "ok", files: body.items.map(documentChip).filter(Boolean) };
  } catch {
    return { state: "failed" };
  }
}

/** Every turn's outline, by key (components/chat/answer/model.js `workedForTurns`). Pure. */
export function turnOutlines(items) {
  const worked = workedForTurns(items);
  const out = new Map();
  for (const o of [...worked.hosts.values(), ...worked.before.values()]) if (o && o.key) out.set(o.key, o);
  return out;
}

/** One outline's sources, with the files attached to its message. Pure. */
export function outlineSources(outline, period = null) {
  const you = outline && outline.you;
  const files = you && !you.started ? splitAttachments(you.text).files : [];
  return turnSources(outline, { period, files });
}

/** What the turn asked, in a line: your words, or the task you started. Pure. */
export function askedWords(outline) {
  const you = outline && outline.you;
  if (!you) return null;
  const text = you.started ? you.text : splitAttachments(you.text).text;
  return typeof text === "string" && text.trim() ? text.trim() : null;
}

export default function SourcesPanel({ open, turn = null, thread, sources = null, clientName = null, ledgerName = null, accountName = null, onClose, files, readFilesImpl = readFiles }) {
  const titleId = useId();
  const titleRef = useRef(null);
  const engine = useEngine();
  const pathname = usePathname();
  const session = sessionFromPath(pathname);
  const [viewing, setViewing] = useState(null);
  const [read, setRead] = useState(null);
  const items = thread && Array.isArray(thread.items) ? thread.items : [];
  const period = thread ? thread.period || null : null;
  const outlines = useMemo(() => turnOutlines(items), [items]);
  // The turn as it stands now (its outline is read again from the thread, so a turn
  // still running fills in while the panel is open).
  const outline = turn && turn.key ? outlines.get(turn.key) || turn : null;
  const whole = open && !outline;
  const data = useMemo(() => {
    if (!open) return null;
    if (outline) return outlineSources(outline, period);
    return mergeSources([...outlines.values()].map((o) => outlineSources(o, period)));
  }, [open, outline, outlines, period]);

  useEffect(() => {
    if (!open) return undefined;
    const frame = typeof window !== "undefined" ? window.requestAnimationFrame(() => titleRef.current && titleRef.current.focus({ preventScroll: true })) : null;
    return () => {
      if (frame !== null) window.cancelAnimationFrame(frame);
    };
  }, [open, turn]);
  useEffect(() => {
    // The conversation's files: given (`files`, chips), or read through the app when the
    // whole conversation's panel opens.
    if (!whole || files !== undefined) return undefined;
    let live = true;
    readFilesImpl(session).then((r) => live && setRead(r));
    return () => {
      live = false;
    };
  }, [whole, session, readFilesImpl, files]);
  const held = files !== undefined ? { state: "ok", files: Array.isArray(files) ? files : [] } : read;

  const asked = outline ? askedWords(outline) : null;
  const when = outline && typeof outline.toAt === "string" && Number.isFinite(Date.parse(outline.toAt)) ? safeTime(outline.toAt) : null;
  const where = [clientName, monthName(period)].filter(Boolean).join(" · ");
  const summary = data ? fetchedSummary(data, ledgerName) : null;

  return (
    <Sheet open={Boolean(open)} side="right" labelledBy={titleId} onClose={onClose} className="sources-sheet">
      {/* Drawn only once opened: the kit Sheet keeps what it last showed for its exit. */}
      {open ? (
      <div className="sources" data-sources-panel={outline ? "turn" : "all"} data-turn-key={outline ? outline.key : undefined}>
        <header className="sources-head">
          <div className="sources-head-text">
            <h2 className="sources-title t-title-3" id={titleId} ref={titleRef} tabIndex={-1}>
              Data and sources
            </h2>
            <p className="sources-sub t-footnote">
              {outline ? (
                <>
                  {asked ? <>For &ldquo;{asked}&rdquo;</> : "For this answer"}
                  {outline.you && startedNote(outline.you) ? <> &middot; {startedNote(outline.you)}</> : null}
                  {when ? <> &middot; {when}</> : null}
                </>
              ) : (
                <>Everything this conversation used{where ? <> &middot; {where}</> : null}</>
              )}
            </p>
          </div>
          <button type="button" className="chat-close sources-close" aria-label="Close data and sources" onClick={onClose}>
            <IconClose />
          </button>
        </header>
        {data ? (
          <div className="sources-body">
            {summary && summary.head && /^Read/.test(summary.head) ? (
              <p className="sources-lead t-body">
                {summary.head.replace(/^Read/, "Vert read")} for {outline ? "this answer" : "this conversation"}. Press any record to open it where it lives.
              </p>
            ) : null}
            <Gap data={data} running={Boolean(outline && outline.running)} whole={whole} />
            {data.groups.map((g) => (
              <SourceGroup key={g.key || g.id} group={g} ledgerName={ledgerName} onOpenFile={(chip, origin) => setViewing({ chip, origin })} clientName={clientName} period={period} />
            ))}
            {data.figures.length ? <FigureList figures={data.figures} engine={engine} accountName={accountName} /> : null}
            {whole ? <ConversationFiles read={held} onOpen={(chip, origin) => setViewing({ chip, origin })} /> : null}
            <section className="sources-group sources-connected" aria-labelledby={`${titleId}-connected`}>
              <h3 className="sources-group-head" id={`${titleId}-connected`}>
                <span className="sources-group-name">Connected sources</span>
              </h3>
              {isThenable(sources) ? (
                <Suspense fallback={<p className="sources-note">Reading your sources…</p>}>
                  <AwaitedSources sources={sources} />
                </Suspense>
              ) : (
                <SourceList sources={sources} />
              )}
              <p className="sources-connections">
                <Link href="/connections" className="link">
                  Connections<IconCaretRight className="caret-trailing" />
                </Link>
              </p>
            </section>
          </div>
        ) : null}
      </div>
      ) : null}
      {open ? <DocumentView chip={viewing && viewing.chip} origin={viewing && viewing.origin} open={Boolean(viewing)} onClose={() => setViewing(null)} /> : null}
    </Sheet>
  );
}

function safeTime(at) {
  try {
    return formatTime(at);
  } catch {
    return null;
  }
}

/** What isn't known, in a sentence. */
function Gap({ data, running, whole }) {
  if (running && !data.recorded) return <p className="sources-note" data-sources-gap="running">Vert is still reading. What it reads appears here as it goes.</p>;
  if (data.recorded) return null;
  if (whole) return <p className="sources-note" data-sources-gap="none">Vert hasn&rsquo;t recorded reading anything in this conversation yet.</p>;
  if (data.steps > 0) {
    return (
      <p className="sources-note" data-sources-gap="unlisted">
        Vert recorded the steps it took (see Reasoning) but not which records it read for this answer.
      </p>
    );
  }
  return (
    <p className="sources-note" data-sources-gap="none">
      Vert didn&rsquo;t record reading anything for this answer. It answered from what was already in this conversation.
    </p>
  );
}

/** How many records a group lists before "Show all N" (a month's bank lines run to hundreds). */
export const RECORDS_SHOWN = 12;

/**
 * The words under a long source: `{ button, note, href }`. The engine lists at most 50
 * records of a source and says how many more it read (`more`), so a button reading
 * "Show all 50" under a head reading 82 promised a list it couldn't show (smoke, 23 Oct
 * 2026). The button says how many of the true count it shows ("Show 50 of 82"); once
 * they are shown the note says so, and points to Records, which lists the whole source,
 * when Records has a list of it. Pure: the counts are the engine's, none is worked out.
 */
export function capWords(group, { period = null, shown = RECORDS_SHOWN } = {}) {
  const listed = Array.isArray(group && group.records) ? group.records.length : 0;
  const count = Number.isInteger(group && group.count) ? group.count : listed;
  const more = Number.isInteger(group && group.more) && group.more > 0 ? group.more : 0;
  const button = listed > shown ? (more ? `Show ${listed} of ${count}` : `Show all ${listed}`) : null;
  if (!more) return { button, note: null, href: null };
  const href = recordsListHref(group.id, period);
  const shownWords = `${listed} of ${count} shown.`;
  const rest = href ? "The full list is in Records." : `The other ${more} were read, not listed here.`;
  return { button, note: `${shownWords} ${rest}`, href, shown: shownWords, rest };
}

function SourceGroup({ group, ledgerName, onOpenFile, clientName = null, period = null }) {
  const Glyph = GROUP_GLYPHS[group.id] || IconFile;
  const headId = useId();
  const [all, setAll] = useState(false);
  const records = all ? group.records : group.records.slice(0, RECORDS_SHOWN);
  const hidden = group.records.length - records.length;
  const books = group.id === "books" && typeof ledgerName === "string" && ledgerName.trim();
  // The engine's record shows its own skill and answers as records; the inferred brain
  // lines are drawn only for a recording made before it.
  const brain = group.id === "knows" && !group.engine ? brainLines(group.brain, { client: clientName }) : [];
  const count = Number.isInteger(group.count) ? group.count : group.records.length;
  const when = readAtWords(group);
  const cap = capWords(group, { period: group.period || period });
  return (
    <section className="sources-group" data-source-group={group.id} data-source-key={group.key || undefined} aria-labelledby={headId}>
      <h3 className="sources-group-head" id={headId}>
        {books ? <SourceLogo source={ledgerName} size={16} className="sources-group-glyph" /> : <Glyph size={16} className="sources-group-glyph" aria-hidden="true" />}
        <span className="sources-group-name">{group.engine ? group.label : groupLabel(group.id, ledgerName)}</span>
        {count ? <span className="sources-group-count">{count}</span> : null}
      </h3>
      {when || group.period ? (
        <p className="sources-group-when t-footnote" data-source-read-at={group.readAt || undefined}>
          {metaLine([group.period ? `Dated in ${monthName(group.period)}` : null, when])}
        </p>
      ) : null}
      {group.failed ? <p className="sources-note" data-source-failed="">Vert couldn&rsquo;t read this for this answer.</p> : null}
      {group.unlisted ? <p className="sources-note" data-source-unlisted="">Vert read this, but didn&rsquo;t list which records.</p> : null}
      {group.engine && !group.records.length && count === 0 ? <p className="sources-note" data-source-none="">Vert looked and found none.</p> : null}
      {group.records.length ? (
        <ul className="sources-records">
          {records.map((r) => (
            <li key={r.key} className="sources-record" data-record-kind={r.kind}>
              <RecordLine record={r} onOpenFile={onOpenFile} ledgerName={ledgerName} />
            </li>
          ))}
        </ul>
      ) : null}
      {hidden > 0 && cap.button ? (
        <p className="sources-more">
          <button type="button" className="btn btn-quiet btn-sm" onClick={() => setAll(true)} data-show-all-records="">
            {cap.button}
          </button>
        </p>
      ) : null}
      {(all || hidden <= 0) && cap.note ? (
        <p className="sources-note" data-source-more={group.more}>
          {cap.href ? (
            <>
              {cap.shown}{" "}
              <Link href={cap.href} className="link" data-source-records="">
                {cap.rest}
              </Link>
            </>
          ) : (
            cap.note
          )}
        </p>
      ) : null}
      {brain.length ? (
        <ul className="sources-records">
          {brain.map((line, i) => (
            <li key={`${line.kind}-${i}`} className="sources-record" data-brain-line={line.kind}>
              {line.opens === "skill" ? (
                <OpenSkill template={line.template} className="sources-record-link">
                  {line.text}
                </OpenSkill>
              ) : line.kind === "recalled" && line.from && line.from.sessionId ? (
                <a className="sources-record-link" href={`/chat/${encodeURIComponent(line.from.sessionId)}`}>
                  {line.text}
                </a>
              ) : (
                <span className="sources-record-text">{line.text}</span>
              )}
            </li>
          ))}
        </ul>
      ) : null}
    </section>
  );
}

/** One record: a press to where it lives in Vert (or its words), what it is (its date
 *  and its own amount, as the engine sent them), and "Open in" the ledger when the engine sent
 *  the ledger's page for it. */
export function RecordLine({ record, onOpenFile = null, ledgerName = null }) {
  const meta = recordMeta(record);
  const ledger = record.ledger && record.ledger.href ? record.ledger : null;
  if (!meta && !ledger) return <RecordMain record={record} onOpenFile={onOpenFile} />;
  return (
    <span className="sources-record-line">
      <RecordMain record={record} onOpenFile={onOpenFile} />
      {meta ? <span className="sources-record-meta t-footnote">{meta}</span> : null}
      {ledger ? (
        <a className="sources-record-ledger t-footnote" href={ledger.href} target="_blank" rel="noreferrer" data-record-ledger="">
          Open in {ledgerNameOf(ledgerName)}
          <IconExternal size={12} className="caret-trailing" aria-hidden="true" />
          <span className="chat-visually-hidden"> (opens in a new tab)</span>
        </a>
      ) : null}
    </span>
  );
}

/** "2 Jul · $1,200.00": a record's own date and amount, formatted, never computed. Pure. */
export function recordMeta(record) {
  const parts = [];
  if (record && typeof record.date === "string") {
    try {
      parts.push(formatDay(record.date));
    } catch {
      /* an unreadable date is left out, never guessed */
    }
  }
  if (record && Number.isInteger(record.amountCents)) parts.push(formatMoney(record.amountCents));
  return parts.length ? metaLine(parts) : null;
}

function RecordMain({ record, onOpenFile = null }) {
  const link = record.link;
  if (link && link.skill) {
    return (
      <OpenSkill template={link.skill} className="sources-record-link">
        {record.label}
      </OpenSkill>
    );
  }
  if (link && link.documentId && typeof onOpenFile === "function") {
    // The file's kind from its name (a statement is a .csv, not a PDF).
    const chip = record.chip || documentChip({ documentId: link.documentId, name: record.label }) || { documentId: link.documentId, name: record.label, kind: "pdf", detail: null };
    return <FileChip chip={chip} onOpen={onOpenFile} />;
  }
  if (link && link.href && link.external) {
    return (
      <a className="sources-record-link" href={link.href} target="_blank" rel="noreferrer" data-record-external="">
        {record.label}
        <IconExternal size={12} className="caret-trailing" aria-hidden="true" />
        <span className="chat-visually-hidden"> (opens in a new tab)</span>
      </a>
    );
  }
  if (link && link.href) {
    return (
      <Link className="sources-record-link" href={link.href} data-record-href={link.href}>
        {record.label}
        <IconCaretRight className="caret-trailing" aria-hidden="true" />
      </Link>
    );
  }
  return <span className="sources-record-text">{record.label}</span>;
}

/** The figures the answer used, each with where it came from and the way to it. */
function FigureList({ figures, engine, accountName }) {
  const headId = useId();
  return (
    <section className="sources-group" data-source-group="figures" aria-labelledby={headId}>
      <h3 className="sources-group-head" id={headId}>
        <span className="sources-group-name">Figures in the answer</span>
        <span className="sources-group-count">{figures.length}</span>
      </h3>
      <ul className="sources-records sources-figures">
        {figures.map(({ key, ref, figure }) => {
          const read = isReadFigure(figure);
          const sheet = read ? figureSource(figure, engine, ref, { accountName }) : null;
          const title = figureName(figure, ref, accountName);
          return (
            <li key={key} className="sources-figure" data-figure={ref}>
              <span className="sources-figure-title">{title}</span>
              <span className="sources-figure-amount num">{read ? formatMoney(figure.cents) : "Not read"}</span>
              {figureFrom(sheet) ? <span className="sources-figure-from t-footnote">{figureFrom(sheet)}</span> : null}
              {sheet && sheet.seeAll && sheet.seeAll.href ? (
                <Link className="sources-record-link sources-figure-link t-footnote" href={sheet.seeAll.href}>
                  {sheet.seeAll.label}
                  <IconCaretRight className="caret-trailing" aria-hidden="true" />
                </Link>
              ) : null}
            </li>
          );
        })}
      </ul>
    </section>
  );
}

// The titles figure-source.js gives a figure it can say nothing more about.
const GENERIC_TITLE = /^(A total Vert worked out|A difference Vert worked out|A balance in your books|Where this comes from|A record Vert read)$/;

/**
 * A figure's name in the panel: the engine's label, else the record or line it names
 * (figure-source.js `figureTitle`), else its own reference in words ("Accrued", "Net
 * change"), so four figures are never four rows of "A total Vert worked out". Pure.
 */
export function figureName(figure, ref, accountName = null) {
  const title = figureTitle(figure, accountName, ref);
  if (!GENERIC_TITLE.test(title)) return title;
  // A month in the reference is a name, never YYYY-MM ("total.2026-08" → "Total,
  // August 2026"); a ranked place ("p2") names nothing a bookkeeper can read, so the
  // figure keeps its kind in words, with the month.
  // A PATH REFERENCE IS NEVER PRINTED (lead LX-4): "party/2026-07/vendors/2" lost its
  // label when the vendor's name read as money, and Sources listed the path itself.
  if (typeof ref === "string" && ref.includes("/")) {
    const segs = ref.split("/").filter(Boolean);
    const m = segs.find((p) => /^\d{4}-(0[1-9]|1[0-2])$/.test(p)) || null;
    const who = { vendors: "vendor", customers: "customer" }[segs[2]];
    const side = segs[0] === "party" && who ? (segs[3] === "unnamed" ? `Lines with no ${who} named` : `${who[0].toUpperCase()}${who.slice(1)} total`) : null;
    return [side || title, m ? `${monthName(m)} ${m.slice(0, 4)}` : null].filter(Boolean).join(", ");
  }
  const parts = typeof ref === "string" ? ref.split(".").filter(Boolean) : [];
  const monthPart = parts.find((p) => /^\d{4}-(0[1-9]|1[0-2])$/.test(p)) || null;
  const rest = parts.filter((p) => p !== monthPart && !/^p\d+$/i.test(p));
  const base = rest.length ? figureLabel(rest.join(".")) : null;
  const month = monthPart ? `${monthName(monthPart)} ${monthPart.slice(0, 4)}` : null;
  return [base || title, month].filter(Boolean).join(", ");
}

/**
 * The sentence under a figure: where it came from, from figure-source.js. A sentence
 * that names "your payout processor" is Vert's abstraction, not a bookkeeper's word
 * (vert_engine/plain_words.py), so it is left out; the record's link still says where
 * the figure lives. Pure.
 */
export function figureFrom(sheet) {
  const from = sheet && typeof sheet.from === "string" ? sheet.from.trim() : "";
  return from && !/processor/i.test(from) ? from : null;
}

function ConversationFiles({ read, onOpen }) {
  if (read && read.state === "off") return null;
  return (
    <section className="sources-group" data-source-group="conversation-files">
      <h3 className="sources-group-head">
        <IconFile size={16} className="sources-group-glyph" aria-hidden="true" />
        <span className="sources-group-name">Files in this conversation</span>
      </h3>
      {!read ? (
        <p className="sources-note">Reading your files…</p>
      ) : read.state === "failed" ? (
        <p className="sources-note">Vert couldn&rsquo;t list its files just now.</p>
      ) : !read.files.length ? (
        <p className="sources-note">No files in this conversation yet.</p>
      ) : (
        <ul className="sources-records" data-context-files="">
          {read.files.map((chip) => (
            <li key={chip.documentId} className="sources-record">
              <FileChip chip={chip} onOpen={onOpen} />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function isThenable(value) {
  return Boolean(value) && typeof value.then === "function";
}

function AwaitedSources({ sources }) {
  return <SourceList sources={use(sources)} />;
}

/** The connected sources and how fresh each is; "not connected" and "not read" in words. */
export function SourceList({ sources }) {
  const list = Array.isArray(sources) ? sources.filter((s) => s && s.label) : null;
  if (list === null) return <p className="sources-note">Vert couldn&rsquo;t read your sources just now.</p>;
  if (!list.length) return <p className="sources-note">Nothing is connected yet.</p>;
  return (
    <dl className="chat-sources sources-connected-list">
      {list.map((s, i) => (
        <div key={`${s.kind}-${i}`}>
          <dt>
            <SourceLogo source={s.kind || s.label} size={16} className="chat-source-logo" />
            {s.label}
          </dt>
          <dd>{sourceWords(s)}</dd>
        </div>
      ))}
    </dl>
  );
}
