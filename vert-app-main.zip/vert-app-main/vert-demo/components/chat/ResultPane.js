"use client";

// components/chat/ResultPane.js — A RESULT, IN THE CONVERSATION OR OVER IT
// ==============================================================================
// p1 chat (founders' review, 23 Oct 2026): the 60% result pane beside the chat is gone.
// "This should be abolished": the answer is the output, inline, and the side of the
// screen holds only the data and sources (SourcesPanel.js). What the pane used to draw
// is still reachable, in one of two places, never beside the chat:
//
//   inline   a workbook (one `artifact.table`, drawn by the one TableView) or an
//            iteration-1 result opens IN THE THREAD, under the turn whose control was
//            pressed: the answer's "N more rows", its file card's Open, a figure whose
//            row the workbook holds. Title, Download Excel and Hide; Esc hides it and
//            focus goes back to the control that opened it.
//   dialog   the plan document (a plan card's Review, where a plan is approved and
//            started), the journal editor and the iteration-4 views (bridge,
//            commentary) open in the kit's modal Sheet: centred on a desk, the whole
//            screen on a phone, Esc and Close, focus held inside and returned.
//
// `paneMode` decides which, from the same body `paneBody` names.
//
// DOWNLOAD ON EVERY RESULT. The head carries Download Excel, through the app's workbook
// proxy (lib/agent/links.js), wherever the engine built a workbook. It is a bordered
// secondary control, never the accent: it writes nothing.
//
// A RESULT HAS NO COMMIT BUTTON. The bank rec's verdict closes its task when the gap is
// explained; "Mark reconciled" does not exist.

import { useId, useRef } from "react";
import useSheetFocus from "./useSheetFocus";
import { appHref } from "@/lib/agent/links";
import { opensOnOf } from "@/lib/agent/pane";
import { workbookHref } from "@/app/api/workpapers/shared";
import { EditorFor } from "@/components/cards";
import TableView from "./results/TableView";
import PayoutBreakdown from "./results/PayoutBreakdown";
import PayoutList from "./results/PayoutList";
import BankRec from "./results/BankRec";
import Workpaper from "./results/Workpaper";
import { deliveredFileOf } from "@/lib/agent/events";
import Journal from "./results/Journal";
import Bridge from "./results/Bridge";
import Commentary from "./results/Commentary";

import { Sheet } from "@/components/ui";
import { IconBridge, IconClose, IconCommentary, IconDownload, IconJournal, IconPlan, IconWorkbook } from "@/components/ui/icons";
import { sheetLabel, workbookOf } from "./results/analysis-views";
import { useStripEdges } from "./results/useMoreToTheRight";

/** DA2-025: the type glyph a pane's head carries, by what it holds. */
function glyphFor(body, artifact, editing) {
  if (body === "bridge") return IconBridge;
  if (body === "commentary") return IconCommentary;
  if (body === "editor") return editing && editing.kind === "plan" ? IconPlan : IconJournal;
  return IconWorkbook;
}
/** Iteration 1's renderers, for a recorded result that carries no table. */
export const RESULT_KINDS = Object.freeze({
  payout_list: PayoutList,
  payout_breakdown: PayoutBreakdown,
  journal: Journal,
  bank_rec: BankRec,
  workpaper: Workpaper,
});

/**
 * Iteration 4's views (build plan §20.0 decisions 7 and 12), each opened FROM a workbook
 * card ("Open bridge", "Edit commentary") and never instead of it: the card, drawn by
 * TableView, stays the primary artifact. A view is drawn only when it is asked for
 * (`view`) AND the artifact carries its payload (`artifact.bridge`,
 * `artifact.commentary`); otherwise the card is drawn as before. Step 0b owns this map;
 * F-BUD and F-PLAN fill the components.
 */
export const ANALYSIS_VIEWS = Object.freeze({
  bridge: Bridge,
  commentary: Commentary,
});

/**
 * Which body the pane draws for `artifact`: "editor" (a journal entry being edited),
 * one of ANALYSIS_VIEWS' keys (a view opened from the card), "table" (TableView),
 * "legacy" (an iteration-1 renderer) or "none".
 */
export function paneBody(artifact, editing = null, view = null) {
  if (editing && editing.kind && EditorFor(editing.kind)) return "editor";
  if (!artifact) return "none";
  if (view && Object.hasOwn(ANALYSIS_VIEWS, view) && artifact[view]) return view;
  if (artifact.table && Array.isArray(artifact.table.sheets) && artifact.table.sheets.length) return "table";
  if (Object.hasOwn(RESULT_KINDS, artifact.kind)) return "legacy";
  return "none";
}

/**
 * Where a body is drawn (p1 chat): "dialog" for the editor (the plan document, a journal
 * entry) and the views (bridge, commentary), the modal Sheet over the conversation;
 * "inline" for a workbook or an iteration-1 result, in the thread under its turn; null
 * when there is nothing to draw. Pure.
 */
export function paneMode(body) {
  if (body === "editor" || Object.hasOwn(ANALYSIS_VIEWS, body)) return "dialog";
  if (body === "table" || body === "legacy") return "inline";
  return null;
}

/** The tab a view is, in the workbook's strip. */
export const VIEW_TAB_WORDS = Object.freeze({ bridge: "Bridge", commentary: "Commentary" });

/**
 * The view a workbook sheet's tab stands for, when the result carries that view's
 * payload, or null: the "Bridge" sheet of a result with `bridge` is the bridge. A sheet a
 * located figure lights (`highlight` on that sheet) stays the table, so the lit cell is
 * seen. Pure.
 */
export function sheetView(artifact, sheetName, highlight = null) {
  if (!artifact || typeof sheetName !== "string" || !sheetName) return null;
  if (highlight && highlight.sheet === sheetName) return null;
  // The bridge only: the commentary view is its editor, opened by "Edit commentary".
  const key = "bridge";
  return VIEW_TAB_WORDS[key] === sheetName && artifact[key] && typeof artifact[key] === "object" ? key : null;
}

/**
 * The workbook's sheet tabs over a view, the view's own tab selected first. A sheet tab
 * goes back to the workbook on that sheet. Arrow keys move along the strip.
 */
/** The strip's tab names: the workbook's sheets in order, the view's label leading only when it is not one of them. Pure. */
export function viewTabOrder(label, sheets) {
  const list = Array.isArray(sheets) ? sheets.filter(Boolean) : [];
  return list.includes(label) ? list : [label, ...list];
}

export function ViewTabs({ label, sheets, onSheet }) {
  // DA2-062 (critic r1 F15): the strip fades at an end with more tabs past it, measured
  // (results/useMoreToTheRight.js), so the phone's "Sourc" is never cut without a cue.
  const stripRef = useRef(null);
  const edges = useStripEdges(stripRef);
  const onKeyDown = (event) => {
    const tabs = [...event.currentTarget.querySelectorAll('[role="tab"]')];
    const at = tabs.indexOf(document.activeElement);
    const to = { ArrowRight: at + 1, ArrowLeft: at - 1, Home: 0, End: tabs.length - 1 }[event.key];
    if (to === undefined || at < 0) return;
    event.preventDefault();
    const next = tabs[(to + tabs.length) % tabs.length];
    if (next) next.focus();
  };
  return (
    <div className="pane-sheets-bar pane-view-tabs" data-view-tabs="">
      <div ref={stripRef} className="pane-sheets" role="tablist" aria-label="Sheets" onKeyDown={onKeyDown} data-edges={edges || undefined}>
        {/* THE WORKBOOK'S OWN ORDER (verify pass 2, D31/D32): opened from "Open bridge",
            the strip put Bridge first, so the same workbook read in two orders. The tabs
            keep the workbook's order and the view's own sheet is the selected one; a view
            with no sheet of its own leads. DA2-020: it is never drawn twice. */}
        {viewTabOrder(label, sheets).map((name) =>
          name === label ? (
            <button key={name} type="button" role="tab" className="pane-sheet-tab" aria-selected="true" tabIndex={0} data-sheet-name={sheets.includes(label) ? name : undefined}>
              {label}
            </button>
          ) : (
            <button key={name} type="button" role="tab" className="pane-sheet-tab" aria-selected="false" tabIndex={-1} onClick={() => onSheet(name)} data-sheet-name={name}>
              {sheetLabel(name)}
            </button>
          )
        )}
      </div>
    </div>
  );
}

/** The view tabs a workbook's strip draws: `[{view, label, open}]` from its view links. Pure. */
export function tableViews(links, onOpenView) {
  if (!Array.isArray(links) || typeof onOpenView !== "function") return null;
  return links
    .filter((l) => l && typeof l.view === "string" && Object.hasOwn(VIEW_TAB_WORDS, l.view) && typeof l.artifactId === "string")
    .map((l) => ({ view: l.view, label: VIEW_TAB_WORDS[l.view], open: () => onOpenView(l.artifactId, l.view) }));
}

/** The workbook artifact a view's Download serves, when it is another artifact here with a file. Pure. */
export function viewWorkbook(artifact, view, artifacts) {
  const id = workbookOf(artifact, view);
  if (!id || !artifact || id === artifact.artifactId) return null;
  return (Array.isArray(artifacts) ? artifacts : []).find((a) => a && a.artifactId === id && typeof a.xlsxHref === "string") || null;
}

/** The body a pane state draws, the same reading everywhere (ConversationView, here). Pure. */
export function bodyFor(artifact, { editing = null, view = null, sheet = null, highlight = null } = {}) {
  // THE BRIDGE TAB IS THE CHART (verify pass 5, U17/D32): a sheet tab that names a view
  // the result carries draws the view.
  return paneBody(artifact, editing, view || sheetView(artifact, editing ? null : sheet || opensOnOf(artifact), highlight));
}

export default function ResultPane({
  mode = "inline",
  artifact,
  artifacts = null,
  sheet = null,
  highlight = null,
  editing = null,
  onSheet = null,
  view = null,
  onView = null,
  views = null,
  onOpenView = null,
  onClose,
  ledgerName,
  paneId,
  entries = null,
}) {
  const open = Boolean(artifact || editing);
  const dialog = mode === "dialog";
  // Inline, the pane keeps the sheet rules itself (title focused, Esc hides, focus goes
  // back); in a dialog the kit Sheet keeps them, and holds Tab inside.
  const titleRef = useSheetFocus(open && !dialog, onClose);
  const titleId = useId();
  if (!open) return null;

  const body = bodyFor(artifact, { editing, view, sheet, highlight });
  const Body = body === "legacy" ? RESULT_KINDS[artifact.kind] : null;
  const View = Object.hasOwn(ANALYSIS_VIEWS, body) ? ANALYSIS_VIEWS[body] : null;
  const backToWorkbook = typeof onView === "function" ? () => onView(null) : null;
  // THE WORKBOOK'S TABS OVER ITS VIEW (Q10): the bridge (or the commentary) is one tab
  // of the workbook it opens from, so its sheets are one press away.
  const viewSheets = View && artifact && artifact.table && Array.isArray(artifact.table.sheets) ? artifact.table.sheets.map((s) => s && s.name).filter(Boolean) : [];
  const Editor = body === "editor" ? EditorFor(editing.kind) : null;
  // A result the person has edited carries `version` n (F-EDIT). Its file is the saved
  // version, which only the engine's /workpapers/{id}.xlsx serves; the house workbook at
  // xlsxHref is rebuilt from the table and would silently drop the edit.
  const saved = artifact && Number.isInteger(artifact.version) && artifact.version > 0 && artifact.artifactId;
  // A VIEW DOWNLOADS ITS OWN WORKBOOK (verify pass 4, F-24).
  const viewBook = View ? viewWorkbook(artifact, body, artifacts) : null;
  const xlsx =
    artifact && body !== "editor"
      ? viewBook && viewBook.xlsxHref
        ? appHref(viewBook.xlsxHref)
        : saved
          ? workbookHref(artifact.artifactId, artifact.version)
          : appHref(artifact.xlsxHref)
      : null;
  // A body that names itself (the plan document passes "Plan") is titled by that name.
  const title = body === "editor" ? (typeof editing.title === "string" && editing.title) || (editing.je && editing.je.memo) || "Edit entry" : artifact.title || "Result";
  // A file that is not a workbook (the month's binder, a zip) keeps its own extension.
  const own = !saved && artifact ? deliveredFileOf(artifact) : null;
  const fileName = `${(artifact && artifact.title) || "Result"}.${own ? own.ext : "xlsx"}`;
  const Glyph = glyphFor(body, artifact, editing);

  const content = (
    <>
      <div className="pane-head">
        <Glyph className="pane-glyph" size={16} aria-hidden="true" />
        <h2 className="pane-title" id={titleId} ref={dialog ? null : titleRef} tabIndex={-1}>
          {title}
        </h2>
        {xlsx ? (
          <a className="icon-btn pane-download" href={xlsx} download={fileName} aria-label={`Download ${fileName}`} title={own && own.ext !== "xlsx" ? "Download" : "Download Excel"}>
            <IconDownload aria-hidden="true" />
          </a>
        ) : null}
        <button type="button" className="chat-close pane-close" aria-label={dialog ? "Close" : `Hide ${title}`} title={dialog ? "Close" : "Hide"} onClick={onClose}>
          <IconClose />
        </button>
      </div>
      <div className="pane-body" key={body === "editor" ? `edit-${editing.actionId}` : artifact.artifactId || artifact.title}>
        {body === "editor" ? (
          <Editor action={editing} artifact={artifact} onDone={onClose} />
        ) : View ? (
          <>
            {viewSheets.length && backToWorkbook ? (
              <ViewTabs label={VIEW_TAB_WORDS[body] || "View"} sheets={viewSheets} onSheet={(name) => {
                backToWorkbook();
                if (typeof onSheet === "function") onSheet(name);
              }} />
            ) : null}
            <div role="tabpanel" aria-label={VIEW_TAB_WORDS[body] || "View"} className="pane-view-panel">
              <View artifact={artifact} ledgerName={ledgerName} onOpenWorkbook={viewSheets.length ? null : backToWorkbook} />
            </div>
          </>
        ) : body === "table" ? (
          <TableView
            artifact={artifact}
            ledgerName={ledgerName}
            sheet={sheet}
            highlight={highlight}
            onSheet={onSheet}
            views={tableViews(views, onOpenView)}
            entries={entries}
          />
        ) : Body ? (
          <Body artifact={artifact} ledgerName={ledgerName} />
        ) : (
          <p className="chat-sheet-note">Vert can't show this kind of result here yet.</p>
        )}
      </div>
    </>
  );

  if (dialog) {
    return (
      <Sheet open side="modal" labelledBy={titleId} onClose={onClose} className="result-viewer">
        <div className="chat-pane result-viewer-pane" id={paneId} data-body={body} data-mode="dialog">
          {content}
        </div>
      </Sheet>
    );
  }
  return (
    <section className="chat-pane chat-pane-inline" id={paneId} aria-labelledby={titleId} data-body={body} data-mode="inline" data-inline-result="">
      {content}
    </section>
  );
}
