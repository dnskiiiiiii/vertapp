// components/chat/Delivered.js — "DELIVERED": EACH FILE AS ONE CARD, ITS KEY FIGURE, ONE PRESS TO OPEN IT
// (design-fix-2 DA2-024: the ArtifactCard of spec §7.1; the notes below describe the
// chip list it replaced)
// ==============================================================================
// Build plan §4.0.8 and FC brief 2; output teardown standard 2 ("every final message
// has a 'What I delivered' outline: each artifact numbered, its contents in one clause
// with the key figure"). Drawn only when the run produced something: an empty
// "What I delivered" is a heading that promises a file and has none.
//
// EACH ITEM IS A FILE CHIP. Its name is the workbook's ("Bank reconciliation · Everyday
// account · July 2026.xlsx"), with a download glyph, and pressing it downloads through
// the app's workbook proxy (app/api/agent/artifacts/[id]/xlsx), for every artifact
// kind. Beside it, the engine's one clause and its key figure, bound like every other
// figure in the thread.
//
// NOT THE ACCENT. A chip downloads; it writes nothing, so it is never purple-filled,
// and neither is its glyph (§4.0.9: purple means "this writes"). That is why the next
// action is never Download either: the chip already is one.
//
// OPEN SITS BESIDE THE CHIP when the thread holds the result itself (Thread.js
// resultsCarriedByChips): the result's own card is then not drawn, so the chip is the
// one place the file appears, and Open is how its pane is reached. It is a quiet text
// button, like the card's was.
//
// AND SO DO THE CARD'S VIEWS (build plan §20.0 decision 7; G4 eval r1 OQ 6, §17.3). The
// hidden card was the only place "Open bridge" and "Edit commentary" were drawn, so with
// the card gone the commentary editor (Save changes · Download) could not be reached at
// all, and the bridge opened only from a second chip of the same name. Everything the
// hidden card offered beside Open is drawn beside the chip's Open: `views` is
// analysis-views.js viewLinks, by the chip's artifact id. Each link needs `onOpenView`,
// so nothing is drawn that opens nothing.

import { TieOutFold } from "@/components/cards/TieOutCard";
import BoundText from "./BoundText";
import EventFigure from "./EventFigure";
import { fileName, xlsxProxyHref } from "./answer/model";
import ArtifactCard, { TYPE_WORDS } from "./ArtifactCard";

import { IconDownload } from "@/components/ui/icons";
/** The download glyph: an arrow into a tray, in the text's own colour. */
export function DownloadGlyph() {
  return (
    <IconDownload className="chat-file-glyph" size={16} />
  );
}

// A KEY FIGURE CARRIES ITS LABEL (eval r3 output-visual F8). The line used to start
// with the figure alone — "−$388.55 · Revenue $9,812.00 → …" — and nobody could say
// what had moved by $388.55. The label is the engine's own name for the figure
// (`figureRef`, "net.change"), said in words: "Net change −$388.55". A conversation's
// answer prefixes the template ("pnl_trend.net.change"); that part is not a label.
const FIGURE_WORDS = Object.freeze({
  nbv: "net book value",
  closing_nbv: "closing net book value",
  je: "entry",
  gst: "GST",
  payg: "PAYG",
});

/** "net.change" → "Net change"; "pnl_trend.net.change" → "Net change". Null for no ref. */
export function figureLabel(ref) {
  if (typeof ref !== "string" || !ref.trim()) return null;
  let parts = ref.trim().split(".").filter(Boolean);
  // A leading template id ("fixed_asset_rollforward.closing_nbv") names the task, not the figure.
  if (parts.length > 1 && parts[0].includes("_")) parts = parts.slice(1);
  const words = parts
    .map((p) => FIGURE_WORDS[p] || p.split("_").map((w) => FIGURE_WORDS[w] || w).join(" "))
    .join(" ")
    .trim();
  if (!words) return null;
  return words.charAt(0).toUpperCase() + words.slice(1);
}

function mentions(detail, ref) {
  return typeof detail === "string" && new RegExp(`\\{\\{\\s*fig:${ref.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*\\}\\}`).test(detail);
}

/**
 * A BRIDGE'S CAPTION SAYS WHERE IT GOES, NOT HOW IT WAS BUILT (DA2-032; critic r1 F7).
 * The engine's clause for a bridge is "6 bars and Everything else, {{fig:net.budget}} to
 * {{fig:net.actual}}", and with its key figure in front the card read as a log line:
 * "Change −$4,003.47, 6 bars and Everything else, $22,890.00 to $18,886.53". The same two
 * figures, named by their own refs, are the caption: "Budget $22,890.00 → Actual
 * $18,886.53". Returns the clause to draw and whether the key figure still leads it;
 * any other clause is kept as the engine wrote it. Pure.
 */
const BRIDGE_CLAUSE = /^\s*\d+ bars? and Everything else, (\{\{\s*fig:([^}\s]+)\s*\}\}) to (\{\{\s*fig:([^}\s]+)\s*\}\})\s*\.?\s*$/;
function endWord(ref) {
  const last = String(ref).split(".").filter(Boolean).pop() || "";
  const words = last.replace(/_/g, " ").trim();
  return words ? words.charAt(0).toUpperCase() + words.slice(1) : null;
}
export function deliveredClause(detail) {
  if (typeof detail !== "string") return { detail: detail || null, keyFigure: true };
  const m = BRIDGE_CLAUSE.exec(detail);
  if (!m) return { detail, keyFigure: true };
  const from = endWord(m[2]);
  const to = endWord(m[4]);
  if (!from || !to) return { detail, keyFigure: true };
  return { detail: `${from} ${m[1]} \u2192 ${to} ${m[3]}`, keyFigure: false };
}

/** "Misclassification scan · September 2026.xlsx" → "Misclassification scan, September 2026". */
export function artifactTitle(name) {
  return String(name || "").replace(/\.xlsx$/i, "").replace(/ · /g, ", ");
}

/**
 * WHERE A DELIVERED FILE DOWNLOADS, WHAT IT IS CALLED AND WHAT KIND IT IS (verify pass
 * 3, D35 / S-E2E-6). A result whose own href is not the house workbook (the month's
 * binder, `/workpapers/binder.zip`) carries `file: {href, ext}` (lib/agent/events.js
 * withFileHrefs) and downloads from there, named and badged by its own extension; the
 * artifact-id workbook route answers it 409. Everything else is the house workbook.
 */
export function deliveredDownload(d) {
  if (!d || typeof d !== "object") return null;
  const label = typeof d.label === "string" ? d.label.trim() : "";
  if (!label) return null;
  if (d.file && typeof d.file.href === "string" && d.file.href && typeof d.file.ext === "string") {
    const ext = d.file.ext.toLowerCase();
    const re = new RegExp(`\\.${ext}$`, "i");
    return { href: d.file.href, name: re.test(label) ? label : `${label}.${ext}`, type: ext === "zip" ? "archive" : "workbook" };
  }
  const href = xlsxProxyHref(d.artifactId);
  const name = fileName(label);
  return href && name ? { href, name, type: "workbook" } : null;
}

export default function Delivered({ delivered, figures, ledgerName = null, openable = null, carriedResults = null, tieOutShown = null, onOpen = null, openAt = null, views = null, onOpenView = null, head = true }) {
  const list = Array.isArray(delivered) ? delivered.filter((d) => deliveredDownload(d)) : [];
  if (!list.length) return null;
  const table = figures && typeof figures === "object" ? figures : {};
  return (
    <div className="chat-delivered" data-delivered="">
      {/* "Delivered" (DA2-024, DA2-081), a section head; one card per file, no numbers. */}
      {/* Under "I've delivered N things" (the answer shape) the section head would say it twice. */}
      {head ? <p className="chat-delivered-head">Delivered</p> : null}
      <ul className="chat-delivered-list">
        {list.map((d) => {
          const file = deliveredDownload(d);
          const name = file.name;
          // The key figure, when the clause does not already say it. A clause that opens
          // with the card's own type word ("Zip · every workbook…") does not say it twice.
          const typeWordShown = TYPE_WORDS[file.type];
          const clause = deliveredClause(typeof d.detail === "string" && typeWordShown ? d.detail.replace(new RegExp(`^\\s*${typeWordShown}\\s*·\\s*`, "i"), "") : d.detail);
          const key = clause.keyFigure && d.figureRef && !mentions(d.detail, d.figureRef) && Object.prototype.hasOwnProperty.call(table, d.figureRef) ? table[d.figureRef] : null;
          const canOpen = typeof onOpen === "function" && openable && openable.has(d.artifactId);
          const viewList = typeof onOpenView === "function" && canOpen && views instanceof Map && Array.isArray(views.get(d.artifactId)) ? views.get(d.artifactId) : [];
          const meta =
            clause.detail || key ? (
              <span className="chat-delivered-detail">
                {key ? (
                  <span className="chat-delivered-key" data-key-figure={d.figureRef}>
                    {figureLabel(d.figureRef) ? `${figureLabel(d.figureRef)} ` : null}
                    <EventFigure figure={key} figureRef={d.figureRef} />
                  </span>
                ) : null}
                {key && clause.detail ? ", " : null}
                {clause.detail ? <BoundText text={clause.detail} figures={table} ledgerName={ledgerName} /> : null}
              </span>
            ) : null;
          // THE WHOLE CARD OPENS IT (DA2-024; critic r1 F6): a card that carries a view
          // ("Open bridge", "Edit commentary") opens that view on its press, so the view
          // is not a second button inside the card; otherwise it opens the workbook, at
          // the sheet the answer named when it named one. The one trailing tool is the
          // download.
          // THE CARD IS THE WORKBOOK (verify pass 1, D31): it opens where the workbook
          // opens (Budget vs actual on its own tab, lib/agent/pane.js OPENS_ON) and is
          // labelled Workbook. A view ("Open bridge") is the answer's next, its own button.
          // Its views are named buttons on the card's row, so "Open bridge" and "Edit
          // commentary" are each one press, said in words.
          const sheet = openAt instanceof Map && typeof openAt.get(d.artifactId) === "string" ? openAt.get(d.artifactId) : null;
          const press = !canOpen ? null : sheet ? () => onOpen(d.artifactId, sheet) : () => onOpen(d.artifactId);
          const tools = viewList.length
            ? viewList.map((v) => (
                <button key={v.view} type="button" className="btn btn-quiet btn-sm artifact-view" data-opens-view={v.view} onClick={() => onOpenView(v.artifactId, v.view)}>
                  {v.label}
                </button>
              ))
            : null;
          return (
            <li key={d.artifactId} className="chat-delivered-item">
              <ArtifactCard
                type={file.type}
                tools={tools}
                typeWord={d.ownFormat && d.ownFormat.href && d.ownFormat.name ? "Vert's workbook" : null}
                title={artifactTitle(name)}
                meta={meta}
                onOpen={press}
                href={canOpen ? null : file.href}
                download={canOpen ? null : name}
                downloadHref={file.href}
                downloadName={name}
                pressProps={canOpen ? { "data-open-artifact": d.artifactId, ...(sheet ? { "data-open-sheet": sheet } : {}) } : { "data-artifact": d.artifactId }}
              />
              {d.ownFormat && d.ownFormat.href && d.ownFormat.name ? (
                // The same result in the person's own workbook, beside Vert's (eval r2
                // #8): "Upload it and I'll match its format" delivers the match.
                <div className="chat-delivered-own" data-own-format="">
                  <ArtifactCard
                    type="workbook"
                    title={artifactTitle(d.ownFormat.name)}
                    meta="In your format, with last month’s closing carried in"
                    href={d.ownFormat.href}
                    download={d.ownFormat.name}
                    downloadHref={d.ownFormat.href}
                    downloadName={d.ownFormat.name}
                    pressProps={{ "data-artifact-format": "own" }}
                  />
                </div>
              ) : null}
              {/* The result's card is not drawn when this card carries it, so its
                  tie-out is drawn here instead (XLS-fix2), folded to one line that
                  opens on press (CO-19). It draws nothing when the engine sent no
                  tie-out. */}
              {/* Not when the answer's own Reconciliation already drew this tie-out
                  (`tieOutShown`, Answer.js tieOutShownBy; verify pass 10 F3). */}
              {carriedResults && typeof carriedResults.get === "function" && carriedResults.get(d.artifactId) && !(tieOutShown === "*" || tieOutShown === d.artifactId) ? (
                <TieOutFold artifact={carriedResults.get(d.artifactId)} ledgerName={ledgerName} />
              ) : null}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
