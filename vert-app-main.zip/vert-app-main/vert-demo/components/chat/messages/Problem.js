"use client";

// components/chat/messages/Problem.js — WHAT HAPPENED, WHAT WAS RECORDED, TRY AGAIN
// ==============================================================================
// Spec §4.2 row 8 and §11.5. A plain sentence from the code, then what was and wasn't
// recorded (the part a bookkeeper needs most), Retry when the engine says a retry can
// work, and the code under Details. The engine stores a code only (build plan §1.2):
// no provider message ever reaches this screen, so none can leak a key or a name.

import { useRef, useState } from "react";
import { Button } from "@/components/ui";
import { problemDetail, problemSentence, recordedSentence } from "@/lib/agent/words";
import { formatTime } from "@/lib/format";

/** What a stop a later run picked up again says: one quiet line, no alert, no retry. */
export const RESUMED_WORDS = "Stopped, then picked up again.";

export default function Problem({ item, onRetry, retryDisabledReason = null }) {
  // ONE PRESS, ONE RETRY (staging, 23 Oct 2026). A task's retry runs in the request
  // (up to the turn's cap) and nothing on screen said so: the co-founder pressed Try
  // again again and again, and 14 retries stopped in 20 s. The button is busy until the
  // retry lands, and a press while one is in flight sends nothing.
  const [busy, setBusy] = useState(false);
  const inFlight = useRef(false);
  const press = async () => {
    if (inFlight.current) return;
    inFlight.current = true;
    setBusy(true);
    try {
      await onRetry(item);
    } finally {
      inFlight.current = false;
      setBusy(false);
    }
  };
  // The run after it resumed the work (`run_state.resumes`, P25): the stop is history,
  // and a "Try again" under it would retry work already done.
  if (item && item.resumed) {
    return (
      <p className="chat-problem-resumed t-footnote" data-message="error-resumed">
        {RESUMED_WORDS}
      </p>
    );
  }
  return (
    <div className="chat-problem" data-message="error" data-code={item.code} role="alert">
      <p className="chat-problem-head">
        {problemSentence(item.code)} {recordedSentence(item.recorded)}
      </p>
      <div className="chat-problem-actions">
        {/* In a recording there is nothing to retry, and the band above already says
            why; a disabled Try again with the reason repeated would be noise. */}
        {item.retry && typeof onRetry === "function" && !retryDisabledReason ? (
          <Button variant="secondary" onClick={press} busy={busy} busyLabel="Trying again…">
            Try again
          </Button>
        ) : null}
        <details className="chat-details">
          <summary>Details</summary>
          {/* Words, never the raw code (S-CF-7); the code is on data-code above. */}
          <span className="chat-problem-detail">{problemDetail({ retry: item.retry, at: timeOf(item.at) })}</span>
        </details>
      </div>
    </div>
  );
}

function timeOf(at) {
  if (typeof at !== "string" || !at) return null;
  try {
    return formatTime(at);
  } catch {
    return null;
  }
}
