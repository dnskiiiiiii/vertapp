// components/chat/messages/Decision.js — A DECISION IN THE THREAD
// ==============================================================================
// Spec §4.2 row 5 and §5. The decision cards are F3's (components/cards/index.js
// `CardFor(action)`), shared with Month-end, so a decision looks and commits the same
// way in both places. A card receives `{ action, onSettled }` and never the event list
// (build plan §2.9); what it writes goes through the existing routes with their gates,
// and the API reads the target back when it settles.
//
// NO onSettled IS PASSED HERE. In the conversation the settlement comes back as its own
// `decision_settled` event on the stream, which folds into this item and draws the
// one line below; the card also refreshes the route after a commit (useCardCommit).
// The card draws its own best-guess mark from the action, so none is added here.
//
// Once settled, the decision is one line: who, what, when (UI-024: never blank), and
// an honest note when Vert's read-back did not confirm the write. It is F3's
// SettledDecision, so the thread and Month-end cannot word one decision two ways.

//
// ONE OPEN CARD AT A TIME (PR8, eval S5, 2 Oct). The thread opens only its first
// undecided card; every other undecided one is drawn closed, as one line that opens in
// place when pressed (`open={false}`), the way Month-end lists its decisions. Three
// drafted entries used to show three purple Approves in one view, and Resolve payout
// breaks three purple commits; purple means "this writes", so a view holds one.

import { CardFor, SettledDecision, drawsOwnSettlement } from "@/components/cards";
import { closedLine } from "@/components/cards/words";
import { useDuties } from "@/lib/store";
import { may } from "@/lib/roles";

/**
 * Whether this viewer is not shown the decision at all (verify pass 6, S-E2E-1): an
 * undecided steps update ("Update the steps for Deferred revenue") for a role that may
 * not change a task's steps. A preparer was shown it with no way to apply it, under
 * every later turn, and its "Not now" would have turned it down for the reviewer it
 * waits for. It stays for a reviewer or an admin. An unknown role keeps the card (its
 * own gate says who can). Pure.
 */
export function hiddenFromViewer(item, duties) {
  if (!item || item.settled || !item.action || item.action.kind !== "skill_update") return false;
  const role = duties ? duties.role || duties.gatedAs || null : null;
  return may(role, "edit_skills") === false;
}

export default function Decision({ item, ledgerName, open = true, onOpen = null, cardProps = null }) {
  const duties = useDuties();
  if (hiddenFromViewer(item, duties)) return null;
  // `cardProps`: what an answer's numbered entry cards pass to the card (`quiet`).
  const extra = cardProps && typeof cardProps === "object" ? cardProps : {};
  // A card that draws its own outcome (the skill update's "What changed", eval r1 #18)
  // is kept, given its settlement; the generic settled line would replace the outline
  // with "Decided · <name>".
  if (item.settled && item.action && drawsOwnSettlement(item.action.kind)) {
    return (
      <div className="chat-decision" data-message="action_request" data-card-open="true">
        <CardFor action={item.action} settled={item.settled} ledgerName={ledgerName} />
      </div>
    );
  }
  if (item.settled) {
    // The same settled line Month-end draws (components/cards/SettledDecision.js):
    // the approver through approverLabel, never a key label, and Undo on an approval
    // while it stands and nothing has posted. Undo reopens this card in place.
    return (
      <div className="chat-decision" data-message="action_request">
        <SettledDecision
          action={item.action}
          settled={item.settled}
          reopen={(again = null) =>
            again && again.action ? (
              <CardFor action={again.action} initial={again.initial || null} ledgerName={ledgerName} />
            ) : (
              <CardFor action={item.action || {}} ledgerName={ledgerName} />
            )
          }
        />
      </div>
    );
  }
  if (!open) {
    return (
      <div className="chat-decision" data-message="action_request" data-card-open="false">
        <button type="button" className="decision-row row" aria-expanded="false" onClick={onOpen || undefined}>
          <span className="decision-row-text t-body">{closedLine(item.action, ledgerName)}</span>
        </button>
      </div>
    );
  }
  return (
    <div className="chat-decision" data-message="action_request" data-card-open="true">
      <CardFor action={item.action || {}} ledgerName={ledgerName} {...extra} />
    </div>
  );
}
