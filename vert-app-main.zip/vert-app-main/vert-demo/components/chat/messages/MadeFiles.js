"use client";

// components/chat/messages/MadeFiles.js — THE FILES VERT MADE, IN THE THREAD
// ==============================================================================
// D38, D39, D40 (engine-pass-1/2 schedules-docs F11). A merge, a split, or a PDF's
// tables laid into a spreadsheet makes new documents. They used to be reachable only
// through the header's files chip, then the pane's "Open the file ↗": two presses, and
// nothing in the thread said a file had been made. Each one is now a card here: the
// chip opens it in the pane, and Download is one press to the bytes.

import { useState } from "react";
import DocumentView, { FileChip, fileHref, originOf } from "../results/DocumentView";
import ArtifactCard from "../ArtifactCard";

/**
 * THE SAME FILES, AS DELIVERED UNDER THEIR ANSWER (verify pass 3, D39): one card per
 * file, as a workbook is delivered (ArtifactCard), its press opening the file in the
 * pane and its trailing icon the download.
 */
export function MadeDelivered({ files }) {
  const [viewing, setViewing] = useState(null);
  const list = Array.isArray(files) ? files.filter((f) => f && f.documentId) : [];
  if (!list.length) return null;
  return (
    <div className="chat-delivered" data-delivered="" data-made-files="">
      <p className="chat-delivered-head">Delivered</p>
      <ul className="chat-delivered-list">
        {list.map((chip) => (
          <li key={chip.documentId} className="chat-delivered-item" data-made-file={chip.documentId}>
            <ArtifactCard
              type="document"
              typeWord={(GLYPH_WORDS[chip.kind] || "File")}
              title={chip.name}
              meta={chip.detail || null}
              onOpen={(event) => setViewing({ chip, origin: event && event.currentTarget ? originOf(event.currentTarget) : null })}
              downloadHref={fileHref(chip.documentId)}
              downloadName={chip.name}
              pressProps={{ "data-open-file": chip.documentId }}
            />
          </li>
        ))}
      </ul>
      <DocumentView chip={viewing && viewing.chip} origin={viewing && viewing.origin} open={Boolean(viewing)} onClose={() => setViewing(null)} />
    </div>
  );
}

const GLYPH_WORDS = { pdf: "PDF", xlsx: "Workbook", csv: "CSV", image: "Image" };

export default function MadeFiles({ item }) {
  const [viewing, setViewing] = useState(null);
  const files = item && Array.isArray(item.files) ? item.files : [];
  if (!files.length) return null;
  return (
    <div className="chat-made-files" data-message="files">
      <p className="chat-made-files-head t-footnote">{files.length === 1 ? "Vert made this file" : `Vert made ${files.length} files`}</p>
      <ul className="chat-made-files-list">
        {files.map((chip) => (
          <li key={chip.documentId} className="chat-made-file" data-made-file={chip.documentId}>
            <FileChip chip={chip} onOpen={(c, origin) => setViewing({ chip: c, origin })} />
            <a className="btn btn-quiet btn-sm chat-made-file-download" href={fileHref(chip.documentId)} download={chip.name}>
              Download
            </a>
          </li>
        ))}
      </ul>
      <DocumentView chip={viewing && viewing.chip} origin={viewing && viewing.origin} open={Boolean(viewing)} onClose={() => setViewing(null)} />
    </div>
  );
}
