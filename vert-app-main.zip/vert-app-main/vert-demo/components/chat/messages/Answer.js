// components/chat/messages/Answer.js — AT MOST FOUR BLOCKS: VERDICT, FACTS, DELIVERED, NEXT
// ==============================================================================
// Build plan §4.0.8 and FC brief 1 (spec §4.2 row 3, §1.5). Plain text, no bubble. The
// answer's direct children are at most four, in this order:
//
//   1. the verdict, in weight 600, the result first ("July bank rec ties out");
//   2. up to three facts (at most OPEN_BODY_WORDS words open), every figure bound, with the rest behind "More";
//   3. "What I delivered", only when the run produced a file (Delivered.js);
//   4. one next action (NextAction.js), never a Download, with the offer's other
//      buttons (`also`) after it in the same row.
//
// The work that produced it is not here: it is the one "Worked for 41 s ▾" line above
// (WorkedFor.js), which also carries who produced it. The old "How this was produced"
// block under every turn's answer is gone; tests/chat-answer-shape.test.js holds the
// count, the order and the absence.
//
// THE ONE MARK. "Vert's best guess. Check it." appears only when the event's
// `basis` is `suggested`, and it sits inside the verdict block because it qualifies the
// verdict. An exact answer carries nothing, because exact is the default (spec §9.1).
// An answer with no verdict and no facts carries no mark either: there is nothing for it
// to qualify, and it was drawn dangling (bug bash 10 Oct 2026).

import { VIEWS, viewToOpen } from "../results/analysis-views";
import { BEST_GUESS_TEXT, BestGuess, Disclosure, guessQualifies } from "@/components/ui";
import BoundText from "../BoundText";
import Delivered from "../Delivered";
import { MadeDelivered } from "./MadeFiles";
import NextAction from "../NextAction";
import ShownInPane from "../results/ShownInPane";
import { alsoActionsOf, asAtFactOf, nextActionOf } from "../answer/model";

// THE PAGE A BLOCK ALREADY IS (founder, 8 Nov 2026). An answer that draws one of these
// blocks has the thing itself on screen; an action whose only job is to open the same
// thing as a page ("Open 093", "Open the trial balance", "Open the statements") is a
// second way to what is already here, so it isn't offered beside it.
const PAGE_OF_BLOCK = [
  ["cashCoding", /^\/reconciliation\/bank\/cash-coding(?:[?#]|$)/],
  ["trialBalance", /^\/reports\/trial-balance(?:[?#]|$)/],
  ["accountTransactions", /^\/reports\/account-transactions(?:[?#]|$)/],
  ["gstReport", /^\/reports\/gst(?:[?#]|$)/],
  ["customerStatement", /^\/reports\/customer-statement(?:[?#]|$)/],
  ["statements", /^\/statements(?:[?#]|$)/],
  ["schedule", /^\/scheduled(?:[?#]|$)/],
  // The documents card uploads a missing statement on its own row.
  ["documents", /^\/connections\?(?:[^#]*&)?import=statement(?:[&#]|$)/],
];
import ShapeBlocks, { ShapeEntries } from "../answer/ShapeBlocks";
import { gateWordsFor } from "../answer/shape-action";
import { hasBlocks } from "../answer/shape";
import { asksOpenFor, linkedTaskOf } from "@/lib/agent/linked";

export const BEST_GUESS = BEST_GUESS_TEXT;

/**
 * HOW MANY WORDS THE ANSWER'S BODY SAYS OPEN (U57, verify pass 2). The cap was three
 * facts and every analysis line, whatever their length: the budget answer said 213 words
 * above the fold and prepaid 166, against the 150 a conversation may say. The body under
 * the verdict now says at most this many words open; the lines past it go behind More,
 * still in the page (each analysis line keeps its workbook cell). A group's own total
 * (its heading) is always drawn, and so is the first line, so an answer is never all fold.
 */
export const OPEN_BODY_WORDS = 45;

/** Words in a line as read: a {{fig:…}} token is one word. Pure. */
export function wordsIn(text) {
  if (typeof text !== "string") return 0;
  const t = text.replace(/\{\{[^}]*\}\}/g, "x").trim();
  return t ? t.split(/\s+/).length : 0;
}

/**
 * The analysis split by the budget: `blocks` keep their headings with the lines that fit
 * open, `rest` the lines folded (in order, each with its cell), and `spent` what the open
 * body used. Pure.
 */
export function foldAnalysis(analysis, budget = OPEN_BODY_WORDS) {
  let spent = 0;
  let drawn = 0;
  const rest = [];
  const blocks = (analysis && Array.isArray(analysis.blocks) ? analysis.blocks : []).map((block) => {
    if (block.summary) spent += wordsIn(block.summary);
    const lines = [];
    for (const line of block.lines) {
      const n = wordsIn(line.text);
      if (drawn === 0 || spent + n <= budget) {
        lines.push(line);
        spent += n;
        drawn += 1;
      } else rest.push(line);
    }
    return { ...block, lines };
  });
  return { blocks: blocks.filter((b) => b.lines.length || b.summary), rest, spent };
}

/** The facts that fit open after `spent` words, and the rest. At least one when nothing else is open. Pure. */
export function foldFacts(facts, spent = 0, budget = OPEN_BODY_WORDS, max = 3) {
  const open = [];
  const rest = [];
  let used = spent;
  for (const fact of facts) {
    const n = wordsIn(fact);
    if (open.length < max && rest.length === 0 && ((used === 0 && open.length === 0) || used + n <= budget)) {
      open.push(fact);
      used += n;
    } else rest.push(fact);
  }
  return { open, rest };
}

/**
 * THE TIE-OUT IS SAID ONCE (verify pass 10, D20/D22 F3). A shaped answer draws its
 * Reconciliation block (ShapeBlocks TieOut), the words included; the workbook card under
 * it then folded the same tie-out again (Delivered's TieOutFold), so the reason for a gap
 * was printed twice on one screen. The result whose tie-out the shape already drew: its
 * artifact id, or "*" when the shape names none (its one tie-out is the answer's). Null
 * when the shape draws no tie-out, and every card keeps its fold. Pure.
 */
// Words a task's title shares with any check, which say nothing about WHICH task.
const GENERIC = new Set(["reconcile", "reconciliation", "reconciliations", "account", "accounts", "the", "and", "build", "check", "your"]);

/**
 * The tasks an answer names (founder's walk, 8 Nov 2026: "which tasks are done?"
 * answered three and then listed all sixteen tasks the turn read, burying the three).
 * A task is named when every distinctive word of its title (four letters or more, not a
 * word every check shares) is in the answer's words, matched on its first five letters
 * ("fixed assets" names "the fixed asset questions"). An answer that points at a list
 * ("listed below") keeps every task, the reason the list exists (W01). Pure.
 */
export function namedTasks(tasks, texts) {
  const list = Array.isArray(tasks) ? tasks.filter((t) => t && typeof t.label === "string") : [];
  const words = (Array.isArray(texts) ? texts : [texts])
    .map((t) => (typeof t === "string" ? t : t && typeof t.text === "string" ? t.text : ""))
    .join(" ")
    .toLowerCase();
  if (!list.length) return [];
  if (/\b(listed|shown) below\b|\bbelow:/.test(words)) return list;
  const stems = new Set((words.match(/[a-z]+/g) || []).map((w) => w.slice(0, 5)));
  return list.filter((t) => {
    const own = (t.label.toLowerCase().match(/[a-z]+/g) || []).filter((w) => w.length >= 4 && !GENERIC.has(w));
    return own.length > 0 && own.every((w) => stems.has(w.slice(0, 5)));
  });
}

export function tieOutShownBy(shape) {
  if (!shape || !shape.tieOut) return null;
  return shapeArtifactId(shape) || "*";
}

/** The result an answer's shape is about: its work table's, else its first delivered item's. Pure. */
export function shapeArtifactId(shape) {
  if (!shape) return null;
  if (shape.work && shape.work.artifactId) return shape.work.artifactId;
  const items = shape.delivered && Array.isArray(shape.delivered.items) ? shape.delivered.items : [];
  const hit = items.find((d) => d && typeof d.artifactId === "string" && d.artifactId);
  return hit ? hit.artifactId : null;
}

export default function Answer({
  item,
  ledgerName,
  factsBelow = false,
  analysis = null,
  onOpenResult,
  onStartTask,
  onAsk,
  cardAnchors = null,
  openable = null,
  carriedResults = null,
  viewLinks = null,
  onOpenView = null,
  disabledReason = null,
  decisions = null,
  // The entries another answer, or the thread, draws (components/chat/Thread.js).
  skipEntries = null,
  // Whether a question of this conversation is still waiting (Thread.js): when none is,
  // the shape's "First answer the question below; then …" points at nothing (Q05).
  questionsOpen = true,
  // The turn read a list for you (answer/model.js answerReadAList): its facts are that
  // list's groups, every one open (verify pass 8, S-E2E-4).
  listing = false,
}) {
  // THE ANSWER SHAPE (founder, 17 Oct 2026; components/chat/answer/shape.js): the work as
  // a table, the tie-out, "I've delivered N things", then the entry cards. With the work
  // or the tie-out on screen, the facts (Vert's own state: "Plan ready", "1 decision is
  // waiting") are not the body any more: they go behind More, nothing dropped.
  const shape = item.shape || null;
  // A linked task's answer speaks of the task's questions, once read (lib/agent/linked.js).
  const asksOpen = asksOpenFor(item, questionsOpen);
  // Every block ShapeBlocks draws counts (shape.js BLOCK_KEYS; prod walk 6 Nov, D3).
  const shapeBody = Boolean(shape && (shape.entries || hasBlocks(shape)));
  // `factsBelow`: every fact is a decision card drawn right after this answer
  // (Thread.js factsRepeatedBelow), so the facts go behind More instead of saying it twice.
  // `analysis`: the result this answer delivered, in the engine's own claims
  // (answer/model.js analysisOf). It is the body; a fact that says a claim again is
  // dropped from the open list, and the rest (a caveat) stays under it.
  // When the figures were read is said on the face, once (asAtFactOf), never under More.
  const lifted = asAtFactOf(item.facts);
  const asAt = lifted.asAt;
  const shownFacts = lifted.rest;
  const own = analysis && Array.isArray(analysis.facts) ? analysis.facts.filter((f) => f !== asAt) : analysis ? shownFacts.filter((f) => !analysis.repeats(f)) : shownFacts;
  // The open body is held to a word budget (U57): the analysis first, then the facts.
  const fold = analysis ? foldAnalysis(analysis) : null;
  const split = factsBelow || shapeBody ? { open: [], rest: own } : listing ? { open: own, rest: [] } : foldFacts(own, fold ? Math.max(fold.spent, 1) : 0);
  const facts = split.open;
  const foldedLines = fold ? fold.rest : [];
  const more = [...split.rest, ...(item.more || [])].filter((f) => f !== asAt);
  const asAtLine = asAt ? (
    <p className="chat-answer-stale t-footnote" data-answer-as-at="">
      {asAt}
    </p>
  ) : null;
  // ONE WAY TO EACH FILE (DA2-024; critic r1 F6). The delivered file's card is the press
  // that opens it: a next action that only opens that same file ("Show the figures
  // behind it", "Open bridge") is not drawn again under it as a second button. What it
  // meant is kept: the sheet it named is where the card opens (`openAt`).
  //
  // THE ANSWER'S NEXT IS DRAWN (verify pass 1, D25/D31/D32). The card is the file, opened
  // where the file opens (lib/agent/pane.js opensOnOf); a next that goes somewhere the
  // card does not — a drill-down sheet ("Show what moved Insurance" → Detail), a view
  // ("Open bridge") — is the answer's one way on and is drawn as its button. Folding
  // those into the card left the flux answer with no drill-down, and the bridge answer
  // saying "Open the bridge" over a screen with no such control.
  const cardOpens = new Set();
  const openAt = new Map();
  if (typeof onOpenResult === "function" && openable && Array.isArray(item.delivered)) {
    for (const d of item.delivered) {
      if (!d || !openable.has(d.artifactId)) continue;
      cardOpens.add(`artifact:${d.artifactId}`);
      // The card's own view buttons ("Open bridge" on the bridge's workbook card).
      if (typeof onOpenView === "function" && viewLinks instanceof Map) {
        for (const v of viewLinks.get(d.artifactId) || []) if (v && typeof v.label === "string") cardOpens.add(`label:${v.label.trim().toLowerCase()}`);
      }
    }
  }
  const drawnOnCard = (o) => {
    if (!o) return false;
    const a = o.action || {};
    const sheet = typeof a.sheet === "string" && a.sheet.trim() ? a.sheet : null;
    if (a.kind === "open_artifact" && cardOpens.has(`artifact:${a.artifactId}`) && !opensView(o) && !sheet) return true;
    return typeof o.label === "string" && cardOpens.has(`label:${o.label.trim().toLowerCase()}`);
  };
  // THE CASH CODING GRID IS IN THE ANSWER (founder, 8 Nov 2026): its "Open 093" and
  // "Open Cash coding" buttons only led to the grid now drawn above them, so they go.
  const opensGrid = (o) => {
    const href = String((o && (o.href || (o.action && o.action.href))) || "");
    return Boolean(shape) && PAGE_OF_BLOCK.some(([key, path]) => shape[key] && path.test(href));
  };
  // ONE REQUEST, ONE CONVERSATION (founder, 8 Nov 2026). A task run from here answers
  // here: its work (the shape), its files and its open questions are drawn in this
  // conversation (lib/agent/linked.js), and an answer to a question goes back to the
  // task. "Open {task}" then only led to the same work again, so it isn't offered once
  // the work is on screen; while the task has nothing to show yet, it stays.
  // Not on a task's own answer drawn here (D35, `item.linked`): its "Open <task>" leads to
  // a card that lives only in the task's conversation.
  const taskShownHere = !item.linked && Boolean(linkedTaskOf(item) && (shapeBody || (Array.isArray(item.delivered) && item.delivered.length > 0)));
  const offered = nextActionOf(item);
  // The work already drawn whole (founder's walk, 8 Nov 2026: "Review the balances" opened
  // the three balances the answer had just shown): opening the same workbook, with no row
  // left to show, is no next step.
  const workWhole = Boolean(shape && shape.work && shape.work.artifactId && !shape.work.moreWords);
  const opensShownWork = (o) => workWhole && Boolean(o) && o.action && o.action.kind === "open_artifact" && o.action.artifactId === shape.work.artifactId && (!o.action.sheet || o.action.sheet === shape.work.sheet);
  const opensTaskHere = (o) => taskShownHere && Boolean(o) && ((o.action && o.action.href) || o.href) === item.next.action.href;
  const next = drawnOnCard(offered) || opensGrid(offered) || opensTaskHere(offered) || opensShownWork(offered) ? null : offered;
  const also = alsoActionsOf(item, offered).filter((o) => !drawnOnCard(o) && !opensGrid(o));
  // NOTHING TO SAY, NOTHING DRAWN (verify pass 1, S-E2E-1): an answer event with no
  // words, no file and no way on drew an empty block after "Start now".
  const verdictText = typeof item.verdict === "string" ? item.verdict.trim() : "";
  const answerTasks = namedTasks(item.tasks, [item.verdict, ...(Array.isArray(item.facts) ? item.facts : []), ...(Array.isArray(item.more) ? item.more : [])]);
  const hasTasks = answerTasks.length > 0;
  const hasDelivered = Array.isArray(item.delivered) && item.delivered.length > 0;
  const hasOffer = Boolean(item.offer && item.offer.text);
  if (!verdictText && !asAt && !shapeBody && !analysis && !facts.length && !more.length && !foldedLines.length && !hasTasks && !hasDelivered && !hasOffer && !next && !also.length) return null;
  if (shapeBody && !analysis) {
    // A SHAPED ANSWER IS FOUR BLOCKS (Q05 AN9, tg-shape 20 Oct 2026; the founder's
    // reference answer, research reference/answer-shape.md). Laid out flat it was six to
    // nine (verdict, More, table and tie-out, delivered, file card, entry cards, offer,
    // next), and AN9's "≤ 4 visible blocks" failed on every shaped answer for four
    // passes. The reference reads as four things, so the answer is drawn as four:
    //   1. the verdict, with Vert's own facts folded under "More" beside it;
    //   2. the work: the table, its tie-out and "I've delivered N things";
    //   3. what was delivered, to open or press: the file card and the entry cards;
    //   4. the one next action.
    const deliverables = Boolean((Array.isArray(item.made) && item.made.length) || hasDelivered || shape.entries || hasOffer || hasTasks);
    return (
      <div className="chat-answer" data-message="assistant_text" data-answer-shaped="">
        <div className="chat-answer-verdict">
          <p className="chat-verdict">
            <BoundText text={gateWordsFor(item.verdict, shape)} figures={item.figures} ledgerName={ledgerName} />
          </p>
          {item.basis === "suggested" && guessQualifies(item.verdict, item.facts, item.more, analysis) ? <BestGuess /> : null}
          {asAtLine}
          {more.length ? (
            <Disclosure summary="More" className="chat-more">
              <ul className="chat-facts">
                {more.map((fact, i) => (
                  <li key={i}>
                    <BoundText text={fact} figures={item.figures} ledgerName={ledgerName} />
                  </li>
                ))}
              </ul>
            </Disclosure>
          ) : null}
        </div>
        <ShownInPane artifactId={shapeArtifactId(shape)}>
          <ShapeBlocks shape={shape} figures={item.figures} ledgerName={ledgerName} onOpenResult={onOpenResult} questionsOpen={asksOpen} superseded={item.superseded || null} seq={item.seq} cardsBelow={hasDelivered || Boolean(shape && shape.entries)} />
        </ShownInPane>
        {deliverables ? (
          <div className="chat-answer-deliverables" data-answer-deliverables="">
            {hasTasks ? (
              <ul className="chat-answer-tasks" data-answer-tasks="">
                {answerTasks.map((t) => (
                  <li key={t.template}>
                    {t.href ? (
                      <a className="link chat-answer-task" href={t.href}>
                        {t.label}
                      </a>
                    ) : (
                      <span className="chat-answer-task">{t.label}</span>
                    )}
                  </li>
                ))}
              </ul>
            ) : null}
            {Array.isArray(item.made) && item.made.length ? <MadeDelivered files={item.made} /> : null}
            {hasDelivered ? <Delivered delivered={item.delivered} figures={item.figures} ledgerName={ledgerName} openable={openable} carriedResults={carriedResults} tieOutShown={tieOutShownBy(shape)} onOpen={onOpenResult} openAt={openAt} views={viewLinks} onOpenView={onOpenView} head={!shape.delivered} /> : null}
            {shape.entries ? (
              <ShapeEntries
                shape={shape}
                figures={item.figures}
                ledgerName={ledgerName}
                decisions={decisions}
                skip={skipEntries}
                onOpenResult={onOpenResult}
                onStartTask={onStartTask}
                onAsk={onAsk}
                disabledReason={disabledReason}
                seq={item.seq}
              />
            ) : null}
            {hasOffer ? (
              <p className="chat-answer-offer t-body" data-answer-offer="">
                <BoundText text={item.offer.text} figures={item.figures} ledgerName={ledgerName} />
              </p>
            ) : null}
          </div>
        ) : null}
        {next || also.length ? (
          <NextAction
            next={next}
            also={also}
            onOpenResult={onOpenResult}
            onStartTask={onStartTask}
            onAsk={onAsk}
            cardAnchors={cardAnchors}
            disabledReason={disabledReason}
          />
        ) : null}
      </div>
    );
  }
  return (
    <div className="chat-answer" data-message="assistant_text">
      <div className="chat-answer-verdict">
        <p className="chat-verdict">
          <BoundText text={gateWordsFor(item.verdict, shape)} figures={item.figures} ledgerName={ledgerName} />
        </p>
        {item.basis === "suggested" && guessQualifies(item.verdict, item.facts, item.more, analysis) ? <BestGuess /> : null}
        {asAtLine}
      </div>
      {shapeBody ? (
        // WORDS ABOVE THE FOLD WITH A PANE OPEN (verify pass 5, U57): while the result the
        // shape is about is open in the pane, its table, tie-out and delivered list fold
        // to "Shown in the pane" (with "Show here too"), as an analysis body does; the
        // verdict stays, and the entry cards below stay (they are where you press).
        <ShownInPane artifactId={shapeArtifactId(shape)}>
          <ShapeBlocks shape={shape} figures={item.figures} ledgerName={ledgerName} onOpenResult={onOpenResult} questionsOpen={asksOpen} superseded={item.superseded || null} seq={item.seq} cardsBelow={hasDelivered || Boolean(shape && shape.entries)} />
        </ShownInPane>
      ) : null}
      {analysis || facts.length || more.length || foldedLines.length ? (
        <div className="chat-answer-facts">
          {analysis ? (
            // DA2-039: while this result is open in the pane, the rail keeps the verdict and
            // says "Shown in the pane" instead of drawing the document again.
            <ShownInPane artifactId={analysis.artifactId}>
              <Analysis analysis={{ ...analysis, blocks: fold.blocks }} ledgerName={ledgerName} />
            </ShownInPane>
          ) : null}
          {analysis && analysis.stale ? (
            // Q08 / F-3: an earlier answer keeps its own run's figures, and says so.
            <p className="chat-answer-stale t-footnote" data-answer-stale="">
              These figures are from this run. A later run below has the current ones.
            </p>
          ) : null}
          {facts.length ? (
            <ul className="chat-facts">
              {facts.map((fact, i) => (
                <li key={i}>
                  <BoundText text={fact} figures={item.figures} ledgerName={ledgerName} />
                </li>
              ))}
            </ul>
          ) : null}
          {more.length || foldedLines.length ? (
            <Disclosure summary="More" className="chat-more">
              {foldedLines.length ? (
                <ul className="chat-facts" data-folded-lines="">
                  {foldedLines.map((line, j) => (
                    <li key={j} data-cell={line.cell || undefined}>
                      <BoundText text={line.text} figures={analysis.figures} ledgerName={ledgerName} />
                    </li>
                  ))}
                </ul>
              ) : null}
              {more.length ? (
              <ul className="chat-facts">
                {more.map((fact, i) => (
                  <li key={i}>
                    <BoundText text={fact} figures={item.figures} ledgerName={ledgerName} />
                  </li>
                ))}
              </ul>
              ) : null}
            </Disclosure>
          ) : null}
        </div>
      ) : null}
      {answerTasks.length ? (
        // The tasks the answer was read from (W01: "listed below" with nothing below).
        <ul className="chat-answer-tasks" data-answer-tasks="">
          {answerTasks.map((t) => (
            <li key={t.template}>
              {t.href ? (
                <a className="link chat-answer-task" href={t.href}>
                  {t.label}
                </a>
              ) : (
                <span className="chat-answer-task">{t.label}</span>
              )}
            </li>
          ))}
        </ul>
      ) : null}
      {Array.isArray(item.made) && item.made.length ? <MadeDelivered files={item.made} /> : null}
      {item.delivered && item.delivered.length ? <Delivered delivered={item.delivered} figures={item.figures} ledgerName={ledgerName} openable={openable} carriedResults={carriedResults} tieOutShown={tieOutShownBy(shape)} onOpen={onOpenResult} openAt={openAt} views={viewLinks} onOpenView={onOpenView} head={!(shape && shape.delivered)} /> : null}
      {shape && shape.entries ? (
        <ShapeEntries
          shape={shape}
          figures={item.figures}
          ledgerName={ledgerName}
          decisions={decisions}
          skip={skipEntries}
          onOpenResult={onOpenResult}
          onStartTask={onStartTask}
          onAsk={onAsk}
          disabledReason={disabledReason}
          seq={item.seq}
        />
      ) : null}
      {item.offer && item.offer.text ? (
        <p className="chat-answer-offer t-body" data-answer-offer="">
          <BoundText text={item.offer.text} figures={item.figures} ledgerName={ledgerName} />
        </p>
      ) : null}
      {next || also.length ? (
        <NextAction
          next={next}
          also={also}
          onOpenResult={onOpenResult}
          onStartTask={onStartTask}
          onAsk={onAsk}
          cardAnchors={cardAnchors}
          disabledReason={disabledReason}
        />
      ) : null}
    </div>
  );
}

/**
 * The analysis body: each group's label in bold, then its lines ("Office expenses:
 * $1,520.00 → $20,010.00 (+1216%), driven by Officeworks …"), each line the engine's
 * claim with its figures bound from the result. A line standing alone (the bottom line)
 * is drawn after the groups, unlabelled. Every line names its workbook cell, so a check
 * can hold the screen to the workbook.
 */
function Analysis({ analysis, ledgerName }) {
  return (
    <div className="chat-analysis" data-analysis={analysis.artifactId}>
      {analysis.blocks.map((block, i) => (
        <div key={i} className="chat-analysis-group">
          {block.summary ? (
            // The group's total, said once, as its heading (verify pass 1, flux).
            <p className="chat-analysis-label" data-group-summary="">
              <BoundText text={block.summary} figures={analysis.figures} ledgerName={ledgerName} />
            </p>
          ) : block.label ? (
            <p className="chat-analysis-label">{block.label}</p>
          ) : null}
          <ul className="chat-facts">
            {block.lines.map((line, j) => (
              <li key={j} data-cell={line.cell || undefined}>
                <BoundText text={line.text} figures={analysis.figures} ledgerName={ledgerName} />
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

/** Whether a next action opens one of a file's views (a bridge, a commentary), not just the file. */
function opensView(o) {
  const a = (o && o.action) || {};
  if (viewToOpen(o)) return true;
  return typeof a.sheet === "string" && Object.prototype.hasOwnProperty.call(VIEWS, a.sheet.trim().toLowerCase());
}
