"use client";

// components/chat/messages/CouldntTell.js — A FIRST-CLASS OUTCOME, NOT AN ERROR
// ==============================================================================
// Spec §4.2 row 7. What Vert couldn't establish and why, in one line, and what would
// settle it. Both are always visible: a reason behind a disclosure is a reason nobody
// reads (tests/abstention.test.js holds the same rule for the old rail). Neutral
// styling: not knowing is honest, not alarming.
//
// SEND AGAIN WHEN ASKING AGAIN IS THE REMEDY (harsh wave 3, ENG-PLATFORM / DEMO-UI). When
// the AI model sent back nothing twice, the engine says so in words and keeps the
// person's message (`resend`): one press sends it again, through the composer's road.
// Gone once sent, or once a later message carries the same words.

import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { SEND_AGAIN } from "@/lib/agent/words";

export const NOT_SENT_AGAIN = "It wasn't sent. Your message is still kept here.";

export default function CouldntTell({ item, onResend = null, disabledReason = null }) {
  const [state, setState] = useState({ busy: false, sent: false, error: null });
  const offer = Boolean(item.resend && !item.resent && !state.sent && typeof onResend === "function");
  async function resend() {
    if (state.busy || state.sent) return;
    setState({ busy: true, sent: false, error: null });
    const result = await onResend(item.resend);
    if (result && result.ok === false) setState({ busy: false, sent: false, error: NOT_SENT_AGAIN });
    else setState({ busy: false, sent: true, error: null });
  }
  return (
    <div className="chat-couldnt" data-message="abstention" role="note">
      <p className="chat-couldnt-head">Couldn't tell</p>
      <p className="chat-couldnt-reason">{item.reason || "Vert didn't record why."}</p>
      {item.next ? <p className="chat-couldnt-next">{item.next}</p> : null}
      {offer ? (
        <p>
          <Button variant="secondary" size="sm" busy={state.busy} busyLabel="Sending…" disabledReason={disabledReason} onClick={resend} data-resend="">
            {SEND_AGAIN}
          </Button>
        </p>
      ) : null}
      {state.error ? <p className="chat-reason" role="alert">{state.error}</p> : null}
    </div>
  );
}
