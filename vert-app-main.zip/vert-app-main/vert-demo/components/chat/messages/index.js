// components/chat/messages/index.js — ONE RENDERER PER EVENT TYPE, AND NO OTHERS
// ==============================================================================
// The thread renders a fixed vocabulary (spec §4.2). This table maps every stored
// event type to what draws it, so the vocabulary join (G1's `event-types-join`) can
// hold three things equal: the engine's EVENT_TYPES, the database constraint, and
// these keys. A type the engine can store and this table does not name would be
// silently dropped; a key here the engine cannot store would be dead code.
//
// Several types fold into one component (a question and its answer; a decision and
// its settlement; the run's state, its steps and its usage, which make up the one
// "Worked for 41 s ▾" line). `task_started` retitles the conversation header. `plan` and `memory_used`
// are iteration 2: named so the vocabulary is complete, drawn as nothing until their
// work exists (spec §1.9: nothing is listed unless it is built).

import Answer from "./Answer";
import CouldntTell from "./CouldntTell";
import Decision from "./Decision";
import MadeFiles from "./MadeFiles";
import Problem from "./Problem";
import Result from "./Result";
import YourMessage from "./YourMessage";
import CanDoNow from "../CanDoNow";
import Clarification from "../Clarification";
import WorkedFor from "../WorkedFor";
import ConversationHeader from "../ConversationHeader";

export const MESSAGE_RENDERERS = Object.freeze({
  user_message: YourMessage,
  run_state: WorkedFor,
  tool_call: WorkedFor,
  tool_result: WorkedFor,
  assistant_text: Answer,
  clarification: Clarification,
  clarification_answered: Clarification,
  action_request: Decision,
  decision_settled: Decision,
  artifact: Result,
  abstention: CouldntTell,
  error: Problem,
  assistant_unavailable: CanDoNow,
  task_started: ConversationHeader,
  usage: WorkedFor,
  plan: null,
  memory_used: null,
});

/** The thread model's item kinds, each to the component that draws it. */
export const ITEM_RENDERERS = Object.freeze({
  you: YourMessage,
  work: WorkedFor,
  answer: Answer,
  question: Clarification,
  decision: Decision,
  result: Result,
  couldnt_tell: CouldntTell,
  problem: Problem,
  can_do_now: CanDoNow,
  // The documents a chat tool made (a merge, a split, a PDF's tables): drawn from the
  // tool_result's document rows, so no event type of its own.
  files: MadeFiles,
});
