"use client";

// components/chat/messages/YourMessage.js — WHAT YOU ASKED, AT THE TOP OF EVERY TURN
// ==============================================================================
// Spec §4.2 row 1. A right-aligned bubble for what you asked Vert. Every turn opens with
// one (p1 chat, founders' review 23 Oct 2026): a conversation you come back to a day
// later reads as a list of what was asked and what Vert did about each.
//
// A TASK YOU STARTED IS WHAT YOU ASKED (`item.started`, lib/agent/events.js). A Month-end
// Start, a preset or a run again records no message, so the turn used to open on Vert's
// work with nothing above it. The task's title is the bubble, with a small note under it
// saying where it was started ("Started from Month-end", "Run again"): the words are the
// task's name, and the note says they were not typed.
//
// WHO TYPED IT (build plan §19.0.9). A turn typed under a person key carries that
// person (`item.by`, from the engine's `turn.actor`), and the name sits above the
// bubble, so a teammate opening the conversation reads "Sam Lee" over Sam's follow-up.
// A turn with no recorded person shows no name: never the viewer's, never a guess.
//
// THE FILES YOU SENT ARE CHIPS, NOT IDS (D39, D04, U14). A message travels with one
// line per attached file ("Attached file: <name> (document <uuid>)", Composer.js), so
// the chat's document tools can read the id. That line is for Vert: the bubble shows
// your words, and each file as the chip you attached, which opens it.

import { useState } from "react";
import "./people.css";
import DocumentView, { FileChip, splitAttachments } from "../results/DocumentView";

/** The note under a started task's bubble. Pure. */
export const STARTED_WORDS = Object.freeze({
  month_end: "Started from Month-end",
  again: "Run again",
  chat: "Started from a chat",
  budget: "Started from Budgets",
  schedule: "Started on its schedule",
});

export function startedNote(item) {
  return item && typeof item.started === "string" && Object.hasOwn(STARTED_WORDS, item.started) ? STARTED_WORDS[item.started] : null;
}

export default function YourMessage({ item }) {
  const [viewing, setViewing] = useState(null);
  const note = startedNote(item);
  const { text, files } = note ? { text: item.text, files: [] } : splitAttachments(item.text);
  return (
    <div className="chat-you" data-message="user_message" data-started={note ? item.started : undefined}>
      {item.by ? (
        <p className="chat-you-by" data-turn-actor="">
          {item.by}
        </p>
      ) : null}
      {text ? <p className="chat-you-bubble">{text}</p> : null}
      {note ? (
        <p className="chat-you-note t-footnote" data-started-note="">
          {note}
        </p>
      ) : null}
      {files.length ? (
        <ul className="chat-you-files" aria-label={files.length === 1 ? "1 file attached" : `${files.length} files attached`}>
          {files.map((chip) => (
            <li key={chip.documentId}>
              <FileChip chip={chip} onOpen={(c, origin) => setViewing({ chip: c, origin })} />
            </li>
          ))}
        </ul>
      ) : null}
      {files.length ? <DocumentView chip={viewing && viewing.chip} origin={viewing && viewing.origin} open={Boolean(viewing)} onClose={() => setViewing(null)} /> : null}
    </div>
  );
}
