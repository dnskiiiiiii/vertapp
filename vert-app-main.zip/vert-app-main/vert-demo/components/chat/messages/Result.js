"use client";

// components/chat/messages/Result.js — A RESULT, AS A CARD THAT OPENS
// ==============================================================================
// Spec §4.2 row 6. The verdict line, two or three key figures, Open, and Download
// Excel where the engine built a workbook. The full result opens in the result pane
// (components/chat/ResultPane.js). A result has no commit button: the bank rec's
// verdict closes its task when the gap is explained, and nothing here marks anything
// reconciled (spec §3.3).
//
// A key figure is shown only when the engine gave it a label. A figure with no label
// has nothing true to be called, and its reference is an internal name.
//
// THE CARD OPENS ITS VIEWS (build plan §20.0 decision 7, F-WIRE). A workbook card that
// a bridge or a commentary opens from carries "Open bridge" / "Edit commentary" beside
// Open (`views`, from components/chat/results/analysis-views.js viewLinks). Each is
// drawn only when the conversation holds the artifact that carries that view, and only
// with a way to open it (`onOpenView`): never a control that opens nothing.

import EventFigure from "../EventFigure";
import BoundText from "../BoundText";
import { appHref } from "@/lib/agent/links";
import TieOutCard from "@/components/cards/TieOutCard";
import { workbookHref } from "@/app/api/workpapers/shared";

export function labelledFigures(figures, limit = 3) {
  const table = figures && typeof figures === "object" ? figures : {};
  return Object.entries(table)
    .filter(([, f]) => f && typeof f.label === "string" && f.label.trim())
    .slice(0, limit)
    .map(([ref, f]) => ({ ref, figure: f }));
}

export default function Result({ item, onOpen, ledgerName, views = null, onOpenView = null }) {
  const a = item.artifact || {};
  // A copy a person's saved edit replaced draws nothing (Q11): the edit is a new version
  // of the same document, not a later run, and the pane opens the latest.
  if (item.replaced && item.replacedByEdit) return null;
  if (item.byYou && !item.replaced) {
    // The person's own version, said as theirs, in one quiet line (Q11).
    const v = Number.isInteger(a.version) ? a.version : null;
    return (
      <p className="chat-result-replaced" data-message="artifact" data-by-you="true">
        {`You saved ${a.title || "your edit"}${v ? `, version ${v}` : ""}.`}
      </p>
    );
  }
  if (item.byYou) return null;
  if (item.replaced) {
    // A later run of the same result replaced this one (lib/agent/events.js): one line,
    // no figures and no Open, so the thread never offers the stale copy's numbers.
    return (
      <p className="chat-result-replaced" data-message="artifact" data-replaced="true">
        {a.title ? `${a.title}: replaced by a later run below.` : "Replaced by a later run below."}
      </p>
    );
  }
  const figures = labelledFigures(a.figures);
  // The engine's path, as the route in app/ that serves it, or no link (lib/agent/links.js).
  // An in-pane edit appends the artifact again with `version` n; its file is the saved
  // version, never the house workbook rebuilt from the table (which drops the edit).
  const saved = Number.isInteger(a.version) && a.version > 0 && a.artifactId;
  const xlsx = saved ? workbookHref(a.artifactId, a.version) : appHref(a.xlsxHref);
  return (
    <div className="chat-result-card" data-message="artifact">
      <p className="chat-result-title">{a.title}</p>
      {a.verdict ? (
        <p className="chat-verdict">
          <BoundText text={a.verdict} figures={a.figures} ledgerName={ledgerName} />
        </p>
      ) : null}
      {figures.length ? (
        <dl className="chat-keyfigs">
          {figures.map(({ ref, figure }) => (
            <div key={ref}>
              <dt>{figure.label}</dt>
              <dd>
                <EventFigure figure={figure} figureRef={ref} />
              </dd>
            </div>
          ))}
        </dl>
      ) : null}
      {/* Does the result agree with the books? The engine's tie-out, drawn only when it
          sent one (build plan §19.0.13); the card itself draws nothing for an empty list. */}
      <TieOutCard artifact={a} />
      <div className="chat-result-actions">
        {typeof onOpen === "function" ? (
          <button type="button" className="chat-quiet" onClick={() => onOpen(a.artifactId)}>
            Open
          </button>
        ) : null}
        {typeof onOpenView === "function" && Array.isArray(views)
          ? views.map((v) => (
              <button key={v.view} type="button" className="chat-quiet" data-opens-view={v.view} onClick={() => onOpenView(v.artifactId, v.view)}>
                {v.label}
              </button>
            ))
          : null}
        {xlsx ? (
          <a className="chat-quiet" href={xlsx}>
            Download Excel
          </a>
        ) : null}
      </div>
    </div>
  );
}
