"use client";

// components/chat/SendingNow.js — YOUR MESSAGE, AND THAT VERT IS ON IT, WHILE IT SENDS
// ==============================================================================
// p0, 23 Oct 2026 ("when I prompt the thing, it doesn't do the task"). The engine answers
// a message inside the request that sends it, 11–69 s on staging, and until it returned
// the screen showed nothing new. What you sent is drawn at once as your message
// (YourMessage, so it is the bubble the thread will draw), with Vert's working line under
// it: the glyph and words the thread's own running turn uses (WorkedFor). Used by the ask
// box on Month-end and by the conversation (lib/agent/outgoing.js says when it gives way).
// A send that fails is said by the box it came from, with Try again; this draws nothing
// for it.

import YourMessage from "./messages/YourMessage";
import { IconSpinner } from "@/components/ui/icons";

export const SENDING_WORDS = "Vert is working on it. This can take a minute…";

export default function SendingNow({ text, className = null }) {
  return (
    <div className={["chat-sending", className].filter(Boolean).join(" ")} role="status" data-sending="">
      <YourMessage item={{ text }} />
      <p className="chat-did-running" aria-busy="true">
        <IconSpinner className="chat-working" size={16} />
        {SENDING_WORDS}
      </p>
    </div>
  );
}
