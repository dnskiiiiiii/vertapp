"use client";

// components/chat/DataFetched.js — WHAT VERT READ FOR THIS TURN, IN ONE BLOCK
// ==============================================================================
// p1 chat (founders' review, 23 Oct 2026). The second thing in every turn, under what
// you asked: a compact block naming the sources Vert read to answer it ("Read 3 sources":
// your books in Xero · 4 accounts, the bank statement · 12 lines, a file you attached),
// with one Open that shows exactly this turn's data and sources in the side panel
// (SourcesPanel.js), each record a press from where it lives.
//
// Only what the engine recorded (lib/agent/turn-sources.js). A turn that recorded no
// read says so in words, and its Open still shows the connected sources. While Vert is
// working the chips fill in as each read arrives.

import { useSourcesPanel } from "./sources-context";
import { fetchedSummary } from "@/lib/agent/turn-sources";
import { IconCaretRight } from "@/components/ui/icons";

/** The block's words when nothing was recorded: while working, and after. Pure. */
export function nothingWords(sources, running = false) {
  if (running) return "Reading…";
  if (sources && sources.steps > 0) return "Steps recorded, sources not listed";
  return "Nothing new read";
}

// A figure whose source is a rule (Vert's own limit) or the person's answer (a limit
// they typed) was not read from the books (w51, production walk 5 Nov 2026: a typed
// small-balance limit was said to be "from your records").
const NOT_FROM_THE_BOOKS = new Set(["rule", "answer"]);

/** The block's words for the figures the answer carries, when no source was read. Pure. */
export function figuresHead(figures) {
  const kinds = (figures || []).map((f) => (f && f.figure && f.figure.source ? f.figure.source.kind : null));
  if (kinds.some((k) => !NOT_FROM_THE_BOOKS.has(k))) return "Used figures from your records";
  if (kinds.includes("answer")) return "Used figures you gave";
  return null;
}

/**
 * ONE QUIET LINK ON THE TURN'S IDENTITY ROW (founder, 8 Nov 2026: "industry grade,
 * really simple"). The boxed block with its chips was the heaviest thing above every
 * answer; what Vert read is now "Read 5 sources ›" beside the time, and the press opens
 * the same side panel with every source and figure. The full block is kept for callers
 * that ask for it (`compact={false}`).
 */
function FetchedLink({ head, panel, outline, expanded }) {
  if (!panel || !outline) {
    return (
      <span className="chat-fetched-link" data-data-fetched="">
        {head}
      </span>
    );
  }
  return (
    <button
      type="button"
      className="chat-did-toggle chat-fetched-link"
      data-data-fetched=""
      data-open-sources=""
      aria-haspopup="dialog"
      aria-expanded={expanded ? "true" : "false"}
      aria-label={`${head}: open the data and sources for this answer`}
      onClick={() => panel.open(outline)}
    >
      {head}
      <IconCaretRight className="chat-did-glyph" size={12} aria-hidden="true" />
    </button>
  );
}

export default function DataFetched({ sources, ledgerName = null, outline = null, running = false, compact = false }) {
  const panel = useSourcesPanel();
  const summary = fetchedSummary(sources, ledgerName);
  const figures = sources && Array.isArray(sources.figures) ? sources.figures.length : 0;
  const chips = [...summary.chips];
  if (figures) chips.push({ id: "figures", label: "Figures in the answer", detail: String(figures), failed: false });
  const head = summary.head || (figures && figuresHead(sources.figures)) || nothingWords(sources, running);
  const expanded = Boolean(panel && outline && panel.openKey === outline.key);
  if (compact) return <FetchedLink head={head} panel={panel} outline={outline} expanded={expanded} />;
  return (
    <section className="chat-fetched" data-data-fetched="" data-fetched-count={summary.chips.length} aria-label="Data fetched">
      <div className="chat-fetched-row">
        <span className="chat-fetched-label t-footnote">Data fetched</span>
        <span className="chat-fetched-head">{head}</span>
        {panel && outline ? (
          <button
            type="button"
            className="btn btn-quiet btn-sm chat-fetched-open"
            data-open-sources=""
            aria-haspopup="dialog"
            aria-expanded={expanded ? "true" : "false"}
            aria-label="Open the data and sources for this answer"
            onClick={() => panel.open(outline)}
          >
            Open
            <IconCaretRight className="caret-trailing" aria-hidden="true" />
          </button>
        ) : null}
      </div>
      {chips.length ? (
        <ul className="chat-fetched-chips">
          {chips.map((c) => (
            <li key={c.id} className="chat-fetched-chip" data-source-chip={c.id} data-failed={c.failed ? "true" : undefined}>
              <span className="chat-fetched-chip-name">{c.label}</span>
              {c.detail ? <span className="chat-fetched-chip-detail">{c.detail}</span> : null}
            </li>
          ))}
        </ul>
      ) : null}
    </section>
  );
}
