// components/chat/NextAction.js — THE ANSWER'S ONE NEXT ACTION
// ==============================================================================
// Build plan §4.0.8 block 4 and FC brief 4. Exactly one button, the one thing to do
// next ("Review the 3 reconciling items"), chosen by components/chat/answer/model.js
// `nextActionOf`: never a Download, because the delivered chip already downloads.
//
// NOT THE ACCENT. A next action takes the person somewhere: it opens a result, a card,
// a task's conversation or the statement import. It writes nothing, so it is the
// bordered secondary button (§4.0.9: per view at most one purple fill, and it is the
// commit on a card that writes). In iteration 1 this was purple, beside a card whose
// purple button did write, and the two read as the same kind of press.
//
// NOTHING IS DRAWN THAT CANNOT BE DONE. Each action kind needs either a link this app
// serves or a handler the thread was given; a kind with neither draws no button rather
// than one that does nothing (tests/no-false-affordance.test.js).
//
// WRITING IT YOURSELF OPENS THE BLANK EDITOR HERE (eval r2 §9.3.F, EC2-fix2). When a
// draft can't be built (a question was skipped, the chart can't be read) the engine's
// next action is `{kind: "write_entry", period}`. It needs no handler from the thread:
// the press opens the same blank JournalEditor as Can-do-now's "Write a journal entry
// yourself", for that period. Save is `POST /journal/drafts`, a draft that waits for a
// person's approval on Month-end; nothing posts.

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui";
import { appHref } from "@/lib/agent/links";
import JournalEditor from "@/components/cards/JournalEditor";
import { DRAFT_SAVED } from "./CanDoNow";
import { useBudgetSheet } from "@/components/budgets/sheet-context";
import { opensBudgets, viewToOpen } from "./results/analysis-views";
import { speaksToYou } from "./answer/model";
import { ReviewSheet } from "./answer/BillInbox";
import InboxSheet, { opensInbox } from "@/components/bills/InboxSheet";
import ReportSheet, { reportOf } from "@/components/reports/ReportSheet";

import { IconCaretRight } from "@/components/ui/icons";
/** The element id the thread gives a card an answer points at. */
export function cardAnchor(actionId) {
  return `card-${String(actionId).replace(/[^A-Za-z0-9_-]/g, "_")}`;
}

/**
 * How the thread carries out an action, or null when it cannot here.
 * `handlers`: { onOpenResult(artifactId, sheet), onStartTask(template, period, {view}), onAsk(text),
 * cardAnchors: Set of the action ids whose cards the thread anchored }.
 */
/** The bill or invoice id a `/bills/<id>` address names, or null. Pure. */
export function billOf(href) {
  const m = typeof href === "string" ? /^\/bills\/([A-Za-z0-9_-]{1,80})(?:[?#].*)?$/.exec(href) : null;
  return m ? m[1] : null;
}

export function actionFor(next, handlers = {}) {
  if (!next) return null;
  if (next.href && billOf(next.href) && typeof handlers.onOpenBill === "function") return { onClick: () => handlers.onOpenBill(billOf(next.href), next.label) };
  if (next.href && opensInbox(next.href) && typeof handlers.onOpenInbox === "function") return { onClick: () => handlers.onOpenInbox() };
  if (next.href && reportOf(next.href) && typeof handlers.onOpenReport === "function") return { onClick: () => handlers.onOpenReport(reportOf(next.href)) };
  if (next.href) {
    const href = appHref(next.href);
    return href ? { href } : null;
  }
  const a = next.action || {};
  switch (a.kind) {
    case "open_artifact":
      return typeof handlers.onOpenResult === "function" && a.artifactId ? { onClick: () => handlers.onOpenResult(a.artifactId, a.sheet || null) } : null;
    case "open_card":
      // Every open card is drawn in its turn (nothing is folded away), and the
      // thread anchors the ones an answer points at (Thread.js). A
      // card that is not drawn here is not linked: the anchor would go nowhere.
      return a.actionId && handlers.cardAnchors instanceof Set && handlers.cardAnchors.has(a.actionId) ? { href: `#${cardAnchor(a.actionId)}` } : null;
    case "start_task":
      // A start that is "Open bridge" says so, so the task's conversation opens the
      // bridge on arrival instead of asking for the same press again (viewToOpen).
      // `again` (engine NextActionTarget, 8 Nov 2026: fixed assets' Check again) runs the
      // task again in this conversation, as its Run again does.
      return typeof handlers.onStartTask === "function" && a.template
        ? { onClick: () => handlers.onStartTask(a.template, a.period || null, a.again === true ? { view: viewToOpen(next), again: true, here: true } : { view: viewToOpen(next) }) }
        : null;
    case "ask":
      // Words Vert says to you are never sent as yours (bug bash 10 Oct 2026; answer/model.js
      // speaksToYou drops them before they get here, and this holds any other caller).
      return typeof handlers.onAsk === "function" && a.text && !speaksToYou(a.text) ? { onClick: () => handlers.onAsk(a.text) } : null;
    case "write_entry":
      return typeof a.period === "string" && /^\d{4}-\d{2}$/.test(a.period) ? { write: { period: a.period } } : null;
    case "open":
      if (opensBudgets(a.href) && typeof handlers.onOpenBudgets === "function") return { onClick: (event) => handlers.onOpenBudgets(event && event.currentTarget) };
      // A bill's review opens beside the chat (founder, 8 Nov 2026), not on its page.
      if (billOf(a.href) && typeof handlers.onOpenBill === "function") return { onClick: () => handlers.onOpenBill(billOf(a.href), next.label) };
      // Bills & invoices opens beside the chat too: the inbox, its upload and its reviews.
      if (opensInbox(a.href) && typeof handlers.onOpenInbox === "function") return { onClick: () => handlers.onOpenInbox() };
      // So does the bank reconciliation report.
      if (reportOf(a.href) && typeof handlers.onOpenReport === "function") return { onClick: () => handlers.onOpenReport(reportOf(a.href)) };
    // falls through: any other `open` is a link this app serves, or nothing
    // A `link` (w25 contract §4: "cash code" answers "Open Cash coding") is a way there,
    // the same: drawn only when this app serves its path.
    case "link":
    case "import_statement": {
      const href = appHref(a.href);
      return href ? { href } : null;
    }
    default:
      return null;
  }
}

/**
 * The answer's next action, then its other offers (`also`, W0r A8: "Draft commentary",
 * "Budgets") as more secondary buttons in the same row.
 *
 * WHY `also` IS HERE AND NOT A FIFTH BLOCK. The offer is one sentence with its buttons
 * (G4 eval r2, OQ line 6): BvA's answer said "Open bridge" and carried "Draft commentary"
 * and "Budgets" in `also`, and the demo drew only the first, so the offer named things
 * the person had no button for. They share the next action's row, so the answer stays at
 * four blocks (tests/chat-answer-shape.test.js). Each is held to the same rule as `next`:
 * one that cannot be done here is not drawn.
 */
export default function NextAction({ next, also = [], onOpenResult, onStartTask, onAsk, cardAnchors = null, disabledReason = null }) {
  const budgets = useBudgetSheet();
  const [bill, setBill] = useState(null);
  const [inbox, setInbox] = useState(false);
  const [report, setReport] = useState(null);
  const handlers = { onOpenResult, onStartTask, onAsk, cardAnchors, onOpenBudgets: budgets ? budgets.open : null, onOpenBill: (id, label) => setBill({ id, label }), onOpenInbox: () => setInbox(true), onOpenReport: (r) => setReport(r) };
  const how = next ? actionFor(next, handlers) : null;
  if (how && how.write) return <WriteEntry next={next} period={how.write.period} />;
  const offers = (Array.isArray(also) ? also : [])
    .map((o) => ({ o, how: actionFor(o, handlers) }))
    // A second write_entry would open a second editor beside the first; not an offer.
    .filter((x) => x.how && !x.how.write);
  if (!how && !offers.length) return null;
  const row = [...(how ? [{ o: next, how, also: false }] : []), ...offers.map((x) => ({ ...x, also: true }))];
  // Why a busy conversation holds a press is said once, under the first button it holds;
  // the others are held without repeating it.
  const firstHeld = disabledReason ? row.findIndex((x) => waits(x.o)) : -1;
  const buttons = (
    <p className="chat-next" data-next-action={how ? next.kind || (next.action && next.action.kind) || "" : undefined}>
      {row.map((x, i) => (
        <Button
          key={`${x.o.label}-${i}`}
          variant="secondary"
          href={x.how.href}
          onClick={x.how.onClick}
          disabledReason={i === firstHeld ? disabledReason : null}
          disabled={Boolean(disabledReason && waits(x.o))}
          data-also-action={x.also ? (x.o.action && x.o.action.kind) || "" : undefined}
        >
          {shownWords(x.o)}<IconCaretRight className="caret-trailing" />
        </Button>
      ))}
    </p>
  );
  if (!bill && !inbox && !report) return buttons;
  return (
    <>
      {buttons}
      {bill ? <ReviewSheet id={bill.id} title={bill.label || "Review"} onClose={() => setBill(null)} /> : null}
      {inbox ? <InboxSheet onClose={() => setInbox(false)} /> : null}
      {report ? <ReportSheet report={report} onClose={() => setReport(null)} /> : null}
    </>
  );
}

/**
 * The words on an offer's button. An ask shows exactly what it sends as your message, so
 * the press never says one thing and sends another (bug bash 10 Oct 2026).
 */
export function shownWords(offer) {
  const a = offer && offer.action;
  const text = a && a.kind === "ask" && typeof a.text === "string" ? a.text.trim() : "";
  return text || offer.label;
}

/** Starting a task or asking writes into a conversation that may be busy; opening never waits. */
function waits(offer) {
  const kind = offer && offer.action && offer.action.kind;
  return kind === "start_task" || kind === "ask";
}

/** The `write_entry` next action: a button that opens the blank editor in place. */
function WriteEntry({ next, period }) {
  const [writing, setWriting] = useState(false);
  const [saved, setSaved] = useState(null);
  return (
    <div className="chat-next" data-next-action="write_entry">
      {saved ? (
        <p className="chat-cando-saved" role="status">
          {DRAFT_SAVED} <Link href="/">Go to Month-end<IconCaretRight className="caret-trailing" /></Link>
        </p>
      ) : (
        <p>
          <Button variant="secondary" aria-expanded={writing ? "true" : "false"} onClick={() => setWriting((w) => !w)}>
            {next.label}<IconCaretRight className="caret-trailing" />
          </Button>
        </p>
      )}
      {writing && !saved ? (
        <div className="chat-cando-editor">
          <JournalEditor
            create={{ period, sessionId: null }}
            onSaved={(result) => { setSaved(result); setWriting(false); }}
            onDone={() => setWriting(false)}
          />
        </div>
      ) : null}
    </div>
  );
}
