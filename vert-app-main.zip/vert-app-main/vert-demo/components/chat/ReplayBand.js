// components/chat/ReplayBand.js — A RECORDING SAYS IT IS ONE
// ==============================================================================
// Spec §9.5. Over every recorded conversation, above its title, in words. Not a tag
// and not a tooltip: a reader who looks at nothing else still reads it.

import { REPLAY_BAND } from "@/lib/agent/replay";

export default function ReplayBand() {
  return (
    <p className="chat-replay-band" role="note" data-replay-band="">
      {REPLAY_BAND}
    </p>
  );
}
