"use client";

// components/chat/WorkedFor.js — WHO ANSWERED, WHAT IT READ, AND ITS REASONING
// ==============================================================================
// p1 chat (founders' review, 23 Oct 2026). Every turn reads top to bottom: what you
// asked (your bubble), then this: Vert's identity row, the data it fetched for the turn
// (DataFetched.js, with an Open to that turn's data and sources in the side panel), and
// one collapsible "Reasoning", closed by default, holding the step-by-step: what it did,
// which skill it loaded, what it checked, how long it took and who produced it. Then the
// answer. The label was "How Vert did this" on the identity row; it is now "Reasoning",
// on a row of its own under the data, so the turn's order is the founders' four blocks.
//
// DESIGN-FIX-2 (10 Oct 2026; founder decision D9, DA2-032, DA2-042, DA2-067). Each of
// Vert's turns opens with its identity row: the navy mark, "Vert" and the time. Its
// working (steps, the skill it loaded, timings of two seconds or more, which model or
// Vert's rules) sits behind one quiet disclosure on that row, "How Vert did this", as a
// trail on one rail. The notes below describe the earlier "Worked for" line it replaced.
//
// Build plan §4.0.8, FC brief 3. While Vert works: one present-tense line, the step it
// is on, with the working indicator. When it finishes: one closed, past-tense line,
// "Worked for 41 s ▾". Opened, it lists each step with its result clause ("Compared 4
// Stripe payouts, $7,000.00: 3 matched the bank") and the records it read, and at the
// foot says who produced the turn: Vert's rules, or which model, live or replayed.
//
// IT REPLACES TWO BLOCKS. The old step sentence ("Checked 31 payouts against …") and
// "How this was produced" under the answer said the same kind of thing twice, around
// the answer they framed. The reference product folds the whole of the work into the
// one line above the answer; so does this. Token counts are one press further down,
// behind "For developers", and nowhere on the face (AN3).
//
// THE DURATION IS THE RECORD'S (components/chat/answer/model.js). It is the distance
// between the engine's own timestamps for the turn, so a replay says how long the
// recorded run took, and a turn whose timestamps are missing says "Worked on this"
// rather than a number nobody measured. Nothing here runs a clock (UI-016: the old rail
// animated a stepper over hardcoded timings with no work behind any node).
//
// WHAT VERT KNEW, FIRST (build plan §19.0.4, §19.6 F-BRAIN). A run that checked what
// Vert knows (`memory_used`, carried on the outline as `brain`) opens its steps with
// three lines, in order: "Checked what Vert knows about Northwind · Prepaid schedule:
// 2 answers from earlier months" (or "nothing saved yet"), the routing line when the
// engine routed a task, and "Loaded the Prepaid schedule skill (v3, edited by Sam on
// 2 Sep)", which opens the skill. Each recalled answer follows, linked to where it was
// given. They sit INSIDE the closed outline: Thoughts stays closed by default (AN9).
//
// THE STATUS LINE NAMES ITS SOURCE (build plan §19.0.14, §19.8 F-FILES). A step is
// one line in present tense while it runs ("Reading payroll-july.xlsx", "Scanning
// 6xxx lines Jul–Sep") and in past tense once done ("Read payroll-july.xlsx"): the
// engine's `running` and `done` strings when it sends them, its `label` otherwise.
// Every document or ledger a step read adds one "Gathered context ✓" chip naming it,
// under the running line as it arrives and under the step in the outline, so what Vert
// looked at is on the face, by name. Only a read the engine says happened (`answered`)
// earns the tick: a source it could not read is "(couldn't be read)", never ✓.
//
// THE MACHINERY REGION. Model ids are allowed only inside `.chat-how` (tests/jargon,
// tests/chat-truth). It holds plain paragraphs and the one developer disclosure, and no
// nested <div>, so the guards can find where it ends.

import { useId, useState } from "react";
import BoundText from "./BoundText";
import { producedLines, tokensLine } from "./HowProduced";
import { workedForLine } from "./answer/model";
import DataFetched from "./DataFetched";
import { outlineSources } from "./SourcesPanel";
import OpenSkill from "@/components/skills/OpenSkill";
import { brainLines } from "@/components/skills/model";
import { MARK_SRC, MARK_SRCSET } from "@/components/shell/icons";
import { turnTimeWords } from "@/lib/format";

import { IconCaretRight, IconCheck, IconSpinner } from "@/components/ui/icons";
/** The record kinds that are context Vert gathered: a document, or the ledger. */
export const CONTEXT_KINDS = Object.freeze(["document", "workbook", "ledger", "gl", "gl_account", "source"]);

/** The disclosure's one label (p1 chat, 23 Oct 2026; was "How Vert did this"). */
export const HOW_LABEL = "Reasoning";

function rowsOf(step) {
  const rows = step && step.result && Array.isArray(step.result.rows) ? step.result.rows : [];
  return rows.filter((r) => r && typeof r.label === "string" && r.label);
}

/** The engine's lowercase "gl" said as a person says it (DA2-032): "GL lines". */
export function plainWords(text) {
  return typeof text === "string" ? text.replace(/\bgl lines\b/g, "GL lines").replace(/\bgl\b/g, "GL") : text;
}

/** A read that found nothing ("0 lines") says nothing on a line of its own (DA2-032). */
function isEmptyCount(label) {
  return /^0 [a-z ]+$/i.test(String(label || "").trim());
}

/** "Looked for disposals … found none: 0 lines" says the absence twice (DA2-032): the
 *  zero count is dropped only when the step's own words already say nothing was found. */
function saysNoneTwice(step) {
  const clause = step && step.result ? step.result.clause : null;
  return typeof clause === "string" && isEmptyCount(clause) && /\b(found none|none found|found nothing|no )\b/i.test(stepLine(step));
}

function stepSources(step) {
  return rowsOf(step).filter((r) => !CONTEXT_KINDS.includes(r.kind) && !isEmptyCount(r.label));
}

/** The documents and ledger reads a step gathered, once each; only reads that happened. */
export function gatheredContext(step) {
  if (!step || !step.result || step.result.answered !== true) return [];
  const seen = new Set();
  return rowsOf(step).filter((r) => CONTEXT_KINDS.includes(r.kind) && !seen.has(`${r.kind}:${r.id ?? r.label}`) && seen.add(`${r.kind}:${r.id ?? r.label}`));
}

/** A step's one line: present tense while it runs, past tense once done. */
export function stepLine(step, { running = false } = {}) {
  if (!step) return "";
  const pick = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
  return plainWords((running ? pick(step.running) : pick(step.done)) || pick(step.label) || "");
}

/** A line said for comparing: no case, no closing stop, one space between words. Pure. */
export function lineKey(text) {
  return typeof text === "string" ? text.replace(/\s+/g, " ").trim().replace(/[.\u2026]+$/u, "").toLowerCase() : "";
}

/**
 * The trail's step lines as `lineKey`s, so a line drawn elsewhere in the turn can be held
 * against the open trail and not said twice (DA2-032; critic r1 F7). Pure.
 */
export function trailKeys(outline) {
  const steps = outline && Array.isArray(outline.steps) ? outline.steps : [];
  const keys = new Set();
  for (const step of steps) {
    const line = stepLine(step);
    if (!line) continue;
    keys.add(lineKey(line));
    const clause = step && step.result && typeof step.result.clause === "string" && !/\{\{/.test(step.result.clause) ? plainWords(step.result.clause) : null;
    if (clause) keys.add(lineKey(`${line}: ${clause}`));
  }
  keys.delete("");
  return keys;
}

function Gathered({ rows }) {
  if (!rows.length) return null;
  return (
    <ul className="chat-step-sources chat-gathered" data-gathered="">
      {rows.map((row, i) => (
        <li key={`${row.kind}-${row.id ?? ""}-${i}`} className="chat-gathered-chip" data-gathered-kind={row.kind}>
          <span className="chat-gathered-mark">Gathered context<IconCheck size={12} className="caret-trailing" /></span>{" "}
          {row.href ? <a href={row.href}>{row.label}</a> : <span>{row.label}</span>}
        </li>
      ))}
    </ul>
  );
}

/** "11:34 am" (today) or "30 Oct, 1:32 pm", the turn's time on its identity row; null
 *  when the record has none (walk 3, N16). */
function turnTime(at, now) {
  return turnTimeWords(at, now || undefined);
}

/**
 * VERT'S IDENTITY ROW (design-fix-2 DA2-042): the 20 px navy mark, "Vert" (footnote 500)
 * and the time (caption ink-3) above each of Vert's turns, with "How Vert did this" on the
 * same row, right-aligned, when the turn has working to show.
 */
export function TurnIdentity({ at = null, now = null, children = null, meta = null }) {
  const time = turnTime(at, now);
  return (
    <div className="chat-turn-id" data-turn-identity="">
      <img className="chat-turn-mark" src={MARK_SRC} srcSet={MARK_SRCSET} alt="" width={20} height={20} aria-hidden="true" />
      <span className="chat-turn-name" translate="no">Vert</span>
      {time ? (
        <time className="chat-turn-time" dateTime={at}>
          {time}
        </time>
      ) : null}
      {/* What Vert read and how it worked, as quiet presses on the same line. */}
      {meta ? <span className="chat-turn-meta">{meta}</span> : null}
      {children ? <span className="chat-turn-tools">{children}</span> : null}
    </div>
  );
}

/**
 * `outline` is one turn's (components/chat/answer/model.js `workedForTurns`):
 * `{ running, steps, fromAt, toAt, produced, summary, reason, open }`.
 *
 * THE ANSWER LEADS (D9). Timings, model names, skill versions and tool steps sit in ONE
 * quiet disclosure on the turn's identity row, "How Vert did this", closed by default. A
 * turn with nothing to show draws the identity row alone, with no disclosure.
 */
export default function WorkedFor({ outline, replay = false, ledgerName = null, onOpenChange = null, period = null }) {
  const [open, setOpenState] = useState(false);
  // The thread hears when the trail opens, so a line the trail now shows is not drawn a
  // second time under it (the question's evidence line; critic r1 F7).
  const setOpen = (update) =>
    setOpenState((was) => {
      const next = typeof update === "function" ? update(was) : update;
      if (next !== was && typeof onOpenChange === "function") queueMicrotask(() => onOpenChange(next));
      return next;
    });
  const bodyId = useId();
  const o = outline || {};
  const steps = (Array.isArray(o.steps) ? o.steps : []).filter((s) => s && (s.label || s.running || s.done));
  const brain = brainLines(o.brain, { client: o.client || null });
  // What the turn read (lib/agent/turn-sources.js), for its "Data fetched" block.
  const sources = outlineSources(o, period);

  if (o.running) {
    const last = steps.length ? steps[steps.length - 1] : null;
    // The step in hand, in present tense; a step whose result is in reads in past tense
    // until the next one starts.
    const current = last ? stepLine(last, { running: !last.result }) : "Getting started";
    const gathered = steps.flatMap(gatheredContext);
    return (
      <div className="chat-did chat-worked" data-message="run_state" data-running="">
        <TurnIdentity at={o.fromAt} meta={o.key ? <DataFetched sources={sources} ledgerName={ledgerName} outline={o} running compact /> : null} />
        <p className="chat-did-running" aria-busy="true">
          {/* Vert's working glyph, in ink; it turns, and holds still under reduced motion. */}
          <IconSpinner className="chat-working" size={16} />
          {current}
          {last && last.result ? "" : "…"}
        </p>
        <Gathered rows={gathered} />
      </div>
    );
  }

  const lines = producedLines({ produced: o.produced, replay });
  const tokens = replay ? null : tokensLine(o.produced && o.produced.usage);
  const took = workedForLine(o.fromAt, o.toAt);
  // Nothing to show behind the disclosure: no steps, no brain, no summary. Then there is
  // no disclosure at all (DA2-056: an empty one closed the posted card's thread).
  const hasWorking = Boolean(steps.length || brain.length || o.summary || took);
  // A turn that did nothing to show and answered nothing draws nothing (DA2-056: the
  // thread ended on an empty "Worked for under a second").
  if (!hasWorking && !o.reason && !o.open && o.answered === false) return null;
  // A RUN THAT DID NOTHING TO SHOW IS NOT A MESSAGE (verify pass 3, D21; pass-2 F12). The
  // task ran again after a question, read nothing, said nothing and ended on the same
  // summary: "Vert 9:37 am · How Vert did this" headed an empty message (the open steps
  // card under it was an earlier turn's). With no step, no answer, nothing it brought and
  // nothing else of Vert's in the turn, the line is not drawn; its summary is a repeat.
  if (!steps.length && !brain.length && !o.reason && !o.open && o.answered === false && o.carries === false) return null;
  return (
    <div className="chat-did chat-worked" data-message="run_state" data-worked-for="">
      {/* ONE LINE ABOVE THE ANSWER (founder, 8 Nov 2026): who, when, what was read, and
          how, as "Vert · 1:05 am · Read 5 sources › · Reasoning ›". The turn's reason was
          a line of its own that repeated the conversation's header, so it isn't drawn. */}
      <TurnIdentity
        at={o.toAt || o.fromAt}
        meta={
          o.key || hasWorking ? (
            <>
              {o.key ? <DataFetched sources={sources} ledgerName={ledgerName} outline={o} compact /> : null}
              {o.key && hasWorking ? (
                <span className="chat-turn-dot" aria-hidden="true">
                  ·
                </span>
              ) : null}
              {hasWorking ? (
                <button type="button" className="chat-did-toggle" aria-expanded={open} aria-controls={bodyId} onClick={() => setOpen((v) => !v)} data-reasoning-toggle="">
                  {HOW_LABEL}
                  <span className="chat-did-chev" aria-hidden="true">
                    <IconCaretRight className="chat-did-glyph" size={12} />
                  </span>
                </button>
              ) : null}
            </>
          ) : null
        }
      />
      {o.open ? (
        // The task this work started or found: a quiet link, not a button that competes
        // with the answer's own action.
        <p className="chat-worked-open">
          <a className="link t-footnote" href={o.open.href}>
            {o.open.label}
          </a>
        </p>
      ) : null}
      {hasWorking ? (
        <div className="chat-disclosure chat-worked-body" id={bodyId} data-open={open ? "true" : "false"} hidden={!open}>
          <div className="chat-worked-inner">
            {o.summary ? <p className="chat-worked-summary">{plainWords(o.summary)}</p> : null}
            {brain.length || steps.length ? (
              <ol className="chat-steps chat-trail" data-trail="">
                {brain.map((line, i) => (
                  <li key={`brain-${line.kind}-${i}`} data-brain-line={line.kind}>
                    {line.opens === "skill" ? (
                      <OpenSkill template={line.template} client={o.client || null} className="chat-quiet skill-open skill-chip">
                        {line.text}
                      </OpenSkill>
                    ) : line.kind === "recalled" && line.from && line.from.sessionId ? (
                      <span className="chat-step-label chat-brain-recalled">
                        <a href={`/chat/${encodeURIComponent(line.from.sessionId)}`}>{line.text}</a>
                      </span>
                    ) : (
                      <span className="chat-step-label">{line.text}</span>
                    )}
                  </li>
                ))}
                {steps.map((step, i) => (
                  // Index too: a re-run step can repeat its call id (9 Nov walk: React's
                  // duplicate-key warning on screen in the bookkeeper's session).
                  <li key={`${step.callId}-${i}`}>
                    <span className="chat-step-label">{stepLine(step)}</span>
                    {step.result && step.result.clause && !saysNoneTwice(step) ? (
                      <span className="chat-step-result">
                        {": "}
                        <BoundText text={plainWords(step.result.clause)} figures={step.result.figures} ledgerName={ledgerName} />
                      </span>
                    ) : null}
                    {step.result && step.result.answered === false ? <span className="chat-step-note"> (couldn't be read)</span> : null}
                    <Gathered rows={gatheredContext(step)} />
                    {stepSources(step).length ? (
                      <ul className="chat-step-sources">
                        {stepSources(step).map((row, i) => (
                          <li key={`${row.kind}-${i}`}>{row.href ? <a href={row.href}>{plainWords(row.label)}</a> : plainWords(row.label)}</li>
                        ))}
                      </ul>
                    ) : null}
                  </li>
                ))}
              </ol>
            ) : null}
            <div className="chat-how" data-how-produced="">
              {took ? <p>{took}.</p> : null}
              {lines.map((line, i) => (
                <p key={i}>{line}</p>
              ))}
              {tokens ? (
                <details className="chat-dev">
                  <summary>For developers</summary>
                  <p>{tokens}</p>
                </details>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
