"use client";

// components/chat/useSheetFocus.js — FOCUS IN, ESC OUT, FOCUS BACK
// ==============================================================================
// The three rules every sheet in the conversation keeps (spec §11.4; UI-017): on open,
// focus moves to the sheet's title; Esc closes it; on close, focus returns to the
// control that opened it. F1's `Sheet` owns the motion; this owns the focus, so the
// conversation's two sheets (context, result) keep the rules whichever Sheet renders
// them.

import { useEffect, useRef } from "react";
import { pushEscape } from "@/components/ui/escape-stack";

export default function useSheetFocus(open, onClose) {
  const titleRef = useRef(null);
  const returnTo = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    returnTo.current = typeof document !== "undefined" ? document.activeElement : null;
    if (titleRef.current) titleRef.current.focus();
    // One Esc closes the topmost layer only (U36; components/ui/escape-stack.js).
    const popEscape = pushEscape(() => {
      if (typeof onClose === "function") onClose();
    });
    return () => {
      popEscape();
      const back = returnTo.current;
      if (back && typeof back.focus === "function") back.focus();
    };
  }, [open, onClose]);

  return titleRef;
}
