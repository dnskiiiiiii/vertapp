// components/chat/answer/financial-statements.js — THE MONTH'S THREE STATEMENTS, READ FROM THE ENGINE
// ==============================================================================
// W4 Step 5 of the close list (29 Oct 2026): "generate and review the profit and loss,
// balance sheet and cash flow". The engine builds them from the ledger and sends them on
// the answer's shape as `statements` (the chat tool `get_financial_statements`), and the
// same object at `GET /close/{period}/statements` for the statements page. Each section
// is a list of rows in display order: a `line` (Revenue), the `account` rows under it
// (4000 Product sales) and the `total` rows (Gross profit), each with this month's cents
// and, when the engine compared a month, the prior month's.
//
// NAMED financial-statements.js, NOT statements.js: the card beside it is Statements.js,
// and on a case-insensitive disk (macOS's default) the two names are one file.
//
// Everything here is a lookup. Every total, subtotal and difference is the engine's
// integer (tests/no-arithmetic.test.js): nothing is summed down a column or across a
// row. A section that doesn't read as the contract says is dropped whole (null), never
// half-drawn: a statement whose lines don't add to its totals is worse than none. A
// figure the engine didn't read (`cents: null`) stays null and keeps the engine's words,
// so it can never be drawn as $0 (memory: an unread zero is not a measured zero).
//
// The two checks are the engine's too: the balance sheet's `balances` (assets equal
// liabilities plus equity) and the cash flow's `ties` (closing cash equals the balance
// sheet's cash), each `true`, `false` (with the engine's difference) or `null` (not
// checked, its words saying why). A tick is drawn only on `true`.
//
// It imports nothing: components/chat/answer/shape.js reads `shape` through it, and
// lib/agent/events.js reads shape.js.

/** The three sections, in the order a set of accounts reads. */
export const STATEMENT_SECTIONS = Object.freeze([
  Object.freeze({ key: "profitAndLoss", title: "Profit and loss", short: "P&L" }),
  Object.freeze({ key: "balanceSheet", title: "Balance sheet", short: "Balance sheet" }),
  Object.freeze({ key: "cashFlow", title: "Cash flow", short: "Cash flow" }),
]);
const KINDS = new Set(["line", "account", "total"]);

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const isInt = (v) => Number.isInteger(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const ISO_MONTH = /^[0-9]{4}-(0[1-9]|1[0-2])$/;
const month = (v) => (typeof v === "string" && ISO_MONTH.test(v) ? v : null);
/** An integer, or null for a figure not read. Anything else is not a figure (undefined). */
const figure = (v) => (v === null || v === undefined ? null : isInt(v) ? v : undefined);

/** Whether `v` is a period this app builds a link from (YYYY-MM, a real month). Pure. */
export function isStatementsPeriod(v) {
  return month(v) !== null;
}

function rowOf(raw) {
  if (!isObj(raw) || !text(raw.key) || !text(raw.label) || !KINDS.has(raw.kind)) return null;
  const cents = figure(raw.cents);
  const priorCents = figure(raw.priorCents);
  if (cents === undefined || priorCents === undefined) return null;
  return {
    key: text(raw.key),
    label: text(raw.label),
    kind: raw.kind,
    // An account sits under its line; the depth is the only layout the reader decides.
    depth: raw.kind === "account" ? 1 : 0,
    cents,
    priorCents,
    words: text(raw.words),
  };
}

/** A check: `true | false | null`, else undefined (not a check). */
function checkOf(state, differenceCents, words) {
  if (state !== true && state !== false && state !== null && state !== undefined) return undefined;
  const diff = figure(differenceCents);
  if (diff === undefined) return undefined;
  return { state: state === undefined ? null : state, differenceCents: diff, words: text(words) };
}

/**
 * One section of `statements` (`key` is one of STATEMENT_SECTIONS), checked and
 * normalised, or null. A section the engine didn't read keeps its words and no rows; a
 * read one is every row or none. Pure.
 */
export function sectionOf(raw, key) {
  if (!isObj(raw) || typeof raw.measured !== "boolean") return null;
  const words = text(raw.words);
  if (!raw.measured) {
    // NOT READ IS WORDS, NEVER $0. With no words there is nothing true to draw.
    if (!words) return null;
    return { key, measured: false, words, rows: [], check: null, hasPrior: false, priorWords: null };
  }
  if (!Array.isArray(raw.rows)) return null;
  const rows = raw.rows.map(rowOf);
  if (rows.some((r) => !r)) return null;
  // Two rows with one key are two rows nobody can tell apart.
  if (new Set(rows.map((r) => r.key)).size !== rows.length) return null;
  let check = null;
  if (key === "balanceSheet") check = checkOf(raw.balances, raw.differenceCents, raw.checkWords);
  if (key === "cashFlow") check = checkOf(raw.ties, raw.differenceCents, raw.tieWords);
  if (check === undefined) return null;
  // Why this section has no comparison column (the engine's words: only the profit and
  // loss is compared month on month), never a claim that the month wasn't read.
  const out = { key, measured: true, words, rows, check, hasPrior: rows.some((r) => r.priorCents !== null), priorWords: text(raw.priorWords) };
  // The contract's own field names are kept beside `check`, so a section read once reads
  // the same again (the shape is read by shape.js, then by the card).
  if (key === "balanceSheet") Object.assign(out, { balances: check.state, differenceCents: check.differenceCents, checkWords: check.words });
  if (key === "cashFlow") {
    const cash = figure(raw.balanceSheetCashCents);
    Object.assign(out, { ties: check.state, differenceCents: check.differenceCents, tieWords: check.words, balanceSheetCashCents: cash === undefined ? null : cash });
  }
  return out;
}

/** `shape.statements` (or `GET /close/{period}/statements`), read, or null. Pure. */
/**
 * WHEN THE BOOKS WERE READ (engine w3/int, staging browser walk 1, D5): `ledgerAsAt` on
 * `GET /close/{period}/statements`, `{readAt, words, behind, behindWords, written}`, kept
 * as the engine's words — "Xero as at 31 Oct 2026, 12:20 pm", and what Vert wrote to the
 * ledger since — or null when it sent none. Pure.
 */
export function ledgerAsAtOf(raw) {
  if (!isObj(raw) || !text(raw.words)) return null;
  const behindWords = raw.behind === true ? text(raw.behindWords) : null;
  return { words: text(raw.words), behind: Boolean(behindWords), behindWords };
}

export function statementsOf(raw) {
  if (!isObj(raw) || !month(raw.period) || typeof raw.measured !== "boolean") return null;
  const base = {
    period: raw.period,
    monthLabel: text(raw.monthLabel),
    currency: text(raw.currency),
    measured: raw.measured,
    words: text(raw.words),
    comparedTo: month(raw.comparedTo),
    comparativeWords: text(raw.comparativeWords),
    // The statement the person asked for: the card opens on it (production walk, D32).
    focus: ["profitAndLoss", "balanceSheet", "cashFlow"].includes(raw.focus) ? raw.focus : null,
    booksStart: month(raw.booksStart),
    basisWords: text(raw.basisWords),
    ledgerAsAt: ledgerAsAtOf(raw.ledgerAsAt),
  };
  if (!raw.measured) {
    if (!base.words) return null;
    return { ...base, profitAndLoss: null, balanceSheet: null, cashFlow: null };
  }
  const out = { ...base };
  for (const s of STATEMENT_SECTIONS) out[s.key] = sectionOf(raw[s.key], s.key);
  // A measured object with no section that reads has nothing to draw.
  return STATEMENT_SECTIONS.some((s) => out[s.key]) ? out : null;
}
