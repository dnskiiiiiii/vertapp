// components/chat/answer/unusual-balances.js — THE TRIAL BALANCE REVIEW, READ FROM THE ENGINE
// ==============================================================================
// The close list's Step 4 (w4/checks, 29 Oct 2026): "Run a Trial Balance: check for
// unusual debit or credit balances, or negative inventory figures." The engine reads
// every balance and sends the ones on their unusual side on the answer's shape as
// `unusualBalances` (vert_engine/analysis/unusual_balances.py shape_of; contract model
// agent_events.ShapeUnusualBalances): each flag's account, kind, side, rule, reason and
// size, the accounts it left alone and why, and the balances it couldn't read.
//
// Everything here is a lookup: every amount is the engine's integer, nothing is summed.
// A block that doesn't read as the contract says is dropped whole (null). A review the
// engine did not read (`measured: false`) keeps the engine's words and carries no flag,
// so it can never be drawn as "nothing unusual".
//
// It imports nothing: components/chat/answer/shape.js reads `shape` through it.

/** The four rules, and the word each is said in on the card. */
export const RULE_WORDS = Object.freeze({
  overdrawn: "Overdrawn",
  negative_inventory: "Below zero",
  wrong_side: "Wrong side",
  refund_due: "Refund due",
  tax_paid_ahead: "Paid ahead",
});

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;
const PERIOD = /^\d{4}-\d{2}$/;
const SIDES = new Set(["debit", "credit"]);
const BASES = new Set(["closing", "movement"]);

function flagOf(raw) {
  if (!isObj(raw) || !text(raw.label) || !text(raw.reason) || !text(raw.figureRef)) return null;
  if (!Object.hasOwn(RULE_WORDS, raw.rule) || !SIDES.has(raw.side) || !BASES.has(raw.basis)) return null;
  if (!Number.isInteger(raw.amountCents) || raw.amountCents < 0) return null;
  return {
    accountId: text(raw.accountId),
    label: text(raw.label),
    kind: text(raw.kind),
    side: raw.side,
    rule: raw.rule,
    ruleWords: RULE_WORDS[raw.rule],
    reason: text(raw.reason),
    basis: raw.basis,
    figureRef: text(raw.figureRef),
    amountCents: raw.amountCents,
    withResult: raw.withResult === true,
  };
}

function notesOf(raw) {
  if (!Array.isArray(raw)) return [];
  return raw.filter((n) => isObj(n) && text(n.label) && text(n.why)).map((n) => ({ label: text(n.label), why: text(n.why) }));
}

/**
 * The payload's `shape.unusualBalances`, read: `{period, asAt, measured, words, checked,
 * flags, unread, normal}`, or null when it isn't one. An unread review with a flag, or
 * without words, is not one. Pure.
 */
export function unusualBalancesOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean") return null;
  const asAt = typeof raw.asAt === "string" && ISO_DAY.test(raw.asAt) ? raw.asAt : null;
  const period = typeof raw.period === "string" && PERIOD.test(raw.period) ? raw.period : null;
  if (!asAt || !period) return null;
  const flags = (Array.isArray(raw.flags) ? raw.flags : []).map(flagOf);
  const info = (Array.isArray(raw.info) ? raw.info : []).map(flagOf);
  if (flags.some((f) => f === null) || info.some((f) => f === null)) return null;
  const checked = Number.isInteger(raw.checked) && raw.checked >= 0 ? raw.checked : 0;
  const unread = (words) => ({ period, asAt, measured: false, partial: false, words, checked: 0, flags: [], info: [], unread: [], normal: [] });
  if (!raw.measured) {
    if (flags.length || info.length || !text(raw.words)) return null;
    return unread(text(raw.words));
  }
  // NOTHING CHECKED IS NOT "NONE" (review, 29 Oct 2026): a measured review that judged
  // no account is drawn as not read, never "0 accounts checked, none on an unusual side".
  if (!checked) return flags.length || info.length ? null : unread("Vert couldn't read the balances");
  const notRead = notesOf(raw.unread);
  return { period, asAt, measured: true, partial: notRead.length > 0, words: text(raw.words), checked, flags, info, unread: notRead, normal: notesOf(raw.normal) };
}
