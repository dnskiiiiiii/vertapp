"use client";

// components/chat/answer/ReminderDrafts.js — PAYMENT REMINDERS, DRAFTED, NOT SENT
// ==============================================================================
// W3 feature 1 (28 Oct 2026), contract v2. One email per customer and currency with
// overdue invoices, drafted by the engine (reminders.js reads it) and drawn under the aged
// receivables, or on its own when an answer's shape carries `reminders`. NOTHING HAS BEEN
// SENT, and nothing here sends without a press:
//
//   · each draft's recipient, subject, opening and closing words are the person's to
//     edit; the invoice block between them is read-only, because the engine writes it at
//     send time from a fresh read of the ledger (an amount typed here would be one Vert
//     never read);
//   · the recipient starts as the ledger's address. Changing it, or typing one where the
//     ledger has none, asks "Send to X instead of Y?" and only then goes, with
//     `confirmRecipient: true`;
//   · a customer reminded within the engine's resend window asks "Reminded on 25 Oct
//     2026. Send again?" and only then goes, with `confirmResend: true`;
//   · "Attach statement" (w46) sends the customer's outstanding statement as at today
//     with the email, as a PDF the engine builds at send time; unticked, none goes;
//   · each draft has its own "Approve & send"; "Approve & send selected" sends the ticked
//     ones in one request, never more than 50 (past that it says so and sends nothing);
//   · with email not connected, the engine's words on the sender, a link to
//     /connections, and every send disabled.
//
// EVERY RESULT AND EVERY PIECE OF STATE IS KEYED BY `draftId` (v2, defect 1): one
// customer can owe in two currencies, and sending one email must never mark the other.
// Each result is said on its own draft in the engine's words: sent; "may have been sent"
// (`unknown`, never "sent" and never "not sent"); failed; the confirmation it still
// needs; refused (such as "already being sent"). A draft that went, or may have, is not
// offered again here; Sent reminders, under the drafts, says what happened. Nor is one
// the engine says can't go again today (`canSendAgain: false`, walk 4 W4-4).
// No effect sends or reads anything (tests/aging-card.test.js reads this file for one).

import "./aging.css";
import { useState } from "react";
import { Button } from "@/components/ui";
import { formatDate } from "@/lib/format";
import { useWritesEnabled } from "@/lib/engine-context";
import { readSentReminderList, sendReminderEmails } from "@/lib/reminders-client";
import {
  MAX_EMAILS_PER_SEND,
  NOT_AGAIN_TODAY,
  canSendDraft,
  emailOf,
  listedInvoices,
  recipientChanged,
  remindersOf,
  resultKey,
  resultTone,
  resultWords,
  selectedEmails,
  sendResultsOf,
  wentOrMayHave,
  yesesNeeded,
} from "./reminders";
import { moneyIn } from "./aging-money";
import SentReminders, { SENT_REMINDERS_ID } from "./SentReminders";

const SAMPLE_SEND_REASON = "These are the sample books, so no email can be sent here.";
const TOO_MANY = `Vert sends at most ${MAX_EMAILS_PER_SEND} reminders at once. Untick some, send those, then send the rest.`;
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const asSet = (v) => new Set(Array.isArray(v) ? v : []);
const without = (set, id) => {
  const next = new Set(set);
  next.delete(id);
  return next;
};

/** The header: "9 reminders drafted" until one is sent, then what's still to send
 *  ("8 to send", "All sent"). Walk 3: "9 reminders drafted" stayed up after a send. */
export function headWords(drafted, unsent, answered) {
  if (!answered) return plural(drafted, "reminder drafted", "reminders drafted");
  return unsent > 0 ? `${unsent} to send` : "All sent";
}

export default function ReminderDrafts({ reminders, ledgerName = null, initial = null, writes: writesProp = null }) {
  const writesCtx = useWritesEnabled();
  const writes = writesProp === null ? writesCtx : Boolean(writesProp);
  const start = initial && typeof initial === "object" ? initial : {};
  // All keyed by draftId.
  const [edits, setEdits] = useState(() => start.edits || {});
  const [selected, setSelected] = useState(() => asSet(start.selected));
  const [confirming, setConfirming] = useState(() => asSet(start.confirming));
  const [results, setResults] = useState(() => start.results || {});
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState(null);
  const [bulkAsk, setBulkAsk] = useState(null);
  const [sends, setSends] = useState(() => start.sends || null);
  const [sendsWords, setSendsWords] = useState(null);
  const [reading, setReading] = useState(false);
  const r = remindersOf(reminders);
  if (!r) return null;
  const ledger = ledgerName || "your ledger";

  if (!r.measured) {
    return (
      <section className="reminders" data-reminder-drafts="" data-measured="unread" aria-label="Payment reminders">
        <p className="aging-unread">{r.words}</p>
      </section>
    );
  }

  // A draft as the engine's last answer about it leaves it: a needs_confirm names the
  // date it was reminded, or the address the ledger holds now.
  const now = (d) => {
    const x = results[d.draftId];
    // A refusal that says it can't go again today (W4-4) takes the send away.
    if (x && x.canSendAgain === false) return { ...d, canSendAgain: false, sendAgainWords: x.sendAgainWords || x.words || d.sendAgainWords };
    if (!x || x.status !== "needs_confirm") return d;
    if (x.confirm === "recipient") return { ...d, ledgerAddress: "ledgerAddress" in x ? x.ledgerAddress : d.ledgerAddress, mustConfirmRecipient: true };
    return { ...d, needsConfirm: true, lastRemindedOn: x.lastRemindedOn || d.lastRemindedOn };
  };
  const drafts = r.drafts.map(now);
  const editOf = (d) => edits[d.draftId] || {};
  const doneHere = (d) => wentOrMayHave(results[d.draftId]);
  const blockedWhy = (d) => {
    const can = canSendDraft(d, r.sender, editOf(d));
    if (!can.ok) return can.reason;
    if (!writes) return SAMPLE_SEND_REASON;
    if (busy) return "Wait for the send to finish.";
    return null;
  };
  const needs = (d, given = {}) => {
    const n = yesesNeeded(d, editOf(d), given);
    // The engine asked about the recipient even though it matches what was drafted.
    if (d.mustConfirmRecipient && !given.recipientOk) n.recipient = true;
    return n;
  };

  const setEdit = (d, field, value) => setEdits((prev) => ({ ...prev, [d.draftId]: { ...(prev[d.draftId] || {}), [field]: value } }));
  const toggle = (d, on) => setSelected((prev) => (on ? new Set(prev).add(d.draftId) : without(prev, d.draftId)));

  const readSends = async () => {
    setReading(true);
    const got = await readSentReminderList();
    setReading(false);
    if (got.ok && got.body && Array.isArray(got.body.sends)) {
      setSends({ sends: got.body.sends });
      setSendsWords(null);
    } else {
      setSends(null);
      setSendsWords(got.ok ? "Vert's list of sent reminders couldn't be read." : got.message);
    }
  };

  const send = async (emails, which) => {
    if (busy || !emails.length) return;
    setBusy(which);
    setError(null);
    const got = await sendReminderEmails(r.asAt, emails);
    setBusy(null);
    if (!got.ok) {
      setError({ message: got.message, connect: Boolean(got.connect) });
      readSends();
      return;
    }
    const read = sendResultsOf(got.body);
    if (!read) {
      setError({ message: "Vert answered without saying which reminders went. Check Sent reminders below before sending again.", connect: false });
      readSends();
      return;
    }
    const keyed = read.map((x) => [resultKey(x, r.drafts), x]).filter(([k]) => k);
    setResults((prev) => {
      const next = { ...prev };
      for (const [k, x] of keyed) next[k] = x;
      return next;
    });
    setConfirming((prev) => {
      let next = new Set(prev);
      for (const [k, x] of keyed) next = x.status === "needs_confirm" ? new Set(next).add(k) : without(next, k);
      return next;
    });
    setSelected((prev) => {
      let next = new Set(prev);
      for (const [k, x] of keyed) if (wentOrMayHave(x)) next = without(next, k);
      return next;
    });
    readSends();
  };

  const sendOne = (d) => {
    if (blockedWhy(d)) return;
    const asked = confirming.has(d.draftId);
    const n = needs(d);
    if ((n.resend || n.recipient) && !asked) {
      setConfirming((prev) => new Set(prev).add(d.draftId));
      return;
    }
    send([emailOf(d, editOf(d), { confirmResend: asked && n.resend, confirmRecipient: asked && n.recipient })], d.draftId);
  };

  const live = drafts.filter((d) => !doneHere(d));
  const ticked = new Set([...selected].filter((id) => live.some((d) => d.draftId === id)));
  const plan = selectedEmails(live, ticked, edits, r.sender);
  const sendSelected = () => {
    if (!writes || busy || !r.sender.connected || plan.tooMany) return;
    if (plan.awaiting.length) {
      setBulkAsk(plan.awaiting.map((d) => d.draftId));
      return;
    }
    send(plan.emails, "selected");
  };
  const sendSelectedYes = () => {
    const ok = new Set(bulkAsk || []);
    const yes = selectedEmails(live, ticked, edits, r.sender, { resendOk: ok, recipientOk: ok });
    setBulkAsk(null);
    if (!yes.tooMany) send(yes.emails, "selected");
  };
  const bulkWhy = !r.sender.connected
    ? r.sender.words || "Email for reminders isn't connected yet."
    : !writes
      ? SAMPLE_SEND_REASON
      : !ticked.size
        ? "Tick the reminders to send first."
        : plan.tooMany
          ? TOO_MANY
          : !plan.emails.length && !plan.awaiting.length
            ? "None of the ticked reminders can be sent."
            : busy
              ? "Wait for the send to finish."
              : null;

  return (
    <section className="reminders" data-reminder-drafts="" aria-label="Payment reminders">
      <header className="reminders-head">
        <p className="shape-label">{headWords(r.drafts.length, live.length, Object.keys(results).length > 0)}</p>
        <p className="reminders-sub">
          {/* Said only until one is sent (walk 2 D19: it stayed up after a send). */}
          {Object.keys(results).length ? null : "Nothing has been sent."}
          {r.sender.connected && r.sender.fromAddress ? ` From ${r.sender.fromAddress}` : ""}
        </p>
      </header>
      {!r.sender.connected ? (
        <p className="reminders-sender" role="note" data-sender="not-connected">
          {r.sender.words || "Email for reminders isn't connected for this client yet."}{" "}
          <a className="link" href="/connections">
            Connect email for reminders
          </a>
        </p>
      ) : null}
      {r.words ? <p className="aging-words">{r.words}</p> : null}
      {r.asAtWords && r.drafts.length ? <p className="aging-words" data-reminders-as-at="">{r.asAtWords}</p> : null}
      {r.drafts.length ? null : <p className="aging-words">No customer has an overdue invoice to remind them about.</p>}
      <ol className="reminders-list">
        {drafts.map((d) => (
          <Draft
            key={d.draftId}
            d={d}
            edit={editOf(d)}
            ledger={ledger}
            why={blockedWhy(d)}
            done={doneHere(d)}
            result={results[d.draftId] || null}
            need={needs(d)}
            ticked={selected.has(d.draftId)}
            confirming={confirming.has(d.draftId)}
            busy={busy === d.draftId}
            onEdit={(field, value) => setEdit(d, field, value)}
            onTick={(on) => toggle(d, on)}
            onSend={() => sendOne(d)}
            onCancel={() => setConfirming((prev) => without(prev, d.draftId))}
          />
        ))}
      </ol>
      {r.drafts.length ? (
        <div className="reminders-foot" data-drafts-foot="">
          {bulkAsk && bulkAsk.length ? (
            <div className="reminders-confirm" role="group" aria-label="Confirm before sending">
              <ul className="reminders-asks">
                {drafts
                  .filter((d) => bulkAsk.includes(d.draftId))
                  .map((d) => (
                    <li key={d.draftId}>{askWords(d, editOf(d), needs(d), ledger)}</li>
                  ))}
              </ul>
              <div className="reminders-actions">
                <Button variant="commit" size="sm" onClick={sendSelectedYes} data-confirm-selected="">
                  Yes, send them
                </Button>
                <Button variant="quiet" size="sm" onClick={() => setBulkAsk(null)}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <Button variant="commit" size="sm" busy={busy === "selected"} busyLabel="Sending…" disabledReason={bulkWhy || undefined} onClick={sendSelected} data-send-selected="">
              {ticked.size ? `Approve & send selected (${ticked.size})` : "Approve & send selected"}
            </Button>
          )}
          {plan.blocked.length && ticked.size && !plan.tooMany ? (
            <p className="reminders-note">{plural(plan.blocked.length, "ticked reminder can't", "ticked reminders can't")} be sent and will be left out.</p>
          ) : null}
        </div>
      ) : null}
      {error ? (
        <p className="aging-error" role="alert">
          {error.message}
          {error.connect ? (
            <>
              {" "}
              <a className="link" href="/connections">
                Connect email for reminders
              </a>
            </>
          ) : null}
        </p>
      ) : null}
      {sends || sendsWords ? (
        <SentReminders sends={sends} words={sendsWords} ledgerName={ledger} />
      ) : (
        <div className="reminders-actions">
          <Button variant="quiet" size="sm" busy={reading} busyLabel="Reading…" onClick={readSends} data-read-sends="">
            Show Sent reminders
          </Button>
        </div>
      )}
    </section>
  );
}

/** The question a draft asks before it goes: the recipient, the resend, or both. */
function askWords(d, edit, need, ledger) {
  const out = [];
  if (need.recipient) {
    const typed = typeof edit.to === "string" ? edit.to.trim() : d.to || "";
    out.push(`Send to ${typed} instead of ${d.ledgerAddress || `no address in ${ledger}`}?`);
  }
  if (need.resend) out.push(`Reminded on ${d.lastRemindedOn ? formatDate(d.lastRemindedOn) : "a recent day"}. Send again?`);
  return `${d.contactName}: ${out.join(" ")}`;
}

function Draft({ d, edit, ledger, why, done, result, need, ticked, confirming, busy, onEdit, onTick, onSend, onCancel }) {
  const money = (cents) => moneyIn(cents, d.currency);
  const id = `draft-${d.draftId}`;
  const value = (field) => (typeof edit[field] === "string" ? edit[field] : field === "to" ? d.to || "" : d[field] || "");
  const cannot = Boolean(why) || done;
  const shown = listedInvoices(d);
  const typedTo = typeof edit.to === "string" ? edit.to.trim() : d.to || "";
  return (
    <li className="reminder" data-draft={d.draftId} data-sent={done ? "" : undefined}>
      <div className="reminder-head">
        <div className="reminder-pick">
          <label className="cbx-hit">
            <input
              type="checkbox"
              className="cbx"
              checked={ticked && !done}
              disabled={cannot && !ticked}
              onChange={(e) => onTick(e.target.checked)}
              aria-label={`Select the reminder to ${d.contactName} in ${d.currency}`}
              aria-describedby={d.ledgerAddress ? undefined : `${id}-why`}
            />
          </label>
          <span className="reminder-name">{d.contactName}</span>
        </div>
        <span className="reminder-owed num">{money(d.overdueCents)} overdue</span>
      </div>
      {d.lastRemindedOn ? <p className="reminder-last">Last reminded on {formatDate(d.lastRemindedOn)}</p> : null}
      <div className="reminder-fields">
        <label className="form-field">
          <span className="field-label">To</span>
          <span className="field-box">
            <input className="field-input" type="email" name={`${id}-to`} autoComplete="off" spellCheck={false} value={value("to")} placeholder={d.ledgerAddress ? undefined : "Type an email address"} disabled={done} onChange={(e) => onEdit("to", e.target.value)} />
          </span>
        </label>
        {!d.ledgerAddress ? (
          <p className="reminder-noto" id={`${id}-why`}>
            {d.toWords || `${ledger} has no email address for ${d.contactName}; type one in and confirm it.`}
          </p>
        ) : recipientChanged(d, edit) ? (
          <p className="reminder-noto">The address in {ledger} is {d.ledgerAddress}. You&rsquo;ll be asked to confirm {typedTo} before it sends.</p>
        ) : null}
        <label className="form-field">
          <span className="field-label">Subject</span>
          <span className="field-box">
            <input className="field-input" type="text" name={`${id}-subject`} autoComplete="off" value={value("subject")} disabled={done} onChange={(e) => onEdit("subject", e.target.value)} />
          </span>
        </label>
        {d.editable ? (
          <label className="form-field">
            <span className="field-label">Opening</span>
            <span className="field-box reminder-body-box">
              <textarea className="field-input reminder-body" name={`${id}-intro`} autoComplete="off" rows={4} value={value("intro")} disabled={done} onChange={(e) => onEdit("intro", e.target.value)} />
            </span>
          </label>
        ) : null}
      </div>
      <div className="reminder-block" aria-label={`The overdue invoices the email lists for ${d.contactName}`}>
        <p className="reminder-block-note">Filled from {ledger} at send</p>
        <ul className="reminder-invoices">
          {shown.map((i) => (
            <li key={i.id} className="reminder-invoice">
              <span className="reminder-invoice-number">{i.number || "Invoice with no number"}</span>
              <span className="reminder-invoice-meta">
                Due {formatDate(i.dueDate)} · <span data-tone="attention">{plural(i.daysOverdue, "day", "days")} overdue</span>
              </span>
              <span className="num">{money(i.amountDueCents)}</span>
              <span className="reminder-invoice-links">
                {i.payUrl ? (
                  <a className="link" href={i.payUrl} target="_blank" rel="noopener noreferrer">
                    Pay link
                  </a>
                ) : null}
                {i.url ? (
                  <a className="link" href={i.url} target="_blank" rel="noopener noreferrer">
                    Open in {ledger}
                  </a>
                ) : null}
              </span>
            </li>
          ))}
        </ul>
        {d.moreCount > 0 ? (
          <p className="reminder-more">
            and {plural(d.moreCount, "more overdue invoice", "more overdue invoices")}
            {d.moreCents !== null ? ` totalling ${money(d.moreCents)}` : ""}
          </p>
        ) : null}
        {d.payLinkWords ? <p className="reminder-paywords">{d.payLinkWords}</p> : null}
      </div>
      {d.editable ? (
        <div className="reminder-fields">
          <label className="form-field">
            <span className="field-label">Closing</span>
            <span className="field-box reminder-body-box">
              <textarea className="field-input reminder-body" name={`${id}-closing`} autoComplete="off" rows={4} value={value("closing")} disabled={done} onChange={(e) => onEdit("closing", e.target.value)} />
            </span>
          </label>
          {/* THE STATEMENT RIDES ON THIS SEND (w46, audit row 20): ticked, the engine
              builds the customer's outstanding statement as at today at send time and
              attaches it as a PDF. Nothing else sends a statement. */}
          <span className="reminder-attach" data-attach-statement="">
            <label className="cbx-hit">
              <input type="checkbox" className="cbx" id={`${id}-statement`} name={`${id}-statement`} checked={edit.attachStatement === true} disabled={done} onChange={(e) => onEdit("attachStatement", e.target.checked)} />
            </label>
            <label htmlFor={`${id}-statement`}>Attach statement</label>
          </span>
        </div>
      ) : null}
      {result ? (
        <p className="reminder-result" data-result={result.status} data-tone={resultTone(result)} role="status">
          <span className="reminder-dot" aria-hidden="true" />
          {resultWords(result)}
          {result.status === "unknown" ? (
            <>
              {" "}
              <a className="link" href={`#${SENT_REMINDERS_ID}`}>
                See Sent reminders
              </a>
            </>
          ) : null}
        </p>
      ) : null}
      {done ? null : d.canSendAgain === false ? (
        // W4-4: the engine says it can't go again today, so no send is offered; its
        // words, unless the result above already said them.
        result && result.words === (d.sendAgainWords || NOT_AGAIN_TODAY) ? null : (
          <p className="reminder-noto" data-no-resend="">
            {d.sendAgainWords || NOT_AGAIN_TODAY}
          </p>
        )
      ) : confirming && (need.resend || need.recipient) ? (
        <div className="reminders-confirm" data-confirm-resend={need.resend ? "" : undefined} data-confirm-recipient={need.recipient ? "" : undefined} role="group" aria-label={`Confirm ${d.contactName}'s reminder`}>
          {need.recipient ? <p>Send to {typedTo} instead of {d.ledgerAddress || `no address in ${ledger}`}?</p> : null}
          {need.resend ? <p>Reminded on {d.lastRemindedOn ? formatDate(d.lastRemindedOn) : "a recent day"}. Send again?</p> : null}
          <div className="reminders-actions">
            <Button variant="secondary" size="sm" busy={busy} busyLabel="Sending…" disabledReason={why || undefined} onClick={onSend}>
              {need.resend && !need.recipient ? "Send again" : "Yes, send"}
            </Button>
            <Button variant="quiet" size="sm" onClick={onCancel}>
              Cancel
            </Button>
          </div>
        </div>
      ) : (
        <div className="reminders-actions">
          <Button variant="secondary" size="sm" busy={busy} busyLabel="Sending…" disabledReason={why || undefined} onClick={onSend}>
            Approve &amp; send
          </Button>
        </div>
      )}
    </li>
  );
}
