// components/chat/answer/bank-rec.js — THE BANK REC'S ROWS, READ FROM THE ENGINE
// ==============================================================================
// The co-founder's ask (23 Oct 2026): "reconcile the bank" answers the way Xero's
// reconcile screen reads — the bank line on the left, what it matches (or how to code
// it) on the right — in sections: already reconciled in Xero, in Xero and not yet
// reconciled, on the statement and not in Xero, can't resolve yet; then a numbered plan
// and the statement against the books. The engine builds all of it
// (vert_engine/workflows/templates/_bank_rec_rows.py, contract `agent_events.ShapeBankRec`)
// and sends it on the answer's shape as `bankRec`.
//
// Everything here is a lookup: counts, totals, amounts and the difference are the
// engine's cents, formatted and never added up (tests/no-arithmetic.test.js). A shape
// that doesn't read as the contract says is dropped whole (null), never half-drawn.

import { formatMoney } from "@/lib/format";
import { bankTransactionNoun } from "@/lib/connections-shape";

const SECTION_KEYS = ["reconciled", "unreconciled", "statement_only", "unresolved"];

/** The status families, each with its quiet colour; the word always comes from the engine. */
const TONES = {
  reconciled: "done",
  suggested_match: "ready",
  near_match: "ready",
  matched: "ready",
  coded: "ready",
  entry: "ready",
  not_on_statement: "neutral",
  no_statement: "neutral",
  multi_match: "attention",
  ambiguous: "attention",
  amount_differs: "attention",
  no_document: "attention",
  pick_account: "attention",
  not_proposed: "attention",
};

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const isInt = (v) => Number.isInteger(v);
const text = (v) => (typeof v === "string" && v.trim() ? v : null);

const ADJUSTMENT_KINDS = ["bank_fee", "rounding", "difference"];

/**
 * A near match's adjustment (D20, founder 7 Nov 2026): what Xero's Find & Match takes for
 * the small difference. `{ kind, amountCents, words, account }`, the account as
 * "404 Bank Fees" only when the engine named one; null when not sent whole. Pure.
 */
export function adjustmentOf(raw) {
  if (!isObj(raw) || !ADJUSTMENT_KINDS.includes(raw.kind) || !isInt(raw.amountCents) || raw.amountCents <= 0 || !text(raw.words)) return null;
  const account = [text(raw.accountCode), text(raw.accountName)].filter(Boolean).join(" ") || null;
  return { kind: raw.kind, amountCents: raw.amountCents, words: raw.words.trim(), account };
}

/** A row's tone ("done", "ready", "neutral", "attention"). Pure. */
export function toneOf(status) {
  return TONES[status] || "neutral";
}

function sideOf(raw) {
  if (!isObj(raw) || !isInt(raw.amountCents) || (raw.direction !== "in" && raw.direction !== "out")) return null;
  // Vert's own provenance tag on what it wrote to the ledger ("[vert:5e76e61f9180]") is
  // its record, not the bank's words: never drawn (walk 2 D19).
  return { date: text(raw.date), description: untagged(raw.description), amountCents: raw.amountCents, direction: raw.direction };
}

function untagged(value) {
  return (text(value) || "").replace(/\s*\[vert:[0-9a-f]{6,}\]/gi, "").trim();
}

const DOCUMENT_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** A line's receipts as the engine listed them (`[{documentId, name}]`); [] when absent. Pure. */
export function receiptsOf(raw) {
  return (Array.isArray(raw) ? raw : [])
    .filter((d) => isObj(d) && typeof d.documentId === "string" && DOCUMENT_ID.test(d.documentId) && text(d.name))
    .map((d) => ({ documentId: d.documentId, name: d.name }));
}

function rowOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !text(raw.status) || !text(raw.statusWords)) return null;
  const bank = sideOf(raw.bank);
  const bankWords = text(raw.bankWords);
  if (!bank && !bankWords) return null;
  // The match's ledger description drops the tag too (walk 3 copy list).
  const proposal = isObj(raw.proposal) && text(raw.proposal.kind) ? (typeof raw.proposal.description === "string" ? { ...raw.proposal, description: untagged(raw.proposal.description) } : raw.proposal) : { kind: "none" };
  return {
    id: raw.id,
    status: raw.status,
    statusWords: raw.statusWords,
    tone: toneOf(raw.status),
    bank,
    bankWords,
    proposal,
    confidence: text(raw.confidence),
    reason: text(raw.reason),
    action: text(raw.action),
    decision: decisionOf(raw.decision),
    // Receipts filed against this bank line (close list step 1, 29 Oct 2026).
    receipts: receiptsOf(raw.receipts),
  };
}

function sectionOf(raw) {
  if (!isObj(raw) || !SECTION_KEYS.includes(raw.key) || !text(raw.title) || !isInt(raw.count)) return null;
  const rows = (Array.isArray(raw.rows) ? raw.rows : []).map(rowOf).filter(Boolean);
  return {
    key: raw.key,
    title: raw.title,
    count: raw.count,
    totalCents: isInt(raw.totalCents) ? raw.totalCents : null,
    collapsed: raw.collapsed === true,
    measured: raw.measured !== false,
    words: text(raw.words),
    rows,
    more: isInt(raw.more) && raw.more > 0 ? raw.more : 0,
  };
}

function stepOf(raw) {
  if (!isObj(raw) || !isInt(raw.n) || !text(raw.words)) return null;
  return { n: raw.n, kind: text(raw.kind) || "step", words: raw.words, count: isInt(raw.count) ? raw.count : null, amountCents: isInt(raw.amountCents) ? raw.amountCents : null };
}

function tieOf(raw) {
  if (!isObj(raw) || !text(raw.status) || !text(raw.words)) return null;
  const cents = (v) => (isInt(v) ? v : null);
  // `itemsCents`: the engine's reconciling items (statement less books less the
  // difference); `owed`: a card, its figures what's owed (9 Nov 2026 walk).
  return { status: raw.status, words: raw.words, statementCents: cents(raw.statementCents), booksCents: cents(raw.booksCents), differenceCents: cents(raw.differenceCents), itemsCents: cents(raw.itemsCents), owed: raw.owed === true };
}

/** The engine's `shape.bankRec`, checked and normalised, or null. Pure. */
export function bankRecOf(raw) {
  if (!isObj(raw) || typeof raw.statement !== "boolean" || !Array.isArray(raw.sections)) return null;
  const sections = raw.sections.map(sectionOf);
  if (!sections.length || sections.some((s) => !s)) return null;
  return {
    period: text(raw.period),
    currency: text(raw.currency),
    account: text(raw.account),
    // The imported statement this rec reconciled: where its Cash coding tab opens (L2-1).
    accountId: text(raw.accountId),
    statement: raw.statement,
    statementWords: text(raw.statementWords),
    sections,
    plan: (Array.isArray(raw.plan) ? raw.plan : []).map(stepOf).filter(Boolean),
    tieOut: tieOf(raw.tieOut),
  };
}

/** "Received" / "Spent": the direction as Xero's own columns word it. Pure. */
export function directionWord(direction) {
  return direction === "in" ? "Received" : "Spent";
}

/** The tie-out's status as one word for its mark. Pure. */
export const TIE_WORDS = Object.freeze({ ties: "Ties", explained: "Explained by you", unexplained: "Unexplained", not_measured: "Not compared yet" });

// ─────────────────────────── a coding row's decision (migration 052) ───────────────────────────
// A row Vert proposed a coding for carries ONE decision (`coding_approve`): Approve or
// Change on the row settles it, and the engine says what it did in words (created in
// the ledger, approved with the fields to enter by hand, already there). Everything
// below reads the engine's fields; nothing is worked out from money.

const DECISION_STATES = ["pending", "settled", "declined", "failed"];
// `withdrawn` and `void`: closed because the statement line was removed (p1 e2e, 24 Oct
// 2026; vert_engine coding_approvals.lines_removed), said in the engine's words.
const OUTCOMES = ["created", "approved", "already_in_ledger", "declined", "changed", "withdrawn", "void"];
// The ledger object a decision made is gone (w18 contract, walk 4 W4-2).
const GONE = ["deleted", "voided", "absent"];
/** A link out is only ever a secure one; the engine names the ledger's own screen. */
const LEDGER_LINK = /^https:\/\//;

function codingOf(raw) {
  if (!isObj(raw) || !text(raw.accountCode)) return null;
  return { accountCode: raw.accountCode, accountName: text(raw.accountName), taxType: text(raw.taxType), taxName: text(raw.taxName), contact: text(raw.contact) };
}

function fieldOf(raw) {
  if (!isObj(raw) || !text(raw.label) || typeof raw.value !== "string") return null;
  return { label: raw.label, value: raw.value, amountCents: isInt(raw.amountCents) ? raw.amountCents : null };
}

/** A row's `decision`, checked, or null. Pure. */
export function decisionOf(raw) {
  if (!isObj(raw) || !text(raw.id) || raw.kind !== "coding_approve" || !DECISION_STATES.includes(raw.state) || !text(raw.words)) return null;
  return {
    id: raw.id,
    kind: raw.kind,
    state: raw.state,
    words: raw.words,
    outcome: OUTCOMES.includes(raw.outcome) ? raw.outcome : null,
    coding: codingOf(raw.coding),
    confidence: text(raw.confidence),
    by: text(raw.by),
    changedBy: text(raw.changedBy),
    fields: (Array.isArray(raw.fields) ? raw.fields : []).map(fieldOf).filter(Boolean),
    ledgerLink: text(raw.ledgerLink) && LEDGER_LINK.test(raw.ledgerLink) ? raw.ledgerLink : null,
    mayApprove: raw.mayApprove === true ? true : raw.mayApprove === false ? false : null,
    whyNot: text(raw.whyNot),
    // WHAT IT MADE IS GONE FROM THE LEDGER (staging browser walk 4, W4-2): deleted,
    // voided or absent there. A settled decision then offers no reconcile link (the
    // object isn't there to OK) and says the engine's words ("Deleted in Xero: run again
    // to redo it"); after Run again it comes back as an ordinary pending decision.
    goneInLedger: GONE.includes(raw.goneInLedger) ? raw.goneInLedger : null,
  };
}

/** Whether a decision can be pressed now: pending, and not refused to this viewer. Pure. */
export function canDecide(decision) {
  return Boolean(decision && decision.state === "pending" && decision.mayApprove !== false);
}

/** Whether a coding row is asking which account (Vert wasn't sure). Pure. */
export function asksForAccount(row) {
  const d = row && row.decision;
  const coded = (d && d.coding && d.coding.accountCode) || (row && row.proposal && text(row.proposal.accountCode));
  return !coded;
}

/**
 * The decisions "Approve N high-confidence" approves in one section: pending, this
 * viewer may approve them, high confidence, with an account. `decisions` holds what a
 * press on this screen already changed (id → decision). Pure.
 */
export function highConfidenceIds(section, decisions = {}) {
  const out = [];
  for (const row of (section && section.rows) || []) {
    const d = row.decision ? decisions[row.decision.id] || row.decision : null;
    if (!canDecide(d) || asksForAccount({ ...row, decision: d })) continue;
    if ((d.confidence || row.confidence) !== "high") continue;
    out.push(d.id);
  }
  return out;
}

const accountLabel = (code, name) => [code, name].filter(Boolean).join(" · ");

/**
 * The Change editor's choices: accounts (the coding's own, the engine's alternatives,
 * then the chart the app read, active ones with a code) and tax rates (the account's
 * own rate, then each rate the engine named). Pure.
 */
export function codingChoices(row, chart = []) {
  const p = (row && row.proposal) || {};
  const own = (row && row.decision && row.decision.coding) || (text(p.accountCode) ? { accountCode: p.accountCode, accountName: text(p.accountName), taxType: text(p.taxType), taxName: text(p.taxName), contact: text(p.contact) } : null);
  // A line Vert asked about has no account yet, and still has its payee (p1 e2e: the
  // editor started with no contact, and picking an alternative filled in another
  // business's name).
  const current = own || (text(p.contact) ? { contact: text(p.contact) } : null);
  const alts = (Array.isArray(p.alternatives) ? p.alternatives : []).filter((a) => isObj(a) && text(a.accountCode));
  const accounts = [];
  const seen = new Set();
  const add = (code, name, extra = {}) => {
    if (!code || seen.has(code)) return;
    seen.add(code);
    accounts.push({ value: code, label: accountLabel(code, name), ...extra });
  };
  if (own) add(own.accountCode, own.accountName, { taxType: own.taxType, contact: own.contact });
  for (const a of alts) add(a.accountCode, text(a.accountName), { taxType: text(a.taxType), contact: text(a.contact) });
  for (const a of Array.isArray(chart) ? chart : []) {
    if (a && a.active !== false && text(a.number)) add(a.number, text(a.name));
  }
  const taxes = [{ value: "", label: "The account's own rate" }];
  const taxSeen = new Set([""]);
  for (const t of [own, ...alts]) {
    const type = t && text(t.taxType);
    if (!type || taxSeen.has(type)) continue;
    taxSeen.add(type);
    taxes.push({ value: type, label: text(t.taxName) || type });
  }
  return { accounts, taxes, current };
}

/**
 * What picking ``code`` in Change sets beside it: the account's tax rate when it is one
 * of the choices, and the contact as it stands. An alternative is offered because
 * ANOTHER payee is coded to that account; its payee is never carried onto this line
 * (p1 e2e, 24 Oct 2026: INSURANCE approved as "453 Office Expenses · 7-Eleven"). Pure.
 */
export function pickedAccount(choices, code, contact) {
  const picked = (choices.accounts || []).find((a) => a.value === code);
  const taxType = picked && picked.taxType && (choices.taxes || []).some((t) => t.value === picked.taxType) ? picked.taxType : "";
  return { taxType, contact: typeof contact === "string" ? contact : "" };
}

/**
 * What a person changed, as the engine's settle takes it: only the fields that differ
 * from the coding on the row. An account picked with no rate takes the account's own
 * (the engine's rule), so no rate is sent for it. Pure.
 */
export function changeOf(current, picked) {
  const c = current || {};
  const p = picked || {};
  const out = {};
  if (text(p.accountCode) && p.accountCode !== c.accountCode) out.accountCode = p.accountCode;
  if (text(p.taxType) && (p.taxType !== c.taxType || out.accountCode)) out.taxType = p.taxType;
  if (typeof p.contact === "string" && p.contact.trim() && p.contact.trim() !== (c.contact || "")) out.contactName = p.contact.trim();
  return out;
}

/** The form's fields as text to paste, one "Label: value" a line. Pure. */
export function fieldsText(fields) {
  return (fields || []).map((f) => `${f.label}: ${f.value}`).join("\n");
}

/** A decision's tone, for its mark: done once it did something, neutral set aside. Pure. */
export function decisionTone(decision) {
  if (!decision) return "neutral";
  if (decision.state === "settled") return decision.goneInLedger ? "attention" : "done";
  if (decision.state === "pending") return decision.mayApprove === false ? "neutral" : "ready";
  return "neutral";
}


/**
 * The plan as it stands after the presses made on this screen (``decided``: row id →
 * the decision the engine answered with): each coding step less the rows a press here
 * has decided, a step with none left dropped, the steps numbered again. The engine
 * counts the plan from the decisions on every read (``_bank_rec_rows.recount_codings``);
 * this keeps the screen true between reads (p1 e2e, 24 Oct 2026: "Approve 3 codings"
 * after three were approved). Pure.
 */
export function planNow(view, decided = {}) {
  const steps = (view && view.plan) || [];
  const pressed = { coded: 0, pick_account: 0 };
  for (const sec of (view && view.sections) || []) {
    for (const r of sec.rows || []) {
      if (!r || !(r.status in pressed)) continue;
      const before = r.decision;
      const now = decided && decided[r.id];
      if (now && now.state && now.state !== "pending" && (!before || before.state === "pending")) pressed[r.status] += 1;
    }
  }
  const less = { approve_codings: pressed.coded, pick_accounts: pressed.pick_account };
  const words = {
    approve_codings: (n) => `Approve ${n} ${n === 1 ? "coding" : "codings"}`,
    pick_accounts: (n) => `Pick the account for ${n} ${n === 1 ? "line" : "lines"}`,
  };
  const out = [];
  for (const s of steps) {
    if (less[s.kind]) {
      const n = Math.max(0, (Number.isInteger(s.count) ? s.count : 0) - less[s.kind]);
      if (!n) continue;
      out.push({ ...s, n: out.length + 1, count: n, words: words[s.kind](n) });
    } else {
      out.push({ ...s, n: out.length + 1 });
    }
  }
  return out;
}

// ─────────────────────────── confirming a write to the ledger ───────────────────────────
// Staging browser walk 1 (31 Oct 2026, D6): one press on a coding's Approve created an
// AUTHORISED Spend Money in Xero with no confirm. Every approval of a coding now asks
// first, naming what will be created. The amount and the accounts are the row's own; the
// noun is the ledger's own word for the transaction where Vert knows it.

const UNNAMED_LEDGER = /^your ledger$/i;

function ledgerNoun(ledger, direction) {
  return bankTransactionNoun(ledger, direction) || (direction === "in" ? "deposit" : "payment");
}

/** "090 · Business Bank Account" → "090 Business Bank Account", as an account is written. */
function accountWords(account) {
  const a = text(account);
  return a ? a.replace(/\s+·\s+/g, " ") : null;
}

function codingWords(coding) {
  if (!isObj(coding)) return null;
  return [text(coding.accountCode), text(coding.accountName)].filter(Boolean).join(" ") || null;
}

/**
 * The confirm for approving one coding: `{ title, commit }`. `row` is the bank line,
 * `coding` what will be approved, `account` the bank account the answer names, `ledger`
 * the connected ledger's name ("your ledger" when none was handed in). Pure.
 */
export function codingWriteQuestion({ row, coding, account = null, ledger = null }) {
  const bank = row && isObj(row.bank) ? row.bank : null;
  const named = text(ledger) && !UNNAMED_LEDGER.test(ledger) ? ledger : null;
  const noun = ledgerNoun(named, bank && bank.direction);
  const amount = bank && isInt(bank.amountCents) ? ` of ${formatMoney(bank.amountCents)}` : "";
  const on = accountWords(account) ? ` on ${accountWords(account)}` : "";
  const to = codingWords(coding) ? `, coded to ${codingWords(coding)}` : "";
  const article = /^[aeiou]/i.test(noun) ? "an" : "a";
  if (!named) return { title: `Approve ${article} ${noun}${amount}${on}${to}?`, commit: "Approve" };
  return { title: `Create ${article} ${noun}${amount}${on}${to}?`, commit: `Create in ${named}` };
}

/** The confirm for "Approve N high-confidence": `{ title, commit }`. Pure. */
export function bulkWriteQuestion({ count, ledger = null, account = null }) {
  const named = text(ledger) && !UNNAMED_LEDGER.test(ledger) ? ledger : null;
  const on = accountWords(account) ? ` on ${accountWords(account)}` : "";
  const what = `${count} ${count === 1 ? "transaction" : "transactions"}`;
  if (!named) return { title: `Approve ${what}${on}, each coded as shown?`, commit: `Approve ${count}` };
  return { title: `Create ${what}${on} in ${named}, each coded as shown?`, commit: `Create ${count} in ${named}` };
}
