// components/chat/answer/aging-money.js — AN ENGINE FIGURE, IN ITS OWN CURRENCY
// ==============================================================================
// lib/format.js writes every figure with a "$", which is right for the dollar
// currencies this product's ledgers mostly hold and wrong for any other. A figure in
// another currency keeps the formatter's digits and grouping and names its code instead
// of a "$" it doesn't have. Formatting only: the cents are the engine's, untouched.

import { formatMoney } from "@/lib/format";

const DOLLARS = new Set(["AUD", "NZD", "USD", "CAD", "SGD", "HKD", "FJD"]);

/** `cents` in `currency`, prose or table style (lib/format.js formatMoney). Pure. */
export function moneyIn(cents, currency, options) {
  const out = formatMoney(cents, options);
  if (!currency || DOLLARS.has(currency)) return out;
  return `${currency} ${out.replace("$", "")}`;
}
