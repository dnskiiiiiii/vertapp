"use client";

// components/chat/answer/WriteOff.js — WRITE OFF A BAD DEBT, FROM THE AGED RECEIVABLES CARD
// ==============================================================================
// W4 (29 Oct 2026), the close list's Step 3 AR point: "write off any uncollectible bad
// debts". Three pieces, each drawn under one of the most overdue invoices on the card:
//
//   1. WriteOffAction — the "Write off" press. It reads the chart's bad debts accounts
//      (a GET, only on the press) and opens the form.
//   2. WriteOffForm — the amount (the amount due by default), the bad debts account (one:
//      chosen for the person; several: they choose; none: the engine's words and no
//      press), an optional reason. "Draft write-off" asks the engine for a DRAFT kept in
//      Vert; nothing reaches the ledger yet.
//   3. WriteOff — the drafted write-off and where it has got to. A second person approves
//      it, and the engine creates the credit note in the ledger, coded to bad debts, for
//      the same customer: as a DRAFT the person approves and allocates IN THE LEDGER (an
//      allocation needs an approved credit note), or, for a client whose documents go in
//      approved (`documentMode: "authorised"`, 4 Nov 2026), APPROVED and allocated to the
//      invoice by Vert, with the allocation's result said in the engine's words. The
//      approve press says which will happen. Without permission to write, the fields to
//      enter by hand.
//
// Every figure is the engine's (write-off.js reads it); the typed amount is read to the
// cent by lib/write-off-amount.js. A lost answer on approve never says nothing was sent.

import { useId, useState } from "react";
import { Button } from "@/components/ui";
import { actorWords, formatDate } from "@/lib/format";
import { useSignedInActor } from "@/lib/store";
import { centsInput } from "@/lib/bills-model";
import { useWritesEnabled } from "@/lib/engine-context";
import { amountCentsOf, amountProblem } from "@/lib/write-off-amount";
import { requestAccounts, requestApprove, requestDiscard, requestDraft, requestWriteOffs } from "@/lib/write-offs-client";
import { moneyIn } from "./aging-money";
import { accountWords, approveWriteOffLabel, documentModeOf, sentWordsOf, writeOffAccountsOf, writeOffOf } from "./write-off";

const SAMPLE_REASON = "These are the sample books, so nothing can be written off here.";

function useWrites(writesProp) {
  const ctx = useWritesEnabled();
  return writesProp === null || writesProp === undefined ? ctx : Boolean(writesProp);
}

/** The press under one overdue invoice, and whatever it has opened. */
export function WriteOffAction({ doc, currency, ledger, initial = null, writes: writesProp = null }) {
  const writes = useWrites(writesProp);
  const [open, setOpen] = useState(() => Boolean(initial && (initial.open || initial.writeOff)));
  const [accounts, setAccounts] = useState(() => (initial && writeOffAccountsOf(initial.accounts)) || null);
  const [writeOff, setWriteOff] = useState(() => (initial && writeOffOf(initial.writeOff)) || null);
  // How the client's credit notes reach the ledger, so the approve press can say it.
  const [documentMode, setDocumentMode] = useState(() => (initial && documentModeOf(initial)) || null);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);

  // Drafted (a press): the draft's answer may say the mode; when it doesn't, the invoice's
  // write-offs are read once for it. Unread stays null, and the press says "as a draft".
  const drafted = (read, _message, mode = null) => {
    setWriteOff(read);
    if (mode) {
      setDocumentMode(mode);
      return;
    }
    requestWriteOffs(doc.id).then((got) => {
      const said = got && got.ok ? documentModeOf(got.body) : null;
      if (said) setDocumentMode(said);
    });
  };

  const press = async () => {
    if (busy || !writes) return;
    setOpen(true);
    setError(null);
    if (accounts) return;
    setBusy(true);
    const got = await requestAccounts();
    setBusy(false);
    const read = got.ok ? writeOffAccountsOf(got.body) : null;
    if (read) setAccounts(read);
    else setError(got.ok ? "Vert's list of bad debts accounts couldn't be read. Nothing was changed." : got.message);
  };

  if (writeOff) return <WriteOff writeOff={writeOff} ledgerName={ledger} writes={writes} documentMode={documentMode} />;
  if (!open) {
    return (
      <div className="write-off-press">
        <Button variant="secondary" size="sm" busy={busy} busyLabel="Opening…" disabledReason={writes ? undefined : SAMPLE_REASON} onClick={press} data-write-off-open={doc.id}>
          Write off
        </Button>
      </div>
    );
  }
  if (error) {
    return (
      <p className="aging-error" role="alert">
        {error}
      </p>
    );
  }
  if (!accounts) return <p className="aging-words">Reading the bad debts accounts…</p>;
  return <WriteOffForm doc={doc} currency={currency} ledger={ledger} writes={writes} accounts={accounts} onDrafted={drafted} onCancel={() => setOpen(false)} />;
}

/** The form: amount, bad debts account, reason. Drafting writes nothing to the ledger. */
export function WriteOffForm({ doc, currency, ledger, writes: writesProp = null, accounts: rawAccounts, onDrafted = null, onCancel = null }) {
  const writes = useWrites(writesProp);
  const id = useId();
  const accounts = writeOffAccountsOf(rawAccounts);
  const [amount, setAmount] = useState(() => centsInput(doc.amountDueCents));
  const [code, setCode] = useState(() => (accounts && accounts.choice === "one" ? accounts.accounts[0].code : ""));
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const money = (cents) => moneyIn(cents, currency);
  const number = doc.number || "this invoice";

  if (!accounts || accounts.choice === "none" || accounts.choice === "unread") {
    return (
      <div className="write-off-form" data-write-off-form="">
        <p className="aging-words">{(accounts && accounts.words) || "Vert couldn't read which account holds bad debts. Nothing was changed."}</p>
        {onCancel ? (
          <Button variant="quiet" size="sm" onClick={onCancel}>
            Close
          </Button>
        ) : null}
      </div>
    );
  }

  const problem = amountProblem(amount, doc.amountDueCents);
  const why = !writes ? SAMPLE_REASON : !code ? (accounts.choice === "expense" ? "Choose the expense account." : "Choose the bad debts account.") : problem || undefined;
  const draft = async () => {
    if (busy || why) return;
    setBusy(true);
    setError(null);
    const got = await requestDraft({ invoiceId: doc.id, amountCents: amountCentsOf(amount), accountCode: code, reason });
    setBusy(false);
    const read = got.ok && got.body ? writeOffOf(got.body.writeOff) : null;
    // One write-off per invoice: the one already there is shown, with its links.
    const already = !got.ok && got.existing ? writeOffOf(got.existing) : null;
    if (read && onDrafted) onDrafted(read, null, documentModeOf(got.body));
    else if (already && onDrafted) onDrafted(already, got.message);
    else if (!read) setError(got.ok ? "Vert's draft write-off couldn't be read. Nothing was sent." : got.message);
  };

  return (
    <div className="write-off-form" data-write-off-form="">
      <p className="aging-words">
        Drafts a credit note to {doc.contactName || "the customer"} for {number}, coded to bad debts. Nothing goes to {ledger} until a second person approves it.
      </p>
      <div className="write-off-fields">
        <label className="form-field">
          <span className="field-label">Amount to write off{currency ? ` (${currency})` : ""}</span>
          <span className="field-box">
            <input className="field-input num" type="text" inputMode="decimal" name="write-off-amount" autoComplete="off" value={amount} aria-describedby={problem ? `${id}-amount` : undefined} onChange={(e) => setAmount(e.target.value)} />
          </span>
        </label>
        {problem ? (
          <p className="write-off-hint" id={`${id}-amount`}>
            {problem}
          </p>
        ) : (
          <p className="write-off-hint">Still due: {money(doc.amountDueCents)}</p>
        )}
        <label className="form-field">
          <span className="field-label">{accounts.choice === "expense" ? "Expense account" : "Bad debts account"}</span>
          <span className="field-box">
            <select className="field-input" name="write-off-account" autoComplete="off" value={code} onChange={(e) => setCode(e.target.value)}>
              {accounts.choice === "several" || accounts.choice === "expense" ? <option value="">Choose an account</option> : null}
              {accounts.accounts.map((a) => (
                <option key={a.code} value={a.code}>
                  {accountWords(a)}
                </option>
              ))}
            </select>
          </span>
        </label>
        {accounts.words ? <p className="write-off-hint">{accounts.words}</p> : null}
        <label className="form-field">
          <span className="field-label">Reason (optional)</span>
          <span className="field-box">
            <input className="field-input" type="text" name="write-off-reason" autoComplete="off" maxLength={500} value={reason} placeholder="For example, the customer has gone into liquidation" onChange={(e) => setReason(e.target.value)} />
          </span>
        </label>
      </div>
      <div className="write-off-actions">
        <Button variant="commit" size="sm" busy={busy} busyLabel="Drafting…" disabledReason={why} onClick={draft} data-write-off-draft="">
          Draft write-off
        </Button>
        {onCancel ? (
          <Button variant="quiet" size="sm" onClick={onCancel}>
            Cancel
          </Button>
        ) : null}
      </div>
      {error ? (
        <p className="aging-error" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}

/** One write-off and where it has got to. */
export default function WriteOff({ writeOff: raw, ledgerName = null, writes: writesProp = null, initial = null, documentMode: modeProp = null }) {
  const writes = useWrites(writesProp);
  const ledger = ledgerName || "your ledger";
  // Who drafted and approved it, as recorded ("key: founder"), worded against the viewer.
  const signedIn = useSignedInActor();
  const [w, setW] = useState(() => writeOffOf(raw));
  const [checked, setChecked] = useState(() => Boolean(initial && initial.checked));
  const [error, setError] = useState(() => (initial && typeof initial.error === "string" ? initial.error : null));
  const [busy, setBusy] = useState(null);
  // The approve answer says the mode too; it wins over what the card was handed.
  const [answeredMode, setAnsweredMode] = useState(null);
  const documentMode = answeredMode || modeProp;
  const checkId = useId();
  if (!w) return null;
  const money = (cents) => moneyIn(cents, w.currency);
  const number = w.invoice.number || "the invoice";
  const approvable = w.status === "drafted" || w.status === "failed" || w.status === "unconfirmed";

  const act = async (which) => {
    if (busy || !writes) return;
    setBusy(which);
    setError(null);
    const got = which === "approve" ? await requestApprove(w.id, w.status === "unconfirmed" && checked) : await requestDiscard(w.id);
    setBusy(null);
    const read = got.ok && got.body ? writeOffOf(got.body.writeOff) : null;
    if (read) {
      setW(read);
      setChecked(false);
      const mode = documentModeOf(got.body);
      if (mode) setAnsweredMode(mode);
    } else {
      setError(got.ok ? "Vert answered without saying what happened. Check the write-off again before pressing anything." : got.message);
    }
  };

  const sent = sentWordsOf(w, { ledger, money });
  // A small balance (w47) is the cents left on an invoice or a bill; a bill's is a supplier's.
  const title = w.kind === "small_balance" ? "Small balance on" : "Write-off of";
  const approveWhy = !writes ? SAMPLE_REASON : w.status === "unconfirmed" && !checked ? `Check ${ledger} for the credit note first, then tick that you have.` : undefined;

  return (
    <section className="write-off" data-write-off-status={w.status} data-write-off-kind={w.kind} aria-label={`${title} ${number}`}>
      <header className="write-off-head">
        <span className="write-off-title">
          {title} {number}
        </span>
        {w.statusWords ? <span className="write-off-status">{w.statusWords}</span> : null}
      </header>
      <dl className="write-off-facts">
        <div>
          <dt>{w.side === "payables" ? "Supplier" : "Customer"}</dt>
          <dd>{w.invoice.contactName || "Not named"}</dd>
        </div>
        <div>
          <dt>Amount</dt>
          <dd className="num">{money(w.amountCents)}</dd>
        </div>
        <div>
          <dt>Account</dt>
          <dd>{accountWords(w.account)}</dd>
        </div>
        {w.date ? (
          <div>
            <dt>Credit note date</dt>
            <dd>{formatDate(w.date)}</dd>
          </div>
        ) : null}
        {w.reason ? (
          <div>
            <dt>Reason</dt>
            <dd>{w.reason}</dd>
          </div>
        ) : null}
        {w.draftedBy ? (
          <div>
            <dt>Drafted by</dt>
            <dd>{actorWords(w.draftedBy, { signedIn })}</dd>
          </div>
        ) : null}
        {w.approvedBy ? (
          <div>
            <dt>Approved by</dt>
            <dd>{actorWords(w.approvedBy, { signedIn })}</dd>
          </div>
        ) : null}
      </dl>
      {w.status === "sent" ? (
        <div className="write-off-sent">
          {/* WHAT THE LEDGER RETURNED: a draft credit note, or an approved one; and, for an
              approved one, whether Vert's allocation to the invoice landed. */}
          <p className="write-off-strong" data-credit-note-status={(w.creditNote && w.creditNote.status) || ""}>
            {sent.heading}
          </p>
          {sent.allocation ? (
            <p className={sent.allocation.status === "allocated" ? "write-off-strong" : "aging-words"} data-write-off-allocation={sent.allocation.status}>
              {sent.allocation.words}
            </p>
          ) : null}
          {sent.instruction ? <p className="aging-words">{sent.instruction}</p> : null}
          <p className="write-off-links">
            {w.creditNote && w.creditNote.url ? (
              <a className="link" href={w.creditNote.url} target="_blank" rel="noopener noreferrer">
                Open the credit note
              </a>
            ) : null}
            {w.allocate && w.allocate.invoiceUrl ? (
              <a className="link" href={w.allocate.invoiceUrl} target="_blank" rel="noopener noreferrer">
                Open {number}
              </a>
            ) : null}
          </p>
        </div>
      ) : null}
      {w.status === "unconfirmed" ? <p className="write-off-strong">Couldn&rsquo;t confirm: check {ledger}</p> : null}
      {w.words ? <p className="aging-words">{w.words}</p> : null}
      {w.status === "manual" && w.fields ? (
        <div className="shape-table-wrap">
          <table className="shape-table write-off-fields-table" data-write-off-fields="">
            <caption className="sr-only">The credit note&rsquo;s fields, to enter in {ledger}</caption>
            <tbody>
              {w.fields.map(([label, value]) => (
                <tr key={label}>
                  <th scope="row">{label}</th>
                  <td>{value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      {w.status === "unconfirmed" ? (
        <div className="write-off-check">
          <label className="cbx-hit">
            <input type="checkbox" className="cbx" checked={checked} onChange={(e) => setChecked(e.target.checked)} aria-labelledby={`${checkId}-words`} data-write-off-confirm="" />
          </label>
          <span id={`${checkId}-words`}>I&rsquo;ve checked {ledger}, and the credit note isn&rsquo;t there</span>
        </div>
      ) : null}
      {approvable ? (
        <div className="write-off-actions">
          <Button variant="commit" size="sm" busy={busy === "approve"} busyLabel="Approving…" disabledReason={approveWhy} onClick={() => act("approve")} data-write-off-approve="">
            {approveWriteOffLabel(documentMode, ledger)}
          </Button>
          {w.status === "drafted" ? (
            <Button variant="quiet" size="sm" busy={busy === "discard"} busyLabel="Setting aside…" disabledReason={writes ? undefined : SAMPLE_REASON} onClick={() => act("discard")} data-write-off-discard="">
              Discard
            </Button>
          ) : null}
        </div>
      ) : null}
      {error ? (
        <p className="aging-error" role="alert">
          {error}
        </p>
      ) : null}
    </section>
  );
}
