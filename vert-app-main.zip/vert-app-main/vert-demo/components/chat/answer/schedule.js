// components/chat/answer/schedule.js — A CHANGE TO SCHEDULED PROPOSED IN CHAT, READ FROM THE ENGINE
// ==============================================================================
// Audit row 23 (w48, 4 Nov 2026; agent_events.ShapeSchedule). "Every Friday check the
// bills", "run depreciation every month on the 15th", "pause the sync": the engine reads
// the words into ONE proposed change and sends it as `shape.schedule`, with the exact
// request body the press sends to Scheduled's own routes (lib/scheduled-client.js):
//
//   create  → POST  /api/scheduled            (the body: kind, name, cadence, config?)
//   edit    → PATCH /api/scheduled/{taskId}   (cadence and/or enabled)
//   pause   → PATCH /api/scheduled/{taskId}   ({ enabled: false })
//   resume  → PATCH /api/scheduled/{taskId}   ({ enabled: true })
//   end     → POST  /api/scheduled/{taskId}/end
//   exists  → no press: one is already set as asked; only the way to it.
//
// A lookup and the press's wiring only; a block that doesn't read as the contract says is
// dropped whole. Nothing here adds, counts or works out a figure.

import { metaLine } from "../../../lib/format.js";
import * as api from "../../../lib/scheduled-client.js";
import { cadenceWords, isTaskId, KINDS } from "../../../lib/scheduled-model.js";

const MODES = new Set(["create", "edit", "pause", "resume", "end", "exists"]);
const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

/** The press's label (at most four words) for each mode that has one. */
export const PRESS_LABEL = Object.freeze({ create: "Set up", edit: "Change it", pause: "Turn off", resume: "Turn on", end: "End it" });
/** What the settled card leads with, once the route said yes. */
export const SETTLED_LEAD = Object.freeze({ create: "Set up", edit: "Changed", pause: "Turned off", resume: "Turned on", end: "Ended" });
/** The way to the routine in Scheduled. */
export const OPEN_LABEL = "Open in Scheduled";

function accountOf(raw) {
  if (!isObj(raw) || !text(raw.name)) return null;
  return { code: text(raw.code), name: text(raw.name), label: [text(raw.code), text(raw.name)].filter(Boolean).join(" ") };
}

function journalOf(raw) {
  if (!isObj(raw)) return null;
  const debit = accountOf(raw.debit);
  const credit = accountOf(raw.credit);
  if (!text(raw.memo) || !Number.isInteger(raw.amountCents) || raw.amountCents <= 0 || !debit || !credit) return null;
  return { memo: text(raw.memo), amountCents: raw.amountCents, currency: text(raw.currency) || "AUD", debit, credit };
}

/** The engine's `shape.schedule`, checked, or null. Pure. */
export function scheduleShapeOf(raw) {
  if (!isObj(raw) || !MODES.has(raw.mode) || !KINDS.includes(raw.kind)) return null;
  if (!text(raw.name) || !text(raw.cadenceWords) || !text(raw.words) || !isObj(raw.cadence)) return null;
  const href = typeof raw.href === "string" && raw.href.startsWith("/") ? raw.href : "/scheduled";
  const taskId = isTaskId(raw.taskId) ? raw.taskId : null;
  const body = isObj(raw.body) ? raw.body : null;
  if (raw.mode === "create" && (!body || body.kind !== raw.kind || taskId)) return null;
  if (raw.mode !== "create" && !taskId) return null;
  if (["edit", "pause", "resume"].includes(raw.mode) && !body) return null;
  const journal = raw.kind === "journal" && raw.mode === "create" ? journalOf(raw.journal) : null;
  if (raw.kind === "journal" && raw.mode === "create" && !journal) return null;
  const current = isObj(raw.current) && isObj(raw.current.cadence) ? { name: text(raw.current.name), cadence: raw.current.cadence, enabled: raw.current.enabled === true } : null;
  return {
    mode: raw.mode,
    kind: raw.kind,
    kindWords: text(raw.kindWords),
    name: text(raw.name),
    cadence: raw.cadence,
    cadenceWords: text(raw.cadenceWords),
    taskId,
    current,
    body,
    journal,
    words: text(raw.words),
    href,
  };
}

/** `/scheduled?task=<id>`: the routine's own sheet in Scheduled. Pure. */
export function taskHref(id) {
  return isTaskId(id) ? `/scheduled?task=${encodeURIComponent(id)}` : "/scheduled";
}

/** "Set up · Bills & invoices (weekly), every Friday at 9:00 am": the settled card's
 *  line, the name the route answered with (the task) and the cadence the press sent, in
 *  the engine's words. One middle dot (design-fix-2 DA2-033): the name and its cadence
 *  are one fact. A routine turned off or ended is its name alone. Pure. */
export function settledLine(view, task) {
  const lead = SETTLED_LEAD[view && view.mode] || "Done";
  const name = (task && text(task.name)) || (view && view.name) || "";
  const stopped = !view || view.mode === "pause" || view.mode === "end";
  const sent = view && view.cadenceWords ? view.cadenceWords.charAt(0).toLowerCase() + view.cadenceWords.slice(1) : null;
  const when = stopped ? null : sent || (task && cadenceWords(task.cadence)) || null;
  const what = when ? `${name}, ${when}` : name;
  return metaLine([lead, what]);
}

function sameCadence(a, b) {
  const x = isObj(a) ? a : {};
  const y = isObj(b) ? b : {};
  return ["every", "time", "weekday", "monthDay"].every((k) => (x[k] ?? null) === (y[k] ?? null));
}

function twinOf(view, tasks) {
  return tasks.find((t) => isObj(t) && t.kind === view.body.kind && t.name === view.body.name && sameCadence(t.cadence, view.body.cadence)) || null;
}

/**
 * Is the change this card proposes already in Scheduled, as it stands now? A card's
 * settled state lived only in the component, so a reload offered the press again (prod
 * walk, 5 Nov 2026). Read on mount: `{ ok: true, task }` when the list shows the change
 * made (a set-up's twin, the new cadence, the routine off or on, an ended one gone),
 * else null. A list that wasn't read settles nothing: an unread list is not an empty one.
 * Never throws.
 */
export async function settledFromList(view, client = api) {
  if (!view || !PRESS_LABEL[view.mode]) return null;
  let listed;
  try {
    listed = await client.list();
  } catch {
    return null;
  }
  if (!listed || listed.ok !== true || !Array.isArray(listed.tasks)) return null;
  const tasks = listed.tasks;
  if (view.mode === "create") {
    const twin = twinOf(view, tasks);
    return twin ? { ok: true, task: twin } : null;
  }
  const task = tasks.find((t) => isObj(t) && t.id === view.taskId) || null;
  if (view.mode === "end") return task ? null : { ok: true, task: null };
  if (!task) return null;
  const body = view.body || {};
  if (typeof body.enabled === "boolean" && (task.enabled === true) !== body.enabled) return null;
  if (isObj(body.cadence) && !sameCadence(task.cadence, body.cadence)) return null;
  return { ok: true, task };
}

/**
 * The press: the card's body to the route its mode names, through lib/scheduled-client.js
 * (the Scheduled screen's own calls). A set-up first reads the list: the same routine
 * already there (this card pressed before, on another tab) is said, never made twice.
 * Never throws: `{ ok, task, already?, message? }`.
 */
export async function pressSchedule(view, client = api) {
  if (!view || !PRESS_LABEL[view.mode]) return { ok: false, message: "Nothing to press" };
  if (view.mode === "create") {
    const listed = await client.list();
    if (listed && listed.ok && Array.isArray(listed.tasks)) {
      const twin = twinOf(view, listed.tasks);
      if (twin) return { ok: true, task: twin, already: true };
    }
    const made = await client.create({ kind: view.body.kind, name: view.body.name || null, cadence: view.body.cadence, config: view.body.config || null });
    return made && made.ok ? { ok: true, task: made.task || null, drafted: made.drafted || [] } : { ok: false, message: (made && made.message) || "Not saved" };
  }
  if (view.mode === "end") {
    const ended = await client.end(view.taskId);
    return ended && ended.ok ? { ok: true, task: ended.task || null } : { ok: false, message: (ended && ended.message) || "Not ended" };
  }
  const changed = await client.patch(view.taskId, view.body);
  return changed && changed.ok ? { ok: true, task: changed.task || null } : { ok: false, message: (changed && changed.message) || "Not saved" };
}
