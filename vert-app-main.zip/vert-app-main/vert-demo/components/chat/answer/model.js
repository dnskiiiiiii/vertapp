// components/chat/answer/model.js — THE ANSWER'S SHAPE, AS PURE FUNCTIONS
// ==============================================================================
// Build plan §4.0.8. A finished answer shows at most four blocks: the verdict, up to
// three facts, what was delivered (only when something was), and ONE next action. The
// work that produced it is folded into one quiet disclosure on the turn's identity row,
// "How Vert did this" (design-fix-2 §7.3, founder decision D9).
//
// These are the decisions behind that shape, kept out of the components so a test can
// hold each one without rendering anything:
//
//   · which next action an answer draws, and why a Download is never one;
//   · where a delivered chip points (the workbook proxy, for every artifact kind);
//   · how long the work took, in words, from the engine's own timestamps;
//   · which line in a turn carries the "How Vert did this" outline, so it is drawn once.
//
// NOTHING HERE TOUCHES MONEY. A duration is the distance between two stored `at`
// timestamps; it is never a clock in the browser (tests/chat-truth.test.js), and a
// missing timestamp is said in words rather than drawn as "0 s".

import { mergeDataRead } from "../../../lib/agent/data-read.js";

/** What a turn's blocks say they read, put together (lib/agent/data-read.js), or null.
 *  Records and counts of records only: no amount is touched. Pure. */
export function turnRead(works) {
  let read = null;
  for (const w of works) if (w && w.read) read = mergeDataRead(read, w.read);
  return read;
}

/** A label that offers a download. The contract refuses it (§4.2); so does the screen. */
export const DOWNLOAD_LABEL = /download/i;

/**
 * Whether an ask chip's words are Vert talking TO you, not words you would say to Vert.
 *
 * WHY. An ask chip's text is sent as YOUR message when pressed. The engine wrote "Would
 * you like to open the four payout breaks first?", the chip sent it, and the thread showed
 * you asking Vert its own question (bug bash 10 Oct 2026). The engine is being fixed to
 * stop writing these; this is the screen's own guard, so such a chip is never drawn.
 *
 * The rule: the words open the way Vert offers or asks permission ("Would you like",
 * "Do you want", "Shall I", "Should I", "Can I", "Want me to", "Would you"), or they are a
 * question that asks about YOUR wishes or state ("Which one would you like…?", "Are you
 * ready…?", "Is your bank feed connected?"). A question of yours to Vert ("What changed?",
 * "Can you show me the breaks?") passes.
 */
const VERT_OPENERS = /^(?:would you like|do you want|shall i|should i|can i|want me to|would you|are you|is your|are your|did you mean)\b/i;
const ASKS_YOUR_WISH = /\byou(?:'d| would)?\s+(?:like|want|prefer|need)\b|\b(?:would|are)\s+you\b/i;
export function speaksToYou(text) {
  const words = typeof text === "string" ? text.trim() : "";
  if (!words) return false;
  if (VERT_OPENERS.test(words)) return true;
  return words.includes("?") && ASKS_YOUR_WISH.test(words);
}

/** Where a delivered chip downloads: the app's workbook proxy (app/api/agent/artifacts). */
export function xlsxProxyHref(artifactId) {
  if (typeof artifactId !== "string" || !artifactId) return null;
  return `/api/agent/artifacts/${encodeURIComponent(artifactId)}/xlsx`;
}

/** A chip's file name: the engine's label, with `.xlsx` once. */
export function fileName(label) {
  const text = typeof label === "string" ? label.trim() : "";
  if (!text) return "";
  return /\.xlsx$/i.test(text) ? text : `${text}.xlsx`;
}

/**
 * The answer's one next action, or null.
 *
 * An iteration-2 `next` ({label, action}) comes first; otherwise the iteration-1 link
 * (`commit`, from `next.href` or `open.href`), so a stored conversation still draws its
 * way on. A label that offers a download is never drawn: every delivered chip already
 * downloads its workbook, and spending the answer's one action on something already on
 * screen leaves the person with nothing to do next. It is logged, because the engine's
 * validator should have refused it and a contract held on one side is a hope.
 *
 * Returns `{ label, kind, href?, action? }`: `href` for a way there, `action` for a
 * thing the thread does (open a result, start a task, ask).
 */
export function nextActionOf(item, { log = defaultLog } = {}) {
  const a = item || {};
  const candidates = [];
  if (a.next && typeof a.next === "object" && a.next.action) {
    const offer = askOffer(a.next, log);
    if (offer) candidates.push(offer);
  }
  if (a.commit && typeof a.commit === "object" && a.commit.href) {
    candidates.push({ label: a.commit.label, kind: a.commit.kind || "open", href: a.commit.href });
  }
  for (const c of candidates) {
    const label = typeof c.label === "string" ? c.label.trim() : "";
    if (!label) continue;
    if (DOWNLOAD_LABEL.test(label)) {
      log(`next action not drawn: "${label}" offers a download, and the delivered chip already does`);
      continue;
    }
    return { ...c, label };
  }
  return null;
}

/**
 * The answer's other offers (`also`: "Draft commentary", "Budgets"), drawn after the next
 * action as secondary buttons (components/chat/NextAction.js), or [].
 *
 * The same rules as the next action: a download is never offered (the chip downloads),
 * and an offer that repeats the next action's label is the same press drawn twice.
 * At most three, so the row never outgrows the answer it closes.
 */
export function alsoActionsOf(item, next = null, { log = defaultLog } = {}) {
  const list = item && Array.isArray(item.also) ? item.also : [];
  const seen = new Set(next && next.label ? [next.label.trim().toLowerCase()] : []);
  const out = [];
  for (const o of list) {
    if (!o || typeof o !== "object" || !o.action || typeof o.action !== "object") continue;
    const offer = askOffer(o, log);
    const label = offer && typeof offer.label === "string" ? offer.label.trim() : "";
    if (!label || seen.has(label.toLowerCase())) continue;
    if (DOWNLOAD_LABEL.test(label)) {
      log(`offer not drawn: "${label}" offers a download, and the delivered chip already does`);
      continue;
    }
    seen.add(label.toLowerCase());
    out.push({ label, kind: o.action.kind, action: o.action });
    if (out.length === 3) break;
  }
  return out;
}

/**
 * An offer `{label, action}` as the button draws it, or null when it must not be drawn.
 * An ASK shows the words it sends: the label "Open the breaks" over the text "Would you
 * like to open…?" let one press say two different things (bug bash 10 Oct 2026). An ask
 * whose words are Vert speaking to you is dropped (speaksToYou), so the answer's other
 * way on (its "Open …" link) is drawn instead.
 */
function askOffer(o, log) {
  const action = o.action;
  if (action.kind !== "ask") return { label: o.label, kind: action.kind, action };
  const text = typeof action.text === "string" ? action.text.trim() : "";
  if (speaksToYou(text)) {
    log(`ask not drawn: "${text}" is Vert asking you, and pressing it would send it as your message`);
    return null;
  }
  return { label: text, kind: "ask", action };
}

function defaultLog(message) {
  if (typeof console !== "undefined" && typeof console.warn === "function") console.warn(`[vert] ${message}`);
}

function parseAt(at) {
  if (typeof at !== "string" || !at) return null;
  const t = Date.parse(at);
  return Number.isFinite(t) ? t : null;
}

/**
 * How long, in words, from one stored timestamp to another: "41 s", "2 min 5 s",
 * "1 h 3 min", "under a second". Null when either is missing or they run backwards:
 * a duration nobody measured is not zero.
 */
export function durationWords(fromAt, toAt) {
  const from = parseAt(fromAt);
  const to = parseAt(toAt);
  if (from === null || to === null || to < from) return null;
  const secs = Math.round((to - from) / 1000);
  if (secs < 1) return "under a second";
  if (secs < 60) return `${secs} s`;
  const mins = Math.floor(secs / 60);
  const rest = secs % 60;
  if (mins < 60) return rest ? `${mins} min ${rest} s` : `${mins} min`;
  const hours = Math.floor(mins / 60);
  const restMins = mins % 60;
  return restMins ? `${hours} h ${restMins} min` : `${hours} h`;
}

/** The shortest work worth timing (design-fix-2 §7.3): under two seconds says nothing. */
export const TIMED_FROM_MS = 2000;

/**
 * How long the turn took, said only inside "How Vert did this" and only when it took two
 * seconds or more (D9, DA2-032): "Took 41 s". Null when it was quicker, or unmeasured: a
 * duration nobody measured is not zero, and a fast turn needs no stopwatch on its face.
 */
export function workedForLine(fromAt, toAt) {
  const from = parseAt(fromAt);
  const to = parseAt(toAt);
  if (from === null || to === null || to - from < TIMED_FROM_MS) return null;
  const words = durationWords(fromAt, toAt);
  return words ? `Took ${words}` : null;
}

function earliest(list) {
  let best = null;
  for (const at of list) {
    const t = parseAt(at);
    if (t !== null && (best === null || t < best.t)) best = { t, at };
  }
  return best ? best.at : null;
}

function latest(list) {
  let best = null;
  for (const at of list) {
    const t = parseAt(at);
    if (t !== null && (best === null || t > best.t)) best = { t, at };
  }
  return best ? best.at : null;
}

/**
 * WHETHER AN ANSWER IS A LIST THE PERSON ASKED FOR (verify pass 8, S-E2E-4). True when the
 * turn your message opened read a list for you: one of its work steps called a `list_*` tool
 * (list_decisions, list_entries…). Such an answer's facts are the list's groups, the thing
 * asked for, so none of them is folded behind More (Answer.js). A task's answer, whose
 * facts are Vert's own state under its work, keeps the open-words budget. Pure.
 */
export function answerReadAList(items, answerSeq) {
  const list = Array.isArray(items) ? items : [];
  const at = list.findIndex((i) => i && i.kind === "answer" && i.seq === answerSeq);
  let listed = false;
  for (let k = at - 1; k >= 0; k -= 1) {
    const item = list[k];
    if (!item || item.kind === "answer") return false;
    // Only a turn YOUR message opened: a task's own run reads its rows with list tools
    // too (the bank rec's list_bank_lines), and its answer keeps the budget.
    // A task you started (your bubble is its title, `started`) is a task's run, not a
    // message: its list tools read rows for the task, and its answer keeps the budget.
    if (item.kind === "you") return item.started ? false : listed;
    if (item.kind === "work" && Array.isArray(item.steps) && item.steps.some((st) => st && typeof st.tool === "string" && /^list_/.test(st.tool))) listed = true;
  }
  return false;
}

/**
 * ONE "WORKED FOR" LINE PER TURN, AND WHERE IT GOES.
 *
 * A turn is your message and everything Vert did after it (or, before you have typed,
 * everything from the start), up to a run that starts after it answered. Its work can arrive as several blocks: a model turn that
 * starts a task has the model's block and the task's. Drawn one each, the person read
 * two outlines about one request; so the LAST block of the turn carries the
 * whole turn's steps, and the earlier ones draw nothing. A turn with answers but no
 * block (a model answering from what it already had) still gets its line, just before
 * its first answer, because that is where the machinery facts live now.
 *
 * Returns `{ hosts, before }`:
 *   hosts    Map(work seq → outline) for the block that draws the turn's line
 *   hidden   Set(work seq) for the blocks folded into a later one
 *   before   Map(answer seq → outline) for a turn with no block
 *
 * An outline is `{ running, current, steps, fromAt, toAt, produced, summary, reason, open }`.
 */
export function workedForTurns(items) {
  const list = Array.isArray(items) ? items : [];
  const turns = [];
  let turn = { you: null, items: [] };
  for (const item of list) {
    // A new turn at your message, and at a block of work that starts after this turn
    // already answered: a task run again is a new run, and one line spanning both would
    // time the days between them.
    const rerun = item.kind === "work" && turn.items.some((i) => i.kind === "answer");
    if (item.kind === "you" || rerun) {
      turns.push(turn);
      turn = { you: item.kind === "you" ? item : null, items: item.kind === "you" ? [] : [item] };
    } else turn.items.push(item);
  }
  turns.push(turn);

  // A RUN THAT ONLY OFFERS A STEPS UPDATE IS NOT A NEW MESSAGE (verify pass 2, D21). After
  // a question was answered the task re-ran, said nothing new, and offered "Update the
  // steps"; the thread drew "Vert 4:07 pm · How Vert did this" with no words under it,
  // holding only that card. Such a run (finished, no answer, nothing but skill updates)
  // belongs to the message before it: its card sits under that answer, and its steps join
  // that message's "How Vert did this".
  for (let i = turns.length - 1; i > 0; i -= 1) {
    const t = turns[i];
    const rest = t.items.filter((x) => x.kind !== "work");
    const finished = t.items.every((x) => x.kind !== "work" || x.state !== "running");
    const onlySteps = rest.length > 0 && rest.every((x) => x.kind === "decision" && x.action && x.action.kind === "skill_update");
    // NOR IS A RUN THAT SAID NOTHING AT ALL (verify pass 6, Q05): a question skipped, the
    // task resumed, read the month again and ended with no answer and nothing else of
    // its own. Drawn as its own turn it was "Vert 3:01 pm · How Vert did this" over no
    // words; its steps join the message before it.
    const silent = rest.length === 0 && t.items.length > 0;
    if (!t.you && finished && (onlySteps || silent) && turns[i - 1].items.some((x) => x.kind === "answer")) {
      turns[i - 1].items.push(...t.items);
      turns.splice(i, 1);
    }
  }

  const hosts = new Map();
  const hidden = new Set();
  const before = new Map();
  for (const t of turns) {
    const works = t.items.filter((i) => i.kind === "work");
    const answers = t.items.filter((i) => i.kind === "answer");
    if (!works.length && !answers.length) continue;
    const lastAnswer = answers.length ? answers[answers.length - 1] : null;
    // The identity row is drawn at its host: the last work BEFORE the turn's first answer
    // (a merged steps-update run's work comes after it and must not carry the row).
    const firstAnswer = answers.length ? answers[0] : null;
    const leading = firstAnswer ? works.filter((w) => w.seq < firstAnswer.seq) : works;
    const host = leading.length ? leading[leading.length - 1] : works.length ? works[works.length - 1] : null;
    const steps = works.flatMap((w) => (Array.isArray(w.steps) ? w.steps : []));
    const fromAt = (t.you && parseAt(t.you.at) !== null ? t.you.at : null) || earliest(t.items.map((i) => i.at));
    const toAt = latest([...works.map((w) => w.finishedAt), ...t.items.map((i) => i.at)]);
    const outline = {
      // The turn, for its "Data fetched" block and the sources panel (lib/agent/turn-sources.js):
      // a stable key, what you asked (your message, or the task you started) and every
      // item Vert drew in it (the figures its answers bind are the data it used).
      key: `turn-${t.you ? t.you.seq : t.items[0].seq}`,
      you: t.you || null,
      items: t.items,
      running: Boolean(host && host.state === "running"),
      steps,
      fromAt,
      toAt,
      // The turn's provenance is its last answer's (the answer it produced); a turn of
      // work alone is the work's.
      produced: (lastAnswer && lastAnswer.produced) || (host && host.produced) || null,
      summary: host ? host.summary || null : null,
      // Not when the turn's answer already says it (verify pass 3, W07: said three times).
      reason: host && !host.reasonSaid ? host.reason || null : null,
      open: works.map((w) => w.open).find(Boolean) || null,
      // What Vert brought to this turn (memory_used): the answers it kept and the skill.
      // A brain carried into a resumed run (lib/agent/events.js) heads only a turn that
      // ran something: a block with no steps draws nothing, as before (P35/D44).
      brain: works.map((w) => w.brain).find((b) => b && !b.carried) || (steps.length ? works.map((w) => w.brain).find(Boolean) : null) || null,
      // What the turn read, as the engine recorded it (`run_state.read`, p1 sources):
      // every block of the turn's, put together. Null on a recording made before it.
      read: turnRead(works),
      // Whether the turn answered anything: a turn of work with no answer and nothing to
      // show draws nothing at all (WorkedFor.js; DA2-056).
      answered: answers.length > 0,
      // Whether anything else of Vert's is drawn in this turn (a card, a question, a
      // result): a header over those still says whose they are (W18).
      carries: t.items.some((i) => i.kind !== "work" && i.kind !== "answer"),
    };
    if (host) {
      hosts.set(host.seq, outline);
      for (const w of works) if (w !== host) hidden.add(w.seq);
    } else {
      before.set(answers[0].seq, outline);
    }
  }
  return { hosts, hidden, before };
}

/* ── THE ANALYSIS BODY: AN ANSWER'S RESULT, IN ITS OWN CLAIMS ─────────────────── */

const CELL = /^([A-Z]{1,3})(\d+)$/;

function cellParts(cell) {
  const m = typeof cell === "string" ? CELL.exec(cell.trim()) : null;
  return m ? { col: m[1], row: Number(m[2]) } : null;
}

/** "Product sales: … → …" → "product sales"; a sentence with no label → null. */
function leadLabel(text) {
  const m = typeof text === "string" ? /^\s*([^:{}]{1,60}):/.exec(text) : null;
  return m ? m[1].trim().toLowerCase() : null;
}

/** A claim that is only a heading ("Revenue"): no figure, no colon, a few words. */
function isHeading(text) {
  return !/\{\{\s*fig:/.test(text) && !/[:.?]/.test(text) && text.trim().split(/\s+/).length <= 4;
}

/**
 * THE ANALYSIS AN ANSWER DELIVERED, IN THE ENGINE'S OWN CLAIMS, or null (eval AY1).
 *
 * A flux answer's three facts said Product sales and the bottom line; the Revenue and
 * Expenses groups, the rent that stopped and the office spend that rose twelvefold were
 * in the result's `claims` and nowhere on screen. The claims are the analysis: each is a
 * sentence the engine wrote against a cell of the workbook (EC3a keeps them mapped), so
 * the body is drawn from them, not re-worded here.
 *
 * Which result: the one the answer delivered, else the one its next action opens; the
 * latest copy, because a task run twice emits it twice. Which claims: those on the
 * result's first-named sheet, the analysis itself. A claim that asks ("Want the lines
 * behind Product sales?") is a drill-down, and the answer's one drill-down is its next
 * action, so it is left out rather than drawn as a second.
 *
 * Grouping is by the cells, never by the words: a heading claim ("Revenue", A5) opens a
 * group; the lines after it in one column are its lines; a line in another column (the
 * bottom line, C20) closes the groups and stands on its own.
 *
 * Returns `{ artifactId, figures, blocks, repeats }`: `blocks` is a list of
 * `{ label, lines }` (a null label for a line standing alone), each line `{ text, cell }`;
 * `repeats(fact)` says whether a fact says again what a claim says ("Product sales: …").
 */
export function analysisOf(answer, items) {
  const a = answer || {};
  const ids = new Set();
  for (const d of Array.isArray(a.delivered) ? a.delivered : []) if (d && d.artifactId) ids.add(d.artifactId);
  const nextAction = a.next && a.next.action;
  if (!ids.size && nextAction && nextAction.kind === "open_artifact" && nextAction.artifactId) ids.add(nextAction.artifactId);
  if (!ids.size) return null;
  // EACH ANSWER BINDS TO ITS OWN RUN'S RESULT (verify passes 1-4, Q08 / F-3). This took
  // the LAST result with the artifact's id anywhere in the thread, so once a later run
  // (after a posting moved July) emitted the same artifact again, the EARLIER answer's
  // groups were redrawn with the later run's claims under its own headline: "$17,458.34
  // (down 6%)" over a bottom line of $18,658.34, "(+21%)" over "(+14%)". Earlier rounds
  // fixed the figure presses, never which run the body was read from.
  // The result an answer speaks for is the one in ITS run: the stretch of the thread
  // between the person's message or work block before it and the next one after it
  // (a run emits its answer and its result in either order). Failing that, the latest
  // copy before the answer (a follow-up about an earlier result); failing that, any.
  const list = Array.isArray(items) ? items : [];
  const at = list.indexOf(answer);
  const boundary = (item) => item && (item.kind === "you" || item.kind === "work");
  let lo = 0;
  let hi = list.length;
  if (at >= 0) {
    for (let i = at - 1; i >= 0; i -= 1) if (boundary(list[i])) { lo = i; break; }
    for (let i = at + 1; i < list.length; i += 1) if (boundary(list[i])) { hi = i; break; }
  }
  // A result whose figures CONTRADICT the answer's own (the same figure key, other
  // cents) is another run's, wherever it sits; it is used only if nothing agrees.
  const agrees = (art) => {
    const mine = a.figures && typeof a.figures === "object" ? a.figures : {};
    const theirs = art.figures && typeof art.figures === "object" ? art.figures : {};
    for (const [k, f] of Object.entries(mine)) {
      const t = theirs[k];
      const c1 = f && typeof f === "object" ? f.cents : undefined;
      const c2 = t && typeof t === "object" ? t.cents : undefined;
      if (Number.isInteger(c1) && Number.isInteger(c2) && c1 !== c2) return false;
    }
    return true;
  };
  const matching = list.filter((item) => {
    // A result borrowed from a linked task (lib/agent/linked.js) is drawn as its card,
    // not as this answer's analysis: the answer keeps the words the engine gave it.
    const art = item && item.kind === "result" && !item.linked ? item.artifact : null;
    return Boolean(art && ids.has(art.artifactId) && Array.isArray(art.claims) && art.claims.length);
  });
  const agreeing = matching.filter((item) => agrees(item.artifact));
  const pool = new Set(agreeing.length ? agreeing : matching);
  let inRun = null;
  let before = null;
  let any = null;
  list.forEach((item, i) => {
    if (!pool.has(item)) return;
    any = item;
    if (at >= 0 && i >= lo && i < hi) inRun = item;
    if (at >= 0 && i < at) before = item;
  });
  const chosen = at < 0 ? any : inRun || before || any;
  if (!chosen) return null;
  const artifact = chosen.artifact;
  // A later run replaced the result this answer read: its figures are kept as they were
  // (they are what it said), and the answer says a later run has the current ones.
  const stale = at >= 0 && Boolean(chosen.replaced);
  if (!artifact) return null;

  const valid = artifact.claims.filter((c) => c && typeof c.text === "string" && c.text.trim());
  if (!valid.length) return null;
  const sheet = valid[0].sheet || null;
  const claims = valid.filter((c) => (c.sheet || null) === sheet && !c.text.includes("?"));
  // A heading alone says nothing: an analysis needs at least one line.
  if (!claims.some((c) => !isHeading(c.text))) return null;

  const blocks = [];
  let group = null;
  for (const c of claims) {
    const text = c.text.trim();
    const at = cellParts(c.cell);
    if (isHeading(text)) {
      group = { label: text, lines: [], col: null };
      blocks.push(group);
      continue;
    }
    const line = { text, cell: c.cell || null };
    if (group && (group.col === null || (at && at.col === group.col))) {
      if (group.col === null) group.col = at ? at.col : null;
      group.lines.push(line);
    } else {
      group = null;
      blocks.push({ label: null, lines: [line], col: null });
    }
  }
  const shown = blocks.filter((b) => b.lines.length).map(({ label, lines }) => ({ label, lines }));
  if (!shown.length) return null;

  const said = new Set();
  for (const b of shown) for (const l of b.lines) { const k = leadLabel(l.text); if (k) said.add(k); }
  // EACH SENTENCE ONCE (verify pass 1, D25/D34/flux). A fact was dropped whole when it
  // LED with a claim's label, else drawn whole: the flux answer's "Revenue: … (+7%).
  // Service revenue: …" led with a group's name, so it was drawn under the groups again,
  // and "Bottom line: … June was never closed in Vert…" led with a claim's, so the June
  // caveat vanished. Now a fact is read sentence by sentence: a sentence a claim says is
  // not drawn again; a sentence that totals a group ("Revenue: $36,000.00 → $38,500.00
  // (+7%).") is that group's heading line; whatever is left (a caveat) is a fact.
  const claimed = new Set();
  for (const b of shown) for (const l of b.lines) claimed.add(sentenceKey(l.text));
  const groups = new Map();
  for (const b of shown) if (b.label) groups.set(b.label.trim().toLowerCase(), b);
  const facts = [];
  for (const fact of factTexts(a.facts)) {
    const left = [];
    for (const sentence of sentencesOf(fact)) {
      if (claimed.has(sentenceKey(sentence))) continue;
      const k = leadLabel(sentence);
      const group = k !== null ? groups.get(k) : null;
      if (group && !group.summary) {
        group.summary = sentence;
        continue;
      }
      left.push(sentence);
    }
    if (left.length) facts.push(left.join(" "));
  }
  return {
    artifactId: artifact.artifactId,
    figures: { ...(a.figures || {}), ...(artifact.figures || {}) },
    stale,
    blocks: shown,
    // The answer's facts with every sentence the analysis already draws taken out.
    facts,
    repeats: (fact) => { const k = leadLabel(fact); return k !== null && said.has(k); },
  };
}

/** The facts' texts, whether the engine sent strings or `{text}` objects. */
function factTexts(facts) {
  return (Array.isArray(facts) ? facts : [])
    .map((f) => (typeof f === "string" ? f : f && typeof f.text === "string" ? f.text : ""))
    .filter((t) => t.trim());
}

/** "A: x → y (+7%). B: …" → ["A: x → y (+7%).", "B: …"]: a full stop, a space, a capital. */
export function sentencesOf(text) {
  return String(text || "")
    .split(/(?<=[.!?])\s+(?=[A-Z])/)
    .map((t) => t.trim())
    .filter(Boolean);
}

function sentenceKey(text) {
  return String(text || "").replace(/\s+/g, " ").replace(/[.\s]+$/, "").trim().toLowerCase();
}

/**
 * THE AS-AT FACT (engine w3/int, staging browser walk 1, D5). A trial balance review says
 * when the figures were read: "Figures are Xero's as at 31 Oct 2026, 12:20 pm.", and what
 * Vert wrote to the ledger since. It is said on the face of the answer, never folded
 * under More with Vert's own state. `{ asAt, rest }`: the fact (or null) and the others,
 * each as sent. Pure.
 */
const AS_AT_FACT = /^Figures are .+?['\u2019]s as at \d{1,2}\s\S+ \d{4}/;
export function asAtFactOf(facts) {
  const list = Array.isArray(facts) ? facts : [];
  const at = list.findIndex((f) => typeof f === "string" && AS_AT_FACT.test(f.trim()));
  if (at < 0) return { asAt: null, rest: list };
  return { asAt: list[at].trim(), rest: list.filter((_, i) => i !== at) };
}
