"use client";

// components/chat/answer/BankRecRows.js — THE BANK REC, AS THE LEDGER'S RECONCILE SCREEN READS
// ==============================================================================
// The co-founder found the bank rec answer "confusing": a balance walk and reconciling
// items keyed R1, R2… What he asked for is the screen he already knows: each bank line
// on the left, what it matches in the ledger (or how to code it) on the right, a word on every
// row saying where it stands, then what to do, numbered, and the statement against the
// books. So, under the verdict, in this order:
//
//   1. Already reconciled in the ledger        a count and a total, the rows folded away;
//   2. In the ledger, not yet reconciled       each entry with the statement line it matches;
//   3. On the bank statement, not in the ledger each line with the invoice or bill it pays,
//                                         the drafted adjusting entry, or a coding;
//   4. Can't resolve yet                 why, in plain words, and what the person can do;
//   5. Plan                              numbered steps;
//   6. Statement against the ledger            closing balance, books, the difference and its
//                                         status word; never plugged.
//
// Without a statement only 1 and 2 are drawn, with the engine's sentence saying why the
// lines need the statement (the ledger doesn't share unreconciled lines through its API); the
// upload is the question drawn under the answer, the one action.
//
// A CODING ROW IS DECIDED ON THE ROW (migration 052, `coding_approve`). Approve takes
// Vert's coding as it stands; Change opens the account, tax rate and contact in place;
// a line Vert wasn't sure about asks which account, with its alternatives to pick. The
// engine checks who may approve (a journal approval's rules), writes it to the ledger when the
// connection allows, and says what it did: "Created in the ledger: click OK on the reconcile
// screen" with the link, "Approved: enter these in the ledger" with the fields to copy, or
// "Already in the ledger". The section of lines the ledger doesn't have carries one "Approve N
// high-confidence" for the rows that qualify. Matches still need the person's OK in
// the ledger (the ledger allows no app to reconcile). Every figure is the engine's cents
// (bank-rec.js); nothing is summed here. Status always carries its word; colour only
// repeats it.

import "./bank-rec.css";
import { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Button, Disclosure, Field, RememberTick, RuleSaved, SelectField, Sheet } from "@/components/ui";
import { usePhone } from "@/components/cards/usePhone";
import { SAMPLE_REASON } from "@/components/cards/words";
import { actorWords, actorsInWords, formatDay, formatMoney } from "@/lib/format";
import { useSignedInActor } from "@/lib/store";
import { useWritesEnabled } from "@/lib/engine-context";
import { withLedger } from "@/lib/agent/events";
import { approveCoding, approveHighConfidenceCodings, readCoding } from "@/lib/agent/actions";
import { readChartOnce } from "@/components/cards/chart-read";
import { attachToBankLine } from "@/lib/documents";
import { callSafely } from "@/lib/decisions";
import CashCodingPanel from "./CashCodingPanel";
import { DOCUMENT_ACCEPT, documentChip, fileHref, sessionFromPath, uploadFile } from "@/components/chat/results/DocumentView";
import { TIE_WORDS, adjustmentOf, asksForAccount, bankRecOf, bulkWriteQuestion, codingWriteQuestion, canDecide, changeOf, codingChoices, decisionOf, decisionTone, directionWord, fieldsText, highConfidenceIds, pickedAccount, planNow, toneOf } from "./bank-rec";

/** The right-hand column's heading, by section. */
const RIGHT_HEAD = { reconciled: (l) => `In ${l}`, unreconciled: (l) => `In ${l}`, statement_only: () => "Proposal", unresolved: () => "Why it can't be resolved" };
/** What an empty section says, rather than an empty box. */
const EMPTY_WORDS = {
  reconciled: (l) => `Nothing is reconciled in ${l} for this month yet.`,
  unreconciled: (l) => `Every entry in ${l} is reconciled.`,
  statement_only: (l) => `Nothing to propose: every other statement line is in ${l} or listed below.`,
  unresolved: () => "Nothing left that Vert can't propose for.",
};

// The answer to a press whose server call never came back: it may have gone through.
const LOST_PRESS = Object.freeze({ ok: false, kind: "unconfirmed", code: "timeout", message: "May have gone through." });

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

export default function BankRecRows({ bankRec, ledgerName = null, superseded = null, seq = null, initial = null }) {
  // What a press on this screen changed, by row: the decision the engine answered with.
  // The answer was said before the press; the row shows what is true now.
  const [decided, setDecided] = useState({});
  const [tab, setTab] = useState("reconcile");
  // AN EARLIER RUN, FOLDED (founder's walk, 8 Nov 2026): a conversation opened on the
  // old run's full rows, and the latest was a scroll below them. It is one line until
  // asked for.
  const [showEarlier, setShowEarlier] = useState(Boolean(initial && initial.showEarlier));
  const signedIn = useSignedInActor();
  const router = useRouter();
  const view = bankRecOf(bankRec);
  if (!view) return null;
  // The engine's words name the ledger as a placeholder; these name it outright, from
  // the connected ledger's own name, and say "your ledger" when none was handed in.
  const ledger = ledgerName || "your ledger";
  // The ledger's name, and any stored actor in the engine's words worded for the viewer
  // (staging browser walk 1, D16: "Changed by key: browser-walk: waiting for …").
  const say = (t) => actorsInWords(withLedger(t, ledger), { signedIn });
  say.ledger = ledger;
  say.decided = decided;
  say.onDecided = (rowId, decision) => {
    if (rowId && decision) setDecided((prev) => ({ ...prev, [rowId]: decision }));
  };
  // A read-back that found the coding decided but sent no decision view: the thread is read again.
  say.refresh = () => router.refresh();
  // A LATER RUN REDRAWS THIS ONE (recheck 4, 26 Oct 2026): its rows are read-only and
  // point at the latest run, where every action is (lib/agent/events.js latestBankRec).
  say.readOnly = Boolean(superseded);
  // A press in flight, by decision id, as a test hands it in (the harness can't press).
  say.pressing = initial && initial.pressing && typeof initial.pressing === "object" ? initial.pressing : {};
  // A confirm open, by decision id (or "bulk"), as a test hands it in.
  say.confirming = initial && initial.confirming && typeof initial.confirming === "object" ? initial.confirming : {};
  // The engine's Rule saved sentence, by decision id, as a test hands it in.
  say.remembered = initial && initial.remembered && typeof initial.remembered === "object" ? initial.remembered : {};
  // The bank account this answer reconciles, for the confirm's words.
  say.account = view.account;
  const latestHref = superseded && superseded.seq != null ? `#bankrec-${superseded.seq}` : null;
  return (
    <section className="bankrec" id={!superseded && seq != null ? `bankrec-${seq}` : undefined} data-bankrec="" data-superseded={superseded ? "" : undefined} data-statement={view.statement ? "read" : "missing"} aria-label="Bank reconciliation">
      {latestHref ? (
        <p className="bankrec-superseded">
          <span className="ink-2">An earlier run, redone below. </span>
          <a className="link" href={latestHref} data-latest-run="">See the latest run</a>
          {" · "}
          <button type="button" className="link" aria-expanded={showEarlier ? "true" : "false"} onClick={() => setShowEarlier((v) => !v)} data-earlier-run="">
            {showEarlier ? "Hide it" : "Show it"}
          </button>
        </p>
      ) : null}
      {superseded && !showEarlier ? null : (
      <>
      {view.account ? <p className="shape-label bankrec-account">{say(view.account)}</p> : null}
      {/* RECONCILE | CASH CODING (w25, 3 Nov 2026), as Xero's bank account tabs: the
          lines with nothing to match are coded together on the Cash coding view. A run
          a later one redrew carries none: its actions are the latest run's. */}
      {/* RECONCILE | CASH CODING, IN PLACE (founder, 8 Nov 2026), as Xero's bank account
          tabs: Cash coding draws the same account's grid here (CashCodingPanel.js), it
          doesn't leave for the Cash coding page. */}
      {!superseded && view.period ? (
        <div className="tabs-ink bankrec-tabs" role="tablist" aria-label="Bank views">
          <button type="button" role="tab" className="tab-ink" aria-selected={tab === "reconcile" ? "true" : "false"} onClick={() => setTab("reconcile")} data-bankrec-tab="reconcile">
            Reconcile
          </button>
          <button type="button" role="tab" className="tab-ink" aria-selected={tab === "cash_coding" ? "true" : "false"} onClick={() => setTab("cash_coding")} data-bankrec-tab="cash_coding">
            Cash coding
          </button>
        </div>
      ) : null}
      {tab === "cash_coding" && !superseded ? (
        <CashCodingPanel cashCoding={{ period: view.period, accountId: view.accountId || null, rows: [] }} />
      ) : (
        <>
          {view.sections.map((s) => (
            <Section key={s.key} section={s} say={say} />
          ))}
          {!view.statement && view.statementWords ? (
            <p className="bankrec-nostatement" data-bankrec-nostatement="">
              {say(view.statementWords)}
            </p>
          ) : null}
          {planNow(view, decided).length ? <Plan steps={planNow(view, decided)} say={say} /> : null}
          {view.tieOut ? <Tie tie={view.tieOut} say={say} /> : null}
        </>
      )}
      </>
      )}
    </section>
  );
}

function Section({ section: raw, say }) {
  // Each row with its decision as this screen last heard it.
  const s = { ...raw, rows: raw.rows.map((r) => (r.decision && say.decided[r.id] ? { ...r, decision: say.decided[r.id] } : r)) };
  const body = !s.measured ? (
    <p className="bankrec-section-words">{say(s.words || "")}</p>
  ) : s.count === 0 ? (
    <p className="bankrec-empty">{EMPTY_WORDS[s.key](say.ledger)}</p>
  ) : (
    <Rows section={s} say={say} />
  );
  return (
    <section className="bankrec-section" data-section={s.key} data-count={s.count}>
      <header className="bankrec-section-head">
        <h4 className="bankrec-section-title">
          {say(s.title)}
          <span className="bankrec-count" aria-label={plural(s.count, "line", "lines")}>
            {s.count}
          </span>
        </h4>
        {s.measured && s.totalCents != null && s.count > 0 ? (
          <span className="bankrec-total num" title="Net of the lines in this section">
            {formatMoney(s.totalCents)}
          </span>
        ) : null}
      </header>
      {s.key === "statement_only" ? <BulkApprove rows={s.rows} say={say} /> : null}
      {s.collapsed && s.measured && s.count > 0 ? (
        <Disclosure summary={`Show the ${plural(s.count, "line", "lines")}`} className="bankrec-fold">
          {body}
        </Disclosure>
      ) : (
        body
      )}
      {s.more > 0 ? <p className="shape-more">{plural(s.more, "more line", "more lines")} in the workbook</p> : null}
    </section>
  );
}

function Rows({ section, say }) {
  return (
    <div className="bankrec-table" role="list">
      <div className="bankrec-cols" aria-hidden="true">
        <span>Bank statement</span>
        <span>{RIGHT_HEAD[section.key](say.ledger)}</span>
      </div>
      {section.rows.map((r) => (
        <div key={r.id} className="bankrec-row" role="listitem" data-status={r.status} data-tone={r.tone} data-row={r.id}>
          <div className="bankrec-bank">
            <span className="sr-only">Bank line: </span>
            {r.bank ? <Side side={r.bank} /> : <span className="bankrec-bankwords">{say(r.bankWords)}</span>}
          </div>
          <div className="bankrec-proposal">
            <span className="sr-only">{RIGHT_HEAD[section.key](say.ledger)}: </span>
            <span className="bankrec-status" data-tone={r.tone}>
              <span className="bankrec-dot" aria-hidden="true" />
              {r.statusWords}
              {r.confidence ? <span className="bankrec-confidence"> · {r.confidence} confidence</span> : null}
            </span>
            <Proposal proposal={r.proposal} say={say} />
            {r.reason ? <p className="bankrec-reason">{say(r.reason)}</p> : null}
            {r.action && !r.decision ? <p className="bankrec-action">{say(r.action)}</p> : null}
            {r.decision ? <CodingDecision row={r} say={say} /> : null}
            <RowReceipts row={r} say={say} />
          </div>
        </div>
      ))}
    </div>
  );
}

function Side({ side }) {
  return (
    <span className="bankrec-side">
      {side.date ? <span className="bankrec-date">{formatDay(side.date)}</span> : null}
      <span className="bankrec-desc" title={side.description}>
        {side.description}
      </span>
      <span className="bankrec-amount num" data-direction={side.direction}>
        <span className="bankrec-dir">{directionWord(side.direction)}</span> {formatMoney(side.amountCents)}
      </span>
    </span>
  );
}

function Proposal({ proposal, say }) {
  const p = proposal;
  if (p.kind === "book_entry") {
    const adj = adjustmentOf(p.adjustment);
    return (
      <div className="bankrec-prop" data-proposal="book_entry">
        <p className="bankrec-prop-main">{p.description}</p>
        <p className="bankrec-prop-meta">
          {p.date ? `${formatDay(p.date)} · ` : ""}
          {directionWord(p.direction)} <span className="num">{formatMoney(p.amountCents)}</span>
          {p.reference ? ` · ${p.reference}` : ""}
        </p>
        {adj ? (
          // The small difference Xero's Find & Match takes as an adjustment (D20).
          <p className="bankrec-prop-adjustment" data-adjustment={adj.kind}>
            Adjustment <span className="num">{formatMoney(adj.amountCents)}</span> · {adj.words}
            {adj.account ? ` · to ${adj.account}` : ` · choose the account in ${say.ledger}`}
          </p>
        ) : null}
      </div>
    );
  }
  if (p.kind === "document") {
    const docs = Array.isArray(p.documents) ? p.documents : [];
    return (
      <div className="bankrec-prop" data-proposal="document">
        {docs.map((d) => {
          const name = [cap(d.type), d.number].filter(Boolean).join(" ");
          return (
            <div key={d.id} className="bankrec-doc">
              <p className="bankrec-prop-main">
                {d.url ? (
                  <a className="link" href={d.url} target="_blank" rel="noopener noreferrer">
                    {name}
                  </a>
                ) : (
                  name
                )}
                {d.contact ? <span className="bankrec-contact"> · {d.contact}</span> : null}
              </p>
              <p className="bankrec-prop-meta">
                {Number.isInteger(d.amountDueCents) ? (
                  <>
                    Due <span className="num">{formatMoney(d.amountDueCents)}</span>
                  </>
                ) : Number.isInteger(d.totalCents) ? (
                  <>
                    Total <span className="num">{formatMoney(d.totalCents)}</span>
                  </>
                ) : null}
                {d.dueDate ? ` · due ${formatDay(d.dueDate)}` : ""}
              </p>
            </div>
          );
        })}
        {Number.isInteger(p.differenceCents) ? (
          <p className="bankrec-prop-meta">
            Differs by <span className="num">{formatMoney(p.differenceCents)}</span>
          </p>
        ) : null}
      </div>
    );
  }
  if (p.kind === "coding") {
    const tax = p.taxName || p.taxType;
    const alts = Array.isArray(p.alternatives) ? p.alternatives : [];
    return (
      <div className="bankrec-prop" data-proposal="coding">
        <p className="bankrec-prop-main">{[p.accountCode, p.accountName].filter(Boolean).join(" · ")}</p>
        <p className="bankrec-prop-meta">{[tax, p.contact].filter(Boolean).join(" · ")}</p>
        {p.basis ? <p className="bankrec-prop-basis">{p.basis}</p> : null}
        {alts.length ? <p className="bankrec-prop-basis">Or: {alts.map((a) => [a.accountCode, a.accountName].filter(Boolean).join(" ")).join(", ")}</p> : null}
      </div>
    );
  }
  if (p.kind === "entry") {
    return (
      <div className="bankrec-prop" data-proposal="entry">
        <p className="bankrec-prop-main">{say(p.words || "")}</p>
      </div>
    );
  }
  return null;
}

function Plan({ steps, say }) {
  return (
    <div className="bankrec-plan" data-bankrec-plan="">
      <p className="shape-label">Plan</p>
      <ol className="bankrec-steps">
        {steps.map((s) => (
          <li key={s.n} data-step={s.kind}>
            {say(s.words)}
            {s.amountCents != null ? (
              <>
                {" "}
                <span className="num bankrec-step-amount">{formatMoney(s.amountCents)}</span>
              </>
            ) : null}
          </li>
        ))}
      </ol>
    </div>
  );
}

function Tie({ tie, say }) {
  const money = (c, words) => (c == null ? <span className="bankrec-unread">{words}</span> : <span className="num">{formatMoney(c)}</span>);
  const tone = tie.status === "ties" ? "done" : tie.status === "unexplained" ? "problem" : tie.status === "explained" ? "attention" : "neutral";
  return (
    <div className="bankrec-tie" data-tie-status={tie.status}>
      <p className="shape-label">Statement against {say.ledger}</p>
      <dl className="bankrec-tie-lines">
        {/* A CARD READS AS OWED (9 Nov 2026 walk): "Statement balance $246.39" here and
            −$246.39 in the bank reconciliation report, which shows a card as the ledger
            does. Here the figures are what's owed, and the labels say so. The
            reconciling items are the engine's own, so the three lines add up. */}
        <div>
          <dt>{tie.owed ? "Owed per card statement" : "Statement balance"}</dt>
          <dd>{money(tie.statementCents, "Not read yet")}</dd>
        </div>
        {tie.itemsCents != null && tie.itemsCents !== 0 ? (
          <div data-tie-items="">
            <dt>Reconciling items</dt>
            <dd>{money(tie.itemsCents, "")}</dd>
          </div>
        ) : null}
        <div>
          <dt>{tie.owed ? `Owed per ${say.ledger}` : `Balance in ${say.ledger}`}</dt>
          <dd>{money(tie.booksCents, "Not read yet")}</dd>
        </div>
        <div className="bankrec-tie-diff">
          <dt>Difference</dt>
          <dd>
            {money(tie.differenceCents, "Not worked out")}{" "}
            <span className="bankrec-status" data-tone={tone}>
              <span className="bankrec-dot" aria-hidden="true" />
              {TIE_WORDS[tie.status] || tie.status}
            </span>
          </dd>
        </div>
      </dl>
      <p className="bankrec-tie-words">{say(tie.words)}</p>
      {tie.owed ? (
        <p className="bankrec-tie-words" data-tie-owed="">
          Shown as what's owed, as the card statement prints it. {say.ledger} and the bank reconciliation report show it as a minus.
        </p>
      ) : null}
    </div>
  );
}

// ─────────────────────────── a coding row's decision ───────────────────────────

const codingLine = (c) => [[c.accountCode, c.accountName].filter(Boolean).join(" "), c.taxName || c.taxType, c.contact].filter(Boolean).join(" · ");

/** Whether the decision approves something other than what the row proposes. */
function differs(row, coding) {
  const p = row.proposal || {};
  return Boolean(coding) && (coding.accountCode !== p.accountCode || (coding.taxType || null) !== (p.taxType || null) || (coding.contact || null) !== (p.contact || null));
}

function CodingDecision({ row, say }) {
  const writes = useWritesEnabled();
  const [editing, setEditing] = useState(false);
  // THE PRESS IN FLIGHT (B6, 27 Oct 2026): `{ which, from }`, the decision as it stood
  // when pressed. Until the settle answers, the row is drawn from `from`, pending, with
  // "Approving…": the thread's read can close the coding first ("Approved: the fields are
  // to enter by hand · key: founder") with no fields, and that drew for ~1 s before the
  // engine's own answer replaced it. The engine's outcome is drawn once the press is over.
  const [pressing, setPressing] = useState(() => (row.decision && say.pressing && say.pressing[row.decision.id]) || null);
  const [error, setError] = useState(null);
  // A PRESS WHOSE ANSWER NEVER CAME (staging browser walk 2, N3): Xero may hold it, so
  // the row offers only Check again (a read of the decision) until the engine says
  // where it stands; never a second Approve over a coding that may have been created.
  const [unsure, setUnsure] = useState(false);
  const [checking, setChecking] = useState(false);
  // THE CONFIRM (staging browser walk 1, D6): `{ which, change, coding }`, the press
  // waiting for its OK. Approving a coding writes to the ledger, so no press here sends
  // the approval itself; the confirm's commit does.
  const [confirming, setConfirming] = useState(() => (row.decision && say.confirming && say.confirming[row.decision.id]) || null);
  // REMEMBER (founder decision, 3 Nov 2026; engine w36): the coding becomes a rule only
  // when the person ticks this, unticked unless they do. It rides on the send, and the
  // engine's sentence for a rule it saved is kept for the outcome ("Rule saved").
  const [remember, setRemember] = useState(false);
  const [remembered, setRemembered] = useState(() => (row.decision && say.remembered && say.remembered[row.decision.id]) || null);
  const busy = pressing ? pressing.which : null;
  const d = pressing && pressing.from ? pressing.from : row.decision;
  if (d.state !== "pending") return <Outcome row={row} decision={d} say={say} remembered={remembered} />;
  if (say.readOnly) {
    // An earlier run's copy: what the decision was when it was drawn, and no press.
    return (
      <div className="bankrec-decision" data-decision-state="pending" data-decision={d.id} data-read-only="">
        <p className="bankrec-decision-line">
          <span className="bankrec-status" data-tone={decisionTone(d)}>
            <span className="bankrec-dot" aria-hidden="true" />
            {say(d.words)}
          </span>
        </p>
      </div>
    );
  }
  const asks = asksForAccount(row);
  const pressable = canDecide(d);
  const reason = writes ? undefined : SAMPLE_REASON;
  // A press asks; the confirm sends.
  const tick = <RememberTick name={`remember-${d.id}`} checked={remember} onChange={setRemember} />;
  const ask = (change, which, coding) => {
    if (pressing) return;
    setConfirming({ which, change, coding: coding || (d && d.coding) || row.proposal });
  };
  const send = async (change, which) => {
    if (pressing) return;
    setConfirming(null);
    setPressing({ which, from: d });
    setError(null);
    // A press whose call to this server was lost may still have reached Xero (walk 2, N3).
    const result = await approveCoding(d.id, change, { remember }).catch(() => LOST_PRESS);
    if (result && result.ok) setRemembered(result.remembered || null);
    const next = result && result.decision ? decisionOf(result.decision) : null;
    // The engine's answer first, then the press ends: the row goes from Approving… to
    // what the engine said, never through the thread's fieldless interim.
    if (next) say.onDecided(row.id, next);
    setPressing(null);
    if (result && result.ok) {
      setEditing(false);
      return;
    }
    // A change Vert kept for someone else to approve is shown as that, with why.
    if (next) setEditing(false);
    setUnsure(Boolean(result && result.kind === "unconfirmed"));
    setError((result && result.message) || LOST_PRESS.message);
  };
  const checkAgain = async () => {
    if (checking) return;
    setChecking(true);
    const back = await readCoding(d.id);
    setChecking(false);
    const next = back && back.decision ? decisionOf(back.decision) : null;
    if (next) say.onDecided(row.id, next);
    if (back && back.ok) {
      setUnsure(false);
      setError(null);
      if (!next && say.refresh) say.refresh();
      return;
    }
    // Still pending on a second look: the press can be made again.
    if (back && back.code === "not_recorded") setUnsure(false);
    setError((back && back.message) || "May have gone through.");
  };
  return (
    <div className="bankrec-decision" data-decision-state="pending" data-decision={d.id} data-pressing={busy || undefined} aria-busy={busy ? "true" : undefined}>
      <p className="bankrec-decision-line">
        <span className="bankrec-status" data-tone={decisionTone(d)}>
          <span className="bankrec-dot" aria-hidden="true" />
          {say(d.words)}
        </span>
      </p>
      {differs(row, d.coding) ? <p className="bankrec-prop-meta">Changed to {codingLine(d.coding)}</p> : null}
      {d.whyNot ? <p className="bankrec-reason">{say(d.whyNot)}</p> : null}
      {asks ? <AccountQuestion row={row} busy={busy} reason={reason} ask={ask} /> : null}
      {editing ? (
        <CodingEditor
          row={row}
          approves={pressable}
          busy={busy === "change"}
          reason={reason}
          onCancel={() => setEditing(false)}
          tick={tick}
          // Saving a change someone else approves writes nothing to the ledger: no confirm.
          onSubmit={(change, coding) => (pressable ? ask(change, "change", coding) : send(change, "change"))}
        />
      ) : (
        <div className="bankrec-decision-actions">
          {unsure ? (
            <Button size="sm" variant="secondary" busy={checking} busyLabel="Checking…" onClick={checkAgain} data-coding-check="">
              Check again
            </Button>
          ) : null}
          {!unsure && !asks && pressable ? (
            <Button size="sm" variant="commit" busy={busy === "approve"} busyLabel="Approving…" disabledReason={reason} onClick={() => ask(null, "approve")}>
              Approve
            </Button>
          ) : null}
          <Button size="sm" variant="quiet" disabledReason={busy ? "Wait for the approval to finish." : reason} onClick={() => setEditing(true)}>
            {asks ? "Something else" : "Change"}
          </Button>
          {unsure ? null : tick}
        </div>
      )}
      {error ? (
        <p className="bankrec-decision-error" role="alert">
          {say(error)}
        </p>
      ) : null}
      <WriteConfirm
        open={Boolean(confirming)}
        question={confirming ? codingWriteQuestion({ row, coding: confirming.coding || (d && d.coding) || row.proposal, account: say.account, ledger: say.ledger }) : null}
        ledger={say.ledger}
        busy={Boolean(busy)}
        reason={reason}
        onCancel={() => setConfirming(null)}
        onConfirm={() => confirming && send(confirming.change, confirming.which)}
      />
    </div>
  );
}

// THE SAME CONFIRM AS POST (components/cards/JournalCard.js JournalPostSheet): a modal
// (a bottom sheet on a phone) whose title is the question, the way back plainly beside
// the commit, and the commit naming the ledger. The question names what will be created.
function WriteConfirm({ open, question, ledger, busy, reason, onCancel, onConfirm, children = null }) {
  const phone = usePhone();
  // Mounted from its first open, so it can play its exit (components/ui/Sheet.js); never
  // drawn into the row's markup before anyone asked.
  const [shown, setShown] = useState(open);
  if (open && !shown) setShown(true);
  const [last, setLast] = useState(question);
  if (question && question !== last && (question.title !== (last && last.title))) setLast(question);
  const q = question || last;
  if (!shown || !q) return null;
  const named = ledger && !/^your ledger$/i.test(ledger) ? ledger : null;
  return (
    <Sheet
      open={open}
      onClose={onCancel}
      side={phone ? "bottom" : "modal"}
      title={q.title}
      className="post-sheet bankrec-confirm"
      footer={
        <div className="sheet-actions">
          <Button variant="quiet" onClick={onCancel}>
            Cancel
          </Button>
          <Button variant="commit" onClick={onConfirm} busy={busy} busyLabel="Approving…" disabledReason={reason} data-coding-confirm="">
            {q.commit}
          </Button>
        </div>
      }
    >
      {children}
      <p className="t-callout">
        {named
          ? `Vert writes it to ${named} when you confirm. It stays unreconciled there until you click OK on ${named}'s reconcile screen.`
          : "Vert approves it in your name when you confirm."}
      </p>
    </Sheet>
  );
}

/** A line Vert wasn't sure about: the question, and each alternative as the answer. */
function AccountQuestion({ row, busy, reason, ask }) {
  const alts = (Array.isArray(row.proposal.alternatives) ? row.proposal.alternatives : []).filter((a) => a && a.accountCode);
  return (
    <div className="bankrec-question" role="group" aria-label="Which account this line goes to">
      <p className="bankrec-question-title">Which account does this go to?</p>
      {alts.length ? (
        <div className="bankrec-question-options">
          {alts.map((a) => (
            <Button
              key={a.accountCode}
              size="sm"
              variant="secondary"
              busy={busy === a.accountCode}
              busyLabel="Approving…"
              disabledReason={busy && busy !== a.accountCode ? "Wait for the approval to finish." : reason}
              onClick={() => ask({ accountCode: a.accountCode, ...(a.taxType ? { taxType: a.taxType } : {}) }, a.accountCode, a)}
            >
              {[a.accountCode, a.accountName].filter(Boolean).join(" · ")}
              {a.taxName ? <span className="bankrec-question-tax"> · {a.taxName}</span> : null}
            </Button>
          ))}
        </div>
      ) : (
        <p className="bankrec-prop-meta">Vert has no suggestion for it. Pick one from your chart.</p>
      )}
    </div>
  );
}

/** Change, in place: account, tax rate and contact, from Vert's choices and the chart. */
function CodingEditor({ row, approves, busy, reason, onCancel, onSubmit, tick = null }) {
  const [chart, setChart] = useState({ accounts: [], note: null });
  useEffect(() => {
    let live = true;
    readChartOnce()
      .then((answer) => {
        if (live) setChart(answer && answer.ok ? { accounts: answer.accounts, note: null } : { accounts: [], note: (answer && answer.message) || null });
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, []);
  const choices = codingChoices(row, chart.accounts);
  const current = choices.current || {};
  const [account, setAccount] = useState(current.accountCode || "");
  const [tax, setTax] = useState(choices.taxes.some((t) => t.value && t.value === current.taxType) ? current.taxType : "");
  const [contact, setContact] = useState(current.contact || "");
  const change = changeOf(current, { accountCode: account, taxType: tax, contact });
  const unchanged = Object.keys(change).length === 0;
  const pickAccount = (code) => {
    setAccount(code);
    const picked = pickedAccount(choices, code, contact);
    setTax(picked.taxType);
    setContact(picked.contact);
  };
  return (
    <form
      className="bankrec-editor"
      aria-label="Change this coding"
      onSubmit={(e) => {
        e.preventDefault();
        const picked = choices.accounts.find((o) => o.value === account);
        if (!unchanged) onSubmit(change, picked ? { accountName: String(picked.label).replace(/\s+·\s+/g, " ") } : null);
      }}
    >
      <SelectField label="Account" value={account} placeholder="Pick an account" options={choices.accounts} onChange={(e) => pickAccount(e.target.value)} />
      <SelectField label="Tax rate" value={tax} options={choices.taxes} onChange={(e) => setTax(e.target.value)} />
      <Field label="Contact" value={contact} maxLength={255} onChange={(e) => setContact(e.target.value)} />
      {chart.note ? <p className="bankrec-prop-basis">{chart.note} Vert's suggestions are listed.</p> : null}
      <div className="bankrec-decision-actions">
        <Button type="submit" size="sm" variant="commit" busy={busy} busyLabel="Sending…" disabledReason={reason || (unchanged ? "Change the account, tax rate or contact first." : undefined)}>
          {approves ? "Approve with this change" : "Save this change"}
        </Button>
        <Button size="sm" variant="quiet" onClick={onCancel}>
          Cancel
        </Button>
        {tick}
      </div>
      {!approves ? <p className="bankrec-prop-basis">Someone else at your firm approves it.</p> : null}
    </form>
  );
}

/** What a decided coding did, in words; the fields to type, and the link to OK it. */
function Outcome({ row, decision: d, say, remembered = null }) {
  const [copied, setCopied] = useState(false);
  // Who decided it, as recorded ("key: founder"), worded against the viewer (engine w3/int).
  const signedIn = useSignedInActor();
  const by = actorWords(d.by, { signedIn });
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(fieldsText(d.fields));
      setCopied(true);
    } catch {
      setCopied(false);
    }
  };
  return (
    <div className="bankrec-decision" data-decision-state={d.state} data-outcome={d.outcome || ""} data-decision={d.id} data-gone-in-ledger={d.goneInLedger || undefined}>
      <p className="bankrec-decision-line">
        <span className="bankrec-status" data-tone={decisionTone(d)}>
          <span className="bankrec-dot" aria-hidden="true" />
          {say(d.words)}
        </span>
        {by ? <span className="bankrec-decision-by"> · {by}</span> : null}
        {typeof remembered === "string" && remembered.trim() ? (
          <span className="bankrec-decision-by">
            {" · "}
            <RuleSaved remembered={remembered} />
          </span>
        ) : null}
      </p>
      {d.state === "settled" && differs(row, d.coding) ? <p className="bankrec-prop-meta">As {codingLine(d.coding)}</p> : null}
      {/* The fields to type, folded (founder, 8 Nov 2026): every approved line printed them
          and a two-paragraph note; one press shows them, with Copy. */}
      {d.outcome === "approved" && d.fields.length && !d.goneInLedger ? (
        <Disclosure summary="Fields to enter" className="bankrec-fields-fold">
          <div className="bankrec-fields-wrap">
            <dl className="bankrec-fields" aria-label={`The fields to enter in ${say.ledger}`}>
              {d.fields.map((f) => (
                <div key={f.label}>
                  <dt>{f.label}</dt>
                  <dd className={f.amountCents != null ? "num" : undefined}>{f.amountCents != null ? formatMoney(f.amountCents) : f.value}</dd>
                </div>
              ))}
            </dl>
            <Button size="sm" variant="quiet" onClick={copy}>
              {copied ? "Copied" : "Copy the fields"}
            </Button>
          </div>
        </Disclosure>
      ) : null}
      {/* Nothing to OK in the ledger once what it made is gone there (W4-2). */}
      {d.state === "settled" && d.ledgerLink && !d.goneInLedger ? (
        <a className="link bankrec-decision-link" href={d.ledgerLink} target="_blank" rel="noopener noreferrer">
          OK it in {say.ledger}
        </a>
      ) : null}
    </div>
  );
}

/** One press for every high-confidence coding this section can approve now. */
function BulkApprove({ rows, say }) {
  const writes = useWritesEnabled();
  const [busy, setBusy] = useState(false);
  const [said, setSaid] = useState(null);
  const [confirming, setConfirming] = useState(() => Boolean(say.confirming && say.confirming.bulk));
  const ids = highConfidenceIds({ rows });
  if (say.readOnly || (!ids.length && !said)) return null;
  const named = (actionId) => {
    const row = rows.find((r) => r.decision && r.decision.id === actionId);
    return (row && row.bank && row.bank.description) || "A line";
  };
  const press = async () => {
    setConfirming(false);
    setBusy(true);
    const result = await approveHighConfidenceCodings(ids).catch(() => LOST_PRESS);
    setBusy(false);
    if (!result || !result.ok) {
      setSaid({ ok: false, words: (result && result.message) || LOST_PRESS.message, skipped: [] });
      return;
    }
    for (const a of result.approved) {
      const row = rows.find((r) => r.decision && r.decision.id === a.actionId);
      const next = decisionOf(a.decision);
      if (row && next) say.onDecided(row.id, next);
    }
    setSaid({ ok: true, words: result.words, skipped: result.skipped.map((s) => ({ id: s.actionId, line: named(s.actionId), reason: s.reason })) });
  };
  return (
    <div className="bankrec-bulk" data-bankrec-bulk="">
      {ids.length ? (
        <Button size="sm" variant="secondary" busy={busy} busyLabel="Approving…" disabledReason={writes ? undefined : SAMPLE_REASON} onClick={() => setConfirming(true)}>
          Approve {ids.length} high-confidence
        </Button>
      ) : null}
      <WriteConfirm
        open={confirming && ids.length > 0}
        question={ids.length ? bulkWriteQuestion({ count: ids.length, ledger: say.ledger, account: say.account }) : null}
        ledger={say.ledger}
        busy={busy}
        reason={writes ? undefined : SAMPLE_REASON}
        onCancel={() => setConfirming(false)}
        onConfirm={press}
      >
        <ul className="bankrec-confirm-lines t-footnote">
          {ids.map((id) => {
            const row = rows.find((r) => r.decision && r.decision.id === id);
            const coding = row && ((row.decision && row.decision.coding) || row.proposal);
            return (
              <li key={id}>
                {named(id)}
                {row && row.bank ? <span className="num">{` · ${formatMoney(row.bank.amountCents)}`}</span> : null}
                {coding && coding.accountCode ? ` → ${[coding.accountCode, coding.accountName].filter(Boolean).join(" ")}` : null}
              </li>
            );
          })}
        </ul>
      </WriteConfirm>
      {said ? (
        <div className="bankrec-bulk-said" role={said.ok ? "status" : "alert"}>
          {said.words ? <p>{say(said.words)}</p> : null}
          {said.skipped.length ? (
            <ul>
              {said.skipped.map((s) => (
                <li key={s.id}>
                  {s.line}: {say(s.reason)}
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

// ─────────────────────────── a receipt on the line ───────────────────────────

/**
 * The receipts filed against this bank line, and "Attach receipt": upload a file or pick
 * one Vert holds, filed against the line (lib/documents.js attachToBankLine). Kept in
 * Vert, and said so. A disclosure, so the row's own presses stay the only buttons until
 * it is opened; Vert's files are read (a GET) only once it is.
 */
function RowReceipts({ row, say }) {
  const [added, setAdded] = useState([]);
  const [open, setOpen] = useState(false);
  const held = Array.isArray(row.receipts) ? row.receipts : [];
  const receipts = [...held, ...added.filter((a) => !held.some((r) => r.documentId === a.documentId))];
  const canAttach = Boolean(row.bank) && !say.readOnly;
  if (!receipts.length && !canAttach) return null;
  const kept = `Kept in Vert. Not attached in ${say.ledger} yet: Vert doesn’t write bank transactions to ${say.ledger} until that permission is granted.`;
  return (
    <div className="bankrec-receipts" data-receipts={receipts.length}>
      {receipts.length ? (
        <>
          <p className="bankrec-prop-meta">
            {receipts.length === 1 ? "Receipt: " : "Receipts: "}
            {receipts.map((r, i) => (
              <span key={r.documentId}>
                {i ? ", " : ""}
                <a className="link" href={fileHref(r.documentId)} target="_blank" rel="noopener noreferrer">
                  {r.name}
                </a>
              </span>
            ))}
          </p>
          <p className="bankrec-prop-basis">{kept}</p>
        </>
      ) : null}
      {canAttach ? (
        <details className="bankrec-attach" onToggle={(e) => setOpen(e.currentTarget.open)}>
          <summary className="link">Attach receipt</summary>
          {open ? <AttachReceipt row={row} kept={kept} onAttached={(doc) => setAdded((now) => [...now, doc])} /> : null}
        </details>
      ) : null}
    </div>
  );
}

function AttachReceipt({ row, kept, onAttached }) {
  const writes = useWritesEnabled();
  const pathname = usePathname();
  const [files, setFiles] = useState({ items: [], note: null });
  const [picked, setPicked] = useState("");
  const [state, setState] = useState({ busy: false, said: null, error: null });
  useEffect(() => {
    let live = true;
    // A GET, once the person opened this: the files Vert already holds.
    fetch("/api/documents", { cache: "no-store" })
      .then((r) => r.json().catch(() => null))
      .then((body) => {
        if (!live) return;
        const items = body && body.ok && Array.isArray(body.items) ? body.items.map(documentChip).filter(Boolean) : null;
        setFiles(items ? { items, note: null } : { items: [], note: "Vert couldn’t list its files just now. Upload the receipt instead." });
      })
      .catch(() => live && setFiles({ items: [], note: "Vert couldn’t list its files just now. Upload the receipt instead." }));
    return () => {
      live = false;
    };
  }, []);
  const link = async (doc) => {
    const result = await callSafely(attachToBankLine, doc.documentId, row.id);
    if (!result || !result.ok) return setState({ busy: false, said: null, error: (result && result.message) || "Not attached. Nothing was changed." });
    onAttached({ documentId: doc.documentId, name: doc.name });
    setState({ busy: false, said: `Attached ${doc.name}.`, error: null });
  };
  const upload = async (file) => {
    if (!file) return;
    setState({ busy: true, said: null, error: null });
    const up = await uploadFile(file, { session: sessionFromPath(pathname) });
    if (!up.ok) return setState({ busy: false, said: null, error: up.message });
    await link(up.chip);
  };
  const pick = async () => {
    const doc = files.items.find((f) => f.documentId === picked);
    if (!doc) return;
    setState({ busy: true, said: null, error: null });
    await link(doc);
  };
  const reason = writes ? undefined : SAMPLE_REASON;
  return (
    <div className="bankrec-attach-panel">
      <label className="bankrec-prop-meta">
        Upload a file{" "}
        <input type="file" accept={DOCUMENT_ACCEPT} disabled={state.busy || !writes} onChange={(e) => { const f = e.target.files && e.target.files[0]; e.target.value = ""; upload(f); }} />
      </label>
      {files.items.length ? (
        <div className="bankrec-decision-actions">
          <SelectField label="Or pick a file Vert holds" value={picked} placeholder="Pick a file" options={files.items.map((f) => ({ value: f.documentId, label: f.name }))} onChange={(e) => setPicked(e.target.value)} />
          <Button size="sm" variant="secondary" busy={state.busy} busyLabel="Attaching…" disabledReason={reason || (picked ? undefined : "Pick a file first.")} onClick={pick}>
            Attach
          </Button>
        </div>
      ) : files.note ? (
        <p className="bankrec-prop-basis">{files.note}</p>
      ) : null}
      {reason ? <p className="bankrec-prop-basis">{reason}</p> : null}
      <p className="bankrec-prop-basis">{kept}</p>
      {state.said ? <p className="bankrec-prop-meta" role="status">{state.said}</p> : null}
      {state.error ? <p className="bankrec-decision-error" role="alert">{state.error}</p> : null}
    </div>
  );
}

function cap(s) {
  return typeof s === "string" && s ? s[0].toUpperCase() + s.slice(1) : "";
}

export { toneOf };
