// components/chat/answer/cash-coding.js — "CASH CODE" IN THE CHAT, READ FROM THE ENGINE
// ==============================================================================
// The co-founder asked Vert to "cash code" and got a bank reconciliation (3 Nov 2026).
// The engine now answers by reading its GET /cash-coding for the month and sends the
// first lines to code on the answer's shape as `cashCoding` (w25 contract v2 §4,
// agent_events.ShapeCashCoding): at most 5 rows, the count of all of them, the
// account, and the view's address. The answer's one action opens the view
// (/reconciliation/bank/cash-coding), where the lines are coded.
//
// Everything here is a lookup: amounts are the engine's integer cents, never summed. A
// block that doesn't read as the contract says is dropped whole (null).
//
// It imports nothing: components/chat/answer/shape.js reads `shape` through it.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const PERIOD = /^\d{4}-\d{2}$/;
const cents = (v) => (v === null || v === undefined ? null : Number.isInteger(v) && v >= 0 ? v : undefined);

function rowOf(raw) {
  if (!isObj(raw) || !text(raw.id)) return null;
  const spentCents = cents(raw.spentCents);
  const receivedCents = cents(raw.receivedCents);
  if (spentCents === undefined || receivedCents === undefined) return null;
  if ((spentCents === null) === (receivedCents === null)) return null;
  return {
    id: raw.id,
    date: text(raw.date),
    payee: text(raw.payee),
    description: text(raw.description),
    account: text(raw.account),
    taxRate: text(raw.taxRate),
    spentCents,
    receivedCents,
  };
}

// w26 CC-5: with several accounts holding lines and none named, `accounts` is a table of
// each account's count and money, in the engine's order (most lines first), and the
// block's own `toCode` / `spentCents` / `receivedCents` are its totals (the engine
// refuses a block whose totals aren't its rows' sum, so nothing is summed or checked
// here). A row that doesn't read drops the block, as a line row does.
const count = (v) => (Number.isInteger(v) && v >= 0 ? v : null);

function accountOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !text(raw.label)) return null;
  const toCode = count(raw.toCode);
  const spentCents = count(raw.spentCents);
  const receivedCents = count(raw.receivedCents);
  if (toCode === null || spentCents === null || receivedCents === null) return null;
  return { id: raw.id, label: text(raw.label), toCode, spentCents, receivedCents, href: text(raw.href) };
}

/** The engine's `shape.cashCoding`, checked, or null. Pure. */
export function cashCodingShapeOf(raw) {
  if (!isObj(raw) || !Array.isArray(raw.rows)) return null;
  const rows = raw.rows.map(rowOf);
  if (rows.some((r) => !r)) return null;
  if (raw.accounts !== undefined && raw.accounts !== null && !Array.isArray(raw.accounts)) return null;
  const accounts = (raw.accounts || []).map(accountOf);
  if (accounts.some((a) => !a)) return null;
  const toCode = count(raw.toCode);
  const spentCents = count(raw.spentCents);
  const receivedCents = count(raw.receivedCents);
  const shown = Number.isInteger(raw.shown) ? raw.shown : rows.length;
  const of = Number.isInteger(raw.of) ? raw.of : shown;
  return {
    period: PERIOD.test(String(raw.period || "")) ? raw.period : null,
    account: text(raw.account),
    // The account the engine read (CashCodingPanel opens the grid on it); absent on a
    // several-accounts answer, whose `accounts` name them.
    accountId: text(raw.accountId),
    rows,
    shown,
    // Kept, so reading a read block again (shape.js, then CashCodingLines) says the same.
    of,
    more: of > shown ? of - shown : 0,
    words: text(raw.words),
    accounts,
    toCode,
    spentCents,
    receivedCents,
    // The accounts table's total row: the engine's own totals, only when it gave all three.
    total: accounts.length && toCode !== null && spentCents !== null && receivedCents !== null ? { toCode, spentCents, receivedCents } : null,
  };
}
