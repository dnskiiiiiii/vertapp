"use client";

// components/chat/answer/SupplierStatementRec.js — A SUPPLIER'S STATEMENT AGAINST THE LEDGER, AS DRAWN
// ==============================================================================
// Function-fidelity audit row 21 (w49, 4 Nov 2026). Under the verdict ("Harbour
// Freight's statement shows $4,812.50 and … $736.25: they differ by $4,076.25"):
//
//   1. the tie line — "Ties" (with a check) only on the engine's tied: true, else
//      "Differs by $X", with the two closing balances beside it and the engine's words;
//   2. the differences, grouped as the engine groups them (statement only, ledger
//      only, amounts differ), each row Date, Reference, what it is and why, Amount, and
//      a link where one exists: the ledger's own page for a record it has, the bill
//      inbox for a bill it doesn't;
//   3. how many of the statement's lines matched.
//
// Nothing here writes: a missing bill's one road is the bill inbox, where a person
// enters and approves it. An unread side is its words alone, never $0. Every amount is
// the engine's integer (supplier-statement.js); nothing is summed here.

import "@/components/reports/reports.css";
import { useState } from "react";
import InboxSheet from "@/components/bills/InboxSheet";
import { formatDate } from "@/lib/format";
import { IconCheck, IconExternal } from "@/components/ui/icons";
import { moneyIn } from "./aging-money";
import { matchedLine, rowAmount, shownGroups, supplierStatementRecOf, tieLine } from "./supplier-statement";

const day = (d) => (d ? formatDate(d) : "");

export default function SupplierStatementRec({ supplierStatementRec, ledgerName = null }) {
  const rec = supplierStatementRecOf(supplierStatementRec);
  if (!rec) return null;
  const ledger = ledgerName || "the ledger";
  const money = (c) => (c == null ? "" : moneyIn(c, rec.currency, { style: "table" }));
  const tie = tieLine(rec, money);
  const matched = matchedLine(rec);
  const groups = shownGroups(rec);
  const state = rec.tie.tied === true ? "tied" : rec.tie.tied === false ? "differs" : "unchecked";
  return (
    <section className="rpt ssr" data-supplier-rec="" data-tie={state} aria-label="Supplier statement reconciliation">
      <header className="rpt-head">
        <h4 className="rpt-title">Supplier statement</h4>
        <span className="rpt-sub">
          {rec.contactName ? `${rec.contactName}, as at ` : "As at "}
          {day(rec.asAt)}
        </span>
      </header>
      {!rec.statement.read ? (
        <p className="rpt-unread" data-rpt-unread="statement">
          {rec.statement.words}
        </p>
      ) : (
        <>
          <div className="ssr-tie" data-ssr-tie={state}>
            {tie ? (
              <p className="ssr-tie-line">
                {rec.tie.tied ? <IconCheck className="ssr-tie-glyph" size={14} aria-hidden="true" /> : null}
                <span>{tie}</span>
              </p>
            ) : null}
            <dl className="ssr-balances">
              <div data-ssr-closing="statement">
                <dt>Statement</dt>
                <dd className="num">{money(rec.statement.closing) || "Not found"}</dd>
              </div>
              <div data-ssr-closing="ledger">
                <dt>In {ledger}</dt>
                <dd className="num">{rec.ledger.read ? money(rec.ledger.balance) : "Not read"}</dd>
              </div>
            </dl>
            <p className="rpt-words" data-ssr-tie-words="">
              {rec.tie.words}
            </p>
          </div>
          {groups.length ? <Differences groups={groups} money={money} ledger={ledger} /> : null}
          {matched ? (
            <p className="rpt-sub" data-ssr-matched={rec.matched}>
              {matched}
            </p>
          ) : null}
          {rec.statement.words ? <p className="rpt-note">{rec.statement.words}</p> : null}
          {rec.words ? <p className="rpt-note">{rec.words}</p> : null}
        </>
      )}
    </section>
  );
}

function Differences({ groups, money, ledger }) {
  // A missing bill is entered beside the chat, in Bills & invoices (founder, 8 Nov 2026),
  // not on Scheduled's page.
  const [inbox, setInbox] = useState(false);
  return (
    <div className="rpt-table-wrap">
      <table className="rpt-table ssr-rows">
        <caption className="sr-only">Differences between the statement and {ledger}</caption>
        <thead>
          <tr>
            <th scope="col">Date</th>
            <th scope="col" className="rpt-ref">Reference</th>
            <th scope="col">Item</th>
            <th scope="col" className="num">Amount</th>
            <th scope="col">
              <span className="sr-only">Link</span>
            </th>
          </tr>
        </thead>
        {groups.map((g) => (
          <tbody key={g.key} data-ssr-group={g.key} data-rows={g.rowCount}>
            <tr className="rpt-section">
              <th scope="colgroup" colSpan={5}>
                {g.label}
              </th>
            </tr>
            {g.rows.map((r, i) => (
              <tr key={`${g.key}:${r.reference || r.label}:${i}`} data-ssr-row={r.kind}>
                <td className="rpt-date">{day(r.date)}</td>
                <td className="rpt-ref">{r.reference || ""}</td>
                <td className="rpt-desc">
                  <span className="ssr-label">{r.label}</span>
                  <span className="ssr-why">{r.why}</span>
                  {g.key === "amount_differs" && r.statement !== null && r.ledger !== null ? (
                    <span className="ssr-why" data-ssr-sides="">
                      Statement {money(r.statement)}, {ledger} {money(r.ledger)}
                    </span>
                  ) : null}
                </td>
                <td className="num">{money(rowAmount(r, g.key))}</td>
                <td className="ssr-link">
                  {r.enterBill ? (
                    <button type="button" className="link bill-row-open" aria-haspopup="dialog" onClick={() => setInbox(true)} data-ssr-enter-bill="">
                      Enter bill
                    </button>
                  ) : r.url ? (
                    <a className="link" href={r.url} target="_blank" rel="noreferrer" data-ssr-open="">
                      <span>Open in {ledger}</span>
                      <IconExternal size={12} aria-hidden="true" />
                    </a>
                  ) : null}
                </td>
              </tr>
            ))}
            {g.more ? (
              <tr className="rpt-more" data-ssr-more={g.more}>
                <td colSpan={5}>{g.more === 1 ? "1 more" : `${g.more} more`} not shown</td>
              </tr>
            ) : null}
          </tbody>
        ))}
      </table>
      {inbox ? <InboxSheet onClose={() => setInbox(false)} /> : null}
    </div>
  );
}
