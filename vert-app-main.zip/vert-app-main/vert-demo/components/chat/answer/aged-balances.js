// components/chat/answer/aged-balances.js — WHO OWES, WHO IS OWED, READ FROM THE ENGINE
// ==============================================================================
// W3 feature 1 (28 Oct 2026): "aged receivables and payables". The engine reads the
// ledger's open invoices and bills, ages them as at a date and sends the result on the
// answer's shape as `agedBalances`: a LIST of one or two sides, receivables first. Each
// side is per currency, with the six buckets (Current, 1–30, 31–60, 61–90, Over 90,
// Unapplied credit), the contacts that owe the most overdue and the most overdue
// documents (contract: W3 aging, `shape.agedBalances`).
//
// Everything here is a lookup. Every total, bucket, count and days-overdue is the
// engine's integer (tests/no-arithmetic.test.js): nothing is summed across buckets,
// contacts or currencies. A side that doesn't read as the contract says is dropped whole
// (null), never half-drawn: a table whose rows don't add to its totals row is worse than
// no table. A side the engine did not read (`measured: false`) keeps the engine's words
// and carries no figure, so it can never be drawn as $0.
//
// It imports nothing: components/chat/answer/shape.js reads `shape` through it, and
// lib/agent/events.js reads shape.js.

/** The six buckets, in the contract's order. */
export const BUCKET_KEYS = Object.freeze(["current", "d1_30", "d31_60", "d61_90", "d90_plus", "credit"]);
const OVERDUE = new Set(["d1_30", "d31_60", "d61_90", "d90_plus"]);
const SIDES = new Set(["receivables", "payables"]);

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const isInt = (v) => Number.isInteger(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;
const day = (v) => (typeof v === "string" && ISO_DAY.test(v) ? v : null);
/** A link out is only ever a secure one; the engine names the ledger's own screen. */
const LINK = /^https:\/\//;
const link = (v) => (typeof v === "string" && LINK.test(v) ? v : null);

/** Whether a bucket is past due (1–30 and older). Current and credit never are. Pure. */
export function isOverdueBucket(key) {
  return OVERDUE.has(key);
}

function bucketsOf(raw) {
  if (!Array.isArray(raw) || raw.length !== BUCKET_KEYS.length) return null;
  const out = [];
  for (let i = 0; i < BUCKET_KEYS.length; i += 1) {
    const b = raw[i];
    if (!isObj(b) || b.key !== BUCKET_KEYS[i] || !text(b.label) || !isInt(b.cents)) return null;
    out.push({ key: b.key, label: text(b.label), cents: b.cents, overdue: isOverdueBucket(b.key) });
  }
  return out;
}

function contactBucketsOf(raw) {
  if (!isObj(raw)) return null;
  const out = {};
  for (const key of BUCKET_KEYS) {
    if (!isInt(raw[key])) return null;
    out[key] = raw[key];
  }
  return out;
}

function contactOf(raw) {
  if (!isObj(raw) || !text(raw.name) || !isInt(raw.totalCents) || !isInt(raw.overdueCents)) return null;
  const buckets = contactBucketsOf(raw.buckets);
  if (!buckets) return null;
  return {
    contactId: text(raw.contactId),
    name: text(raw.name),
    totalCents: raw.totalCents,
    overdueCents: raw.overdueCents,
    oldestDaysOverdue: isInt(raw.oldestDaysOverdue) ? raw.oldestDaysOverdue : null,
    buckets,
  };
}

function overdueDocOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !day(raw.dueDate) || !isInt(raw.daysOverdue) || !isInt(raw.amountDueCents)) return null;
  return {
    id: text(raw.id),
    number: text(raw.number),
    contactName: text(raw.contactName),
    dueDate: raw.dueDate,
    daysOverdue: raw.daysOverdue,
    amountDueCents: raw.amountDueCents,
    bucket: BUCKET_KEYS.includes(raw.bucket) ? raw.bucket : null,
    url: link(raw.url),
  };
}

/** Every element read, or null when any one doesn't: a list is drawn whole or not at all. */
function allOf(raw, read) {
  if (!Array.isArray(raw)) return null;
  const out = raw.map(read);
  return out.some((x) => !x) ? null : out;
}

function currencyOf(raw) {
  if (!isObj(raw) || !text(raw.currency)) return null;
  for (const k of ["totalCents", "overdueCents", "overdueCount", "documentCount"]) if (!isInt(raw[k])) return null;
  const buckets = bucketsOf(raw.buckets);
  const contacts = allOf(raw.contacts, contactOf);
  const topOverdue = allOf(raw.topOverdue, overdueDocOf);
  if (!buckets || !contacts || !topOverdue) return null;
  return {
    currency: text(raw.currency),
    totalCents: raw.totalCents,
    overdueCents: raw.overdueCents,
    overdueCount: raw.overdueCount,
    documentCount: raw.documentCount,
    // The invoices (bills) alone, credit notes left out (w18 contract, walk 4 W4-7): the
    // count the lead says. Null on an answer stored before it.
    invoiceCount: isInt(raw.invoiceCount) ? raw.invoiceCount : null,
    buckets,
    contacts,
    moreContacts: isInt(raw.moreContacts) && raw.moreContacts > 0 ? raw.moreContacts : 0,
    topOverdue,
  };
}

function actionOf(raw, side) {
  if (side !== "receivables" || !isObj(raw) || raw.kind !== "draft_reminders" || !text(raw.label)) return null;
  return { kind: "draft_reminders", label: text(raw.label), asAt: day(raw.asAt) };
}

/** One side of `shape.agedBalances`, checked and normalised, or null. Pure. */
export function agedSideOf(raw) {
  if (!isObj(raw) || !SIDES.has(raw.side) || !text(raw.title) || typeof raw.measured !== "boolean") return null;
  const base = { side: raw.side, title: text(raw.title), asAt: day(raw.asAt), measured: raw.measured, words: text(raw.words) };
  if (!raw.measured) {
    // NOT READ IS WORDS, NEVER $0 (memory: an unread zero is not a measured zero). With
    // no words there is nothing true to draw, so the side is dropped.
    if (!base.words) return null;
    return { ...base, currencies: [], action: null };
  }
  const currencies = allOf(raw.currencies, currencyOf);
  if (!currencies) return null;
  return { ...base, currencies, action: actionOf(raw.action, raw.side) };
}

/** `shape.agedBalances`: the sides that read, in the engine's order, or null. Pure. */
export function agedBalancesOf(raw) {
  if (!Array.isArray(raw)) return null;
  const sides = raw.map(agedSideOf).filter(Boolean);
  return sides.length ? sides : null;
}

/**
 * The sentence under a side held in more than one currency: they are separate blocks,
 * and nothing adds them together. Null for one currency. Pure.
 */
export function currenciesWords(currencies) {
  const codes = (Array.isArray(currencies) ? currencies : []).map((c) => c && c.currency).filter(Boolean);
  if (codes.length < 2) return null;
  const named = codes.length === 2 ? `${codes[0]} and ${codes[1]}` : `${codes.slice(0, -1).join(", ")} and ${codes[codes.length - 1]}`;
  return `Held in ${named}: each currency is shown on its own and they are not added together.`;
}
