"use client";

// components/chat/answer/SentReminders.js — WHAT PAYMENT REMINDERS WENT, AND HOW
// ==============================================================================
// Contract v2 (28 Oct 2026). The engine keeps every reminder send (GET /reminders/sends);
// this draws them newest first: when, which customer, to whom, and the status in words.
// "May have been sent" is the engine's `unknown` (the mail server took part of it and
// didn't confirm), never "sent" and never "not sent"; "Being sent" is one in flight. A
// recipient that wasn't the ledger's, or an edited message, is said on the row. This is
// the list every "check Sent reminders" sentence points at. It reads nothing itself: the
// rows are handed in (the Connections page reads them on the server; the drafts read
// them from a press).

import "./aging.css";
import { formatDate, formatTime } from "@/lib/format";
import { sendChanges, sendStatusWords, sendTone, sendsOf } from "./reminders";

export const SENT_REMINDERS_ID = "sent-reminders";

export default function SentReminders({ sends, ledgerName = null, id = SENT_REMINDERS_ID, words = null }) {
  const rows = sendsOf(sends);
  const ledger = ledgerName || "your ledger";
  return (
    <section className="sent-reminders" id={id} data-sent-reminders="" aria-labelledby={`${id}-title`}>
      <p className="shape-label" id={`${id}-title`}>
        Sent reminders
      </p>
      {rows === null ? (
        <p className="aging-words">{words || "Vert couldn't list the sent reminders just now."}</p>
      ) : !rows.length ? (
        <p className="aging-words">No reminders have been sent for this client yet.</p>
      ) : (
        <ul className="sent-list">
          {rows.map((s) => {
            const changes = sendChanges(s, ledger);
            return (
              <li key={s.sendId} className="sent-row" data-send-status={s.status}>
                <span className="sent-when">{s.sentAt ? `${formatDate(s.sentAt)}, ${formatTime(s.sentAt)}` : "Time not recorded"}</span>
                <span className="sent-who">
                  <span className="sent-name">{s.contactName || "A customer"}</span>
                  {s.to ? <span className="sent-to"> to {s.to}</span> : null}
                </span>
                <span className="reminder-result" data-tone={sendTone(s)}>
                  <span className="reminder-dot" aria-hidden="true" />
                  {sendStatusWords(s)}
                </span>
                {changes.length || s.words ? (
                  <span className="sent-notes">
                    {[...changes, s.words].filter(Boolean).join("; ")}
                  </span>
                ) : null}
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}
