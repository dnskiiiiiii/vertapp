// components/chat/answer/small-balances.js — THE CENTS LEFT AFTER A PAYMENT, READ FROM THE ENGINE
// ==============================================================================
// w47 (audit row 19, 4 Nov 2026). "Write off the small balances in AR" / "clear the cents
// left on the bills": the engine answers with `shape.smallBalances`
// (vert_engine/agent_events.py ShapeSmallBalances): each part-paid invoice and bill with
// less than the limit left, the account they'd be cleared to (one proposed, or a choice),
// the GST rate each goes out at and why, and whether they can be cleared from here.
// SmallBalances.js draws it, with a tick per row and one press.
//
// Everything here is a lookup: amounts are the engine's integer cents, never summed or
// subtracted. A block that doesn't read as the contract says is dropped whole (null). An
// unread read (`measured: false`) keeps its words and nothing else: never "none left".
//
// It imports nothing: components/chat/answer/shape.js reads `shape` through it.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const count = (v) => (Number.isInteger(v) && v >= 0 ? v : null);
const DAY = /^\d{4}-\d{2}-\d{2}$/;
const SIDES = new Set(["receivables", "payables"]);
const KINDS = new Set(["invoice", "bill"]);
const CHOICES = new Set(["one", "several", "none", "unread"]);
/** The most one press clears (the engine's MAX_BATCH). */
export const MAX_CLEARED = 50;

function rowOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !SIDES.has(raw.side) || !KINDS.has(raw.kind) || !text(raw.statusWords)) return null;
  if (!Number.isInteger(raw.totalCents) || !Number.isInteger(raw.amountDueCents) || raw.amountDueCents <= 0) return null;
  // A small balance is what is LEFT after a payment: the engine says so, and a row that
  // doesn't is not drawn as one.
  if (raw.amountDueCents >= raw.totalCents) return null;
  const url = text(raw.url);
  return {
    id: raw.id,
    side: raw.side,
    kind: raw.kind,
    contact: text(raw.contact),
    number: text(raw.number),
    date: typeof raw.date === "string" && DAY.test(raw.date) ? raw.date : null,
    totalCents: raw.totalCents,
    amountDueCents: raw.amountDueCents,
    currency: text(raw.currency),
    url: url && url.startsWith("https://") ? url : null,
    ready: raw.ready === true,
    statusWords: text(raw.statusWords),
    taxWords: text(raw.taxWords),
  };
}

function accountOf(raw) {
  if (!isObj(raw) || !CHOICES.has(raw.choice) || !text(raw.words) || !Array.isArray(raw.options)) return null;
  const options = raw.options.map((o) => (isObj(o) && text(o.code) ? { code: text(o.code), name: typeof o.name === "string" ? o.name.trim() : "" } : null));
  if (options.some((o) => !o)) return null;
  const proposed = text(raw.proposed);
  if ((raw.choice === "one") !== Boolean(proposed)) return null;
  if (proposed && !options.some((o) => o.code === proposed)) return null;
  return { choice: raw.choice, proposed, options, words: text(raw.words) };
}

function sideOf(raw) {
  if (!isObj(raw) || !SIDES.has(raw.side) || typeof raw.measured !== "boolean" || count(raw.unpaid) === null) return null;
  return { side: raw.side, measured: raw.measured, words: text(raw.words), unpaid: raw.unpaid };
}

/** The engine's `shape.smallBalances`, checked, or null. Pure. */
export function smallBalancesShapeOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean" || !text(raw.words) || !Array.isArray(raw.rows) || !Array.isArray(raw.sides)) return null;
  if (!Number.isInteger(raw.limitCents) || raw.limitCents <= 0) return null;
  const rows = raw.rows.map(rowOf);
  const sides = raw.sides.map(sideOf);
  const account = accountOf(raw.account);
  if (rows.some((r) => !r) || sides.some((s) => !s) || !sides.length || !account) return null;
  const shown = count(raw.shown);
  const of = count(raw.of);
  if (shown === null || of === null || shown !== rows.length || of < shown) return null;
  if (!raw.measured && rows.length) return null;
  const canClear = raw.canClear === true && raw.measured;
  return {
    measured: raw.measured,
    words: text(raw.words),
    limitCents: raw.limitCents,
    sides,
    rows,
    shown,
    of,
    more: Math.max(0, of - shown),
    account,
    canClear,
    clearWords: text(raw.clearWords),
    // What a press sends (w44): "authorised" or "draft"; anything else unread.
    documentMode: raw.documentMode === "authorised" || raw.documentMode === "draft" ? raw.documentMode : null,
  };
}

/** The rows a press may clear: ready ones, at most MAX_CLEARED. Pure. */
export function clearableIds(view) {
  if (!view || !view.canClear) return [];
  return view.rows.filter((r) => r.ready).map((r) => r.id).slice(0, MAX_CLEARED);
}

/**
 * How the confirm says where the press sends them, the way the bill inbox's confirm does
 * (bill-inbox.js sendModeWords): "as draft credit notes", "approved, and allocated to each",
 * or nothing when the client's mode wasn't read (the engine then sends drafts, but the
 * words don't guess). Pure.
 */
export function creditModeWords(mode, n) {
  if (mode === "authorised") return n === 1 ? " approved, and allocated to it" : " approved, and allocated to each";
  if (mode === "draft") return n === 1 ? " as a draft credit note" : " as draft credit notes";
  return "";
}

/** "Clear 1 small balance", "Clear 3 small balances". Pure. */
export function clearLabel(n) {
  return `Clear ${n} small balance${n === 1 ? "" : "s"}`;
}

/** "Send 2 credit notes to your ledger as draft credit notes?": the press's question, naming what it sends. Pure. */
export function confirmWords(n, mode, ledger = "your ledger") {
  return `Send ${n} credit note${n === 1 ? "" : "s"} to ${ledger}${creditModeWords(mode, n)}?`;
}

/** `POST /write-offs/small-balances`'s items for the ticked rows: each one's id and what it showed due. Pure. */
export function itemsFor(view, ids) {
  if (!view) return [];
  const wanted = new Set(ids || []);
  return view.rows.filter((r) => wanted.has(r.id) && r.ready).map((r) => ({ invoiceId: r.id, amountCents: r.amountDueCents }));
}

/** "Customer" or "Supplier", for a row's side. Pure. */
export function partyWord(side) {
  return side === "payables" ? "Supplier" : "Customer";
}
