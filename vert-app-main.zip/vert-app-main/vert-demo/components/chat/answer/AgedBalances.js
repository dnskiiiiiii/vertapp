"use client";

// components/chat/answer/AgedBalances.js — WHO OWES YOU, WHO YOU OWE, AND HOW LATE
// ==============================================================================
// W3 feature 1 (28 Oct 2026). Under the verdict, one block per side (receivables, then
// payables), each in the order an aged report reads:
//
//   1. the summary, per currency: what is owed, what of it is overdue, and how many
//      invoices (or bills) are overdue;
//   2. the bucket table by contact: Current, 1–30, 31–60, 61–90, Over 90, Unapplied
//      credit, Total, with the engine's totals row under it (contacts left out are
//      counted under the table, so its rows needn't add to the totals);
//   3. the most overdue documents, each with its number, due date, days overdue, amount
//      due and a link into the ledger;
//   4. on receivables with overdue invoices, one press: Draft reminders, whose drafts
//      (ReminderDrafts.js) are drawn inline under the card. Drafting sends nothing.
//   5. on receivables, each of the most overdue invoices carries "Write off" (W4, 29 Oct
//      2026; WriteOff.js): a bad debt drafted as a credit note, approved by a second
//      person, created in the ledger as a draft. `initial.writeOffs[invoiceId]` hands a
//      pressed state in for the server-rendered tests.
//
// SHOW THE WORK INLINE (answer-shape reference, 17 Oct 2026). Every figure is the
// engine's (aged-balances.js); nothing is summed here, not across buckets, contacts or
// currencies. Two currencies are two blocks and a sentence saying they are not added
// together. A side the engine did not read says the engine's words, never $0. An
// overdue cell carries the attention tone and its column says the age in words, so the
// colour only repeats what the heading already says.

import "./aging.css";
import { useState } from "react";
import { Button } from "@/components/ui";
import { formatDate } from "@/lib/format";
import { useWritesEnabled } from "@/lib/engine-context";
import { requestDrafts } from "@/lib/reminders-client";
import { agedBalancesOf, currenciesWords } from "./aged-balances";
import { moneyIn } from "./aging-money";
import ReminderDrafts from "./ReminderDrafts";
import { WriteOffAction } from "./WriteOff";

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const DOC = { receivables: ["invoice", "invoices", "Invoices"], payables: ["bill", "bills", "Bills"] };
const OWED = { receivables: "Owed to you", payables: "You owe" };
const SAMPLE_DRAFT_REASON = "These are the sample books, so no reminders can be drafted here.";

export default function AgedBalances({ agedBalances, ledgerName = null, initial = null }) {
  const sides = agedBalancesOf(agedBalances);
  if (!sides) return null;
  const ledger = ledgerName || "your ledger";
  return (
    <section className="aging" data-aged-balances="" aria-label="Aged balances">
      {sides.map((side) => (
        <AgedSide key={side.side} side={side} ledger={ledger} initial={side.side === "receivables" ? initial : null} />
      ))}
    </section>
  );
}

function AgedSide({ side, ledger, initial }) {
  // The engine already says several currencies aren't added together; said once.
  const note = side.words && /not added together/i.test(side.words) ? null : currenciesWords(side.currencies);
  return (
    <section className="aging-side" data-aged-side={side.side} data-measured={side.measured ? "read" : "unread"}>
      <header className="aging-side-head">
        <h4 className="aging-title">{side.title}</h4>
        {side.asAt ? <span className="aging-asat">as at {formatDate(side.asAt)}</span> : null}
      </header>
      {!side.measured ? (
        <p className="aging-unread" data-aged-unread="">
          {side.words}
        </p>
      ) : (
        <>
          {side.words ? <p className="aging-words">{side.words}</p> : null}
          {note ? <p className="aging-words" data-aged-currencies="">{note}</p> : null}
          {/* WHO TO CHASE, FIRST (founder, 8 Nov 2026): the one press this answer exists
              for sits under the headline, not after every table and invoice. */}
          {side.action ? <DraftReminders action={side.action} asAt={side.asAt} ledger={ledger} initial={initial} /> : null}
          {side.currencies.length ? (
            side.currencies.map((c) => <CurrencyBlock key={c.currency} side={side.side} c={c} ledger={ledger} multi={side.currencies.length > 1} writeOffs={initial && initial.writeOffs} />)
          ) : (
            <p className="aging-words">{side.side === "receivables" ? "Nobody owes you anything as at this date." : "You owe nothing as at this date."}</p>
          )}
        </>
      )}
    </section>
  );
}

/** How many of the most overdue are listed before "Show N more". */
const OVERDUE_SHOWN = 5;

function CurrencyBlock({ side, c, ledger, multi, writeOffs = null }) {
  const money = (cents, options) => moneyIn(cents, c.currency, options);
  const [one, many, heading] = DOC[side];
  // A COLUMN OF $0.00 SAYS NOTHING (founder, 8 Nov 2026): an ageing bucket that is zero
  // in its total and for every contact isn't drawn. Read off the engine's figures, never
  // added up here.
  const buckets = c.buckets.filter((b) => b.cents !== 0 || c.contacts.some((p) => p.buckets[b.key] !== 0));
  const [allOverdue, setAllOverdue] = useState(false);
  const overdue = allOverdue ? c.topOverdue : c.topOverdue.slice(0, OVERDUE_SHOWN);
  const credit = c.buckets.find((b) => b.key === "credit") || null;
  return (
    <div className="aging-currency" data-currency={c.currency}>
      <dl className="aging-summary">
        <div>
          <dt>
            {OWED[side]}
            {multi ? ` in ${c.currency}` : ""}
          </dt>
          <dd className="num">{money(c.totalCents)}</dd>
        </div>
        <div data-tone={c.overdueCents !== 0 ? "attention" : undefined}>
          <dt>Overdue</dt>
          <dd className="num">{money(c.overdueCents)}</dd>
          {/* BEFORE UNAPPLIED CREDIT (production walk, 8 Nov 2026, D30): overdue counts the
              invoices before it and the total after it, so overdue could read larger than
              what's owed. The credit is the engine's own bucket, shown, never subtracted. */}
          {credit && credit.cents !== 0 ? <p className="aging-summary-note">Before unapplied credit ({money(credit.cents, { style: "table" }).replace(/[()]/g, "")})</p> : null}
        </div>
        <div>
          <dt>{heading}</dt>
          <dd>
            {/* Over the invoices alone (W4-7: "11 of 15" counted 2 credit notes). */}
            {c.overdueCount} of {plural(c.invoiceCount !== null && c.invoiceCount !== undefined ? c.invoiceCount : c.documentCount, one, many)} overdue
          </dd>
        </div>
      </dl>
      <div className="shape-table-wrap aging-table-wrap">
        <table className="shape-table aging-table" data-cols={buckets.length + 2}>
          <caption className="sr-only">
            {`${OWED[side]} by contact, in ${c.currency}, by how overdue`}
          </caption>
          <thead>
            <tr>
              <th scope="col">Contact</th>
              {buckets.map((b) => (
                <th key={b.key} scope="col" className="num" data-bucket={b.key}>
                  {b.label}
                </th>
              ))}
              <th scope="col" className="num">
                Total
              </th>
            </tr>
          </thead>
          <tbody>
            {c.contacts.map((p, i) => (
              <tr key={p.contactId || `${p.name}-${i}`}>
                <th scope="row" className="aging-contact">
                  {p.name}
                </th>
                {buckets.map((b) => {
                  const cents = p.buckets[b.key];
                  const late = b.overdue && cents !== 0;
                  return (
                    // `data-label`: a phone stacks the row and prints it before the figure
                    // (app/styles/chat.css .shape-table; staging browser walk 1, D12).
                    <td key={b.key} className={cents === 0 ? "num aging-zero" : "num"} data-bucket={b.key} data-label={b.label} data-tone={late ? "attention" : undefined}>
                      {money(cents, { style: "table" })}
                    </td>
                  );
                })}
                <td className="num aging-rowtotal" data-label="Total">
                  {money(p.totalCents, { style: "table" })}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <th scope="row">Total</th>
              {buckets.map((b) => (
                <td key={b.key} className="num" data-bucket={b.key} data-label={b.label} data-tone={b.overdue && b.cents !== 0 ? "attention" : undefined}>
                  {money(b.cents, { style: "table" })}
                </td>
              ))}
              <td className="num" data-label="Total">
                {money(c.totalCents, { style: "table" })}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
      {c.moreContacts > 0 ? (
        <p className="shape-more">{plural(c.moreContacts, "more contact", "more contacts")} aren&rsquo;t listed; the totals row includes them.</p>
      ) : null}
      {c.topOverdue.length ? (
        <div className="aging-overdue" data-aged-overdue="">
          <p className="shape-label">Most overdue</p>
          <ul className="aging-overdue-list">
            {overdue.map((d) => (
              <li key={d.id} className="aging-doc">
                <span className="aging-doc-main">
                  {/* The number is the way into the ledger: one link, not a second button. */}
                  {d.url ? (
                    <a className="link aging-doc-number" href={d.url} target="_blank" rel="noopener noreferrer" aria-label={`${d.number || "Document"}, open in ${ledger}`}>
                      {d.number || (side === "payables" ? "Bill with no number" : "Invoice with no number")}
                    </a>
                  ) : (
                    <span className="aging-doc-number">{d.number || (side === "payables" ? "Bill with no number" : "Invoice with no number")}</span>
                  )}
                  {d.contactName ? <span className="aging-doc-contact"> · {d.contactName}</span> : null}
                </span>
                <span className="aging-doc-meta">
                  Due {formatDate(d.dueDate)} · <span data-tone="attention">{plural(d.daysOverdue, "day", "days")} overdue</span>
                </span>
                <span className="aging-doc-amount num">{money(d.amountDueCents)}</span>
                {side === "receivables" ? (
                  <div className="aging-doc-writeoff">
                    <WriteOffAction doc={d} currency={c.currency} ledger={ledger} initial={writeOffs ? writeOffs[d.id] || null : null} />
                  </div>
                ) : null}
              </li>
            ))}
          </ul>
          {c.topOverdue.length > OVERDUE_SHOWN ? (
            <button type="button" className="link aging-more" aria-expanded={allOverdue ? "true" : "false"} onClick={() => setAllOverdue((v) => !v)} data-aged-more="">
              {allOverdue ? "Show fewer" : `Show ${c.topOverdue.length - OVERDUE_SHOWN} more`}
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

/** The one press on receivables, and the drafts it brings back, inline under the card. */
function DraftReminders({ action, asAt, ledger, initial }) {
  const writes = useWritesEnabled();
  const [busy, setBusy] = useState(false);
  const [drafts, setDrafts] = useState(() => (initial && initial.drafts) || null);
  const [error, setError] = useState(() => (initial && initial.error) || null);
  const press = async () => {
    if (busy) return;
    setBusy(true);
    setError(null);
    const got = await requestDrafts(action.asAt || asAt);
    setBusy(false);
    if (got.ok && got.body && got.body.reminders) {
      setDrafts(got.body.reminders);
      return;
    }
    setError({ message: got.ok ? "Vert's drafts couldn't be read. Nothing was sent." : got.message, connect: Boolean(got.connect) });
  };
  return (
    <div className="aging-action">
      {drafts ? null : (
        <Button variant="secondary" size="sm" busy={busy} busyLabel="Drafting…" disabledReason={writes ? undefined : SAMPLE_DRAFT_REASON} onClick={press} data-draft-reminders="">
          {action.label}
        </Button>
      )}
      {error ? (
        <p className="aging-error" role="alert">
          {error.message}
          {error.connect ? (
            <>
              {" "}
              <a className="link" href="/connections">
                Connect email
              </a>
            </>
          ) : null}
        </p>
      ) : null}
      {drafts ? <ReminderDrafts reminders={drafts} ledgerName={ledger} /> : null}
    </div>
  );
}
