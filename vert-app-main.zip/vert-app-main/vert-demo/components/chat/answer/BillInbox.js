"use client";

// components/chat/answer/BillInbox.js — THE BILLS WAITING FOR REVIEW, IN THE ANSWER
// ==============================================================================
// Demo rehearsal D4 (3 Nov 2026). Under the verdict ("1 bill waiting for review: 1 ready
// to approve."): one row per waiting item (Contact, Date, Amount, Status), each linked to
// its review, then "and N more" and ONE press for the ready ones, "Approve 1 bill". The
// press asks once more ("Send 1 bill to Xero?"), as the inbox's own bulk approve does,
// then sends exactly the engine's `readyIds` to POST /api/bills/approve: a person's press.
// Each bill goes to Xero as the client's document mode says (a draft, or approved,
// awaiting payment: 4 Nov 2026), which this shape doesn't carry, so the question claims
// neither; what each approval did, from what Xero returned, is said under it.
// The answer's own action, "Open Bills & invoices", is drawn by NextAction.
//
// An unread inbox is its words alone: no table, no press, never an empty inbox. An unread
// total is words, never $0.00. Every amount is the engine's integer (bill-inbox.js).

import { useEffect, useState } from "react";

import { Button } from "@/components/ui";
import { Sheet } from "@/components/ui/Sheet";
import BillReview from "@/components/bills/BillReview";
import InboxSheet from "@/components/bills/InboxSheet";
import { formatDay, formatMoney } from "@/lib/format";
import { approveMany, listInbox, readItem } from "@/lib/bills-client";
import { statusWords } from "@/lib/bills-model";
import { useWritesEnabled } from "@/lib/engine-context";
import { approveLabel, approvedLines, billInboxShapeOf, sendModeWords, withLiveInbox } from "./bill-inbox";

const SAMPLE_REASON = "These are the sample books, so nothing can be approved here.";

// REVIEW BESIDE THE LIST (founder, 8 Nov 2026: work the close list the way other software
// does). A bill tool's inbox opens a bill in a panel beside the list, with the document
// and its fields, and Approve there; this one sent each row to its own page
// (/bills/<id>). A row's press now opens the same review (components/bills/BillReview.js)
// in a side sheet in the chat; what the review did is said on the row when it closes.

/** The review in a sheet: reads the bill and the ledger's connection, then draws it. */
export function ReviewSheet({ id, title, onClose, onChanged = () => {}, xero: known = undefined }) {
  const [read, setRead] = useState({ state: "loading" });
  const [ledgerState, setLedger] = useState(known === undefined ? null : known);
  useEffect(() => {
    let live = true;
    // THE BILL FIRST (founder's walk, 8 Nov 2026): the sheet waited on the whole inbox
    // list (~10 s) for the connection's line; the bill is drawn as soon as it is read,
    // and the connection comes from the caller's own read of the inbox when it has one.
    readItem(id).then((one) => {
      if (!live) return;
      if (one && one.ok && one.item) setRead({ state: "read", item: one.item });
      else setRead({ state: "failed", words: (one && one.message) || "Vert couldn't open that bill just now." });
    });
    if (known === undefined) {
      listInbox({}).then((list) => {
        if (live && list && list.ok) setLedger(list.xero || null);
      });
    }
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);
  return (
    <Sheet open side="right" title={title} onClose={onClose} className="bill-sheet">
      {read.state === "loading" ? (
        <p className="ink-2" role="status">
          Opening the bill…
        </p>
      ) : read.state === "failed" ? (
        <p className="ink-2" role="alert">
          {read.words}
        </p>
      ) : (
        <BillReview
          key={read.item.id}
          item={read.item}
          xero={ledgerState}
          onItem={(next) => {
            if (next) {
              setRead((r) => ({ ...r, item: next }));
              onChanged(next);
            }
          }}
          onBack={onClose}
        />
      )}
    </Sheet>
  );
}

export default function BillInbox({ billInbox, ledgerName = null }) {
  const answered = billInboxShapeOf(billInbox);
  const [open, setOpen] = useState(null);
  const [changed, setChanged] = useState({});
  const [inboxOpen, setInboxOpen] = useState(false);
  // The inbox as it is now, read by the browser: an answer read again later lists what
  // waits then, never what was approved or set aside since (as the cash coding grid).
  const [items, setItems] = useState(null);
  const [liveLedger, setLiveLedger] = useState(undefined);
  const measured = Boolean(answered && answered.measured);
  useEffect(() => {
    if (!measured) return undefined;
    let live = true;
    listInbox({}).then((got) => {
      if (live && got && got.ok && Array.isArray(got.items)) {
        setItems(got.items);
        setLiveLedger(got.xero || null);
      }
    });
    return () => {
      live = false;
    };
  }, [measured, inboxOpen, open]);
  const view = withLiveInbox(answered, items) || answered;
  if (!view) return null;
  if (!view.measured) {
    return (
      <section className="cc-answer" data-bill-inbox-answer="" aria-label="Bill inbox">
        <p className="ink-2">{view.words}</p>
      </section>
    );
  }
  // The answer's words are of their time; when the inbox has moved since, the table
  // says what it holds now, so the sentence above it isn't read as today's count.
  const moved = view.live && answered && view.waiting !== answered.waiting;
  return (
    <section className="cc-answer" data-bill-inbox-answer="" aria-label="Bills waiting for review">
      {moved ? (
        <p className="ink-2 t-footnote" data-bill-inbox-now="">
          Inbox now: {view.waiting} waiting
        </p>
      ) : null}
      {view.rows.length ? (
        <div className="table-scroll">
          <table className="table">
            <caption className="sr-only">{view.words}</caption>
            <thead>
              <tr>
                <th scope="col">Contact</th>
                <th scope="col">Date</th>
                <th scope="col" className="num-col">Amount</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {view.rows.map((r) => (
                <tr key={r.id} className="row" data-bill-row={r.ready ? "ready" : "review"}>
                  <td data-label="Contact" translate="no">
                    {r.href ? (
                      <button type="button" className="link bill-row-open" aria-haspopup="dialog" onClick={() => setOpen(r)} data-bill-review={r.id}>
                        {r.contact || "Contact not read"}
                      </button>
                    ) : (
                      r.contact || "Contact not read"
                    )}
                    {r.number ? <span className="ink-2"> · {r.number}</span> : null}
                  </td>
                  <td data-label="Date" className="num">{r.date ? formatDay(r.date) : <span className="ink-2">Not read</span>}</td>
                  <td data-label="Amount" className="num-col num" translate="no">
                    {r.totalCents !== null ? formatMoney(r.totalCents) : r.subtotalCents !== null ? `${formatMoney(r.subtotalCents)} + GST` : <span className="ink-2">Total not read</span>}
                  </td>
                  <td data-label="Status">{changed[r.id] ? statusWords(changed[r.id]) : r.statusWords}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      {view.more ? (
        <p className="shape-more ink-2">
          and {view.more} more in{" "}
          <button type="button" className="link bill-row-open" aria-haspopup="dialog" onClick={() => setInboxOpen(true)} data-bill-inbox-open="">
            Bills &amp; invoices
          </button>
        </p>
      ) : null}
      {inboxOpen ? <InboxSheet onClose={() => setInboxOpen(false)} /> : null}
      {view.readyIds.length ? <ApproveReady view={view} ledger={ledgerName || "your ledger"} /> : null}
      {/* AN INBOX TAKES NEW BILLS (founder's walk, 8 Nov 2026): the answer listed what
          was waiting and offered no way to add one. Upload opens Bills & invoices beside
          the chat, at its drop zone. */}
      <p className="bill-inbox-add">
        <Button variant="quiet" size="sm" aria-haspopup="dialog" onClick={() => setInboxOpen(true)} data-bill-inbox-upload="">
          Upload bills or receipts
        </Button>
      </p>
      {open ? <ReviewSheet id={open.id} title={open.contact || "Review"} xero={liveLedger} onClose={() => setOpen(null)} onChanged={(item) => setChanged((c) => ({ ...c, [open.id]: item }))} /> : null}
    </section>
  );
}

function ApproveReady({ view, ledger }) {
  const writes = useWritesEnabled();
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [lines, setLines] = useState(null);
  const n = view.readyIds.length;
  const press = async () => {
    if (busy) return;
    setBusy(true);
    const answer = await approveMany(view.readyIds);
    setBusy(false);
    setConfirming(false);
    setLines(approvedLines(answer, view.rows, ledger));
  };
  if (lines) {
    return (
      <ul className="shape-more" data-bill-inbox-outcome="" aria-live="polite">
        {lines.map((l, i) => (
          <li key={l.id || i} className={l.ok ? null : "ink-2"}>
            {l.name ? <span translate="no">{l.name}: </span> : null}
            {l.words}
          </li>
        ))}
      </ul>
    );
  }
  return (
    <div className="aging-action">
      {confirming ? (
        <p role="group" aria-label="Confirm approval">
          Send {approveLabel(n, view.rows).replace(/^Approve /, "")} to {ledger}{sendModeWords(view.documentMode, n)}?{" "}
          <Button variant="commit" size="sm" busy={busy} busyLabel="Sending…" onClick={press} data-bill-inbox-send="">
            Send
          </Button>{" "}
          <Button variant="secondary" size="sm" onClick={() => setConfirming(false)}>
            Cancel
          </Button>
        </p>
      ) : (
        <Button variant="secondary" size="sm" disabledReason={writes ? undefined : SAMPLE_REASON} onClick={() => setConfirming(true)} data-bill-inbox-approve="">
          {approveLabel(n, view.rows)}
        </Button>
      )}
    </div>
  );
}
