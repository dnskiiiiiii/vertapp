"use client";

// components/chat/answer/SmallBalances.js — THE CENTS LEFT AFTER A PAYMENT, IN THE ANSWER
// ==============================================================================
// w47 (audit row 19, 4 Nov 2026). Under the verdict ("1 invoice and 1 bill have less than
// $5.00 left after a payment."): one row per part-paid invoice or bill (Contact, Date,
// Total, Left, Status, with the GST rate its credit note goes out at), each with a tick
// and its own Clear; the account they are cleared to (the one the engine proposed, or a
// choice: nothing is picked for the person); then ONE press for the ticked ones,
// "Clear 2 small balances". The press asks once more, the way the bill inbox's does
// ("Send 2 credit notes to Xero as draft credit notes?", or "approved, and allocated to
// each" for a client whose documents go in approved), then sends exactly the ticked
// rows to POST /api/write-offs/small-balances: a person's press. What each did is drawn
// under it, as the bad-debt write-off's own card (WriteOff.js), so a send that failed
// or may have landed keeps its own Approve again / check-the-ledger road.
//
// An unread read is its words alone: no table, no press. Every amount is the engine's
// integer (small-balances.js); nothing is added up here.

import { useId, useState } from "react";

import { Button } from "@/components/ui";
import { formatDay } from "@/lib/format";
import { useWritesEnabled } from "@/lib/engine-context";
import { requestClearSmall } from "@/lib/write-offs-client";
import { moneyIn } from "./aging-money";
import { clearableIds, clearLabel, confirmWords, itemsFor, partyWord, smallBalancesShapeOf } from "./small-balances";
import WriteOff from "./WriteOff";
import { writeOffOf } from "./write-off";

const SAMPLE_REASON = "These are the sample books, so nothing can be cleared here.";

export default function SmallBalances({ smallBalances, ledgerName = null, writes: writesProp = null, initial = null }) {
  const ctxWrites = useWritesEnabled();
  const writes = writesProp === null || writesProp === undefined ? ctxWrites : Boolean(writesProp);
  const view = smallBalancesShapeOf(smallBalances);
  const ledger = ledgerName || "your ledger";
  const id = useId();
  const [ticked, setTicked] = useState(() => new Set((initial && initial.ticked) || clearableIds(view)));
  const [code, setCode] = useState(() => (initial && initial.accountCode) || (view && view.account.proposed) || "");
  const [confirming, setConfirming] = useState(() => (initial && initial.confirming) || null);
  const [busy, setBusy] = useState(false);
  const [results, setResults] = useState(() => (initial && initial.results) || null);
  const [error, setError] = useState(null);
  const [mode, setMode] = useState(null);
  if (!view) return null;
  const currency = (view.rows[0] && view.rows[0].currency) || null;
  const money = (cents, cur = currency) => moneyIn(cents, cur);
  const documentMode = mode || view.documentMode;

  if (!view.measured) {
    return (
      <section className="cc-answer" data-leftovers-answer="" aria-label="Small balances">
        <p className="ink-2">{view.words}</p>
        {view.sides.filter((s) => !s.measured && s.words).map((s) => (
          <p key={s.side} className="ink-2">
            {s.words}
          </p>
        ))}
      </section>
    );
  }

  const ready = new Set(clearableIds(view));
  const chosen = [...ticked].filter((x) => ready.has(x));
  const why = !writes ? SAMPLE_REASON : !view.canClear ? view.clearWords || "These can't be cleared here." : !code ? "Choose the account these go to." : undefined;
  const toggle = (rowId, on) => {
    const next = new Set(ticked);
    if (on) next.add(rowId);
    else next.delete(rowId);
    setTicked(next);
  };
  const send = async (ids) => {
    if (busy || why) return;
    setBusy(true);
    setError(null);
    const got = await requestClearSmall({ items: itemsFor(view, ids), accountCode: code, limitCents: view.limitCents });
    setBusy(false);
    setConfirming(null);
    const list = got.ok && got.body && Array.isArray(got.body.results) ? got.body.results : null;
    if (!list) {
      setError(got.ok ? "Vert answered without saying what happened. Check the ledger before clearing again." : got.message);
      return;
    }
    if (got.body.documentMode === "authorised" || got.body.documentMode === "draft") setMode(got.body.documentMode);
    setResults(list);
  };

  return (
    <section className="cc-answer" data-leftovers-answer="" aria-label="Small balances left after a payment">
      {view.rows.length ? (
        <div className="table-scroll">
          <table className="table">
            <caption className="sr-only">
              {view.words} Under {money(view.limitCents)}.
            </caption>
            <thead>
              <tr>
                {view.canClear ? (
                  <th scope="col">
                    <span className="sr-only">Clear</span>
                  </th>
                ) : null}
                <th scope="col">Contact</th>
                <th scope="col">Date</th>
                <th scope="col" className="num-col">
                  Total
                </th>
                <th scope="col" className="num-col">
                  Left
                </th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {view.rows.map((r) => {
                const tickId = `${id}-${r.id}`;
                return (
                  <tr key={r.id} className="row" data-leftover-row={r.ready ? "ready" : "held"}>
                    {view.canClear ? (
                      <td data-label="Clear">
                        {r.ready ? (
                          <label className="cbx-hit">
                            <input type="checkbox" className="cbx" id={tickId} checked={ticked.has(r.id)} disabled={!writes} onChange={(e) => toggle(r.id, e.target.checked)} aria-label={`Clear ${r.number || r.contact || "this one"}`} data-leftover-tick={r.id} />
                          </label>
                        ) : null}
                      </td>
                    ) : null}
                    <td data-label="Contact" translate="no">
                      {r.url ? (
                        <a className="link" href={r.url} target="_blank" rel="noopener noreferrer">
                          {r.contact || `${partyWord(r.side)} not read`}
                        </a>
                      ) : (
                        r.contact || `${partyWord(r.side)} not read`
                      )}
                      {r.number ? <span className="ink-2"> · {r.number}</span> : null}
                      <span className="ink-2"> · {r.kind === "bill" ? "Bill" : "Invoice"}</span>
                    </td>
                    <td data-label="Date" className="num">
                      {r.date ? formatDay(r.date) : <span className="ink-2">Not read</span>}
                    </td>
                    <td data-label="Total" className="num-col num" translate="no">
                      {money(r.totalCents, r.currency)}
                    </td>
                    <td data-label="Left" className="num-col num" translate="no">
                      {money(r.amountDueCents, r.currency)}
                    </td>
                    <td data-label="Status">
                      {r.statusWords}
                      {r.taxWords ? <span className="ink-2 small-balance-tax"> {r.taxWords}</span> : null}
                      {r.ready && view.canClear && !results ? (
                        <>
                          {" "}
                          <Button variant="quiet" size="sm" disabledReason={why} onClick={() => setConfirming([r.id])} data-leftover-one={r.id}>
                            Clear
                          </Button>
                        </>
                      ) : null}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : null}
      {view.more ? <p className="shape-more ink-2">and {view.more} more: clear these, then ask again for the rest.</p> : null}
      {view.rows.length && view.canClear && !results ? (
        <div className="write-off-fields">
          <label className="form-field">
            <span className="field-label">Account they go to</span>
            <span className="field-box">
              <select className="field-input" name="small-balance-account" autoComplete="off" value={code} disabled={!writes} onChange={(e) => setCode(e.target.value)} data-leftover-account="">
                {view.account.choice !== "one" ? <option value="">Choose an account</option> : null}
                {view.account.options.map((a) => (
                  <option key={a.code} value={a.code}>
                    {[a.code, a.name].filter(Boolean).join(" ")}
                  </option>
                ))}
              </select>
            </span>
          </label>
          <p className="write-off-hint">{view.account.words}</p>
          {code && code !== view.account.proposed ? <p className="write-off-hint">The GST rate is worked out again for the account you chose, and the answer says which it used.</p> : null}
        </div>
      ) : null}
      {view.rows.length && !view.canClear && view.clearWords ? <p className="ink-2">{view.clearWords}</p> : null}
      {results ? (
        <Outcomes results={results} rows={view.rows} ledger={ledger} documentMode={documentMode} writes={writes} />
      ) : view.canClear && ready.size ? (
        <div className="aging-action">
          {confirming ? (
            <p role="group" aria-label="Confirm clearing">
              {confirmWords(confirming.length, documentMode, ledger)}{" "}
              <Button variant="commit" size="sm" busy={busy} busyLabel="Sending…" disabledReason={why} onClick={() => send(confirming)} data-leftover-send="">
                Send
              </Button>{" "}
              <Button variant="secondary" size="sm" onClick={() => setConfirming(null)}>
                Cancel
              </Button>
            </p>
          ) : (
            <Button variant="secondary" size="sm" disabledReason={why || (chosen.length ? undefined : "Tick at least one to clear.")} onClick={() => setConfirming(chosen)} data-leftover-clear="">
              {clearLabel(chosen.length)}
            </Button>
          )}
        </div>
      ) : null}
      {error ? (
        <p className="aging-error" role="alert">
          {error}
        </p>
      ) : null}
    </section>
  );
}

/** What each clear did: the write-off's own card when there is one, else the engine's words. */
function Outcomes({ results, rows, ledger, documentMode, writes }) {
  return (
    <div className="small-balance-outcomes" data-leftover-outcome="" aria-live="polite">
      {results.map((r, i) => {
        const known = rows.find((x) => x.id === r.invoiceId) || {};
        const w = r.writeOff ? writeOffOf(r.writeOff) : null;
        // The write-off's own words say what the ledger did (or refused); its card keeps
        // the road on from there (approve again, check the ledger).
        if (w) return <WriteOff key={w.id} writeOff={w} ledgerName={ledger} writes={writes} documentMode={documentMode} />;
        const name = [known.contact, known.number].filter(Boolean).join(" · ") || "A small balance";
        return (
          <p key={r.invoiceId || i} className="ink-2" data-leftover-refused={r.invoiceId}>
            <span translate="no">{name}: </span>
            {r.message || "Not cleared."}
          </p>
        );
      })}
    </div>
  );
}
