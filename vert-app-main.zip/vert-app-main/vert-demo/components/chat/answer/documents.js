// components/chat/answer/documents.js — THE MONTH'S DOCUMENTS, READ FROM THE ENGINE
// ==============================================================================
// Audit 1.1 (3 Nov 2026), the close checklist's Step 1 "Collect documents". The engine's
// GET /close/{period}/documents and the chat answer's `shape.documents` (w33 contract §2,
// agent_events.ShapeDocuments) carry one body: statements per bank, card and loan account
// through month end, bills against the suppliers who usually bill monthly, receipts
// awaiting coding. Each part is `measured` or carries its words for why not.
//
// A lookup only: nothing is counted here (every count is the engine's). A body that
// doesn't read as the contract says is dropped whole (null). An unread part keeps its
// words and no rows; an unread receipt count is null, never 0.
//
// It imports nothing: components/chat/answer/shape.js reads `shape` through it.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const count = (v) => (Number.isInteger(v) && v >= 0 ? v : null);
const path = (v) => {
  const t = text(v);
  return t && t.startsWith("/") && !t.startsWith("//") ? t : null;
};
const ACCOUNT_KINDS = new Set(["bank", "card", "loan"]);
const STATEMENT_STATUSES = new Set(["missing", "partial", "not_measured", "not_due", "received"]);
const BILL_STATUSES = new Set(["received", "missing", "not_due"]);

function statementRowOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !text(raw.label) || !ACCOUNT_KINDS.has(raw.kind) || !STATEMENT_STATUSES.has(raw.status) || !text(raw.words)) return null;
  return { id: raw.id, label: text(raw.label), kind: raw.kind, status: raw.status, through: text(raw.through), words: text(raw.words), href: path(raw.href) };
}

function statementsOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean" || !text(raw.words) || !Array.isArray(raw.rows)) return null;
  const rows = raw.rows.map(statementRowOf);
  if (rows.some((r) => !r) || (!raw.measured && rows.length)) return null;
  return { measured: raw.measured, words: text(raw.words), rows };
}

function billsOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean" || !text(raw.words) || !Array.isArray(raw.rows)) return null;
  const rows = raw.rows.map((r) => (isObj(r) && text(r.contact) && BILL_STATUSES.has(r.status) ? { contact: text(r.contact), status: r.status } : null));
  if (rows.some((r) => !r) || (!raw.measured && rows.length)) return null;
  return { measured: raw.measured, words: text(raw.words), rows, expected: count(raw.expected) };
}

function receiptsOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean" || !text(raw.words)) return null;
  const n = raw.awaitingCoding === null || raw.awaitingCoding === undefined ? null : count(raw.awaitingCoding);
  if (raw.measured !== (n !== null)) return null;
  return { measured: raw.measured, words: text(raw.words), awaitingCoding: n, href: path(raw.href) || "/scheduled?task=bills" };
}

/** The engine's documents checklist, checked, or null. Pure. */
export function documentsShapeOf(raw) {
  if (!isObj(raw) || !text(raw.words)) return null;
  const statements = statementsOf(raw.statements);
  const bills = billsOf(raw.bills);
  const receipts = receiptsOf(raw.receipts);
  if (!statements || !bills || !receipts) return null;
  return {
    period: text(raw.period),
    words: text(raw.words),
    missing: count(raw.missing),
    statements,
    bills,
    receipts,
    // What the card lists by name: what's missing or stops early; received rows are counted.
    missingStatements: statements.rows.filter((r) => r.status === "missing" || r.status === "partial" || r.status === "not_measured"),
    missingBills: bills.rows.filter((r) => r.status === "missing"),
  };
}
