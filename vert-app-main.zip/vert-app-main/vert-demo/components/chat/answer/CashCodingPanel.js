"use client";

// components/chat/answer/CashCodingPanel.js — THE CASH CODING GRID, IN THE ANSWER
// ==============================================================================
// Founder, 8 Nov 2026: "i asked the chat to complete cash coding and it gave [a summary
// with Open 093 / Open 091] whereas it should be just the cash coding table in the chat
// and not need to click into to get there. we need to reduce clicks and make it direct."
//
// So the answer IS the grid: the same Grid the Cash coding page draws (one row per line,
// payee, account, tax rate, Code N lines), read here by the browser for the answer's
// month, on the account the engine named or, with several, the one with the most lines.
// The other accounts with lines are a row of pills above it that switch in place.
// Nothing opens another page to code.
//
// The grid is read live, not drawn from the answer: an answer read again tomorrow shows
// what is left to code then, never lines that were coded since.
//
// While the first read is out, the engine's own first rows (the answer's `cashCoding`,
// CashCodingLines) stand in its place, so the answer is never blank; a read that fails
// says so, offers Retry and keeps those rows.

import { useCallback, useEffect, useRef, useState } from "react";
import { CashCodingRefresh, Empty, Grid, Retry } from "@/components/cash-coding/CashCodingScreen";
import { readGrid } from "@/lib/cash-coding-client";
import { gridKey, gridOf } from "@/lib/cash-coding-model";
import { useDuties, useSignedInActor } from "@/lib/store";
import CashCodingLines from "./CashCodingLines";
import { cashCodingShapeOf } from "./cash-coding";

/** The account to open first: the one the engine named, else the one with the most lines. Pure. */
export function firstAccountOf(view) {
  if (!view) return null;
  if (view.accountId) return view.accountId;
  const withLines = view.accounts.filter((a) => a.toCode > 0);
  return withLines.length ? withLines[0].id : null;
}

export default function CashCodingPanel({ cashCoding }) {
  const view = cashCodingShapeOf(cashCoding);
  const period = view && view.period;
  const actor = useSignedInActor();
  const duties = useDuties();
  const [account, setAccount] = useState(() => firstAccountOf(view));
  // The last good read stays drawn while the next one is out (switching, re-reading).
  const [read, setRead] = useState({ body: null, failed: null, busy: true });
  const asked = useRef(0);

  const load = useCallback(
    async (which) => {
      if (!period) return;
      const ticket = ++asked.current;
      setRead((r) => ({ ...r, busy: true }));
      const got = await readGrid({ period, account: which });
      if (ticket !== asked.current) return;
      setRead((r) => (got.ok ? { body: got.body, failed: null, busy: false } : { ...r, failed: got.message, busy: false }));
    },
    [period]
  );

  useEffect(() => {
    load(account);
  }, [load, account]);

  if (!view || !period) return <CashCodingLines cashCoding={cashCoding} />;
  const grid = read.body ? gridOf(read.body) : null;

  if (!grid) {
    return (
      <section className="cc-chat" data-cash-coding-panel="" aria-busy={read.busy ? "true" : "false"}>
        {read.failed ? (
          <CashCodingRefresh value={() => load(account)}>
            <p className="cc-words" role="status" data-cc-unread="">
              {read.failed}
            </p>
            <Retry />
          </CashCodingRefresh>
        ) : null}
        <div className={read.busy ? "cc-chat-standin" : undefined}>
          <CashCodingLines cashCoding={cashCoding} />
        </div>
      </section>
    );
  }

  const shownAccount = grid.account ? grid.account.id : account;
  const pills = grid.accounts.filter((a) => a.toCode > 0 || a.id === shownAccount);
  return (
    <CashCodingRefresh value={() => load(shownAccount)}>
      <section className="cc-chat" data-cash-coding-panel="" aria-busy={read.busy ? "true" : "false"}>
        {pills.length > 1 ? (
          <nav className="cc-accounts cc-chat-accounts" aria-label="Bank account">
            {pills.map((a) => {
              const current = a.id === shownAccount;
              return (
                <button
                  key={a.id}
                  type="button"
                  aria-pressed={current ? "true" : "false"}
                  className="cc-account"
                  translate="no"
                  onClick={() => (current ? null : setAccount(a.id))}
                >
                  <span>{a.label}</span>
                  {Number.isInteger(a.toCode) ? <span className="cc-account-count num">{a.toCode}</span> : null}
                </button>
              );
            })}
          </nav>
        ) : null}
        {read.failed ? (
          <p className="cc-words cc-chat-failed" role="status">
            {read.failed}
          </p>
        ) : null}
        <div className={read.busy ? "cc-chat-body cc-chat-standin" : "cc-chat-body"}>
          {grid.account && grid.lines.length ? (
            // The grid's own headline ("6 lines to code in October.") repeats the verdict
            // and the account's count beside its name, so the chat leaves it out.
            <Grid key={gridKey(grid)} grid={{ ...grid, words: null }} viewer={{ actor, duties }} onCoded={() => {}} />
          ) : (
            <Empty grid={grid} period={grid.period || period} />
          )}
        </div>
      </section>
    </CashCodingRefresh>
  );
}
