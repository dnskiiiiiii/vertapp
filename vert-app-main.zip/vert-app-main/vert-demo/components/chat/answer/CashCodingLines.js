// components/chat/answer/CashCodingLines.js — THE FIRST LINES TO CODE, IN THE ANSWER
// ==============================================================================
// w25 contract v2 §4. Under the verdict ("7 July lines to code, $68.00 spent"): the
// account, then the first lines in the chat table's columns (Date, Payee, Description,
// Account, Tax rate, Spent, Received), then "and N more". The answer's one action,
// "Open Cash coding", is drawn by NextAction under it; the coding happens there.
//
// Every amount is the engine's integer (cash-coding.js); nothing is summed here. A line
// Vert has no account for says so in words rather than leaving the cell blank.
//
// w26 CC-5: with several accounts holding lines and none named, there are no rows; the
// block carries `accounts` instead, drawn as one short table (Account, Lines, Spent,
// Received) in the engine's order, with a total row only when the engine gave its totals.
// The Open actions ("Open 090", "Open 091") are the answer's, drawn by NextAction.

import { formatDay, formatMoney } from "@/lib/format";
import { cashCodingShapeOf } from "./cash-coding";

export default function CashCodingLines({ cashCoding }) {
  const view = cashCodingShapeOf(cashCoding);
  if (!view) return null;
  return (
    <section className="cc-answer" data-cash-coding-answer="" aria-label="Lines to code">
      {view.account ? (
        <p className="shape-label" translate="no">
          On {view.account}
        </p>
      ) : null}
      {view.rows.length ? (
        <div className="table-scroll">
          <table className="table">
            <caption className="sr-only">{view.words || "Lines to code"}</caption>
            <thead>
              <tr>
                <th scope="col">Date</th>
                <th scope="col">Payee</th>
                <th scope="col">Description</th>
                <th scope="col">Account</th>
                <th scope="col">Tax rate</th>
                <th scope="col" className="num-col">Spent</th>
                <th scope="col" className="num-col">Received</th>
              </tr>
            </thead>
            <tbody>
              {view.rows.map((r) => (
                <tr key={r.id} className="row">
                  <td data-label="Date" className="num">{r.date ? formatDay(r.date) : ""}</td>
                  <td data-label="Payee" translate="no">{r.payee || ""}</td>
                  <td data-label="Description">{r.description || ""}</td>
                  <td data-label="Account" translate="no">{r.account || <span className="ink-2">Not proposed</span>}</td>
                  <td data-label="Tax rate">{r.taxRate || ""}</td>
                  <td data-label="Spent" className="num-col num" translate="no">{r.spentCents !== null ? formatMoney(r.spentCents) : ""}</td>
                  <td data-label="Received" className="num-col num" translate="no">{r.receivedCents !== null ? formatMoney(r.receivedCents) : ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}
      {view.more ? <p className="shape-more ink-2">and {view.more} more</p> : null}
      {view.accounts.length ? <AccountsTable view={view} /> : null}
    </section>
  );
}

function AccountsTable({ view }) {
  const ruled = view.accounts.length >= 5;
  return (
    <div className="table-scroll cc-answer-accounts-wrap">
      <table className={["table", "cc-answer-accounts", ruled ? "table-ruled" : null].filter(Boolean).join(" ")} data-cc-accounts="">
        <caption className="sr-only">{view.words || "Lines to code by account"}</caption>
        <thead>
          <tr>
            <th scope="col">Account</th>
            <th scope="col" className="num-col">Lines</th>
            <th scope="col" className="num-col">Spent</th>
            <th scope="col" className="num-col">Received</th>
          </tr>
        </thead>
        <tbody>
          {view.accounts.map((a) => (
            <tr key={a.id}>
              <td data-label="Account" translate="no">{a.label}</td>
              <td data-label="Lines" className="num-col num">{a.toCode}</td>
              <td data-label="Spent" className="num-col num" translate="no">{formatMoney(a.spentCents)}</td>
              <td data-label="Received" className="num-col num" translate="no">{formatMoney(a.receivedCents)}</td>
            </tr>
          ))}
        </tbody>
        {view.total ? (
          <tfoot>
            <tr data-cc-accounts-foot="">
              <td data-label="Account">Total</td>
              <td data-label="Lines" className="num-col num">{view.total.toCode}</td>
              <td data-label="Spent" className="num-col num" translate="no">{formatMoney(view.total.spentCents)}</td>
              <td data-label="Received" className="num-col num" translate="no">{formatMoney(view.total.receivedCents)}</td>
            </tr>
          </tfoot>
        ) : null}
      </table>
    </div>
  );
}
