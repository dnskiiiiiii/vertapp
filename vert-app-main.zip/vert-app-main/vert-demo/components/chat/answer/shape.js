// components/chat/answer/shape.js — THE ANSWER SHAPE, AS PURE FUNCTIONS
// ==============================================================================
// The founder's answer shape (17 Oct 2026, research reference/answer-shape.md; the wire is
// verify/shape-contract.md). A finished task answer reads, in this order:
//
//   1. the work itself, inline, as a table (top rows, then "N more in the workbook");
//   2. the tie-out to the GL in four short lines, ✓ only when the engine checked it;
//   3. "I've delivered N things", numbered, naming each and what happens next;
//   4. the journal entry card(s), one per entry, numbered "1 of 3", a blocked one
//      visibly blocked on its own card;
//   5. one primary action, its label from the ledger's createsDraft, role-aware.
//
// The engine sends all of it on the `assistant_text` payload as `shape`
// (vert_engine/workflows/player.py). These functions only READ it: nothing here adds a
// column, subtracts one side from another or invents a status. Every rule a screen
// depends on is here so a test can hold it without a browser.

// It imports nothing but bank-rec.js, aged-balances.js, reminders.js,
// unusual-balances.js, financial-statements.js and cash-coding.js, which import
// nothing either: lib/agent/events.js reads `shape` through it, and the wording half
// (shape-action.js) imports the cards' words, which import events.js.
import { bankRecOf } from "./bank-rec.js";
import { agedBalancesOf } from "./aged-balances.js";
import { remindersOf } from "./reminders.js";
import { unusualBalancesOf } from "./unusual-balances.js";
import { statementsOf } from "./financial-statements.js";
import { cashCodingShapeOf } from "./cash-coding.js";
import { billInboxShapeOf } from "./bill-inbox.js";
import { smallBalancesShapeOf } from "./small-balances.js";
import { documentsShapeOf } from "./documents.js";
import { pettyCashShapeOf } from "./petty-cash.js";
import { scheduleShapeOf } from "./schedule.js";
import { trialBalanceOf } from "../../reports/trial-balance.js";
import { accountTransactionsOf } from "../../reports/account-transactions.js";
import { gstReportOf } from "../../reports/gst-report.js";
import { customerStatementOf } from "../../reports/customer-statement.js";
import { supplierStatementRecOf } from "./supplier-statement.js";

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

/** Above this many entries the answer draws CARDS_ABOVE_LIMIT cards and a compact list. */
export const ENTRY_CARD_LIMIT = 5;
export const CARDS_ABOVE_LIMIT = 3;
/** The work table's figure rows at most (the engine sends top rows only). */
export const WORK_ROWS = 5;

/** The tie-out line kinds, in the order the contract allows them. */
const TIE_KINDS = new Set(["opening", "movement", "ending", "gl", "variance"]);

/**
 * THE TOTALS ROW, IN EITHER SPELLING (verify pass 5, Q-SHAPE-1 F-15). The engine sends
 * `work.totals` as the row's cells themselves (`{amount: 2900000, payout: "Total"}`);
 * this read accepted only `{cells: {...}}`, so every sent totals row was dropped and
 * never drawn. Both are read; anything else is no totals row. Pure.
 */
export function totalsOf(t) {
  if (!isObj(t)) return null;
  if (isObj(t.cells)) return t;
  const cells = Object.fromEntries(Object.entries(t).filter(([, v]) => typeof v === "string" || (typeof v === "number" && Number.isFinite(v)) || v === null));
  return Object.keys(cells).length ? { cells } : null;
}

/** The most columns the chat's inline table draws; the rest stay in the workbook. */
export const CHAT_COLUMNS = 7;

const STATUS_COLUMN = /^(state|status|tie|tied|f\/u)$/i;
const MONEY_KINDS = new Set(["money"]);

/**
 * THE CHAT TABLE'S COLUMN BUDGET (verify pass 5, Q-SHAPE-1 / items 16, 39). The engine
 * sends the workbook sheet's columns, up to 14 of them (a budget's twelve months), and
 * the chat drew every one: past ~6 the table outgrew the 672 px answer column, the last
 * column was clipped behind a sideways scroll at 1440, and the money was off-screen.
 * The chat draws at most `max` columns, chosen so the money stays: the first (what the
 * row is), every money column the room allows, then the row's status word; dates,
 * counts, percentages and descriptive words give way first, then the middle money
 * columns (the last money column, the total or closing, is kept). What was left out is
 * named under the table, and every column is in the workbook. Returns `{columns, left}`
 * in the engine's order. Pure.
 */
export function chatColumns(columns, max = CHAT_COLUMNS) {
  const all = Array.isArray(columns) ? columns : [];
  if (all.length <= max) return { columns: all, left: [] };
  const rank = (c, i) => {
    if (i === 0) return 0;
    if (MONEY_KINDS.has(c.kind)) return 1;
    if (STATUS_COLUMN.test(String(c.label || c.key || "").trim())) return 2;
    if (c.kind === "percent") return 3;
    if (c.kind === "text") return 4;
    return 5; // dates, counts
  };
  const order = all.map((c, i) => ({ c, i, r: rank(c, i) }));
  const keep = new Set([0]);
  const money = order.filter((o) => o.r === 1);
  const rest = order.filter((o) => o.r > 1).sort((a, b) => a.r - b.r || a.i - b.i);
  const room = max - 1;
  // Money first: all of it when it fits, else the first ones and the last (the total).
  const moneyKept = money.length <= room ? money : [...money.slice(0, Math.max(0, room - 1)), money[money.length - 1]];
  for (const o of moneyKept) keep.add(o.i);
  for (const o of rest) if (keep.size < max && !keep.has(o.i)) keep.add(o.i);
  return { columns: all.filter((_, i) => keep.has(i)), left: all.filter((_, i) => !keep.has(i)) };
}

/** "Also in the workbook: In use from, Months left." for the columns the chat left out. Pure. */
export function leftColumnsWords(left) {
  const names = (Array.isArray(left) ? left : []).map((c) => text(c && c.label)).filter(Boolean);
  return names.length ? `Also in the workbook: ${names.join(", ")}.` : null;
}

function workOf(w) {
  if (!isObj(w)) return null;
  const columns = Array.isArray(w.columns) ? w.columns.filter((c) => isObj(c) && typeof c.key === "string" && c.key) : [];
  const rows = Array.isArray(w.rows) ? w.rows.filter((r) => isObj(r) && isObj(r.cells)) : [];
  if (!columns.length || !rows.length) return null;
  const shown = Number.isInteger(w.shown) ? w.shown : rows.filter((r) => !r.role || r.role === "figure").length;
  const of = Number.isInteger(w.of) ? w.of : shown;
  const budget = chatColumns(columns);
  return {
    artifactId: text(w.artifactId),
    title: text(w.title),
    sheet: text(w.sheet),
    columns: budget.columns,
    // Every column the engine sent (the pane and the workbook draw them all).
    allColumns: columns,
    leftWords: leftColumnsWords(budget.left),
    rows,
    totals: totalsOf(w.totals),
    shown,
    of,
    // "N more in the workbook": the engine's words, else said from its own counts.
    moreWords: of > shown ? text(w.moreWords) || `${of - shown} more in the workbook` : null,
    // What belongs beside the table but is in none of its rows (engine verify pass 8,
    // D18: a prepaid schedule waiting to be agreed is in no total). The engine's words.
    noteWords: text(w.noteWords) || null,
  };
}

function tieOutOf(t, nested = false) {
  if (!isObj(t) || !Array.isArray(t.lines)) return null;
  // SEVERAL UNLIKE ACCOUNTS (engine note, 18 Oct 2026): the GL rec ties a bank asset, a
  // clearing account and GST, whose balances are never added. Each is its own block in
  // `accounts`; the top-level lines are the totals check. One level deep only.
  const accounts = !nested && Array.isArray(t.accounts) ? t.accounts.map((a) => tieOutOf(a, true)).filter(Boolean) : [];
  const lines = t.lines
    .filter((l) => isObj(l) && TIE_KINDS.has(l.kind) && text(l.label))
    .map((l) => ({
      kind: l.kind,
      label: text(l.label),
      figureRef: text(l.figureRef),
      measured: l.measured === true,
      negative: l.negative === true,
      // The figure is below zero in its own right (engine `belowZero`, W7-1).
      belowZero: l.belowZero === true,
    }));
  if (!lines.length) return null;
  return {
    account: text(t.account),
    // The engine's heading for a block that is no reconciliation ("Bank summary",
    // "GST tie-out"); without one, ShapeBlocks' tieHeading says "Reconciliation".
    title: text(t.title),
    lines,
    // Only the engine's literal `true` is a tick; anything else is not a check.
    tied: t.tied === true ? true : t.tied === false ? false : null,
    words: text(t.words),
    accounts,
  };
}

function deliveredOf(d) {
  if (!isObj(d) || !Array.isArray(d.items)) return null;
  const items = d.items
    .filter((i) => isObj(i) && text(i.label))
    .map((i, k) => ({
      n: Number.isInteger(i.n) ? i.n : k + 1,
      kind: text(i.kind) || "other",
      label: text(i.label),
      detail: text(i.detail),
      next: text(i.next),
      artifactId: text(i.artifactId),
      actionIds: Array.isArray(i.actionIds) ? i.actionIds.filter((a) => a != null).map(String) : [],
    }));
  if (!items.length) return null;
  return { lead: text(d.lead) || deliveredLead(items.length), items };
}

const NUMBER_WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"];

/** "I've delivered two things:" — said from the count when the engine sent no lead. Pure. */
export function deliveredLead(n) {
  const word = NUMBER_WORDS[n] || String(n);
  return n === 1 ? "I've delivered one thing:" : `I've delivered ${word} things:`;
}

function jeOf(je) {
  if (!isObj(je) || !Array.isArray(je.lines)) return null;
  return je;
}

function entryOf(e, k, of) {
  if (!isObj(e)) return null;
  const je = jeOf(e.je);
  if (!je) return null;
  // The block's own note and, for an entry approved on another task's card, that task
  // (`elsewhere`) are kept (w19 contract, W5-4: dropping `note` drew "This entry can't be
  // approved until that's resolved." under "Ready to approve on its card in …").
  const block = isObj(e.block) && text(e.block.words)
    ? { words: text(e.block.words), action: isObj(e.block.action) ? e.block.action : null, note: text(e.block.note), elsewhere: text(e.block.elsewhere) }
    : null;
  return {
    n: Number.isInteger(e.n) ? e.n : k + 1,
    of,
    actionId: e.actionId != null ? String(e.actionId) : null,
    entryId: text(e.entryId),
    title: text(e.title) || text(je.memo) || "Journal entry",
    // The entry's kind when the engine names each entry by it ("Reclassification").
    name: text(e.name),
    status: ["draft", "approved", "posted"].includes(e.status) ? e.status : "draft",
    date: text(e.date) || text(je.date),
    je,
    // A blocked entry is never ready, whatever else it says.
    ready: block ? false : e.ready !== false,
    block,
    mayApprove: e.mayApprove === true ? true : e.mayApprove === false ? false : null,
    whyNot: text(e.whyNot),
  };
}

function entriesOf(x) {
  if (!isObj(x) || !Array.isArray(x.items)) return null;
  const raw = x.items.filter(isObj);
  // `of` is what the screen shows, so it is the list's own length: a headline that says
  // 3 over two cards is the defect this block exists for.
  const items = raw.map((e, k) => entryOf(e, k, raw.length)).filter(Boolean).map((e, k, all) => ({ ...e, n: k + 1, of: all.length }));
  if (!items.length) return null;
  const bulk = isObj(x.bulk) && x.bulk.actionId != null && text(x.bulk.label)
    ? {
        label: text(x.bulk.label),
        actionId: String(x.bulk.actionId),
        covers: Array.isArray(x.bulk.covers) ? x.bulk.covers.map(String) : [],
        figureRef: text(x.bulk.figureRef),
      }
    : null;
  return { headline: text(x.headline), items, bulk };
}

function ledgerOf(l) {
  if (!isObj(l)) return null;
  return {
    configured: l.configured === true,
    displayName: text(l.displayName),
    platform: text(l.platform),
    createsDraft: l.createsDraft === true,
    postingEffect: text(l.postingEffect),
    // Whose books, and the sentence for each entry kind (staging D1, 26 Oct 2026).
    organisation: text(l.organisation),
    postingEffects: isObj(l.postingEffects)
      ? Object.fromEntries(Object.entries(l.postingEffects).filter(([, v]) => text(v)).map(([k, v]) => [k, text(v)]))
      : {},
  };
}

/**
 * Every block ShapeBlocks draws under the verdict, named once (prod walk, 6 Nov 2026, D3).
 * The answer decided "is there a shape to draw?" from its own hand-kept list, which had
 * fallen behind: a supplier statement rec, a customer statement, the GST report, the trial
 * balance and Account Transactions arrived valid and were never drawn. The answer, the
 * blocks and `shapeOf` all ask here. `entries` is not a block: its cards are drawn apart
 * (ShapeEntries).
 */
export const BLOCK_KEYS = Object.freeze(["work", "tieOut", "delivered", "bankRec", "agedBalances", "reminders", "unusualBalances", "statements", "cashCoding", "billInbox", "smallBalances", "documents", "pettyCash", "trialBalance", "accountTransactions", "gstReport", "customerStatement", "supplierStatementRec", "schedule"]);

/** Does `shape` hold a block ShapeBlocks draws? Pure. */
export function hasBlocks(shape) {
  return isObj(shape) && BLOCK_KEYS.some((k) => Boolean(shape[k]));
}

/**
 * The payload's `shape`, read: `{work, tieOut, delivered, entries, ledger}`, each null when
 * absent or unreadable, or null when nothing in it can be drawn. Pure.
 */
export function shapeOf(raw) {
  if (!isObj(raw)) return null;
  const out = {
    work: workOf(raw.work),
    tieOut: tieOutOf(raw.tieOut),
    delivered: deliveredOf(raw.delivered),
    entries: entriesOf(raw.entries),
    ledger: ledgerOf(raw.ledger),
    // The bank rec's rows, as Xero's reconcile screen lays them out (BankRecRows.js).
    bankRec: bankRecOf(raw.bankRec),
    // Aged receivables and payables, and the reminder drafts (W3 feature 1, 28 Oct 2026;
    // AgedBalances.js, ReminderDrafts.js).
    agedBalances: agedBalancesOf(raw.agedBalances),
    reminders: remindersOf(raw.reminders),
    // The trial balance review (close list Step 4, w4/checks; UnusualBalances.js).
    unusualBalances: unusualBalancesOf(raw.unusualBalances),
    // The month's profit and loss, balance sheet and cash flow, with their two checks
    // (W4 Step 5, 29 Oct 2026; Statements.js).
    statements: statementsOf(raw.statements),
    // "Cash code": the first lines to code, and how many more (w25 contract v2 §4;
    // CashCodingLines.js). The coding is done on the Cash coding view.
    cashCoding: cashCodingShapeOf(raw.cashCoding),
    // "Approve the bills": the bill inbox's waiting items and one Approve press for the
    // ready ones (w33 D4; BillInbox.js).
    billInbox: billInboxShapeOf(raw.billInbox),
    // "Write off the small balances in AR" (w47, audit row 19; SmallBalances.js): the
    // part-paid invoices and bills with a few cents left, and one press to clear them.
    // Kept as the engine sent it: the card reads it through smallBalancesShapeOf itself.
    smallBalances: smallBalancesShapeOf(raw.smallBalances) ? raw.smallBalances : null,
    // "What documents are missing for October" (w33, audit 1.1; DocumentsCard.js). Kept
    // as the engine sent it: the card reads it through documentsShapeOf itself.
    documents: documentsShapeOf(raw.documents) ? raw.documents : null,
    // "Record petty cash $25 for milk" (w33, audit 1.3a; PettyCash.js).
    pettyCash: pettyCashShapeOf(raw.pettyCash) ? raw.pettyCash : null,
    // The full trial balance as at a date, flags on its rows, and Account Transactions
    // (close Step 4.1 and 4.2, w31; components/reports/).
    // Kept as the engine sent them once they read as the contract says: the cards read
    // them again themselves (TrialBalance.js, AccountTransactions.js).
    trialBalance: trialBalanceOf(raw.trialBalance) ? raw.trialBalance : null,
    accountTransactions: accountTransactionsOf(raw.accountTransactions) ? raw.accountTransactions : null,
    // The GST report for a month or a quarter (w42, audit row 22; GstReport.js): GST by
    // tax rate and the checks; its tie-out to the GST account rides as `tieOut`.
    gstReport: gstReportOf(raw.gstReport) ? raw.gstReport : null,
    // One customer's statement (w46, audit row 20; CustomerStatement.js), read strictly
    // there again.
    customerStatement: customerStatementOf(raw.customerStatement) ? raw.customerStatement : null,
    // A supplier's statement against the ledger (w49, audit row 21;
    // SupplierStatementRec.js), read strictly there again.
    supplierStatementRec: supplierStatementRecOf(raw.supplierStatementRec) ? raw.supplierStatementRec : null,
    // "Every Friday check the bills" (w48, audit row 23; ScheduleCard.js): one change to
    // Scheduled, set up only by the person's press.
    schedule: scheduleShapeOf(raw.schedule) ? raw.schedule : null,
  };
  return out.entries || hasBlocks(out) ? out : null;
}

/**
 * Which entries are drawn as cards and which as compact rows: all of them up to
 * ENTRY_CARD_LIMIT, else the first CARDS_ABOVE_LIMIT as cards and the rest as rows. Never
 * a bare count. Pure.
 */
export function entryLayout(items) {
  const list = Array.isArray(items) ? items : [];
  if (list.length <= ENTRY_CARD_LIMIT) return { cards: list, rows: [] };
  return { cards: list.slice(0, CARDS_ABOVE_LIMIT), rows: list.slice(CARDS_ABOVE_LIMIT) };
}

/** "1 of 3", or "1 of 2 · Reclassification" when the engine names the entry by its kind. Pure. */
export function entryNumber(entry) {
  if (!entry) return null;
  const name = typeof entry.name === "string" && entry.name ? entry.name : null;
  if (!(entry.of > 1)) return name;
  return `${entry.n} of ${entry.of}` + (name ? ` · ${name}` : "");
}

/**
 * The action ids an answer's shape draws itself: each entry's card and the bulk card.
 * The thread does not draw those decisions a second time on their own. Pure.
 */
export function shapeActionIds(shape) {
  const out = new Set();
  const e = shape && shape.entries;
  if (!e) return out;
  for (const item of e.items) if (item.actionId != null) out.add(item.actionId);
  if (e.bulk && e.bulk.actionId != null) out.add(e.bulk.actionId);
  return out;
}

/** The entry total as cents, from the engine's own totals (never summed here). Pure. */
export function entryTotalCents(je) {
  const t = je && je.totals;
  if (isObj(t) && Number.isInteger(t.debitCents)) return t.debitCents;
  return null;
}

/* ── THE APPROVE-ENTRIES PANE OPENS ON THE ENTRIES (founder, 17 Oct 2026) ──────────────
   "it says 3 entries but it is not clear and intuitive enough". The pane of a result
   about entries opened on Summary & Flags, a table that only repeated the stat tiles, and
   nowhere on screen were the entries themselves. Now: the pane opens on its Entries
   sheet, a summary sheet that only repeats the tiles is not a tab, and the Entries sheet
   draws every entry the answer is about as its own numbered card with its lines. */

/** The templates whose result is a list of entries to approve. */
export const ENTRIES_TEMPLATES = Object.freeze(new Set(["approve_entries"]));
/** The sheet such a result opens on. */
export const ENTRIES_SHEET = "Entries";

function templateOfArtifact(artifact) {
  if (!isObj(artifact)) return "";
  if (typeof artifact.template === "string" && artifact.template) return artifact.template;
  // "2026-07-approve_entries:entries": the session id's template (after the period)
  // before the colon, the artifact's own key after it. Either names the template.
  const id = typeof artifact.artifactId === "string" ? artifact.artifactId : "";
  const at = id.lastIndexOf(":");
  const head = (at >= 0 ? id.slice(0, at) : id).replace(/^\d{4}-\d{2}-/, "");
  if (ENTRIES_TEMPLATES.has(head)) return head;
  return at >= 0 ? id.slice(at + 1) : id;
}

/**
 * The entries an open result is about, from the latest answer whose shape names it
 * (`work.artifactId`, a delivered item's `artifactId`, or the answer's own delivered
 * file), as `{items, headline, ledger, figures}`, or null. Pure.
 */
export function paneEntriesFor(items, artifactId) {
  if (!artifactId) return null;
  const list = Array.isArray(items) ? items : [];
  for (let k = list.length - 1; k >= 0; k -= 1) {
    const it = list[k];
    const shape = it && it.kind === "answer" ? it.shape : null;
    if (!shape || !shape.entries) continue;
    const named =
      (shape.work && shape.work.artifactId === artifactId) ||
      (shape.delivered && shape.delivered.items.some((d) => d.artifactId === artifactId)) ||
      (Array.isArray(it.delivered) && it.delivered.some((d) => d && d.artifactId === artifactId));
    if (named) return { items: shape.entries.items, headline: shape.entries.headline, ledger: shape.ledger, figures: it.figures || {} };
  }
  return null;
}

/**
 * Whether a result is an entries pane: its TEMPLATE lists entries (approve_entries). A
 * schedule whose answer also carries an entry card (a prepaid release, a depreciation
 * entry) is not one (verify pass 5, D18 pane): read as one, the prepaid pane lost its
 * Summary & Flags tab though the workbook and the answer both list it. `entries` is
 * kept in the signature for the callers that pass it; it no longer decides. Pure.
 */
// eslint-disable-next-line no-unused-vars
export function isEntriesPane(artifact, entries = null) {
  return ENTRIES_TEMPLATES.has(templateOfArtifact(artifact));
}

/** A sheet that is the workbook's summary (Summary & Flags): it only repeats the tiles. Pure. */
export function isSummarySheet(sheet) {
  return Boolean(sheet && typeof sheet.name === "string" && /^summary\b/i.test(sheet.name.trim()));
}

/**
 * The tabs an entries pane draws and the one it opens on: every sheet but the summary,
 * opening on Entries. Any other result: its sheets as they are, no opinion. Pure.
 */
export function entriesPaneSheets(artifact, entries = null) {
  const sheets = isObj(artifact) && isObj(artifact.table) && Array.isArray(artifact.table.sheets) ? artifact.table.sheets : [];
  if (!isEntriesPane(artifact, entries)) return { sheets, opensOn: null };
  const kept = sheets.filter((s) => !isSummarySheet(s));
  const list = kept.length ? kept : sheets;
  return { sheets: list, opensOn: list.some((s) => s && s.name === ENTRIES_SHEET) ? ENTRIES_SHEET : null };
}
