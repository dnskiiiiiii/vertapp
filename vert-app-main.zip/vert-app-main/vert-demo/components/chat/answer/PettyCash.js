"use client";

// components/chat/answer/PettyCash.js — THE PETTY CASH SPEND, AND THE ONE PRESS THAT APPROVES IT
// ==============================================================================
// Audit 1.3a (3 Nov 2026). Under the verdict: From (the petty cash account), To (the
// account and tax rate), the date, what it was for and the amount, then "Approve". Xero
// has no draft Spend Money, so this press is the check: it asks once more ("Create this
// Spend Money in Xero?"), then settles the decision through the cash coding road's own
// server action (lib/agent/actions.js approveCoding, as BankRecRows.js: the approve role and
// drafter-can't-approve are the engine's). What the engine says it did is drawn under it.
// Remember sits beside Approve, unticked: ticked, the coding is saved as a rule (founder
// decision, 3 Nov 2026; engine w36), and "Rule saved" is said when the engine saved one.

import { useState } from "react";

import { Button, RememberTick, RuleSaved } from "@/components/ui";
import { formatDay, formatMoney } from "@/lib/format";
import { approveCoding } from "@/lib/agent/actions";
import { useWritesEnabled } from "@/lib/engine-context";
import { pettyCashShapeOf } from "./petty-cash";

const SAMPLE_REASON = "These are the sample books, so nothing can be approved here.";
const LOST = "The approval didn't come back. It may have gone through: check the decision before pressing again.";

export default function PettyCash({ pettyCash, ledgerName = null }) {
  const view = pettyCashShapeOf(pettyCash);
  const writes = useWritesEnabled();
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [said, setSaid] = useState(null);
  const [remember, setRemember] = useState(false);
  if (!view) return null;
  const press = async () => {
    if (busy) return;
    setBusy(true);
    const result = await approveCoding(view.actionId, null, { remember }).catch(() => ({ ok: false, message: LOST }));
    setBusy(false);
    setConfirming(false);
    const decided = result && result.decision && typeof result.decision.words === "string" ? result.decision.words : null;
    setSaid({ ok: Boolean(result && result.ok), words: (result && (result.words || decided || result.message)) || (result && result.ok ? "Approved." : LOST), remembered: result && result.ok ? result.remembered || null : null });
  };
  return (
    <section className="cc-answer" data-petty-cash="" aria-label="Petty cash spend">
      <dl className="shape-more">
        <div><dt className="ink-2">From</dt> <dd translate="no">{view.account}</dd></div>
        <div><dt className="ink-2">To</dt> <dd translate="no">{view.to}{view.taxName ? `, ${view.taxName}` : ""}</dd></div>
        <div><dt className="ink-2">For</dt> <dd>{view.description}{view.date ? `, ${formatDay(view.date)}` : ""}</dd></div>
        <div><dt className="ink-2">Amount</dt> <dd className="num" translate="no">{formatMoney(view.amountCents)}</dd></div>
      </dl>
      <p className="ink-2">{view.words}</p>
      {said ? (
        <p role="status" className={said.ok ? null : "ink-2"} data-petty-cash-outcome="">
          {said.words}
          {said.remembered ? (
            <>
              {" · "}
              <RuleSaved remembered={said.remembered} />
            </>
          ) : null}
        </p>
      ) : confirming ? (
        <p role="group" aria-label="Confirm approval">
          Create this Spend Money in {ledgerName || "your ledger"}?{" "}
          <Button variant="commit" size="sm" busy={busy} busyLabel="Approving…" onClick={press} data-petty-cash-send="">
            Approve
          </Button>{" "}
          <Button variant="secondary" size="sm" onClick={() => setConfirming(false)}>
            Cancel
          </Button>{" "}
          <RememberTick name={`remember-${view.actionId}`} checked={remember} onChange={setRemember} />
        </p>
      ) : (
        <p>
          <Button variant="secondary" size="sm" disabledReason={writes ? undefined : SAMPLE_REASON} onClick={() => setConfirming(true)} data-petty-cash-approve="">
            Approve
          </Button>{" "}
          <RememberTick name={`remember-${view.actionId}`} checked={remember} onChange={setRemember} />
        </p>
      )}
    </section>
  );
}
