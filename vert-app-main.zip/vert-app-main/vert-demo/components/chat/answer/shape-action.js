// components/chat/answer/shape-action.js — AN ENTRY'S ONE PRIMARY ACTION, WORDED BY THE LEDGER
// ==============================================================================
// The wording half of ./shape.js (kept apart so lib/agent/events.js can read `shape`
// without importing the cards' words, which import events.js). The label comes from
// words.js postActionLabel / approveActionLabel with the ledger target's createsDraft,
// never a hard-coded "Post to <ledger>"; Vert's approval rule stands (a reviewer or admin
// approves, the drafter can't approve their own entry), so a viewer who may not approve
// gets a plain line saying who does.

import { approveActionLabel, postActionLabel, splitLedgerName } from "@/components/cards/words";
import { postingEffectOf } from "@/components/cards/ledger-effect";
import { gateSentence } from "@/lib/roles";

const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

/** The ledger's name as a button says it: the descriptor's, else the page's. Pure. */
export function ledgerNameOf(ledger, ledgerName = null) {
  const own = ledger && ledger.displayName;
  return text(own) || text(ledgerName);
}

/**
 * THE ONE PRIMARY ACTION OF AN ENTRY, role-aware and worded by the ledger target:
 *
 *   blocked                       → none (the block's own action stands instead)
 *   posted                        → none
 *   may approve, draft            → "Approve and post to QuickBooks" / "Approve and send to Xero as draft"
 *   approved                      → "Post to QuickBooks" / "Send to Xero as draft"
 *   may not approve (or unknown)  → a plain line saying who approves
 *   no ledger connected           → "Approve" with the ledger's absence said beside it
 *
 * `{kind: "commit", label, effect}` or `{kind: "line", words}` or null. The label is
 * never a hard-coded "Post to <ledger>": it comes from words.js postActionLabel with the
 * target's createsDraft. Pure.
 */
export function primaryActionOf(entry, ledger, ledgerName = null) {
  if (!entry || entry.block || !entry.ready || entry.status === "posted") return null;
  const name = ledgerNameOf(ledger, ledgerName);
  const connected = Boolean(ledger && ledger.configured && name);
  // A recording ledger is worded by its platform too (verify pass 5, Q-SHAPE-4): the
  // label names it ("Approve and post to QuickBooks Online", words.js strips the note)
  // and the engine's posting effect ("nothing is sent to QuickBooks") stands beside it.
  const draft = Boolean(ledger && ledger.createsDraft);
  // The entry's own sentence (its `je.entryKind`), naming the organisation (staging D1).
  const effect = connected ? postingEffectOf(ledger, ledgerName, entry.je) : null;
  if (entry.status === "approved") {
    if (!connected) return { kind: "line", words: "Approved. It goes to your ledger once one is connected." };
    return { kind: "commit", label: postActionLabel(name, { draft }), effect };
  }
  if (entry.mayApprove !== true) {
    return { kind: "line", words: gateSentence(entry.whyNot) || "A reviewer approves this entry." };
  }
  if (!connected) return { kind: "commit", label: "Approve", effect: null };
  return { kind: "commit", label: approveActionLabel(name, { draft }), effect };
}

/**
 * A delivered item's "what happens next", with "your ledger" named when it is known, and
 * worded for who is reading (verify pass 5, Q-SHAPE-4 #40): "Once a reviewer approves
 * it" was shown to the reviewer or admin who approves it. When the read says this viewer
 * may approve the answer's entries (`viewerApproves`), it reads "Once you approve it".
 * Pure.
 */
export function nextWords(next, ledger, ledgerName = null, { viewerApproves = false, who = null } = {}) {
  let words = text(next);
  if (!words) return null;
  words = reviewerWords(words, who || (viewerApproves ? "you" : null));
  const name = ledger && ledger.configured ? ledgerNameOf(ledger, ledgerName) : null;
  return name && !splitLedgerName(name).recording ? words.replace(/\byour ledger\b/g, name) : words;
}

/**
 * The answer's gate clause worded for the viewer (verify pass 6, Q-SHAPE-4 / Q05 line 7):
 * the engine writes "Nothing posts until you approve it." into the stored answer, and a
 * preparer, whom the read says may approve none of the entries, read it as hers to do.
 * For that viewer it says who approves. Any other viewer, or a read that could not tell,
 * keeps the engine's words. Pure.
 */
export function gateWordsFor(text, shape) {
  if (typeof text !== "string") return text;
  const items = shape && shape.entries && Array.isArray(shape.entries.items) ? shape.entries.items : [];
  const nobodyHere = items.length > 0 && items.every((i) => i && i.mayApprove === false);
  const own = nobodyHere ? text.replace(/\bNothing posts until you approve (it|them)\b/g, "Nothing posts until a reviewer approves $1") : text;
  return reviewerWords(own, whoApprovesOf(shape));
}

/**
 * WHO APPROVES, FOR THE VIEWER (verify pass 7, Q-SHAPE-4): "you" when the read says this
 * viewer may approve an entry here; "other" when it says they may approve none because
 * they drafted them (an admin who ran the rec read "ready for a reviewer", a role word
 * that is not theirs to wait on: any other reviewer or admin may approve); null when
 * the read can't tell, or the viewer is a preparer (a reviewer approves, as said). Pure.
 */
export function whoApprovesOf(shape) {
  const items = shape && shape.entries && Array.isArray(shape.entries.items) ? shape.entries.items : [];
  if (items.some((i) => i && i.mayApprove === true)) return "you";
  const drafted = (i) => i && i.mayApprove === false && /\byou drafted\b|\bstarted the plan\b/i.test(String(i.whyNot || ""));
  return items.length > 0 && items.every(drafted) ? "other" : null;
}

const SOMEONE = "someone else at your firm";

/**
 * The engine's "a reviewer" sentences worded for `who` (see whoApprovesOf): "Ready for a
 * reviewer below", "1 entry, $15.00: ready for a reviewer.", "Nothing posts until a
 * reviewer approves it", "once a reviewer approves it". Unknown `who` keeps them. Pure.
 */
export function reviewerWords(words, who) {
  if (typeof words !== "string" || (who !== "you" && who !== "other")) return words;
  const you = who === "you";
  return words
    .replace(/\b([Rr])eady for a reviewer\b/g, (_, r) => (you ? `${r}eady for your approval` : `${r}eady for ${SOMEONE} to approve`))
    .replace(/\b([Nn])othing posts until a reviewer approves (it|them)\b/g, (_, n, it) => (you ? `${n}othing posts until you approve ${it}` : `${n}othing posts until ${SOMEONE} approves ${it}`))
    .replace(/\b([Oo])nce a reviewer approves (it|them)\b/g, (_, o, it) => (you ? `${o}nce you approve ${it}` : `${o}nce ${SOMEONE} approves ${it}`));
}

/** Whether the read says this viewer may approve the shape's entries (any of them). Pure. */
export function viewerApprovesOf(shape) {
  const items = shape && shape.entries && Array.isArray(shape.entries.items) ? shape.entries.items : [];
  return items.some((i) => i && i.mayApprove === true);
}

