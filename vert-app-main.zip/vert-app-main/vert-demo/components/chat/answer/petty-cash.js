// components/chat/answer/petty-cash.js — A PETTY CASH SPEND DRAFTED FROM CHAT, READ FROM THE ENGINE
// ==============================================================================
// Audit 1.3a (3 Nov 2026; w33 contract §4, agent_events.ShapePettyCash). "record petty
// cash $25 for milk" drafts a Spend Money from the chart's petty cash account as ONE
// coding decision (`actionId`, kind coding_approve). PettyCash.js draws it with one
// Approve press, which settles the decision through cash coding's own road.
//
// A lookup only; a block that doesn't read as the contract says is dropped whole.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

/** The engine's `shape.pettyCash`, checked, or null. Pure. */
export function pettyCashShapeOf(raw) {
  if (!isObj(raw) || !text(raw.actionId) || !text(raw.account) || !text(raw.description) || !text(raw.accountCode) || !text(raw.words)) return null;
  if (!Number.isInteger(raw.amountCents) || raw.amountCents <= 0) return null;
  return {
    actionId: text(raw.actionId),
    account: text(raw.account),
    date: text(raw.date),
    description: text(raw.description),
    amountCents: raw.amountCents,
    to: [text(raw.accountCode), text(raw.accountName)].filter(Boolean).join(" "),
    taxName: text(raw.taxName),
    words: text(raw.words),
  };
}
