// components/chat/answer/write-off.js — A BAD-DEBT WRITE-OFF, READ FROM THE ENGINE
// ==============================================================================
// W4 (29 Oct 2026), the close list's "write off any uncollectible bad debts". The engine
// (vert_api/routers/write_offs.py) keeps each write-off: the invoice it is for, the amount,
// the bad debts account, who drafted and approved it, and, once approved, the DRAFT credit
// note it created in the ledger (or the fields to enter by hand when the connection may not
// write). This reads that object for the card (WriteOff.js), whole or not at all: a
// malformed answer is null, never half-drawn.
//
// Every figure is the engine's integer; nothing here computes one. A link out is only ever
// a secure one. A credit note is what the ledger RETURNED: a DRAFT, or (since 4 Nov 2026,
// for a client whose documents go in approved) AUTHORISED, or unsaid (null); any other
// status is a malformed answer. An approved credit note is also allocated to the invoice
// it writes off, and `allocation` says how that went: allocated, refused by the ledger, or
// unconfirmed. `documentModeOf` reads the list's and the approve answer's `documentMode`.

export const STATUSES = Object.freeze(["drafted", "sent", "unconfirmed", "manual", "failed", "discarded"]);
const CREDIT_STATUSES = new Set(["DRAFT", "AUTHORISED"]);
const ALLOCATION_STATUSES = new Set(["allocated", "refused", "unconfirmed"]);
/** The two answers `documentMode` may give (4 Nov 2026). */
export const DOCUMENT_MODES = Object.freeze(["draft", "authorised"]);
// "unread": the engine couldn't read the chart; its words say so (never "none").
const CHOICES = new Set(["one", "several", "none", "unread", "expense"]);

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const isInt = (v) => Number.isInteger(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const textOr = (v) => (typeof v === "string" ? v.trim() : null);
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;
const day = (v) => (typeof v === "string" && ISO_DAY.test(v) ? v : null);
const link = (v) => (typeof v === "string" && /^https:\/\//.test(v) ? v : null);

function invoiceOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !isInt(raw.amountDueCents)) return null;
  return {
    id: text(raw.id),
    number: text(raw.number),
    contactId: text(raw.contactId),
    contactName: text(raw.contactName),
    currency: text(raw.currency),
    amountDueCents: raw.amountDueCents,
    totalCents: isInt(raw.totalCents) ? raw.totalCents : null,
    dueDate: day(raw.dueDate),
    url: link(raw.url),
  };
}

function creditNoteOf(raw) {
  if (raw === null || raw === undefined) return { ok: true, value: null };
  const status = raw && raw.status === undefined ? null : raw && raw.status;
  if (!isObj(raw) || !text(raw.id) || (status !== null && !CREDIT_STATUSES.has(status))) return { ok: false };
  return { ok: true, value: { id: text(raw.id), number: text(raw.number), url: link(raw.url), status } };
}

function allocationOf(raw) {
  if (raw === null || raw === undefined) return { ok: true, value: null };
  if (!isObj(raw) || !ALLOCATION_STATUSES.has(raw.status)) return { ok: false };
  if (raw.amountCents !== null && raw.amountCents !== undefined && !isInt(raw.amountCents)) return { ok: false };
  return { ok: true, value: { status: raw.status, amountCents: isInt(raw.amountCents) ? raw.amountCents : null, invoiceNumber: text(raw.invoiceNumber), words: text(raw.words) } };
}

/** The `documentMode` an answer carries ("draft" | "authorised"), or null when unsaid. */
export function documentModeOf(raw) {
  return isObj(raw) && DOCUMENT_MODES.includes(raw.documentMode) ? raw.documentMode : null;
}

function fieldsOf(raw) {
  if (raw === null || raw === undefined) return { ok: true, value: null };
  if (!isObj(raw)) return { ok: false };
  const out = [];
  for (const [label, value] of Object.entries(raw)) {
    if (typeof value !== "string" && typeof value !== "number") return { ok: false };
    out.push([label, String(value)]);
  }
  return { ok: true, value: out };
}

function allocateOf(raw) {
  if (raw === null || raw === undefined) return { ok: true, value: null };
  if (!isObj(raw) || !text(raw.words)) return { ok: false };
  return { ok: true, value: { words: text(raw.words), invoiceUrl: link(raw.invoiceUrl), creditNoteUrl: link(raw.creditNoteUrl) } };
}

function eventsOf(raw) {
  if (!Array.isArray(raw)) return [];
  return raw.filter((e) => isObj(e) && isInt(e.seq) && text(e.event)).map((e) => ({ seq: e.seq, event: text(e.event), actor: text(e.actor), at: text(e.at) }));
}

/** One write-off as the card draws it, or null. Idempotent: it reads its own output. */
export function writeOffOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !STATUSES.includes(raw.status) || !isInt(raw.amountCents)) return null;
  const invoice = invoiceOf(raw.invoice);
  if (!invoice) return null;
  if (!isObj(raw.account) || !text(raw.account.code)) return null;
  const credit = creditNoteOf(raw.creditNote);
  const fields = fieldsOf(Array.isArray(raw.fields) ? Object.fromEntries(raw.fields) : raw.fields);
  const allocate = allocateOf(raw.allocate);
  const allocation = allocationOf(raw.allocation);
  if (!credit.ok || !fields.ok || !allocate.ok || !allocation.ok) return null;
  return {
    id: text(raw.id),
    // What it is (w47): a bad debt, or the small balance left on an invoice or a bill.
    kind: raw.kind === "small_balance" ? "small_balance" : "bad_debt",
    side: raw.side === "payables" ? "payables" : "receivables",
    status: raw.status,
    statusWords: text(raw.statusWords),
    words: text(raw.words),
    invoice,
    amountCents: raw.amountCents,
    currency: text(raw.currency) || invoice.currency,
    account: { code: text(raw.account.code), name: textOr(raw.account.name) || "" },
    reason: textOr(raw.reason) || "",
    date: day(raw.date),
    draftedBy: text(raw.draftedBy),
    draftedAt: text(raw.draftedAt),
    approvedBy: text(raw.approvedBy),
    approvedAt: text(raw.approvedAt),
    creditNote: credit.value,
    fields: fields.value,
    allocate: allocate.value,
    allocation: allocation.value,
    events: eventsOf(raw.events),
  };
}

/** `{writeOffs: [...]}` → the list, read whole, or null. */
export function writeOffsOf(raw) {
  const list = isObj(raw) ? raw.writeOffs : raw;
  if (!Array.isArray(list)) return null;
  const out = list.map(writeOffOf);
  return out.some((w) => !w) ? null : out;
}

/** The bad debts accounts the chart offers: one (chosen for the person), several (they
 *  choose) or none (the engine's words say what to do), or null when unreadable. */
export function writeOffAccountsOf(raw) {
  if (!isObj(raw) || !CHOICES.has(raw.choice) || !Array.isArray(raw.accounts)) return null;
  const accounts = raw.accounts.map((a) => (isObj(a) && text(a.code) ? { code: text(a.code), name: textOr(a.name) || "", accountId: text(a.accountId) } : null));
  if (accounts.some((a) => !a)) return null;
  if (raw.choice === "one" && accounts.length !== 1) return null;
  if ((raw.choice === "none" || raw.choice === "unread") && accounts.length) return null;
  // No bad debts account, so the chart's expense accounts, one to be chosen (founder's
  // manual test, 7 Nov 2026, D16): an empty list there is nothing to choose from.
  if (raw.choice === "expense" && !accounts.length) return null;
  return { accounts, choice: raw.choice, words: text(raw.words) };
}

/**
 * The approve press, saying which happens (4 Nov 2026): "as awaiting payment" when the
 * client's documents go in approved, "as a draft" otherwise — also when the mode is
 * unread, because a draft is what the engine sends on an unread setting. Pure.
 */
export function approveWriteOffLabel(documentMode, ledger) {
  const name = text(ledger) || "your ledger";
  return documentMode === "authorised" ? `Approve and send to ${name} as awaiting payment` : `Approve and send to ${name} as a draft`;
}

/**
 * What a sent write-off says about its credit note and its allocation, from what the
 * ledger returned. `{ heading, allocation: {status, words} | null, instruction }`, where
 * `instruction` is how to finish it in the ledger, or null once nothing is left. Pure.
 */
export function sentWordsOf(w, { ledger = "your ledger", money = (c) => String(c) } = {}) {
  const cn = w && w.creditNote;
  const number = (w && w.invoice && w.invoice.number) || "the invoice";
  const tail = cn && cn.number ? ` (${cn.number})` : "";
  const heading =
    cn && cn.status === "AUTHORISED" ? `Credit note approved in ${ledger}${tail}` : cn && cn.status === "DRAFT" ? `Draft credit note created in ${ledger}${tail}` : `Credit note created in ${ledger}${tail}`;
  const a = w && w.allocation;
  const told = w && w.allocate ? w.allocate.words : null;
  if (!a) return { heading, allocation: null, instruction: told };
  if (a.status === "allocated") {
    const amount = Number.isInteger(a.amountCents) ? a.amountCents : w.amountCents;
    return { heading, allocation: { status: "allocated", words: `Allocated ${money(amount)} to ${a.invoiceNumber || number}.` }, instruction: told };
  }
  const fallback = a.status === "refused" ? `${ledger} refused the allocation to ${a.invoiceNumber || number}.` : `Vert couldn’t confirm the allocation to ${a.invoiceNumber || number} reached ${ledger}.`;
  return { heading, allocation: { status: a.status, words: a.words || fallback }, instruction: told || `Allocate it to ${a.invoiceNumber || number} in ${ledger}.` };
}

/** "684 Bad Debts". */
export function accountWords(account) {
  if (!account) return "";
  return [account.code, account.name].filter(Boolean).join(" ");
}
