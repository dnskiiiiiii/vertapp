"use client";

// components/chat/answer/UnusualBalances.js — THE TRIAL BALANCE REVIEW, AS DRAWN
// ==============================================================================
// The close list's Step 4 (w4/checks, 29 Oct 2026). Under the verdict, in the order a
// reviewer reads a trial balance:
//
//   1. the head: "Trial balance review", as at the month end, and how many accounts the
//      engine checked;
//   2. each balance on its unusual side: the account, what is unusual in one word
//      (Overdrawn, Below zero, Wrong side, Refund due), its side and size, and why;
//   3. the balances it couldn't read, by name (never counted as clean);
//   4. behind a disclosure, the accounts it looked at and left alone, each with why
//      (a contra account on its normal side, an account either side is normal for).
//
// SHOW THE WORK INLINE (answer-shape reference, 17 Oct 2026). Every amount is the
// engine's integer (unusual-balances.js); nothing is summed here. A review the engine
// didn't read says the engine's words, never "nothing unusual". An overdraft is a
// position, not an error, so only a wrong-side or negative-stock balance takes the
// attention ink; the word beside it already says which.

import "./unusual-balances.css";
import { formatDate } from "@/lib/format";
import { unusualBalancesOf } from "./unusual-balances";
import { moneyIn } from "./aging-money";

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const ATTENTION = new Set(["wrong_side", "negative_inventory"]);

/** The flag's currency: its figure's, as the engine sent it; the books' AUD without one. */
function currencyOf(figures, ref) {
  const f = figures && typeof figures === "object" ? figures[ref] : null;
  return f && typeof f.currency === "string" && f.currency ? f.currency : "AUD";
}

/** The line under the head. A partial read never says "none" of what it didn't read. */
export function headWords(review) {
  const checked = plural(review.checked, "account", "accounts");
  if (review.flags.length) return `${checked} checked, ${plural(review.flags.length, "balance", "balances")} to look at.`;
  if (review.partial) return `${checked} checked, none of them on an unusual side; ${plural(review.unread.length, "balance", "balances")} couldn't be read.`;
  return `${checked} checked, none on an unusual side.`;
}

function FlagList({ flags, figures }) {
  return (
    <ul className="tb-flags">
      {flags.map((f) => (
        <li key={f.figureRef} className="tb-flag" data-tb-rule={f.rule} data-tone={ATTENTION.has(f.rule) ? "attention" : undefined}>
          <div className="tb-flag-head">
            <span className="tb-account">{f.withResult ? `${f.label}, including this year's result` : f.label}</span>
            <span className="tb-rule">{f.withResult ? "Accumulated losses" : f.ruleWords}</span>
            <span className="tb-amount">
              {moneyIn(f.amountCents, currencyOf(figures, f.figureRef))} <span className="tb-side">{f.side === "debit" ? "Dr" : "Cr"}</span>
            </span>
          </div>
          <p className="tb-reason">
            {f.basis === "movement" ? "This month's movement. " : null}
            {f.reason}
          </p>
        </li>
      ))}
    </ul>
  );
}

export default function UnusualBalances({ unusualBalances, figures = {} }) {
  const review = unusualBalancesOf(unusualBalances);
  if (!review) return null;
  return (
    <section className="tb-review" data-unusual-balances="" data-measured={review.measured ? "read" : "unread"} aria-label="Trial balance review">
      <header className="tb-head">
        <h4 className="tb-title">Trial balance review</h4>
        <span className="tb-asat">as at {formatDate(review.asAt)}</span>
      </header>
      {!review.measured ? (
        <p className="tb-unread" data-tb-unread="">
          Not read: {review.words}. An unread balance is unknown, not clean.
        </p>
      ) : (
        <>
          <p className="tb-words">{headWords(review)}</p>
          {review.flags.length ? <FlagList flags={review.flags} figures={figures} /> : null}
          {review.info.length ? (
            <div className="tb-notes" data-tb-info="">
              <p className="tb-notes-title">Worth knowing, not wrong</p>
              <FlagList flags={review.info} figures={figures} />
            </div>
          ) : null}
          {review.unread.length ? (
            <div className="tb-notes" data-tb-notread="">
              <p className="tb-notes-title">Not read, so not checked</p>
              <ul>
                {review.unread.map((n) => (
                  <li key={n.label}>
                    {n.label}: {n.why}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
          {review.normal.length ? (
            <details className="tb-notes" data-tb-normal="">
              <summary>{plural(review.normal.length, "account", "accounts")} left alone</summary>
              <ul>
                {review.normal.map((n) => (
                  <li key={n.label}>
                    {n.label}: {n.why}
                  </li>
                ))}
              </ul>
            </details>
          ) : null}
        </>
      )}
    </section>
  );
}
