// components/chat/answer/bill-inbox.js — "APPROVE THE BILLS" IN THE CHAT, READ FROM THE ENGINE
// ==============================================================================
// Demo rehearsal D4 (3 Nov 2026): "approve the bills" said nothing was attached while one
// waited in Scheduled → Bills & invoices. The engine now answers with the inbox itself as
// `shape.billInbox` (w33 contract §1, agent_events.ShapeBillInbox): the items waiting for
// review (at most 10 rows, and the count of all), the ids of the ones ready to approve,
// and the address of Bills & invoices. BillInbox.js draws it.
//
// Everything here is a lookup: amounts are the engine's integer cents, never summed. A
// block that doesn't read as the contract says is dropped whole (null). An unread inbox
// (`measured: false`) keeps its words and nothing else: never an empty list.
//
// It imports nothing but the bill model's id check and its reading of the ledger's
// returned status: components/chat/answer/shape.js
// reads `shape` through it.

import { isItemId, returnedStatusOf } from "../../../lib/bills-model.js";

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const count = (v) => (Number.isInteger(v) && v >= 0 ? v : null);
const KINDS = new Set(["bill", "invoice", "credit_note"]);
const DAY = /^\d{4}-\d{2}-\d{2}$/;

function rowOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !KINDS.has(raw.kind) || !text(raw.statusWords)) return null;
  const total = raw.totalCents === null || raw.totalCents === undefined ? null : Number.isInteger(raw.totalCents) ? raw.totalCents : undefined;
  if (total === undefined) return null;
  const href = text(raw.href);
  return {
    id: raw.id,
    kind: raw.kind,
    contact: text(raw.contact),
    number: text(raw.number),
    date: typeof raw.date === "string" && DAY.test(raw.date) ? raw.date : null,
    totalCents: total,
    // The ex-tax amount, only where no total was read (an invoice drafted from words).
    subtotalCents: total === null && Number.isInteger(raw.subtotalCents) ? raw.subtotalCents : null,
    currency: text(raw.currency),
    status: text(raw.status),
    statusWords: text(raw.statusWords),
    ready: raw.ready === true,
    href: href && href.startsWith("/") && !href.startsWith("//") ? href : null,
  };
}

/** The engine's `shape.billInbox`, checked, or null. Pure. */
export function billInboxShapeOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean" || !text(raw.words) || !Array.isArray(raw.rows)) return null;
  const rows = raw.rows.map(rowOf);
  if (rows.some((r) => !r)) return null;
  const waiting = count(raw.waiting);
  const ready = count(raw.ready);
  if (waiting === null || ready === null) return null;
  if (!raw.measured && rows.length) return null;
  const readyIds = Array.isArray(raw.readyIds) ? raw.readyIds.filter((id) => isItemId(id)) : [];
  const href = text(raw.href);
  return {
    period: text(raw.period),
    measured: raw.measured,
    words: text(raw.words),
    rows,
    waiting,
    ready,
    more: Math.max(0, waiting - rows.length),
    readyIds: raw.measured ? [...new Set(readyIds)] : [],
    href: href && href.startsWith("/") && !href.startsWith("//") ? href : "/scheduled?task=bills",
    // What an approval sends (w44): "authorised" or "draft"; anything else unread.
    documentMode: raw.documentMode === "authorised" || raw.documentMode === "draft" ? raw.documentMode : null,
  };
}

/**
 * How the confirm says where the press sends them: "as drafts", "approved, as awaiting
 * payment", or nothing when the client's mode wasn't read (the engine then sends drafts,
 * but the words don't guess). Pure.
 */
export function sendModeWords(mode, n) {
  if (mode === "authorised") return " approved, as awaiting payment";
  if (mode === "draft") return n === 1 ? " as a draft" : " as drafts";
  return "";
}

/** "Approve 1 bill", "Approve 3 bills": the press names exactly what it sends. */
export function approveLabel(n, rows = []) {
  const kinds = new Set(rows.filter((r) => r.ready).map((r) => r.kind));
  const [one, many] = kinds.size === 1 && kinds.has("invoice") ? ["invoice", "invoices"] : kinds.size > 1 ? ["item", "items"] : ["bill", "bills"];
  return `Approve ${n} ${n === 1 ? one : many}`;
}

// The ledger is named by the caller (the API's /approvals/ledger name), never here.
// "sent" is a draft only when the ledger RETURNED one: a client whose documents go in
// approved (4 Nov 2026) gets the engine's own sentence, built from Xero's returned status,
// or `approved in <ledger>, awaiting payment` (sentLine below).
const sentWords = (ledger) => ({
  sent: `Sent to ${ledger} as a draft`,
  authorised: `Approved in ${ledger}, awaiting payment`,
  submitted: `Sent to ${ledger}, waiting for approval there`,
  // An earlier send found in the ledger and kept (the engine's `already_in_<ledger>`).
  already: `Sent to ${ledger} as a draft (Vert found the earlier send and kept it)`,
  approved: `Approved: enter it in ${ledger} by hand`,
  unconfirmed: `Couldn't confirm it reached ${ledger}: check ${ledger} before trying again`,
});

// A sent line from what the ledger returned, never "as a draft" for an approved one. The
// engine's sentence wins wherever the send wasn't a plain draft.
function sentLine(status, r, SENT_WORDS) {
  if (status !== "sent" && status !== "already") return SENT_WORDS[status] || null;
  // What the ledger returned: the outcome's status, else the item's (the bill model reads both).
  const returned = returnedStatusOf(r.item, r.outcome);
  const engine = text(r.outcome && r.outcome.words);
  if (returned === "AUTHORISED") return engine || SENT_WORDS.authorised;
  if (returned === "SUBMITTED") return engine || SENT_WORDS.submitted;
  if (!returned && engine && !/\bas a draft\b/i.test(engine)) return engine;
  return SENT_WORDS[status];
}

/**
 * What each approval did, in words, from POST /api/bills/approve's `{results}` (lib/bills-
 * client.js approveMany). Pure. A whole refusal (`ok: false`) is one line with its words.
 */
export function approvedLines(answer, rows = [], ledger = "your ledger") {
  const SENT_WORDS = sentWords(ledger);
  if (!answer || answer.ok !== true || !Array.isArray(answer.results)) {
    return [{ id: null, name: null, ok: false, words: (answer && answer.message) || "Nothing was approved." }];
  }
  return answer.results.map((r) => {
    const known = rows.find((x) => x.id === r.itemId) || {};
    const name = (r.item && r.item.document && r.item.document.contactName) || known.contact || "A bill";
    const raw = r.ok && r.outcome ? String(r.outcome.status || "") : null;
    const status = raw && raw.startsWith("already_in_") ? "already" : raw;
    const words = r.ok ? sentLine(status, r, SENT_WORDS) || "Approved. Reload Bills & invoices to see where it stands." : text(r.message) || "Not approved.";
    return { id: r.itemId, name, ok: Boolean(r.ok) && status !== "unconfirmed", words };
  });
}

/** The statuses an inbox answer lists: waiting for a review, or ready to approve. */
const WAITING = new Set(["needs_review", "extracted"]);
/** The most rows an answer draws; the rest are "and N more". */
export const LIVE_ROWS = 5;

/**
 * The answer's inbox as it is NOW (founder's walk, 8 Nov 2026: an answer from the
 * morning said "only one item is waiting" beside an inbox holding five). `items` is the
 * bill inbox's own list (`GET /api/bills`), every item; the rows are its waiting ones,
 * ready to approve first, and Approve sends only the ones ready now. `null` when the list
 * wasn't read, so the answer keeps the engine's rows. Pure.
 */
export function withLiveInbox(view, items) {
  if (!view || !view.measured || !Array.isArray(items)) return null;
  const waiting = items.filter((i) => isObj(i) && isItemId(i.id) && WAITING.has(i.status));
  waiting.sort((a, b) => (a.status === "extracted" ? 0 : 1) - (b.status === "extracted" ? 0 : 1));
  const rows = waiting.slice(0, LIVE_ROWS).map((i) => {
    const d = isObj(i.document) ? i.document : {};
    const total = Number.isInteger(d.totalCents) ? d.totalCents : null;
    return {
      id: i.id,
      kind: KINDS.has(i.kind) ? i.kind : "bill",
      contact: text(d.contactName),
      number: text(d.invoiceNumber),
      date: typeof d.issueDate === "string" && DAY.test(d.issueDate) ? d.issueDate : null,
      totalCents: total,
      subtotalCents: total === null && Number.isInteger(d.subtotalCents) ? d.subtotalCents : null,
      currency: text(d.currency),
      status: i.status,
      statusWords: text(i.statusWords) || (i.status === "extracted" ? "Ready to approve" : "Needs review"),
      ready: i.status === "extracted",
      href: `/bills/${i.id}`,
    };
  });
  const readyIds = waiting.filter((i) => i.status === "extracted").map((i) => i.id);
  return { ...view, rows, waiting: waiting.length, ready: readyIds.length, readyIds, more: Math.max(0, waiting.length - rows.length), live: true };
}
