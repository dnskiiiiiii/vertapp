"use client";

// components/chat/answer/Statements.js — THE PROFIT AND LOSS, THE BALANCE SHEET, THE CASH FLOW
// ==============================================================================
// W4 Step 5 of the close list (29 Oct 2026). Under the verdict of a statements answer,
// and full width on the statements page (app/statements/page.js), in this order:
//
//   1. the month, the basis ("Accrual basis, as the ledger reported it.") and the two
//      checks, drawn before any table because they are what a reviewer reads first:
//      "Balances" with a tick only on the engine's `balances: true`, "Doesn't balance by
//      $X" with the engine's difference on `false`, and the engine's words when it
//      didn't check; the same for "Cash ties";
//   2. the statements: in the chat, one at a time behind a three-way switch (P&L,
//      Balance sheet, Cash flow), so the answer stays a card; on the page, all three
//      stacked. Each is a table: the line, its accounts indented under it, the totals
//      bold; this month's column and, when the engine compared a month, the prior's;
//   3. in the chat, the month-end pack: "Download month-end pack" (PDF) and "Excel",
//      plain download links to the app's route (app/api/close/[period]/pack), and "Open
//      statements" to the page. On the page the downloads lead it instead.
//
// SHOW THE WORK INLINE (answer-shape reference, 17 Oct 2026). Every figure is the
// engine's (financial-statements.js); nothing is summed or subtracted here. A figure not read is
// "Not read" with the engine's words under its row, never $0.00. A section the engine
// didn't read says its words; one that didn't read as the contract says is said to be
// unreadable rather than drawn in part.

import "./statements.css";
import { useState } from "react";
import { Segmented } from "@/components/ui";
import { IconCheck, IconDownload, IconWarning } from "@/components/ui/icons";
import { formatMoney } from "@/lib/format";
import { periodLabel } from "@/lib/period";
import { STATEMENT_SECTIONS, isStatementsPeriod, statementsOf } from "./financial-statements";
import { moneyIn } from "./aging-money";

const NOT_READ = "Not read";

/**
 * A check, as the line the card draws: `{ tone, text, words }`. `kind` is "balance"
 * (the balance sheet) or "cash" (the cash flow). The difference is the engine's; its
 * size is said, whichever side is over. Pure.
 */
export function checkLine(check, kind) {
  const words = check ? check.words || null : null;
  const balance = kind === "balance";
  if (!check || check.state === null) return { tone: "unread", text: balance ? "Balance not checked" : "Cash not checked", words };
  if (check.state === true) return { tone: "ok", text: balance ? "Balances" : "Cash ties", words };
  const by = Number.isInteger(check.differenceCents) && check.differenceCents !== 0 ? ` by ${formatMoney(Math.abs(check.differenceCents))}` : "";
  return { tone: "off", text: `${balance ? "Doesn't balance" : "Cash doesn't tie"}${by}`, words };
}

/** The pack's two download paths and the statements page, for a month. Null for a bad one. Pure. */
export function statementLinks(period) {
  if (!isStatementsPeriod(period)) return null;
  return {
    pdf: `/api/close/${period}/pack?format=pdf`,
    xlsx: `/api/close/${period}/pack?format=xlsx`,
    page: `/statements?period=${period}`,
  };
}

export default function Statements({ statements, full = false, initialTab = "profitAndLoss" }) {
  const s = statementsOf(statements);
  const opening = (s && s.focus) || initialTab;
  const [tab, setTab] = useState(STATEMENT_SECTIONS.some((x) => x.key === opening) ? opening : "profitAndLoss");
  if (!s) return null;
  const label = s.monthLabel || periodLabel(s.period);
  const priorLabel = s.comparedTo ? periodLabel(s.comparedTo) : null;
  const links = statementLinks(s.period);
  const shown = full ? STATEMENT_SECTIONS : STATEMENT_SECTIONS.filter((x) => x.key === tab);
  return (
    <section className="stmt" data-statements="" data-full={full ? "true" : undefined} data-measured={s.measured ? "read" : "unread"} aria-label={`Financial statements, ${label}`}>
      <header className="stmt-head">
        <h4 className="stmt-title">Financial statements</h4>
        <span className="stmt-month">{label}</span>
        {s.currency ? <span className="stmt-currency">{s.currency}</span> : null}
      </header>
      {s.ledgerAsAt ? (
        <p className="stmt-words" data-ledger-as-at={s.ledgerAsAt.behind ? "behind" : "read"}>
          {s.ledgerAsAt.behindWords ? `${s.ledgerAsAt.words}. ${s.ledgerAsAt.behindWords}` : s.ledgerAsAt.words}
        </p>
      ) : null}
      {!s.measured ? (
        <p className="stmt-unread" data-statements-unread="">
          {s.words}
        </p>
      ) : (
        <>
          {s.basisWords ? <p className="stmt-words">{s.basisWords}</p> : null}
          {s.words ? <p className="stmt-words">{s.words}</p> : null}
          <Checks s={s} />
          {s.comparativeWords ? <p className="stmt-words" data-statements-comparison="">{s.comparativeWords}</p> : null}
          {full ? null : (
            <Segmented
              size="sm"
              label="Statement"
              className="stmt-switch"
              options={STATEMENT_SECTIONS.map((x) => ({ value: x.key, label: x.short }))}
              value={tab}
              onChange={setTab}
            />
          )}
          {shown.map((x) => (
            <SectionBlock key={x.key} meta={x} section={s[x.key]} label={label} priorLabel={priorLabel} currency={s.currency} full={full} />
          ))}
          {/* On the statements page the pack's downloads lead the page (app/statements). */}
          {links && !full ? <PackLinks links={links} /> : null}
        </>
      )}
    </section>
  );
}

function Checks({ s }) {
  const items = [];
  if (s.balanceSheet && s.balanceSheet.measured) items.push(["balance", s.balanceSheet.check]);
  else items.push(["balance", { state: null, differenceCents: null, words: s.balanceSheet ? s.balanceSheet.words : "The balance sheet couldn't be read, so it wasn't checked." }]);
  if (s.cashFlow && s.cashFlow.measured) items.push(["cash", s.cashFlow.check]);
  else items.push(["cash", { state: null, differenceCents: null, words: s.cashFlow ? s.cashFlow.words : "The cash flow couldn't be read, so cash wasn't checked." }]);
  return (
    <ul className="stmt-checks" aria-label="Checks">
      {items.map(([kind, check]) => {
        const line = checkLine(check, kind);
        return (
          <li key={kind} className="stmt-check" data-check={kind} data-tone={line.tone}>
            <span className="stmt-check-text">
              {line.tone === "ok" ? <IconCheck className="stmt-check-icon" aria-hidden="true" /> : line.tone === "off" ? <IconWarning className="stmt-check-icon" aria-hidden="true" /> : null}
              <span>{line.text}</span>
            </span>
            {line.words ? <span className="stmt-check-words">{line.words}</span> : null}
          </li>
        );
      })}
    </ul>
  );
}

function SectionBlock({ meta, section, label, priorLabel, currency, full }) {
  const Title = full ? "h3" : "h5";
  if (!section) {
    return (
      <div className="stmt-section" data-section={meta.key} data-measured="unreadable">
        <Title className="stmt-section-title">{meta.title}</Title>
        <p className="stmt-unread">Vert&rsquo;s {meta.title.toLowerCase()} for this month couldn&rsquo;t be read as it was sent, so it isn&rsquo;t drawn here.</p>
      </div>
    );
  }
  if (!section.measured) {
    return (
      <div className="stmt-section" data-section={meta.key} data-measured="unread">
        <Title className="stmt-section-title">{meta.title}</Title>
        <p className="stmt-unread">{section.words}</p>
      </div>
    );
  }
  const prior = Boolean(priorLabel && section.hasPrior);
  const money = (cents) => moneyIn(cents, currency, { style: "table" });
  return (
    <div className="stmt-section" data-section={meta.key} data-measured="read">
      <Title className="stmt-section-title">{meta.title}</Title>
      {section.words ? <p className="stmt-words">{section.words}</p> : null}
      {priorLabel && !section.hasPrior && section.priorWords ? (
        // Live check, 29 Oct 2026: this said "No August 2026 figures were read for the
        // balance sheet" beside a P&L that had read August. The engine says why instead.
        <p className="stmt-words">{section.priorWords}</p>
      ) : null}
      <div className="stmt-table-wrap">
        <table className="stmt-table">
          <caption className="sr-only">{`${meta.title}, ${label}${prior ? `, against ${priorLabel}` : ""}`}</caption>
          <thead>
            <tr>
              <th scope="col">
                <span className="sr-only">Line</span>
              </th>
              <th scope="col" className="num" data-col="current">
                {label}
              </th>
              {prior ? (
                <th scope="col" className="num" data-col="prior">
                  {priorLabel}
                </th>
              ) : null}
            </tr>
          </thead>
          <tbody>
            {section.rows.map((r) => (
              <Row key={r.key} r={r} prior={prior} money={money} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Row({ r, prior, money }) {
  const cols = prior ? 3 : 2;
  const unread = r.cents === null;
  return (
    <>
      <tr data-row={r.key} data-kind={r.kind} data-depth={r.depth || undefined} data-row-has-note={unread && r.words ? "" : undefined}>
        <th scope="row" className="stmt-label">
          {r.label}
        </th>
        <td className={unread ? "num stmt-missing" : "num"}>{unread ? NOT_READ : money(r.cents)}</td>
        {prior ? <td className={r.priorCents === null ? "num stmt-missing" : "num"}>{r.priorCents === null ? NOT_READ : money(r.priorCents)}</td> : null}
      </tr>
      {r.words ? (
        <tr className="stmt-note" data-note-for={r.key}>
          <td colSpan={cols}>{r.words}</td>
        </tr>
      ) : null}
    </>
  );
}

function PackLinks({ links }) {
  return (
    <div className="stmt-foot" data-statements-pack="">
      <a className="btn btn-secondary btn-sm" href={links.pdf} download data-pack-download="pdf">
        <IconDownload aria-hidden="true" />
        <span>Download month-end pack</span>
      </a>
      <a className="btn btn-quiet btn-sm" href={links.xlsx} download data-pack-download="xlsx">
        Excel
      </a>
    </div>
  );
}
