// components/chat/answer/ShapeBlocks.js — THE WORK, THE TIE-OUT, WHAT WAS DELIVERED, THE ENTRIES
// ==============================================================================
// The founder's answer shape (17 Oct 2026, research reference/answer-shape.md). Under the
// verdict, a finished task answer draws, in this order:
//
//   1. WorkTable   the work itself, inline: the top rows of the schedule or rec, money
//                  right-aligned, "N more in the workbook" when there are more;
//   2. TieOut      four short lines to the GL, the variance last: ✓ only on the engine's
//                  `tied: true`; a variance that does not tie in the problem ink with what
//                  explains it; one that could not be checked in words, never ✓;
//   3. Delivered   "I've delivered N things:", numbered, each naming what it holds and
//                  what happens next;
//   4. Entries     one journal card per entry, numbered "1 of 3", a blocked entry's card
//                  carrying its waiting tag and the one action that resolves it and no
//                  approve; above five, three cards and a compact list of the rest; then
//                  the bulk action, which names exactly the ready entries it covers.
//
// Every figure is the engine's (cents in a cell, or a figure the payload carries); nothing
// is summed or subtracted here. An unread figure is words, never $0.00.

import { withLedger } from "@/lib/agent/events";
import { useState } from "react";
import BoundText from "../BoundText";
import EventFigure from "../EventFigure";
import { isReadFigure } from "@/lib/agent/figure-source";
import NextAction, { cardAnchor } from "../NextAction";
import Decision from "../messages/Decision";
import { Disclosure, Meta } from "@/components/ui";
import { entryHref } from "@/lib/scheduled-model";
import { IconCheck } from "@/components/ui/icons";
import { formatMoney } from "@/lib/format";
import { rowCellText, totalCellText } from "../results/TableView";
import { SideCell } from "@/components/cards/JournalCard";
import { accountText, entryHeadLine, statusDateLine, statusWordFor } from "@/components/cards/journal-model";
import { entryLayout, entryNumber, entryTotalCents, hasBlocks } from "./shape";
import { nextWords, primaryActionOf, reviewerWords, viewerApprovesOf, whoApprovesOf } from "./shape-action";
import { gateSentence } from "@/lib/roles";
import { payoutLineWords, payoutOfTitle, withoutRawIds } from "@/lib/raw-ids";
import BankRecRows from "./BankRecRows";
import AgedBalances from "./AgedBalances";
import ReminderDrafts from "./ReminderDrafts";
import UnusualBalances from "./UnusualBalances";
import CashCodingPanel from "./CashCodingPanel";
import AccountSheet, { accountCodeOf } from "@/components/reports/AccountSheet";
import BillInbox from "./BillInbox";
import SmallBalances from "./SmallBalances";
import DocumentsCard from "@/components/month/DocumentsCard";
import PettyCash from "./PettyCash";
import ScheduleCard from "./ScheduleCard";
import Statements from "./Statements";
import TrialBalanceView from "@/components/reports/TrialBalanceView";
import AccountTransactions from "@/components/reports/AccountTransactions";
import GstReport from "@/components/reports/GstReport";
import CustomerStatement from "@/components/reports/CustomerStatement";
import SupplierStatementRec from "./SupplierStatementRec";

const NUMERIC = new Set(["money", "percent", "count"]);
/** "Draft · 31 Jul 2026, July 2026 period, No. automatic": the card's head (journal-model.js entryHeadLine). Pure. */
export function statusLine(entry) {
  return entryHeadLine(entry && entry.status, (entry && entry.je) || null, { date: (entry && entry.date) || null });
}

/**
 * The head of the shape (the work, the tie-out, what was delivered) — drawn under the
 * verdict, before the delivered file's card.
 */
export default function ShapeBlocks({ shape, figures = {}, ledgerName = null, onOpenResult = null, questionsOpen = true, superseded = null, seq = null, cardsBelow = false }) {
  if (!hasBlocks(shape)) return null;
  // THE WORK THE ENGINE SENDS IS DRAWN, ALWAYS (tg-shape, 20 Oct 2026). This screen used
  // to guess that a table whose rows cited a drawn entry WAS that entry and hid it
  // (verify pass 6, D10); the guess hid the accruals table (b308e90) and was patched
  // with another guess. Which sheet is the work, and that an entry's own lines are its
  // card and not a table above it, is the engine's decision (answer_shape.is_entry_sheet);
  // tests/engine-shapes.test.js holds every Batch-1 answer, as the engine says it, to it.
  const work = shape.work || null;
  return (
    <div className="chat-shape" data-answer-shape="">
      {/* THE BANK REC IS DRAWN AS XERO'S RECONCILE SCREEN (co-founder, 23 Oct 2026): its
          rows ARE the work, and they carry their own statement-against-books lines, so
          the reconciling-items table and the four-line roll are not drawn beside them. */}
      {shape.bankRec ? <BankRecRows bankRec={shape.bankRec} ledgerName={ledgerName} superseded={superseded} seq={seq} /> : null}
      {/* AGED BALANCES ARE THE WORK (W3 feature 1, 28 Oct 2026): the summary, the bucket
          table by contact and the most overdue, with Draft reminders on receivables; the
          drafts it brings back are drawn under it. Drafts an answer carries itself are
          drawn on their own. Nothing in either sends without a press. */}
      {shape.agedBalances ? <AgedBalances agedBalances={shape.agedBalances} ledgerName={ledgerName} /> : null}
      {shape.reminders ? <ReminderDrafts reminders={shape.reminders} ledgerName={ledgerName} /> : null}
      {/* THE TRIAL BALANCE REVIEW IS THE WORK (close list Step 4, w4/checks): each
          balance on its unusual side with why, what wasn't read, what was left alone. */}
      {shape.unusualBalances ? <UnusualBalances unusualBalances={shape.unusualBalances} figures={figures} /> : null}
      {/* THE STATEMENTS ARE THE WORK (W4 Step 5, 29 Oct 2026): the two checks, then the
          profit and loss, balance sheet and cash flow, then the month-end pack's two
          downloads. Downloading is a read; nothing here writes. */}
      {shape.statements ? <Statements statements={shape.statements} /> : null}
      {/* "CASH CODE" IS THE GRID (founder, 8 Nov 2026): the Cash coding grid itself, read
          live, coded here; no click through to another page (CashCodingPanel.js). */}
      {shape.cashCoding ? <CashCodingPanel cashCoding={shape.cashCoding} /> : null}
      {shape.billInbox ? <BillInbox billInbox={shape.billInbox} ledgerName={ledgerName} /> : null}
      {shape.smallBalances ? <SmallBalances smallBalances={shape.smallBalances} ledgerName={ledgerName} /> : null}
      {shape.documents ? <DocumentsCard period={shape.documents.period} initial={shape.documents} /> : null}
      {shape.pettyCash ? <PettyCash pettyCash={shape.pettyCash} ledgerName={ledgerName} /> : null}
      {/* A ROUTINE FOR SCHEDULED (w48, audit row 23): what runs and when, and the one
          press that sets it up, changes or stops it through Scheduled's own routes. */}
      {shape.schedule ? <ScheduleCard schedule={shape.schedule} /> : null}
      {/* THE TRIAL BALANCE IS THE WORK (close Step 4.1, w31): every account as Xero lays
          it out, flags on their rows; an account opens its transactions beside it. */}
      {shape.trialBalance ? <TrialBalanceView trialBalance={shape.trialBalance} compact /> : null}
      {/* ACCOUNT TRANSACTIONS (close Step 4.2, w31): the first lines of each account
          with its running balance and its tie to the books; the rest on the page. */}
      {shape.accountTransactions ? <AccountTransactions accountTransactions={shape.accountTransactions} compact /> : null}
      {/* THE GST REPORT (w42, audit row 22): GST by tax rate, collected and paid, and the
          checks; the tie-out to the GST account is the TieOut below; every line on the
          page. A report for checking: nothing in it is filed anywhere. */}
      {shape.gstReport ? <GstReport gstReport={shape.gstReport} compact /> : null}
      {/* A CUSTOMER'S STATEMENT (w46, audit row 20): the latest lines with the running
          balance, Balance due, the ageing and the PDF and Excel downloads; every line on
          the page. It sends nothing: a reminder's Attach statement is the one road. */}
      {shape.customerStatement ? <CustomerStatement customerStatement={shape.customerStatement} compact /> : null}
      {/* A SUPPLIER'S STATEMENT AGAINST THE LEDGER (w49, audit row 21): ties or differs
          by how much, each difference grouped with its link, and how many lines matched.
          It writes nothing: a missing bill's road is the bill inbox. */}
      {shape.supplierStatementRec ? <SupplierStatementRec supplierStatementRec={shape.supplierStatementRec} ledgerName={ledgerName} /> : null}
      {work && !shape.bankRec ? <WorkTable work={work} onOpenResult={onOpenResult} /> : null}
      {shape.tieOut && !shape.bankRec ? <TieOut tieOut={shape.tieOut} figures={figures} ledgerName={ledgerName} /> : null}
      {/* "I'VE DELIVERED N THINGS" ONLY WHEN NOTHING ELSE SAYS IT (founder, 8 Nov 2026): the
          files and entries it listed are drawn as their own cards right under it, each
          with its action, so the numbered list was the same things said twice. */}
      {shape.delivered && !cardsBelow ? <DeliveredList delivered={shape.delivered} ledger={shape.ledger} ledgerName={ledgerName} viewerApproves={viewerApprovesOf(shape)} who={whoApprovesOf(shape)} questionsOpen={questionsOpen} /> : null}
    </div>
  );
}

/** The entry cards of the shape, numbered, then the bulk action — after the file card. */
export function ShapeEntries({ shape, figures = {}, ledgerName = null, decisions = null, skip = null, onOpenResult = null, onStartTask = null, onAsk = null, disabledReason = null, seq = null }) {
  if (!shape || !shape.entries) return null;
  // EACH ENTRY ONCE (verify pass 5): the entries another answer, or the thread, draws are
  // left to it (components/chat/Thread.js entryOwners). With none left, nothing is drawn.
  const entries = skipped(shape.entries, skip);
  if (!entries) return null;
  return (
    <Entries
      entries={entries}
      ledger={shape.ledger}
      figures={figures}
      ledgerName={ledgerName}
      decisions={decisions}
      onOpenResult={onOpenResult}
      onStartTask={onStartTask}
      onAsk={onAsk}
      disabledReason={disabledReason}
      runId={`shape-${seq == null ? "answer" : seq}`}
    />
  );
}

/** The entries with the `skip` ids taken out (the bulk too when it is), or null when none is left. Pure. */
export function skipped(entries, skip) {
  if (!(skip instanceof Set) || !skip.size) return entries;
  const items = entries.items.filter((e) => !(e.actionId != null && skip.has(String(e.actionId))));
  if (!items.length) return null;
  const bulk = entries.bulk && entries.bulk.actionId != null && skip.has(String(entries.bulk.actionId)) ? null : entries.bulk;
  return { ...entries, items, bulk };
}

/* ── 1. the work, as a table ─────────────────────────────────────────────────── */

/** A words cell longer than this is clamped in the chat table (its whole text on hover). */
export const CLAMP_AT = 48;

/** Whether a column holds an account's name ("Bank account"), drawn in its cell however long. Pure. */
export function isAccountColumn(column) {
  return Boolean(column) && (column.key === "account" || /\baccount$/i.test(String(column.label || "").trim()));
}

/** Money columns that are the two sides of an entry: an empty side reads "–", never $0.00. */
const SIDE_KEYS = new Set(["debit", "credit"]);

/** Whether a work table is laid out as entry lines (a Debit and a Credit column). Pure. */
export function hasSides(columns) {
  const keys = new Set((Array.isArray(columns) ? columns : []).map((c) => c && c.key));
  return keys.has("debit") && keys.has("credit");
}

/**
 * The Total row's label and which cells it empties (verify pass 6, Q-SHAPE-1): the
 * engine writes "Total" in a words column (Item, Entry, Account), and the row also drew
 * its own "Total" in the first column, so it read "Total … Total" (and "Entry: Total" on a
 * phone). The label is said once, in the first column: the first column's own words, else
 * the words a later words column carried, else "Total"; those later words cells are blank.
 * Pure.
 */
export function totalsLayout(columns, totals) {
  const cells = totals && typeof totals === "object" ? totals : {};
  const words = (c) => (c && !NUMERIC.has(c.kind) && typeof cells[c.key] === "string" ? cells[c.key].trim() : "");
  const cols = Array.isArray(columns) ? columns : [];
  const blank = new Set();
  let label = cols.length ? words(cols[0]) : "";
  cols.forEach((c, i) => {
    if (i === 0) return;
    const w = words(c);
    if (!w) return;
    if (!label) label = w;
    if (w === label || /^total\b/i.test(w)) blank.add(c.key);
  });
  return { label: label || "Total", blank };
}

export function WorkTable({ work, onOpenResult = null }) {
  const sheet = { columns: work.columns, rows: work.rows, totals: work.totals ? work.totals.cells : null };
  const sides = hasSides(work.columns);
  const total = totalsLayout(work.columns, sheet.totals);
  const canOpen = typeof onOpenResult === "function" && work.artifactId;
  // A COLUMN SAID UNDER EVERY ROW ISN'T A COLUMN (founder, 8 Nov 2026): when each of its
  // cells is a paragraph drawn on its own line under the row (or empty), its header stood
  // over an empty column. It is left out of the table; its words stay under each row.
  const longCell = (row, c, ci) => {
    if (ci === 0 || NUMERIC.has(c.kind) || isAccountColumn(c)) return false;
    const shown = rowCellText(row, c, { screen: true });
    return Boolean(shown && typeof shown.text === "string" && shown.text.length > CLAMP_AT);
  };
  const emptyCell = (row, c) => {
    const shown = rowCellText(row, c, { screen: true });
    return !shown || shown.text === "" || shown.text === null;
  };
  const underOnly = new Set(
    work.columns
      .filter((c, ci) => work.rows.some((r) => longCell(r, c, ci)) && work.rows.every((r) => longCell(r, c, ci) || emptyCell(r, c)))
      .map((c) => c.key)
  );
  // ONE WORD ON EVERY ROW IS SAID ONCE (founder's walk, 8 Nov 2026: "Checked against:
  // Nil: a clearing account empties each month" on each of four rows). A words column,
  // past the first, whose rows all say the same thing is a line above the table instead.
  const figureRows = work.rows.filter((r) => (r.role || "figure") === "figure");
  const textOf = (row, c) => {
    const shown = rowCellText(row, c, { screen: true });
    return shown && typeof shown.text === "string" ? shown.text.trim() : "";
  };
  const sameEverywhere = work.columns.filter(
    (c, ci) => ci > 0 && !NUMERIC.has(c.kind) && !isAccountColumn(c) && !underOnly.has(c.key) && figureRows.length >= 2 && textOf(figureRows[0], c) && figureRows.every((r) => textOf(r, c) === textOf(figureRows[0], c))
  );
  const saidOnce = sameEverywhere.map((c) => ({ key: c.key, label: c.label, words: textOf(figureRows[0], c) }));
  sameEverywhere.forEach((c) => underOnly.add(c.key));
  const shownColumns = work.columns.filter((c) => !underOnly.has(c.key));
  // A FLAGGED ACCOUNT OPENS ITS TRANSACTIONS (founder's walk, 8 Nov 2026): where the first
  // column is an account and the work names its month (a task's artifact id leads with
  // it), the account is a press that opens its month's lines beside the chat.
  const monthOfWork = (/^(\d{4}-\d{2})-/.exec(String(work.artifactId || "")) || [])[1] || null;
  const accountsOpen = Boolean(monthOfWork) && isAccountColumn(shownColumns[0]);
  const [account, setAccount] = useState(null);
  return (
    <div className="shape-work" data-shape-work={work.artifactId || ""}>
      {work.title ? <p className="shape-label">{work.title}</p> : null}
      {saidOnce.map((x) => (
        <p key={x.key} className="shape-more t-footnote" data-said-once={x.key}>
          {x.label ? `${x.label}: ` : ""}
          {x.words}
        </p>
      ))}
      <div className="shape-table-wrap">
        <table className="shape-table" data-sheet={work.sheet || undefined} data-cols={shownColumns.length}>
          <thead>
            <tr>
              {shownColumns.map((c) => (
                <th key={c.key} scope="col" className={NUMERIC.has(c.kind) ? "num" : undefined} data-col={c.key}>
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {work.rows.map((row, i) => {
              // A PARAGRAPH NEVER SETS THE ROW, AND IS NEVER CUT (verify pass 5 and 6,
              // Q-SHAPE-1/5): a words cell past the first that runs past CLAMP_AT (a fixed
              // asset's State, a scan's Why) is said whole on its own line under the row,
              // "State: …", across the table; its cell is left empty. A clamp kept the
              // rows short but cut the reason off at "The register's cost is…".
              const below = [];
              const cells = work.columns.map((c, ci) => {
                // A CARD IN THE CONVERSATION WRITES MONEY AS A SENTENCE DOES (verify pass 5, S-UI-11 /
                // S-SM-16): a negative with the minus sign, a measured zero as $0.00 (the
                // workbook's "–" for zero read as "not measured" beside "$0.00" in the tie-out).
                // AN ENTRY'S EMPTY SIDE IS "–" (verify pass 6, D10 / Q-SHAPE-4): in a table of
                // entry lines (Debit and Credit columns) a line's zero side is the side it
                // does not touch, drawn as the JE card draws it.
                const shown = rowCellText(row, c, { screen: true });
                const words = shown === null ? "not shown" : shown.text;
                const numeric = NUMERIC.has(c.kind);
                const value = row && row.cells ? row.cells[c.key] : undefined;
                if (sides && SIDE_KEYS.has(c.key) && (row.role || "figure") === "figure" && value === 0) {
                  return (
                    <td key={c.key} className="num" data-col={c.key} data-label={c.label || undefined} data-cell-kind="money" data-side-empty="">
                      <span aria-label="none">&ndash;</span>
                    </td>
                  );
                }
                // A BANK ACCOUNT IS A NAME, NOT A PARAGRAPH (walk 5): it wraps in its own
                // column; moved under the row it left the column blank on every row.
                const long = !numeric && ci > 0 && !isAccountColumn(c) && typeof words === "string" && words.length > CLAMP_AT;
                if (long && !saidOnce.some((x) => x.key === c.key)) below.push({ key: c.key, label: c.label, words });
                if (underOnly.has(c.key)) return null;
                const code = accountsOpen && ci === 0 && typeof words === "string" ? accountCodeOf(words) : null;
                return (
                  <td key={c.key} className={[numeric ? "num" : null, shown && shown.unmeasured ? "shape-missing" : null].filter(Boolean).join(" ") || undefined} data-col={c.key} data-label={c.label || undefined} data-cell-kind={numeric ? "money" : "words"} data-cell-below={long ? "" : undefined}>
                    {long ? "" : code ? (
                      <button type="button" className="link shape-account-open" aria-haspopup="dialog" onClick={() => setAccount({ code, label: words })} data-account-open={code}>
                        {words}
                      </button>
                    ) : (
                      words
                    )}
                  </td>
                );
              });
              return [
                <tr key={i} data-role={row.role || "figure"} data-tone={row.tone || undefined} data-row-has-note={below.length ? "" : undefined}>
                  {cells}
                </tr>,
                ...below.map((b) => (
                  <tr key={`${i}-${b.key}`} className="shape-row-note" data-row-note={b.key}>
                    <td colSpan={shownColumns.length} data-cell-kind="words">
                      {b.label ? <span className="shape-row-note-label">{b.label}: </span> : null}
                      {b.words}
                    </td>
                  </tr>
                )),
              ];
            })}
          </tbody>
          {work.totals ? (
            <tfoot>
              <tr>
                {shownColumns.map((c, i) => {
                  if (i === 0) {
                    return (
                      <th key={c.key} scope="row">
                        {total.label}
                      </th>
                    );
                  }
                  if (total.blank.has(c.key)) return <td key={c.key} data-col={c.key} data-cell-kind="words" />;
                  const shown = totalCellText(sheet, c, { screen: true });
                  const words = shown === null ? "not shown" : shown.text;
                  return (
                    <td key={c.key} className={[NUMERIC.has(c.kind) ? "num" : null, shown && shown.unmeasured ? "shape-missing" : null].filter(Boolean).join(" ") || undefined} data-col={c.key} data-label={c.label || undefined} data-cell-kind={NUMERIC.has(c.kind) ? "money" : "words"}>
                      {words}
                    </td>
                  );
                })}
              </tr>
            </tfoot>
          ) : null}
        </table>
      </div>
      {work.leftWords ? (
        <p className="shape-more t-footnote" data-shape-left="">
          {work.leftWords}
        </p>
      ) : null}
      {work.moreWords ? (
        <p className="shape-more t-footnote" data-shape-more="">
          {canOpen ? (
            <button type="button" className="link shape-more-link" onClick={() => onOpenResult(work.artifactId, work.sheet || undefined)}>
              {work.moreWords}
            </button>
          ) : (
            work.moreWords
          )}
        </p>
      ) : null}
      {work.noteWords ? (
        <p className="shape-more t-footnote" data-shape-note="">
          {work.noteWords}
        </p>
      ) : null}
      {account ? <AccountSheet code={account.code} label={account.label} period={monthOfWork} onClose={() => setAccount(null)} /> : null}
    </div>
  );
}

/* ── 2. the tie-out, four lines ─────────────────────────────────────────────── */

/**
 * "tied", "off" or "unchecked". A ✓ is drawn ONLY when the engine said `tied: true` AND
 * what is on screen bears it out: every line measured and the variance a measured zero.
 * A `tied: true` over a variance that is not zero, or over a line that was not read, is
 * the check sharing the defect it reports; it is drawn as not checked (words, no ✓), and
 * a measured non-zero variance is drawn as off whatever `tied` says. Pure.
 */
export function tieOutState(tieOut, figures = {}) {
  if (!tieOut || !Array.isArray(tieOut.lines)) return "unchecked";
  const variance = tieOut.lines.find((l) => l.kind === "variance") || null;
  const fig = variance && variance.figureRef && figures ? figures[variance.figureRef] : null;
  const varianceRead = Boolean(variance && variance.measured && fig && fig.measured !== false && Number.isInteger(fig.cents));
  if (varianceRead && fig.cents !== 0) return "off";
  if (tieOut.tied === false) return varianceRead ? "off" : "unchecked";
  if (tieOut.tied !== true) return "unchecked";
  const allRead = tieOut.lines.every((l) => {
    const f = l.figureRef && figures ? figures[l.figureRef] : null;
    return l.measured && f && f.measured !== false && Number.isInteger(f.cents);
  });
  if (!(allRead && varianceRead && fig.cents === 0)) return "unchecked";
  // With several accounts, the whole ties only when every account's own block does.
  const accounts = Array.isArray(tieOut.accounts) ? tieOut.accounts : [];
  return accounts.every((a) => tieOutState(a, figures) === "tied") ? "tied" : "unchecked";
}

/** The block's heading: the engine's title when it sends one, else "Reconciliation". */
export function tieHeading(tieOut) {
  return tieOut && typeof tieOut.title === "string" && tieOut.title.trim() ? tieOut.title.trim() : "Reconciliation";
}

export function TieOut({ tieOut, figures = {}, ledgerName = null }) {
  const state = tieOutState(tieOut, figures);
  const accounts = Array.isArray(tieOut.accounts) ? tieOut.accounts : [];
  return (
    <div className="shape-tieout" data-shape-tieout={state}>
      {/* The engine names a block that is no reconciliation ("Bank summary", w29). */}
      <p className="shape-label">{tieOut.account ? `${tieHeading(tieOut)} · ${tieOut.account}` : tieHeading(tieOut)}</p>
      <TieBlock tieOut={tieOut} state={state} figures={figures} ledgerName={ledgerName} />
      {accounts.length ? (
        // ONE ROW PER ACCOUNT (founder's walk, 8 Nov 2026): four accounts of six lines each,
        // an unreconciled one saying "The reconciliation hasn't been done." on every line,
        // was a wall. Each account is its name, its difference (or why there is none) and
        // the engine's words; its lines are one press down.
        <div className="shape-tie-accounts">
          {accounts.map((acct, i) => {
            const own = tieOutState(acct, figures);
            const variance = (acct.lines || []).find((l) => l.kind === "variance") || null;
            const vFigure = variance && variance.figureRef ? figures[variance.figureRef] : null;
            const measured = Boolean(vFigure && variance.measured && vFigure.measured !== false && isReadFigure(vFigure));
            return (
              <div key={i} className="shape-tie-account" data-shape-tieout={own}>
                <p className="shape-tie-account-row">
                  <span className="shape-tie-account-name">{acct.account || "Account"}</span>
                  <span className={measured ? "shape-tie-amount num" : "shape-tie-amount"} data-tie-off={own === "off" ? "" : undefined}>
                    {measured ? (
                      <>
                        Difference <EventFigure figure={vFigure} figureRef={variance.figureRef} />
                      </>
                    ) : (
                      "Not checked"
                    )}
                    {own === "tied" ? (
                      <span className="shape-tie-tick" data-tie-tick="" aria-label="checked against the GL">
                        {" "}
                        <IconCheck size={12} aria-hidden="true" />
                      </span>
                    ) : null}
                  </span>
                </p>
                {own !== "tied" && acct.words && acct.tied !== true ? (
                  <p className="shape-tie-words t-footnote" data-tie-words="">
                    <BoundText text={acct.words} figures={figures} ledgerName={ledgerName} />
                  </p>
                ) : null}
                <Disclosure summary="Show the lines" className="shape-tie-fold">
                  <TieBlock tieOut={acct} state={own} figures={figures} ledgerName={ledgerName} wordsShown noTick />
                </Disclosure>
              </div>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}

/**
 * ONE MINUS ON SCREEN (verify pass 7 and 8, S-BK-3). A tie-out's subtracted line
 * (`negative: true`; the contract draws it "($4,985.00)") is written "−$4,985.00", the minus
 * every other figure on screen and every sentence uses (S-UI-11). Pass 7 did this only in a
 * block that also held a negative balance, so the card rec's positive block still wrote
 * "($16.50)" beside the bank rec's "−$4,985.00": one rule per block gave two styles per
 * screen. Kept as a function, always true, for its callers and tests. Pure.
 */
export function signedTieOut() {
  return true;
}

/**
 * Subtracted lines that are a PART of the line above them, not an adjustment to it, and
 * so read in its sign (staging browser walk 5): "Deposits matched to them: −$16,148.56"
 * sat under "Paid out by the processors: $16,148.56". What is left is the line below.
 */
const PART_OF_ABOVE = new Set(["Deposits matched to them"]);

/** Whether a tie-out line is drawn as subtracted (a minus). Pure. */
export function drawnSubtracted(line) {
  return Boolean(line && line.negative) && !PART_OF_ABOVE.has(String(line.label || "").trim());
}

/** One block's lines, its ✓ (only when `state` is "tied") and its words. */
function TieBlock({ tieOut, state, figures, ledgerName, wordsShown = false, noTick = false }) {
  const signed = signedTieOut(tieOut, figures);
  return (
    <>
      <ul className="shape-tie-lines">
        {tieOut.lines.map((line, i) => {
          const figure = line.figureRef ? figures[line.figureRef] : null;
          // ONE NEGATIVE STYLE PER BLOCK (verify pass 7, S-BK-3): beside a balance drawn
          // "−$382,478.90", a subtracted line is "−$4,985.00", not "($4,985.00)": the
          // line's sign written as the minus, its amount as the engine sent it.
          // A ZERO HAS NO SIGN (staging D1, 26 Oct 2026; tg2 Q-SHAPE-2): "Less June's
          // accruals reversed: −$0.00" was a subtracted measured zero. Neither the minus nor
          // the brackets are drawn over one, whatever the engine marked.
          const zero = Boolean(figure && figure.measured !== false && figure.cents === 0);
          const negative = drawnSubtracted(line) && !zero;
          const minus = Boolean(signed && negative);
          const variance = line.kind === "variance";
          const off = variance && state === "off";
          // WORDS WRAP, MONEY DOESN'T (verify pass 5, Q-SHAPE-2): a value that is words
          // (unmeasured, or not worked out) is not `.num` (white-space: nowrap), so it
          // wraps inside the answer column at 390 and at 1440 instead of running past it.
          const money = Boolean(figure && line.measured && figure.measured !== false && isReadFigure(figure));
          return (
            <li key={i} className="shape-tie-line" data-tie-kind={line.kind} data-tie-off={off ? "" : undefined}>
              {/* The ledger's name, never the engine's {{ledger}} (founder's walk, 8 Nov 2026; D37). */}
              <span className="shape-tie-label">{withLedger(line.label, ledgerName)}:</span>{" "}
              <span className={money ? "shape-tie-amount num" : "shape-tie-amount"} data-tie-words={money ? undefined : ""}>
                {figure && line.measured && figure.measured !== false ? (
                  minus ? (
                    <>
                      −<EventFigure figure={figure} figureRef={line.figureRef} belowZero={line.belowZero === true} />
                    </>
                  ) : negative ? (
                    <>
                      (<EventFigure figure={figure} figureRef={line.figureRef} belowZero={line.belowZero === true} />)
                    </>
                  ) : (
                    <EventFigure figure={figure} figureRef={line.figureRef} belowZero={line.belowZero === true} />
                  )
                ) : figure ? (
                  // Unmeasured: the figure's own words, never $0.00.
                  <EventFigure figure={{ ...figure, measured: false }} figureRef={line.figureRef} />
                ) : (
                  <span className="shape-missing">not worked out</span>
                )}
              </span>
              {variance && state === "tied" && !noTick ? (
                <span className="shape-tie-tick" data-tie-tick="" aria-label="checked against the GL">
                  {" "}
                  <IconCheck size={12} aria-hidden="true" />
                </span>
              ) : null}
            </li>
          );
        })}
      </ul>
      {state !== "tied" && !wordsShown ? (
        <p className={`shape-tie-words t-footnote${state === "off" ? " shape-tie-problem" : ""}`} data-tie-words="">
          {/* The engine's words only where its own verdict is the one drawn: words written
              for a tie are not drawn under a variance that is not zero. */}
          {tieOut.words && tieOut.tied !== true ? (
            <BoundText text={tieOut.words} figures={figures} ledgerName={ledgerName} />
          ) : state === "off" ? (
            "This doesn't tie to the GL yet."
          ) : (
            "Couldn't check this against the GL."
          )}
        </p>
      ) : null}
    </>
  );
}

/* ── 3. what was delivered, numbered ───────────────────────────────────────── */

/**
 * A delivered item's next step once nothing is asked (verify pass 6, Q05): the engine
 * writes "First answer the question below; then open it …" into the answer when it
 * asks, and the answer is kept; once the question is answered or skipped the clause
 * points at nothing. With no question open it is dropped ("Answer the question below
 * and Vert carries on" has nothing left, so null). Pure.
 */
export function settledNext(next, questionsOpen = true) {
  if (questionsOpen || typeof next !== "string") return next;
  // "below" (the task's own answer) or "in <task>" (the chat's mirror of it, engine
  // answer_shape.mirrored; staging chat c-4, 23 Oct 2026).
  if (/^Answer the (?:question|\d+ questions) (?:below|in .+?) and Vert carries on\.?$/.test(next.trim())) return null;
  const rest = next.replace(/^First answer the (?:question|\d+ questions) (?:below|in .+?); then /, "");
  return rest === next ? next : rest.charAt(0).toUpperCase() + rest.slice(1);
}

/**
 * A clause the engine sends without its stop, ended as a sentence (UI walk 3, W3-6: "…
 * Once they're approved, they go to your ledger" had none). One already ended is kept. Pure.
 */
export function ended(text) {
  if (typeof text !== "string") return text;
  const t = text.trimEnd();
  return !t || /[.!?…:;]["'’”)]?$/.test(t) ? t : `${t}.`;
}

export function DeliveredList({ delivered, ledger = null, ledgerName = null, viewerApproves = false, who = null, questionsOpen = true }) {
  return (
    <div className="shape-delivered" data-shape-delivered={delivered.items.length}>
      <p className="shape-lead">{delivered.lead}</p>
      <ol className="shape-delivered-list">
        {delivered.items.map((item) => {
          const detail = item.detail ? reviewerWords(item.detail, who || (viewerApproves ? "you" : null)) : null;
          const next = settledNext(item.next, questionsOpen) ? nextWords(settledNext(item.next, questionsOpen), ledger, ledgerName, { viewerApproves, who }) : null;
          // The item's last clause ends the sentence; the detail's stop comes before next.
          return (
            <li key={item.n} value={item.n} data-delivered-kind={item.kind}>
              <strong>{item.label}</strong>
              {detail ? <> &mdash; {next ? detail : ended(detail)}</> : null}
              {next ? <>. {ended(next)}</> : null}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

/* ── 4. the entries, one card each ─────────────────────────────────────────── */

function Entries({ entries, ledger, figures, ledgerName, decisions, onOpenResult, onStartTask, onAsk, disabledReason, runId }) {
  const [opened, setOpened] = useState(() => new Set());
  const layout = entryLayout(entries.items);
  const cards = [...layout.cards, ...layout.rows.filter((e) => opened.has(e.n))];
  const rows = layout.rows.filter((e) => !opened.has(e.n));
  const bulk = entries.bulk && decisions instanceof Map ? decisions.get(entries.bulk.actionId) || null : null;
  // ONE ACCENT IN VIEW (PR8): of the live, undecided entry cards drawn, the first carries
  // the accent and the rest draw the same commit quiet, still pressable.
  const live = (e) => {
    const d = liveDecision(e, decisions);
    return Boolean(d && !d.settled);
  };
  // With a bulk card standing over the ready entries, the bulk is the one accent and each
  // entry's own commit is quiet.
  const bulkLive = Boolean(bulk && !bulk.settled);
  const lead = bulkLive ? null : cards.find(live);
  return (
    <div className="shape-entries" data-shape-entries={entries.items.length}>
      {entries.headline ? (
        <p className="shape-entries-headline" data-entries-headline="">
          <BoundText text={reviewerWords(entries.headline, whoApprovesOf({ entries }))} figures={figures} ledgerName={ledgerName} />
        </p>
      ) : null}
      <ol className="shape-entry-cards" aria-label={`${entries.items.length} ${entries.items.length === 1 ? "entry" : "entries"}`}>
        {cards.map((entry) => (
          <li
            key={entry.n}
            className="shape-entry chat-card-anchor"
            id={entry.actionId != null ? cardAnchor(entry.actionId) : `shape-entry-${runId}-${entry.n}`}
            data-entry-n={entry.n}
            data-entry-of={entry.of}
            data-entry-blocked={entry.block ? "" : undefined}
          >
            <EntryCard entry={entry} ledger={ledger} ledgerName={ledgerName} decisions={decisions} quiet={bulkLive || (Boolean(lead) && lead !== entry)} onOpenResult={onOpenResult} onStartTask={onStartTask} onAsk={onAsk} disabledReason={disabledReason} runId={runId} />
          </li>
        ))}
      </ol>
      {rows.length ? (
        <ul className="shape-entry-rows" aria-label="More entries" data-entry-rows={rows.length}>
          {rows.map((entry) => {
            const total = entryTotalCents(entry.je);
            return (
              <li key={entry.n}>
                <button type="button" className="decision-row row shape-entry-row" aria-expanded="false" onClick={() => setOpened((prev) => new Set(prev).add(entry.n))} data-entry-n={entry.n}>
                  <span className="shape-entry-row-n t-footnote num">{entryNumber(entry)}</span>
                  <span className="shape-entry-row-title">{entry.title}</span>
                  <span className="num shape-entry-row-total">{total === null ? "total not sent" : formatMoney(total)}</span>
                  <span className="t-footnote shape-entry-row-status" data-tone={entry.block ? "attention" : undefined}>{entry.block ? entry.block.words : statusDateLine(entry.status, null, entry.je)}</span>
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}
      {bulk ? (
        <div className="shape-bulk" data-shape-bulk={entries.bulk.covers.length}>
          <Decision item={bulk.settled ? bulk : bulkDecision(bulk, entries.bulk, figures)} ledgerName={ledgerName} open />
        </div>
      ) : null}
    </div>
  );
}

/**
 * The bulk card worded by the shape: its commit is the shape's label ("Approve the 2
 * ready entries · $X"), its figure laid on from the answer, and its question names the
 * count it covers, never "all N" when an entry is left out. Pure.
 */
export function bulkDecision(item, bulk, figures = {}) {
  if (!item || !item.action || !bulk) return item;
  const n = bulk.covers.length;
  const figure = bulk.figureRef && figures && figures[bulk.figureRef] ? { [bulk.figureRef]: figures[bulk.figureRef] } : {};
  return {
    ...item,
    action: {
      ...item.action,
      commitLabel: bulk.label,
      figures: { ...(item.action.figures || {}), ...figure },
      proposal: n === 1 ? "Approve the ready entry?" : `Approve the ${n} ready entries together?`,
    },
  };
}

/** The live decision an entry is, or null: never for a blocked entry. Pure. */
export function liveDecision(entry, decisions) {
  if (!entry || entry.block || entry.actionId == null || !(decisions instanceof Map)) return null;
  const d = decisions.get(entry.actionId) || null;
  return d && d.action ? d : null;
}

/**
 * The entry's decision with the shape laid on: the entry's lines where the event carried
 * none (a payout approval's event has no lines, D01), and the numbering "2 of 3" with its
 * run, so one card of the run carries the accent (pagerFocus). Pure.
 */
/**
 * A card's own lines with the rates the engine now puts on the entry's (w45 `line.tax`,
 * `je.tax`). A card put up before tax codes (31 Oct) carries lines without them, and
 * drew no Tax rate column on a draft that has one (local browser walk, 4 Nov 2026).
 * A rate is laid on only where the lines are the same lines (account and amounts, in
 * order); otherwise the card's lines stand as they are. Pure.
 */
export function withEntryTax(je, fresh) {
  const lines = je && Array.isArray(je.lines) ? je.lines : null;
  const now = fresh && Array.isArray(fresh.lines) ? fresh.lines : null;
  if (!lines || !now || lines.length !== now.length) return je;
  if (lines.some((l) => l && l.tax)) return je;
  const same = (a, b) =>
    a && b && String(a.account ?? "") === String(b.account ?? "") && (a.debitCents ?? 0) === (b.debitCents ?? 0) && (a.creditCents ?? 0) === (b.creditCents ?? 0);
  if (!lines.every((l, i) => same(l, now[i])) || !now.some((l) => l && l.tax)) return je;
  return {
    ...je,
    lines: lines.map((l, i) => (now[i].tax ? { ...l, tax: now[i].tax } : l)),
    ...(je.tax || !fresh.tax ? {} : { tax: fresh.tax }),
  };
}

export function numberedDecision(item, entry, runId) {
  if (!item || !item.action) return item;
  const own = item.action.je && Array.isArray(item.action.je.lines) && item.action.je.lines.length ? item.action.je : null;
  const je = own ? withEntryTax(own, entry.je) : entry.je;
  if (!je) return item;
  // An entry named for its kind carries the name on its pager ("1 of 2 · Reclassification"),
  // so the card says what the delivered list says (founder, 19 Oct 2026).
  const name = entry.name || undefined;
  return { ...item, action: { ...item.action, je: { ...je, pager: entry.of > 1 || name ? { index: entry.n, of: entry.of, runId, name } : undefined } } };
}

/**
 * What an entry's live card is given: the ledger the read laid on the shape (so the
 * commit is worded by createsDraft at first paint, not only after the card asks), and,
 * for a card with no pager of its own, `quiet` and `lines: false` (its lines are its
 * event's, never the sample's page journal). Pure.
 */
export function entryCardProps(paged, quiet, ledger, entry = null) {
  const out = {};
  if (ledger && typeof ledger === "object") out.ledger = ledger;
  // THE READ'S WORD FOR THIS VIEWER (contract `mayApprove`/`whyNot`, laid on at read): a
  // viewer the read says may not approve gets who approves, never a live Approve. `null`
  // (the read could not tell) leaves the card's own role check and the engine's gate.
  if (entry && entry.mayApprove === false) out.refusal = gateSentence(entry.whyNot) || "A reviewer approves this entry.";
  // WHO SIGNS IT, BEFORE THE PRESS (verify pass 7, Q-SHAPE-4): where nobody else may
  // sign (payroll's only admin), the read says so, and the card says it above Approve.
  if (entry && entry.mayApprove !== false && typeof entry.signsAlone === "string" && entry.signsAlone) {
    out.signsAlone = entry.signsAlone;
  }
  if (!paged) {
    out.quiet = Boolean(quiet);
    out.lines = false;
  }
  return out;
}

/** Card kinds that draw the run's "2 of 3" themselves (JournalCard's pager). */
const PAGED_KINDS = new Set(["journal_approve", "journal_draft", "reverse", "journal"]);

function EntryCard({ entry, ledger, ledgerName, decisions, quiet = false, onOpenResult, onStartTask, onAsk, disabledReason, runId }) {
  const decision = liveDecision(entry, decisions);
  // A LIVE ENTRY IS ITS OWN CARD: the decision this entry is, drawn by its card (approve,
  // edit, post, its state as of now), numbered by the shape. A card that draws no pager
  // of its own (a payout approval) carries the number above it.
  if (decision) {
    const paged = PAGED_KINDS.has(decision.action.kind);
    const number = entryNumber(entry);
    return (
      <>
        {!paged && number ? (
          <p className="shape-entry-number t-footnote num" data-entry-number="">
            {`Entry ${number}`}
          </p>
        ) : null}
        <Decision item={numberedDecision(decision, entry, runId)} ledgerName={ledgerName} open cardProps={entryCardProps(paged, quiet, ledger, entry)} />
      </>
    );
  }
  return <StaticEntryCard entry={entry} ledger={ledger} ledgerName={ledgerName} onOpenResult={onOpenResult} onStartTask={onStartTask} onAsk={onAsk} disabledReason={disabledReason} />;
}

/**
 * Whether an entry's block is another task's card, where it is approved, not a hold
 * (staging browser walk 5, W5-4): its words said "Ready to approve on its card in
 * Prepaid schedules" and the fallback note under them "This entry can't be approved
 * until that's resolved.", about nothing. The engine's `elsewhere` when sent, else its
 * words. Pure.
 */
export function approvedElsewhere(block) {
  if (!block || typeof block !== "object") return false;
  if (typeof block.elsewhere === "string" && block.elsewhere.trim()) return true;
  return typeof block.words === "string" && /^Ready to approve on its (?:own )?card\b/i.test(block.words.trim());
}

/** An entry's engine-written words (title, block, line descriptions, evidence) with no raw id. Pure. */
export function entryWithoutRawIds(entry, ledgerName = null) {
  if (!entry || typeof entry !== "object") return entry;
  const un = (text) => withoutRawIds(text, { ledgerName });
  const je = entry.je && typeof entry.je === "object" ? entry.je : {};
  // A line the engine described by a payout entry's raw memo says its own words, else
  // the payout the entry's title names (staging browser walk 6, W6-3).
  const label = payoutOfTitle(entry.title) || payoutOfTitle(je.memo);
  const words = (l) => payoutLineWords(l.description, { name: l.name, label });
  return {
    ...entry,
    title: un(entry.title),
    block: entry.block && typeof entry.block === "object" ? { ...entry.block, words: un(entry.block.words), note: un(entry.block.note) } : entry.block,
    je: {
      ...je,
      lines: Array.isArray(je.lines) ? je.lines.map((l) => (l && typeof l === "object" ? { ...l, description: un(words(l)) } : l)) : je.lines,
      evidence: Array.isArray(je.evidence) ? je.evidence.map((e) => (e && typeof e === "object" ? { ...e, label: un(e.label) } : e)) : je.evidence,
    },
  };
}

/**
 * An entry with no live card behind it (blocked, or not proposed for a press here): the
 * same face as the journal card — title, status · date, Account | Debit | Credit |
 * Description, Total — with its block or who approves it, and never an Approve.
 */
export function StaticEntryCard({ entry: given, ledger = null, ledgerName = null, onOpenResult = null, onStartTask = null, onAsk = null, disabledReason = null, inPane = false }) {
  // The engine's words on the card carry no raw id (walk 5, the W4-9 remainder).
  const entry = entryWithoutRawIds(given, ledgerName);
  const je = entry.je;
  const lines = Array.isArray(je.lines) ? je.lines : [];
  const totals = je.totals && typeof je.totals === "object" ? je.totals : {};
  const action = primaryActionOf(entry, ledger, ledgerName);
  const number = entryNumber(entry);
  const evidence = Array.isArray(je.evidence) ? je.evidence.filter((e) => e && typeof e.label === "string" && e.label) : [];
  return (
    <article className="dcard jcard shape-entry-card" data-je-state={entry.status} data-entry-static="" aria-label={entry.title}>
      <div className="dcard-head jcard-head">
        <div className="jcard-titlebar">
          <p className="jcard-memo">{entry.title}</p>
          {entry.block ? (
            <Meta className="jcard-state shape-entry-wait" data-tone="attention" data-entry-wait="">
              {entry.block.words}
            </Meta>
          ) : null}
          {number ? (
            <span className="jcard-tools">
              <span className="jcard-pager t-footnote num" data-je-pager="">
                {number}
              </span>
            </span>
          ) : null}
        </div>
        <p className="jcard-label t-footnote">
          <span className="num" data-entry-status="">{statusLine(entry)}</span>
        </p>
      </div>
      {je.redacted ? (
        // A payroll entry where its lines may not be read (§20.12 H3): the engine sent
        // no line and no amount, and says why; an admin's read carries the lines.
        <p className="jcard-note t-footnote shape-entry-redacted" data-entry-redacted="">
          {je.redacted}
        </p>
      ) : (
      <div className="jcard-grid-wrap" data-lexicon="entry">
        <table className="jcard-grid">
          <thead>
            <tr>
              <th scope="col">Account</th>
              <th scope="col" className="num">Debit</th>
              <th scope="col" className="num">Credit</th>
              <th scope="col" className="jcard-desc-col">Description</th>
            </tr>
          </thead>
          <tbody>
            {lines.map((line, i) => (
              <tr key={i}>
                <td className="jcard-account" translate="no">
                  <span className="jcard-account-name">{accountText(line.account)}</span>
                </td>
                <SideCell className="jcard-debit" cents={line.debitCents} />
                <SideCell className="jcard-credit" cents={line.creditCents} />
                <td className="jcard-desc-col" data-je-desc="">
                  {line.description ? (
                    <span className="jcard-desc" title={line.description}>
                      {line.description}
                    </span>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <th scope="row">Total</th>
              <td className="num">{Number.isInteger(totals.debitCents) ? formatMoney(totals.debitCents) : ""}</td>
              <td className="num">{Number.isInteger(totals.creditCents) ? formatMoney(totals.creditCents) : ""}</td>
              <td className="jcard-desc-col" />
            </tr>
          </tfoot>
        </table>
      </div>
      )}
      {evidence.length ? (
        // WHAT IT WAS DRAFTED FROM, ON EVERY CARD (tg-shape, Q-SHAPE-4): the engine names
        // each entry's source (a schedule, an asset, a payout, the conversation); the
        // static card, unlike the live journal card, drew none of them.
        <ul className="jcard-evidence" aria-label="Supporting records" data-entry-evidence="">
          {evidence.map((ev, i) => (
            <li key={i} className="jcard-chip t-footnote">
              {ev.label}
            </li>
          ))}
        </ul>
      ) : null}
      {entry.block ? (
        <div className="jcard-foot shape-entry-foot" data-entry-block="">
          {/* The block's own note, when the engine says one (verify pass 7, e2e F10:
              another task's entry reads "Ready to approve on its card in X"). */}
          {typeof entry.block.note === "string" && entry.block.note ? (
            <p className="jcard-note t-footnote" data-entry-block-note="">
              {entry.block.note}
            </p>
          ) : approvedElsewhere(entry.block) ? null : (
            <p className="jcard-note t-footnote" data-entry-block-note="">
              This entry can’t be approved until that’s resolved.
            </p>
          )}
          {entry.block.action ? (
            <NextAction next={entry.block.action} also={[]} onOpenResult={onOpenResult} onStartTask={onStartTask} onAsk={onAsk} disabledReason={disabledReason} />
          ) : null}
        </div>
      ) : inPane ? (
        // In the pane the entry is read, not pressed: its approval is its card in the
        // conversation beside it. It says where it stands and who approves it.
        <div className="jcard-foot shape-entry-foot">
          <p className="jcard-note t-footnote" data-entry-who="">
            {entry.status === "posted"
              ? `${statusWordFor("posted", entry.je)}.`
              : entry.status === "approved"
                ? "Approved, waiting to post."
                : action && action.kind === "line"
                  ? action.words
                  : "Ready to approve. Approve it on its card in the conversation."}
          </p>
        </div>
      ) : action && action.kind === "commit" ? (
        // No live card stands behind this entry here, so no press is drawn: never a
        // fake Approve. Its entry in Records is where it is approved.
        <div className="jcard-foot shape-entry-foot">
          <p className="jcard-note t-footnote" data-entry-who="">
            {/* To the entry itself (route audit, 8 Nov 2026): bare /records opened Payouts. */}
            Approve it from its entry in <a className="link" href={entry.entryId ? entryHref(entry.entryId) : "/records?tab=entries"}>Records</a>.
          </p>
        </div>
      ) : action && action.kind === "line" ? (
        <div className="jcard-foot shape-entry-foot">
          <p className="jcard-note t-footnote" data-entry-who="">
            {action.words}
          </p>
        </div>
      ) : null}
    </article>
  );
}

/**
 * The approve-entries pane's Entries tab (founder, 17 Oct 2026): the headline, then every
 * entry as its own numbered card with its lines, a blocked one visibly blocked with the
 * action that resolves it. Read-only: each entry is approved on its card in the
 * conversation.
 */
export function PaneEntries({ entries, ledgerName = null, onOpenResult = null, onStartTask = null, onAsk = null }) {
  const items = entries && Array.isArray(entries.items) ? entries.items : [];
  if (!items.length) return null;
  return (
    <div className="shape-entries shape-pane-entries">
      {entries.headline ? (
        <p className="shape-entries-headline" data-entries-headline="">
          <BoundText text={reviewerWords(entries.headline, whoApprovesOf({ entries }))} figures={entries.figures || {}} ledgerName={ledgerName} />
        </p>
      ) : null}
      <ol className="shape-entry-cards" aria-label={`${items.length} ${items.length === 1 ? "entry" : "entries"}`}>
        {items.map((entry) => (
          <li key={entry.n} className="shape-entry" data-entry-n={entry.n} data-entry-of={entry.of} data-entry-blocked={entry.block ? "" : undefined}>
            <StaticEntryCard entry={entry} ledger={entries.ledger || null} ledgerName={ledgerName} onOpenResult={onOpenResult} onStartTask={onStartTask} onAsk={onAsk} inPane />
          </li>
        ))}
      </ol>
    </div>
  );
}
