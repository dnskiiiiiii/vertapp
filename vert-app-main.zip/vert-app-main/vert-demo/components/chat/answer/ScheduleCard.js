"use client";

// components/chat/answer/ScheduleCard.js — A ROUTINE FOR SCHEDULED, AND THE ONE PRESS THAT SETS IT UP
// ==============================================================================
// Audit row 23 (w48, 4 Nov 2026). "Every Friday check the bills" is answered with this
// card under the verdict: what runs, when, its name (a journal: the amount and both
// accounts), then ONE press. Nothing is set up, changed or stopped until it is pressed;
// the press sends the engine's own body to the route Scheduled's screen uses
// (schedule.js pressSchedule → lib/scheduled-client.js), so the role checks and the
// journal's validation are the routes'. Once the route says yes the card settles to
// "Set up · {name}, {cadence}" (one middle dot, design-fix-2 DA2-033) with the way to it in Scheduled. A refusal is the
// route's words, and the press stays.
//
// Labels are at most four words (founder, 31 Oct 2026: minimal copy). Every amount is
// the engine's integer, formatted, never worked out here.

import { useEffect, useState } from "react";

import { Button } from "@/components/ui";
import { formatMoney } from "@/lib/format";
import { cadenceWords as scheduleWords } from "@/lib/scheduled-model";
import { useWritesEnabled } from "@/lib/engine-context";
import { OPEN_LABEL, PRESS_LABEL, pressSchedule, scheduleShapeOf, settledFromList, settledLine, taskHref } from "./schedule";

const SAMPLE_REASON = "These are the sample books, so nothing can be set up here.";
const LOST = "The answer didn't come back. It may have gone through: check Scheduled before pressing again.";

export function ScheduleRows({ view }) {
  const changing = view.mode === "edit" && Boolean(view.body && view.body.cadence);
  const now = changing && view.current ? scheduleWords(view.current.cadence) : null;
  return (
    <dl className="shape-more">
      <div>
        <dt className="ink-2">What</dt> <dd translate="no">{view.name}</dd>
      </div>
      <div>
        <dt className="ink-2">{changing ? "New time" : "When"}</dt> <dd>{view.cadenceWords}</dd>
      </div>
      {now ? (
        <div>
          <dt className="ink-2">Now</dt> <dd>{now}</dd>
        </div>
      ) : null}
      {view.journal ? (
        <>
          <div>
            <dt className="ink-2">Amount</dt> <dd className="num" translate="no">{formatMoney(view.journal.amountCents)}</dd>
          </div>
          <div>
            <dt className="ink-2">Debit</dt> <dd translate="no">{view.journal.debit.label}</dd>
          </div>
          <div>
            <dt className="ink-2">Credit</dt> <dd translate="no">{view.journal.credit.label}</dd>
          </div>
        </>
      ) : null}
    </dl>
  );
}

export default function ScheduleCard({ schedule, press = pressSchedule, check = settledFromList }) {
  const view = scheduleShapeOf(schedule);
  const writes = useWritesEnabled();
  const [busy, setBusy] = useState(false);
  const [settled, setSettled] = useState(null);
  const [failed, setFailed] = useState(null);
  // After a reload the press is offered only if Scheduled doesn't already show the change.
  const key = view ? `${view.mode}:${view.taskId || ""}:${view.name}:${view.cadenceWords}` : "";
  useEffect(() => {
    if (!view || !writes) return undefined;
    let live = true;
    check(view).then((done) => {
      if (live && done) setSettled((was) => was || done);
    });
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, writes]);
  if (!view) return null;
  const label = PRESS_LABEL[view.mode] || null;
  const onPress = async () => {
    if (busy) return;
    setBusy(true);
    setFailed(null);
    const result = await press(view).catch(() => ({ ok: false, message: LOST }));
    setBusy(false);
    if (result && result.ok) setSettled(result);
    else setFailed((result && result.message) || LOST);
  };
  const href = settled && settled.task && settled.task.id ? taskHref(settled.task.id) : view.href;
  return (
    <section className="cc-answer" data-schedule-card="" data-schedule-mode={view.mode} aria-label="Scheduled routine">
      <ScheduleRows view={view} />
      {settled ? (
        <p role="status" data-schedule-settled="">
          {settled.already ? `Already set up · ${view.name}` : settledLine(view, settled.task)}{" "}
          <a className="link" href={href}>
            {OPEN_LABEL}
          </a>
        </p>
      ) : (
        <>
          <p className="ink-2">{view.words}</p>
          {failed ? (
            <p role="alert" className="ink-2" data-schedule-failed="">
              {failed}
            </p>
          ) : null}
          <p>
            {/* The routine is set up here, with the one press; "Open in Scheduled" beside it
                was a second way to the same thing (founder, 8 Nov 2026). With nothing to
                press, the link is the way to it. */}
            {label ? (
              <Button variant={view.mode === "end" ? "quiet" : view.mode === "pause" ? "secondary" : "commit"} destructive={view.mode === "end" ? true : undefined} size="sm" busy={busy} busyLabel="Saving…" disabledReason={writes ? undefined : SAMPLE_REASON} onClick={onPress} data-schedule-press="">
                {label}
              </Button>
            ) : (
              <a className="link" href={href} data-schedule-open="">
                {OPEN_LABEL}
              </a>
            )}
          </p>
        </>
      )}
    </section>
  );
}
