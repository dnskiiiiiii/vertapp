// components/chat/answer/reminders.js — PAYMENT REMINDER DRAFTS, READ FROM THE ENGINE
// ==============================================================================
// W3 feature 1 (28 Oct 2026). "Draft reminders" under the aged receivables asks the
// engine for one email per customer with overdue invoices (`POST /reminders/drafts`,
// the same object an answer may carry as `shape.reminders`). NOTHING HAS BEEN SENT when
// a draft is drawn: each one is the person's to edit, and it goes only on its own
// explicit press ("Approve & send"), or on "Approve & send selected" over the ticked
// ones. A customer reminded within the engine's resend window needs a second, explicit
// yes, sent as `confirmResend: true`. Every figure is the engine's cents; nothing here
// sums an invoice list (tests/no-arithmetic.test.js). A draft that doesn't read as the
// contract says is dropped whole, never half-drawn.
//
// CONTRACT v2 (28 Oct 2026, after an adversarial review):
//   · A DRAFT IS KEYED BY `draftId` (contact + currency + day), and so is every result
//     and every piece of state: one customer can owe in two currencies, and sending one
//     email must never mark the other sent.
//   · ONLY `intro` AND `closing` ARE THE PERSON'S. The invoice block between them is
//     written by the engine at send time from a fresh read of the ledger; `body` is a
//     read-only preview and is never sent.
//   · THE RECIPIENT defaults to the ledger's address (`ledgerAddress` here; the wire
//     names it after the vendor, read in one place: LEDGER_ADDRESS). Changing it, or
//     typing one where the ledger has none, is allowed and needs an explicit yes, sent as
//     `confirmRecipient: true`.
//   · `unknown` means the email MAY have been sent; it is said so, never "sent" and
//     never "not sent".
//
// It imports nothing, as aged-balances.js beside it.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const isInt = (v) => Number.isInteger(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;
const day = (v) => (typeof v === "string" && ISO_DAY.test(v) ? v : null);
const LINK = /^https:\/\//;
const link = (v) => (typeof v === "string" && LINK.test(v) ? v : null);
/** A date or null, and nothing else: a malformed date is a malformed draft. */
const dayOrNull = (v) => (v === null || v === undefined ? { ok: true, value: null } : day(v) ? { ok: true, value: v } : { ok: false });

const BACKENDS = new Set(["resend", "smtp"]);
export const RESULT_STATUSES = Object.freeze(["sent", "unknown", "failed", "needs_confirm", "refused"]);
/** The most emails one send request carries, here and in the engine (contract v2). */
export const MAX_EMAILS_PER_SEND = 50;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// The contact's address in the ledger (W3 contract v2, `ledgerAddress`): the recipient a
// draft defaults to. Vendor-neutral on the wire, as everywhere (tests/claims.test.js).
const LEDGER_ADDRESS = "ledgerAddress";
const looksLikeEmail = (v) => typeof v === "string" && EMAIL.test(v.trim());

function senderOf(raw) {
  if (!isObj(raw) || typeof raw.connected !== "boolean") return null;
  return {
    connected: raw.connected,
    backend: BACKENDS.has(raw.backend) ? raw.backend : null,
    fromAddress: text(raw.fromAddress),
    words: text(raw.words),
  };
}

function invoiceOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !day(raw.dueDate) || !isInt(raw.daysOverdue) || !isInt(raw.amountDueCents)) return null;
  const reminded = dayOrNull(raw.lastRemindedOn);
  if (!reminded.ok) return null;
  return {
    id: text(raw.id),
    number: text(raw.number),
    dueDate: raw.dueDate,
    daysOverdue: raw.daysOverdue,
    amountDueCents: raw.amountDueCents,
    payUrl: link(raw.payUrl),
    url: link(raw.url),
    lastRemindedOn: reminded.value,
  };
}

/** One draft, checked, or null. Pure. */
export function draftOf(raw) {
  if (!isObj(raw) || !text(raw.draftId) || !text(raw.contactId) || !text(raw.contactName)) return null;
  if (typeof raw.subject !== "string" || typeof raw.body !== "string" || !text(raw.currency) || !isInt(raw.overdueCents)) return null;
  if (typeof raw.needsConfirm !== "boolean") return null;
  // v2 names the ledger's address; a v1 draft only had `to`, which was that address.
  const ledgerAddress = LEDGER_ADDRESS in raw ? text(raw[LEDGER_ADDRESS]) : text(raw.to);
  const to = text(raw.to) || ledgerAddress;
  const toWords = text(raw.toWords);
  // No address and no word on why: nothing true to say about where it would go.
  if (!to && !toWords) return null;
  if (!Array.isArray(raw.invoices) || !raw.invoices.length) return null;
  const invoices = raw.invoices.map(invoiceOf);
  if (invoices.some((i) => !i)) return null;
  const reminded = dayOrNull(raw.lastRemindedOn);
  if (!reminded.ok) return null;
  // The two editable parts (v2). A draft without them (an older engine) is read and
  // shown, and can't be sent: there is nothing the person could edit that the engine
  // would take.
  const editable = typeof raw.intro === "string" && typeof raw.closing === "string";
  return {
    draftId: text(raw.draftId),
    contactId: text(raw.contactId),
    contactName: text(raw.contactName),
    to,
    ledgerAddress,
    toWords: to ? null : toWords,
    subject: raw.subject,
    body: raw.body,
    intro: editable ? raw.intro : null,
    closing: editable ? raw.closing : null,
    editable,
    currency: text(raw.currency),
    overdueCents: raw.overdueCents,
    invoices,
    listed: isInt(raw.listed) && raw.listed > 0 ? raw.listed : null,
    moreCount: isInt(raw.moreCount) && raw.moreCount > 0 ? raw.moreCount : 0,
    moreCents: isInt(raw.moreCents) ? raw.moreCents : null,
    payLinkWords: text(raw.payLinkWords),
    lastRemindedOn: reminded.value,
    needsConfirm: raw.needsConfirm,
    // Walk 4, W4-4: the engine's resend key is one per customer per day, so a second
    // resend the same day is refused. `canSendAgain: false` says so up front, with the
    // engine's words; absent is the old engine, which never said, and is offered as before.
    canSendAgain: raw.canSendAgain !== false,
    sendAgainWords: text(raw.sendAgainWords),
  };
}

/** `shape.reminders` (or `POST /reminders/drafts`'s answer), checked, or null. Pure. */
export function remindersOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean") return null;
  const sender = senderOf(raw.sender);
  if (!sender) return null;
  const base = {
    asAt: day(raw.asAt),
    measured: raw.measured,
    words: text(raw.words),
    resendDays: isInt(raw.resendDays) && raw.resendDays > 0 ? raw.resendDays : null,
    // The day "N days overdue" is counted to (w18 contract, W4-7): today, which can be a
    // day after the aged balances' month end. Said once above the drafts.
    asAtWords: text(raw.asAtWords),
    sender,
  };
  if (!raw.measured) {
    if (!base.words) return null;
    return { ...base, drafts: [] };
  }
  const drafts = (Array.isArray(raw.drafts) ? raw.drafts : []).map(draftOf).filter(Boolean);
  return { ...base, drafts };
}

/** The invoices the email itself lists (the engine's `listed`, oldest first). Pure. */
export function listedInvoices(draft) {
  if (!draft) return [];
  return draft.listed ? draft.invoices.slice(0, draft.listed) : draft.invoices;
}

/** Whether this draft needs the person's second yes before it goes again. Pure. */
export function confirmNeeded(draft) {
  return Boolean(draft && draft.needsConfirm);
}

/** What the person typed over the draft, or the draft as written. */
function edited(draft, edit = {}) {
  const e = isObj(edit) ? edit : {};
  return {
    to: typeof e.to === "string" ? e.to.trim() : draft.to || "",
    subject: typeof e.subject === "string" ? e.subject : draft.subject,
    intro: typeof e.intro === "string" ? e.intro : draft.intro || "",
    closing: typeof e.closing === "string" ? e.closing : draft.closing || "",
  };
}

/** The recipient as it stands, and whether it differs from the ledger's address. Pure. */
export function recipientChanged(draft, edit = {}) {
  if (!draft) return false;
  const { to } = edited(draft, edit);
  return Boolean(to) && to.toLowerCase() !== (draft.ledgerAddress || "").toLowerCase();
}

/** Said when the engine refuses another send today without words of its own (W4-4). */
export const NOT_AGAIN_TODAY = "Already sent today. Send again tomorrow.";

/**
 * Whether a draft can be sent now: `{ok, reason}`. Email has to be connected (else the
 * engine's own words on the sender); the draft has to be one the engine can take (v2);
 * and it needs an address: the ledger's, or one the person typed. A typed address IS
 * sendable; it goes only after the person confirms it (`recipientChanged`, then
 * `confirmRecipient`). Pure.
 */
export function canSendDraft(draft, sender, edit = {}) {
  if (!draft) return { ok: false, reason: "This draft couldn't be read." };
  if (!sender || !sender.connected) {
    return { ok: false, reason: (sender && sender.words) || "Email for reminders isn't connected yet." };
  }
  if (!draft.editable) return { ok: false, reason: "This draft was made by an older version of Vert. Draft the reminders again to send it." };
  if (draft.canSendAgain === false) return { ok: false, reason: draft.sendAgainWords || NOT_AGAIN_TODAY };
  const { to, subject } = edited(draft, edit);
  if (!to) {
    return { ok: false, reason: draft.ledgerAddress ? `Enter an email address for ${draft.contactName} to send this.` : draft.toWords || `There's no email address for ${draft.contactName} in your ledger; type one in and confirm it.` };
  }
  if (!looksLikeEmail(to)) return { ok: false, reason: `"${to}" isn't an email address.` };
  if (!subject.trim()) return { ok: false, reason: "Give the email a subject." };
  return { ok: true, reason: null };
}

/**
 * The email `POST /reminders/send` takes for one draft (v2), from the person's edit of
 * it: intro and closing, never a body. `confirmResend` and `confirmRecipient` are sent
 * only when the person said yes AND the draft needs it. Pure.
 */
export function emailOf(draft, edit = {}, { confirmResend = false, confirmRecipient = false } = {}) {
  const e = edited(draft, edit);
  const out = {
    draftId: draft.draftId,
    contactId: draft.contactId,
    invoiceIds: draft.invoices.map((i) => i.id),
    to: e.to,
    subject: e.subject,
    intro: e.intro,
    closing: e.closing,
  };
  // The customer's statement goes with it only when the person ticked it (w46).
  if (isObj(edit) && edit.attachStatement === true) out.attachStatement = true;
  if (confirmResend && confirmNeeded(draft)) out.confirmResend = true;
  // The engine asking (mustConfirmRecipient) is enough: the stored address may match and
  // the ask would otherwise come back on every press (verification item E).
  if (confirmRecipient && (recipientChanged(draft, edit) || draft.mustConfirmRecipient)) out.confirmRecipient = true;
  return out;
}

/** The yeses a draft still needs before it goes: `{resend, recipient}`. Pure. */
export function yesesNeeded(draft, edit = {}, { resendOk = false, recipientOk = false } = {}) {
  return { resend: confirmNeeded(draft) && !resendOk, recipient: recipientChanged(draft, edit) && !recipientOk };
}

/**
 * "Approve & send selected": the ticked drafts split. `emails` go now; `awaiting` need a
 * yes first (reminded recently, or a recipient that isn't the ledger's; `resendOk` and
 * `recipientOk` are Sets of draft ids already given it); `blocked` can't go, each with
 * its reason. Past MAX_EMAILS_PER_SEND ticked, `tooMany` is set and nothing goes: one
 * press sends one request, and part of a selection is not what was approved. `edits` is
 * draftId → the person's edit. Pure.
 */
export function selectedEmails(drafts, selected, edits = {}, sender = null, { resendOk = new Set(), recipientOk = new Set() } = {}) {
  const out = { emails: [], awaiting: [], blocked: [], tooMany: false };
  const picked = (Array.isArray(drafts) ? drafts : []).filter((d) => d && selected && selected.has(d.draftId));
  for (const d of picked) {
    const edit = (edits && edits[d.draftId]) || {};
    const can = canSendDraft(d, sender, edit);
    if (!can.ok) {
      out.blocked.push({ draft: d, reason: can.reason });
      continue;
    }
    const need = yesesNeeded(d, edit, { resendOk: resendOk.has(d.draftId), recipientOk: recipientOk.has(d.draftId) });
    if (need.resend || need.recipient) {
      out.awaiting.push(d);
      continue;
    }
    out.emails.push(emailOf(d, edit, { confirmResend: resendOk.has(d.draftId), confirmRecipient: recipientOk.has(d.draftId) }));
  }
  if (out.emails.length > MAX_EMAILS_PER_SEND || out.awaiting.length > MAX_EMAILS_PER_SEND || picked.length > MAX_EMAILS_PER_SEND) {
    return { ...out, emails: [], tooMany: true };
  }
  return out;
}

const CONFIRMS = new Set(["resend", "recipient"]);

function resultOf(raw) {
  if (!isObj(raw) || !text(raw.contactId) || !RESULT_STATUSES.includes(raw.status)) return null;
  return {
    draftId: text(raw.draftId),
    contactId: text(raw.contactId),
    currency: text(raw.currency),
    status: raw.status,
    confirm: raw.status === "needs_confirm" && CONFIRMS.has(raw.confirm) ? raw.confirm : null,
    ledgerAddress: text(raw[LEDGER_ADDRESS]),
    to: text(raw.to),
    messageId: text(raw.messageId),
    words: text(raw.words),
    lastRemindedOn: day(raw.lastRemindedOn),
    sentAt: text(raw.sentAt),
    canSendAgain: raw.canSendAgain !== false,
    sendAgainWords: text(raw.sendAgainWords),
  };
}

/** `POST /reminders/send`'s results, each checked; null when there is no list. Pure. */
export function sendResultsOf(raw) {
  if (!isObj(raw) || !Array.isArray(raw.results)) return null;
  return raw.results.map(resultOf).filter(Boolean);
}

/**
 * The draft a result is about: its `draftId`, else the one draft with the same contact
 * AND currency. Never the contact alone: a customer can have a draft per currency, and a
 * result that could be either is about neither. Pure.
 */
export function resultKey(result, drafts) {
  if (!result) return null;
  const list = Array.isArray(drafts) ? drafts : [];
  if (result.draftId) return list.some((d) => d.draftId === result.draftId) ? result.draftId : null;
  if (!result.currency) return null;
  const same = list.filter((d) => d.contactId === result.contactId && d.currency === result.currency);
  return same.length === 1 ? same[0].draftId : null;
}

const SENT_LIST = "Check Sent reminders before sending it again.";
const STATUS_WORDS = {
  sent: "Sent.",
  unknown: `May have been sent: the mail server took it and didn't confirm. ${SENT_LIST}`,
  failed: "Not sent.",
  refused: "Not sent: Vert refused it.",
};
const STATUS_TONE = { sent: "done", unknown: "attention", failed: "problem", needs_confirm: "attention", refused: "problem" };

/** A result in words: the engine's, else the status said plainly. Pure. */
export function resultWords(result) {
  if (!result) return "Vert didn't say what happened.";
  if (result.words) return result.words;
  if (result.status === "needs_confirm") {
    if (result.confirm === "recipient") return result.ledgerAddress ? `Not sent yet: the address in your ledger is ${result.ledgerAddress}. Confirm the one you typed to send.` : "Not sent yet: confirm the address you typed to send.";
    return result.lastRemindedOn ? `Not sent yet: reminded on ${result.lastRemindedOn}. Confirm to send again.` : "Not sent yet: reminded recently. Confirm to send again.";
  }
  return STATUS_WORDS[result.status] || "Vert didn't say what happened.";
}

/** A result's tone for its mark; the word always carries the meaning. Pure. */
export function resultTone(result) {
  return STATUS_TONE[result && result.status] || "neutral";
}

/** Whether a result means this draft is done here: sent, or may have been. Pure. */
export function wentOrMayHave(result) {
  return Boolean(result && (result.status === "sent" || result.status === "unknown"));
}

/* ───────────────────────── the sent list (GET /reminders/sends) ───────────────────────── */

const SEND_STATUSES = new Set(["sent", "unknown", "failed", "sending", "cancelled"]);

function sendRowOf(raw) {
  if (!isObj(raw) || !text(raw.sendId) || !SEND_STATUSES.has(raw.status)) return null;
  return {
    sendId: text(raw.sendId),
    contactId: text(raw.contactId),
    contactName: text(raw.contactName),
    invoiceIds: Array.isArray(raw.invoiceIds) ? raw.invoiceIds.filter((i) => typeof i === "string") : [],
    to: text(raw.to),
    ledgerAddress: text(raw[LEDGER_ADDRESS]),
    status: raw.status,
    sentBy: text(raw.sentBy),
    sentAt: text(raw.sentAt),
    subject: text(raw.subject),
    recipientEdited: raw.recipientEdited === true,
    bodyEdited: raw.bodyEdited === true,
    currency: text(raw.currency),
    words: text(raw.words),
  };
}

/** `GET /reminders/sends`, checked, newest first; null when there is no list. Pure. */
export function sendsOf(raw) {
  if (!isObj(raw) || !Array.isArray(raw.sends)) return null;
  const rows = raw.sends.map(sendRowOf).filter(Boolean);
  // ISO instants order as strings; a row with no time goes last.
  return rows.sort((a, b) => (a.sentAt === b.sentAt ? 0 : !a.sentAt ? 1 : !b.sentAt ? -1 : a.sentAt < b.sentAt ? 1 : -1));
}

const SEND_WORDS = { sent: "Sent", unknown: "May have been sent", failed: "Not sent", sending: "Being sent", cancelled: "Cancelled" };
const SEND_TONE = { sent: "done", unknown: "attention", failed: "problem", sending: "neutral", cancelled: "neutral" };

/** A sent-list row's status, in words. Pure. */
export function sendStatusWords(row) {
  return SEND_WORDS[row && row.status] || "Not known";
}

export function sendTone(row) {
  return SEND_TONE[row && row.status] || "neutral";
}

/** What was changed from the draft, in words: the recipient, the message. Pure. */
export function sendChanges(row, ledger = "your ledger") {
  const out = [];
  if (row && row.recipientEdited) out.push(row.ledgerAddress ? `recipient changed from ${row.ledgerAddress}` : `recipient typed in; ${ledger} had no address`);
  if (row && row.bodyEdited) out.push("message edited");
  return out;
}
