// components/chat/answer/supplier-statement.js — A SUPPLIER'S STATEMENT AGAINST THE LEDGER, READ
// ==============================================================================
// Function-fidelity audit row 21 (w49, 4 Nov 2026). The engine sends one supplier's
// statement reconciled to their bills, credits and payments in the ledger
// (vert_engine/supplier_statement.py shape_of; contract model
// agent_events.ShapeSupplierStatementRec): the two closing balances and the gap between
// them, the differences grouped statement only / ledger only / amounts differ (the
// engine's own labels, drawn as sent), each with what it contributes to the gap, and how many lines matched.
//
// A lookup only: every amount is the engine's integer, shown as sent; nothing is summed,
// netted or signed here. "Ties" only on the engine's tied: true over a checked tie. An
// unread side carries no balance and says why in the engine's words. A block that
// doesn't read as the contract says is dropped whole.
//
// It imports nothing.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const int = (v) => (Number.isInteger(v) ? v : null);
const count = (v) => (Number.isInteger(v) && v >= 0 ? v : null);
const ISO_DAY = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
// The ledger's own page for a record, as the engine built it (vert_engine/ledger_links.py).
const SAFE_URL = /^https:\/\/[a-z0-9.-]+\//;
// A place in this app (the bill inbox), never another origin.
const SAFE_HREF = /^\/[A-Za-z0-9/_?=&.-]*$/;
export const GROUP_KEYS = Object.freeze(["statement_only", "ledger_only", "amount_differs"]);
const MODES = new Set(["open_items", "activity"]);

function rowOf(raw, key) {
  if (!isObj(raw) || raw.group !== key || !text(raw.label) || !text(raw.why)) return null;
  if (int(raw.cents) === null) return null;
  if (raw.date != null && !(typeof raw.date === "string" && ISO_DAY.test(raw.date))) return null;
  const href = typeof raw.href === "string" && SAFE_HREF.test(raw.href) ? raw.href : null;
  return {
    kind: text(raw.kind) || "line",
    date: raw.date || null,
    reference: text(raw.reference),
    label: text(raw.label),
    cents: raw.cents,
    statement: int(raw.statementCents),
    ledger: int(raw.ledgerCents),
    why: text(raw.why),
    url: typeof raw.url === "string" && SAFE_URL.test(raw.url) ? raw.url : null,
    where: text(raw.where),
    // The bill inbox, offered only for a bill the ledger doesn't have.
    enterBill: raw.action === "enter_bill" && key === "statement_only" && href ? href : null,
  };
}

function groupOf(raw, key) {
  if (!isObj(raw) || raw.key !== key || !text(raw.label)) return null;
  const rows = (Array.isArray(raw.rows) ? raw.rows : []).map((r) => rowOf(r, key));
  if (rows.some((r) => r === null)) return null;
  const rowCount = count(raw.rowCount);
  const more = count(raw.moreRows);
  if (rowCount === null || more === null || rows.length + more !== rowCount) return null;
  return { key, label: text(raw.label), rows, rowCount, more, cents: int(raw.cents) };
}

/** The engine's `shape.supplierStatementRec`, read strictly, or null. Pure. */
export function supplierStatementRecOf(raw) {
  if (!isObj(raw) || !MODES.has(raw.mode) || typeof raw.asAt !== "string" || !ISO_DAY.test(raw.asAt)) return null;
  if (typeof raw.currency !== "string" || !/^[A-Z]{3}$/.test(raw.currency)) return null;
  const st = isObj(raw.statement) ? raw.statement : null;
  const xe = isObj(raw.ledger) ? raw.ledger : null;
  const tie = isObj(raw.tie) ? raw.tie : null;
  if (!st || !xe || !tie || !Array.isArray(raw.groups) || raw.groups.length !== GROUP_KEYS.length) return null;
  const groups = raw.groups.map((g, i) => groupOf(g, GROUP_KEYS[i]));
  if (groups.some((g) => g === null)) return null;
  const statementRead = st.measured === true;
  const ledgerRead = xe.measured === true;
  const closing = int(st.closingCents);
  const balance = int(xe.balanceCents);
  // An unread side carries no balance and says why (the contract's own rule).
  if (!statementRead && (closing !== null || !text(st.words))) return null;
  if (!ledgerRead && (balance !== null || !text(xe.words))) return null;
  const checked = closing !== null && balance !== null;
  if ((tie.checked === true) !== checked) return null;
  const gap = int(tie.gapCents);
  // The gap is the engine's figure, never worked out here (no-arithmetic): read as
  // sent, and only its tie word is checked against it.
  if (checked && (gap === null || tie.tied !== (gap === 0))) return null;
  if (!checked && (gap !== null || tie.tied === true || tie.tied === false)) return null;
  if (!text(tie.words)) return null;
  if ((!statementRead || !ledgerRead) && groups.some((g) => g.rows.length)) return null;
  const matched = count(raw.matchedCount);
  if (matched === null) return null;
  const lineCount = count(st.lineCount);
  return {
    contactName: text(raw.contactName),
    asAt: raw.asAt,
    currency: raw.currency,
    mode: raw.mode,
    documentName: isObj(raw.document) ? text(raw.document.name) : null,
    statement: { read: statementRead, words: text(st.words), closing, lineCount: lineCount === null ? 0 : lineCount },
    ledger: { read: ledgerRead, words: text(xe.words), balance },
    tie: { checked, tied: checked ? tie.tied : null, gap: checked ? gap : null, unexplained: checked ? int(tie.unexplainedCents) : null, words: text(tie.words) },
    matched,
    groups,
    words: text(raw.words),
  };
}

/** The tie line: "Ties", "Differs by …" (the gap's size, the engine's figure), or null
 *  when nothing was compared (the engine's words say why). Pure. */
export function tieLine(rec, money) {
  if (!rec || !rec.tie.checked) return null;
  if (rec.tie.tied) return "Ties";
  return `Differs by ${money(Math.abs(rec.tie.gap))}`;
}

/** "3 of 3 lines matched", "No line matched", or null when the statement wasn't read. Pure. */
export function matchedLine(rec) {
  if (!rec || !rec.statement.read || !rec.ledger.read) return null;
  const n = rec.statement.lineCount;
  if (!rec.matched) return n ? `No line of ${n} matched` : "No line matched";
  return `${rec.matched} of ${n} ${n === 1 ? "line" : "lines"} matched`;
}

/** The amount a row shows: what the statement says for a line only it has, the
 *  ledger's for one only the ledger has, the difference where both have it. Pure. */
export function rowAmount(row, key) {
  if (key === "statement_only") return row.statement !== null ? row.statement : row.cents;
  if (key === "ledger_only") return row.ledger;
  return row.cents;
}

/** The groups that have something in them. Pure. */
export function shownGroups(rec) {
  return rec ? rec.groups.filter((g) => g.rowCount > 0) : [];
}
