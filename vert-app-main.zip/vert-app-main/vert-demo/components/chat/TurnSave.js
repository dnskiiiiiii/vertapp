"use client";

// components/chat/TurnSave.js — THE INLINE SAVE UNDER A TURN THAT OFFERS A NOTE
// ==============================================================================
// Build plan §19.0.5, §19.7 F-PLAN ("the inline Save on a `propose_note` turn. There is
// no card"). When Vert's answer offers to keep something for this client ("Keep this
// for next month: Atlassian bills annually in March"), the sentence sits under the
// answer with one quiet Save. Pressed, it sends `note_save`
// (lib/agent/plan-actions.js saveNote); the line then says it was kept, and only once
// the engine said so. It is never the accent: keeping a note writes nothing to the books.
//
// Nothing is drawn in a build with nothing behind it: a Save that could not save would
// be a false affordance, so the sentence is shown with the reason instead.

import { useState } from "react";
import { saveNote } from "@/lib/agent/plan-actions";
import { useWritesEnabled } from "@/lib/engine-context";
import { SAMPLE_REASON } from "@/components/cards/words";

export default function TurnSave({ note, sessionId, seq = null, save = saveNote }) {
  const writesEnabled = useWritesEnabled();
  const [phase, setPhase] = useState(note && note.saved ? "saved" : "idle");
  const [message, setMessage] = useState(null);
  if (!note || typeof note.text !== "string" || !note.text.trim()) return null;

  async function press() {
    if (phase === "busy" || phase === "saved") return;
    setPhase("busy");
    setMessage(null);
    let answer = null;
    try {
      answer = await save(sessionId, { seq, text: note.text });
    } catch {
      answer = null;
    }
    if (answer && answer.ok) setPhase("saved");
    else {
      setPhase("idle");
      setMessage((answer && answer.message) || "Not saved. Nothing was kept.");
    }
  }

  return (
    <p className="turn-save t-footnote" data-turn-save={phase}>
      <span className="turn-save-text">{note.text}</span>{" "}
      {phase === "saved" ? (
        <span className="turn-save-done">Saved</span>
      ) : writesEnabled ? (
        <button type="button" className="chat-quiet" onClick={press} aria-busy={phase === "busy" ? "true" : undefined} data-turn-press="save">
          {phase === "busy" ? "Saving…" : "Save"}
        </button>
      ) : (
        <span className="turn-save-reason">{SAMPLE_REASON}</span>
      )}
      {message ? (
        <span className="chat-inline-error" role="alert">
          {" "}
          {message}
        </span>
      ) : null}
    </p>
  );
}
