"use client";

// components/chat/sources-context.js — THE WAY TO THE DATA AND SOURCES PANEL
// ==============================================================================
// p1 chat (23 Oct 2026). A turn's "Data fetched" block (WorkedFor.js) opens the panel
// (SourcesPanel.js) on its own turn through this context: `open(outline)` for that
// turn, `open(null)` for the whole conversation, and `openKey` (the open turn's key, or
// "all") so the pressed Open can say it is expanded. Outside a conversation it is null,
// and the block draws no Open: there is no panel to open.

import { createContext, useContext } from "react";

export const SourcesContext = createContext(null);

export function useSourcesPanel() {
  return useContext(SourcesContext);
}
