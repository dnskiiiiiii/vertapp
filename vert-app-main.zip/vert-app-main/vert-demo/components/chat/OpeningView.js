"use client";

// components/chat/OpeningView.js — THE REPLY, WHILE THE CONVERSATION PAGE LOADS
// ==============================================================================
// The conversation's loading screen. When the ask box handed over the conversation's
// first events (lib/agent/opening.js), they are drawn at once, as the page will draw
// them: your message and, without the assistant, what Vert can do now (eval C4: the
// reply within 2 s of Enter). Otherwise it is the skeleton, as before.
//
// It never follows the stream: the page's own render replaces it within a moment, and
// that render is the one that follows. The sources are "being read" here, because
// they are: the page has not arrived yet.

import { usePathname } from "next/navigation";
import { openingFor } from "@/lib/agent/opening";
import ConversationView from "./ConversationView";

const READING = new Promise(() => {});

/** The conversation id in `/chat/<id>`, decoded, or null for any other path. */
export function conversationIdOf(pathname) {
  const m = /^\/chat\/([^/?#]+)\/?$/.exec(typeof pathname === "string" ? pathname : "");
  if (!m) return null;
  try {
    return decodeURIComponent(m[1]);
  } catch {
    return m[1];
  }
}

export default function OpeningView({ children = null }) {
  const id = conversationIdOf(usePathname());
  const opening = id ? openingFor(id) : null;
  if (!opening) return children;
  return <ConversationView sessionId={id} session={opening.session} events={opening.events} sources={READING} preview />;
}
