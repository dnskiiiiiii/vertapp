// components/chat/questions/model.js — WHAT A QUESTION IS, AS DATA, BEFORE IT IS DRAWN
// ==============================================================================
// Build plan §4.0.10 (teardown standard 14): a question shows what it is about FIRST,
// offers Vert's best guess as option 1, pages "1 of N" when several arrive together,
// can be skipped where the engine allows it, and once answered is one grey Q → A line.
//
// Everything here is a pure function of the thread model's question items, so the
// anatomy, the pager and the answered line are tested without a browser
// (tests/clarification.test.js) and the components only draw what this decides.
//
// WHY THE PAGER LIVES HERE AND NOT IN STATE. Which question is open is a fact about the
// conversation (which are still unanswered), plus one choice a person made (the one they
// pressed). Deriving the open question from both, every render, means an answer that
// arrives on the stream moves the pager on by itself, and a pressed question that has
// since been answered can never leave the thread with nothing open.
// The month names have ONE copy, in lib/format.js (design-fix-2 DA2-087).
import { metaLine, MONTHS as SHORT_MONTHS, MONTHS_LONG as MONTHS } from "@/lib/format";

/** The keyboard hint under an open question: the keys already work, so say so. Esc only
 *  lets go of the card; it never skips (design-fix-2 D10), so no hint names it. */
export const KEY_HINT = Object.freeze({
  move: "↑↓ to move",
  choose: "Enter to use",
});

/** What a statement question takes: the bank import reads CSV only. */
export const FILE_ACCEPT = ".csv";

/** Every type a file question may ask for (§19.2 `FILE_ACCEPTS`, agent_events.py). */
export const FILE_ACCEPTS = Object.freeze([".csv", ".xlsx", ".pdf", ".png", ".jpg"]);

/**
 * Whether a file question asks for a DOCUMENT (anything but the CSV-only statement):
 * "Do you have last month's schedule? Upload it and I'll match its format" takes a
 * workbook, a PDF or a photo, goes to the documents store, and answers with the
 * document's id. A CSV-only question is the bank statement, and keeps its import.
 */
export function asksForDocument(form) {
  return Boolean(form && form.kind === "file" && typeof form.accept === "string" && form.accept !== FILE_ACCEPT && !isStatementQuestion(form));
}

// The fields a bank or card rec's statement question names (vert_engine bank_rec
// `form.field`): "statement" since the engine reads PDFs (ENG-RECS-e1), "statement_id"
// before it.
const STATEMENT_FIELDS = new Set(["statement", "statement_id"]);

/**
 * Whether a file question is the bank statement (D04 F3). Since the engine reads a PDF
 * statement it sends `accept: ".csv,.pdf"`, which the old rule ("anything but .csv is a
 * document") sent to the documents store: the file was answered with a document id,
 * the mapping and its confirm never appeared, and the engine asked again. The field
 * names the statement, whatever it accepts; the reading hints (`form.statement`) do too.
 */
export function isStatementQuestion(form) {
  if (!form || form.kind !== "file") return false;
  if (STATEMENT_FIELDS.has(form.field)) return true;
  return Boolean(form.statement && typeof form.statement === "object");
}

/** What a statement question's drop zone takes: the engine's `accept` when it is valid. */
export function statementAccept(form) {
  return form && acceptIsValid(form.accept) ? form.accept : FILE_ACCEPT;
}

/** The statement files already attached in this conversation (`form.attached`). */
export function attachedStatements(form) {
  const list = form && Array.isArray(form.attached) ? form.attached : [];
  const seen = new Set();
  const out = [];
  for (const a of list) {
    const id = a && typeof a.documentId === "string" ? a.documentId.trim() : "";
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id) || seen.has(id)) continue;
    seen.add(id);
    out.push({ documentId: id, name: typeof a.name === "string" && a.name.trim() ? a.name.trim() : "the attached statement" });
  }
  return out;
}

/**
 * THE ONE STATEMENT ATTACHED IS READ AT ONCE (verify pass 2, U24). Attached through the
 * composer, a statement took four presses (attach, send, "Use <file>", Import) where the
 * card's drop zone takes two: the question already knew the file and still waited for a
 * press to read it. Reading writes nothing (an inspection: dates, lines, totals, a
 * proposed reading), so when exactly one statement is attached the card reads it
 * straight away and opens on the read-as line, as a dropped file does. Two or more
 * attached is a choice, and stays one; a blocked card (a replay, a turn running) and one
 * that has already read something read nothing. Pure.
 */
export function attachedToReadNow(form, { blocked = false, read = null, reading = false } = {}) {
  if (blocked || reading || read) return null;
  const attached = attachedStatements(form);
  return attached.length === 1 ? attached[0] : null;
}

/** "A CSV or PDF exported from your bank." — what the statement drop zone takes. */
export function statementHelp(form) {
  const accept = statementAccept(form).split(",");
  const pdf = accept.includes(".pdf");
  return `${pdf ? "A CSV or PDF statement" : "A CSV exported"} from your bank. Nothing is imported until you say so.`;
}

/** `accept` is a comma-joined subset of FILE_ACCEPTS, each once; anything else is malformed. */
export function acceptIsValid(accept) {
  if (typeof accept !== "string" || !accept) return false;
  const parts = accept.split(",");
  return new Set(parts).size === parts.length && parts.every((p) => FILE_ACCEPTS.includes(p));
}

const KIND_WORDS = { ".xlsx": "an Excel workbook", ".csv": "a CSV", ".pdf": "a PDF", ".png": "a photo", ".jpg": "a photo" };

/**
 * The drop zone's help line for a document question, in the copy-format wording: what
 * it takes, in words, and what Vert does with it. Nothing is posted from a file.
 *
 * `brief` (Month-end, W0c CO-21): the help without its last clause. "Nothing is posted
 * until you approve" brought approval and posting onto a Month-end that already held
 * five ideas (§9.1 S4, eval r3 F15; tests/month-all-cards.test.js). In the
 * conversation the whole sentence stays: there the file is the subject.
 */
export function documentHelp(form, { brief = false } = {}) {
  const kinds = [...new Set((form && typeof form.accept === "string" ? form.accept.split(",") : []).map((a) => KIND_WORDS[a]).filter(Boolean))];
  const list = kinds.length > 1 ? `${kinds.slice(0, -1).join(", ")} or ${kinds[kinds.length - 1]}` : kinds[0] || "a file";
  const what = `${list[0].toUpperCase()}${list.slice(1)}. Vert copies its format and reads its figures`;
  return brief ? `${what}.` : `${what}; nothing is posted until you approve.`;
}

/** The most evidence rows a question shows (§4.2: a table of ≤ 5 rows). */
export const EVIDENCE_ROWS = 5;

/** Whether this question may be skipped. `skippable` is the iteration-2 field; an
 *  iteration-1 question carries only `allowSkip`, and still replays. */
export function isSkippable(item) {
  if (!item) return false;
  if (typeof item.skippable === "boolean") return item.skippable;
  return item.allowSkip === true;
}

/** The question's evidence, cut to what may be shown, or null when it carries none. */
export function evidenceOf(item) {
  const e = item && item.evidence;
  if (!e || typeof e !== "object") return null;
  const table = e.table && Array.isArray(e.table.columns) && e.table.columns.length && Array.isArray(e.table.rows) && e.table.rows.length
    ? { columns: e.table.columns.filter((c) => c && c.key), rows: e.table.rows.slice(0, EVIDENCE_ROWS) }
    : null;
  const quote = e.quote && typeof e.quote.text === "string" && e.quote.text.trim()
    ? { text: e.quote.text, source: typeof e.quote.source === "string" ? e.quote.source : "" }
    : null;
  return table || quote ? { table, quote } : null;
}

/**
 * What is wrong with a question's anatomy (§4.0.10), as sentences; empty when it is
 * whole. The engine refuses most of these at emit time (vert_engine/agent_events.py
 * `Clarification`); this is the demo's own reading of the same rule, so a question
 * that reaches the screen malformed is caught here as well, not trusted.
 */
export function anatomyProblems(item) {
  const problems = [];
  if (!item || typeof item !== "object") return ["not a question"];
  if (!item.title || !String(item.title).trim()) problems.push("it has no title");
  if (!evidenceOf(item)) problems.push("it shows no evidence: a table of the lines it is about, or a quoted source line");
  const evidence = item.evidence && item.evidence.table;
  if (evidence && Array.isArray(evidence.rows) && evidence.rows.length > EVIDENCE_ROWS) {
    problems.push(`its evidence has ${evidence.rows.length} rows; a question shows at most ${EVIDENCE_ROWS}`);
  }
  const options = Array.isArray(item.options) ? item.options : [];
  if (options.length && options[0].bestGuess !== true) problems.push("option 1 is not marked as Vert's best guess");
  if (options.slice(1).some((o) => o && o.bestGuess === true)) problems.push("a best guess is marked somewhere other than option 1");
  const form = item.form;
  if (form && form.kind === "file" && !acceptIsValid(form.accept)) problems.push(`a file question takes some of ${FILE_ACCEPTS.join(",")}, not ${JSON.stringify(form.accept)}`);
  if (form && form.kind === "account" && item.allowOther) problems.push("an account is chosen from the chart, never typed");
  if (item.batch && !(Number.isInteger(item.batch.index) && Number.isInteger(item.batch.of) && item.batch.index >= 1 && item.batch.index <= item.batch.of)) {
    problems.push("its place in the batch is not within the batch");
  }
  if (!options.length && !form && !item.allowOther) problems.push("it cannot be answered: no options, no form, no free answer");
  return problems;
}

/* ── the pager ─────────────────────────────────────────────────────────────── */

/**
 * The questions asked together with `item`: the run of consecutive questions in the
 * thread that carry a `batch` and belong to the same "1 of N". A question with no
 * batch is a batch of one. Consecutive, because the engine emits a batch as one run of
 * events (vert_engine/workflows/player.py), and a later run of questions is a new batch
 * that starts again at 1.
 */
export function batchOf(items, item) {
  const questions = (Array.isArray(items) ? items : []).filter((i) => i && i.kind === "question");
  if (!item || !item.batch) return [item].filter(Boolean);
  const at = questions.findIndex((q) => q.questionId === item.questionId);
  if (at < 0) return [item];
  let start = at;
  while (start > 0 && sameBatch(questions[start - 1], questions[start])) start -= 1;
  let end = at;
  while (end < questions.length - 1 && sameBatch(questions[end], questions[end + 1])) end += 1;
  return questions.slice(start, end + 1);
}

function sameBatch(a, b) {
  return Boolean(a && b && a.batch && b.batch && a.batch.of === b.batch.of && b.batch.index === a.batch.index + 1);
}

/**
 * Which question is open. The one a person pressed, while it is still unanswered;
 * otherwise the next unanswered question after it (Skip and an answer both move on);
 * otherwise the first unanswered question in the thread. Null when none is open.
 */
export function activeQuestionId(items, pressedId = null) {
  const questions = (Array.isArray(items) ? items : []).filter((i) => i && i.kind === "question");
  if (pressedId != null) {
    const at = questions.findIndex((q) => q.questionId === pressedId);
    if (at >= 0) {
      if (!questions[at].answer) return pressedId;
      const after = questions.slice(at + 1).find((q) => !q.answer);
      if (after) return after.questionId;
    }
  }
  const first = questions.find((q) => !q.answer);
  return first ? first.questionId : null;
}

/**
 * The open question the composer's words answer (D10: "What is the entry for?" was
 * open, the person typed the memo into the composer, and it went out as a message the
 * task never took as the answer). Only a question that asks for words and nothing else
 * — no options to choose, no form, "Something else…" its one way to answer — takes
 * them; any other question stays answered on its card. Null when there is none. Pure.
 */
export function composerAnswers(items) {
  const id = activeQuestionId(items);
  if (id == null) return null;
  const q = (Array.isArray(items) ? items : []).find((i) => i && i.kind === "question" && i.questionId === id);
  if (!q || q.answer) return null;
  const options = Array.isArray(q.options) ? q.options.length : 0;
  const form = q.form && typeof q.form === "object" ? q.form : null;
  return !options && !form && q.allowOther === true ? q : null;
}

/**
 * The pager an open question draws: "2 of 3", and the unanswered questions of the same
 * batch before and after it (the ‹ and › go only to questions still asking something).
 * Null for a question asked alone.
 */
export function pagerFor(items, item) {
  if (!item || !item.batch || !(item.batch.of > 1)) return null;
  const batch = batchOf(items, item);
  const at = batch.findIndex((q) => q.questionId === item.questionId);
  const before = batch.slice(0, at).reverse().find((q) => !q.answer);
  const after = batch.slice(at + 1).find((q) => !q.answer);
  // COUNTED FROM WHAT IS STILL ASKED (verify pass 2, W11). With Q2 answered out of order
  // the last open question read "1 of 2" under a header saying "Vert needs 1 answer".
  // The pager counts the questions still open (this one among them), so it agrees with
  // the header; with one left there is nothing to page and no pager.
  const open = batch.filter((q) => !q.answer || q.questionId === item.questionId);
  if (open.length <= 1) return null;
  return {
    index: open.findIndex((q) => q.questionId === item.questionId) + 1,
    of: open.length,
    previousId: before ? before.questionId : null,
    nextId: after ? after.questionId : null,
  };
}

/**
 * Where "Answer later" goes on a question Vert needs answered (W11): the next unanswered
 * question of its batch, else the one before. Null when it is the only one left, where
 * "later" would be nowhere. Nothing is sent: the question stays open in the batch, and
 * the run waits for it as it already does. Pure.
 */
export function laterTarget(pager) {
  if (!pager) return null;
  if (pager.nextId != null) return pager.nextId;
  if (pager.previousId != null) return pager.previousId;
  return null;
}

/**
 * Skip, then open the next question of the batch. The skip is sent like any answer;
 * only once it is recorded does the pager move, so a skip that failed leaves the
 * person on the question they skipped, with the failure shown there. Returns the
 * send's result. `send` is `(answer) → result`; `onPage` is `(questionId) → void`.
 */
export async function skipAndAdvance(send, pager, onPage) {
  const result = await send({ skip: true });
  if (result && result.ok && pager && pager.nextId != null && typeof onPage === "function") onPage(pager.nextId);
  return result;
}

/* ── the answered line ─────────────────────────────────────────────────────── */

/**
 * The answer half of the one Q → A line. A chosen option reads as its label, a typed
 * answer as typed, a statement upload as what it was (the import's id is a reference
 * for the engine, not words for a person), and a skip as "Skipped".
 */
export function answerWords(item) {
  const a = item && item.answer;
  if (!a) return null;
  if (a.skipped) return a.settledBy || "Skipped";
  const form = item.form;
  if (form && form.kind === "file") {
    const v = a.value && typeof a.value === "object" ? a.value : null;
    if (v && typeof v.documentId === "string") return typeof v.name === "string" && v.name.trim() ? `Uploaded ${v.name.trim()}` : "File uploaded";
    if (v && typeof v.importId === "string" && typeof v.name === "string" && v.name.trim()) return `Uploaded ${v.name.trim()}`;
    return asksForDocument(form) ? "File uploaded" : "Statement uploaded";
  }
  if (a.optionId != null && Array.isArray(item.options)) {
    const option = item.options.find((o) => o.id === a.optionId);
    if (option) return option.label;
  }
  if (form && form.kind === "account" && a.label != null && Array.isArray(item.options)) {
    const option = item.options.find((o) => String(o.id) === String(a.label));
    if (option) return option.label;
  }
  // A month picked in the month field arrives as "2026-06": said as the month (p1 e2e).
  if (form && form.kind === "month" && typeof a.label === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(a.label.trim())) {
    const [y, m] = a.label.trim().split("-").map(Number);
    return `${MONTHS[m - 1]} ${y}`;
  }
  return a.label || "Answered";
}

/** The name of the file an answered `file` question was answered with, or null (D04). Pure. */
export function answerFileName(item) {
  const a = item && item.answer;
  if (!a || a.skipped || !item.form || item.form.kind !== "file") return null;
  const v = a.value && typeof a.value === "object" ? a.value : null;
  return v && (typeof v.importId === "string" || typeof v.documentId === "string") && typeof v.name === "string" && v.name.trim() ? v.name.trim() : null;
}

/* ── the chart picker ──────────────────────────────────────────────────────── */

/**
 * The chart's accounts that match what was typed into the picker's filter, by number
 * or name, keeping the engine's order (the best guess stays first). The filter narrows
 * the list; it is never itself an answer, so an account is always one the chart has.
 */
export function filterAccounts(options, query) {
  const list = Array.isArray(options) ? options : [];
  const q = typeof query === "string" ? query.trim().toLowerCase() : "";
  if (!q) return list;
  return list.filter((o) => String(o.label || "").toLowerCase().includes(q) || String(o.detail || "").toLowerCase().includes(q));
}

/* ── the statement upload ──────────────────────────────────────────────────── */

/** Why a dropped file is not one a DOCUMENT question takes, or null when it is. */
export function documentRefusal(file, accept) {
  const name = file && typeof file.name === "string" ? file.name : "";
  if (!name) return "Choose a file to upload.";
  const allowed = (typeof accept === "string" ? accept.split(",") : FILE_ACCEPTS).map((a) => a.toLowerCase());
  const ext = (/\.[a-z0-9]+$/i.exec(name) || [""])[0].toLowerCase();
  const ok = allowed.includes(ext) || (ext === ".jpeg" && allowed.includes(".jpg"));
  return ok ? null : `${name} isn't a type this question takes (${allowed.join(", ")}).`;
}

/** The answer an uploaded document gives its question: its id and name, as the value. */
export function documentAnswer(questionId, chip) {
  return chip && typeof chip.documentId === "string" && chip.documentId ? { questionId, value: { documentId: chip.documentId, name: chip.name } } : null;
}

/**
 * A document question's whole press: check the type, upload, and only then answer.
 * `upload(file, { session })` → `{ ok, chip }` (DocumentView.js `uploadFile`). Returns
 * `{ ok: true, chip, answer }` or `{ ok: false, refusal }`, and NEVER answers a question
 * with a file the store did not confirm: an answer carrying an id nobody stored would
 * resume the task on nothing. Never throws.
 */
export async function uploadThenAnswer(file, { questionId, accept, upload, session = null }) {
  const refused = documentRefusal(file, accept);
  if (refused) return { ok: false, refusal: refused };
  if (typeof upload !== "function") return { ok: false, refusal: "This build can't read files, so nothing was sent." };
  let result;
  try {
    result = await upload(file, { session });
  } catch {
    result = null;
  }
  const answer = result && result.ok ? documentAnswer(questionId, result.chip) : null;
  if (!answer) return { ok: false, refusal: (result && result.message) || `${file.name} wasn't read. Nothing was stored.` };
  return { ok: true, chip: result.chip, answer };
}

/** Why a dropped or chosen file is not one this question reads, or null when it is. */
export function fileRefusal(file, accept = FILE_ACCEPT) {
  const pdf = typeof accept === "string" && accept.split(",").includes(".pdf");
  if (!file) return pdf ? "Choose the statement your bank gave you, as a CSV or PDF." : "Choose a CSV file exported from your bank.";
  const name = typeof file.name === "string" ? file.name : "";
  if (pdf && /\.pdf$/i.test(name)) return null;
  if (!/\.csv$/i.test(name)) {
    return pdf
      ? `${name || "That file"} isn't a CSV or PDF. Use the statement your bank gave you, as a CSV or PDF.`
      : `${name || "That file"} isn't a CSV. Export the statement from your bank as CSV.`;
  }
  return null;
}

/**
 * Read a statement for a question: the file goes to the existing statement import
 * (`POST /bank-statements`, through the server action), which reads it and WRITES
 * NOTHING. The mapping and the commit that follow are the import's own two-press gate
 * (components/settings/BankStatementMapping.js), unchanged; only its committed import
 * id comes back here, as the answer.
 *
 * `upload` is the server action `(previous, formData) → outcome`. Never throws.
 */
export async function readStatement(file, upload, hints = null, accept = FILE_ACCEPT) {
  const refusal = fileRefusal(file, accept);
  if (refusal) return { ok: false, remedy: refusal, reason: null, rowNumber: null, inspection: null };
  if (typeof upload !== "function") {
    return { ok: false, remedy: "This build can't read files, so nothing was sent.", reason: null, rowNumber: null, inspection: null };
  }
  const form = new FormData();
  form.append("file", file, file.name);
  // What the question already knows (see `statementHints`), sent so the service can
  // preview that reading. Proposals only: the service still writes nothing.
  if (hints) {
    form.append("account_id", hints.account_id);
    form.append("currency", hints.currency);
    form.append("deposits_are_positive", hints.deposits_are_positive ? "true" : "false");
  }
  try {
    const outcome = await upload(null, form);
    return outcome && typeof outcome === "object" ? named(outcome, file.name) : { ok: false, remedy: "The file wasn't read. Nothing was imported.", reason: null, rowNumber: null, inspection: null };
  } catch {
    return { ok: false, remedy: "The file didn't reach Vert. Nothing was imported.", reason: null, rowNumber: null, inspection: null };
  }
}

/**
 * Read a statement ALREADY ATTACHED in this conversation (`form.attached`, D04): the
 * same inspection, sent with `document_id` in place of a file, and the same mapping
 * and confirm after it. Never throws.
 */
export async function readAttachedStatement(attached, upload, hints = null) {
  if (!attached || !attached.documentId) return { ok: false, remedy: "That statement isn't one Vert holds. Nothing was imported.", reason: null, rowNumber: null, inspection: null };
  if (typeof upload !== "function") {
    return { ok: false, remedy: "This build can't read files, so nothing was sent.", reason: null, rowNumber: null, inspection: null };
  }
  const form = new FormData();
  form.append("document_id", attached.documentId);
  form.append("file_name", attached.name || "");
  if (hints) {
    form.append("account_id", hints.account_id);
    form.append("currency", hints.currency);
    form.append("deposits_are_positive", hints.deposits_are_positive ? "true" : "false");
  }
  try {
    const outcome = await upload(null, form);
    return outcome && typeof outcome === "object" ? named(outcome, attached.name) : { ok: false, remedy: "The statement wasn't read. Nothing was imported.", reason: null, rowNumber: null, inspection: null };
  } catch {
    return { ok: false, remedy: "The request didn't reach Vert. Nothing was imported.", reason: null, rowNumber: null, inspection: null };
  }
}

/**
 * A read that went well carries the file's name (verify pass 7, D04). Connections' own
 * inspection (`inspectStatementAction`, used when the question proposes no reading)
 * answers without `fileName`, so the import answered "Statement uploaded" and no chip
 * of the dropped file stood in the conversation. The name is the file the person chose,
 * kept when the action named it already. Pure.
 */
function named(outcome, name) {
  if (!outcome.ok || (typeof outcome.fileName === "string" && outcome.fileName.trim())) return outcome;
  return typeof name === "string" && name.trim() ? { ...outcome, fileName: name.trim() } : outcome;
}

/**
 * The answer a committed import gives its question: the import's id, as the value; with
 * the file's name, `{importId, name}` (verify pass 5, D04: the answered card read
 * "Statement uploaded" with no file, since the id alone names nothing; the engine reads
 * `value.importId`, bank_reconciliation.py `_text_answer` / reads.py `_uploaded_import`).
 */
export function importAnswer(questionId, outcome, fileName = null) {
  const id = outcome && outcome.ok && typeof outcome.importId === "string" ? outcome.importId.trim() : "";
  if (!id) return null;
  const name = typeof fileName === "string" && fileName.trim() ? fileName.trim().slice(0, 200) : null;
  return name ? { questionId, value: { importId: id, name } } : { questionId, value: id };
}

/* ── a statement the question already knows how to read (eval iter2 r1, flow 4) ── */

/**
 * The reading a `file` question proposes (`form.statement`: the account, its currency,
 * its sign convention), or null. All three or nothing: a partial proposal would leave
 * the person stating the rest on the full form anyway, and that form is the fallback.
 */
export function statementHints(form) {
  const s = form && form.kind === "file" && form.statement;
  if (!s || typeof s !== "object") return null;
  const account = typeof s.account_id === "string" ? s.account_id.trim() : "";
  const currency = typeof s.currency === "string" ? s.currency.trim().toUpperCase() : "";
  if (!account || currency.length !== 3 || typeof s.deposits_are_positive !== "boolean") return null;
  return {
    account_id: account,
    account_name: typeof s.account_name === "string" && s.account_name.trim() ? s.account_name.trim() : account,
    currency,
    deposits_are_positive: s.deposits_are_positive,
  };
}

/**
 * The question's reading as the full mapping form's proposals (lib/bank-import.js
 * `mappingChoices` `stated`), or null. When Edit opens the form, or the service would
 * not preview the reading, the rec's own account, currency and sign are still shown as
 * "Vert suggests … Check it." (production, 5 Nov 2026: the 090 rec's form asked for all
 * three, the account as free text). Proposals only: the person still confirms. Pure.
 */
export function statedFromHints(hints) {
  if (!hints) return null;
  // The engine's hint says money arriving is negative only for a card (D48b): the kind
  // rides along so the file's balance proof is read as a card's, never against it.
  return { account_id: hints.account_id, currency: hints.currency, deposits_are_positive: hints.deposits_are_positive ? "yes" : "no", kind: hints.deposits_are_positive ? "bank" : "card" };
}

const PREVIEW_KEYS = ["date_column", "description_column", "amount_column", "date_format", "currency", "account_id"];

/**
 * The service's preview of a proposed reading, checked, or null. Null whenever any
 * part is missing — above all the token — so the one-press import is offered only on
 * a reading the service itself echoed; anything less falls back to the full form.
 */
export function previewOf(raw) {
  if (!raw || typeof raw !== "object") return null;
  const m = raw.mapping;
  if (!m || typeof m !== "object" || typeof m.deposits_are_positive !== "boolean") return null;
  if (!PREVIEW_KEYS.every((k) => typeof m[k] === "string" && m[k].trim())) return null;
  if (typeof raw.confirmation !== "string" || !raw.confirmation.trim()) return null;
  if (!Number.isInteger(raw.lines) || raw.lines < 1) return null;
  return {
    mapping: { ...m },
    lines: raw.lines,
    moneyIn: Number.isInteger(raw.money_in) ? raw.money_in : null,
    moneyOut: Number.isInteger(raw.money_out) ? raw.money_out : null,
    // The engine's totals, in cents, when it sends them (bug bash 10 Oct 2026): money in
    // and out are positive sums; the closing balance is signed, or null when the file
    // gives none. Absent is null, never 0: a total nobody sent is not a zero.
    moneyInMinor: Number.isInteger(raw.money_in_minor) && raw.money_in_minor >= 0 ? raw.money_in_minor : null,
    moneyOutMinor: Number.isInteger(raw.money_out_minor) && raw.money_out_minor >= 0 ? raw.money_out_minor : null,
    closingBalanceMinor: Number.isInteger(raw.closing_balance_minor) ? raw.closing_balance_minor : null,
    first: typeof raw.first === "string" ? raw.first : null,
    last: typeof raw.last === "string" ? raw.last : null,
    skipped: Number.isInteger(raw.skipped) ? raw.skipped : 0,
    echo: typeof raw.echo === "string" ? raw.echo : "",
    confirmation: raw.confirmation.trim(),
  };
}

/** "Date, Description, Amount (charges positive), AUD": the whole mapping, one line
 *  (design-fix-2 DA2-033: commas, not a row of middle dots).
 *  A card's convention is said in a card's words; a bank's in a bank's. */
export function readingLine(preview, { card = false } = {}) {
  if (!preview) return "";
  const m = preview.mapping;
  const sign = m.deposits_are_positive
    ? (card ? "payments positive" : "deposits positive")
    : (card ? "charges positive" : "deposits negative");
  return `${m.date_column}, ${m.description_column}, ${m.amount_column} (${sign}), ${m.currency}`;
}

function shortDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso || "");
  return m ? `${Number(m[3])} ${SHORT_MONTHS[Number(m[2]) - 1]}` : null;
}

function counted(n, one, many) {
  return `${n} ${n === 1 ? one : many}`;
}

/**
 * What the reading produced, in the words a person checks against the statement in
 * front of them: "10 lines: 9 charges, 1 payment · 3 Jun – 30 Jul". The counts are
 * the check the echo exists for — a wrong sign shows as 1 charge and 9 payments.
 */
export function previewCountsLine(preview, { card = false } = {}) {
  if (!preview) return "";
  const parts = [counted(preview.lines, "line", "lines")];
  const charges = card ? preview.moneyOut : preview.moneyIn;
  const others = card ? preview.moneyIn : preview.moneyOut;
  // With the engine's totals, the totals line (previewTotals) says in and out in dollars,
  // which is what a person holds against the statement; the counts are kept only when
  // the totals did not come.
  if (charges !== null && others !== null && !hasTotals(preview)) {
    parts[0] += card
      ? `: ${counted(charges, "charge", "charges")}, ${counted(others, "payment", "payments")}`
      : `: ${counted(charges, "in", "in")}, ${counted(others, "out", "out")}`;
  }
  const from = shortDate(preview.first);
  const to = shortDate(preview.last);
  if (from && to) parts.push(from === to ? from : `${from} to ${to}`);
  if (preview.skipped) parts.push(`${counted(preview.skipped, "row", "rows")} skipped`);
  return metaLine(parts, { joiner: "; " });
}

function hasTotals(preview) {
  return Boolean(preview) && preview.moneyInMinor !== null && preview.moneyOutMinor !== null;
}

/**
 * The statement's totals as the import will read them, `[{ key, label, cents }]`, or []
 * when the engine sent none: "Money in $1,250.00 · Money out $980.40 · Closing balance
 * $5,310.12" for a bank, "Charges … · Payments …" for a card (a card's charges are its
 * money out). Bug bash 10 Oct 2026: the preview said only how many lines went each way,
 * and a person checks a statement by its totals. The closing balance is listed only when
 * the engine sent one. Cents only; StatementReady draws each through Figure.
 */
export function previewTotals(preview, { card = false } = {}) {
  if (!hasTotals(preview)) return [];
  const rows = card
    ? [
        { key: "money_out", label: "Charges", cents: preview.moneyOutMinor },
        { key: "money_in", label: "Payments", cents: preview.moneyInMinor },
      ]
    : [
        { key: "money_in", label: "Money in", cents: preview.moneyInMinor },
        { key: "money_out", label: "Money out", cents: preview.moneyOutMinor },
      ];
  if (preview.closingBalanceMinor !== null) rows.push({ key: "closing_balance", label: "Closing balance", cents: preview.closingBalanceMinor });
  return rows;
}

/** The confirm form for the previewed reading, token included: the body
 *  `confirmStatementAction` sends. Exactly the previewed facts, so the token matches. */
export function previewFormData(inspectionId, preview) {
  const data = new FormData();
  data.append("inspection_id", inspectionId || "");
  for (const key of PREVIEW_KEYS) data.append(key, preview.mapping[key]);
  data.append("deposits_are_positive", preview.mapping.deposits_are_positive ? "yes" : "no");
  data.append("confirmation", preview.confirmation);
  return data;
}

/* ── last month's schedule, in the person's own format ─────────────────────── */

/**
 * The engine's prior-schedule question id is `prior_schedule:{template}`, and a re-ask
 * after a file it could not read is `prior_schedule:{template}:{short}` (engine
 * workflows/templates/modify_workbook.py `prior_qid`). Restated here because the
 * thread is all the screen has.
 */
export const PRIOR_QUESTION = "prior_schedule";

/**
 * The result each schedule template lays into the person's file: only that card is
 * served in their format (engine vert_api/routers/workpapers.py `_PRIOR_CARDS`). Any
 * other result of the conversation (a plan, a journal) has no copy of theirs, so it is
 * never offered one.
 */
export const PRIOR_CARDS = Object.freeze({
  prepaid_schedule: "prepaid",
  deferred_revenue: "deferred_revenue",
  fixed_asset_rollforward: "fixed_asset_rollforward",
});


/**
 * "Fixed assets June 2026.xlsx" → "Fixed assets July 2026.xlsx" for `2026-07`: the copy
 * is this month's schedule, so it is not offered under last month's name (the engine
 * names the download the same way, workpapers.py `month_named`). A name with no month
 * in it is kept as the person wrote it.
 */
export function monthNamed(name, period) {
  const text = typeof name === "string" ? name.trim() : "";
  const m = /^(\d{4})-(\d{2})$/.exec(typeof period === "string" ? period : "");
  if (!text || !m) return text;
  const year = Number(m[1]);
  const month = Number(m[2]);
  if (month < 1 || month > 12) return text;
  const [py, pm] = month === 1 ? [year - 1, 12] : [year, month - 1];
  const before = `${MONTHS[pm - 1]} ${py}`;
  const now = `${MONTHS[month - 1]} ${year}`;
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const out = text.replace(new RegExp(esc(before), "gi"), now);
  return out.replace(new RegExp(`\\b${esc(`${before.slice(0, 3)} ${py}`)}\\b`, "gi"), `${now.slice(0, 3)} ${year}`);
}

function priorTemplateOf(questionId) {
  if (typeof questionId !== "string") return null;
  const parts = questionId.split(":");
  return parts[0] === PRIOR_QUESTION && parts[1] && Object.prototype.hasOwnProperty.call(PRIOR_CARDS, parts[1]) ? parts[1] : null;
}

/**
 * Which schedule results the person's own format is delivered for, from the thread's
 * questions alone: `{ [template]: { documentId, name } }` for each template whose LATEST
 * prior-schedule question was answered with an uploaded file. A skip keeps Vert's
 * layout, and an open re-ask (the file could not be read) means there is no copy of
 * theirs yet, so neither offers one: a chip that downloaded a workbook nobody could
 * make would be a control that lies (tests/no-false-affordance.test.js).
 */
export function priorUploads(items) {
  const latest = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    if (!item || item.kind !== "question") continue;
    const template = priorTemplateOf(item.questionId);
    if (template) latest.set(template, item);
  }
  const out = {};
  for (const [template, q] of latest) {
    const a = q.answer;
    const v = a && !a.skipped && a.value && typeof a.value === "object" ? a.value : null;
    if (v && typeof v.documentId === "string" && v.documentId) out[template] = { documentId: v.documentId, name: typeof v.name === "string" ? v.name.trim() : "" };
  }
  return out;
}

/**
 * The format-matched copy a delivered workbook has, or null: `{ name, href }`, where
 * `href` is the app's download of the result as it now stands — the engine fills the
 * person's own file with this month's figures there (GET /workpapers/{id}.xlsx) — and
 * `name` is their file, moved on a month. Offered BESIDE Vert's layout, never instead
 * of it: their file is what they asked for, and Vert's is the one the pane opens.
 */
export function ownFormatCopy(artifactId, uploads, period, hrefOf) {
  if (typeof artifactId !== "string" || !uploads || typeof hrefOf !== "function") return null;
  const cardKey = artifactId.slice(artifactId.lastIndexOf(":") + 1);
  for (const [template, doc] of Object.entries(uploads)) {
    if (PRIOR_CARDS[template] !== cardKey || artifactId.lastIndexOf(":") < 0) continue;
    const base = monthNamed(doc.name, period) || "Your format.xlsx";
    const name = /\.xlsx$/i.test(base) ? base : `${base.replace(/\.[a-z0-9]+$/i, "")}.xlsx`;
    return { name, href: hrefOf(artifactId) };
  }
  return null;
}
