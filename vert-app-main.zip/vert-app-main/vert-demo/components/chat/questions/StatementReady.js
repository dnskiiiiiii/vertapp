"use client";

// components/chat/questions/StatementReady.js — "READ AS: DATE · DESCRIPTION · AMOUNT
// (CHARGES POSITIVE), AUD", AND ONE PRESS TO IMPORT IT
// ==============================================================================
// Eval iter2 r1, flow 4. The task's question knew the account, its currency and the
// sign convention; the file proposed its columns and date format; the service
// previewed that reading and handed back its echo and token. All seven answers are
// therefore on the table at once, so they are drawn as ONE line a person reads
// against their statement, with Edit beside it for the person who disagrees — not as
// seven fields each labelled "Proposed by the service".
//
// THE GATE HOLDS. The one press sends the token the service issued for exactly this
// reading (`previewFormData`), through the same `confirmStatementAction` Connections
// uses. The counts under the reading — "9 charges, 1 payment" — are the check the
// echo exists for: an inverted sign shows here as 1 charge and 9 payments, before
// anything is written. A refusal of the token falls back to the full form (`onEdit`).

import { useState } from "react";
import { Button, Figure } from "@/components/ui";
import { confirmStatementAction } from "@/components/settings/actions";
import { ImportRefusal, ImportUnconfirmed } from "@/components/settings/BankImportOutcome";
import { previewCountsLine, previewFormData, previewTotals, readingLine } from "./model";

import { IconCaretRight } from "@/components/ui/icons";
export default function StatementReady({ inspection, fileName, preview, card = false, accountName = null, onImported, onEdit, commit = confirmStatementAction }) {
  const [phase, setPhase] = useState({ busy: false, refused: null });

  async function importIt() {
    if (phase.busy) return;
    setPhase({ busy: true, refused: null });
    let outcome = null;
    try {
      outcome = await commit(null, previewFormData(inspection.inspectionId, preview));
    } catch {
      // The action threw before it could read anything back: unknown, never "nothing".
      outcome = { ok: false, stage: "unconfirmed", inspectionId: inspection && inspection.inspectionId, read: null };
    }
    if (outcome && outcome.ok && outcome.importId) {
      setPhase({ busy: false, refused: null });
      if (typeof onImported === "function") onImported(outcome);
      return;
    }
    // Asked to review again (the token no longer matches) or refused: say so, and
    // leave Edit as the way on. Nothing was written.
    setPhase({ busy: false, refused: outcome && outcome.stage === "review" ? { ok: false, remedy: "The file changed since it was read. Check the reading and import again.", reason: null } : outcome });
  }

  const lines = preview.lines;
  const totals = previewTotals(preview, { card });
  return (
    <div className="chat-q-reading" data-reading="ready">
      <p className="chat-q-reading-line">
        <span className="chat-q-reading-label">Read as</span>{" "}
        <span className="chat-q-reading-value">{readingLine(preview, { card })}</span>{" "}
        <button type="button" className="link chat-q-reading-edit" onClick={onEdit}>
          Edit<IconCaretRight className="caret-trailing" />
        </button>
      </p>
      <p className="chat-q-reading-counts">
        {fileName ? <span className="chat-q-reading-file">{fileName}</span> : null}
        {fileName ? " · " : null}
        {previewCountsLine(preview, { card })}
        {accountName ? ` · into ${accountName}` : null}
      </p>
      {/* The totals, when the engine sent them: what a person ticks off against the
          statement in front of them (bug bash 10 Oct 2026). Each amount is a bound
          Figure, like every other amount on screen. */}
      {totals.length ? (
        <p className="chat-q-reading-counts" data-reading-totals="">
          {totals.map((t, i) => (
            <span key={t.key}>
              {i ? " · " : null}
              {t.label} <Figure cents={t.cents} figure={`statement/${inspection && inspection.inspectionId ? inspection.inspectionId : "preview"}/${t.key}`} />
            </span>
          ))}
        </p>
      ) : null}
      {/* A confirm whose answer was lost (CC2-1) is not a refusal: it says what the
          read-back found, and a re-read that finds the import answers the question. */}
      {phase.refused && phase.refused.stage === "unconfirmed" ? (
        <ImportUnconfirmed
          key={phase.refused.inspectionId}
          outcome={phase.refused}
          onSettled={(found) => {
            setPhase({ busy: false, refused: null });
            if (typeof onImported === "function") onImported(found);
          }}
        />
      ) : phase.refused ? (
        <ImportRefusal outcome={phase.refused} title="Nothing was imported" />
      ) : null}
      <div className="chat-q-reading-actions">
        <Button variant="commit" busy={phase.busy} busyLabel="Importing…" onClick={importIt}>
          {`Import ${lines} ${lines === 1 ? "line" : "lines"}`}
        </Button>
      </div>
    </div>
  );
}
