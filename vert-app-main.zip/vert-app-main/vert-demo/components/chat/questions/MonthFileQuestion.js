"use client";

// components/chat/questions/MonthFileQuestion.js — THE STATEMENT, DROPPED ON MONTH-END
// ==============================================================================
// Eval iter2 r1, flow 4: the Month-end card for "Upload the Business Visa statement"
// could not take the file. It said "Answer in the conversation ›", which cost a
// navigation and a press before the file could even be chosen. The card now takes the
// drop itself — the same FileQuestion the conversation uses, so the same one-line
// reading and the same gated import — and, once the import is committed, answers the
// task's question with its id and opens the conversation, where the task has resumed
// and asks its next question (the statement's closing balance).
//
// The answer is the import id and nothing else, exactly as in the conversation; the
// service resumes the task on it (`scope.statement_id`). Nothing posts from here.

import { useState } from "react";
import { useRouter } from "next/navigation";
import { answerQuestion } from "@/lib/agent/actions";
import { callSafely } from "@/lib/decisions";
import FileQuestion from "./FileQuestion";
import { asksForDocument } from "./model";

import { IconCaretRight } from "@/components/ui/icons";
export function conversationHref(sessionId) {
  return `/chat/${encodeURIComponent(sessionId)}`;
}

export default function MonthFileQuestion({ question, sessionId, answer = answerQuestion }) {
  const router = useRouter();
  const [failure, setFailure] = useState(null);
  const [sent, setSent] = useState(false);
  // A document question (last month's schedule, a payroll report) is uploaded, not
  // imported: the words say which happened (build plan §19.8 F-FILES).
  const isDocument = asksForDocument(question.form);

  async function onAnswer(value) {
    setFailure(null);
    const result = await callSafely(answer, sessionId, value);
    if (!result || !result.ok) {
      setFailure((result && (result.message || result.remedy)) || (isDocument ? "The file was uploaded, but the task didn't hear about it. Open the conversation to carry on." : "The statement was imported, but the task didn't hear about it. Open the conversation to carry on."));
      return;
    }
    setSent(true);
    router.push(conversationHref(sessionId));
  }

  return (
    <div className="month-file-question" data-question={question.questionId}>
      <p className="t-body">{question.title || (isDocument ? "Upload the file" : "Upload the statement")}</p>
      <FileQuestion item={question} blocked={sent} onAnswer={onAnswer} />
      {sent ? <p className="t-footnote">{isDocument ? "Uploaded" : "Imported"}. Opening the conversation…</p> : null}
      {failure ? (
        <p className="t-footnote" role="alert">
          {failure}{" "}
          <a className="link" href={conversationHref(sessionId)}>Open the conversation<IconCaretRight className="caret-trailing" /></a>
        </p>
      ) : null}
    </div>
  );
}
