"use client";

// components/chat/questions/FileQuestion.js — "UPLOAD THE JULY STATEMENT", ANSWERED HERE
// ==============================================================================
// Build plan §4.2 (`form.kind: file`, `accept: ".csv"`) and §4.11a #2. A bank or card
// reconciliation that has no statement asks for one, and the person drops the CSV
// straight into the question instead of leaving for Connections and coming back (the
// task-flow count in iter2/visual-spec.md: about 8 presses and 3 screens down to 4 and 2).
//
// THE ONLY FILE CONTROL IN THE CONVERSATION, AND IT GOES SOMEWHERE. The rail card that
// took a file and sent nothing (tests/no-false-affordance.test.js, 20 Aug) is why this
// exists only inside a question that asked for a file, and why every path out of it
// is a request: choosing or dropping the file sends it at once to the existing
// statement import (`POST /bank-statements`, the server action Connections uses),
// which reads it and WRITES NOTHING. The import's own mapping form follows, with its
// two-press gate unchanged (components/settings/BankStatementMapping.js): the columns
// and the sign convention are a person's to state, here as there. Only once the
// service has committed the import does its id go back as the question's answer, and
// the task resumes on that statement (`scope.statement_id`).
//
// Nothing here posts, reconciles or marks anything: an import is bank lines with their
// file and row number, and the reconciliation reads them.
//
// WHEN THE QUESTION ALREADY KNOWS HOW TO READ THE FILE (eval iter2 r1, flow 4). A card
// rec's question carries the account, its currency and the card convention
// (`form.statement`); sent with the file, they come back as the service's preview of
// that whole reading, echo and token included. Then the mapping is ONE line —
// "Read as: Date · Description · Amount (charges positive), AUD · Edit ›" — and one
// press imports it (StatementReady.js): drop → Import → the task resumes. Edit, or
// any reading the service would not preview, is the full form above, unchanged.
//
// A QUESTION THAT ASKS FOR A DOCUMENT (build plan §19.2, §19.8 F-FILES). "Do you have
// last month's schedule? Upload it and I'll match its format" takes a workbook, a PDF
// or a photo (`form.accept` widened past ".csv"). That file is not a bank statement, so
// it goes to the documents store (POST /api/documents), and the question is answered
// with the stored document's id ONLY after the store says it holds it: it uploads, then
// answers. The resume reads it as `scope.document_id`. The chip it leaves opens the file
// in the pane, growing from the chip that was pressed (anchored to its trigger). Nothing
// is posted from a file; a refused upload says so and answers nothing.

import { useEffect, useId, useRef, useState } from "react";
import { inspectStatementAction } from "@/components/settings/actions";
import { ImportRefusal } from "@/components/settings/BankImportOutcome";
import BankStatementMapping from "@/components/settings/BankStatementMapping";
import { inspectQuestionStatementAction } from "./actions";
// An attached statement is read with a GET (./statement-read.js): arriving at a question
// with one attached sends no Server Action. A dropped file stays the action, from its press.
import { inspectAttachedByGet } from "./statement-read";
import StatementReady from "./StatementReady";
import { asksForDocument, attachedStatements, attachedToReadNow, documentHelp, importAnswer, readAttachedStatement, readStatement, statedFromHints, statementAccept, statementHelp, statementHints, uploadThenAnswer } from "./model";
import DocumentView, { FileChip, sessionFromPath, uploadFile } from "../results/DocumentView";
import { usePathname } from "next/navigation";

export default function FileQuestion(props) {
  return asksForDocument(props.item && props.item.form) ? <DocumentQuestion {...props} /> : <StatementQuestion {...props} />;
}

/** The document question: upload to the store, then answer with the document's id. */
//
// `inConversation` (W0c CO-21): the conversation's question (Clarification) passes it and
// gets the whole help line; Month-end's (MonthFileQuestion) does not, and gets the brief
// one, so the drop zone does not bring approval and posting onto a page already at five
// ideas (9.1 S4).
function DocumentQuestion({ item, blocked = false, onAnswer, uploadDocument = uploadFile, sessionId = null, initial = null, inConversation = false }) {
  const [reading, setReading] = useState(false);
  const [refusal, setRefusal] = useState(null);
  // `initial.chip` seeds the uploaded state for a render test; nothing in the app passes it.
  const [chip, setChip] = useState(initial && initial.chip ? initial.chip : null);
  const [over, setOver] = useState(false);
  const [viewing, setViewing] = useState(null);
  const inputId = useId();
  const helpId = useId();
  const pathname = usePathname();
  const session = sessionId || sessionFromPath(pathname);
  const form = item.form;

  const take = async (file) => {
    if (blocked || reading || chip) return;
    setRefusal(null);
    setReading(true);
    const outcome = await uploadThenAnswer(file, { questionId: item.questionId, accept: form.accept, upload: uploadDocument, session });
    setReading(false);
    if (!outcome.ok) {
      setRefusal(outcome.refusal);
      return;
    }
    setChip(outcome.chip);
    if (typeof onAnswer === "function") onAnswer(outcome.answer);
  };

  return (
    <div className="chat-q-file" data-form="file" data-file="document">
      {chip ? null : (
        <label
          htmlFor={inputId}
          className={["chat-q-drop", over ? "chat-q-drop-over" : null, blocked ? "chat-q-drop-off" : null].filter(Boolean).join(" ")}
          onDragOver={(event) => {
            if (blocked) return;
            event.preventDefault();
            setOver(true);
          }}
          onDragLeave={() => setOver(false)}
          onDrop={(event) => {
            event.preventDefault();
            setOver(false);
            const files = event.dataTransfer && event.dataTransfer.files;
            if (files && files.length) take(files[0]);
          }}
        >
          <span className="chat-q-drop-title">{reading ? "Reading the file…" : "Drop the file here, or choose one"}</span>
          <span className="chat-q-drop-help" id={helpId}>
            {documentHelp(form, { brief: !inConversation })}
          </span>
          <input
            id={inputId}
            className="chat-q-file-input"
            name="file"
            type="file"
            accept={form.accept}
            disabled={blocked || reading}
            aria-describedby={helpId}
            onChange={(event) => {
              const files = event.target.files;
              if (files && files.length) take(files[0]);
            }}
          />
        </label>
      )}
      {refusal ? (
        <p className="chat-inline-error" role="alert">
          {refusal}
        </p>
      ) : null}
      {chip ? (
        <p className="chat-q-file-done">
          <FileChip chip={chip} onOpen={(c, origin) => setViewing({ chip: c, origin })} />
        </p>
      ) : null}
      <DocumentView chip={viewing && viewing.chip} origin={viewing && viewing.origin} open={Boolean(viewing)} onClose={() => setViewing(null)} />
    </div>
  );
}

/** The statement question: the bank import, as iteration 2 built it. */
function StatementQuestion({ item, blocked = false, onAnswer, upload = null }) {
  const [reading, setReading] = useState(false);
  const [read, setRead] = useState(null);
  const [over, setOver] = useState(false);
  const [editing, setEditing] = useState(false);
  const inputId = useId();
  const helpId = useId();
  const hints = statementHints(item && item.form);
  // The question that knows its reading asks for the preview; any other uses
  // Connections' own inspection, as it always has.
  const send = upload || (hints ? inspectQuestionStatementAction : inspectStatementAction);
  // What the statement may be (D04): the engine's `accept` (".csv,.pdf" since it reads
  // PDFs), and the statements already attached here, each one press from its reading.
  const accept = statementAccept(item && item.form);
  const attached = attachedStatements(item && item.form);

  const take = async (file) => {
    if (blocked || reading) return null;
    setReading(true);
    setEditing(false);
    const outcome = await readStatement(file, send, hints, accept);
    setReading(false);
    setRead(outcome);
    return outcome;
  };
  const useAttached = async (doc) => {
    if (blocked || reading) return null;
    setReading(true);
    setEditing(false);
    // The question's own action reads `document_id`; Connections' takes files only.
    const outcome = await readAttachedStatement(doc, upload || inspectAttachedByGet, hints);
    setReading(false);
    setRead(outcome);
    return outcome;
  };
  // One statement attached: read it now, once, as a dropped file is (U24; model.js
  // `attachedToReadNow`). A failed read shows its refusal and the "Use" press again.
  const autoRead = useRef(false);
  useEffect(() => {
    if (autoRead.current) return;
    const doc = attachedToReadNow(item && item.form, { blocked, read, reading });
    if (!doc) return;
    autoRead.current = true;
    useAttached(doc);
    // Once per card: later renders (a refusal, Edit) are the person's to drive.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [blocked]);
  const ready = read && read.ok && read.inspection && read.preview && !editing;

  const imported = (outcome) => {
    const answer = importAnswer(item.questionId, outcome, read && read.fileName);
    if (answer && typeof onAnswer === "function") onAnswer(answer);
  };

  return (
    <div className="chat-q-file" data-form="file">
      <label
        htmlFor={inputId}
        className={["chat-q-drop", over ? "chat-q-drop-over" : null, blocked ? "chat-q-drop-off" : null].filter(Boolean).join(" ")}
        onDragOver={(event) => {
          if (blocked) return;
          event.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(event) => {
          event.preventDefault();
          setOver(false);
          const files = event.dataTransfer && event.dataTransfer.files;
          if (files && files.length) take(files[0]);
        }}
      >
        <span className="chat-q-drop-title">{reading ? "Reading the file…" : "Drop the statement here, or choose a file"}</span>
        <span className="chat-q-drop-help" id={helpId}>
          {statementHelp(item && item.form)}
        </span>
        <input
          id={inputId}
          className="chat-q-file-input"
          name="file"
          type="file"
          accept={accept}
          disabled={blocked || reading}
          aria-describedby={helpId}
          onChange={(event) => {
            const files = event.target.files;
            if (files && files.length) take(files[0]);
          }}
        />
      </label>

      {attached.length && !(read && read.ok) ? (
        <ul className="chat-q-attached" aria-label="Statements attached in this conversation">
          {attached.map((doc) => (
            <li key={doc.documentId}>
              <button type="button" className="btn btn-secondary btn-sm" disabled={blocked || reading} onClick={() => useAttached(doc)} data-use-attached={doc.documentId}>
                Use {doc.name}
              </button>
            </li>
          ))}
        </ul>
      ) : null}

      {read && !read.ok ? <ImportRefusal outcome={read} title="The file wasn't read" /> : null}

      {ready ? (
        <StatementReady
          key={read.inspection.inspectionId}
          inspection={read.inspection}
          fileName={read.fileName}
          preview={read.preview}
          card={hints ? !hints.deposits_are_positive : false}
          accountName={hints ? hints.account_name : null}
          onImported={imported}
          onEdit={() => setEditing(true)}
        />
      ) : null}

      {read && read.ok && read.inspection && !ready ? (
        <div className="chat-q-mapping">
          {/* A new file is a new import, so it gets a new form (BankStatementImport.js
              says why the key matters: a reused form kept the first file's answers). */}
          <BankStatementMapping key={read.inspection.inspectionId} inspection={read.inspection} fileName={read.fileName} onImported={imported} stated={statedFromHints(hints)} />
        </div>
      ) : null}
    </div>
  );
}
