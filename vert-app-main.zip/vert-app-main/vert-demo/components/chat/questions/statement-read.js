// components/chat/questions/statement-read.js — AN ATTACHED STATEMENT, READ WITH A GET
// ==============================================================================
// A statement question with exactly one statement already attached reads it at once,
// as a dropped file is (model.js `attachedToReadNow`). That read was the
// `inspectQuestionStatementAction` Server Action: a POST on arriving at the
// conversation, before anyone pressed anything (found by tests/p0-quiet-page-load.test.js,
// 28 Oct 2026). It is now a GET to app/api/statements, which calls the same inspection
// on the server, so the key stays there. The inspection writes nothing
// (vert_api/routers/bank_statements.py); the commit is still `confirmStatementAction`,
// from its own press.
//
// Same shape as the action, `(previous, formData) → outcome`, so model.js
// `readAttachedStatement` takes either. A dropped file is not read here: a file cannot
// ride a GET, and dropping one is a press, so it stays the action.

const DOCUMENT_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const FIELDS = ["file_name", "account_id", "currency", "deposits_are_positive"];

const refused = (remedy) => ({ ok: false, kind: "refused", status: 0, remedy, reason: null, rowNumber: null, inspection: null });

/** The question's inspection of an attached statement, by GET. Never throws. */
export async function inspectAttachedByGet(_previous, formData, fetchImpl = null) {
  const documentId = formData && typeof formData.get === "function" ? formData.get("document_id") : null;
  if (typeof documentId !== "string" || !DOCUMENT_ID.test(documentId.trim())) return refused("That statement isn't one Vert holds. Nothing was imported.");
  const doFetch = fetchImpl || (typeof window !== "undefined" && typeof window.fetch === "function" ? window.fetch.bind(window) : null);
  if (!doFetch) return refused("This build can't read files, so nothing was sent.");
  const query = new URLSearchParams({ document: documentId.trim() });
  for (const key of FIELDS) {
    const value = formData.get(key);
    if (typeof value === "string" && value.trim()) query.append(key, value.trim());
  }
  try {
    const response = await doFetch(`/api/statements?${query.toString()}`, {
      method: "GET",
      headers: { accept: "application/json" },
      cache: "no-store",
      credentials: "same-origin",
    });
    const body = response && typeof response.json === "function" ? await response.json().catch(() => null) : null;
    return body && typeof body === "object" && typeof body.ok === "boolean" ? body : refused("The request didn't reach Vert. Nothing was imported.");
  } catch {
    return refused("The request didn't reach Vert. Nothing was imported.");
  }
}
