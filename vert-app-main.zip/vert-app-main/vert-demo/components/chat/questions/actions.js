"use server";

// components/chat/questions/actions.js — A STATEMENT ASKED FOR BY A TASK, READ WITH WHAT
// THE TASK ALREADY KNOWS
// ==============================================================================
// Eval iter2 r1, flow 4: uploading the card statement took eight presses, seven of
// them re-stating things the card rec already knew (the account, its currency, that a
// card's statement prints charges positive) and then pressing twice to see and agree
// to the echo. The engine's file question now carries those three as a proposal
// (`form.statement`), and the inspection, given them, answers with `preview`: the
// echo and the token for exactly that reading (vert_api/routers/bank_statements.py
// `_question_preview`). Nothing is written by this call.
//
// This is Connections' `inspectStatementAction` plus those three fields and the
// preview it hands back. The commit is still `confirmStatementAction`, and it still
// sends only a token the service issued for the reading on screen: this file never
// mints one and never calls the service twice to obtain one.

import { importRefusal, inspectionSummary } from "@/lib/bank-import";
import { inspectBankStatement } from "@/lib/connections";
import { previewOf } from "./model";

const HINTS = ["account_id", "currency", "deposits_are_positive"];

const DOCUMENT_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function inspectQuestionStatementAction(_previous, formData) {
  const file = formData.get("file");
  // A statement already attached in the conversation (D04, ENG-RECS-e1): the route
  // takes `document_id` in place of `file`, and reads it the same way.
  const documentId = formData.get("document_id");
  const attached = typeof documentId === "string" && DOCUMENT_ID.test(documentId.trim()) ? documentId.trim() : null;
  if (!attached && (!file || typeof file === "string" || !file.name)) {
    return { ok: false, kind: "refused", status: 0, remedy: "Choose the statement your bank gave you, as a CSV or PDF.", reason: null, rowNumber: null, inspection: null };
  }
  const forward = new FormData();
  if (attached) forward.append("document_id", attached);
  else forward.append("file", file, file.name);
  const named = formData.get("file_name");
  const fileName = attached ? (typeof named === "string" && named.trim() ? named.trim() : "the attached statement") : file.name;
  for (const key of HINTS) {
    const value = formData.get(key);
    if (typeof value === "string" && value.trim()) forward.append(key, value.trim());
  }

  const result = await inspectBankStatement(forward);
  if (!result.ok) {
    const refusal = importRefusal(result.body);
    return { ok: false, kind: result.kind, status: result.status, reason: refusal.reason, remedy: refusal.remedy || result.message || null, rowNumber: refusal.rowNumber, inspection: null };
  }
  const inspection = inspectionSummary(result.body);
  if (!inspection.inspectionId) {
    return {
      ok: false, kind: "refused", status: result.status, reason: null, rowNumber: null, inspection: null,
      remedy: "The service read the file but did not return an inspection id, so there is nothing to confirm against. Nothing was imported.",
    };
  }
  return { ok: true, fileName, inspection, preview: previewOf(result.body && result.body.preview) };
}
