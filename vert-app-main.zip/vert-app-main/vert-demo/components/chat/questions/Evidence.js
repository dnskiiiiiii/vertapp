// components/chat/questions/Evidence.js — WHAT THE QUESTION IS ABOUT, SHOWN FIRST
// ==============================================================================
// Build plan §4.0.10. A person answers a question about lines they can see far better
// than one about lines they have to go and find: so before the question, the few rows
// it is about (at most five), or the one source line it quotes, as the record wrote it.
//
// Cells are written by the one cell formatter the result pane and the workbook share
// (components/chat/results/TableView.js `cellText` → lib/format.js `formatAccounting`),
// so a deposit reads the same here as it does in the pane beside it, except for a
// negative amount: a card writes it with the minus sign, as the question above it does
// (`screenCellText`, verify pass 2 S-UI-11). The values are the engine's: integer
// cents, a count, a date, words. Nothing here adds or rounds.
//
// THE QUOTED LINE IS A PROVENANCE LINE (design pass, spec §6.12; audit §4 P0). It was a
// monospace blockquote behind a 2 px side stripe, the build's worst anti-reference. It is
// now body type: a 14 px source glyph (the ledger's book, or a document), the line Vert
// read, and where it read it in footnote ink. No border, no mono.
//
// Server-safe: no hooks, no handlers.

import { screenCellText } from "../results/TableView";
import { evidenceOf } from "./model";
import { withLedger } from "@/lib/agent/events";
import { SourceLogo } from "@/components/ui";

/** Whether a quoted source is the ledger (a book glyph) rather than a document. Pure. */
export function fromLedger(source) {
  return typeof source !== "string" || !source.trim() || /ledger|journal|chart of accounts|books/i.test(source);
}

const NUMERIC = new Set(["money", "percent", "count"]);

/**
 * Each column's class (Q13/U05, W11). Every text column after the first used to take
 * `width: 100%`, so with two of them ("Date booked" and "Memo") the first took the
 * table and the memo fell to one word per line. Now: figures right-aligned and whole, a
 * date or a short first column whole, and ONE column — the last of the prose — takes
 * what is left, with a floor so it never collapses to a word. Pure.
 */
export function evidenceColumnClasses(columns) {
  const list = Array.isArray(columns) ? columns : [];
  let stretch = -1;
  list.forEach((c, i) => {
    if (c && !NUMERIC.has(c.kind) && c.kind !== "date" && i > 0) stretch = i;
  });
  if (stretch < 0) list.forEach((c, i) => {
    if (c && !NUMERIC.has(c.kind) && c.kind !== "date") stretch = i;
  });
  return list.map((c, i) => {
    if (c && NUMERIC.has(c.kind)) return "num";
    if (i === stretch) return "chat-q-prose";
    return c && c.kind === "date" ? "chat-q-whole chat-q-date" : "chat-q-whole";
  });
}

export default function Evidence({ item, id, ledgerName = null, hideQuote = false }) {
  const evidence = evidenceOf(item);
  if (!evidence) return null;
  // The quoted line is not drawn while the open "How Vert did this" trail above already
  // shows the same step (critic r1 F7); the table, when there is one, stays.
  if (hideQuote && !evidence.table) return null;
  const classes = evidence.table ? evidenceColumnClasses(evidence.table.columns) : [];
  return (
    <div className="chat-q-evidence" data-evidence="" id={id}>
      {evidence.table ? (
        <table className="chat-q-table">
          <thead>
            <tr>
              {evidence.table.columns.map((c, i) => (
                <th key={c.key} scope="col" className={classes[i]}>
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {evidence.table.rows.map((row, r) => (
              <tr key={r}>
                {evidence.table.columns.map((c, i) => {
                  // Template text names the ledger only as `{{ledger}}`; a cell is template
                  // text like the title and options above it, so it gets the same name.
                  const raw = screenCellText(row ? row[c.key] : null, c.kind);
                  const text = typeof raw === "string" ? withLedger(raw, ledgerName) : raw;
                  return (
                    <td key={c.key} className={classes[i]}>
                      {text === null ? "" : text}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      ) : null}
      {evidence.quote && !hideQuote ? (
        <figure className="chat-provenance" data-provenance="">
          {/* The source's own mark, monochrome, 16 px (design-fix-2 DA2-008, DA2-027): the
              ledger Vert read is the connected ledger, so it wears that ledger's mark. */}
          <SourceLogo source={fromLedger(evidence.quote.source) ? ledgerName || "ledger" : evidence.quote.source} size={16} className="chat-provenance-glyph" />
          <blockquote>{evidence.quote.text}</blockquote>
          {evidence.quote.source ? <figcaption className="chat-provenance-source">{evidence.quote.source}</figcaption> : null}
        </figure>
      ) : null}
    </div>
  );
}
