"use client";

// components/chat/ConversationView.js — ONE CONVERSATION, START TO FINISH
// ==============================================================================
// Spec §3.3. Holds the event list, follows the live stream (lib/agent/stream.js) and
// hands the thread model (lib/agent/events.js) to the pieces that draw it: the header,
// the thread, the composer, the result pane and the context sheet.
//
// WHAT IT DECIDES, AND WHAT IT DOES NOT. It decides nothing about the books. A message,
// an answer and a Stop are sent through server actions (lib/agent/actions.js) and come
// back as events on the stream; nothing is drawn as sent until the service says it was
// stored. Decisions that write go through F3's cards and lib/actions.js.
//
// A REPLAY never streams, never sends and never pretends to: the band says what it is,
// the composer says why it is off, and every control that would start work is
// disabled with that reason.
//
// ONE COLUMN, AND A PANEL FOR THE DATA (p1 chat, founders' review 23 Oct 2026). The
// conversation is one readable column: every turn is your message, the data Vert read
// ("Data fetched"), its reasoning (closed) and its answer, and every turn stays on screen
// (no "Earlier" fold). The side of the screen holds one thing only: the data and sources
// panel (SourcesPanel.js), opened by a turn's Open (that turn's data) or the head's
// Sources (the whole conversation's), closed by Esc or its Close. There is no result
// pane beside the chat any more: a workbook opens INLINE under the turn whose control
// was pressed, and the plan, the journal editor and the bridge and commentary views open
// in a modal over the conversation (ResultPane.js `paneMode`). The skill and Budgets
// sheets open on demand as the kit's sheets (results/DeskPane.js falls back to them).
//
// ONE RESULT STATE: which result is open, at which sheet, which row a figure pointed
// at, the entry or plan being edited, a `view` ("bridge", "commentary") opened from a
// workbook card, and the turn (`data-turn`) whose control opened it, where an inline
// result is drawn. A figure in the chat whose row a workbook holds opens that row
// (PaneContext); a bar or a figure in a view opens its row in that workbook. The budget
// sheet opens over the conversation from "Choose a budget" (BudgetSheetContext) or on
// arrival at `?sheet=budgets`.

import { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useEngine } from "@/lib/engine-context";
import { composerState, lastSeqOf, mergeEvents, sessionAfterRuns, threadModel } from "@/lib/agent/events";
import { addOutgoing, dropOutgoing, stillOutgoing } from "@/lib/agent/outgoing";
import SendingNow from "./SendingNow";
import { paneEntriesFor } from "./answer/shape";
import { answerRoute, linkReadTries, linkedTaskFor, linkedTasks, readLinkedTask, withLinkedResults } from "@/lib/agent/linked";
import { stepHeld } from "@/lib/agent/stream-state";
import { useAssistantDown } from "@/lib/agent/assistant-status";
import { followConversation } from "@/lib/agent/stream";
import { againIfRaceLost, answerQuestion, sendMessage, startConversation, stopTurn } from "@/lib/agent/actions";
import { composerAnswers } from "./questions/model";
import { wasJustStarted } from "@/lib/agent/opening";
import { safeRefresh } from "@/components/shared/safeRefresh";
import { accountName } from "@/lib/format";
import { accountNameIn, anchorOrigin, entryArtifact, locateFigure, paneArtifacts, recordNameIn } from "@/lib/agent/pane";
import { PaneContext } from "./results/paneContext";
import ConversationHeader from "./ConversationHeader";
import { useSignedInActor } from "@/lib/store";
import { startHeldTask } from "@/lib/tasks";
import { callSafely } from "@/lib/decisions";
import Thread from "./Thread";
import Composer, { MESSAGE_NOT_SENT, MESSAGE_NOT_SENT_AGAIN, sendFailureWords } from "./Composer";
import ResultPane, { bodyFor, paneMode } from "./ResultPane";
import SourcesPanel from "./SourcesPanel";
import FeedsSourcesNote from "./FeedsSourcesNote";
import { SourcesContext } from "./sources-context";
import { Portal } from "@/components/ui/Portal";
import ReplayBand from "./ReplayBand";
import { usePublishThreadWord } from "@/components/shell/thread-word";
import { listedTitle, markShellStale, useShellReading } from "@/components/shell/live-shell";
import BudgetSheet from "@/components/budgets/BudgetSheet";
import { BudgetSheetContext } from "@/components/budgets/sheet-context";
import { BUDGETS_SHEET, VIEW_PARAM, arrivalTarget, attachedDocuments, viewFor, viewLinks, workbookOf } from "./results/analysis-views";

/** A message that did not reach Vert (DA2-074): the cause, and that nothing is lost. */
export const NOT_SENT = MESSAGE_NOT_SENT;

/** Said after the second failure in a row. */
export const NOT_SENT_AGAIN = MESSAGE_NOT_SENT_AGAIN;
/** While Vert can't be reached at all (DA2-031). */
export const OFFLINE = "Can't reach Vert. Your answers aren't being sent yet.";

export default function ConversationView({
  sessionId,
  session = null,
  events: initialEvents = [],
  replay = false,
  ledgerName = null,
  sources = null,
  // Whether the engine reads files (app/chat/[id]/page.js, read on the server), for the
  // composer's attach control. Not told — the loading screen's copy — is off.
  documentsEnabled = false,
  // The loading screen's copy (OpeningView): drawn from the ask box's hand-over, never
  // streaming, replaced by the page's own render in a moment.
  preview = false,
}) {
  const engine = useEngine();
  const router = useRouter();
  const [events, setEvents] = useState(() => mergeEvents([], initialEvents));
  const [held, setHeld] = useState([]);
  // Messages being sent, drawn as yours until the thread holds them (p0, lib/agent/outgoing.js).
  const [outgoing, setOutgoing] = useState([]);
  const outgoingId = useRef(0);
  const [failure, setFailure] = useState(null);
  const [failures, setFailures] = useState(0);
  // VERT CAN'T BE REACHED (DA2-031): the stream fell back, and a direct read of the
  // conversation failed too. Said above the composer, with the presses that would go
  // nowhere held with that reason, until a read gets through again.
  const [offline, setOffline] = useState(false);
  const [retrying, setRetrying] = useState(false);
  const [pane, setPane] = useState(null);
  // The data and sources panel: `{ turn }` for one turn's (its outline), `{ turn: null }`
  // for the whole conversation's, or null when it is closed.
  const [sourcesOpen, setSourcesOpen] = useState(null);
  const [budgets, setBudgets] = useState(null);
  const chipRef = useRef(null);
  const scrollRef = useRef(null);
  const lastPress = useRef(null);
  const paneId = useId();

  // A TASK STARTED FROM HERE SHOWS ITS RESULT HERE (harsh wave 1, W1-46; lib/agent/linked.js):
  // the linked task's conversation is read once per answer that opens it, and its
  // delivered workbooks are drawn under that answer, opening in this pane.
  const [borrowed, setBorrowed] = useState(() => new Map());
  // THE TITLE THE SESSIONS LIST HOLDS NOW (staging browser walk 6, W6-4). The engine
  // renames a rec request after each run; the shell re-reads the list when a run ends
  // (below), and the header takes this conversation's row from that same reading, so
  // the header and the sidebar row say one title without a page load.
  const shellReading = useShellReading();
  const listed = listedTitle(shellReading, sessionId);
  // The page's reading of this conversation (its `stale` included) was taken with the
  // events up to this seq; a run that finished after it brought it up to date (W8-1).
  const readUpTo = useMemo(() => lastSeqOf(initialEvents), [initialEvents]);
  const sessionNow = useMemo(() => {
    const named = listed && session && typeof session === "object" && session.title !== listed ? { ...session, title: listed } : session;
    return sessionAfterRuns(named, events, readUpTo);
  }, [session, listed, events, readUpTo]);
  const ownThread = useMemo(() => threadModel(events, sessionNow), [events, sessionNow]);
  // A signed-in person (only a live service has one) can open and edit the task's skill.
  const viewerSignedIn = Boolean(useSignedInActor());
  // START on a task made with Create (founders, 22 Oct 2026): its first turn runs in the
  // request; the stream then draws it. A refusal is said in the engine's words.
  const [startingHeld, setStartingHeld] = useState(false);
  const [startHeldFailure, setStartHeldFailure] = useState(null);
  const startHeld = useCallback(async () => {
    if (!ownThread.taskId) return;
    setStartingHeld(true);
    setStartHeldFailure(null);
    const result = await callSafely(startHeldTask, ownThread.taskId);
    setStartingHeld(false);
    if (!result || !result.ok) {
      setStartHeldFailure((result && result.message) || "Not started. Nothing was run.");
      return;
    }
    safeRefresh(router);
  }, [ownThread.taskId, router]);
  const tasksLinked = linkedTasks(ownThread.items, sessionId);
  const linkKey = tasksLinked.map((l) => `${l.taskId}@${l.seq}`).join(",");
  // The tasks linked when this view opened, and whether it was working then: those are
  // read once, not waited for (walk 2: ~30 s of re-reads after the page had drawn).
  const openedWith = useRef(null);
  if (openedWith.current === null) openedWith.current = { ids: new Set(tasksLinked.map((l) => l.taskId)), running: Boolean(ownThread.turn && ownThread.turn.running) };
  useEffect(() => {
    if (replay || preview || !linkKey) return undefined;
    let live = true;
    for (const { taskId } of tasksLinked) {
      readLinkedTask(taskId, undefined, { tries: linkReadTries(taskId, openedWith.current.ids, { running: openedWith.current.running }) }).then((lent) => {
        // A workbook to borrow, or questions to ask here (p1: a task that stopped on
        // questions asks them in the chat that started it).
        // Or the stop it ended on, said here with Try again (23 Oct 2026).
        // Or its cards to approve here (8 Nov 2026: a task with only entries to approve
        // was never borrowed, so its entries stayed static cards).
        if (!live || !lent || !(lent.delivered.length || lent.asks.length || lent.problem || (Array.isArray(lent.decisions) && lent.decisions.length))) return;
        setBorrowed((now) => new Map(now).set(taskId, lent));
      });
    }
    return () => {
      live = false;
    };
    // `tasksLinked` is read through its key: a new answer that opens a task reads it again.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [linkKey, replay, preview]);
  const thread = useMemo(() => withLinkedResults(ownThread, borrowed, sessionId), [ownThread, borrowed, sessionId]);
  const composer = composerState(thread, { replay });
  const disabledReason = replay ? composer.reason : null;
  // While Vert can't be reached, every press that sends is held with that reason.
  const heldReason = disabledReason || (offline ? OFFLINE : null);
  // Whose books, by name: the one reader the sidebar and the top bar use (lib/format.js
  // accountName), so the chip never says "northwind" where the sidebar says the name
  // (eval S6 #11).
  const clientName = accountName({ business: engine && engine.business });

  const addEvents = useCallback((incoming) => setEvents((held) => mergeEvents(held, incoming)), []);

  // A RE-RENDER'S EVENTS ARE KEPT. A press refreshes the route, and the server's render
  // brings the conversation as it now stands — the settle and the `run_state` that
  // followed it. The held list was seeded once, so without this merge the header kept
  // its old word until the stream happened to deliver the same rows (eval polish C6:
  // "Needs you" over an entry the API called done). Merged by seq; nothing is lost.
  useEffect(() => {
    addEvents(initialEvents);
  }, [initialEvents, addEvents]);

  // The sidebar's row for this conversation says what this header says
  // (components/shell/thread-word.js). Not in a replay: the sample's word is the
  // sample's, and the sidebar does not list it.
  usePublishThreadWord(replay || preview || !sessionId ? null : `/chat/${encodeURIComponent(sessionId)}`, thread.word);

  // IS VERT THERE? One read of the conversation: through means reachable; a refused or
  // dropped request (or a server error) means not. Never throws.
  const probe = useCallback(async () => {
    if (replay || preview || !sessionId) return true;
    try {
      const response = await fetch(`/api/agent/sessions/${encodeURIComponent(sessionId)}?after=${Number.MAX_SAFE_INTEGER}`, { cache: "no-store" });
      const ok = response.status < 500;
      setOffline(!ok);
      return ok;
    } catch {
      setOffline(true);
      return false;
    }
  }, [replay, preview, sessionId]);
  const retryNow = useCallback(async () => {
    setRetrying(true);
    await probe();
    setRetrying(false);
  }, [probe]);
  // Retrying runs on no clock of its own (tests/chat-truth.test.js): the stream's own
  // reconnects ask again (onPhase below), and so does the browser coming back online.
  useEffect(() => {
    if (!offline) return undefined;
    const onOnline = () => probe();
    window.addEventListener("online", onOnline);
    return () => window.removeEventListener("online", onOnline);
  }, [offline, probe]);
  // The browser saying it lost the network is reason to ask at once (DA2-031): an open
  // stream can sit silent for a long time before it notices.
  useEffect(() => {
    if (replay || preview || !sessionId) return undefined;
    const onOffline = () => probe();
    window.addEventListener("offline", onOffline);
    return () => window.removeEventListener("offline", onOffline);
  }, [replay, preview, sessionId, probe]);

  // FOLLOW THE CONVERSATION. Resumes after the last seq the server render drew. A stream
  // that drops (connecting again, or polling) asks whether Vert is there at all.
  const firstSeq = useRef(lastSeqOf(initialEvents));
  useEffect(() => {
    if (replay || preview || !sessionId) return undefined;
    const onPhase = (phase) => {
      if (phase === "open") setOffline(false);
      else if (phase === "connecting" || phase === "polling") probe();
    };
    const stop = followConversation(sessionId, { lastSeq: firstSeq.current, onEvents: addEvents, onPhase });
    return stop;
  }, [replay, preview, sessionId, addEvents, probe]);

  // A CONVERSATION STARTED FROM THIS TAB was started by a fetch, which brings no page
  // render back (lib/agent/actions.js), so the sidebar has not heard of it yet. One
  // background refresh lists it; it holds nothing on this screen.
  useEffect(() => {
    if (replay || preview || !sessionId) return;
    // safeRefresh: skipped if the person is already leaving (round-3 D6).
    if (wasJustStarted(sessionId)) safeRefresh(router);
  }, [replay, preview, sessionId, router]);

  // NO AUTOMATIC FOLLOW TO A TASK. An answer that points at a task's conversation used
  // to move the view there by itself (eval W8, D9). It fired on follow-ups too, so a
  // message typed in this conversation landed you in another one (bug bash 10 Oct 2026).
  // The view never moves without a press: the answer's "Open …" button is the way there.

  // CATCH UP AT ONCE after something was sent, instead of waiting for the stream's
  // next tick: the service answers the no-assistant fallback synchronously, and the
  // reply should be on screen when the button stops saying "Sending".
  const catchUp = useCallback(async () => {
    if (replay || !sessionId) return;
    try {
      const after = lastSeqOf(events);
      const url = `/api/agent/sessions/${encodeURIComponent(sessionId)}${after === null ? "" : `?after=${after}`}`;
      const response = await fetch(url, { cache: "no-store" });
      if (!response.ok) return;
      const body = await response.json();
      if (body && Array.isArray(body.events)) addEvents(body.events);
    } catch {
      // The stream or its polling fallback will bring it; nothing to say here.
    }
  }, [replay, sessionId, events, addEvents]);

  // EVERY MESSAGE GOES TO THE SERVER AT ONCE (verify pass 1, S-AC-11). While Vert was
  // working, messages were held in this tab's memory and sent one per finished turn: three
  // typed in a row vanished, and a reload dropped the rest. The server queues turns, so
  // each send is POSTed now, in the order typed (one after another, never racing), and
  // nothing unsent lives only here.
  const sendChain = useRef(Promise.resolve());
  const send = useCallback(
    (text) => {
      setFailure(null);
      // ON SCREEN AT ONCE (p0, 23 Oct 2026): Vert answers inside this send's request, so
      // the message is drawn as yours now, with the working line, not after a minute.
      outgoingId.current += 1;
      const mine = `out-${outgoingId.current}`;
      setOutgoing((now) => addOutgoing(now, { id: mine, text, after: lastSeqOf(events) }));
      const run = async () => {
        // Words typed while a words-only question is open ARE its answer (D10), sent as
        // the answer so the task continues from it, not as a second message beside it.
        const asked = composerAnswers(thread.items);
        // A send that only lost the race to be queued (W1-44) recorded nothing, so it
        // goes again before the person is told (lib/agent/actions.js againIfRaceLost).
        const result = await againIfRaceLost(async () => (asked ? await answerQuestion(answerRoute(thread.items, asked, sessionId), { questionId: asked.questionId, text }) : await sendMessage(sessionId, text)));
        if (!result || !result.ok) {
          // The composer puts the words back, with the failure line and Try again.
          setOutgoing((now) => dropOutgoing(now, mine));
          setFailures((n) => n + 1);
          setFailure(sendFailureWords(result));
          probe();
          return { ok: false };
        }
        setFailures(0);
        await catchUp();
        // After the thread has read its own record of it, so nothing blinks out between.
        setOutgoing((now) => dropOutgoing(now, mine));
        return { ok: true };
      };
      const next = sendChain.current.then(run, run);
      sendChain.current = next.catch(() => undefined);
      return next;
    },
    [sessionId, catchUp, thread.items, probe, events]
  );

  // IS ANYONE THERE TO ANSWER? (verify pass 1, S-CF-5; lib/agent/assistant-status.js)
  const assistantDown = useAssistantDown({ active: !replay && !preview && Boolean(sessionId), running: thread.turn.running, lastSeq: lastSeqOf(events) });

  // RELEASE A HELD MESSAGE WHEN THE MODEL'S TURN ENDS, one per turn (stream-state.js).
  const wasRunning = useRef(thread.turn.running);
  useEffect(() => {
    const ended = wasRunning.current && !thread.turn.running;
    wasRunning.current = thread.turn.running;
    if (!ended || replay) return;
    // The run may have renamed the conversation (W6-4) and moved the month's counts:
    // the sidebar reads the sessions list again, and the header follows its reading.
    markShellStale();
    const { held: next, release } = stepHeld(held, { type: "turn_ended" });
    if (!release.length) return;
    setHeld(next);
    for (const message of release) {
      sendMessage(sessionId, message.text).then((result) => {
        setHeld((queue) => stepHeld(queue, { type: "sent", id: message.id }).held);
        if (!result || !result.ok) setFailure(NOT_SENT);
        else catchUp();
      });
    }
  }, [thread.turn.running, held, replay, sessionId, catchUp]);

  const answer = useCallback(
    async (a) => {
      // A linked task's question is answered in the task's own conversation, through the
      // same road its own page uses; the task runs on in that request (the engine resumes
      // a rules task there), so one read brings what it did next into this chat.
      const route = answerRoute(thread.items, a, sessionId);
      const result = await answerQuestion(route, a);
      if (!result || !result.ok) return result;
      if (route !== sessionId) {
        const lent = await readLinkedTask(route, undefined, { tries: 1 });
        if (lent) setBorrowed((now) => new Map(now).set(route, lent));
        return result;
      }
      // A choice that NAMES a task (the engine puts the template on the option) starts
      // that task and moves to its conversation, the same call Month-end's Start makes,
      // without waiting on a model turn to say so (eval D9): the choice is the press. Any
      // other answer comes back on the stream; a task Vert starts because of it is linked
      // from the answer's "Open …" button, never followed by itself (bug bash 10 Oct 2026).
      const template = optionTemplate(thread.items, a);
      if (template) {
        const started = await startConversation({ period: thread.period, template });
        if (started && started.ok && started.sessionId && started.sessionId !== sessionId) {
          router.push(`/chat/${encodeURIComponent(started.sessionId)}`);
          return result;
        }
      }
      await catchUp();
      return result;
    },
    [sessionId, catchUp, thread.items, thread.period, router]
  );

  const stop = useCallback(async () => {
    const result = await stopTurn(sessionId);
    if (!result || !result.ok) setFailure("Couldn't stop it. Nothing else was changed.");
    else await catchUp();
  }, [sessionId, catchUp]);

  // A start that was for a view ("Open bridge", NextAction viewToOpen) carries it: the
  // conversation it lands in opens that view on arrival (`arrival` below), so the person
  // does not press "Open bridge" a second time there (G4 eval r1, §17.3: 4 presses → 3).
  const arrival = useRef(null);
  const startTask = useCallback(
    async (template, _period = null, opts = null) => {
      setFailure(null);
      const view = opts && typeof opts.view === "string" ? opts.view : null;
      // Run again / Try again name THIS conversation, and Run again says "again": a
      // template start alone only opens a task that already ran (D10/D19 F10).
      const here = opts && opts.here === true && template === thread.template;
      const again = opts && opts.again === true;
      const result = await startConversation({
        period: thread.period,
        template,
        ...(again ? { again: true } : {}),
        ...(here ? { sessionId } : {}),
      });
      if (!result || !result.ok) {
        setFailure("That task didn't start. Nothing was recorded. Try again.");
        return;
      }
      if (result.sessionId === sessionId) {
        if (view) arrival.current = view;
        await catchUp();
        // The task ran again: Month-end's counts and the sidebar's word moved with it.
        router.refresh();
      } else router.push(`/chat/${encodeURIComponent(result.sessionId)}${view ? `?${VIEW_PARAM}=${encodeURIComponent(view)}` : ""}`);
    },
    [thread.period, thread.template, sessionId, catchUp, router]
  );

  // RETRY: a task is run again; a question to Vert is asked again, in your words. A
  // linked task's stop drawn here (lib/agent/linked.js) retries THAT task, in its own
  // conversation, then reads it again so what it did is drawn here (23 Oct 2026).
  const retry = useCallback(async (item = null) => {
    if (item && item.linked && item.template) {
      const result = await startConversation({ period: thread.period, template: item.template, sessionId: item.linked });
      if (!result || !result.ok) {
        setFailure("That task didn't start. Nothing was recorded. Try again.");
        return;
      }
      const lent = await readLinkedTask(item.linked, undefined, { tries: 1 });
      if (lent) setBorrowed((now) => new Map(now).set(item.linked, lent));
      router.refresh();
      return;
    }
    if (thread.template) return startTask(thread.template, null, { here: true });
    const lastYou = [...thread.items].reverse().find((i) => i.kind === "you");
    if (lastYou) return send(lastYou.text);
    return undefined;
  }, [thread, startTask, send, router]);

  // The LATEST copy of each result: a task run twice emits the same artifact twice, and
  // opening the first drew the stale "0 of 4 match" beside an answer saying 2 of 4.
  const artifacts = useMemo(() => paneArtifacts(thread.items), [thread.items]);
  const openArtifact = pane && pane.artifactId ? artifacts.find((a) => a.artifactId === pane.artifactId) || null : null;
  // The entries an open result is about (answer shape): the approve-entries pane draws
  // them as numbered cards on its Entries tab.
  const paneEntries = useMemo(() => (openArtifact ? paneEntriesFor(thread.items, openArtifact.artifactId) : null), [thread.items, openArtifact]);
  const chatRef = useRef(null);

  // OPEN A RESULT from `trigger` (the control pressed). The turn the control sits in
  // (`data-turn`, Thread.js) is where an inline result is drawn; failing that, the turn
  // that holds the result; failing that, the last. THE CONTROL THAT OPENED IT gets focus
  // back when it closes (verify pass 1, U36).
  const opener = useRef(null);
  const openPane = useCallback((next, trigger = null) => {
    const el = trigger && trigger.isConnected ? trigger : lastPress.current && lastPress.current.isConnected ? lastPress.current : null;
    const active = typeof document !== "undefined" ? document.activeElement : null;
    opener.current = el || (active && active !== document.body ? active : null);
    const holder = el && typeof el.closest === "function" ? el.closest("[data-turn]") : null;
    const turn = holder ? holder.getAttribute("data-turn") : null;
    setPane({ sheet: null, highlight: null, editing: null, ...next, turn });
  }, []);
  // A press that names a view's word as its sheet ("Bridge"), or an artifact that is only
  // a view, opens the view; anything else opens the workbook at that sheet.
  const openResultAt = useCallback(
    (artifactId, sheet = null) => {
      const view = viewFor(artifacts.find((a) => a.artifactId === artifactId) || null, sheet);
      openPane(view ? { artifactId, view } : { artifactId, sheet });
      // A linked task's workbook not read yet (W1-46): read it now; the pane draws it
      // the moment it is held, so the press is never a download or a dead button.
      const taskId = artifacts.some((a) => a.artifactId === artifactId) ? null : linkedTaskFor(thread.items, artifactId);
      if (taskId) {
        readLinkedTask(taskId).then((lent) => {
          if (lent && lent.delivered.length) setBorrowed((now) => new Map(now).set(taskId, lent));
        });
      }
    },
    [openPane, artifacts, thread.items]
  );
  const openView = useCallback((artifactId, view) => openPane({ artifactId, view }), [openPane]);
  const links = useMemo(() => viewLinks(artifacts), [artifacts]);
  // "Open workbook" from a view: its workbook card when this conversation holds it, else
  // the same artifact's table when it has one. Neither: no way back is drawn.
  const paneView = pane && pane.view ? pane.view : null;
  const backTo = openArtifact && paneView ? workbookOf(openArtifact, paneView) : null;
  const backTarget = backTo ? artifacts.find((a) => a.artifactId === backTo) || null : null;
  const canGoBack = Boolean(backTarget && backTarget.table && Array.isArray(backTarget.table.sheets) && backTarget.table.sheets.length);
  const onView = useCallback(
    (view) => {
      if (view) return setPane((p) => (p ? { ...p, view, sheet: null, highlight: null } : p));
      return setPane((p) => (p ? { ...p, artifactId: backTo || p.artifactId, view: null, sheet: null, highlight: null } : p));
    },
    [backTo]
  );
  // OPEN THE VIEW THE PRESS WAS FOR, ON ARRIVAL. Arriving at `?view=bridge` (or a start
  // in this same conversation that carried it) opens the latest artifact carrying that
  // view as soon as the thread holds one; the task may still be running, so this waits
  // for the event. Once only, and never over a pane the person already opened. The query
  // is then dropped from the address, so a reload or Back does not open it again.
  useEffect(() => {
    if (replay || preview || typeof window === "undefined") return;
    if (arrival.current === null) {
      const asked = new URLSearchParams(window.location.search).get(VIEW_PARAM);
      arrival.current = asked || false;
    }
    const view = arrival.current;
    if (!view) return;
    if (pane) {
      arrival.current = false;
      return;
    }
    const target = arrivalTarget(artifacts, view);
    if (!target) return;
    arrival.current = false;
    openPane({ artifactId: target, view });
    const url = new URL(window.location.href);
    if (url.searchParams.has(VIEW_PARAM)) {
      url.searchParams.delete(VIEW_PARAM);
      window.history.replaceState(window.history.state, "", `${url.pathname}${url.search}${url.hash}`);
    }
  }, [replay, preview, artifacts, pane, openPane]);
  const closeResult = useCallback(() => {
    setPane(null);
    const back = opener.current;
    opener.current = null;
    if (typeof window === "undefined") return;
    window.requestAnimationFrame(() => {
      if (back && back.isConnected && typeof back.focus === "function") back.focus({ preventScroll: true });
      else {
        // The opener is gone (the card it sat on was replaced): the composer's field.
        const field = chatRef.current && chatRef.current.querySelector(".chat-composer-field");
        if (field) field.focus({ preventScroll: true });
      }
    });
  }, []);
  const pickSheet = useCallback((sheet) => setPane((p) => (p ? { ...p, sheet, highlight: null } : p)), []);
  const paneApi = useMemo(
    () => ({
      id: paneId,
      // Whether the pane is in the document now: a figure names it in aria-controls only
      // then (S-UI-6, axe aria-valid-attr-value: an id with no element is invalid).
      isOpen: Boolean(openArtifact || (pane && pane.editing)),
      locate: (figure, ref) => locateFigure(artifacts, figure, ref),
      // An account's name as the results write it, for a figure's source sheet (W06).
      // Then as the turn's own tool rows name it ("1020 Business Cheque", Q06 F-1).
      accountName: (id) => accountNameIn(artifacts, id) || recordNameIn(thread.items, "ledger", id),
      open: (target, trigger) => openPane({ artifactId: target.artifactId, sheet: target.sheet, highlight: target }, trigger),
      // No result is shown beside the answer any more (p1 chat): an answer always draws
      // its own body (results/ShownInPane.js folds nothing).
      shownId: null,
      // A view's drill finds its workbook here (results/Bridge.js, results/Commentary.js).
      artifact: (artifactId) => artifacts.find((a) => a.artifactId === artifactId) || null,
      // FJ's slot: a JE card's Edit opens its editor here (components/cards EditorFor).
      editEntry: (action, trigger) => {
        const a = entryArtifact(artifacts, action);
        openPane({ artifactId: a ? a.artifactId : null, editing: action }, trigger);
      },
    }),
    [paneId, artifacts, openPane, openArtifact, pane, thread.items]
  );

  // WHERE THE OPEN RESULT IS DRAWN (ResultPane.js `paneMode`): inline under its turn, or
  // in the modal over the conversation.
  const paneBodyNow = pane ? bodyFor(openArtifact, { editing: pane.editing, view: pane.view, sheet: pane.sheet, highlight: pane.highlight }) : "none";
  const mode = paneMode(paneBodyNow);
  const resultProps = {
    paneId,
    artifact: openArtifact,
    artifacts,
    sheet: pane ? pane.sheet : null,
    highlight: pane ? pane.highlight : null,
    editing: pane ? pane.editing : null,
    onSheet: pickSheet,
    view: paneView,
    onView: paneView && !canGoBack ? null : onView,
    views: openArtifact && !paneView ? links.get(openArtifact.artifactId) || null : null,
    onOpenView: openView,
    onClose: closeResult,
    ledgerName,
    entries: paneEntries,
  };
  const inline = mode === "inline" ? { turn: pane.turn || null, artifactId: openArtifact ? openArtifact.artifactId : null, node: <ResultPane mode="inline" {...resultProps} /> } : null;

  // THE DATA AND SOURCES PANEL. A turn's Open passes its outline; the head's Sources
  // opens the whole conversation's. The control that opened it gets focus back (the kit
  // Sheet's own rule).
  const sourcesApi = useMemo(
    () => ({
      open: (turn = null) => setSourcesOpen({ turn: turn || null }),
      openKey: sourcesOpen && sourcesOpen.turn ? sourcesOpen.turn.key : sourcesOpen ? "all" : null,
    }),
    [sourcesOpen]
  );
  const closeSources = useCallback(() => setSourcesOpen(null), []);
  const nameAccount = paneApi.accountName;

  // THE BUDGET SHEET. Opened over the conversation, anchored to the control pressed.
  const budgetApi = useMemo(
    () =>
      replay || preview || !sessionId
        ? null
        : {
            open: (trigger = null) => {
              const el = trigger && trigger.isConnected ? trigger : lastPress.current && lastPress.current.isConnected ? lastPress.current : null;
              const origin = el && typeof el.getBoundingClientRect === "function" ? anchorOrigin(el.getBoundingClientRect(), { width: window.innerWidth, height: window.innerHeight }) : null;
              setBudgets({ origin });
            },
          },
    [replay, preview, sessionId]
  );
  useEffect(() => {
    // Arriving at `?sheet=budgets` (a "Choose a budget" link from outside this view)
    // opens the sheet once. Read from the address, not useSearchParams, so the static
    // build's recorded conversations still prerender without a Suspense boundary.
    if (!budgetApi || typeof window === "undefined") return;
    const asked = new URLSearchParams(window.location.search).get("sheet");
    if (asked === BUDGETS_SHEET) setBudgets((b) => b || { origin: null });
  }, [budgetApi, initialEvents]);
  const closeBudgets = useCallback(() => setBudgets(null), []);
  const followImport = useCallback(
    (status) => {
      if (status && status.sessionId && status.sessionId !== sessionId) router.push(`/chat/${encodeURIComponent(status.sessionId)}`);
      else catchUp();
    },
    [sessionId, router, catchUp]
  );
  const documents = useMemo(() => attachedDocuments(thread.items), [thread.items]);

  return (
    <PaneContext.Provider value={paneApi}>
    <SourcesContext.Provider value={sourcesApi}>
    <BudgetSheetContext.Provider value={budgetApi}>
    <div
      ref={chatRef}
      className="chat bleed"
      data-sources={sourcesOpen ? "open" : "closed"}
      onClickCapture={(event) => {
        const el = event.target && typeof event.target.closest === "function" ? event.target.closest("button, a") : null;
        if (el) lastPress.current = el;
      }}
    >
      <div className="chat-main">
        {replay ? <ReplayBand /> : null}
        <ConversationHeader
          ref={chipRef}
          thread={thread}
          clientName={clientName}
          ledgerName={ledgerName}
          onOpenSources={() => sourcesApi.open(null)}
          sourcesOpen={sourcesApi.openKey === "all"}
          onRunAgain={() => startTask(thread.template, null, { again: true, here: true })}
          runAgainDisabledReason={disabledReason}
          canEditSkill={Boolean(viewerSignedIn) && !replay}
          onStartHeld={thread.held && thread.taskId && !replay && !disabledReason ? startHeld : null}
          startingHeld={startingHeld}
          startHeldFailure={startHeldFailure}
          offline={offline}
        />
        <div className="chat-scroll" ref={scrollRef}>
          <Thread
            thread={thread}
            sessionId={sessionId}
            ledgerName={ledgerName}
            replay={replay}
            onAnswer={answer}
            onOpenResult={openResultAt}
            onOpenView={openView}
            viewLinks={links}
            onStartTask={startTask}
            // An answer's `ask` next action sends its question as your message: the
            // same road as the composer, so it is held while a model turn runs and is
            // disabled, with its reason, in a replay (eval AN5: half the live answers
            // ended on nothing).
            onAsk={send}
            onRetry={retry}
            disabledReason={heldReason}
            assistantDown={assistantDown}
            inline={inline}
          />
          {/* The feeds answer beside the month's own sources (staging browser walk 1, D14). */}
          <FeedsSourcesNote template={thread.template} sources={sources} period={thread.period} />
          {stillOutgoing(outgoing, thread.items).map((o) => (
            <SendingNow key={o.id} text={o.text} />
          ))}
        </div>
        <Composer
          state={composer}
          held={held}
          onSend={send}
          onStop={stop}
          failure={failure ? `${failure}${failures > 1 ? ` ${NOT_SENT_AGAIN}` : ""}` : null}
          offline={offline && !replay ? { text: OFFLINE, retrying, onRetry: retryNow } : null}
          documentsEnabled={documentsEnabled}
        />
      </div>
      {/* Both layers are portalled to <body> (components/ui/Portal.js): inside the shell
          they sat in its stacking context, under the sidebar and the phone's top bar. */}
      {mode === "dialog" ? (
        <Portal>
          <ResultPane mode="dialog" {...resultProps} />
        </Portal>
      ) : null}
      <Portal>
      <SourcesPanel
        open={Boolean(sourcesOpen)}
        turn={sourcesOpen ? sourcesOpen.turn : null}
        thread={thread}
        sources={sources}
        clientName={clientName}
        ledgerName={ledgerName}
        accountName={nameAccount}
        onClose={closeSources}
      />
      </Portal>
      {budgets ? (
        <BudgetSheet
          open
          origin={budgets.origin || null}
          sessionId={sessionId}
          documents={documents}
          ledgerName={ledgerName}
          onStarted={followImport}
          onClose={closeBudgets}
        />
      ) : null}
    </div>
    </BudgetSheetContext.Provider>
    </SourcesContext.Provider>
    </PaneContext.Provider>
  );
}

/**
 * The task template a question's chosen option names, or null. The engine marks an
 * option that stands for a month-end task with `template` (its id); an option without
 * one is an ordinary answer.
 */
export function optionTemplate(items, answer) {
  if (!answer || answer.optionId == null) return null;
  const q = (Array.isArray(items) ? items : []).find((i) => i.kind === "question" && i.questionId === answer.questionId);
  const option = q ? q.options.find((o) => o.id === answer.optionId) : null;
  const t = option && typeof option.template === "string" ? option.template.trim() : "";
  return /^[a-z][a-z0-9_]*$/.test(t) ? t : null;
}
