"use client";

// components/chat/Composer.js — ASK A FOLLOW-UP, AND HAND VERT A FILE
// ==============================================================================
// Spec §3.3 and §4.3. Fixed to the bottom and always reachable, phone included
// (UI-038). Enter sends; Shift+Enter adds a line.
//
// THE ATTACH CONTROL EXISTS ONLY WHERE FILES ARE READ (build plan §19.0.3, §19.8
// F-FILES). The "+" and the drop onto the box are drawn only when the engine says it
// reads files (`GET /session` → `documentsEnabled`, through lib/documents.js
// `documentsStatus`). Anywhere else — no service, a SQLite store, no blob root, the
// static showpiece, a failed read — there is no "+" at all: absent, never dead
// (spec §1.9; tests/no-false-affordance.test.js). The page passes `documentsEnabled`,
// read on the server (app/chat/[id]/page.js); left undefined, it is off. The composer
// used to ask itself, from an effect, and `documentsStatus` is a server action, so
// opening a conversation sent a POST before anyone pressed anything (smoke test, 23 Oct;
// tests/p0-quiet-page-load.test.js).
//
// A FILE IS SENT AT ONCE AND SHOWN AS WHAT THE STORE HOLDS. Choosing or dropping a file
// uploads it (POST /api/documents → the engine's POST /documents), and the chip that
// appears is the engine's own reading of it ("3 pages", "2 of 3 pages read"). One press
// on the chip opens the file in the pane (DocumentView): upload → chip → pane in two
// presses. A refused upload says why and that nothing was stored; the text you typed is
// never touched by it.
//
// SENDING CARRIES THE FILE IN WORDS. The message goes out with one line per attached
// file ("Attached file: payroll-july.xlsx (document …)"), so your turn says what you
// sent and the chat's document tools read the id from the same text; the files also go
// to `onSend` as its second argument, for a view that sends them structurally.
//
// MERGE AND SPLIT ARE NOT HERE. "Merge the two invoices" is something you type; there is
// no chip menu (§19.8).
//
// THREE STATES BESIDE READY, EACH SAID IN WORDS:
//   · rules work running: disabled, with the reason printed. There is no queue that
//     promises something nobody will do.
//   · a model turn running: what you send is held and shown "Will answer when this
//     finishes", and Stop replaces Send. Only while something IS running: a task's
//     conversation nobody started (its brief as the only turn, the engine's "waiting")
//     is ready, so what you type is sent, never held behind a Stop over nothing (eval
//     r1 WP #3; the rule is lib/agent/events.js threadModel `notStarted`).
//   · a replay: disabled, because nobody is there to answer.
//
// A MESSAGE THAT FAILED TO SEND IS KEPT. The text stays in the box and the line under
// it says "Not sent. Nothing was recorded." (spec §11.5: input is never discarded).

import { useEffect, useId, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import { IconButton, NoticeLine } from "@/components/ui";
import { formatCount } from "@/lib/format";
import DocumentView, { DOCUMENT_ACCEPT, FileChip, attachmentLines, sessionFromPath, uploadFile } from "./results/DocumentView";
import { IconAttach, IconSend } from "@/components/ui/icons";


export { sessionFromPath, uploadFile };

/** The text a message goes out with: your words, then one line per attached file. */
export function messageWithFiles(text, chips) {
  const lines = attachmentLines(chips);
  return [text.trim(), ...lines].filter(Boolean).join("\n");
}

/** The placeholder: an example ending in "…" (spec §5.3), shorter on a phone (DA2-073). */
export const PLACEHOLDER = "Ask a follow-up, e.g. why did this change…";
export const PLACEHOLDER_SHORT = "Ask a follow-up…";

/** A message that did not reach Vert (DA2-074): the cause, and that nothing is lost. */
export const MESSAGE_NOT_SENT = "Couldn't send: Vert's server didn't answer. Your message is still here.";
/** The longest message the API takes (vert_api: 4,000 characters; S-AC-10). */
export const MESSAGE_MAX = 4000;
/** The counter appears once a message is this close to the limit. */
export const COUNT_FROM = 3500;
export const MESSAGE_TOO_LONG = "That message is over 4,000 characters, so it wasn't sent. Shorten it and send again.";

/**
 * The words for a send that failed, from the API's own answer (verify pass 1, S-AC-10).
 * A 400 or 422 is the API refusing the message itself, not "the server didn't answer":
 * the limit is named; another refusal says it was refused, in the API's sentence when it
 * wrote one for a person. Anything else is the network line. Pure.
 */
export function sendFailureWords(result) {
  const r = result && typeof result === "object" ? result : {};
  const status = Number.isInteger(r.status) ? r.status : 0;
  if (status === 400 || status === 422) {
    const said = `${r.code || ""} ${r.message || ""}`;
    if (/too[_ ]long|at most|max(?:imum)?[_ ]length|4[, ]?000|string_too_long/i.test(said)) return MESSAGE_TOO_LONG;
    const message = typeof r.message === "string" ? r.message.trim() : "";
    const human = message && message.length < 240 && /[.!?]$/.test(message) && !/[{}<>]|https?:|\bHTTP\b/.test(message);
    return human ? `Couldn't send: ${message} Your message is still here.` : "Couldn't send: Vert refused that message. Your message is still here.";
  }
  // A 409 is the API turning the send away because another one was being queued at the
  // same moment (W1-44, DOW-RAPID20: "lost the race for the next ordinal"), and a 429
  // is too many sends at once. Both were answered, so neither is "didn't answer"; the
  // engine's race sentence is internal and is never shown.
  if (status === 409) return MESSAGE_BUSY;
  if (status === 429) return MESSAGE_TOO_MANY;
  return MESSAGE_NOT_SENT;
}

export const MESSAGE_BUSY = "Couldn't send: Vert was taking another message at that moment. Your message is still here; send it again.";
export const MESSAGE_TOO_MANY = "Couldn't send: too many messages at once. Wait a moment, then send again. Your message is still here.";


/**
 * THE LENGTH, SAID BEFORE IT MATTERS (harsh wave 1, W1-45). Shared by the thread's
 * composer and Home's ask box: from 3,500 characters, "3,612 of 4,000 characters"; at
 * the limit, that it is the most one message holds, so a paste the box cut short is never
 * a silent loss. `length` is the whole message about to go out. Pure.
 */
export function messageCountWords(length) {
  const n = Number.isInteger(length) && length > 0 ? length : 0;
  if (n < COUNT_FROM) return null;
  if (n > MESSAGE_MAX) return `${formatCount(n)} of ${formatCount(MESSAGE_MAX)} characters. ${MESSAGE_TOO_LONG}`;
  if (n === MESSAGE_MAX) return `${formatCount(n)} of ${formatCount(MESSAGE_MAX)} characters: the most one message holds. Anything past it isn't in the box.`;
  return `${formatCount(n)} of ${formatCount(MESSAGE_MAX)} characters`;
}

/** The count line under a box, or nothing below 3,500 characters. */
export function MessageCount({ length, className = null }) {
  const words = messageCountWords(length);
  if (!words) return null;
  return (
    <p className={["chat-composer-count t-footnote", className].filter(Boolean).join(" ")} data-message-count="" aria-live="polite">
      {words}
    </p>
  );
}

/** Said after the second failure in a row. */
export const MESSAGE_NOT_SENT_AGAIN = "Check your connection or try again in a minute.";

/**
 * THE SEND FAILURE, ONE LINE (DA2-074; critic r1 F14), for any box a person types to Vert
 * in: the thread's composer and Home's ask box. Under the box, in a slot that is always
 * there so nothing shifts when it appears: the problem glyph, the cause, that the words
 * are still in the box, and a quiet Try again. After a second failure in a row it adds
 * what to do. `failures` is how many sends in a row have failed (0 draws nothing).
 */
export function SendFailedLine({ failures = 0, onRetry = null, busy = false, text = MESSAGE_NOT_SENT, className = null }) {
  return (
    <div className={["chat-composer-notice", className].filter(Boolean).join(" ")} data-send-failed-slot="">
      {failures > 0 ? (
        <NoticeLine tone="problem" actionLabel={typeof onRetry === "function" ? "Try again" : undefined} onAction={onRetry || undefined} actionBusy={busy} actionBusyLabel="Sending…">
          {`${text}${failures > 1 ? ` ${MESSAGE_NOT_SENT_AGAIN}` : ""}`}
        </NoticeLine>
      ) : null}
    </div>
  );
}

export default function Composer({ state, held = [], onSend, onStop, failure = null, documentsEnabled, sessionId, upload = uploadFile, offline = null }) {
  // Below 600 px the placeholder is the short one. Read after mount, so the server's
  // render and the first client render agree.
  const [phone, setPhone] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return undefined;
    const list = window.matchMedia("(max-width: 599.98px)");
    const on = () => setPhone(list.matches);
    on();
    list.addEventListener("change", on);
    return () => list.removeEventListener("change", on);
  }, []);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [files, setFiles] = useState([]);
  const [reading, setReading] = useState(0);
  const [refusal, setRefusal] = useState(null);
  const [dragOver, setOver] = useState(false);
  const [viewing, setViewing] = useState(null);
  const [origin, setOrigin] = useState(null);
  const pickerRef = useRef(null);
  const fieldId = useId();
  const reasonId = useId();
  const sendReasonId = useId();
  const pathname = usePathname();
  const session = sessionId || sessionFromPath(pathname);
  const disabled = state.disabled;
  // Offline (DA2-031): what you type is kept, and Send is held with the reason.
  const held_ = Boolean(offline);

  // The page's word, read on the server; any doubt (not told) reads as off.
  const attachable = documentsEnabled === true;

  const take = async (list) => {
    if (!attachable || disabled) return;
    const chosen = Array.from(list || []).filter(Boolean);
    if (!chosen.length) return;
    setRefusal(null);
    setReading((n) => n + chosen.length);
    for (const file of chosen) {
      const result = await upload(file, { session });
      setReading((n) => n - 1);
      if (result && result.ok && result.chip) setFiles((prev) => (prev.some((c) => c.documentId === result.chip.documentId) ? prev : [...prev, result.chip]));
      else setRefusal((result && result.message) || `${file.name} wasn't read. Nothing was stored.`);
    }
  };

  // EVERY SEND GOES AT ONCE (verify pass 1, S-AC-11). A send while one was in flight
  // was ignored, so a person typing fast lost the words in between; and while Vert was
  // working, messages were held in this tab's memory and dropped on reload. The box now
  // empties the moment you send, the message goes to the server (which queues turns),
  // and only a send that FAILED puts your words back, with the reason.
  const inFlight = useRef(0);
  const submit = async () => {
    const value = text.trim();
    if ((!value && !files.length) || disabled || held_ || reading || typeof onSend !== "function") return;
    if (value.length > MESSAGE_MAX) return;
    const sentFiles = files;
    const message = messageWithFiles(value, sentFiles);
    setText("");
    setFiles([]);
    inFlight.current += 1;
    setSending(true);
    const result = await onSend(message, sentFiles.length ? { documents: sentFiles } : undefined);
    inFlight.current -= 1;
    if (inFlight.current === 0) setSending(false);
    if (!(result && result.ok)) {
      // Your words back in the box, unless you have typed something new since.
      setText((now) => (now.trim() ? now : value));
      setFiles((now) => (now.length ? now : sentFiles));
    }
  };
  const over = text.length > MESSAGE_MAX;

  const dropProps = attachable
    ? {
        onDragOver: (event) => {
          if (disabled) return;
          event.preventDefault();
          setOver(true);
        },
        onDragLeave: () => setOver(false),
        onDrop: (event) => {
          event.preventDefault();
          setOver(false);
          take(event.dataTransfer && event.dataTransfer.files);
        },
      }
    : {};

  return (
    <form
      className="chat-composer"
      onSubmit={(event) => {
        event.preventDefault();
        submit();
      }}
    >
      {held.length ? (
        <ul className="chat-held">
          {held.map((m) => (
            <li key={m.id}>
              <span className="chat-held-text">{m.text}</span>
              <span className="chat-held-note">Will answer when this finishes.</span>
            </li>
          ))}
        </ul>
      ) : null}
      {state.reason ? (
        <p className="chat-composer-reason" id={reasonId}>
          {state.reason}
        </p>
      ) : null}
      {offline ? (
        // Above the composer, sticky with it: the one place someone typing will look.
        <NoticeLine tone="problem" className="chat-offline-notice" actionLabel="Try again" onAction={offline.onRetry} actionBusy={offline.retrying} actionBusyLabel="Retrying…">
          {offline.text}
        </NoticeLine>
      ) : null}
      {/* The live region is always in the document, so a refusal that appears in it is
          announced (verify pass 3, FL-ui2: a region inserted with its words is often not). */}
      {attachable && (
        <div className="chat-file-live" role="alert" aria-live="assertive" data-file-live="">
          {refusal ? (
            <p className="chat-inline-error" data-attach-refusal="">
              {refusal}
            </p>
          ) : null}
        </div>
      )}
      {files.length || reading ? (
        <div className="chat-composer-files" data-composer-files="">
          {files.map((chip) => (
            <FileChip key={chip.documentId} chip={chip} onOpen={(c, o) => { setOrigin(o); setViewing(c); }} onRemove={(c) => setFiles((prev) => prev.filter((x) => x.documentId !== c.documentId))} />
          ))}
          {reading ? (
            <span className="chat-file-chip chat-file-chip-reading" aria-live="polite">
              Reading {reading === 1 ? "the file" : `${reading} files`}…
            </span>
          ) : null}
        </div>
      ) : null}
      <div className={["chat-composer-box", dragOver ? "chat-composer-box-over" : null].filter(Boolean).join(" ")} {...dropProps}>
        {attachable ? (
          <>
            <IconButton label="Attach a file" className="chat-attach" disabled={disabled} onClick={() => pickerRef.current && pickerRef.current.click()}>
              <IconAttach size={16} />
            </IconButton>
            <input
              ref={pickerRef}
              className="chat-attach-input"
              hidden
              type="file"
              multiple
              accept={DOCUMENT_ACCEPT}
              tabIndex={-1}
              aria-hidden="true"
              disabled={disabled}
              onChange={(event) => {
                take(event.target.files);
                event.target.value = "";
              }}
            />
          </>
        ) : held_ ? (
          // The attach slot keeps its width while Vert can't be reached, so the words in
          // the box don't jump left when the file reader can't be asked (DA2-031).
          <span className="chat-attach chat-attach-slot" aria-hidden="true" />
        ) : null}
        <label className="chat-visually-hidden" htmlFor={fieldId}>
          Ask a follow-up
        </label>
        <textarea
          id={fieldId}
          name="message"
          autoComplete="off"
          className="chat-composer-field"
          rows={1}
          placeholder={phone ? PLACEHOLDER_SHORT : PLACEHOLDER}
          value={text}
          maxLength={MESSAGE_MAX}
          disabled={disabled}
          aria-describedby={state.reason ? reasonId : held_ ? sendReasonId : undefined}
          onChange={(event) => setText(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
              event.preventDefault();
              submit();
            }
          }}
        />
        {state.canStop ? (
          <button type="button" className="chat-send chat-stop" onClick={onStop}>
            Stop
          </button>
        ) : (
          <button
            type="submit"
            className="chat-send"
            aria-label="Send"
            aria-busy={sending ? "true" : undefined}
            aria-disabled={held_ ? "true" : undefined}
            aria-describedby={held_ ? sendReasonId : undefined}
            disabled={!held_ && (disabled || over || Boolean(reading) || (!text.trim() && !files.length))}
            onClick={held_ ? (event) => event.preventDefault() : undefined}
          >
            <IconSend size={16} />
          </button>
        )}
      </div>
      <MessageCount length={text.length} />
      {held_ ? (
        <span className="chat-visually-hidden" id={sendReasonId}>
          {offline.text}
        </span>
      ) : null}
      {/* THE FAILURE LINE (DA2-074): one line under the composer, the cause, that your
          words are still here, and Try again; its space is kept so nothing shifts. */}
      <div className="chat-composer-notice">
        {failure ? (
          <NoticeLine tone="problem" actionLabel="Try again" onAction={submit} actionBusy={sending} actionBusyLabel="Sending…">
            {failure}
          </NoticeLine>
        ) : null}
      </div>
      <DocumentView chip={viewing} open={Boolean(viewing)} origin={origin} onClose={() => setViewing(null)} />
    </form>
  );
}
