"use client";

// components/chat/FeedsSourcesNote.js — THE FEEDS ANSWER, BESIDE WHAT THE SOURCES SAY
// ==============================================================================
// Staging browser walk 1 (31 Oct 2026, D14): Integration feeds said "2 feeds are current
// for October, with no failed sync recorded" while Month-end's Sources popover said "Bank
// feed only through 17 Oct". The verdict is the engine's, judged from its sync runs
// (vert_engine/analysis/feed_health.py); the popover's is the month's `sources` from
// GET /close, worded by lib/format.js freshnessWords. A bookkeeper read two answers to
// one question.
//
// The feeds conversation now says the popover's fact under its answer, from the same
// `sources` (the page's promise of the month, lib/agent/conversation-page.js) through the
// same rule and words (components/month/model.js sourcesBehindWords). Nothing behind,
// nothing said; any other task, nothing drawn.

import { Suspense, use } from "react";
import { sourcesBehindWords } from "@/components/month/model";
import { monthName } from "@/lib/period";

const FEEDS = "integration_feeds";

function Note({ sources, period }) {
  const words = sourcesBehindWords(sources);
  if (!words) return null;
  const month = period ? monthName(period) : null;
  return (
    <p className="chat-feeds-sources t-footnote" role="note" data-feeds-sources="">
      {`Not every source is current${month ? ` for ${month}` : ""}: ${words}.`}{" "}
      {/* Month-end has no Sync now (walk 3 copy list): the link is where it is. */}
      <a className="link" href="/connections">
        Sync now
      </a>
    </p>
  );
}

function Awaited({ sources, period }) {
  return <Note sources={use(sources)} period={period} />;
}

export function FeedsSourcesNote({ template, sources, period = null }) {
  if (template !== FEEDS || !sources) return null;
  if (typeof sources.then === "function") {
    return (
      <Suspense fallback={null}>
        <Awaited sources={sources} period={period} />
      </Suspense>
    );
  }
  return <Note sources={sources} period={period} />;
}

export default FeedsSourcesNote;
