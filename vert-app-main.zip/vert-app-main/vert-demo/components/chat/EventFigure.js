"use client";

// components/chat/EventFigure.js — ONE ENGINE FIGURE IN A CONVERSATION
// ==============================================================================
// Every money figure in a conversation is one the engine emitted, carried as
// `{ cents, currency, measured, source: { kind, id }, reason? }` (build plan §2.2). It
// is drawn by F1's `Figure`, the same component Month-end and Records use, so the same
// cents read the same way and open the same kind of SOURCE SHEET (spec §9.3): the
// record behind the number in words, the id under Details, the way on to Records
// (lib/agent/figure-source.js). This replaced the chat's own inline note, which named
// only a generic origin (eval C2, 30 Sep).
//
// THE MARKUP CARRIES THE BINDING. The wrapper has `data-figure` (the event's reference)
// and `data-cents` (the engine's integer), so a check can hold the text on screen to
// the number the engine sent without parsing a formatted string (eval C1).
//
// INSIDE ANOTHER CONTROL (`plain`), the figure is text with the same data attributes and
// no sheet: a question's option is itself a button, and a button inside a button is
// invalid markup that a browser repairs by splitting the option in two.
//
// IN A CONVERSATION WITH A RESULT THAT HOLDS ITS ROW, the figure opens that row in the
// result pane, highlighted, instead of a source sheet: the row IS the source, with its
// neighbours and totals around it (build plan §4.4 FP 3; components/chat/results/
// paneContext.js). Never a new page and never a modal; the chat keeps its place.
//
// UNREAD IS WORDS. `measured === false`, or no cents: the engine's reason if it gave
// one, else "not read yet". Never $0.00 (spec §9.4).

import { useContext, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Figure, SourceSheet } from "@/components/ui";
import { InsideControl } from "@/components/ui/Figure";
import { formatMoney } from "@/lib/format";
import { useEngine } from "@/lib/engine-context";
import { figureSource, isReadFigure } from "@/lib/agent/figure-source";
import { usePane } from "./results/paneContext";

// `belowZero`: the tie-out line drawing this figure says it is below zero in its own
// right; its sheet's total carries the line's minus (W7-1).
export default function EventFigure({ figure, figureRef = null, plain: plainProp = false, belowZero = false }) {
  const engine = useEngine();
  // Inside a control (a delivered file's card, an option row) the figure is text.
  const inside = useContext(InsideControl);
  const plain = plainProp || inside;
  const [open, setOpen] = useState(false);
  const [used, setUsed] = useState(false);
  const trigger = useRef(null);
  const pane = usePane();
  const read = isReadFigure(figure);
  const unread = figure && typeof figure.reason === "string" && figure.reason.trim() ? figure.reason.trim() : "not available yet";
  // The conversation's results name the accounts a P&L figure was read from (W06).
  const source = read && !plain ? figureSource(figure, engine, figureRef, { accountName: pane && typeof pane.accountName === "function" ? pane.accountName : null, belowZero }) : null;
  // Spelled as quoted keys: a hyphenated JSX attribute next to a money name reads as a
  // subtraction to tests/no-arithmetic.test.js, and there is none here.
  const binding = {
    "data-figure": figureRef || "",
    "data-cents": read ? String(figure.cents) : undefined,
    "data-measured": read ? "true" : "false",
  };
  // Where the figure is a control, the cents are on the control a person presses, once
  // (W06); the wrapper keeps the reference so a reader of the sentence still finds it.
  const outer = { "data-figure": binding["data-figure"], "data-measured": binding["data-measured"] };
  const row = read && !plain && pane ? pane.locate(figure, figureRef) : null;
  if (row) {
    return (
      <span className="chat-fig" {...outer}>
        <button
          type="button"
          className="figure num figure-source figure-row"
          // Only while the pane is in the document (S-UI-6): an aria-controls naming an
          // id that isn't there is a critical axe violation.
          aria-controls={pane.isOpen ? pane.id : undefined}
          // A number alone is not a name for a control (U68): it says what pressing does.
          aria-label={`${formatMoney(figure.cents)}, show it in the workbook`}
          // THE PRESSED NUMBER'S CELL, NOT ONLY ITS LINE (verify pass 3, Q07/Q09: 10/10
          // presses opened a tab with no cell marked): the target carries the figure's
          // cents, and the pane marks the cell of the lit row that holds them.
          onClick={(event) => pane.open({ ...row, cents: figure.cents }, event.currentTarget)}
          data-ui="Figure"
          data-opens="pane"
          // The binding on the pressable itself too (W06): a check that reads the
          // control a person presses finds the engine's reference and cents on it.
          {...binding}
        >
          {formatMoney(figure.cents)}
        </button>
      </span>
    );
  }
  if (plain && read) {
    // Text inside another control: the binding once, on the wrapper (one string, one
    // `data-cents`), and no second control.
    return (
      <span className="chat-fig" {...binding}>
        <span className="figure num" data-ui="Figure" translate="no">
          {formatMoney(figure.cents)}
        </span>
      </span>
    );
  }
  if (!source) {
    return (
      <span className="chat-fig" {...binding}>
        <Figure cents={read ? figure.cents : undefined} measured={read} unread={unread} figure={figureRef || ""} />
      </span>
    );
  }
  // WITH A SOURCE: F1's Figure trigger and F1's SourceSheet, with the sheet PORTALLED to
  // the document body. A conversation's figure sits inside a sentence (a <p>), and a
  // sheet is a <div>/<section>/<h2>; mounted in place it is invalid HTML that React
  // reports as a hydration error. The trigger's markup is Figure's own (class, role,
  // data-ui), so it reads and behaves as every other figure in the app.
  return (
    <span className="chat-fig" {...outer}>
      <button
        type="button"
        ref={trigger}
        className="figure num figure-source"
        aria-haspopup="dialog"
        aria-expanded={open ? "true" : "false"}
        aria-label={`${formatMoney(figure.cents)}, where it comes from`}
        onClick={() => {
          setUsed(true);
          setOpen(true);
        }}
        data-ui="Figure"
        data-below-zero={belowZero ? "" : undefined}
        // The binding on the pressable too (W06: a check reading the control a person
        // presses found no data-figure / data-cents on any task answer's figure).
        {...binding}
      >
        {formatMoney(figure.cents)}
      </button>
      {used && typeof document !== "undefined"
        ? createPortal(<SourceSheet open={open} onClose={() => setOpen(false)} {...source} />, document.body)
        : null}
    </span>
  );
}
