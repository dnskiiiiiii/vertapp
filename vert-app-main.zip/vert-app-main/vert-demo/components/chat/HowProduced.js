// components/chat/HowProduced.js — WHO PRODUCED A TURN, IN WORDS: THE ONLY PLACE A MODEL IS NAMED
// ==============================================================================
// Spec §4.2 and §9.1: exact results are unmarked, a model's reading carries only the
// best-guess mark, and everything about the machinery (rules or a model, which model,
// live or replayed) is said in one place. A model id appearing anywhere else in the
// thread is a defect that chat-truth holds.
//
// ITERATION 2 (build plan §4.0.8): "How this was produced" is no longer a block of its
// own under the answer. These lines sit at the foot of the opened "Worked for 41 s ▾"
// outline (components/chat/WorkedFor.js), inside its `chat-how` region, and token
// counts sit one further press down, behind a disclosure for developers: a bookkeeper
// has no use for them, and "Tokens: 900 in" on the face of an answer is jargon (AN3).
//
// A RECORDING IS NEVER CAPTIONED LIVE. When the conversation is a replay, this says so
// whatever the recorded events claim about themselves.

import { REPLAY_PRODUCED } from "@/lib/agent/replay";

/** "Tokens: 900 in, 40 out.", or null when the usage was not measured (never "0"). */
export function tokensLine(usage) {
  if (!usage || usage.measured !== true) return null;
  const parts = [];
  if (Number.isInteger(usage.input)) parts.push(`${usage.input} in`);
  if (Number.isInteger(usage.output)) parts.push(`${usage.output} out`);
  if (Number.isInteger(usage.cacheRead) && usage.cacheRead > 0) parts.push(`${usage.cacheRead} from cache`);
  return parts.length ? `Tokens: ${parts.join(", ")}.` : null;
}

export function producedLines({ produced, replay }) {
  if (replay) return [REPLAY_PRODUCED];
  const p = produced || {};
  if (p.by === "rules") {
    return ["Worked out from your records by Vert's rules."];
  }
  const usage = p.usage || null;
  if (!usage) return ["Vert didn't record how this answer was produced."];
  const lines = [];
  lines.push(typeof usage.model === "string" && usage.model ? `Written by ${usage.model}.` : "Written by a model Vert didn't name.");
  lines.push(usage.transportLive === true ? "Answered live." : "Not confirmed as a live answer.");
  return lines;
}
