// components/chat/BoundText.js — TEXT WITH ITS FIGURES BOUND, NEVER WRITTEN
// ==============================================================================
// Event text refers to money only by reference, `{{fig:<ref>}}`, and names the ledger
// only as `{{ledger}}` (build plan §2.2). This puts the ledger's name in and each
// referenced figure where its placeholder was, from the event's own `figures`, drawn
// by EventFigure (F1's Figure, with its source sheet).
//
// A REFERENCE THE EVENT DID NOT CARRY is never drawn as a number (spec §9.2), and it is
// not spliced into the sentence as a noun phrase either: "Two deposits of a figure
// Vert couldn't trace on 2 Jul" reads as a broken sentence and hides the fact in the
// middle of it (eval S6, 30 Sep). The slot says "an amount", which reads in any place
// money can stand, and the sentence is followed by one plain sentence saying the
// amount could not be traced, once however many slots were missing.
//
// NO RAW ID IS DRAWN (staging browser walk 5, the W4-9 remainder): the engine's words
// between the figures pass through lib/raw-ids.js withoutRawIds, so a stored answer's
// "Posted as journal 5179f49e-…" or "bank line xero:…" reads as words. The figures
// themselves are bound from their refs first, so no ref is ever rewritten.
//
// `plain` is for text inside another control (a question's option, its collapsed row):
// the figures are drawn without their sheet, see EventFigure.

import EventFigure from "./EventFigure";
import { bindFigures, withLedger } from "@/lib/agent/events";
import { withoutRawIds } from "@/lib/raw-ids";

export const UNTRACED_SLOT = "an amount";
export const UNTRACED_NOTE = "Vert couldn't trace the amount, so it isn't shown.";

export default function BoundText({ text, figures, ledgerName, plain = false }) {
  const parts = bindFigures(withLedger(text, ledgerName), figures).map((p) => (p.t === "text" ? { ...p, v: withoutRawIds(p.v, { ledgerName }) } : p));
  const untraced = parts.some((p) => p.t === "fig" && !p.figure);
  // A FIGURE KEEPS ITS BRACKETS (verify pass 1, D33): "( $22,613.47" broke after the
  // opening bracket, because a line may break beside the figure's control. The bracket
  // before a figure and the punctuation after it are drawn with it, unbreakable.
  const glue = glued(parts);
  return (
    <>
      {parts.map((part, i) =>
        part.t === "text" ? (
          <span key={i}>{glue.text[i]}</span>
        ) : part.figure ? (
          glue.lead[i] || glue.tail[i] ? (
            <span key={i} className="chat-fig-glue">
              {glue.lead[i]}
              <EventFigure figure={part.figure} figureRef={part.ref} plain={plain} />
              {glue.tail[i]}
            </span>
          ) : (
            <EventFigure key={i} figure={part.figure} figureRef={part.ref} plain={plain} />
          )
        ) : (
          <span key={i} className="chat-fig-untraced" data-figure={part.ref} data-measured="false">
            {UNTRACED_SLOT}
          </span>
        )
      )}
      {untraced ? <span className="chat-fig-note"> {UNTRACED_NOTE}</span> : null}
    </>
  );
}

/**
 * For each figure, the opening bracket that ends the text before it and the closing
 * punctuation that starts the text after it, taken out of those texts. Pure.
 */
export function glued(parts) {
  const text = parts.map((p) => (p.t === "text" ? p.v : null));
  const lead = parts.map(() => "");
  const tail = parts.map(() => "");
  parts.forEach((p, i) => {
    if (p.t !== "fig" || !p.figure) return;
    const before = i > 0 && typeof text[i - 1] === "string" ? text[i - 1] : null;
    const m = before !== null ? /[(\[\u201c\u2018]$/.exec(before) : null;
    if (m) {
      lead[i] = m[0];
      text[i - 1] = before.slice(0, -m[0].length);
    }
    const after = i + 1 < parts.length && typeof text[i + 1] === "string" ? text[i + 1] : null;
    const n = after !== null ? /^[)\].,;:!?%\u201d\u2019]+/.exec(after) : null;
    if (n) {
      tail[i] = n[0];
      text[i + 1] = after.slice(n[0].length);
    }
  });
  return { text, lead, tail };
}
