"use client";

// components/chat/Thread.js — THE CONVERSATION, IN ORDER
// ==============================================================================
// Draws the thread model (lib/agent/events.js `threadModel`) and nothing else: every
// item is one of the spec §4.2 kinds, looked up in messages/index.js. The list is a
// polite live region, so a screen reader hears what Vert adds without being
// interrupted.
//
// QUESTIONS ARE LISTED, AND A BATCH PAGES. The first unanswered question is open; the
// others are one-line rows that open in place when pressed (spec §4.2 row 4). Questions
// asked together carry "‹ 1 of 3 ›", and Skip or an answer opens the next one
// (components/chat/questions/model.js decides which is open, FQ, build plan §4.0.10).
//
// EVERY TURN, IN FOUR PARTS, TOP TO BOTTOM (p1 chat, founders' review 23 Oct 2026):
//   1. what you asked: your bubble (a task you started is its title, "Started from
//      Month-end"; messages/YourMessage.js);
//   2. the data Vert fetched for it, with an Open to that turn's data and sources in
//      the side panel (DataFetched.js);
//   3. its reasoning, one "Reasoning" disclosure, closed (WorkedFor.js);
//   4. the output: the answer inline (its table, tie-out, what it delivered, the entry
//      cards and one next action), and the cards and questions the turn raised.
// Each turn is one <section data-turn> (its key is the turn's, components/chat/answer/
// model.js `workedForTurns`), so a result opened from a control in it is drawn inline at
// the turn's foot (`inline`, ConversationView.js).
//
// NOTHING IS FOLDED AWAY. The thread used to open at "where it stands", with earlier runs
// and decided cards behind "Earlier: 3 decided". People come back to these workflows in a
// day or two and need the context: the whole conversation is drawn, in order.
//
// ONE CARD IS OPEN (PR8, eval S5, 2 Oct). Purple means "this writes", and a view holds
// one purple commit. So, as with questions and as Month-end does, the first undecided
// card is open and the others are one-line rows (messages/Decision.js) that open in
// place; deciding the open one opens the next. An answer's "open the card" link opens
// the card it names (`#card-…`).

import { useEffect, useMemo, useRef, useState } from "react";
import { lineFor } from "@/components/cards/words";
import { reopenSaved, useEditsVersion } from "@/components/cards/journal-edits";
import { ITEM_RENDERERS } from "./messages";
import { TakeUpAgain } from "@/components/cards/SettledDecision";
import WorkedFor, { lineKey, trailKeys } from "./WorkedFor";
import { wasPressedHere } from "@/lib/pressed-here";
import { cardAnchor } from "./NextAction";
import { landOn } from "@/lib/agent/land-on";
import { analysisOf, answerReadAList, workedForTurns } from "./answer/model";
import { shapeActionIds } from "./answer/shape";
import { activeQuestionId, pagerFor } from "./questions/model";
import { questionAnchor } from "@/app/api/budgets/shared";
import { typeset } from "@/lib/format";
import { linkedOpenable } from "@/lib/agent/linked";

/** The ids whose cards open in the pane: the carried results and a linked task's. Pure. */
export function withLinked(carried, items) {
  const linked = linkedOpenable(items);
  if (!linked.size) return carried;
  return new Set([...carried, ...linked]);
}

export default function Thread({
  thread,
  sessionId = null,
  ledgerName = null,
  replay = false,
  onAnswer,
  onOpenResult,
  onOpenView = null,
  viewLinks = null,
  onStartTask,
  onAsk,
  onRetry,
  disabledReason = null,
  assistantDown = false,
  // The result open inline (ConversationView.js): `{ turn, artifactId, node }`, or null.
  inline = null,
}) {
  const [openQuestion, setOpenQuestion] = useState(null);
  // The work outlines whose "How Vert did this" trail is open, by the item they sit on.
  const [openTrails, setOpenTrails] = useState(() => new Set());
  const trailToggle = (seq) => (open) =>
    setOpenTrails((prev) => {
      const next = new Set(prev);
      if (open) next.add(seq);
      else next.delete(seq);
      return next;
    });
  const activeQuestion = activeQuestionId(thread.items, openQuestion);
  const worked = workedForTurns(thread.items);
  const anchors = cardsPointedAt(thread.items);
  const carried = resultsCarriedByChips(thread.items);
  const carriedResults = carriedArtifacts(thread.items, carried);
  // A task started from here: its cards open in this pane even before the task's
  // conversation has been read (lib/agent/linked.js, harsh wave 1 W1-46).
  const openable = withLinked(carried, thread.items);

  // A journal card settled only by its saved edit is open again (eval final-a C6).
  useEditsVersion();
  const items = reopenSaved(thread.items);
  // THE ENTRIES AN ANSWER DRAWS ITSELF (answer shape, founder 17 Oct 2026): an answer
  // whose `shape.entries` names a decision draws that decision as its numbered card, so
  // the thread does not draw it a second time on its own (drawnByShape), and the one-open
  // rule is the thread's other cards' (the answer's entries are all on screen at once).
  // WHICH ANSWER DRAWS EACH ENTRY (verify pass 5, Q-SHAPE-5 / U09 / prepaid cards): only
  // what is DRAWN counts. Read over every item, an answer folded behind "Earlier" (a
  // stale or an older run's) still claimed its entries, so their open cards were drawn
  // nowhere on screen ("4 still need you" over one card); each older answer drew the same
  // entry again (Allianz three times, journal 2's plate three times). Now each entry is
  // drawn once: by the latest answer in view that carries it, else as its own card in
  // view when it is open or just posted, else by the latest folded answer.
  // Nothing is folded (p1 chat): every item is in view, in order.
  const fold = { earlier: [], current: items };
  const owners = entryOwners(fold);
  const shaped = new Set([...owners].filter(([, owner]) => owner !== CARD_OWNER).map(([id]) => id));
  // A linked task's cards (lib/agent/linked.js `lentDecisions`) are found as this
  // conversation's own are, so its entries are approved on their cards here.
  const decisions = decisionsById([...items, ...items.flatMap((i) => (i && Array.isArray(i.lentDecisions) ? i.lentDecisions : []))]);
  const [openCard, setOpenCard] = useState(null);
  // The card the address names (`#card-<id>`), anchored even when no answer points at it.
  const [hashTarget, setHashTarget] = useState(null);
  const landed = useRef(null);
  const activeCard = activeDecisionId(shaped.size ? items.filter((i) => !(i && i.kind === "decision" && i.action && shaped.has(String(i.action.actionId)))) : items, openCard);
  // The card the thread opened by itself is pinned as the one on screen, so a settlement
  // from elsewhere can't swap it for another under the person's pointer (S-CF-12).
  useEffect(() => {
    if (openCard == null && activeCard != null) setOpenCard(activeCard);
  }, [openCard, activeCard]);
  useEffect(() => {
    // An answer's next action is a link to `#card-<id>`; following it opens that card.
    // Needs you links to `#question-<id>` (an import's phasing question, #10); following
    // it opens that question, so the conversation opens AT the question card.
    const follow = () => {
      const hash = typeof window !== "undefined" ? window.location.hash.slice(1) : "";
      if (!hash) return;
      const hit = undecidedIds(thread.items).find((id) => cardAnchor(id) === hash);
      if (hit != null) {
        setOpenCard(hit);
        setHashTarget(hash);
      }
      const asked = thread.items.find((i) => i.kind === "question" && !i.answer && questionAnchor(i.questionId) === hash);
      if (asked) setOpenQuestion(asked.questionId);
      // LAND ON IT (verify pass 5, W10): Month-end's "Open in chat" now carries the card's
      // anchor, but the card is drawn after the thread renders (and an inline table above
      // it pushed it under the fold), so the browser's own jump found nothing. Once it is
      // in the document it is scrolled into view and focused, once per arrival.
      if ((hit != null || asked) && landed.current !== hash) landOn(hash, landed);
    };
    follow();
    window.addEventListener("hashchange", follow);
    return () => window.removeEventListener("hashchange", follow);
  }, [thread.items]);

  // "Take this up again" on a skipped decision runs this conversation's own task again,
  // here (components/cards/SettledDecision.js says why). Only a task conversation has a
  // task to run, and a replay runs nothing.
  const takeUp = useMemo(
    () => (thread.template && !replay && typeof onStartTask === "function" ? { run: () => onStartTask(thread.template, null, { again: true, here: true }), disabledReason } : null),
    [thread.template, replay, onStartTask, disabledReason]
  );

  const pending = pendingTurn(thread, replay);
  // A question still waiting for its answer (not answered, not skipped) anywhere here.
  const questionsOpen = thread.items.some((i) => i && i.kind === "question" && !i.answer);
  // A decision settled after the run is drawn where it was settled (DA2-056): the posted
  // card follows the answer it came after, not the card's first appearance.
  fold.current = settledInPlace(fold.current);
  const repeated = factsRepeatedBelow(fold.current);
  // The open cards an answer points at; a settled one is a line, not a place to go.
  // A plan's card is its ArtifactCard, which opens the plan in one press (DA2-024): an
  // answer's "Review the plan" pointing at it would be a second way to the same document,
  // so it is not drawn (NextAction draws an open_card only for an anchored card).
  // A card drawn in this turn, right under its answer, is not linked from the answer
  // either (critic r1 F6): "Review the reclass ›" sat between the answer and the very card
  // it pointed at, a second press to a thing already on screen. Only a card the turn does
  // not draw (an earlier one, folded away) keeps the link.
  const drawnNow = new Set(fold.current.filter((i) => i.kind === "decision" && !i.settled && i.action && i.action.actionId != null).map((i) => i.action.actionId));
  const openAnchors = new Set(items.filter((i) => i.kind === "decision" && !i.settled && i.action && i.action.kind !== "plan" && anchors.has(i.action.actionId) && !drawnNow.has(i.action.actionId)).map((i) => i.action.actionId));

  // A step the open trail shows is not quoted again as a question's evidence line under
  // it (DA2-032; critic r1 F7): "Looked for disposals (credits to 1500) in July: found
  // none" was said twice, in the trail and on the card.
  const shownInTrail = new Set();
  for (const seq of openTrails) {
    const outline = worked.hosts.get(seq) || worked.before.get(seq);
    if (outline) for (const k of trailKeys(outline)) shownInTrail.add(k);
  }
  const quoteInTrail = (item) => Boolean(shownInTrail.size && item && item.evidence && item.evidence.quote && shownInTrail.has(lineKey(item.evidence.quote.text)));

  const draw = (item) => {
    const Component = ITEM_RENDERERS[item.kind];
    if (!Component) return null;
    // A linked task's question or answer shares the seq of the answer that borrowed it.
    const key = item.linkedKey ? `${item.kind}-${item.linkedKey}` : `${item.kind}-${item.seq}`;
    switch (item.kind) {
      case "question":
        // Each question is a place a link can land (Needs you's `#question-<id>`).
        return (
          <div key={key} id={questionAnchor(item.questionId)} className="chat-card-anchor">
            <Component
              item={item}
              open={item.questionId === activeQuestion}
              onOpen={() => setOpenQuestion(item.questionId)}
              pager={pagerFor(thread.items, item)}
              onPage={setOpenQuestion}
              onAnswer={onAnswer}
              disabledReason={disabledReason}
              ledgerName={ledgerName}
              template={thread.template}
              quoteInTrail={quoteInTrail(item)}
            />
          </div>
        );
      case "result":
        // Its answer's "What I delivered" chip already carries it, with Open and the
        // card's view links ("Open bridge", "Edit commentary") beside it.
        if (!item.replaced && item.artifact && carried.has(item.artifact.artifactId)) return null;
        return (
          <Component
            key={key}
            item={item}
            onOpen={onOpenResult}
            ledgerName={ledgerName}
            views={viewLinks instanceof Map && item.artifact ? viewLinks.get(item.artifact.artifactId) || null : null}
            onOpenView={onOpenView}
          />
        );
      case "can_do_now":
        return <Component key={key} item={item} onStartTask={onStartTask} onResend={replay ? null : onAsk} disabledReason={disabledReason} period={thread.period || null} sessionId={sessionId} />;
      case "problem":
        return <Component key={key} item={item} onRetry={onRetry} retryDisabledReason={disabledReason} />;
      case "couldnt_tell":
        return <Component key={key} item={item} onResend={replay ? null : onAsk} disabledReason={disabledReason} />;
      case "work": {
        const outline = worked.hosts.get(item.seq);
        return outline ? <Component key={key} outline={outline} replay={replay} ledgerName={ledgerName} period={thread.period || null} onOpenChange={trailToggle(item.seq)} /> : null;
      }
      case "decision": {
        const id = item.action && item.action.actionId;
        if (id != null && shaped.has(String(id))) return null;
        const card = (
          <Component
            key={key}
            item={item}
            ledgerName={ledgerName}
            replay={replay}
            open={item.settled || id == null || id === activeCard || Boolean(item.action && ALWAYS_OPEN_KINDS.has(item.action.kind))}
            onOpen={() => setOpenCard(id)}
          />
        );
        // An answer's next action points at this card: it is the anchor that action
        // scrolls to (components/chat/NextAction.js).
        return id != null && (anchors.has(id) || cardAnchor(id) === hashTarget) && !item.settled ? (
          <div key={key} id={cardAnchor(id)} className="chat-card-anchor">
            {card}
          </div>
        ) : (
          card
        );
      }
      case "answer": {
        // A linked task's answer follows the chat's own: the turn's Reasoning is drawn once.
        const outline = item.linked ? null : worked.before.get(item.seq);
        const answer = (
          <Component
            key={key}
            item={item}
            ledgerName={ledgerName}
            factsBelow={repeated.has(item.seq)}
            listing={answerReadAList(thread.items, item.seq)}
            analysis={analysisOf(item, thread.items)}
            onOpenResult={onOpenResult}
            onStartTask={onStartTask}
            onAsk={onAsk}
            cardAnchors={openAnchors}
            openable={openable}
            carriedResults={carriedResults}
            // The hidden card's "Open bridge" / "Edit commentary" go on the chip (Delivered.js).
            viewLinks={viewLinks instanceof Map ? viewLinks : null}
            onOpenView={onOpenView}
            disabledReason={disabledReason}
            decisions={item.shape && item.shape.entries ? decisions : null}
            skipEntries={item.shape && item.shape.entries ? notOwnedBy(owners, item.seq, item.shape) : null}
            questionsOpen={questionsOpen}
          />
        );
        return outline ? [<WorkedFor key={`worked-${item.seq}`} outline={outline} replay={replay} ledgerName={ledgerName} period={thread.period || null} onOpenChange={trailToggle(item.seq)} />, answer] : answer;
      }
      default:
        return <Component key={key} item={item} ledgerName={ledgerName} replay={replay} />;
    }
  };

  // THE TURNS. A new one at each message of yours (or task you started); what came
  // before the first is a turn of its own. An inline result is drawn at the foot of the
  // turn its control was pressed in, else the turn that holds the result, else the last.
  const sections = turnSections(fold.current, worked);
  const inlineAt = inline ? inlineSection(sections, inline) : null;

  return (
    <TakeUpAgain.Provider value={takeUp}>
    <div className="chat-thread" role="log" aria-live="polite" aria-relevant="additions">
      {sections.map((section, i) => {
        const last = i === sections.length - 1;
        return (
          <section key={section.key} className="chat-turn" data-turn={section.key} aria-label={section.label || undefined}>
            {section.items.map(draw)}
            {inlineAt === section.key ? <div className="chat-turn-inline">{inline.node}</div> : null}
            {last && pending ? (
              // VERT IS ON IT, SAID UNDER YOUR MESSAGE (verify pass 1, W04): with your
              // message sent and no step reported yet, the turn's identity row and its
              // present-tense line stand in until the first step.
              <WorkedFor key="pending-turn" outline={{ running: true, steps: [], fromAt: pending.at || null, key: section.key, you: pending.kind === "you" ? pending : null, items: [] }} replay={replay} ledgerName={ledgerName} period={thread.period || null} />
            ) : null}
            {last && pending && assistantDown ? (
              <p className="chat-assistant-down t-footnote" role="status" data-assistant-down="">
                {ASSISTANT_DOWN}
              </p>
            ) : null}
          </section>
        );
      })}
      {!sections.length && pending ? (
        <WorkedFor key="pending-turn" outline={{ running: true, steps: [], fromAt: pending.at || null }} replay={replay} ledgerName={ledgerName} />
      ) : null}
    </div>
    </TakeUpAgain.Provider>
  );
}

/**
 * The thread's turns, in order: `[{ key, label, items }]`. A new turn opens at each `you`
 * item (your message, or a task you started); its key is `turn-<seq>`, the same key the
 * turn's outline carries (answer/model.js `workedForTurns`), so a control's turn is
 * found from the document (`data-turn`). Items before the first `you` are a turn keyed
 * by their first item. Pure.
 */
export function turnSections(items, worked = null) {
  const out = [];
  let current = null;
  for (const item of Array.isArray(items) ? items : []) {
    if (!item) continue;
    if (item.kind === "you" || !current) {
      current = { key: `turn-${item.seq}`, label: item.kind === "you" && typeof item.text === "string" ? sectionLabel(item) : null, items: [] };
      out.push(current);
    }
    current.items.push(item);
  }
  // A turn's outline may be keyed by an earlier item than the section saw first (a run
  // whose work came before your message's echo): nothing to reconcile today, the keys
  // agree by construction; `worked` is accepted so a caller can check them.
  void worked;
  return out;
}

function sectionLabel(item) {
  const text = String(item.text || "").split("\n")[0].trim();
  if (!text) return null;
  return text.length > 80 ? `${text.slice(0, 79)}…` : text;
}

/** The section an inline result is drawn in: its control's turn, else the one holding the result, else the last. Pure. */
export function inlineSection(sections, inline) {
  if (!Array.isArray(sections) || !sections.length || !inline) return null;
  if (inline.turn && sections.some((s) => s.key === inline.turn)) return inline.turn;
  if (inline.artifactId) {
    const holds = (i) =>
      (i.kind === "result" && i.artifact && i.artifact.artifactId === inline.artifactId) ||
      (i.kind === "answer" && Array.isArray(i.delivered) && i.delivered.some((d) => d && d.artifactId === inline.artifactId)) ||
      (i.kind === "answer" && i.shape && i.shape.work && i.shape.work.artifactId === inline.artifactId);
    const hit = [...sections].reverse().find((s) => s.items.some(holds));
    if (hit) return hit.key;
  }
  return sections[sections.length - 1].key;
}

/** The owner a decision drawn as its own card is given in `entryOwners`. */
export const CARD_OWNER = "card";

/**
 * Who draws each shaped decision, by action id: an answer's seq, or CARD_OWNER (the
 * thread draws it as its own card). Folded answers first (the latest wins), then what
 * is in view: an answer in view takes the id; an open or posted decision in view that no
 * answer in view carries is its own card. Pure.
 */
export function entryOwners(fold) {
  const owners = new Map();
  const earlier = fold && Array.isArray(fold.earlier) ? fold.earlier : [];
  const current = fold && Array.isArray(fold.current) ? fold.current : [];
  for (const item of earlier) {
    if (item && item.kind === "answer" && item.shape) for (const id of shapeActionIds(item.shape)) owners.set(String(id), item.seq);
  }
  const inView = new Set();
  for (const item of current) {
    if (item && item.kind === "answer" && item.shape) {
      for (const id of shapeActionIds(item.shape)) {
        owners.set(String(id), item.seq);
        inView.add(String(id));
      }
    }
  }
  for (const item of current) {
    const id = item && item.kind === "decision" && item.action && item.action.actionId != null ? String(item.action.actionId) : null;
    if (id && owners.has(id) && !inView.has(id)) owners.set(id, CARD_OWNER);
  }
  return owners;
}

/** The ids an answer's shape carries that another answer, or the thread, draws. Pure. */
export function notOwnedBy(owners, seq, shape) {
  const out = new Set();
  for (const id of shapeActionIds(shape)) if (owners.has(String(id)) && owners.get(String(id)) !== seq) out.add(String(id));
  return out.size ? out : null;
}

/**
 * The decisions an answer's shape draws itself, by action id: each entry's card and the
 * bulk card of every answer carrying `shape.entries`. Pure.
 */
export function drawnByShape(items) {
  const out = new Set();
  for (const item of Array.isArray(items) ? items : []) {
    if (item && item.kind === "answer" && item.shape) for (const id of shapeActionIds(item.shape)) out.add(id);
  }
  return out;
}

/** Every decision in the thread by its action id (the latest copy wins). Pure. */
export function decisionsById(items) {
  const out = new Map();
  for (const item of Array.isArray(items) ? items : []) {
    if (item && item.kind === "decision" && item.action && item.action.actionId != null) out.set(String(item.action.actionId), item);
  }
  return out;
}

/**
 * The results an answer's "What I delivered" list already carries: a live (not
 * replaced) result whose artifact is one of the delivered chips. Drawn as its own card
 * too, the thread said the same file twice — the chip, then a card with its title,
 * verdict, figures, Open and Download Excel — which put five conversations over their
 * word budget and the answer over four blocks (eval S2/AN9, 2 Oct). For these the card
 * is not drawn and the chip gets Open beside it; a result no answer delivered keeps its
 * card, so nothing becomes unreachable. Only a result the thread holds can be opened,
 * which is why Open is offered only for these ids.
 */
export function resultsCarriedByChips(items) {
  const list = Array.isArray(items) ? items : [];
  const results = new Set(
    list.filter((i) => i.kind === "result" && !i.replaced && i.artifact && i.artifact.artifactId != null).map((i) => i.artifact.artifactId),
  );
  const out = new Set();
  for (const item of list) {
    if (item.kind !== "answer" || !Array.isArray(item.delivered)) continue;
    for (const d of item.delivered) if (d && results.has(d.artifactId)) out.add(d.artifactId);
  }
  return out;
}

/**
 * The artifacts the chips carry, by id: what a hidden result card drew that the chip
 * must still draw. The tie-out ("does this agree with the books?") lived only on the
 * result card, so hiding the card hid it (XLS-fix2, eval r2 #7). Latest result wins.
 */
export function carriedArtifacts(items, carried = resultsCarriedByChips(items)) {
  const out = new Map();
  for (const i of Array.isArray(items) ? items : []) {
    if (i.kind === "result" && !i.replaced && i.artifact && carried.has(i.artifact.artifactId)) out.set(i.artifact.artifactId, i.artifact);
  }
  return out;
}

/** The undecided cards' action ids, in thread order. */
// Cards that are always drawn open (W18/OU14): a skill update writes nothing to the
// books and carries no accent, so the one-open rule (one purple per view) does not fold
// it to a row that took two presses to Apply.
export const ALWAYS_OPEN_KINDS = Object.freeze(new Set(["skill_update"]));

export function undecidedIds(items) {
  return (Array.isArray(items) ? items : [])
    .filter((i) => i.kind === "decision" && !i.settled && i.action && i.action.actionId != null && !ALWAYS_OPEN_KINDS.has(i.action.kind))
    .map((i) => i.action.actionId);
}

/**
 * Which undecided card is open: the one you opened while it is still undecided, else
 * the first. Null when nothing waits. Pure, so tests/chat-one-open-card.test.js holds
 * the rule without a browser.
 */
export function activeDecisionId(items, chosen = null, pressedHere = wasPressedHere) {
  const ids = undecidedIds(items);
  if (chosen != null && ids.includes(chosen)) return chosen;
  // The card on screen was settled ELSEWHERE (another tab, another person): it stays the
  // open card, drawn settled with who did it, and nothing else takes its place until the
  // person chooses one (verify pass 1, S-CF-12). Settled by a press here, the next opens.
  // A card VERT set aside (a plan a re-run replaced, `superseded` by vert) is not a
  // person's decision under the pointer: it gives way (verify pass 10, S-E2E-1 F12: the
  // re-run's new plan was drawn closed as a bare "Start this plan?" until a reload).
  if (chosen != null && !pressedHere(chosen) && settledIds(items).includes(chosen)) return chosen;
  return ids.length ? ids[0] : null;
}

/** Whether a settlement is Vert taking a card down for a newer one, not a person's. */
export function setAsideByVert(settled) {
  if (!settled || typeof settled !== "object") return false;
  return settled.outcome === "superseded" || (typeof settled.by === "string" && settled.by.trim().toLowerCase() === "vert");
}

function settledIds(items) {
  return (Array.isArray(items) ? items : [])
    .filter((i) => i && i.kind === "decision" && i.settled && !setAsideByVert(i.settled) && i.action && i.action.actionId != null)
    .map((i) => i.action.actionId);
}

/** The action ids an answer's next action opens (`open_card`). */
export function cardsPointedAt(items) {
  const out = new Set();
  for (const item of Array.isArray(items) ? items : []) {
    const a = item.kind === "answer" && item.next && item.next.action;
    if (a && a.kind === "open_card" && a.actionId != null) out.add(a.actionId);
  }
  return out;
}

/**
 * The answers whose every fact is one of the open decision cards drawn after it, named
 * by the same payout ("Stripe payout · 5 Jul — no deposit found" above the card
 * "Stripe payout · 5 Jul · $6,000.00 / No deposit found"). The list says each thing
 * twice in the first screen a bookkeeper reads, which put Resolve payout breaks over its
 * word budget (eval S2, final round, finding 6). Those facts move behind the answer's
 * "More"; nothing is dropped. The match is on the card's own line (F3's `lineFor`) up
 * to its amount, so a fact about anything the cards do not show stays in the open.
 */
export function factsRepeatedBelow(items) {
  const list = Array.isArray(items) ? items : [];
  const out = new Set();
  list.forEach((item, i) => {
    if (item.kind !== "answer" || !item.facts.length) return;
    const lines = list
      .slice(i + 1)
      .filter((d) => d.kind === "decision" && !d.settled)
      .map((d) => lineFor(d.action))
      .filter((l) => typeof l === "string" && l)
      .map((l) => l.split(" · ").slice(0, -1).join(" · "))
      .filter(Boolean);
    if (!lines.length) return;
    // Both sides as the screen draws them (typeset: "payout on 5 Jul", dates unbroken).
    const drawn = item.facts.map((f) => typeset(f));
    if (drawn.every((f) => lines.some((l) => f.startsWith(`${l} `) || f.startsWith(`${l},`)))) out.add(item.seq);
  });
  return out;
}

/**
 * A settled decision moved to where it was SETTLED (design-fix-2 DA2-056): the card is
 * emitted during the run, but a person posts it later, and the Posted card drawn at the
 * card's first position sat above the answer it followed. Every other item keeps its
 * place (the fold's own order); each settled decision goes before the first item that
 * came after its settlement. Pure.
 */
export function settledInPlace(list) {
  const items = Array.isArray(list) ? list : [];
  const settledAt = (i) => (i && i.kind === "decision" && i.settled && Number.isInteger(i.settled.seq) ? i.settled.seq : null);
  const moving = items.filter((i) => settledAt(i) !== null);
  if (!moving.length) return items;
  const out = items.filter((i) => settledAt(i) === null);
  for (const d of moving) {
    const at = out.findIndex((i) => Number.isInteger(i.seq) && i.seq > settledAt(d));
    if (at < 0) out.push(d);
    else out.splice(at, 0, d);
  }
  return out;
}

/** Said under a waiting turn when the API reports the assistant isn't running (S-CF-5). */
export const ASSISTANT_DOWN = "The assistant isn't running right now. Your message is saved, and Vert will answer it when the assistant is back.";

/**
 * The message a running turn has not started on yet, or null: a turn the thread model
 * says is running (`thread.turn.running`) with no running block of work drawn for it.
 * Pure.
 */
export function pendingTurn(thread, replay = false) {
  if (replay || !thread || !thread.turn || !thread.turn.running) return null;
  const items = Array.isArray(thread.items) ? thread.items : [];
  if (items.some((i) => i && i.kind === "work" && i.state === "running")) return null;
  const lastYou = [...items].reverse().find((i) => i && i.kind === "you");
  return lastYou || { at: null };
}
