"use client";

// components/chat/ArtifactCard.js — ONE DELIVERED FILE, ONE OBJECT
// ==============================================================================
// Design-fix-2 spec §7.1 (DA2-024). Each delivered file was three loose pieces that
// opened three ways: a numbered list of one ("1."), a filename chip with a download
// glyph, a separate "Open", a caption, then an outlined "Review the plan ›", and the
// plan again as a "Plan … · Review" row. It is now one card, 56 px:
//
//   [tile]  Misclassification scan, September 2026            [Open bridge] [↓]
//           Workbook · 4 lines flagged, $9,125.00
//
// a 40 px type tile (the file type's Phosphor glyph on the inset ground), the title at
// body 500, one meta line in caption ink-3 (one middle dot allowed), the WHOLE CARD
// opening the pane, and a trailing download icon button. A card the thread cannot open
// in a pane downloads on its press instead. Nothing on it writes, so nothing on it is
// the accent.

import { InsideControl } from "@/components/ui/Figure";
import { IconArchive, IconBridge, IconCommentary, IconDownload, IconFile, IconJournal, IconPlan, IconWorkbook } from "@/components/ui/icons";

const TYPE_GLYPHS = {
  workbook: IconWorkbook,
  plan: IconPlan,
  bridge: IconBridge,
  commentary: IconCommentary,
  journal: IconJournal,
  // The month's binder is a zip of workbooks, not a workbook (verify pass 3, D35).
  archive: IconArchive,
  // A document Vert made (a split or merged PDF, a laid-out table), D39.
  document: IconFile,
};

/** The file type's word on the meta line. */
export const TYPE_WORDS = Object.freeze({
  workbook: "Workbook",
  plan: "Plan",
  bridge: "Bridge",
  commentary: "Commentary",
  journal: "Journal",
  archive: "Zip",
  document: "File",
});

/**
 * `type` names the tile's glyph and the meta's first word. `onOpen` makes the whole card
 * open (the pane); without it, `href` makes the card a download. `downloadHref` adds the
 * trailing download icon button. `tools` are extra quiet buttons before it ("Open
 * bridge"). `pressProps` go on the card's own press (data hooks).
 */
export default function ArtifactCard({ type = "workbook", typeWord = null, title, meta = null, onOpen = null, href = null, download = null, downloadHref = null, downloadName = null, tools = null, pressProps = {}, className, children }) {
  const Glyph = TYPE_GLYPHS[type] || IconWorkbook;
  // `typeWord` replaces the type's word where two files of one type sit together
  // ("Vert's workbook" beside the one in your format).
  const word = typeWord || TYPE_WORDS[type] || null;
  const body = (
    <>
      <span className="artifact-tile" aria-hidden="true">
        <Glyph size={24} />
      </span>
      <span className="artifact-text">
        <span className="artifact-title" translate="no">
          {title}
        </span>
        {word || meta ? (
          <span className="artifact-meta">
            {word}
            {word && meta ? " · " : null}
            {meta}
          </span>
        ) : null}
      </span>
    </>
  );
  return (
    <div className={["artifact-card", className].filter(Boolean).join(" ")} data-artifact-card={type}>
      {typeof onOpen === "function" ? (
        <button type="button" className="artifact-press" onClick={onOpen} {...pressProps}>
          <InsideControl.Provider value>{body}</InsideControl.Provider>
        </button>
      ) : href ? (
        <a className="artifact-press" href={href} download={download || undefined} {...pressProps}>
          <InsideControl.Provider value>{body}</InsideControl.Provider>
        </a>
      ) : (
        <span className="artifact-press artifact-static">{body}</span>
      )}
      {tools || downloadHref ? (
        <span className="artifact-tools">
          {tools}
          {downloadHref ? (
            <a className="icon-btn artifact-download" href={downloadHref} download={downloadName || undefined} aria-label={`Download ${downloadName || title}`} data-artifact-download="">
              <IconDownload size={16} />
            </a>
          ) : null}
        </span>
      ) : null}
      {children}
    </div>
  );
}

