"use client";

// components/chat/CanDoNow.js — WHEN VERT CAN'T ANSWER, WHAT IT CAN STILL DO
// ==============================================================================
// Spec §10 and §4.2 row 9. One quiet sentence, then every task the engine says runs
// with no model, then a way to write a journal entry by hand. The same sentence in
// every state (off, offline, failing, not set up): which one it is is an operator's
// business, reported by the API and the readiness check, and never shown to a
// bookkeeper. So this component takes no state prop at all, and no provider, key,
// model or setup word can reach it (chat-can-do-now holds that). The one exception is
// a spend limit (build plan §20.12 H2), carried as its own `limit` block, not as a
// state: it ends at a time Vert knows, so it is said, with when it ends.
//
// EVERY RUNNABLE TASK, NOT THREE (eval S10′). The note listed three of the nine built
// tasks, so a bookkeeper asking for the bank, GL or card rec, the comparison or the
// prepaids met a dead end with the task one press away. The list is the engine's
// (EA owns the suggestions source); this draws all of it.
//
// WRITING AN ENTRY NEEDS NO MODEL. "Draft an entry" answered with this note and no way
// to write one. The last line opens a blank journal editor here; Save is
// `POST /journal/drafts`, a draft that waits for a person's approval like any other,
// and nothing posts.

import { useState } from "react";
import Link from "next/link";
import { CAN_DO_NOW, CAN_DO_NOW_AFTER_KEPT, KEPT_MESSAGE, NOT_BACK_YET, SEND_AGAIN, limitSentence } from "@/lib/agent/words";
import { useAssistantBack } from "@/lib/agent/assistant-status";
import { Button } from "@/components/ui/Button";
import JournalEditor from "@/components/cards/JournalEditor";
import "@/components/firm/duties.css";

import { IconArrowRight, IconCaretRight } from "@/components/ui/icons";
export const WRITE_ENTRY = "Write a journal entry yourself";
export const DRAFT_SAVED = "Saved as a draft. Nothing is posted until it is approved on Month-end.";

function Glyph() {
  return (
    <IconArrowRight className="chat-cando-glyph" size={16} />
  );
}

/**
 * The kept message's line and its one Send again (verify pass 4, S-CF-5): the press posts
 * the engine's `resend` once, through the composer's road, and only once the assistant
 * is back (`/agent/status` live). After it is sent, or once a later message carries the
 * same words, the press is gone.
 */
export function KeptMessage({ item, onResend = null, disabledReason = null, initialBack = null }) {
  const waiting = Boolean(item && item.resend && !item.resent && typeof onResend === "function" && !disabledReason);
  const polled = useAssistantBack({ waiting: waiting && initialBack === null });
  const back = initialBack === null ? polled : initialBack;
  const [state, setState] = useState({ busy: false, sent: false, error: null });
  if (!item || !item.resend || item.resent || state.sent) return null;
  async function resend() {
    if (state.busy || state.sent) return;
    setState({ busy: true, sent: false, error: null });
    const result = await onResend(item.resend);
    if (result && result.ok === false) setState({ busy: false, sent: false, error: "It wasn't sent. Your message is still kept here." });
    else setState({ busy: false, sent: true, error: null });
  }
  return (
    <div className="chat-cando-kept" data-kept-message="">
      <p className="chat-cando-limit">{KEPT_MESSAGE}</p>
      {typeof onResend === "function" ? (
        <p>
          <Button
            variant="secondary"
            size="sm"
            busy={state.busy}
            busyLabel="Sending…"
            disabledReason={disabledReason || (back ? null : NOT_BACK_YET)}
            onClick={resend}
            data-resend=""
          >
            {SEND_AGAIN}
          </Button>
        </p>
      ) : null}
      {state.error ? <p className="chat-reason" role="alert">{state.error}</p> : null}
    </div>
  );
}

export default function CanDoNow({ item, onStartTask, onResend = null, disabledReason = null, period = null, sessionId = null }) {
  const suggestions = Array.isArray(item.suggestions) ? item.suggestions : [];
  const [writing, setWriting] = useState(false);
  const [saved, setSaved] = useState(null);
  const off = Boolean(disabledReason);
  // A spend limit (§20.12 H2) is said first, in words, with when it ends: the only
  // reason for silence the bookkeeper can plan around. Every other reason stays unsaid.
  const limit = limitSentence(item.limit);
  return (
    <div className="chat-cando" data-message="assistant_unavailable" data-limit={limit ? item.limit.window : undefined}>
      {limit ? <p className="chat-cando-limit">{limit}</p> : null}
      {/* ONE STATE, ONE SENTENCE (verify pass 5, P15 / S-CF-8): under a spend limit the
          limit sentence is the state; the offline block ("isn't running right now … Send
          again") is the OFFLINE state's and gave a second, contradictory reason beside it,
          with a Send again that could not work until the limit lifted. */}
      {limit ? null : <KeptMessage item={item} onResend={onResend} disabledReason={disabledReason} />}
      {/* With a kept message the line above already says it can't answer: not twice. */}
      <p className="chat-cando-lead">{item.resend && !item.resent && !limit ? CAN_DO_NOW_AFTER_KEPT : CAN_DO_NOW}</p>
      {/* Suggestion lines, icon and phrase, like the reference's new chat: a quiet
          list to pick from, not a row of buttons competing with the composer. */}
      <ul className="chat-cando-tasks">
        {suggestions.map((s) => (
          <li key={s.template}>
            <button
              type="button"
              className="chat-cando-line"
              data-template={s.template}
              disabled={off}
              onClick={off || typeof onStartTask !== "function" ? undefined : () => onStartTask(s.template)}
            >
              <Glyph />
              {s.label}
            </button>
          </li>
        ))}
        <li>
          <button
            type="button"
            className="chat-cando-line"
            data-write-entry=""
            aria-expanded={writing ? "true" : "false"}
            disabled={off}
            onClick={off ? undefined : () => { setWriting((w) => !w); setSaved(null); }}
          >
            <Glyph />
            {WRITE_ENTRY}
          </button>
        </li>
      </ul>
      {writing && !off ? (
        <div className="chat-cando-editor">
          <JournalEditor
            create={{ period, sessionId }}
            onSaved={(result) => { setSaved(result); setWriting(false); }}
            onDone={() => setWriting(false)}
          />
        </div>
      ) : null}
      {saved ? (
        <p className="chat-cando-saved" role="status">
          {DRAFT_SAVED} <Link href="/">Go to Month-end<IconCaretRight className="caret-trailing" /></Link>
        </p>
      ) : null}
      {!suggestions.length ? (
        <p>
          <Link href="/">See what needs you this month<IconCaretRight className="caret-trailing" /></Link>
        </p>
      ) : null}
      {disabledReason ? <p className="chat-reason">{disabledReason}</p> : null}
    </div>
  );
}
