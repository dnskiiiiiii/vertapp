"use client";

// components/chat/Clarification.js — ONE OF VERT'S QUESTIONS: EVIDENCE, GUESS, ANSWER
// ==============================================================================
// Build plan §4.0.10 and §4.6 FQ (teardown standard 14). In order, top to bottom:
//
//   1. THE EVIDENCE. The few lines the question is about (a table of at most five rows)
//      or the one source line it quotes. First, because a person answers a question
//      about lines they can see far better than one about lines they must go and find.
//   2. THE CARD. The question, with "‹ 1 of 3 ›" at its right when several were asked
//      together; one line of why; then the numbered options, option 1 being Vert's
//      best guess, marked so and PRESELECTED with the tick the Month-end card draws
//      (critique r1 #13): it is the row the keyboard starts on and Enter sends it.
//      Preselecting is not answering: nothing is sent until a row is pressed.
//      A money or month form, the chart picker, or the statement upload takes the place
//      of options where the question asks for one of those.
//   3. THE FOOT, the same as the Month-end decision card's (critique r1 #13): the keys
//      that work on the left (↑↓ to move, Enter to choose, Esc to skip), and Skip, a
//      quiet button, on the right. A question the engine will not let you skip
//      (confirm-none questions: allow_skip=False, and the engine refuses the skip) draws
//      no Skip; its reason is the line under the title (verify pass 9, Q13), as on the
//      Month-end question card, so it never offers a press that would be refused.
//
// ANSWERED, it is one grey line: "Which account is Everyday? → 1010 · Everyday", and,
// when the template keeps the answer (§19.0.4), "Saved to the skill · Forget" under
// it (components/skills/SavedLine.js). Asked
// later in a batch and not open, it is one row that opens in place (spec §4.2 row 4).
//
// Answering writes nothing to the books (build plan §2.2): an answer is something Vert
// reads and continues the task from. A typed amount is sent as typed, in dollars; the
// engine reads it, and nothing here converts a figure. An account is one the chart has
// (the options the engine sent), never typed. A statement is imported through the
// import's own two-press gate (questions/FileQuestion.js), and only its id is sent.

import { useEffect, useId, useRef, useState } from "react";
import { BestGuess, Button, DOLLARS_INVALID, DOLLARS_TOO_LARGE, NoticeLine, Pager, dollarsError, guessQualifies } from "@/components/ui";
import BoundText from "./BoundText";
import { showsRegisterChrome } from "@/components/shared/registerChrome";
import Evidence from "./questions/Evidence";
import FileQuestion from "./questions/FileQuestion";
import { PRIOR_QUESTION, answerFileName, answerWords, filterAccounts, isSkippable, laterTarget, skipAndAdvance } from "./questions/model";
import { DECISION_HINTS, DecisionFoot, OptionRow, useDeferredSkip } from "@/components/cards/OptionRows";
import { formatPosition } from "@/lib/format";
import { IconCaretRight, IconFile, IconSearch } from "@/components/ui/icons";

const FORM_LABEL = {
  money: "Amount in dollars",
  month: "Month",
};

/** The one-line failure under a card whose answer did not reach Vert (DA2-074). */
export const NOT_SENT = "Couldn't send: Vert's server didn't answer. Your choice is still here.";
/** Added after a second failure in a row (DA2-074). */
export const NOT_SENT_AGAIN = "Check your connection or try again in a minute.";

// THE MONTH FIELD IS A TEXT BOX IN SAFARI AND FIREFOX. `<input type="month">` draws a
// picker in Chrome and a bare text box elsewhere, where people typed "July" (bug bash
// 10 Oct 2026). So it shows an example of what to type, and what was typed is sent as
// typed: a picker's "2025-10" unchanged, anything else trimmed, for the engine to read
// as a month name.
export const MONTH_PLACEHOLDER = "e.g. October 2025";

/**
 * The month answer to send: a picker's "2025-10" unchanged, anything typed trimmed
 * ("July", "Oct 2025"). Never reshaped here: the engine reads month names, and a guess
 * at the year made in the browser would be a guess nobody can see.
 */
export function monthAnswer(text) {
  if (typeof text !== "string") return "";
  return /^\d{4}-\d{2}$/.test(text) ? text : text.trim();
}

/**
 * THE AMOUNT FIELD SAYS WHAT IS WRONG WHEN YOU LEAVE IT (verify pass 4, U46). The money
 * answer, the statement's closing balance among them, was a bare input: "12.3.4" was sent
 * and the engine's refusal came back as a second question. It is now held to the
 * validation kit's rules (components/ui/fields.js): checked on blur with the kit's own
 * reader of dollars, the message under the field and joined to it, typing clears it,
 * and the typed value is never discarded. Empty is not an error until it is sent.
 */
export const MONEY_INVALID = DOLLARS_INVALID;
export const MONEY_TOO_LARGE = DOLLARS_TOO_LARGE;
export function moneyAnswerError(text) {
  return dollarsError(typeof text === "string" ? text : "");
}

/**
 * CHANGING AN ANSWER (verify pass 9, S-E2E-2 F12). An answered question's line carries a
 * quiet "Change": it re-opens the same card on the answer given, and the new answer goes
 * to the same question through the same road as the first, so the task runs again from
 * it. A typed follow-up was the only way back, and it lost what the card had known.
 */
export const CHANGE_NOTE = "Choose the new answer. Vert runs this task again with it; nothing posts until you approve it.";
export const ANSWER_UNCHANGED = "That's your answer already.";

/** Whether an answered question can be changed here: something can be sent, and the
 *  answer was yours to give (not settled by Vert, not a file). Pure. */
export function canChangeAnswer(item, blocked) {
  if (blocked || !item || !item.answer || item.answer.settledBy) return false;
  if (answerFileName(item)) return false;
  const form = item.form && typeof item.form === "object" ? item.form : null;
  if (form && form.kind === "file") return false;
  return (Array.isArray(item.options) && item.options.length > 0) || Boolean(form) || item.allowOther === true;
}

/** Why the decision can't be skipped: said under the title (spec §7.2), never beside a dead Skip. */
export const SKIP_REFUSED = "Vert needs this answer to go on.";

/** Why "Use this one" waits: nothing is chosen yet. */
export const CHOOSE_ONE = "Choose one first.";

/**
 * WHAT ESC DOES ON A QUESTION (verify pass 2, U45: Esc did nothing on the deferred
 * revenue and prepaid questions, and only the skippable card showed the hint). Every
 * question card answers Esc, and says so in its foot:
 *   skip   — a question that can be skipped is skipped (after the undo toast);
 *   later  — a needed question in a batch moves to the next open one (Answer later);
 *   leave  — a needed question asked alone stays open and focus goes to the composer,
 *            so the person can do something else and come back (Answer later).
 * Pure, so the rule is held without a browser.
 */
export function escapeAction({ skippable = false, later = false } = {}) {
  if (skippable) return "skip";
  return later ? "later" : "leave";
}

/**
 * The foot's key hints for a question: the option keys when it has options, and Esc's
 * ONLY when no button in the foot already does what Esc does. A foot that read
 * "Esc Skip … Skip" or "Esc Answer later … Answer later" said each way out twice (verify
 * pass 4, W04/W07/W11). Where a button does it (Skip, Answer later, No prior schedule)
 * the key rides on that button instead (`EscKey`), and the hint is not drawn; only a
 * needed question asked alone, whose held Skip does nothing, keeps "Esc Answer later".
 */
export function questionHints({ options = 0, skippable = false, later = false } = {}) {
  const act = escapeAction({ skippable, later });
  const keys = options > 0 ? [...DECISION_HINTS] : [];
  if (act === "leave") keys.push({ keys: ["Esc"], label: "Answer later" });
  return keys;
}

/** The Esc key drawn on the foot's button that Esc presses (see questionHints). */
export function EscKey() {
  return (
    <kbd className="kbd dfoot-key-on" aria-hidden="true">
      Esc
    </kbd>
  );
}

/**
 * "Need help finding it" on the prior-schedule question (verify pass 4, W07; the
 * reference's "I'll upload it now / No prior schedule / Need help finding it").
 */
export const PRIOR_HELP =
  "It's the workbook your firm kept for this schedule last month, often in last month's close folder. Without it, Vert uses its own layout and ties the opening balances to the books.";

/** Up to this many options are rows; past it, the guess and the top three plus a search (DA2-026). */
export const ROWS_MAX = 5;
const ROWS_SHORT = 4;

export default function Clarification({
  item,
  open = true,
  onOpen,
  onAnswer,
  pager = null,
  onPage,
  disabledReason = null,
  ledgerName,
  template = null,
  client = null,
  quoteInTrail = false,
}) {
  // The row chosen, by option id; null until the person chooses, when Vert's guess (if it
  // made one) is the chosen row. Choosing never sends (D10).
  const [picked, setPicked] = useState(null);
  const [focusId, setFocusId] = useState(null);
  const [otherPressed, setOther] = useState(false);
  // A memo the engine read from the request (`prefill.text`), offered in the field (D10).
  const [text, setText] = useState(() => (item && item.prefill && typeof item.prefill.text === "string" ? item.prefill.text : ""));
  const [fieldError, setFieldError] = useState(null);
  const [filter, setFilter] = useState("");
  const [showAll, setShowAll] = useState(false);
  const [sending, setSending] = useState(false);
  const [failures, setFailures] = useState(0);
  const [lastSent, setLastSent] = useState(null);
  const [priorHelp, setPriorHelp] = useState(false);
  const [changing, setChanging] = useState(false);
  // Back on the answered line after a cancelled change, focus rests on its Change.
  const lineRef = useRef(null);
  const refocusChange = useRef(false);
  useEffect(() => {
    if (changing || !refocusChange.current) return;
    refocusChange.current = false;
    const press = lineRef.current && lineRef.current.querySelector("[data-answer-change]");
    if (press && typeof press.focus === "function") press.focus();
  }, [changing]);
  const cardRef = useRef(null);
  const titleRef = useRef(null);
  const listRef = useRef(null);
  const fieldId = useId();
  const needsId = useId();
  const filterId = useId();
  const reasonId = useId();
  const evidenceId = useId();
  const titleId = useId();

  const blocked = Boolean(disabledReason) || typeof onAnswer !== "function";
  const send = async (answer) => {
    if (blocked || sending) return null;
    setSending(true);
    setLastSent(answer);
    const result = await onAnswer({ questionId: item.questionId, ...answer });
    setSending(false);
    if (!result || !result.ok) setFailures((n) => n + 1);
    else {
      setFailures(0);
      // A change that was sent folds back to the answered line, focus on its Change; the
      // new answer replaces the old one there when its event arrives.
      if (changing) refocusChange.current = true;
      setChanging(false);
    }
    return result;
  };
  // SKIP IS HELD FIVE SECONDS BEHIND "Skipped. Undo" (spec §7.2), then sent, and the
  // pager moves on once it is recorded (skipAndAdvance).
  const deferred = useDeferredSkip(() => skipAndAdvance(send, pager, onPage));

  const startChange = () => {
    const was = item.answer || {};
    // The words you typed last time, offered again in the field (as a request's memo is).
    const prefillAnswer = was.optionId == null && typeof was.label === "string" ? was.label : "";
    setPicked(was.optionId ?? null);
    setFocusId(null);
    setText(prefillAnswer);
    setOther(Boolean(prefillAnswer) && Array.isArray(item.options) && item.options.length > 0);
    setFieldError(null);
    setFailures(0);
    setChanging(true);
  };
  const cancelChange = () => {
    refocusChange.current = true;
    setChanging(false);
    setPicked(null);
    setText("");
    setOther(false);
  };

  if (item.answer && !changing) {
    const changeable = canChangeAnswer(item, blocked);
    return (
      // Your answer sits on your side, like your own message: the question small above
      // it, the answer in ink (visual spec §4). The arrow stays for a reader of text.
      <div className="chat-you" data-message="clarification" data-answered="" ref={lineRef}>
        <p className="chat-you-bubble chat-question-done">
          <span className="chat-q-done-q">
            <BoundText text={item.title} figures={item.figures} ledgerName={ledgerName} plain />
          </span>{" "}
          <span className="chat-visually-hidden">→ </span>
          {answerFileName(item) ? (
            // THE FILE IT WAS ANSWERED WITH, AS A CHIP (verify pass 5, D04).
            <span className="chat-q-done-a chat-q-done-file" data-answer-file="">
              <IconFile size={14} aria-hidden="true" />
              <span className="chat-visually-hidden">Uploaded </span>
              <span translate="no">{answerFileName(item)}</span>
            </span>
          ) : (
            <span className="chat-q-done-a">{answerWords(item)}</span>
          )}
        </p>
        {changeable ? (
          <button
            type="button"
            className="chat-quiet chat-q-change"
            onClick={startChange}
            data-answer-change=""
          >
            Change
            <span className="chat-visually-hidden">
              {" your answer to: "}
              <BoundText text={item.title} figures={item.figures} ledgerName={ledgerName} plain />
            </span>
          </button>
        ) : null}
      </div>
    );
  }

  if (deferred.pending) {
    // Skipped, and still undoable: one quiet line where the card was, and the toast.
    return (
      <div className="chat-q chat-q-skipped" data-message="clarification" data-skip-pending="">
        <p className="chat-decision-done">Skipped: <BoundText text={item.title} figures={item.figures} ledgerName={ledgerName} plain /></p>
        {deferred.toast}
      </div>
    );
  }

  // A CHANGE IS ALWAYS DRAWN OPEN (p1 e2e, 24 Oct 2026). In the thread an answered
  // question is never the open one (activeQuestionId skips it), so Change drew this
  // closed row: the title alone, no answer, no options, and a press that opened nothing.
  if (!open && !changing) {
    return (
      <button type="button" className="chat-question-row" data-message="clarification" onClick={onOpen}>
        {pager ? <span className="chat-q-row-n">{formatPosition(pager.index, pager.of)}</span> : null}
        <BoundText text={item.title} figures={item.figures} ledgerName={ledgerName} plain /><IconCaretRight className="caret-trailing" />
      </button>
    );
  }

  // A change is not a first answer: nothing to skip or leave for later; Esc and Cancel
  // put the answered line back.
  const skippable = !changing && isSkippable(item);
  const form = item.form && typeof item.form === "object" ? item.form : null;
  const kind = form ? form.kind : null;
  const all = Array.isArray(item.options) ? item.options : [];
  const long = all.length > ROWS_MAX;
  // A long list (a chart of accounts) shows Vert's guess and the next three, a search, and
  // "Other…" for the rest (DA2-026); a search narrows the whole list; ≤ 5 are all rows.
  const searching = (kind === "account" || long) && filter.trim() !== "";
  const options = searching ? filterAccounts(all, filter) : long && !showAll ? all.slice(0, ROWS_SHORT) : all;
  const guessId = all.length && all[0].bestGuess === true ? all[0].id : null;
  // A QUESTION THAT ASKS ONLY FOR WORDS SHOWS ITS FIELD (verify pass 3, D10). "What is
  // the entry for?" has no options and no form; its one way to answer sat behind
  // "Something else…", a press nobody had a reason to make. With nothing to choose from,
  // the field is drawn open and labelled as the answer.
  const freeText = !all.length && !form && item.allowOther === true;
  const other = otherPressed || freeText;
  // TYPING CHOOSES "SOMETHING ELSE" (verify pass 1, D20). With words in the field the
  // commit sent the suggested option and dropped the words: a person typed "none" and
  // northwind's amortisation closed Done on the guess. Words in the field are the
  // answer; no option row reads chosen while they are there.
  const typedOther = (otherPressed && (kind === "money" || kind === "month") && text.trim() !== "") || (other && !form && text.trim() !== "");
  const chosenId = typedOther ? null : picked != null && all.some((o) => o.id === picked) ? picked : guessId;
  const chosen = all.find((o) => o.id === chosenId) || null;

  const commit = () => {
    if (blocked || sending) return;
    if (typedOther) {
      if (kind === "month") send({ value: monthAnswer(text) });
      else if (kind === "money") send({ value: text });
      else send({ text: text.trim() });
      return;
    }
    if (!chosen) return;
    send({ optionId: chosen.id });
  };

  const focusRow = (index) => {
    const rows = listRef.current ? listRef.current.querySelectorAll("[data-option]") : [];
    if (rows[index]) rows[index].focus();
  };

  const onKeyDown = (event) => {
    const inField = event.target && (event.target.tagName === "INPUT" || event.target.tagName === "TEXTAREA");
    // Esc in a change puts the answered line back, focus on its Change (never <body>).
    if (changing && event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      cancelChange();
      return;
    }
    if (event.key === "Escape") {
      event.preventDefault();
      // ESC ON EVERY QUESTION (U45; escapeAction above). A skippable one is skipped; a
      // needed one is left for later: the next open question of its batch, else the
      // composer. Focus never falls to <body> (critic r1 F8).
      const act = escapeAction({ skippable, later });
      if (!blocked && !inField) {
        event.stopPropagation();
        if (act === "skip") {
          deferred.skip();
          return;
        }
        if (act === "later") {
          onPage(laterTarget(pager));
          return;
        }
        const field = typeof document !== "undefined" ? document.querySelector(".chat-composer-field") : null;
        if (field && typeof field.focus === "function") {
          field.focus();
          return;
        }
      }
      if (titleRef.current) titleRef.current.focus();
      return;
    }
    if (inField) {
      if (event.key === "ArrowDown" && options.length && event.target.id === filterId) {
        event.preventDefault();
        focusRow(0);
      }
      return;
    }
    if (!options.length) return;
    const at = Math.max(0, options.findIndex((o) => o.id === (focusId ?? chosenId)));
    let next = null;
    if (event.key === "ArrowDown") next = (at + 1) % options.length;
    else if (event.key === "ArrowUp") next = (at + options.length - 1) % options.length;
    else if (/^[1-9]$/.test(event.key) && Number(event.key) <= options.length) next = Number(event.key) - 1;
    else if (event.key === "Enter" && event.target && event.target.hasAttribute && event.target.hasAttribute("data-option")) {
      event.preventDefault();
      commit();
      return;
    }
    if (next == null) return;
    event.preventDefault();
    setPicked(options[next].id);
    setFocusId(options[next].id);
    focusRow(next);
  };

  // A TYPED ANSWER BESIDE OPTIONS IS "SOMETHING ELSE" (verify pass 4, D20): the
  // amortisation cost question drew an empty "Amount in dollars" with a dead "Use this"
  // beside "Use this one", two answer paths with one of them inert. With options, the
  // field opens only under "Something else…"; with none, it is the answer and is drawn.
  const typedKind = kind === "money" || kind === "month";
  const typed = typedKind && (!all.length || otherPressed);
  const prior = kind === "file" && typeof item.questionId === "string" && item.questionId.split(":")[0] === PRIOR_QUESTION;
  const accountEmpty = kind === "account" && !all.length;
  const tabTarget = options.some((o) => o.id === (focusId ?? chosenId)) ? (focusId ?? chosenId) : options.length ? options[0].id : null;
  const later = !changing && !skippable && laterTarget(pager) != null && typeof onPage === "function";
  const failedLine = failures ? `${NOT_SENT}${failures > 1 ? ` ${NOT_SENT_AGAIN}` : ""}` : null;
  const unchanged = changing && !typedOther && chosen && item.answer && chosen.id === item.answer.optionId;
  const commitReason = disabledReason || (!blocked && options.length && !chosen && !typedOther ? CHOOSE_ONE : unchanged ? ANSWER_UNCHANGED : null);

  return (
    <div className="chat-q" data-message="clarification" data-question={item.questionId} data-changing={changing ? "" : undefined}>
      <Evidence item={item} id={evidenceId} ledgerName={ledgerName} hideQuote={quoteInTrail} />

      <div className="chat-question" ref={cardRef} onKeyDown={onKeyDown} role="group" aria-labelledby={titleId}>
        <div className="dcard-titlebar chat-q-head">
          <p className="chat-question-title" id={titleId} ref={titleRef} tabIndex={-1}>
            <BoundText text={item.title} figures={item.figures} ledgerName={ledgerName} />
          </p>
          {pager ? (
            <Pager
              index={pager.index}
              count={pager.of}
              label="Question"
              onPrev={pager.previousId != null && typeof onPage === "function" ? () => onPage(pager.previousId) : undefined}
              onNext={pager.nextId != null && typeof onPage === "function" ? () => onPage(pager.nextId) : undefined}
            />
          ) : null}
        </div>
        {changing ? (
          <p className="dcard-needs" data-change-note="">
            {CHANGE_NOTE}
          </p>
        ) : !skippable && !later && (options.length || typed || kind === "account") ? (
          <p className="dcard-needs" id={needsId} data-needs-answer="">
            {SKIP_REFUSED}
          </p>
        ) : null}
        {/* Never over nothing (bug bash 10 Oct 2026): a question with no words has no
            guess on screen to check. */}
        {item.basis === "suggested" && guessQualifies(item.title, item.why) ? <BestGuess /> : null}
        {/* Not when the answer above already said it, word for word (U57; lib/agent/
            events.js `markRepeatedWhys`). */}
        {item.why && !item.whySaid ? (
          <p className="chat-question-why">
            <BoundText text={item.why} figures={item.figures} ledgerName={ledgerName} />
          </p>
        ) : null}

        {(kind === "account" && showsRegisterChrome(all.length)) || long ? (
          <div className="chat-q-filter chat-q-search">
            <label className="chat-visually-hidden" htmlFor={filterId}>
              {kind === "account" ? "Search accounts" : "Search the choices"}
            </label>
            <IconSearch className="chat-q-search-glyph" size={14} aria-hidden="true" />
            <input
              id={filterId}
              name="filter"
              className="chat-field chat-q-search-field"
              type="search"
              autoComplete="off"
              placeholder={kind === "account" ? "Search accounts…" : "Search the choices…"}
              value={filter}
              onChange={(event) => {
                setFilter(event.target.value);
                setFocusId(null);
              }}
            />
          </div>
        ) : null}

        {accountEmpty ? (
          <p className="chat-q-empty">There are no accounts to choose from: Vert hasn't read the chart of accounts.</p>
        ) : null}
        {searching && !options.length ? <p className="chat-q-empty">No account matches “{filter.trim()}”.</p> : null}

        {options.length ? (
          <div className={long ? "dcard-scroll" : undefined}>
            <ol className="chat-options" ref={listRef} role="radiogroup" aria-labelledby={titleId} data-picker={kind === "account" ? "account" : undefined}>
              {options.map((option, i) => (
                <li key={option.id} role="none">
                  <OptionRow
                    n={i + 1}
                    value={option.id}
                    label={<BoundText text={option.label} figures={item.figures} ledgerName={ledgerName} plain />}
                    detail={option.detail ? <BoundText text={option.detail} figures={item.figures} ledgerName={ledgerName} plain /> : null}
                    guess={option.id === guessId && !searching}
                    chosen={option.id === chosenId}
                    // A row pressed while words are in "Something else" is the answer.
                    busy={sending && lastSent && lastSent.optionId === option.id}
                    disabled={blocked}
                    tabIndex={option.id === tabTarget ? 0 : -1}
                    onFocus={() => setFocusId(option.id)}
                    onSelect={() => {
                      setPicked(option.id);
                      if (typedOther) setText("");
                    }}
                  />
                </li>
              ))}
              {long && !showAll && !searching ? (
                <li role="none">
                  <button type="button" className="chat-option chat-option-other" data-option-other="" tabIndex={-1} onClick={() => setShowAll(true)}>
                    <span className="chat-option-mark" aria-hidden="true">
                      <IconCaretRight size={16} />
                    </span>
                    <span className="chat-option-label">Other… ({all.length - ROWS_SHORT} more)</span>
                  </button>
                </li>
              ) : null}
            </ol>
          </div>
        ) : null}

        {kind === "file" ? <FileQuestion item={item} blocked={blocked} onAnswer={send} inConversation /> : null}
        {prior && priorHelp ? (
          <p className="chat-question-why" data-prior-help="">
            {PRIOR_HELP}
          </p>
        ) : null}

        {typed || (other && !form) ? (
          <form
            className="chat-answer-form"
            onSubmit={(event) => {
              event.preventDefault();
              if (kind === "money" && moneyAnswerError(text)) {
                setFieldError(moneyAnswerError(text));
                return;
              }
              if (kind === "month") send({ value: monthAnswer(text) });
              else if (typed) send({ value: text });
              else send({ text });
            }}
          >
            <label className="chat-field-label" htmlFor={fieldId}>
              {typed ? FORM_LABEL[kind] : freeText ? "Your answer" : "Something else"}
            </label>
            <input
              id={fieldId}
              name="answer"
              autoComplete="off"
              className="chat-field"
              type={kind === "month" ? "month" : "text"}
              placeholder={kind === "month" ? MONTH_PLACEHOLDER : undefined}
              inputMode={kind === "money" ? "decimal" : undefined}
              value={text}
              disabled={blocked}
              aria-invalid={kind === "money" && fieldError ? "true" : undefined}
              aria-describedby={[blocked ? reasonId : null, kind === "money" && fieldError ? `${fieldId}-error` : null].filter(Boolean).join(" ") || undefined}
              onBlur={kind === "money" ? (event) => setFieldError(moneyAnswerError(event.target.value)) : undefined}
              onChange={(event) => {
                setText(event.target.value);
                if (fieldError) setFieldError(null);
              }}
            />
            <Button type="submit" variant={options.length ? "secondary" : "commit"} disabled={blocked || !text.trim()}>
              {sending ? "Sending…" : "Use this"}
            </Button>
            {kind === "money" && fieldError ? (
              <p className="field-error chat-field-error" id={`${fieldId}-error`} role="alert">
                {fieldError}
              </p>
            ) : null}
          </form>
        ) : null}

        {/* THE FOOT (spec §7.2): key hints while the card has focus; then the quiet ways
            out; then the one commit, trailing. Esc is named in the hints (U45). */}
        {changing || options.length || skippable || later || typed || (item.allowOther && !form && !other) || (typedKind && all.length && !otherPressed) ? (
          <DecisionFoot
            hints={changing ? (options.length ? DECISION_HINTS : []) : questionHints({ options: options.length, skippable, later })}
            commit={
              options.length ? (
                <Button variant="commit" busy={sending} busyLabel="Sending…" disabledReason={commitReason || undefined} onClick={commit} data-commit="">
                  Use this one
                </Button>
              ) : null
            }
          >
            {(item.allowOther && !form && !other) || (typedKind && all.length && !otherPressed) ? (
              <Button variant="quiet" disabled={blocked} onClick={() => setOther(true)} data-something-else="">
                Something else…
              </Button>
            ) : null}
            {prior ? (
              <Button variant="quiet" aria-expanded={priorHelp ? "true" : "false"} onClick={() => setPriorHelp((v) => !v)} data-prior-help-press="">
                Need help finding it
              </Button>
            ) : null}
            {changing ? (
              <Button variant="quiet" onClick={cancelChange} aria-keyshortcuts="Escape" trailingIcon={<EscKey />} data-change-cancel="">
                Cancel
              </Button>
            ) : null}
            {skippable ? (
              <Button variant="quiet" data-skip="" disabled={blocked} onClick={deferred.skip} aria-keyshortcuts="Escape" trailingIcon={<EscKey />}>
                {prior ? "No prior schedule" : "Skip"}
              </Button>
            ) : later ? (
              // A batch's needed question can be left for later (W11): it moves to the
              // next one and sends nothing; this one stays open, and the run waits on it.
              <Button variant="quiet" data-answer-later="" disabled={blocked} onClick={() => onPage(laterTarget(pager))} aria-keyshortcuts="Escape" trailingIcon={<EscKey />}>
                Answer later
              </Button>
            ) : null
            // A decision Vert cannot go on without draws no Skip (verify pass 9, Q13): a
            // greyed Skip at the foot read as a broken control far from its reason. The
            // reason is the line under the title ("Vert needs this answer to go on."), and
            // the Month-end question card (ChooseDepositQuestion) already leaves it out.
            }
          </DecisionFoot>
        ) : null}
        <div className="dcard-notice-slot">
          {failedLine ? (
            <NoticeLine tone="problem" actionLabel="Try again" onAction={() => lastSent && send(lastSent)} actionBusy={sending} actionBusyLabel="Sending…">
              {failedLine}
            </NoticeLine>
          ) : null}
        </div>
        {disabledReason && !options.length ? (
          <p className="chat-reason" id={reasonId}>
            {disabledReason}
          </p>
        ) : null}
      </div>
    </div>
  );
}
