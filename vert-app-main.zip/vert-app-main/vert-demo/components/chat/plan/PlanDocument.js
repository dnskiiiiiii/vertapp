"use client";

// components/chat/plan/PlanDocument.js — THE PLAN, READ AS A DOCUMENT
// ==============================================================================
// Build plan §19.0.6, §19.7 F-PLAN; the reference product's plan view (the UI teardown,
// "Created plan · Review"). Opened from the thread's plan line into the result pane, or
// into a sheet on Month-end, where there is no pane. It is a document on the type
// scale, with no card chrome:
//
//   Updated plan                                               ← only once re-emitted
//   What changed   Capitalisation threshold  $2,500.00 → $5,000.00   (a re-emitted plan)
//   Scope          Month · Accounts · each setting as a phrase you can change in place
//   Current state  the engine's table (at most five rows)
//   Findings from the GL cross-reference
//                  the findings, then each search: found N / found none / couldn't look
//   Triggers       Starting: Ask me before starting (a phrase, switchable in place)
//                  Scheduled: Starts on its own on 1 Nov 2026 at 9:00 (Sydney time) · Cancel
//                  + Add trigger   — or "Scheduling isn't available here", no control
//   Execution steps  1. … 2. Draft the entry (waits for your approval)
//                    Dr 1500 Plant & equipment      $3,250.00
//                       Cr 6400 Office expenses     $3,250.00
//   Outputs
//   Ask me before starting. Pause if a difference is over $500.00.   ← the checkpoint
//   ─────────────────────────────────────────────────────────────
//   Save changes (only after an edit) · Reject · Schedule · [■ Start now]
//
// THE FOOTER ORDER IS PINNED (iteration 4, §20.0 decision 11; tests/plan-footer.test.js):
// Save changes · Reject · Schedule · Start now, the reference's plan footer. Schedule is
// drawn only where the engine says a start could be fired (`triggers.schedulingAvailable`)
// and opens the Schedule sheet anchored under it, as Reject opens its notes.
//
// ONE ACCENT: Start now. Save changes and Reject are quiet; Schedule is secondary, so the
// popover it opens has an anchor you can see (design-pass spec §6.14). Reject opens its notes
// anchored under it, and cannot be sent empty: notes are what Vert redoes the plan from
// (`plan_notes`), and notes that map to nothing come back as a question, never a guess.
//
// THE PLAN NEVER CLAIMS ITS OWN CHANGE. After Save changes or Reject the engine
// re-emits the plan with its diff on the conversation's stream; until then this says
// what was sent, not what changed. Start now starts drafting; nothing posts from here.
//
// NO FIGURE HERE IS COMPUTED: findings bind `{{fig:…}}` from the plan's own figures,
// table cells are written by the pane's one cell formatter, a setting's money is cents.

import "./plan.css";
import { useEffect, useMemo, useRef, useState } from "react";
import { Button, Notice } from "@/components/ui";
import { IconArrowRight, IconMore } from "@/components/ui/icons";
import BoundText from "@/components/chat/BoundText";
import { cellText } from "@/components/chat/results/TableView";
import { SAMPLE_REASON } from "@/components/cards/words";
import { useWritesEnabled } from "@/lib/engine-context";
import {
  PLAN_SECTIONS,
  REJECT_NEEDS_NOTES,
  crossCheckView,
  diffRows,
  editedSettings,
  findingTable,
  planIdOf,
  planLine,
  planOf,
  planTitle,
  rejectGate,
  scopeRows,
  scopeSentence,
  stepLines,
  withKinds,
} from "@/lib/agent/plan";
import { decidePlan } from "@/lib/agent/plan-actions";
import { readPlanSkill } from "./plan-skill";
import { DISPLAY_TIME_ZONE } from "@/lib/format";
import PlanPhrase from "./PlanPhrase";
import useUnsavedWarning from "@/components/chat/results/useUnsavedWarning";
import { ScheduleSheet, TriggersSection } from "./TriggersSection";
import { Sheet } from "@/components/ui";
import usePhone from "./usePhone";
import { useMoreToTheRight } from "@/components/chat/results/useMoreToTheRight";
import { START_MODE_KEY, checkpointRest, editsToSend, footerButtons, scheduleReadBack, triggersOf, withReadBack } from "./triggers-model";
import { cancelPlanStart, schedulePlanStart } from "./schedule-actions";

const NUMERIC = new Set(["money", "percent", "count"]);
/** Columns of words; one whose cells run past PROSE_AT characters is a column of sentences. */
const TEXT_KINDS = new Set(["text", "account"]);
const PROSE_AT = 48;

const DONE_WORDS = Object.freeze({
  // Not "drafting now" (verify pass 3, D10/D13): a plan whose guard drafts nothing said
  // it was drafting entries. What is true of every plan: it runs, and nothing posts.
  approve: "Started. Vert is working through the plan now; anything it drafts waits for your approval, and nothing posts until then.",
  reject: "Sent back with your notes. Vert will redo the plan and show what changed.",
  edit: "Changes sent. Vert will update the plan and show what changed.",
  schedule: "Schedule sent. Vert will show the start under Triggers once it is recorded; it drafts then, and nothing posts until you approve.",
  cancel: "Cancel sent. Vert will show the plan without its scheduled start once it is recorded.",
  // The engine read the stored row back in its answer, so Triggers already shows it.
  scheduled: "Scheduled. Vert starts this plan on its own at the time under Triggers; it drafts then, and nothing posts until you approve.",
  cancelled: "Scheduled start cancelled. The plan stays open; nothing starts until you start it.",
});

/** The presses that leave the plan open (a schedule is not a decision on the plan). */
const OPEN_PRESSES = new Set(["schedule", "cancel", "scheduled", "cancelled"]);

/** Why Schedule can't be pressed where the plan's conversation isn't known. */
const NEEDS_CONVERSATION = "Open this plan from its conversation to schedule it.";

/** The conversation this document is in, from the address bar (/chat/{id}), or null. */
function sessionFromLocation() {
  if (typeof window === "undefined" || !window.location) return null;
  const m = /^\/chat\/([^/?#]+)/.exec(window.location.pathname || "");
  return m ? decodeURIComponent(m[1]) : null;
}

/**
 * `declared` is the template's settings (kind and options), when the caller has them;
 * otherwise they are read from the task's skill once. `decide` is the press road
 * (lib/agent/plan-actions.js decidePlan), replaceable in tests. `revalidate` is true
 * where there is no stream to bring the re-emitted plan back (Month-end).
 */
export default function PlanDocument({
  action,
  onDone = null,
  declared = null,
  decide = decidePlan,
  revalidate = false,
  ledgerName = null,
  initial = null,
  sessionId = null,
  schedule = schedulePlanStart,
  cancelSchedule = cancelPlanStart,
  now = null,
}) {
  // `initial` seeds the document's own state ({edits, rejecting, notes}) — the same seam
  // the cards' `initial` is: a server render cannot press, so tests/plan.test.js draws
  // "after an edit" and "Reject open" through it.
  const seed = initial && typeof initial === "object" ? initial : {};
  const plan = planOf(action);
  const writesEnabled = useWritesEnabled();
  const [kinds, setKinds] = useState(() => (Array.isArray(declared) ? declared : null));
  const [edits, setEdits] = useState(() => (seed.edits && typeof seed.edits === "object" ? seed.edits : {}));
  const [rejecting, setRejecting] = useState(seed.rejecting === true);
  const [notes, setNotes] = useState(typeof seed.notes === "string" ? seed.notes : "");
  // Which anchored sheet is open: "footer" (under Schedule), "trigger" (under "+ Add
  // trigger") or null. Only one of it and Reject's notes is open at once.
  const docRef = useRef(null);
  const [scheduling, setScheduling] = useState(seed.scheduling === "footer" || seed.scheduling === "trigger" ? seed.scheduling : null);
  const phone = usePhone();
  const [where, setWhere] = useState(() => sessionId || (action && action.sessionId) || null);
  const [busy, setBusy] = useState(null);
  const [failure, setFailure] = useState(null);
  const [done, setDone] = useState(null);
  // The last schedule press's read-back, for the plan it was pressed on:
  // `{planId, schedule}` where `schedule` is the stored row, or null once cancelled.
  // Triggers draws from it at once (triggers-model.js `scheduleReadBack`); `initial.
  // readBack` seeds it so a server render can draw "after Schedule start".
  const [readBack, setReadBack] = useState(() => (seed.readBack !== undefined ? { planId: planIdOf(action), schedule: seed.readBack } : null));
  const notesRef = useRef(null);

  const template = plan && plan.scope && plan.scope.skill && plan.scope.skill.template;
  useEffect(() => {
    if (Array.isArray(declared) || !template || !writesEnabled) return undefined;
    let live = true;
    // A GET, once per template however often this mounts (staging D1: four POSTs on
    // one open, through the getSkill server action; ./plan-skill.js says why).
    Promise.resolve(readPlanSkill(template))
      .then((answer) => {
        if (live && answer && answer.ok && answer.skill && Array.isArray(answer.skill.settings)) setKinds(answer.skill.settings);
      })
      .catch(() => {});
    return () => {
      live = false;
    };
  }, [declared, template, writesEnabled]);

  useEffect(() => {
    if (where) return;
    const found = sessionFromLocation();
    if (found) setWhere(found);
  }, [where]);

  useEffect(() => {
    if (rejecting && notesRef.current && typeof notesRef.current.focus === "function") notesRef.current.focus();
  }, [rejecting]);

  const settings = useMemo(() => withKinds(plan && plan.settings, kinds), [plan, kinds]);
  // A changed setting or typed notes, not yet sent: leaving the page asks first (WIG).
  useUnsavedWarning(Boolean(plan) && !(action && action.settled) && done === null && (Object.keys(edits).length > 0 || (rejecting && notes.trim() !== "")));
  if (!plan) return <p className="chat-sheet-note">Vert can't show this plan here.</p>;

  // The start mode is drawn under Triggers, never twice: a plan that also lists it among
  // its settings shows it there only.
  const shown = editedSettings(settings, edits).filter((s) => s.key !== START_MODE_KEY);
  const planId = planIdOf(action);
  const triggers = withReadBack(triggersOf(plan), readBack && readBack.planId === planId ? readBack.schedule : undefined);
  const startMode = Object.hasOwn(edits, START_MODE_KEY) ? edits[START_MODE_KEY] : triggers.startMode;
  const changed = editsToSend(settings, edits, triggers);
  // The start mode is changeable in place only once the task's skill declares it (the
  // engine's `start_mode` setting): an edit the engine would refuse is never offered, as
  // no other setting of an undeclared kind is (tests/plan.test.js).
  const startModeDeclared = Array.isArray(kinds) && kinds.some((k) => k && k.key === START_MODE_KEY);
  const edited = Object.keys(changed).length > 0;
  const settled = Boolean(action && action.settled) || (done !== null && !OPEN_PRESSES.has(done));
  // Whether anything in the plan can be changed here: a setting the engine marks
  // editable and the skill declares, or the start mode under Triggers.
  const editable = settings.some((s) => s && s.editable && s.key !== START_MODE_KEY) || startModeDeclared;
  const footer = footerButtons({ edited, decided: settled, schedulingAvailable: triggers.schedulingAvailable, editable });
  const actionId = action && action.actionId;
  const disabledReason = writesEnabled ? null : SAMPLE_REASON;

  async function press(decision) {
    if (busy) return;
    setFailure(null);
    setBusy(decision);
    const opts = { planId, revalidate };
    if (decision === "reject") opts.notes = notes;
    if (decision === "edit") opts.settings = changed;
    let answer;
    try {
      answer = await decide(actionId, decision, opts);
    } catch {
      answer = null;
    }
    setBusy(null);
    if (answer && answer.ok) {
      setDone(decision);
      setRejecting(false);
      return;
    }
    setFailure((answer && answer.message) || "Nothing was changed.");
  }

  // The Schedule sheet's send: the time, as an instant with its offset, against this
  // plan's action. Resolves the outcome so the sheet can say a refusal beside itself.
  async function sendSchedule(fireAt, tz) {
    if (busy) return { ok: false, message: "Vert is still sending your last press." };
    setFailure(null);
    setBusy("schedule");
    let answer;
    try {
      answer = await schedule(where, { planActionId: actionId, fireAt, tz });
    } catch {
      answer = null;
    }
    setBusy(null);
    if (answer && answer.ok) {
      const stored = scheduleReadBack(answer.result);
      if (stored !== undefined) setReadBack({ planId, schedule: stored });
      setDone(stored ? "scheduled" : "schedule");
      setScheduling(null);
      return { ok: true };
    }
    return { ok: false, message: (answer && answer.message) || "Not scheduled. Nothing was changed." };
  }

  async function sendCancel() {
    if (busy) return;
    setFailure(null);
    setBusy("cancel");
    let answer;
    try {
      answer = await cancelSchedule(where);
    } catch {
      answer = null;
    }
    setBusy(null);
    if (answer && answer.ok) {
      const gone = scheduleReadBack(answer.result);
      if (gone === null) setReadBack({ planId, schedule: null });
      setDone(gone === null ? "cancelled" : "cancel");
      return;
    }
    setFailure((answer && answer.message) || "Not cancelled. The start is still scheduled.");
  }

  const zone = (triggers.schedule && triggers.schedule.tz) || DISPLAY_TIME_ZONE;
  const scheduleReason = disabledReason || (where ? null : NEEDS_CONVERSATION);
  const scheduleSheet = (inSheet = false) => (
    <ScheduleSheet
      period={plan.scope && plan.scope.period}
      tz={zone}
      now={now}
      initial={seed.scheduleDraft || null}
      busy={busy === "schedule"}
      onSchedule={sendSchedule}
      onClose={() => {
        // Focus goes back to the control that opened the popover (U36), never to
        // whatever opened the pane.
        const anchor = scheduling;
        setScheduling(null);
        const press = anchor === "trigger" ? "add-trigger" : "schedule";
        const el = docRef.current && docRef.current.querySelector(`[data-plan-press="${press}"]`);
        if (el && typeof el.focus === "function") el.focus();
      }}
      inSheet={inSheet}
    />
  );
  // On a desk Schedule opens a popover anchored to its button; on a phone the footer's
  // Schedule opens a bottom sheet instead (spec §6.15; critique r1 #4: the popover hung
  // off the left edge of a 390 px screen). The sheet is drawn once, outside the footer,
  // and kept mounted so it can leave the way it came.
  const sheetFor = (anchor) => (scheduling === anchor && !(phone && anchor === "footer") ? scheduleSheet(false) : null);
  const openSheet = (anchor) => {
    setRejecting(false);
    setScheduling((s) => (s === anchor ? null : anchor));
  };

  // Reject's notes, anchored under Reject… on a desk and above Start now on a phone.
  const rejectNotes = (
    <span className="plan-reject-notes" role="group" aria-label="What should change">
      <label className="t-footnote" htmlFor={`plan-notes-${planId || "x"}`}>
        What should change?
      </label>
      <textarea
        id={`plan-notes-${planId || "x"}`}
        name="plan-notes"
        autoComplete="off"
        ref={notesRef}
        className="field-input plan-notes"
        rows={3}
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
      />
      <span className="plan-reject-actions">
        <button type="button" className="chat-quiet" onClick={() => setRejecting(false)}>
          Cancel
        </button>
        <Button variant="secondary" size="sm" onClick={() => press("reject")} busy={busy === "reject"} disabledReason={rejectGate(notes) ? REJECT_NEEDS_NOTES : null} data-plan-press="reject-send">
          Send back
        </Button>
      </span>
    </span>
  );

  const rows = diffRows(plan, settings);
  const current = plan.currentState && Array.isArray(plan.currentState.columns) && Array.isArray(plan.currentState.rows) ? plan.currentState : null;
  const findings = Array.isArray(plan.findings) ? plan.findings.filter((f) => f && typeof f.words === "string" && f.words.trim()) : [];
  const checks = Array.isArray(plan.crossChecks) ? plan.crossChecks.map(crossCheckView) : [];
  const steps = Array.isArray(plan.steps) ? plan.steps.filter((s) => s && s.label) : [];
  const outputs = Array.isArray(plan.outputs) ? plan.outputs.filter((o) => o && o.label) : [];
  const title = (key) => PLAN_SECTIONS.find((s) => s.key === key).title;

  return (
    <article ref={docRef} className="plan-doc" data-plan={planId || ""} data-plan-state={settled ? "decided" : "open"}>
      {plan.supersedes ? <p className="plan-kicker t-footnote">{planLine(plan)}</p> : null}
      <h2 className="plan-title t-title-2" data-plan-title="">{planTitle(plan, action && action.taskTitle)}</h2>

      {rows.length ? (
        <section className="plan-section plan-diff" data-plan-diff="" aria-label="What changed">
          <h3 className="plan-h t-title-3">What changed</h3>
          <ul className="plan-diff-list">
            {rows.map((r) => (
              <li key={r.field} className="plan-diff-row">
                <span className="plan-diff-label">{r.label}</span>{" "}
                {r.before ? <del className="diff-del">{r.before}</del> : null}
                {r.before && r.after ? <span aria-hidden="true"> → </span> : null}
                {r.after ? <ins className="diff-ins">{r.after}</ins> : <span className="plan-muted">removed</span>}
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      <section className="plan-section" data-plan-section="scope">
        <h3 className="plan-h t-title-3">{title("scope")}</h3>
        {scopeSentence(plan) ? (
          <p className="plan-scope-lede t-body" data-plan-scope-sentence="">
            {scopeSentence(plan)}
          </p>
        ) : null}
        <dl className="plan-scope">
          {/* The month is in the sentence above; the rows hold what it doesn't. */}
          {scopeRows(plan).filter((r) => !(scopeSentence(plan) && r.label === "Month")).map((r) => (
            <div key={r.label} className="plan-scope-row">
              <dt>{r.label}</dt>
              <dd>{r.value}</dd>
            </div>
          ))}
          {shown.map((s) => (
            <div key={s.key} className="plan-scope-row" data-plan-setting={s.key}>
              <dt>{s.label}</dt>
              <dd>
                <PlanPhrase setting={s} changed={Object.prototype.hasOwnProperty.call(changed, s.key)} onSet={settled ? null : (key, value) => setEdits((e) => ({ ...e, [key]: value }))} />
              </dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="plan-section" data-plan-section="current">
        <h3 className="plan-h t-title-3">{title("current")}</h3>
        {current ? (
          // A wide current state scrolls inside its own box, never the document: at a
          // 390px phone the pane is the screen (PR7; tests/mobile-overflow.test.js).
          <PlanTable table={current} kind="current" />
        ) : (
          <p className="plan-muted">Vert didn't read the current state for this plan.</p>
        )}
      </section>

      <section className="plan-section" data-plan-section="findings">
        <h3 className="plan-h t-title-3">{title("findings")}</h3>
        {findings.length ? (
          <ul className="plan-list">
            {findings.map((f, i) => (
              <li key={i} data-plan-finding="">
                <BoundText text={f.words} figures={plan.figures || {}} ledgerName={ledgerName} />
                {findingTable(f) ? <PlanTable table={findingTable(f)} kind="finding" /> : null}
              </li>
            ))}
          </ul>
        ) : null}
        {checks.length ? (
          <ul className="plan-checks" aria-label="What Vert looked for">
            {checks.map((c, i) => (
              <li key={i} className="plan-prov" data-plan-check={c.measured ? "measured" : "unmeasured"}>
                {c.text}
                {c.found.length ? (
                  <ul className="plan-found">
                    {c.found.map((f, j) => (
                      <li key={j}>{f}</li>
                    ))}
                  </ul>
                ) : null}
              </li>
            ))}
          </ul>
        ) : null}
        {!findings.length && !checks.length ? <p className="plan-muted">Vert didn't cross-check anything for this plan.</p> : null}
      </section>

      <TriggersSection
        triggers={triggers}
        startMode={startMode}
        changed={startMode !== triggers.startMode}
        onStartMode={settled || !startModeDeclared ? null : (key, value) => setEdits((e) => ({ ...e, [key]: value }))}
        onAddTrigger={settled ? null : () => openSheet("trigger")}
        onCancel={settled || done === "cancel" || done === "cancelled" ? null : sendCancel}
        cancelBusy={busy === "cancel"}
        sheet={sheetFor("trigger")}
        disabledReason={scheduleReason}
      />

      <section className="plan-section" data-plan-section="steps">
        <h3 className="plan-h t-title-3">{title("steps")}</h3>
        <ol className="plan-steps">
          {steps.map((s, i) => (
            <li key={i} data-plan-step={s.je ? "entry" : "step"}>
              {s.label}
              {s.je ? <span className="plan-muted"> · waits for your approval</span> : null}
              <StepLines step={s} figures={plan.figures || {}} />
            </li>
          ))}
        </ol>
      </section>

      <section className="plan-section" data-plan-section="outputs">
        <h3 className="plan-h t-title-3">{title("outputs")}</h3>
        {outputs.length ? (
          <ul className="plan-list">
            {outputs.map((o, i) => (
              <li key={i}>{o.label}</li>
            ))}
          </ul>
        ) : (
          <p className="plan-muted">Nothing is produced beyond the steps above.</p>
        )}
      </section>

      {checkpointRest(plan) ? <p className="skill-checkpoint plan-checkpoint">{checkpointRest(plan)}</p> : null}

      {done ? (
        <Notice kind="completion">{DONE_WORDS[done]}</Notice>
      ) : null}
      {failure ? (
        <Notice kind="error" recorded="nothing">
          {failure}
        </Notice>
      ) : null}

      {footer.length ? (
        // DA2-051: one full-width glass foot. Save changes (only once something changed)
        // and Reject… (quiet) at the left; Schedule… (secondary) and Start
        // now (the one commit) at the right. On a phone: Start now, and the rest behind
        // a More button. The DOM keeps the pinned order (tests/plan-footer.test.js).
        <div className="plan-foot" data-plan-footer="" data-phone={phone ? "true" : undefined}>
          {phone ? (
            <PhoneFoot
              footer={footer}
              onSave={() => press("edit")}
              onReject={() => {
                setScheduling(null);
                setRejecting(true);
              }}
              onSchedule={() => openSheet("footer")}
              disabledReason={disabledReason}
              scheduleReason={scheduleReason}
            />
          ) : null}
          {footer.map((b) => {
            // A phone keeps Schedule… in the bar beside Start now (verify pass 4, U29: a
            // scheduled start took 4 presses at 390 with Schedule behind More); Save
            // changes and Reject… sit behind More.
            if (phone && !PHONE_BAR.has(b.id)) return null;
            if (b.id === "reject") {
              return (
                <span key="reject" className="plan-reject-anchor">
                  {/* Quiet, in ink, not the problem red (verify pass 3, Q12): rejecting a
                      plan sends it back to be redone and loses nothing, so it is not drawn
                      as a destructive press beside the one commit. */}
                  <Button
                    variant="quiet"
                    aria-expanded={rejecting ? "true" : "false"}
                    onClick={() => {
                      setScheduling(null);
                      setRejecting((r) => !r);
                    }}
                    disabledReason={disabledReason}
                    data-plan-press="reject"
                  >
                    {b.label}
                  </Button>
                  {rejecting ? rejectNotes : null}
                </span>
              );
            }
            if (b.id === "schedule") {
              return (
                <span key="schedule" className="plan-reject-anchor plan-schedule-anchor">
                  <Button variant={b.variant} aria-expanded={scheduling === "footer" ? "true" : "false"} onClick={() => openSheet("footer")} disabledReason={scheduleReason} data-plan-press="schedule">
                    {b.label}
                  </Button>
                  {sheetFor("footer")}
                </span>
              );
            }
            return (
              <Button
                key={b.id}
                variant={b.variant}
                onClick={() => press(b.id === "save" ? "edit" : "approve")}
                busy={busy === (b.id === "save" ? "edit" : "approve")}
                disabledReason={disabledReason || b.disabledReason || null}
                title={!disabledReason && b.disabledReason ? b.disabledReason : undefined}
                data-plan-press={b.id}
              >
                {b.label}
              </Button>
            );
          })}
          {phone && rejecting ? <span className="plan-reject-anchor plan-reject-phone">{rejectNotes}</span> : null}
        </div>
      ) : done && typeof onDone === "function" ? (
        <div className="plan-foot">
          <Button variant="secondary" onClick={onDone}>
            Done
          </Button>
        </div>
      ) : null}
      {phone ? (
        <Sheet open={scheduling === "footer"} side="bottom" title="Schedule the start" onClose={() => setScheduling(null)} className="plan-schedule-bottom">
          {scheduleSheet(true)}
        </Sheet>
      ) : null}
    </article>
  );
}

/** On a phone these presses stay in the bar; the rest go behind More (U29, pass 4). */
export const PHONE_BAR = new Set(["schedule", "start"]);
/** The presses a phone's More menu holds. */
export const phoneMore = (footer) => (Array.isArray(footer) ? footer : []).filter((b) => !PHONE_BAR.has(b.id));

/**
 * The phone's foot (DA2-051): Start now is the bar; the other presses (Save changes once
 * something changed, Reject…, Schedule…) sit behind one More button, in a menu that
 * opens upward from it and closes on Esc, on a pick, or when focus leaves it.
 */
function PhoneFoot({ footer, onSave, onReject, onSchedule, disabledReason = null, scheduleReason = null }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const buttonRef = useRef(null);
  const items = phoneMore(footer);
  useEffect(() => {
    if (!open || !menuRef.current) return;
    const first = menuRef.current.querySelector("button:not([aria-disabled='true'])");
    if (first) first.focus();
  }, [open]);
  if (!items.length) return null;
  const close = (refocus = true) => {
    setOpen(false);
    if (refocus && buttonRef.current) buttonRef.current.focus();
  };
  const run = { save: onSave, reject: onReject, schedule: onSchedule };
  const reason = (b) => (b.id === "schedule" ? scheduleReason : disabledReason) || b.disabledReason || null;
  return (
    <span
      className="plan-more-anchor"
      onKeyDown={(e) => {
        if (e.key === "Escape" && open) {
          e.stopPropagation();
          close();
        }
      }}
      onBlur={(e) => {
        if (open && !e.currentTarget.contains(e.relatedTarget)) setOpen(false);
      }}
    >
      <button ref={buttonRef} type="button" className="icon-btn plan-more" aria-label="More actions" aria-haspopup="menu" aria-expanded={open ? "true" : "false"} onClick={() => setOpen((v) => !v)} data-plan-press="more">
        <IconMore size={20} aria-hidden="true" />
      </button>
      {open ? (
        <span ref={menuRef} className="popover plan-more-menu" role="menu" aria-label="More actions">
          {items.map((b) => (
            <button
              key={b.id}
              type="button"
              role="menuitem"
              className="plan-more-item"
              aria-disabled={reason(b) ? "true" : undefined}
              title={reason(b) || undefined}
              onClick={() => {
                if (reason(b)) return;
                // Focus back on More first, so a sheet this opens (Schedule) remembers it
                // and hands focus back to it when it closes (U36), never to <body>.
                close(true);
                const go = run[b.id];
                if (typeof go === "function") go();
              }}
            >
              {b.label}
            </button>
          ))}
        </span>
      ) : null}
    </span>
  );
}

/**
 * THE PLAN'S TABLES AS ONE GRID (design-fix-2 DA2-018). A flagged line was a bordered
 * block of eight label / value rows, values 650 px from their labels and the "Why" prose
 * right-aligned. Now it is one table, no box:
 *
 *   Date · Payee (its description under it) · Amount · Coded to → Should be · Action
 *   Why, as a left-aligned ink-3 second line under the row, clamped to two lines with
 *   "More" when it runs longer.
 *
 * The shape is read from the columns, not from a template: a column of sentences (any
 * text column whose cells run past PROSE_AT characters) becomes the second line; a
 * "from" and "to" pair becomes one cell of two account chips; a "description" goes
 * under the "payee". Every cell is still written by the pane's one cell formatter, and
 * every column is still drawn: on a phone each record stacks. A wide table scrolls in
 * its own box, never the document (PR7).
 */
export function planTableShape(table) {
  const columns = Array.isArray(table && table.columns) ? table.columns : [];
  const rows = Array.isArray(table && table.rows) ? table.rows : [];
  const has = (key) => columns.some((c) => c.key === key);
  const prose = columns.filter((c) => TEXT_KINDS.has(c.kind) && rows.some((r) => String(cellText(r[c.key], c.kind) || "").length > PROSE_AT)).map((c) => c.key);
  const pair = has("from") && has("to") ? { from: columns.find((c) => c.key === "from"), to: columns.find((c) => c.key === "to") } : null;
  const under = has("payee") && has("description") && !prose.includes("description") ? "description" : null;
  const main = [];
  for (const c of columns) {
    if (prose.includes(c.key) || c.key === under) continue;
    if (pair && c.key === "to") continue;
    if (pair && c.key === "from") {
      main.push({ key: "from", label: `${pair.from.label} \u2192 ${pair.to.label}`, kind: "pair" });
      continue;
    }
    main.push(c.key === "state" && /^reclass$/i.test(String(c.label || "")) ? { ...c, label: "Action" } : c);
  }
  return { main, prose: prose.map((k) => columns.find((c) => c.key === k)), pair, under };
}

/** An account as a chip: its code tabular in ink-3, then its name (spec §3.4). */
function AccountChip({ text }) {
  const m = /^(\d{3,6})\s+(.*)$/.exec(String(text || ""));
  return (
    <span className="plan-chip" translate="no">
      {m ? (
        <>
          <span className="plan-chip-code">{m[1]}</span> {m[2]}
        </>
      ) : (
        text
      )}
    </span>
  );
}

/** The "Why" line: two lines at rest, "More" past them. */
function WhyLine({ label, text }) {
  const [open, setOpen] = useState(false);
  const long = String(text).length > 140;
  return (
    <p className="plan-why" data-open={open ? "true" : undefined}>
      <span className="chat-visually-hidden">{label}: </span>
      <span className="plan-why-text">{text}</span>
      {long ? (
        <button type="button" className="plan-why-more" aria-expanded={open ? "true" : "false"} onClick={() => setOpen((v) => !v)}>
          {open ? "Less" : "More"}
        </button>
      ) : null}
    </p>
  );
}

function PlanTable({ table, kind }) {
  const wrap = useRef(null);
  const more = useMoreToTheRight(wrap);
  // A grid still wider than its pane (a template with many columns) stacks each record
  // rather than hiding columns behind the edge (Q12/U06, W09).
  const stack = useStackWhenWide(wrap);
  const shape = planTableShape(table);
  const span = shape.main.length;
  // A record table (a payee and an amount): stacked, each record is a compact two-line
  // block, not label/value rows (critic r1 F11, DA2-018 phone).
  const keys = new Set(shape.main.map((c) => c.key));
  const compact = keys.has("payee") && keys.has("amount");
  const colClass = (c) => (NUMERIC.has(c.kind) ? "num" : c.kind === "pair" ? "plan-pair-col" : undefined);
  const totals = table.totals && typeof table.totals === "object" && !Array.isArray(table.totals) ? table.totals : null;
  const totalLabelKey = (shape.main.find((c) => !NUMERIC.has(c.kind)) || {}).key || null;
  const notShown = Number.isInteger(table.rowsNotShown) && table.rowsNotShown > 0 ? table.rowsNotShown : 0;
  const cell = (row, c) => {
    if (c.kind === "pair") {
      const from = cellText(row.from, shape.pair.from.kind);
      const to = cellText(row.to, shape.pair.to.kind);
      return (
        <span className="plan-pair">
          {from ? <AccountChip text={from} /> : null}
          {from && to ? <IconArrowRight className="plan-pair-arrow" size={12} aria-label="should be" /> : null}
          {to ? <AccountChip text={to} /> : null}
        </span>
      );
    }
    const text = cellText(row[c.key], c.kind);
    if (c.key === "payee" && shape.under) {
      const sub = cellText(row[shape.under], "text");
      return (
        <span className="plan-payee-cell">
          <span className="plan-payee">{text}</span>
          {sub ? <span className="plan-sub">{sub}</span> : null}
        </span>
      );
    }
    return text;
  };
  return (
    <div ref={wrap} className="scroll-x plan-table-wrap" data-plan-table={kind} data-more={more && !stack ? "right" : undefined} data-stack={stack ? "" : undefined} data-why={shape.prose.length ? "" : undefined} data-compact={compact ? "" : undefined}>
      <table className="plan-table">
        <thead>
          <tr>
            {shape.main.map((c) => (
              <th key={c.key} scope="col" className={colClass(c)}>
                {c.label}
              </th>
            ))}
          </tr>
        </thead>
        {table.rows.map((row, i) => (
          <tbody key={i} className="plan-record">
            <tr>
              {shape.main.map((c) => (
                <td key={c.key} className={colClass(c)} data-label={c.label} data-col={c.key}>
                  {cell(row, c)}
                </td>
              ))}
            </tr>
            {shape.prose.map((c) => {
              const text = cellText(row[c.key], c.kind);
              return text ? (
                <tr key={c.key} className="plan-why-row">
                  <td colSpan={span}>
                    <WhyLine label={c.label} text={text} />
                  </td>
                </tr>
              ) : null;
            })}
          </tbody>
        ))}
        {totals ? (
          // THE TOTALS ROW (verify pass 1, Q12): the engine's sums over EVERY row the
          // run read, shown or not, so the Current state ties to the books. The first
          // text column says "Total"; a column the engine did not total stays blank.
          <tfoot className="plan-record plan-total">
            <tr data-current-foot="">
              {shape.main.map((c) => {
                const v = totals[c.key];
                const text = c.kind === "pair" || v === null || v === undefined ? null : cellText(v, c.kind);
                return (
                  <td key={c.key} className={colClass(c)} data-label={c.label} data-col={c.key}>
                    {text || (c.key === totalLabelKey ? "Total" : null)}
                  </td>
                );
              })}
            </tr>
          </tfoot>
        ) : null}
      </table>
      {notShown ? (
        <p className="plan-muted plan-rows-not-shown t-footnote" data-rows-not-shown="">
          {notShown === 1 ? "1 more row is" : `${notShown} more rows are`} in the {totals ? "totals" : "result"}, not shown here.
        </p>
      ) : null}
    </div>
  );
}

/**
 * True when the table in `ref`'s box is wider than the box. The table's own width is
 * measured while it is drawn as a table and kept, so the stacked rows (which always
 * fit) never flip it back; a wider box later is compared with that kept width.
 */
export function useStackWhenWide(ref) {
  const [stack, setStack] = useState(false);
  const natural = useRef(0);
  const stacked = useRef(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || typeof window === "undefined") return undefined;
    const measure = () => {
      const table = el.querySelector("table");
      if (!table) return;
      if (!stacked.current) natural.current = table.scrollWidth;
      const next = natural.current > el.clientWidth + 1;
      stacked.current = next;
      setStack(next);
    };
    measure();
    const seen = typeof ResizeObserver === "function" ? new ResizeObserver(measure) : null;
    if (seen) seen.observe(el);
    return () => {
      if (seen) seen.disconnect();
    };
  }, [ref]);
  return stack;
}


/**
 * A step's journal lines, Dr then Cr, with their amounts: "Dr 1500 · Plant & equipment
 * $3,100.00" (eval r1 §17.4: "Dr 2300…, Cr revenue" with no amounts). An amount the plan
 * did not measure says "amount not read", never $0.00.
 */
function StepLines({ step, figures }) {
  const lines = stepLines(step, figures);
  if (!lines.length) return null;
  return (
    <div className="scroll-x plan-table-wrap plan-je-wrap">
    <table className="plan-je" data-plan-je="">
      <tbody>
        {lines.map((l, i) => (
          <tr key={i} data-side={l.side} data-plan-je-line="">
            <td className="plan-je-mark">{l.mark}</td>
            <td className="plan-je-account">
              {l.account}
              {l.description ? <span className="plan-je-desc t-footnote">{l.description}</span> : null}
            </td>
            <td className="num plan-je-amount">{l.cents === null ? <span className="plan-muted">amount not read</span> : cellText(l.cents, "money")}</td>
          </tr>
        ))}
      </tbody>
    </table>
    </div>
  );
}
