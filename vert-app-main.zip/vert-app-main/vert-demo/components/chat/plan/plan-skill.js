// components/chat/plan/plan-skill.js — THE PLAN'S SKILL SETTINGS, READ WITH ONE GET
// ==============================================================================
// Staging walkthrough D1 (26 Oct 2026): opening the accrual plan fired four
// `POST /chat/2026-07-accrual_schedule` requests in ~8 s with nobody pressing anything.
// PlanDocument read the task's skill settings (which settings may be changed in place)
// by calling the `getSkill` SERVER ACTION from an effect:
//
//   · a server action is a POST on the wire, which a proxy, a tester or a read-only role
//     cannot tell from a write (tests/p0-quiet-page-load.test.js);
//   · each open mounted the document twice — the dialog's Portal draws its children in
//     place, then moves them to <body>, and React mounts the moved tree afresh — and each
//     mount asked again;
//   · a server action's reply carries a fresh render of the page (proxy.js slides the
//     session cookie), so a read made from one re-rendered the conversation under it.
//
// Now it is a GET through the app's own route (app/api/skills, as SkillSheet reads it),
// and one read per template is shared by every mount for a short while: the document
// mounting twice, or again on the next open, asks once. A failed read is not kept, so
// the next mount asks again. Never throws.

const KEPT_MS = 60000;
const asked = new Map();

/** `{ok: true, skill}` or `{ok: false}`, read once per template through GET /api/skills. */
export function readPlanSkill(template, fetchImpl = globalThis.fetch) {
  const key = String(template || "");
  const held = asked.get(key);
  const now = Date.now();
  if (held && (held.pending || now - held.at < KEPT_MS)) return held.answer;
  const entry = { at: now, pending: true, answer: null };
  entry.answer = (async () => {
    try {
      const res = await fetchImpl(`/api/skills?template=${encodeURIComponent(key)}`, { cache: "no-store", headers: { accept: "application/json" } });
      const body = await res.json();
      return body && body.ok && body.skill ? { ok: true, skill: body.skill } : { ok: false };
    } catch {
      return { ok: false };
    }
  })().then((answer) => {
    entry.pending = false;
    entry.at = Date.now();
    if (!answer.ok && asked.get(key) === entry) asked.delete(key);
    return answer;
  });
  asked.set(key, entry);
  return entry.answer;
}

/** For tests: forget every read. */
export function forgetPlanSkills() {
  asked.clear();
}
