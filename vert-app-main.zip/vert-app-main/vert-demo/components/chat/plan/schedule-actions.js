"use server";

// components/chat/plan/schedule-actions.js — WHAT THE SCHEDULE SHEET AND CANCEL SEND
// ==============================================================================
// Build plan §20.0 decision 10, §20.4 F-PLAN. Server actions, so the engine key is read
// on the server and never reaches a browser:
//
//   schedulePlanStart(sessionId, {planActionId, fireAt, tz})
//        → POST /agent/sessions/{sessionId}/plan/schedule   (`plan_schedule`)
//   cancelPlanStart(sessionId)
//        → DELETE /agent/sessions/{sessionId}/plan/schedule (`plan_schedule_cancel`)
//
// NEITHER STARTS OR POSTS ANYTHING. A schedule only records when the plan should start;
// the engine's worker starts it then, after a sync, and only into drafts (PL2: posting
// stays a press). The engine re-emits the plan with its `triggers.schedule`, which is
// how the screen learns it was scheduled: nothing here claims it until the engine says.
//
// THE ROAD TO THE ENGINE IS lib/agent/client.js (`schedulePlan`, `cancelPlanSchedule`,
// wired by F-WIRE). Schedule is sent only while `GET /agent/status` says the assistant is
// live for this client (a start would never fire otherwise), and is refused in words
// otherwise. A build with no service, or an engine that still answers 501 (SCHED not
// merged), is "not connected" in words: never a pretend success.
//
// ONLY ASYNC FUNCTIONS ARE EXPORTED (a "use server" file may export nothing else), so
// the body check and the words live in ./triggers-model.js, where tests reach them too.
//
// EVERY EXPORT RETURNS A DESCRIBED OUTCOME AND NEVER THROWS (a thrown Server Action is an
// opaque digest in the browser). A body that is not a schedule is refused here, before
// any request.

import { NOT_CONNECTED, scheduleBody } from "./triggers-model";
import { cancelPlanSchedule, schedulePlan } from "@/lib/agent/client";

const ID = /^[A-Za-z0-9_.:-]{1,64}$/;

/** A build with no service behind it, or the engine's step-0b 501: not connected. */
function notConnected(result) {
  return Boolean(result && (result.code === "not_connected" || result.kind === "unavailable" || result.code === "not_built" || result.status === 501));
}

function refused(message, code = "invalid_request") {
  return { ok: false, kind: "refused", code, message };
}

export async function schedulePlanStart(sessionId, { planActionId = null, fireAt = null, tz = null } = {}) {
  try {
    if (!ID.test(String(sessionId ?? ""))) return refused("Open this plan from its conversation to schedule it. Nothing was scheduled.");
    const press = scheduleBody({ planActionId, fireAt, tz });
    if (!press.ok) return refused(press.message);
    const result = await schedulePlan(sessionId, press.body);
    if (notConnected(result)) return refused(NOT_CONNECTED, "not_connected");
    if (result && result.code === "scheduling_unavailable") return refused(result.message, result.code);
    if (!result || !result.ok) {
      return { ok: false, kind: (result && result.kind) || "unreachable", code: (result && result.code) || "unreachable", message: "Not scheduled. Nothing was changed." };
    }
    return { ok: true, result: result.body || null };
  } catch {
    return { ok: false, kind: "unreachable", code: "network", message: "Not scheduled. Nothing was changed." };
  }
}

export async function cancelPlanStart(sessionId) {
  try {
    if (!ID.test(String(sessionId ?? ""))) return refused("Open this plan from its conversation to cancel its start. Nothing was changed.");
    const result = await cancelPlanSchedule(sessionId);
    if (notConnected(result)) return refused("Cancelling isn't connected here yet. The start is still scheduled.", "not_connected");
    if (!result || !result.ok) {
      return { ok: false, kind: (result && result.kind) || "unreachable", code: (result && result.code) || "unreachable", message: "Not cancelled. The start is still scheduled." };
    }
    return { ok: true, result: result.body || null };
  } catch {
    return { ok: false, kind: "unreachable", code: "network", message: "Not cancelled. The start is still scheduled." };
  }
}
