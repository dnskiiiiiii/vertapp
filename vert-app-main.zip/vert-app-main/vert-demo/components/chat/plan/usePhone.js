"use client";

// components/chat/plan/usePhone.js — IS THIS A PHONE-WIDTH SCREEN (below 700 px)?
// ==============================================================================
// Design-pass spec §6.11 and §6.15: a popover on a desk is a bottom sheet on a phone.
// The answer follows the window as it resizes (useSyncExternalStore over matchMedia), and
// a server render says "not a phone", so the desk markup is what the server draws.

import { useSyncExternalStore } from "react";

// Design-fix-2 DA2-086: the one phone-row breakpoint (640 px), from lib/breakpoints.js.
import { NARROW_ROW_QUERY } from "@/lib/breakpoints";
export const PHONE_QUERY = NARROW_ROW_QUERY;

function subscribe(onChange) {
  if (typeof window === "undefined" || !window.matchMedia) return () => {};
  const list = window.matchMedia(PHONE_QUERY);
  list.addEventListener("change", onChange);
  return () => list.removeEventListener("change", onChange);
}

const snapshot = () => (typeof window !== "undefined" && window.matchMedia ? window.matchMedia(PHONE_QUERY).matches : false);
const serverSnapshot = () => false;

export default function usePhone() {
  return useSyncExternalStore(subscribe, snapshot, serverSnapshot);
}
