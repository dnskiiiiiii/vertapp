"use client";

// components/chat/plan/TriggersSection.js — THE PLAN'S TRIGGERS, THE SCHEDULE SHEET, AND THE TASK'S LINE
// ==============================================================================
// Build plan §20.0 decisions 9–11, §20.4 F-PLAN; the reference's plan "Triggers" (the UI
// teardown: "Every month", "When new … are identified", "+ Add trigger"). Three pieces,
// all drawn from `plan.triggers` through ./triggers-model.js, which holds every rule:
//
//   TriggersSection  between the findings and the steps:
//                      Starting   Ask me before starting            ← a phrase, in place
//                      Scheduled  Starts on its own on 1 Nov 2026 at 9:00 (Sydney time)
//                                 · set by Sam Lee · Cancel
//                      + Add trigger                                 ← opens the sheet
//                    or, where nothing could fire a schedule, "Scheduling isn't
//                    available here" and no control (decision 10).
//   ScheduleSheet    anchored to whatever opened it (a popover above the footer's
//                    Schedule, or under "+ Add trigger"): Day and Time as fields, the
//                    client's zone named, then Cancel and "Schedule start". Quiet and
//                    secondary only: the view's one accent stays Start now. A day or time that can't be honoured is refused in words before
//                    anything is sent.
//   ScheduledLine    "Scheduled for 1 Nov, 9:00 · Cancel", for the task's row on Month-end
//                    (F-WIRE / F-POL4 mount it there; this slot does not own the row).
//
// NOTHING HERE STARTS OR POSTS. Scheduling records a time; the engine starts the plan
// then, into drafts, and every post is still a person's press (PL2). Until the engine
// re-emits the plan, a press says what was SENT, never that the plan is scheduled.

import { useEffect, useId, useRef, useState } from "react";
import { Button, DateField, TimeSlotSelect, TIME_SLOTS } from "@/components/ui";
import { IconAdd } from "@/components/ui/icons";
import { actorWords } from "@/lib/format";
import { useSignedInActor } from "@/lib/store";
import PlanPhrase from "./PlanPhrase";
import {
  NO_SCHEDULING,
  START_MODE_KEY,
  fireAtFrom,
  scheduleWords,
  scheduledLine,
  startModeSetting,
  suggestedStart,
  zoneWords,
} from "./triggers-model";
import { DISPLAY_TIME_ZONE } from "@/lib/format";

/**
 * The time the sheet keeps when its day changes: `time` while it is still ahead on `date`,
 * otherwise the first slot the list offers that is (verify pass 9, P24: today at 9:42 am
 * must not sit on a passed 9:00). With nothing left that day, `time` stays and the send
 * says in words why it can't be honoured.
 */
export function firstOpenSlot(date, time, tz = DISPLAY_TIME_ZONE, now = Date.now()) {
  if (fireAtFrom(date, time, tz, now).ok) return time;
  const open = TIME_SLOTS.find((t) => t >= SLOT_FROM && t <= SLOT_TO && fireAtFrom(date, t, tz, now).ok);
  return open || time;
}

const SLOT_FROM = "06:00";
const SLOT_TO = "21:00";

/**
 * The Triggers section. `triggers` is triggersOf(plan); `startMode` the value shown (an
 * unsaved edit included); `onStartMode(key, value)` records an edit (null once decided);
 * `onAddTrigger` opens the sheet; `onCancel` cancels a scheduled start; `sheet` is the
 * sheet when "+ Add trigger" opened it, drawn under the control.
 */
export function TriggersSection({ triggers, startMode, changed = false, onStartMode = null, onAddTrigger = null, onCancel = null, cancelBusy = false, sheet = null, disabledReason = null }) {
  // Who set the schedule, worded for the viewer, never the stored "key: …" (D16).
  const signedIn = useSignedInActor();
  const words = triggers.schedule ? scheduleWords(triggers.schedule) : null;
  return (
    <section className="plan-section" data-plan-section="triggers">
      <h3 className="plan-h t-title-3">Triggers</h3>
      <dl className="plan-scope plan-triggers">
        <div className="plan-scope-row" data-plan-trigger="start-mode" data-start-mode={startMode}>
          <dt>Starting</dt>
          <dd>
            <PlanPhrase setting={startModeSetting(startMode)} changed={changed} onSet={onStartMode} />
          </dd>
        </div>
        {words ? (
          <div className="plan-scope-row" data-plan-trigger="schedule">
            <dt>Scheduled</dt>
            <dd>
              {words}
              {triggers.schedule.by ? <span className="plan-muted"> · set by {actorWords(triggers.schedule.by, { signedIn })}</span> : null}
              {triggers.schedulingAvailable && typeof onCancel === "function" ? (
                <>
                  {" · "}
                  <button type="button" className="chat-quiet plan-trigger-cancel" onClick={onCancel} disabled={cancelBusy} data-plan-press="schedule-cancel">
                    {cancelBusy ? "Cancelling…" : "Cancel"}
                  </button>
                </>
              ) : null}
            </dd>
          </div>
        ) : null}
      </dl>
      {triggers.schedulingAvailable ? (
        typeof onAddTrigger === "function" ? (
          <span className="plan-trigger-anchor">
            <Button variant="quiet" size="sm" icon={<IconAdd size={14} aria-hidden="true" />} onClick={onAddTrigger} aria-expanded={sheet ? "true" : "false"} disabledReason={disabledReason} data-plan-press="add-trigger">
              Add trigger…
            </Button>
            {sheet}
          </span>
        ) : null
      ) : (
        <p className="plan-muted" data-plan-trigger="unavailable">
          {NO_SCHEDULING}
        </p>
      )}
    </section>
  );
}

/**
 * The Schedule sheet, anchored under the control that opened it. `period` is the plan's
 * month (the suggested day is the 1st after it); `tz` the client's zone; `onSchedule(
 * fireAt, tz)` sends it and resolves `{ok, message}`; `onClose` folds it. `now` is
 * injectable for tests. `initial` seeds `{date, time}` (a server render cannot type).
 */
// `inSheet`: drawn inside the phone's bottom Sheet, which carries the title, so the
// popover's own head is left out (one title per surface).
export function ScheduleSheet({ period = null, tz = DISPLAY_TIME_ZONE, onSchedule, onClose, now = null, initial = null, busy = false, inSheet = false }) {
  const id = useId();
  const rootRef = useRef(null);
  // Esc folds THIS popover, not the pane around it (U36: Esc closed the plan's pane and
  // left focus on "Review" in the thread). Listened for on the popover itself, so the
  // key never reaches the pane's document listener; the plan puts focus back on the
  // control that opened it. The bottom sheet has its own Esc.
  useEffect(() => {
    const el = rootRef.current;
    if (!el || inSheet) return undefined;
    const onKey = (event) => {
      if (event.key !== "Escape") return;
      event.stopPropagation();
      event.preventDefault();
      if (typeof onClose === "function") onClose();
    };
    el.addEventListener("keydown", onKey);
    return () => el.removeEventListener("keydown", onKey);
  }, [inSheet, onClose]);
  const at = Number.isFinite(now) ? now : Date.now();
  const [draft, setDraft] = useState(() => (initial && typeof initial === "object" ? initial : suggestedStart(period, tz, at)));
  const [error, setError] = useState(null);
  useEffect(() => {
    // In the bottom sheet the Sheet puts focus on its title (it announces what opened);
    // a phone's date field focused at once would also raise the picker over it.
    if (inSheet || !rootRef.current) return;
    const field = rootRef.current.querySelector("button, select");
    if (field && typeof field.focus === "function") field.focus();
  }, [inSheet]);
  const checked = fireAtFrom(draft.date, draft.time, tz, at);

  async function send() {
    const fresh = fireAtFrom(draft.date, draft.time, tz, Date.now());
    if (!fresh.ok) {
      setError(fresh.words);
      return;
    }
    setError(null);
    if (typeof onSchedule === "function") {
      const answer = await onSchedule(fresh.fireAt, tz);
      if (answer && !answer.ok) setError(answer.message || "Not scheduled. Nothing was changed.");
    }
  }

  return (
    <span
      className="plan-schedule-sheet"
      role="group"
      aria-label="Schedule the start"
      data-plan-schedule-sheet=""
      data-in-sheet={inSheet ? "true" : undefined}
      ref={rootRef}
    >
      {inSheet ? null : <span className="plan-schedule-head">Schedule the start</span>}
      {/* DA2-066 / DA2-051: the kit's DateField (a month grid, keyboard first) and
          TimeSlotSelect (30-minute slots, the zone in words), never the browser's own
          date and time controls. */}
      <span className="plan-schedule-fields">
        <DateField
          id={`${id}-date`}
          className="plan-schedule-field"
          label="Day"
          name="schedule-day"
          value={draft.date}
          onChange={(date) => setDraft((d) => ({ ...d, date, time: firstOpenSlot(date, d.time, tz, Date.now()) }))}
        />
        <TimeSlotSelect
          id={`${id}-time`}
          className="plan-schedule-field"
          label="Time"
          name="schedule-time"
          zone={zoneWords(tz)}
          value={draft.time}
          from={SLOT_FROM}
          to={SLOT_TO}
          isUnavailable={(time) => !fireAtFrom(draft.date, time, tz, at).ok}
          onChange={(time) => setDraft((d) => ({ ...d, time }))}
        />
      </span>
      <span className="plan-schedule-zone t-footnote" data-plan-schedule-zone={tz}>
        In {zoneWords(tz)} ({tz}). Vert starts the plan then and drafts; nothing posts until you approve it.
      </span>
      {error ? (
        <span className="chat-inline-error" role="alert">
          {error}
        </span>
      ) : null}
      <span className="plan-reject-actions">
        <Button variant="quiet" size="sm" onClick={onClose} data-plan-press="schedule-close">
          Cancel
        </Button>
        <Button variant="secondary" size="sm" onClick={send} busy={busy} busyLabel="Scheduling…" disabledReason={checked.ok ? null : checked.words} data-plan-press="schedule-send">
          Schedule start
        </Button>
      </span>
    </span>
  );
}

/**
 * "Scheduled for 1 Nov, 9:00 · Cancel": a task's scheduled start, for its row. Draws
 * nothing without a live schedule. Cancel is offered only with `onCancel`.
 */
export function ScheduledLine({ schedule, onCancel = null, busy = false }) {
  const line = scheduledLine(schedule);
  if (!line) return null;
  return (
    <span className="plan-scheduled-line t-footnote" data-plan-scheduled="">
      {line}
      {typeof onCancel === "function" ? (
        <>
          {" · "}
          <button type="button" className="chat-quiet" onClick={onCancel} disabled={busy} data-plan-press="schedule-cancel">
            {busy ? "Cancelling…" : "Cancel"}
          </button>
        </>
      ) : null}
    </span>
  );
}

export { START_MODE_KEY };
