"use client";

// components/chat/plan/PlanPhrase.js — ONE OF THE PLAN'S SETTINGS, CHANGED IN PLACE
// ==============================================================================
// Build plan §19.7 F-PLAN: "the settings phrases are editable inline". A setting reads
// as words in its sentence ("$2,500.00", "straight line"); pressed, it becomes the field
// its kind takes, in place, the way the skill sheet's phrases do (same classes, same
// check: components/skills/model.js checkSetting). A value outside its kind is refused
// in words and never kept. Nothing is sent from here: the edit waits in the document
// until Save changes (`plan_edit`), which is what makes Save changes appear.
//
// A setting whose kind is unknown, or that the plan marks not editable, is words only,
// never a control that cannot be checked before it is sent.

import { useState } from "react";
import { MoneyField } from "@/components/ui";
import { IconEdit } from "@/components/ui/icons";
import { checkPhrase, phraseWords } from "@/lib/agent/plan";

export default function PlanPhrase({ setting, onSet, changed = false }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState(null);
  if (!setting) return null;
  const words = phraseWords(setting);
  if (!setting.editable || typeof onSet !== "function") {
    return (
      <span className="plan-phrase-fixed" data-setting={setting.key}>
        {words}
      </span>
    );
  }
  if (!editing) {
    const start = () => {
      setDraft(setting.value != null && setting.kind !== "money" ? String(setting.value) : "");
      setError(null);
      setEditing(true);
    };
    // DA2-065: a real <button> drawn as an inline chip (footnote 500 ink on the inset
    // ground, the inner radius, a pencil on hover), never a dashed underline on a span
    // with hand-rolled keys. The chip wraps inside its own box if a phrase runs long.
    return (
      <button
        type="button"
        className="skill-phrase"
        data-setting={setting.key}
        data-changed={changed ? "true" : undefined}
        aria-label={`${setting.label}: ${words}. Change`}
        onClick={start}
      >
        <span className="skill-phrase-words">{words}</span>
        <IconEdit className="skill-phrase-pencil" size={12} aria-hidden="true" />
      </button>
    );
  }
  const commit = (value) => {
    const typed = setting.kind === "accounts" && typeof value === "string" ? value.split(",").map((a) => a.trim()).filter(Boolean) : value;
    const checked = checkPhrase(setting, typed);
    if (!checked.ok) {
      setError(checked.message);
      return;
    }
    onSet(setting.key, checked.value);
    setEditing(false);
  };
  const options = Array.isArray(setting.options)
    ? setting.options.map((o) => (o && typeof o === "object" ? { id: o.id ?? o.value, label: o.label || String(o.id ?? o.value) } : { id: o, label: String(o) }))
    : [];
  return (
    <span className="skill-phrase-edit" data-setting-edit={setting.key}>
      {setting.kind === "money" ? (
        <MoneyField
          label={setting.label}
          defaultValue=""
          onValueChange={({ cents }) => setDraft(cents)}
          onKeyDown={(e) => {
            if (e.key === "Enter") commit(draft);
          }}
        />
      ) : setting.kind === "choice" || setting.kind === "account" ? (
        <select className="field-input" name={`setting-${setting.key}`} autoComplete="off" aria-label={setting.label} defaultValue={setting.value ?? ""} onChange={(e) => commit(e.target.value)}>
          <option value="" disabled>
            Choose…
          </option>
          {options.map((o) => (
            <option key={o.id} value={o.id}>
              {o.label}
            </option>
          ))}
        </select>
      ) : setting.kind === "bool" ? (
        <select className="field-input" name={`setting-${setting.key}`} autoComplete="off" aria-label={setting.label} defaultValue={setting.value ? "yes" : "no"} onChange={(e) => commit(e.target.value === "yes")}>
          <option value="yes">yes</option>
          <option value="no">no</option>
        </select>
      ) : (
        <input
          className="field-input"
          name={`setting-${setting.key}`}
          autoComplete="off"
          aria-label={setting.label}
          value={draft}
          inputMode={setting.kind === "percent" ? "decimal" : undefined}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") commit(draft);
          }}
        />
      )}
      {setting.kind === "money" || setting.kind === "percent" || setting.kind === "text" || setting.kind === "accounts" ? (
        <button type="button" className="chat-quiet" onClick={() => commit(draft)}>
          Use this
        </button>
      ) : null}
      <button type="button" className="chat-quiet" onClick={() => setEditing(false)}>
        Cancel
      </button>
      {error ? (
        <span className="chat-inline-error" role="alert">
          {error}
        </span>
      ) : null}
    </span>
  );
}
