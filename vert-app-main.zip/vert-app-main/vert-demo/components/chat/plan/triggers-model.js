// components/chat/plan/triggers-model.js — WHEN A PLAN STARTS, AS WORDS AND AS A FOOTER
// ==============================================================================
// Build plan §20.0 decisions 9–11, §20.4 F-PLAN. Pure functions, so every rule the plan
// document's Triggers section and its footer follow is tested without a browser
// (tests/plan-triggers.test.js, tests/plan-footer.test.js, tests/plan-schedule.test.js).
// (Named `-model`, not `triggers.js`: macOS file names ignore case, and TriggersSection.js
// sits beside it.)
//
// WHAT THE TRIGGERS SECTION SAYS, from the engine's `plan.triggers`
// (`{startMode: ask|when_nothing_new, schedule?: {fireAt, tz, by, cancelled?},
// schedulingAvailable}`):
//
//   · the start mode, switchable in place: "Ask me before starting" (THE DEFAULT, and
//     what an iteration-3 plan with no `triggers` means) or "Start when nothing is new;
//     otherwise ask me" (the engine's own phrase, vert_engine/skills/sop.py, and the skill
//     sheet's: one mode, one sentence everywhere it is said). Changing it is an edit like any setting: it waits for Save
//     changes and is sent as `start_mode`, so the engine checks it and re-emits the plan.
//   · a scheduled start, when there is one: "Starts on its own on 1 Nov 2026 at 9:00
//     (Sydney time) · set by Sam Lee · Cancel". The engine's schedule is ONE instant
//     (`scheduled_starts.fire_at`), so this never says "every month": a repeat the
//     engine does not hold would be a promise nobody keeps.
//   · "+ Add trigger", which opens the Schedule sheet, or, where no periodic worker runs
//     for this client (`schedulingAvailable: false`), "Scheduling isn't available here"
//     and NO control at all (decision 10, NF-1st: a Schedule button with nothing behind
//     it to fire is a dead control).
//
// THE FOOTER ORDER IS PINNED: Save changes · Reject · Schedule · Start now (the
// reference's plan footer; tests/plan-footer.test.js). Start now stays the one purple;
// Schedule is quiet. Save changes appears once something is edited, as on iteration 3,
// and when it does it is first.
//
// TIMES ARE THE CLIENT'S. The books are Australian, so the sheet's date and time are read
// in the client's zone (the schedule's own `tz`, else lib/format.js DISPLAY_TIME_ZONE)
// and sent as an instant WITH ITS OFFSET, worked out for that date: 9:00 in Sydney is
// +11:00 in November and +10:00 in July. A local time the clocks skip (2:30 on the
// first Sunday of October) is refused in words, never moved silently to 3:30.

import { DISPLAY_TIME_ZONE, MONTHS } from "@/lib/format";
import { planEditSettings, planFooter } from "@/lib/agent/plan";

/** The start-mode setting's key, as the plan edit sends it (PSTART's setting). */
export const START_MODE_KEY = "start_mode";

/**
 * The two start modes, in the words the plan, the skill sheet and the engine all use.
 * Iteration 4's first Triggers section said "When nothing new is found: start on its
 * own" while the engine and the skill sheet said the sentence below: the same mode in two
 * phrasings reads as two rules. tests/start-mode-words.test.js pins the one phrase.
 */
export const START_MODES = Object.freeze({
  ask: "Ask me before starting",
  when_nothing_new: "Start when nothing is new; otherwise ask me",
});

/** The default, decision 9: Vert asks unless someone has said otherwise. */
export const DEFAULT_START_MODE = "ask";

/** Said in place of every Schedule control where nothing could fire it. */
export const NO_SCHEDULING = "Scheduling isn't available here";

/** The footer's pinned order (decision 11). */
export const FOOTER_ORDER = Object.freeze(["save", "reject", "schedule", "start"]);

/** Said when the road to the engine is not built yet (./schedule-actions.js). */
export const NOT_CONNECTED = "Scheduling isn't connected here yet. Nothing was scheduled.";

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

const INSTANT = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?(\.\d+)?(Z|[+-]\d{2}:\d{2})$/;
const DAY = /^(\d{4})-(\d{2})-(\d{2})$/;
const CLOCK = /^(\d{1,2}):(\d{2})$/;
const ACTION_ID = /^[A-Za-z0-9_.:-]{1,64}$/;
const ZONE = /^[A-Za-z_]+(\/[A-Za-z_+-]+){0,2}$/;

/**
 * The plan's triggers, read once with every default applied: `{startMode, schedule,
 * schedulingAvailable}`. `schedule` is null when there is none or it was cancelled. An
 * absent `triggers` (an iteration-3 plan) is Ask me with no scheduling: nothing here
 * offers a control the engine did not say it can honour.
 */
export function triggersOf(plan) {
  const t = isObj(plan) && isObj(plan.triggers) ? plan.triggers : {};
  const startMode = Object.hasOwn(START_MODES, t.startMode) ? t.startMode : DEFAULT_START_MODE;
  const s = isObj(t.schedule) ? t.schedule : null;
  const schedule = s && s.cancelled !== true && typeof s.fireAt === "string" && INSTANT.test(s.fireAt) ? s : null;
  return { startMode, schedule, schedulingAvailable: t.schedulingAvailable === true };
}

/** The start mode as the phrase the Triggers section switches in place. */
export function startModeSetting(startMode) {
  return {
    key: START_MODE_KEY,
    label: "Starting",
    kind: "choice",
    value: Object.hasOwn(START_MODES, startMode) ? startMode : DEFAULT_START_MODE,
    options: Object.entries(START_MODES).map(([id, label]) => ({ id, label })),
    editable: true,
  };
}

/** The zone's everyday name: "Australia/Sydney" → "Sydney time". */
export function zoneWords(tz) {
  const zone = typeof tz === "string" && tz.trim() ? tz.trim() : DISPLAY_TIME_ZONE;
  const city = zone.split("/").pop().replace(/_/g, " ");
  return `${city} time`;
}

/** The wall-clock parts of an instant in `tz`: {year, month, day, hour, minute}. */
function wallClock(ms, tz) {
  const parts = new Intl.DateTimeFormat("en-AU", {
    timeZone: tz,
    year: "numeric",
    month: "numeric",
    day: "numeric",
    hour: "numeric",
    minute: "numeric",
    hourCycle: "h23",
  }).formatToParts(new Date(ms));
  const get = (type) => Number(parts.find((p) => p.type === type).value);
  return { year: get("year"), month: get("month"), day: get("day"), hour: get("hour") % 24, minute: get("minute") };
}

/** Minutes east of UTC that `tz` keeps at the instant `ms`. */
export function zoneOffsetMinutes(tz, ms) {
  const w = wallClock(ms, tz);
  const asUtc = Date.UTC(w.year, w.month - 1, w.day, w.hour, w.minute);
  return Math.round((asUtc - Math.floor(ms / 60000) * 60000) / 60000);
}

function offsetText(minutes) {
  const sign = minutes < 0 ? "-" : "+";
  const abs = Math.abs(minutes);
  return `${sign}${String(Math.floor(abs / 60)).padStart(2, "0")}:${String(abs % 60).padStart(2, "0")}`;
}

/**
 * The sheet's date ("2026-11-01") and time ("09:00"), read in `tz`, as the instant the
 * engine stores: `{ok: true, fireAt: "2026-11-01T09:00:00+11:00"}`, or `{ok: false,
 * words}` saying what is wrong. A time in the past is refused (`now`, injectable), and so
 * is a local time the clocks skip.
 */
export function fireAtFrom(date, time, tz = DISPLAY_TIME_ZONE, now = Date.now()) {
  const d = DAY.exec(typeof date === "string" ? date.trim() : "");
  const c = CLOCK.exec(typeof time === "string" ? time.trim() : "");
  if (!d) return { ok: false, words: "Choose the day it should start." };
  if (!c) return { ok: false, words: "Choose the time it should start, as hours and minutes." };
  const [year, month, day, hour, minute] = [Number(d[1]), Number(d[2]), Number(d[3]), Number(c[1]), Number(c[2])];
  if (month < 1 || month > 12 || day < 1 || day > 31 || hour > 23 || minute > 59) {
    return { ok: false, words: "That isn't a day and time Vert can read." };
  }
  const wall = Date.UTC(year, month - 1, day, hour, minute);
  if (new Date(wall).getUTCDate() !== day) return { ok: false, words: "That day isn't in the calendar." };
  // Two passes: the offset at a first guess, then at the instant that guess gives,
  // which settles on the right side of a daylight-saving change.
  let ms = wall - zoneOffsetMinutes(tz, wall) * 60000;
  ms = wall - zoneOffsetMinutes(tz, ms) * 60000;
  const back = wallClock(ms, tz);
  if (back.year !== year || back.month !== month || back.day !== day || back.hour !== hour || back.minute !== minute) {
    return { ok: false, words: `The clocks go forward then, so ${time.trim()} doesn't happen that day in ${zoneWords(tz).replace(/ time$/, "")}. Choose another time.` };
  }
  if (ms <= now) return { ok: false, words: "That time has already passed. Choose a later one." };
  const fireAt = `${d[1]}-${d[2]}-${d[3]}T${String(hour).padStart(2, "0")}:${c[2]}:00${offsetText(zoneOffsetMinutes(tz, ms))}`;
  return { ok: true, fireAt };
}

/** "9:00" — the time an instant shows in `tz`, with no leading zero. */
function clockWords(ms, tz) {
  const w = wallClock(ms, tz);
  return `${w.hour}:${String(w.minute).padStart(2, "0")}`;
}

function scheduleAt(schedule) {
  if (!isObj(schedule) || schedule.cancelled === true || typeof schedule.fireAt !== "string" || !INSTANT.test(schedule.fireAt)) return null;
  const ms = new Date(schedule.fireAt).getTime();
  if (Number.isNaN(ms)) return null;
  const tz = typeof schedule.tz === "string" && schedule.tz ? schedule.tz : DISPLAY_TIME_ZONE;
  return { ms, tz, w: wallClock(ms, tz) };
}

/**
 * A scheduled start as the Triggers section says it: "Starts on its own on 1 Nov 2026
 * at 9:00 (Sydney time)". Null for anything that is not a live schedule.
 */
export function scheduleWords(schedule) {
  const at = scheduleAt(schedule);
  if (!at) return null;
  return `Starts on its own on ${at.w.day} ${MONTHS[at.w.month - 1]} ${at.w.year} at ${clockWords(at.ms, at.tz)} (${zoneWords(at.tz)})`;
}

/** The short line for the task: "Scheduled for 1 Nov, 9:00". Null without a schedule. */
export function scheduledLine(schedule) {
  const at = scheduleAt(schedule);
  if (!at) return null;
  return `Scheduled for ${at.w.day} ${MONTHS[at.w.month - 1]}, ${clockWords(at.ms, at.tz)}`;
}

/**
 * The day the sheet suggests: the 1st of the month after the plan's period, at 9:00,
 * when that is still ahead; otherwise tomorrow at 9:00. `{date, time}` as the inputs take
 * them. A suggestion only: nothing is scheduled until the person presses.
 */
export function suggestedStart(period, tz = DISPLAY_TIME_ZONE, now = Date.now()) {
  const m = /^(\d{4})-(\d{2})$/.exec(typeof period === "string" ? period : "");
  const pad = (n) => String(n).padStart(2, "0");
  if (m) {
    const y = Number(m[1]) + (Number(m[2]) === 12 ? 1 : 0);
    const mo = Number(m[2]) === 12 ? 1 : Number(m[2]) + 1;
    const date = `${y}-${pad(mo)}-01`;
    if (fireAtFrom(date, "09:00", tz, now).ok) return { date, time: "09:00" };
  }
  const w = wallClock(now + 24 * 3600 * 1000, tz);
  return { date: `${w.year}-${pad(w.month)}-${pad(w.day)}`, time: "09:00" };
}

/**
 * The footer, in its pinned order: Save changes (once edited) · Reject · Schedule
 * (only where scheduling is available) · Start now. Built on lib/agent/plan.js
 * planFooter, which owns Save, Reject and Start now; this only places Schedule, as the
 * secondary button (design-pass spec §6.14: its popover needs an anchor you can see),
 * immediately before Start now. A decided plan has no footer at all.
 */
export function footerButtons({ edited = false, decided = false, schedulingAvailable = false, editable = false } = {}) {
  // SAVE CHANGES IS ALWAYS IN THE FOOT OF AN EDITABLE PLAN, disabled until something
  // changed (verify passes 1-4, Q12 line 7 and W09: "footer Save changes · Reject ·
  // Schedule · Start now (pinned)"). Design-fix-2 DA2-051 had dropped it before an edit,
  // and that is why Q12 failed four passes running: the checker opens a fresh plan and
  // finds no Save changes at all. DA2-051's complaint was the CLUTTER (a grey button
  // plus a visible "Change a setting first." line); the foot now keeps the quiet button
  // and carries its reason for assistive tech only (plan.css hides the reason line).
  // The two presses that open something say so with "…" (spec §3.5).
  const base = planFooter({ edited, decided, editable })
    .map((b) => (b.id === "reject" ? { ...b, label: `${b.label}\u2026` } : b));
  if (!base.length || !schedulingAvailable) return base;
  const out = [];
  for (const b of base) {
    if (b.id === "start") out.push({ id: "schedule", label: "Schedule\u2026", variant: "secondary" });
    out.push(b);
  }
  return out;
}

/**
 * The body `POST /agent/sessions/{id}/plan/schedule` takes (the engine's
 * PlanScheduleRequest, which forbids any other key), or `{ok: false, message}` saying why
 * there is none. Checked before any request leaves.
 */
export function scheduleBody({ planActionId = null, fireAt = null, tz = null } = {}) {
  if (!ACTION_ID.test(String(planActionId ?? ""))) return { ok: false, message: "That plan isn't one Vert put to you. Nothing was scheduled." };
  if (typeof fireAt !== "string" || !INSTANT.test(fireAt)) return { ok: false, message: "Choose a day and a time. Nothing was scheduled." };
  if (typeof tz !== "string" || !ZONE.test(tz)) return { ok: false, message: "Vert doesn't know this client's time zone. Nothing was scheduled." };
  return { ok: true, body: { planActionId, fireAt, tz } };
}

/**
 * What Save changes sends: the plan's own editable settings that changed (lib/agent/
 * plan.js planEditSettings) plus `start_mode` when it differs from the plan's. The start
 * mode is the Triggers section's, never a second copy among the settings.
 */
export function editsToSend(settings, edits, triggers) {
  const own = (Array.isArray(settings) ? settings : []).filter((s) => s && s.key !== START_MODE_KEY);
  const out = { ...planEditSettings(own, edits) };
  const was = isObj(triggers) && Object.hasOwn(START_MODES, triggers.startMode) ? triggers.startMode : DEFAULT_START_MODE;
  if (isObj(edits) && Object.hasOwn(edits, START_MODE_KEY) && Object.hasOwn(START_MODES, edits[START_MODE_KEY]) && edits[START_MODE_KEY] !== was) {
    out[START_MODE_KEY] = edits[START_MODE_KEY];
  }
  return out;
}

const START_LEAD = /^\s*(Ask me before starting|Start when nothing is new; otherwise ask me)\.?\s*/;

/**
 * The plan's checkpoint sentence without its start-mode clause, for a plan that carries
 * `triggers`: the Triggers section already says how the plan starts, and "Ask me before
 * starting" twice on one page reads as two rules. Null when nothing is left. A plan with
 * no `triggers` (iteration 3) keeps its sentence whole, as it was written.
 */
export function checkpointRest(plan) {
  const sentence = isObj(plan) && isObj(plan.checkpoints) && typeof plan.checkpoints.sentence === "string" ? plan.checkpoints.sentence.trim() : "";
  if (!sentence) return null;
  if (!isObj(plan.triggers)) return sentence;
  return sentence.replace(START_LEAD, "").trim() || null;
}

/**
 * The schedule a press's own answer reads back, or undefined when it reads back nothing
 * this screen can draw. Schedule start's answer carries the stored row as the engine
 * re-reads it (`{schedule: {fireAt, tz, by}}`, vert_api/routers/agent.py
 * `schedule_plan`); Cancel's carries `{cancelled: true}`, read back here as "no schedule"
 * (null).
 *
 * WHY THE SCREEN DRAWS FROM THIS AT ONCE (eval r1 §17, iteration 4): the engine lays a
 * schedule onto the plan only when the plan is READ, never as a stream event, so a
 * screen that waited for "the engine re-emits the plan" said nothing after Schedule
 * start, and Triggers still read "Ask me before starting" until a reload, although the
 * row was stored. The read-back IS the engine's word that it is stored, so drawing it is
 * not the plan claiming its own change.
 */
export function scheduleReadBack(result) {
  if (!isObj(result)) return undefined;
  if (result.cancelled === true) return null;
  const s = isObj(result.schedule) ? result.schedule : null;
  if (!s || s.cancelled === true || typeof s.fireAt !== "string" || !INSTANT.test(s.fireAt)) return undefined;
  if (typeof s.tz !== "string" || !ZONE.test(s.tz)) return undefined;
  return { fireAt: s.fireAt, tz: s.tz, ...(typeof s.by === "string" && s.by.trim() ? { by: s.by.trim() } : {}) };
}

/**
 * The plan's triggers with the last press's read-back laid over them: a schedule read
 * back replaces the plan's (or adds one), a cancel read back removes it, and no
 * read-back (undefined) leaves the plan's own triggers as the engine sent them.
 */
export function withReadBack(triggers, readBack) {
  const t = isObj(triggers) ? triggers : triggersOf(null);
  if (readBack === undefined) return t;
  return { ...t, schedule: readBack };
}
