// components/month/FirstRun.js — "CONNECT YOUR BOOKS TO START"
// ==============================================================================
// Spec §3.2 "First run" and §3.6; audit UI-061. Before one payment source and the bank
// are in, there is no month to start, so Month-end IS the connections list, under one
// heading. Once they are in, the page becomes "September hasn't started." There is no
// separate Setup page to be sent to (it duplicated Connections).
//
// THE LIST IS THE ONE /connections DRAWS (components/setup/ConnectionsList.js), from
// the same two reads, so setting up and checking later are the same rows. app/page.js
// makes the reads (`readConnections()` and `listBankAccountsAction()`) and decides
// first run with `needsSetup` over them; this only frames the list.

import ConnectionsList from "@/components/setup/ConnectionsList";

export default function FirstRun({ connections, bank }) {
  return (
    <div className="month-first-run">
      <h1 className="month-title t-title-1">Connect your books to start</h1>
      <ConnectionsList connections={connections} bank={bank} />
    </div>
  );
}
