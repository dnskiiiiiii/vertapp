"use client";

// components/month/TaskRow.js — ONE TASK, ONE LINE
// ==============================================================================
// Spec §3.2 and §4.4. A task reads as its title and what the engine said about it:
// "Resolve payout breaks · 4 decisions", "Build workpapers · after the payout breaks and
// the bank rec". The count is the task's own `decisions` from the payload; the words are
// its `line`. It opens its conversation, where the work is.
//
// A TASK IN TROUBLE stays under Needs you with a Problem line — "Couldn't finish: this
// took longer than it should, so Vert stopped." — and Retry, which runs the task again
// (`POST /agent/sessions {period, template}`). A failure is not a fifth status.
//
// IN THE CHECKLIST CARD (`listed`; visual spec §3, eval r1 §17.4). Every task of the
// month is one 2.5rem row: the title alone at body weight on the left, and on the right
// the count or reason as an outlined chip ("4 decisions", "after the bank rec") and the
// outlined status chip. The whole row opens the conversation. Its problem line and
// Retry are not repeated there: they belong to the Needs-you row above, where the
// person acts, and one Retry per task is the rule (one filled path per decision).
//
// ITERATION 3 (build plan §19.0.8, §19.5 F-CHK): ONE ROW TYPE. A custom task and a
// built-in template are the same row. Beside the chips it shows the assignee's initials
// (named in full for a screen reader and on hover) and the due day ("Due 5th"). A task
// with an approver reaches Done only when THAT person presses "Mark complete", so the
// control is drawn only for the named approver (the signed-in person, `viewer`), only
// on a task the engine can complete (it has an id), and never on one already Done. It
// is a secondary button, not purple: a checklist of them would put many purples in one
// view (§13), and the decision it records is the approver's sign-off, not a posting.
//
// OPEN SKILL (build plan §19.6 F-BRAIN). A task bound to a skill (`template`) has a "⋯"
// at the row's end whose item opens the skill sheet (components/skills); a person's
// task can also be moved to a group from it (TaskRowMenu.js, ui-pass-1 W02). It is
// drawn only where the skill can be read: with a signed-in viewer, which only a live
// service has. In the static build there is no skill to read, and a control that
// opened "couldn't read" would be a false affordance.

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Button, StatusMark } from "@/components/ui";
import { IconCaretRight } from "@/components/ui/icons";
import { startConversation } from "@/lib/agent/actions";
import { problemSentence } from "@/lib/agent/words";
import { callSafely } from "@/lib/decisions";
import { completeTask, startHeldTask } from "@/lib/tasks";
import { canStartHeld, recursMonthly, taskRowChip, taskRowText } from "./model";
import { dueDate, initials } from "./GroupBy";
import TaskRowMenu from "./TaskRowMenu";

export default function TaskRow({ task, period, figure = null, mark = false, retryDisabledReason = null, recounting = false, listed = false, viewer = null, rowKey = null, tabbable = false, onRowFocus = null, groups = null, showStatus = false }) {
  const router = useRouter();
  const [retry, setRetry] = useState("idle");
  const href = task.sessionId ? `/chat/${encodeURIComponent(task.sessionId)}` : null;
  const text = taskRowText(task, { recounting });
  if (listed) return <ListedRow task={task} href={href} chip={taskRowChip(task, { recounting, statusShown: showStatus })} figure={figure} viewer={viewer} rowKey={rowKey} tabbable={tabbable} onRowFocus={onRowFocus} groups={groups} showStatus={showStatus} period={period} />;

  async function runAgain() {
    setRetry("busy");
    const result = await callSafely(startConversation, { period, template: task.template });
    if (!result.ok) {
      setRetry("failed");
      return;
    }
    setRetry("idle");
    router.refresh();
  }

  return (
    <div className="task-row" data-task={task.template} data-task-decisions={typeof task.decisions === "number" ? task.decisions : undefined}>
      <div className="task-row-main">
        {mark ? <StatusMark word={task.status} compact /> : null}
        {href ? (
          <Link href={href} className="task-row-title t-body">
            {text}
          </Link>
        ) : (
          <span className="task-row-title t-body">{text}</span>
        )}
      </div>
      {/* The outlined status chip on the right (visual spec §3): icon + word in the
          status ink. The word is the payload's; nothing is inferred here. */}
      {task.status && !mark ? <StatusMark word={task.status} chip className="task-row-chip t-footnote" /> : null}
      {task.problem ? (
        <div className="task-row-problem">
          <p className="task-problem t-footnote">
            {couldntFinish(task.problem.code)}
            {retry === "failed" ? " Retry wasn't sent. Nothing was recorded." : ""}
          </p>
          {/* A row beside the checklist (an account's own rec) has no Retry here: its
              template would run the month's own task, not this conversation's work;
              its conversation, which the row opens, offers Try again itself. */}
          {task.beside ? null : (
            <Button variant="secondary" size="sm" onClick={runAgain} busy={retry === "busy"} busyLabel="Running…" disabledReason={retryDisabledReason}>
              Retry
            </Button>
          )}
        </div>
      ) : null}
    </div>
  );
}

/**
 * "Couldn't finish: this took longer than it should, so Vert stopped." The engine's
 * sentence is joined on lower-case, except where it starts with a name: "Vert hit a
 * problem it didn't expect" (a `task_failed` row, engine D04) read "vert hit…". Pure.
 */
export function couldntFinish(code) {
  const sentence = problemSentence(code);
  const joined = /^Vert\b/.test(sentence) ? sentence : sentence.replace(/^./, (c) => c.toLowerCase());
  return `Couldn't finish: ${joined}`;
}

/** Whether `viewer` may press "Mark complete" on this task (see header). */
export function canMarkComplete(task, viewer) {
  const who = typeof viewer === "string" ? viewer.trim() : "";
  const approver = task && typeof task.approver === "string" ? task.approver.trim() : "";
  return Boolean(who && approver && who === approver && task.id && task.status !== "Done");
}

/**
 * Whether this row offers Start: a person's task made with Create, not Done. `held` is
 * the live engine's own word (`GET /close`); a recording never carries it, so no Start
 * is drawn where nothing could start. Anyone who may write may start it, a shared key
 * too (unlike Mark complete, which is the named approver's). Pure; kept in model.js so
 * the board (components/home/rows.js) asks the same rule.
 */
export { canStartHeld };

/**
 * The quiet "Monthly" tag beside a recurring task's title (walkthrough, 27 Oct 2026),
 * on the checklist and the board alike. Caption ink, no fill: it says how often, not
 * what to do.
 */
export function MonthlyTag() {
  return (
    <span className="task-tag t-caption" data-recurs="monthly">
      <span className="sr-only"> · </span>
      Monthly
    </span>
  );
}

/** The meta column's full words for its hover title: the chip, then the figure. Pure. */
export function metaTitle(chip, figure) {
  return [chip, figure && figure.text ? figure.text : null].filter(Boolean).join(" · ") || null;
}

/**
 * Whether a Mark complete press came back Done, from the engine's own read-back of the
 * task (`POST /tasks/{id}/complete` answers `{task, verified}`; lib/tasks.js settled).
 * Only a verified answer whose task says "Done" counts. Pure.
 */
export function completedFrom(result) {
  return Boolean(result && result.ok === true && result.task && result.task.status === "Done");
}

/**
 * The task as this row draws it: the payload's, or, once THIS row's Mark complete came
 * back Done, the engine's read-back laid over it (verify pass 3, W03). The press used
 * only `router.refresh()`, and a Month-end read takes seconds (18.9 s for a 10,000-line
 * August), so the approver's row went on reading "Waiting · Mark complete" over an API
 * that already said Done, and a second press looked necessary. Only `status`, `doneBy`
 * and `doneAt` are taken from the read-back; the refresh then moves the row to Done.
 * Pure.
 */
export function shownTask(task, readBack) {
  if (!readBack || readBack.status !== "Done" || !task || task.status === "Done") return task;
  const out = { ...task, status: "Done" };
  for (const key of ["doneBy", "doneAt"]) if (readBack[key] !== undefined) out[key] = readBack[key];
  return out;
}

// One row of the Checklist card. The " · " between title and chip is for a screen
// reader (and the text tests), so the row still reads as one sentence.
//
// THE TITLE IS ONE STOP OF THE CHECKLIST'S ROVING TABINDEX (`rowKey`; Checklist.js
// rovingKeys): `tabbable` on the one row Tab enters on, -1 on the rest, and a focus
// reports the row so Tab comes back to it. Without a `rowKey` the link is an ordinary
// Tab stop.
//
// DESIGN-FIX-2 (DA2-035, DA2-007, DA2-060, DA2-061; 10 Oct 2026). Forty px, no hairline,
// a hover fill; fixed columns so nothing is ragged: the meta ("4 decisions", or the
// engine's reason) in a 13.75rem left-aligned column, the due date ("Due 5 Aug", the
// attention ink once it has passed), a 20 px initials avatar (or its empty slot), the
// status (only in the Group cut: under a status band the band already says it), the
// "•••" (seen on hover or focus, always on touch) and a trailing CaretRight in a reserved
// 24 px gutter. A row whose only menu item would be "Open skill" shows that as a direct
// icon button (TaskRowMenu). The focus ring is the whole row's (month.css :has). Below
// 640 px it is one 48 px line: the title, then one right-aligned figure (the count, else
// the due date), then the "•••".
function ListedRow({ task: served, href, chip, figure = null, viewer, rowKey = null, tabbable = false, onRowFocus = null, groups = null, showStatus = false, period = null }) {
  const router = useRouter();
  const [complete, setComplete] = useState({ state: "idle", message: null, task: null });
  // Once the page's month says Done itself, the payload's row is drawn (shownTask).
  const task = shownTask(served, complete.task);
  const completedHere = task !== served;
  const title = typeof task.title === "string" ? task.title : "A task";
  const who = typeof task.assignee === "string" && task.assignee.trim() ? task.assignee.trim() : null;
  const mark = initials(who);
  const due = dueDate(task.due, task.period || period, { done: task.status === "Done" });

  // START, on a task made with Create (founders, 22 Oct 2026): its first turn runs, and
  // the person goes to its conversation to watch it, as Create and start would have.
  const [starting, setStarting] = useState({ state: "idle", message: null });
  async function startNow() {
    setStarting({ state: "busy", message: null });
    const result = await callSafely(startHeldTask, task.id);
    if (!result || !result.ok) {
      setStarting({ state: "failed", message: (result && result.message) || "Not started. Nothing was run." });
      return;
    }
    setStarting({ state: "idle", message: null });
    const session = (result.task && result.task.sessionId) || task.sessionId;
    if (session) router.push(`/chat/${encodeURIComponent(session)}`);
    else router.refresh();
  }

  async function markComplete() {
    setComplete({ state: "busy", message: null, task: null });
    const result = await callSafely(completeTask, task.id);
    if (!result || !result.ok) {
      setComplete({ state: "failed", message: (result && result.message) || "Not sent. Nothing was recorded.", task: null });
      return;
    }
    setComplete({ state: "idle", message: null, task: completedFrom(result) ? result.task : null });
    router.refresh();
  }

  return (
    <div
      className="task-row task-row-listed"
      data-task={task.template || task.id}
      data-task-id={task.id || undefined}
      data-task-decisions={typeof task.decisions === "number" ? task.decisions : undefined}
      data-linked={href ? "true" : undefined}
      data-status={showStatus || completedHere ? "true" : undefined}
      data-completed-here={completedHere ? "true" : undefined}
      data-phone-figure={chip && typeof task.decisions === "number" && task.decisions > 0 ? "meta" : due ? "due" : undefined}
    >
      <div className="task-row-main">
        {href ? (
          <Link
            href={href}
            className="task-row-title t-body"
            data-row-key={rowKey || undefined}
            tabIndex={rowKey ? (tabbable ? 0 : -1) : undefined}
            onFocus={rowKey && onRowFocus ? () => onRowFocus(rowKey) : undefined}
          >
            {title}
          </Link>
        ) : (
          <span className="task-row-title t-body">{title}</span>
        )}
        {recursMonthly(task) ? <MonthlyTag /> : null}
      </div>
      <span className="task-row-count t-footnote" title={metaTitle(chip, figure) || undefined}>
        {chip ? (
          <>
            <span className="sr-only"> · </span>
            {chip}
          </>
        ) : null}
        {figure && figure.text ? (
          // The bank rec's closing balance (model.js bankRecFigureOf, S-UI-11).
          <span className="task-row-figure num" data-row-figure={figure.state}>
            {chip ? " · " : <span className="sr-only"> · </span>}
            {figure.text}
          </span>
        ) : null}
      </span>
      <span className="task-row-due t-caption num" data-overdue={due && due.overdue ? "true" : undefined}>
        {due ? (
          <>
            <span className="sr-only"> · </span>
            {due.overdue ? <span className="sr-only">Overdue. </span> : null}
            <time dateTime={due.iso}>{due.text}</time>
          </>
        ) : null}
      </span>
      <span className="task-row-who" title={who ? `Assigned to ${who}` : undefined} data-vacant={mark ? undefined : "true"}>
        {mark ? (
          <>
            <span className="task-row-avatar t-caption" aria-hidden="true">
              {mark}
            </span>
            <span className="sr-only">{` · Assigned to ${who}`}</span>
          </>
        ) : null}
      </span>
      {canStartHeld(task) ? (
        <Button variant="secondary" size="sm" onClick={startNow} busy={starting.state === "busy"} busyLabel="Starting…" className="task-row-complete task-row-start" data-task-start="">
          Start
        </Button>
      ) : null}
      {canMarkComplete(task, viewer) ? (
        <Button variant="secondary" size="sm" onClick={markComplete} busy={complete.state === "busy"} busyLabel="Completing…" className="task-row-complete">
          Mark complete
        </Button>
      ) : null}
      {(showStatus || completedHere) && task.status ? (
        <span className="task-row-status">
          <StatusMark word={task.status} className="task-row-chip" />
        </span>
      ) : task.status ? (
        // Under its status band the word is the band's; a screen reader still hears it.
        <span className="sr-only">{` · ${task.status}`}</span>
      ) : null}
      <span className="task-row-tools">
        <TaskRowMenu task={task} title={title} viewer={viewer} groups={groups} />
      </span>
      <span className="task-row-go" aria-hidden="true">
        {href ? <IconCaretRight size={12} /> : null}
      </span>
      {complete.state === "failed" ? <p className="task-problem t-footnote" role="alert">{complete.message}</p> : null}
      {starting.state === "failed" ? <p className="task-problem t-footnote" role="alert">{starting.message}</p> : null}
    </div>
  );
}
