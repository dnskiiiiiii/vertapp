"use client";

// components/month/MonthView.js — MONTH-END, THE ONE HOME PAGE
// ==============================================================================
// Spec §3.2; build plan §3 F3. One page, not two: the month's name and verdict, the
// progress bar, the ask box, the checklist grouped by the four words with Needs you
// first and its first decision open, and the sources in words at the foot. There is no
// separate Close page repeating the bar and the counts (§12.1).
//
// Four states, chosen by the payload alone (model.js monthState):
//   not_read     the month couldn't be read: said in words, with the ask box
//   not_started  "September hasn't started." and Start September
//   closed       "June was closed on 20 Oct." and its records to review; no Start
//   running      the checklist
//   done         "September is done. 5 of 5." with Done open
//
// Everything here is drawn from `month` (the `GET /close/{period}` body, or the export's
// recorded month) and `itemsByTask` (each needs-you task's open cards and questions,
// read from its conversation by app/page.js). This component fetches nothing and counts
// nothing.
//
// ITERATION 2 (build plan §4.6 FM):
//   · ABOVE THE FOLD, AT MOST FIVE IDEAS. The sources are no longer a line at the foot:
//     the client and the month are one chip on the title's line, which opens them
//     (MonthContext.js). Done stays folded to one line; the ask box offers at most three
//     suggestions, each naming only what the page already names (model.js
//     suggestionsFor).
//   · THE CATCH-UP. When `GET /close` says `catchUp.needed` — the month moved since a
//     task last ran — this page says so and offers Catch up; the press calls the
//     idempotent, capped `POST /close/{period}` (useCatchUp, below; never on load since
//     31 Oct 2026), says "Catching up on what changed…" while it runs, and then re-reads
//     the page so the header and the cards it lists come from the same new reading.
//     The page decides nothing about whether the month is behind and counts nothing:
//     both are the payload's.
//
// ITERATION 4 (build plan §20.6 F-POL4): `imports` — the budget import's open questions
// (lib/budgets.js importQuestions' `imports`) — may be handed in by a caller that has
// already read them; otherwise Needs you reads them itself after the first paint. Either
// way the same rows are drawn: the hand-in exists so the mid-close walk (tests/
// month-iter4-cards.test.js) sees the budget question on the server-rendered page, as
// a person sees it a moment later.

import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import AskBox from "./AskBox";
import Checklist from "./Checklist";
import CloseList from "./CloseList";
import { documentsNote } from "./close-list";
import MonthContext from "./MonthContext";
import MonthHeader from "./MonthHeader";
import NotStarted from "./NotStarted";
import ClosePanel, { PackDownloads, openTasksOf } from "./ClosePanel";
import DocumentsCard from "./DocumentsCard";
import { CLOSE_PANEL_STATES, lockNote, lockStatusOf } from "./close-step";
import Progress from "./Progress";
import { catchUpNeeded, changedAfterCloseOf, groupTasks, monthName, monthReadingOf, monthState, packAsAtOf, suggestionsFor, withReading } from "./model";
import { Button, Disclosure } from "@/components/ui";
import { startMonth } from "@/lib/actions";
import { callSafely } from "@/lib/decisions";
import { useMonthReading, useRecordMonth } from "@/lib/store";
import { formatDay } from "@/lib/format";
import { Segmented } from "@/components/ui";
import { IconAdd } from "@/components/ui/icons";
import Board from "@/components/home/Board";
import { summaryLine } from "@/components/home/rows";
import { useNewTask } from "@/components/home/newTask";
import { currentSearch, replaceSearch, viewFromSearch } from "./url-state";

import { IconCaretRight } from "@/components/ui/icons";
import { keepBoard, keptBoard, keptProps, staleWords, tabStorage } from "./last-good";

// A MONTH READ THAT TIMED OUT DRAWS THE LAST GOOD BOARD (staging browser walk 1, 31 Oct
// 2026, D2; components/month/last-good.js). `keep` is `{ key, failed }` from app/page.js:
// the signed-in client's key, and whether this load's `GET /close` failed in a way a
// second ask might not. A good read is kept for this tab; a failed one draws the kept
// board under "Couldn't refresh just now · as at <time>" and asks again once, in the
// background. The server renders the failure (it has no tab storage); the kept board is
// laid over it after the first frame.
export default function MonthView(props) {
  const kept = useKeptBoard(props);
  return <MonthBody {...(kept && !props.staleAt ? keptProps(props, kept) : props)} />;
}

function useKeptBoard({ keep, period, month, itemsByTask, runs, figures }) {
  const router = useRouter();
  const [kept, setKept] = useState(null);
  const retried = useRef(new Set());
  const key = keep && typeof keep.key === "string" ? keep.key : null;
  const failed = Boolean(keep && keep.failed === true);
  useEffect(() => {
    if (!key) return;
    if (!failed) {
      setKept(null);
      keepBoard(tabStorage(), key, period, { month, itemsByTask, runs, figures }, new Date().toISOString());
      return;
    }
    setKept(keptBoard(tabStorage(), key, period));
    // ONE BACKGROUND RE-READ per month per page: the page's own GET, nothing written.
    if (retried.current.has(period)) return;
    retried.current.add(period);
    router.refresh();
  }, [key, failed, period, month, itemsByTask, runs, figures, router]);
  return failed ? kept : null;
}

// "Couldn't refresh just now · as at 1:41 pm", over a kept board, with Try again.
function StaleNotice({ at }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  if (!at) return null;
  return (
    <div className="month-stale" data-month-stale="">
      <p className="month-stale-words t-footnote" role="status">
        {staleWords(at)}
      </p>
      <Button variant="secondary" size="sm" busy={pending} busyLabel="Reading…" onClick={() => startTransition(() => router.refresh())} data-month-retry="">
        Try again
      </Button>
    </div>
  );
}

function MonthBody({
  month: served,
  period,
  itemsByTask = {},
  ledger = null,
  clientName = null,
  disabledReason = null,
  unreadReason = null,
  canRetry = false,
  canCatchUp = false,
  viewer = null,
  imports = undefined,
  figures = null,
  // Whether the engine reads files, read by app/page.js on the server: the ask box never
  // asks it from the browser, where it was a server action (a POST) on every page view.
  documentsEnabled = false,
  // THE HOMEPAGE IS THE BOARD (founders, 22 Oct 2026; components/home/Board.js). app/page.js
  // asks for it with `initialView="board"`; the month-end checklist below is one press
  // away (the View switch, `?view=checklist`). A caller that names no view gets the
  // checklist exactly as it always drew, with no switch.
  initialView = undefined,
  // Each read conversation's latest run, by session id (month-reads.js readOpenItems),
  // for the board's lines and step bars.
  runs = {},
  // STEP 5, SIGN OFF AND LOCK (W4, 29 Oct 2026; ClosePanel.js): `{ status, words, sample }`,
  // the engine's lock status for this month as app/page.js read it on the server (null
  // when it wasn't read, `words` saying why). A caller that hands none draws no panel.
  close = undefined,
  // The time a kept board was read, when this is one (MonthView, above), else null.
  staleAt = null,
  // THE MONTH'S DOCUMENTS (w33, audit 1.1; DocumentsCard.js): `{ body, words, sample }`
  // as app/page.js read GET /close/{period}/documents. A caller that hands none draws
  // no card.
  monthDocuments = undefined,
}) {
  // The server's month, with the counts and task rows of any newer reading a write
  // answered with laid over it (model.js withReading; lib/store.js useMonthReading). The
  // sidebar badge takes the same reading, so the three counts move as one (e2e r3 D1).
  const reading = useMonthReading(served);
  const month = withReading(served, reading);
  const state = monthState(month);
  const recount = useRecount(served, reading);
  // WHAT THE CLOSE PANEL'S LAST PRESS LEFT THE MONTH AS (staging browser walk 4, W4-10).
  // The month was read before the sign-off, so it still said `catchUp.needed` and
  // "Trial balance review out of date · Catch up" stayed under the signed-off panel until
  // a reload. A server reading that says something new about the month replaces it.
  const [liveClose, setLiveClose] = useState(null);
  const closeKey = close && close.status && typeof close.status === "object" ? `${close.status.step}|${close.status.signedOff}|${close.status.reopened}` : "";
  useEffect(() => setLiveClose(null), [closeKey]);
  const signedOff = closeSignedOff(liveClose || lockStatusOf(close && close.status));
  const catchUp = useCatchUp(served, period, canCatchUp && !disabledReason, { signedOff });
  const catchingUp = catchUp.working;
  // Between a decision and its re-read, and while the month catches up, the counts in
  // hand describe cards as they were: the rows hold theirs back too.
  const holding = recount.recounting || catchingUp;
  // MID-CLOSE, THE SOURCES STRIP IS NOT DRAWN (eval iter2 polish, S4; build plan §19.3
  // W0d). While a decision waits, "3 of 5 sources behind · Sync now" under the ask box
  // was one of the five ideas above the fold on every screen, beside cards that had
  // nothing to do with a source. It is not hidden from anyone: the context chip keeps
  // its dot and says "Some sources are behind" (MonthContext.js), and its sheet says
  // which, with the one Sync now. Once nothing needs you, the strip comes back.
  const deciding = state === "running" && groupTasks(month).groups["Needs you"].length > 0;
  const ledgerName = ledger && ledger.configured === true && typeof ledger.displayName === "string" ? ledger.displayName : null;
  const boardable = initialView === "board" || initialView === "checklist";
  const [view, chooseView] = useHomeView(boardable ? initialView : "checklist");
  const newTask = useNewTask({ month, period, viewer });
  const context = state === "not_read" ? null : <MonthContext month={month} period={period} clientName={clientName} disabledReason={disabledReason} />;
  const switcher = boardable ? (
    <Segmented
      size="sm"
      label="View"
      className="month-view-switch"
      options={[
        { value: "board", label: "Close" },
        { value: "checklist", label: "Tasks" },
      ]}
      value={view}
      onChange={chooseView}
    />
  ) : null;

  if (boardable && view === "board") {
    const canAdd = newTask.available && (state === "running" || state === "done" || state === "not_started");
    return (
      <div className="month month-board-view" data-month-state={state} data-month-view="board" data-catching-up={catchingUp ? "true" : undefined}>
        <MonthHeader
          month={month}
          period={period}
          recounting={recount.recounting}
          catchingUp={catchingUp}
          context={context}
          // ONE COUNT ON THE PAGE (founder's walk, 8 Nov 2026): "8 need you · 3 done of 16"
          // stood over a list of 19 rows and a sidebar badge of 6. The Close view's list
          // says each job's state; the header says only that it is recounting.
          summary={recount.recounting || catchingUp ? summaryLine(month, { recounting: recount.recounting, catchingUp }) : null}
          tools={
            <>
              {switcher}
              {canAdd ? (
                <Button variant="secondary" size="sm" icon={<IconAdd />} onClick={(event) => newTask.open(event.currentTarget)} aria-haspopup="dialog" data-new-task="" className="month-new-task">
                  <span className="month-new-task-label">New task</span>
                </Button>
              ) : null}
            </>
          }
        />
        {state === "not_read" ? <NotRead reason={unreadReason} canRetry={canRetry} /> : null}
        <StaleNotice at={staleAt} />
        <RoleNotice month={served} />
        <CatchUpOffer month={served} catchUp={catchUp} />
        {state === "not_read" ? null : <ChangedAfterClose month={served} open={monthIsOpenAgain(close, liveClose)} />}
        {state === "not_started" ? <NotStarted month={month} period={period} disabledReason={disabledReason} /> : null}
        {state === "closed" ? <ClosedMonth month={month} period={period} /> : null}
        <AskBox
          period={period}
          suggestions={suggestionsFor(month, period)}
          disabledReason={disabledReason ? "This is a sample month, so there's nobody here to answer." : null}
          month={state === "not_read" ? null : month}
          syncDisabledReason={disabledReason}
          showTray={!deciding && state !== "not_started" && state !== "closed"}
          documentsEnabled={documentsEnabled}
        />
        {/* THE CLOSE LIST (founder, 8 Nov 2026): the five steps the founders close the books
            by, each job one press from its work in the chat. The month's tasks by status
            are folded under it. */}
        {state !== "not_read" && state !== "closed" ? (
          <CloseList
            month={month}
            period={period}
            disabledReason={disabledReason}
            // The documents checklist and the sign-off panel open under their own rows
            // (founder, 8 Nov 2026), not as two more cards under the list.
            panels={{
              documents: monthDocuments && period ? <MonthDocuments documents={monthDocuments} state={state} period={period} checkOnOpen /> : null,
              pack: period && state !== "not_read" ? (
                <section className="close-panel" data-pack-panel="" aria-label="The month-end pack">
                  <div className="close-panel-body">
                    <p className="close-panel-words">Executive summary, profit and loss, balance sheet, cash flow, trial balance and aged balances, as a PDF snapshot or Excel.</p>
                  </div>
                  <PackDownloads period={period} asAt={packAsAtOf(month)} open={openTasksOf(month)} />
                </section>
              ) : null,
              lock: CLOSE_PANEL_STATES.has(state) && close ? <CloseStep close={close} state={state} period={period} ledgerName={ledgerName} asAt={packAsAtOf(month)} onStatus={setLiveClose} open={openTasksOf(month)} /> : null,
            }}
            notes={{ documents: documentsNote(monthDocuments && monthDocuments.body), lock: lockNote(liveClose || (close && close.status)) }}
          />
        ) : null}
        {state === "running" || state === "done" || state === "not_started" ? (
          <Disclosure summary="All tasks" className="month-all-tasks">
            <Board month={month} period={period} itemsByTask={itemsByTask} runs={runs} figures={figures || {}} disabledReason={disabledReason} />
          </Disclosure>
        ) : null}
        {state === "done" ? <WorkpapersLink month={month} /> : null}
        {state === "not_read" || state === "closed" ? (
          <>
            <MonthDocuments documents={monthDocuments} state={state} period={period} />
            <CloseStep close={close} state={state} period={period} ledgerName={ledgerName} asAt={packAsAtOf(month)} onStatus={setLiveClose} open={openTasksOf(month)} />
          </>
        ) : null}
        {newTask.element}
      </div>
    );
  }

  return (
    <div className="month" data-month-state={state} data-month-view={boardable ? "checklist" : undefined} data-catching-up={catchingUp ? "true" : undefined}>
      <MonthHeader
        month={month}
        period={period}
        recounting={recount.recounting}
        catchingUp={catchingUp}
        context={context}
        tools={switcher}
      />
      {state === "not_read" ? <NotRead reason={unreadReason} canRetry={canRetry} /> : null}
      <StaleNotice at={staleAt} />
      <RoleNotice month={served} />
      <CatchUpOffer month={served} catchUp={catchUp} />
      {state === "not_read" ? null : <ChangedAfterClose month={served} open={monthIsOpenAgain(close, liveClose)} />}
      {state === "not_started" ? <NotStarted month={month} period={period} disabledReason={disabledReason} /> : null}
      {state === "closed" ? <ClosedMonth month={month} period={period} /> : null}
      {/* Design pass §7.2 (Calm neutral, 9 Oct 2026): the title, then the progress strip
          unboxed under it, then the one prompt, then the one raised decision card and the
          checklist — "one prompt, one bar, one queue". */}
      {state === "running" || state === "done" ? <Progress month={month} /> : null}
      <AskBox
        period={period}
        suggestions={suggestionsFor(month, period)}
        disabledReason={disabledReason ? "This is a sample month, so there's nobody here to answer." : null}
        month={state === "not_read" ? null : month}
        syncDisabledReason={disabledReason}
        showTray={!deciding && state !== "not_started" && state !== "closed"}
        documentsEnabled={documentsEnabled}
      />
      {state === "running" || state === "done" ? (
        <Checklist
          month={month}
          period={period}
          itemsByTask={itemsByTask}
          ledger={ledger}
          ledgerName={ledgerName}
          clientName={clientName}
          disabledReason={disabledReason}
          doneOpen={state === "done"}
          recounting={holding}
          onDecided={recount.start}
          viewer={viewer}
          imports={imports}
          figures={figures}
        />
      ) : null}
      {state === "done" ? <WorkpapersLink month={month} /> : null}
      <MonthDocuments documents={monthDocuments} state={state} period={period} />
      <CloseStep close={close} state={state} period={period} ledgerName={ledgerName} asAt={packAsAtOf(month)} onStatus={setLiveClose} open={openTasksOf(month)} />
    </div>
  );
}

// The close checklist's Step 1 (w33): what's in and what's missing for the month shown.
function MonthDocuments({ documents, state, period, checkOnOpen = false }) {
  if (!documents || state === "not_read" || !period) return null;
  return <DocumentsCard key={period} period={period} initial={documents.body || null} unreadWords={documents.words || null} sample={documents.sample === true} checkOnOpen={checkOnOpen} />;
}

// STEP 5 OF THE CLOSE LIST (W4, 29 Oct 2026): the statements, the month-end pack and Sign
// off and lock, for a month that has started or was closed. A month not read, or not
// started, has nothing to sign off; the panel isn't drawn for it.
function CloseStep({ close, state, period, ledgerName, asAt = null, onStatus = null, open = null }) {
  if (!close || !CLOSE_PANEL_STATES.has(state)) return null;
  return <ClosePanel period={period} initial={close.status || null} unreadWords={close.words || null} sample={close.sample === true} ledgerName={ledgerName} asAt={asAt} onStatus={onStatus} open={open} />;
}

/**
 * Which of the homepage's two views is drawn, and the way to choose. The board unless the
 * address asks for the checklist (url-state.js `?view=checklist`, or any of the
 * checklist's own keys). Read after mount, like the checklist's own view (the static
 * build prerenders this page); written with history.replaceState, so a choice survives a
 * reload and never re-reads the month. Choosing the board drops the checklist's keys, so
 * a reload lands on the board that was chosen.
 */
function useHomeView(initial) {
  const [view, setView] = useState(initial);
  useEffect(() => {
    if (viewFromSearch(currentSearch()).view === "checklist") setView("checklist");
  }, []);
  const choose = useCallback((next) => {
    const value = next === "board" ? "board" : "checklist";
    setView(value);
    replaceSearch(value === "board" ? { view: null, decision: null, query: "", filter: "all", by: null } : { view: "checklist" });
  }, []);
  return [view, choose];
}

// A PERSON WITH NO ROLE IS TOLD SO BEFORE THEY PRESS (verify pass 2, P06). The engine's
// `GET /close` sends `roleNotice`, the sentence a signed-in person with no role at a firm
// that has an admin reads: they are held to drafting. Before, they learned it only from a
// refusal at the moment they pressed Approve or opened payroll. One quiet line under the
// title; nothing when the engine sends none (a sample month carries `roleNotice: null`).
export function roleNoticeOf(month) {
  const n = month && typeof month === "object" ? month.roleNotice : null;
  return typeof n === "string" && n.trim() ? n.trim() : null;
}

function RoleNotice({ month }) {
  const words = roleNoticeOf(month);
  if (!words) return null;
  return (
    <p className="month-role-notice t-footnote ink-2" role="note" data-role-notice="">
      {words}
    </p>
  );
}

// A CLOSED MONTH THAT MOVED IS SAID ON ITS OWN PAGE (verify pass 4, S-BK-6), in every
// state the month can be read in: June "hasn't started" here (nobody ran its checklist)
// and was still closed in the ledger, and a bill dated 15 Jun arrived after. The engine's
// sentence, then its lines — account, day and amount — so the warning names the entry.
/**
 * Whether the month's lock status (`close`, as app/page.js read it) says it was reopened
 * and isn't signed off again: an open month (staging browser walk 3, W3-2). Pure.
 */
export function monthIsOpenAgain(close, live = null) {
  // What the sign-off panel's last press left the month as wins over the read from before
  // it (lead LX-3: right after Reopen the board still said "reopen it" until a re-read).
  if (live && typeof live === "object" && typeof live.signedOff === "boolean") {
    return live.reopened === true && live.signedOff === false;
  }
  const s = close && close.status;
  return Boolean(s && typeof s === "object" && s.reopened === true && s.signedOff === false);
}

function ChangedAfterClose({ month, open = false }) {
  const changed = changedAfterCloseOf(month, { open });
  if (!changed) return null;
  return (
    <div className="notice notice-warning month-changed" role="note" data-changed-after-close={changed.measured ? "measured" : "unread"}>
      <div className="notice-body">
        <p className="notice-text">{changed.words}</p>
        {changed.lines.length ? (
          <ul className="month-changed-lines t-footnote">
            {changed.lines.map((l) => (
              // "Office expenses, 15 Jun: $777.77 added"
              // The account's name is cut to the room left on its line, its whole name in
              // the title (S-UI-3: a 191-character name ran five lines at 390); the day,
              // amount and how stay whole after it.
              <li key={l.key} data-changed-line={l.key}>
                <span className="month-changed-account" title={l.account || undefined} translate="no">
                  {l.account || "An account"}
                </span>
                <span className="month-changed-rest">
                  {l.day ? `, ${formatDay(l.day)}` : ""}
                  {l.amount ? (
                    <>
                      {": "}
                      <span className="num" translate="no">{l.amount}</span>
                    </>
                  ) : null}
                  {l.how ? <span className="ink-2">{` ${l.how}`}</span> : null}
                </span>
              </li>
            ))}
          </ul>
        ) : null}
      </div>
    </div>
  );
}

// A MONTH THAT COULDN'T BE READ IS ASKED FOR AGAIN WITH ONE PRESS (ui-pass-1 #31, U42).
// "This month couldn't be read just now. Nothing was changed." used to be the whole page:
// the only way back was the browser's reload, which a person who reads "just now" as
// "try later" does not think of. Try again re-runs the server read (the page's
// `GET /close`), which is where the month comes from; it writes nothing, so it is the
// quiet secondary button, never the commit. While the read runs the button says so
// ("Reading…", aria-busy), so a press shows within a frame (A11 latency). It is drawn
// only when the page says a read was attempted and failed (`canRetry`): a sample build
// with no month, or a client with no month started, has nothing a second read would find.
function NotRead({ reason, canRetry }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  return (
    <div className="month-unread" data-month-unread="">
      <p className="month-verdict t-callout" role={canRetry ? "alert" : undefined}>
        {reason || "This month hasn't been read yet."}
      </p>
      {canRetry ? (
        <Button variant="secondary" size="sm" busy={pending} busyLabel="Reading…" onClick={() => startTransition(() => router.refresh())} data-month-retry="">
          Try again
        </Button>
      ) : null}
    </div>
  );
}

//: How long the catch-up line waits for the page's re-read after a catch-up before it
//: shows the counts it has again. The POST itself is capped by the API.
export const CATCH_UP_GIVE_UP_MS = 15_000;

/**
 * Whether `POST /close/{period}` should be called for this server month: the payload
 * asks (model.js catchUpNeeded), the page may write (`allowed`: never in the static
 * build, which has no service), and this page has not already asked for this month.
 * Pure, so the "once" is tested without a browser. A month signed off (and not reopened
 * since) is never asked (walk 4, W4-10), whatever the month read before the sign-off said.
 */
export function shouldCatchUp(month, period, allowed, asked, { signedOff = false } = {}) {
  if (!allowed || signedOff || !catchUpNeeded(month)) return false;
  const key = catchUpKey(month, period);
  return Boolean(key) && !(asked && asked.has(key));
}

/** Whether a lock status (close-step.js lockStatusOf) is a month signed off now. Pure. */
export function closeSignedOff(status) {
  return Boolean(status && typeof status === "object" && status.signedOff === true);
}

/**
 * WHICH CATCH-UP A PRESS WAS FOR (engine w3/int): the month, the engine's reason and
 * tasks, and its decision count. A press is asked once per reading; a decision made after
 * it (POST /journal/{id}/approve, reject or withdraw) moves the month, and the next GET's
 * `catchUp` (reason `decided` or `changed`) is a new reading the page offers again.
 * Null without a month. Pure.
 */
export function catchUpKey(month, period) {
  const key = (month && month.period) || period;
  if (!key) return null;
  const c = month && month.catchUp && typeof month.catchUp === "object" ? month.catchUp : {};
  const tasks = Array.isArray(c.tasks) ? c.tasks.filter((t) => typeof t === "string").join(",") : "";
  const decisions = month && month.counts && Number.isInteger(month.counts.decisions) ? month.counts.decisions : "";
  return `${key}|${c.reason || ""}|${tasks}|${decisions}`;
}

/**
 * Run the catch-up once: record that this month was asked, call `POST /close`, hand its
 * reading to the store (so the sidebar badge moves with the header), and ask for the
 * page again so the cards are redrawn from the same reading. Returns whether the POST
 * landed. Its collaborators are passed in so a test can run it with fakes.
 */
export async function runCatchUp({ month, period, asked, start, recordMonth, refresh }) {
  const key = (month && month.period) || period;
  asked.add(catchUpKey(month, period));
  const result = await callSafely(start, key);
  if (!result || !result.ok) return false;
  const reading = monthReadingOf(result);
  if (reading) recordMonth(reading);
  refresh();
  return true;
}

// THE CATCH-UP IS A PRESS (staging browser walk 1, 31 Oct 2026, D1). It used to be called
// from this hook's effect on every page view of a month that said `catchUp.needed`: each
// Month-end load re-ran the misclassification scan (~38 runs in 55 min, each re-reading
// the ledger) until Xero's daily limit for the org ran out and the board read "Xero's
// transactions not read". A page load only reads. A behind month says so and offers
// Catch up (CatchUpOffer, below); `run` is that press, and the only caller of the POST.
// Once per month per page: if the POST lands and the re-read STILL says behind (the
// API's cap stopped it part way), the page shows that reading's counts rather than
// offering the press again. A POST that failed offers it again, with the reason.
function useCatchUp(served, period, allowed, { signedOff = false } = {}) {
  const router = useRouter();
  const recordMonth = useRecordMonth();
  const asked = useRef(new Set());
  const [working, setWorking] = useState(false);
  const [failed, setFailed] = useState(false);
  // One press, every round (9 Nov 2026): the API plays tasks for 5 s a call, so October's
  // seven took three presses and the founder would have read "5 tasks need re-running"
  // after pressing Re-run as a failure. A press keeps going while each round leaves fewer
  // tasks behind (keepCatchingUp), and stops the first time one doesn't.
  const press = useRef(null);
  const [round, setRound] = useState(0);
  const seen = useRef(served);

  const go = useCallback((month) => {
    const key = catchUpKey(month, period);
    setWorking(true);
    setFailed(false);
    setRound((n) => n + 1);
    runCatchUp({ month, period, asked: asked.current, start: startMonth, recordMonth, refresh: () => router.refresh() }).then((landed) => {
      if (landed) return;
      asked.current.delete(key);
      press.current = null;
      setWorking(false);
      setFailed(true);
    });
  }, [period, recordMonth, router]);

  useEffect(() => {
    if (served === seen.current) return;
    seen.current = served;
    const next = keepCatchingUp(press.current, served) && shouldCatchUp(served, period, allowed, asked.current, { signedOff });
    if (next) {
      press.current = { rounds: press.current.rounds + 1, left: catchUpLeft(served) };
      go(served);
      return;
    }
    press.current = null;
    setWorking(false);
  }, [served, period, allowed, signedOff, go]);

  useEffect(() => {
    if (!working) return undefined;
    const timer = setTimeout(() => { press.current = null; setWorking(false); }, CATCH_UP_GIVE_UP_MS);
    return () => clearTimeout(timer);
  }, [working, round]);

  const run = useCallback(() => {
    if (working || !shouldCatchUp(served, period, allowed, asked.current, { signedOff })) return;
    press.current = { rounds: 1, left: catchUpLeft(served) };
    go(served);
  }, [working, served, period, allowed, signedOff, go]);

  const offered = !working && shouldCatchUp(served, period, allowed, asked.current, { signedOff });
  return { working, offered, failed, run };
}

/** How many tasks the engine names as behind; 0 when none are named. Pure. */
export function catchUpLeft(month) {
  const tasks = month && month.catchUp && Array.isArray(month.catchUp.tasks) ? month.catchUp.tasks : [];
  return tasks.filter((t) => typeof t === "string" && t).length;
}

//: The most rounds one Re-run press plays (each is one capped POST and one re-read).
export const CATCH_UP_ROUNDS = 6;

/**
 * Whether a Re-run press goes another round on this re-read: a press is under way, the
 * month still names tasks behind, and fewer than before the last round (so a task that
 * can't be brought up to date ends the press rather than looping). Pure.
 */
export function keepCatchingUp(press, month) {
  if (!press || !(month && month.catchUp && month.catchUp.needed === true)) return false;
  const left = catchUpLeft(month);
  return left > 0 && left < press.left && press.rounds < CATCH_UP_ROUNDS;
}

/** The tasks the engine says are behind, in words: "Misclassification scan" or "3 tasks". Pure. */
export function catchUpWords(month) {
  const named = Array.isArray(month && month.catchUp && month.catchUp.tasks) ? month.catchUp.tasks.filter((t) => typeof t === "string" && t) : [];
  const titles = named.map((template) => {
    const task = (month.tasks || []).find((t) => t && t.template === template);
    return task && typeof task.title === "string" && task.title.trim() ? task.title.trim() : null;
  });
  // Labels, not sentences (walk 2 copy list, N14: "…ran before the latest changes. They…").
  // Founder's walk (8 Nov 2026): "out of date" didn't say what happened, and "Catch up"
  // didn't say what the press does. What happened: the books changed after they ran.
  if (named.length === 1 && titles[0]) return `${titles[0]} needs re-running`;
  if (named.length > 1) return `${named.length} tasks need re-running`;
  return "Tasks need re-running";
}

// A BEHIND MONTH SAYS SO, AND WAITS FOR A PRESS. Nothing re-runs on its own: a re-run reads
// the ledger again, and every read counts against the ledger's daily limit.
function CatchUpOffer({ month, catchUp }) {
  if (!catchUp.offered) return null;
  return (
    <div className="month-catch-up" data-catch-up-offer="">
      <p className="month-catch-up-words t-footnote">
        {catchUpWords(month)}
        {catchUp.failed ? " · Didn't catch up" : null}
      </p>
      <Button variant="secondary" size="sm" onClick={catchUp.run} data-catch-up="">
        {catchUp.failed ? "Try again" : "Re-run"}
      </Button>
    </div>
  );
}

//: How long the header waits for the re-read before it shows the counts it has again.
//: Long enough for a slow render; short enough that a re-read that never came (a
//: network drop after the write landed) doesn't leave "Counting again…" up for good.
export const RECOUNT_GIVE_UP_MS = 15_000;

// BETWEEN A DECISION AND THE RE-READ (model.js RECOUNTING). A write that answered with
// the month needs no wait at all: its reading is drawn the moment it lands, so `start`
// is handed that reading and does nothing. Only a write that came back WITHOUT one (a
// settle that failed after the write landed, a question answered into a task the worker
// resumes later) holds the counts back, until the next server month or a reading
// arrives — whichever is first — or the give-up timer.
function useRecount(month, reading) {
  const [recounting, setRecounting] = useState(false);
  const seen = useRef(month);
  useEffect(() => {
    if (month === seen.current) return;
    seen.current = month;
    setRecounting(false);
  }, [month]);
  useEffect(() => {
    if (reading) setRecounting(false);
  }, [reading]);
  useEffect(() => {
    if (!recounting) return undefined;
    const timer = setTimeout(() => setRecounting(false), RECOUNT_GIVE_UP_MS);
    return () => clearTimeout(timer);
  }, [recounting]);
  const start = useCallback((carried = null) => {
    if (carried) return;
    setRecounting(true);
  }, []);
  return { recounting, start };
}

// "September is done" comes with the workpapers (spec §3.2 "Everything done").
// "Download workpapers" DOWNLOADS THEM (verify pass 3, S-E2E-6): it only opened the
// workpapers conversation, so the link named a download and gave a page. It is the
// month's binder, every delivered workbook in one zip (app/api/workpapers/binder),
// drawn once the workpapers task has run; the conversation stays one press away.
const PERIOD = /^[0-9]{4}-(0[1-9]|1[0-2])$/;
/**
 * A CLOSED MONTH OFFERS ITS REVIEW, NEVER A START (verify pass 7, S-BK-6). Its checklist
 * was never run and is not run now: Start would draft entries into a month whose entries
 * the engine refuses ("June 2026 is closed … Date the entry into an open month"). What a
 * closed month has is its books, so the one way on is to read them in Records.
 */
export function ClosedMonth({ month, period }) {
  const p = PERIOD.test(String(period || "")) ? period : typeof month.period === "string" && PERIOD.test(month.period) ? month.period : null;
  if (!p) return null;
  return (
    <div className="month-closed" data-month-closed="">
      <Link className="month-workpapers link t-body" href={`/records?period=${p}`}>
        Review {monthName(month, p)} in Records<IconCaretRight className="caret-trailing" />
      </Link>
    </div>
  );
}

export function WorkpapersLink({ month }) {
  const task = (month.tasks || []).find((t) => t && t.template === "workpapers" && t.sessionId);
  if (!task) return null;
  const period = typeof month.period === "string" && PERIOD.test(month.period) ? month.period : null;
  if (!period) {
    return (
      <Link className="month-workpapers link t-body" href={`/chat/${encodeURIComponent(task.sessionId)}`}>
        Open the workpapers<IconCaretRight className="caret-trailing" />
      </Link>
    );
  }
  return (
    <a className="month-workpapers link t-body" href={`/api/workpapers/binder?period=${period}`} download={`Workpapers binder ${period}.zip`} data-binder-download="">
      Download workpapers
    </a>
  );
}
