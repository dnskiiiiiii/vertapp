// components/month/Progress.js — HOW FAR THE MONTH HAS GOT
// ==============================================================================
// Spec §3.2; design pass §6.8 (Calm neutral, 9 Oct 2026). No card: a strip under the
// page title, one 6 px segmented bar (Done in its ink, the other words on their soft
// tints), sized by the payload's own counts, and one line of facts under it that says
// each word with its glyph and its count (StatusCounts; visible at rest since verify pass 1). Nothing is summed or derived here: every
// number is `month.counts` (the one-count rule, UI-001).
//
// UNMEASURED IS NEVER ZERO. If any of the four per-word counts is missing, the card
// falls back to the kit's done-of-total bar, which itself draws nothing without a total
// — a segment of width zero would read as "none" about a word nobody counted.

"use client";

import { useId } from "react";
import { ProgressBar, StatusCounts } from "@/components/ui";

const isCount = (n) => Number.isInteger(n) && n >= 0;

// Order matches the checklist's reading order of the work: what's finished, what Vert
// is doing, what needs a person, what waits on something else.
export const SEGMENTS = [
  { key: "done", word: "Done", tone: "done" },
  { key: "working", word: "Vert's working", tone: "working" },
  { key: "needsYou", word: "Needs you", tone: "attention" },
  { key: "waiting", word: "Waiting", tone: "neutral" },
];

/** The segments to draw, or null when any per-word count is unmeasured. Pure. */
export function progressSegments(counts) {
  if (!counts || !isCount(counts.total)) return null;
  if (!SEGMENTS.every((s) => isCount(counts[s.key]))) return null;
  return SEGMENTS.map((s) => ({ ...s, count: counts[s.key] }));
}

export default function Progress({ month }) {
  const c = month && month.counts;
  const tipId = useId();
  if (!c) return null;
  const segments = progressSegments(c);
  const label = `${c.done} of ${c.total} tasks done`;
  const shown = segments ? segments.filter((s) => s.count > 0) : [];
  return (
    <section className="month-strip" aria-label="Progress">
      {segments ? (
        <div className="month-bar-wrap">
          {/* DESIGN-FIX-2 (DA2-022): 6 px, 2 px gaps, no track. VERIFY PASS 1 F-8 (U53,
              U01): the words were only the bar's hover tooltip, so at rest the strip told
              its states apart by colour alone, and in forced colours it vanished. The
              counts line under it is visible now, each word with its glyph (design-pass
              spec §6.8), and the segments keep a shape in forced colours (month.css). */}
          <div className="month-bar" role="img" aria-label={label} aria-describedby={tipId}>
            {shown.map((s) => (
              <span key={s.key} className="month-bar-seg" data-tone={s.tone} style={{ flexGrow: s.count }} />
            ))}
          </div>
          <div id={tipId}>
            <StatusCounts counts={c} className="month-counts" />
          </div>
        </div>
      ) : (
        <ProgressBar done={c.done} total={c.total} label={label} className="month-progress" />
      )}
    </section>
  );
}
