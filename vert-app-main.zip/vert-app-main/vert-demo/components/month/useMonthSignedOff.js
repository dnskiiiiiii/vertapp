"use client";

// components/month/useMonthSignedOff.js — IS THIS ENTRY'S MONTH SIGNED OFF?
// ==============================================================================
// UI walk 2, N2 (30 Oct 2026): an entry approved before its month was signed off still
// offered "Post…" afterwards; the engine refused the post (the month is closed), and
// nothing had warned beforehand. A screen offering Post on an approved entry asks this
// first, so the press is drawn disabled with the reason instead (EntryDetail.js
// closedPostReason) — the same `GET /close/{period}/lock` the Journals page reads, here
// through the app's own route (lib/close-client.js readLockStatus): a GET, never a write.
//
// true, false, or null while not read (or unreadable): a lock not read gates nothing, and
// the engine stays the gate. Reads in flight for one month are shared, so a thread of
// cards for September asks once.

import { useEffect, useRef, useState } from "react";
import { readLockStatus } from "@/lib/close-client";
import { monthName } from "@/lib/period";
import { lockStatusOf } from "./close-step";

const PERIOD = /^[0-9]{4}-(0[1-9]|1[0-2])$/;
const inFlight = new Map();

/**
 * Why an approved entry can't be posted while its month is signed off, worded by what the
 * screen it is said on offers (UI walk 3, W3-3: "or reject and redraft" was said where no
 * Reject is). `undo`: "here" when the press beside it is Undo (the conversation's card),
 * "conversation" when Undo is one press away in its conversation (the Records sheet's
 * Open its conversation), null when nothing on the screen undoes the approval. Pure.
 *
 *   "September is signed off. To post this, reopen September on Month-end, or undo the
 *    approval and draft it again dated in an open month."
 */
export function closedPostReason(period, { undo = null } = {}) {
  const month = typeof period === "string" && PERIOD.test(period) ? monthName(period) : null;
  const reopen = month ? `reopen ${month} on Month-end` : "reopen its month on Month-end";
  const redraft =
    undo === "here"
      ? ", or undo the approval and draft it again dated in an open month"
      : undo === "conversation"
        ? ", or undo the approval in its conversation and draft it again dated in an open month"
        : "";
  return `${month || "Its month"} is signed off. To post this, ${reopen}${redraft}.`;
}

/**
 * Whether a refused write says the month is closed (UI walk 3, W3-2): the engine's 409
 * carries `detail.reason: "closed_month"` (lib/journal.js passes it on as `reason`), and
 * its sentence says "… is closed: it was signed off". The screen that offered the press
 * then reads the month's lock again, so the press is drawn held with its reason. Pure.
 */
export function closedMonthRefusal(result) {
  if (!result || typeof result !== "object" || result.ok) return false;
  if (result.reason === "closed_month" || result.code === "period_closed") return true;
  return typeof result.message === "string" && /\bis closed: it was signed off\b/.test(result.message);
}

/** Whether `period` is signed off, read once per month in flight: true | false | null. */
export function readSignedOff(period, options) {
  if (typeof period !== "string" || !PERIOD.test(period)) return Promise.resolve(null);
  const pending = inFlight.get(period);
  if (pending) return pending;
  const read = readLockStatus(period, options)
    .then((r) => {
      const status = r && r.ok ? lockStatusOf(r.body) : null;
      return status ? status.signedOff : null;
    })
    .catch(() => null)
    .finally(() => inFlight.delete(period));
  inFlight.set(period, read);
  return read;
}

/**
 * The hook: `period` is null until there is something to ask about. `reads` counts the
 * times the caller asks again (a refusal said the month is closed, W3-2): the month is
 * read again, and what was read stands until the new answer, so Post doesn't flicker.
 */
export function useMonthSignedOff(period, reads = 0) {
  const [signedOff, setSignedOff] = useState(null);
  const asked = useRef(null);
  useEffect(() => {
    let live = true;
    if (asked.current !== period) setSignedOff(null);
    asked.current = period;
    if (!period) return undefined;
    readSignedOff(period).then((v) => live && setSignedOff(v));
    return () => {
      live = false;
    };
  }, [period, reads]);
  return signedOff;
}
