// components/month/url-state.js — THE CHECKLIST'S VIEW AND THE DECISION PAGE, IN THE ADDRESS
// ==============================================================================
// Design-fix-2 DA2-080 (WIG "URL reflects state"). "Assigned to you", the search and
// the group cut were lost on reload (the cut lived only in localStorage), and the decision
// pager's page could not be linked to. They now live in the query:
//
//   ?show=assigned   the checklist narrowed to your tasks   (absent: all tasks)
//   ?group=group     cut by group                           (absent: by status)
//   ?q=bank          the search                             (absent: none)
//   ?decision=3      the decision pager's third page        (absent: the first)
//   ?view=checklist  the month-end checklist, not the board  (absent: the board, the
//                    homepage; any of the checklist's own keys above opens it too, so a
//                    link to a narrowed list or a decision page lands where it points)
//
// READ FROM THE ADDRESS AFTER MOUNT, WRITTEN WITH history.replaceState. Not
// `useSearchParams`, for the reason ConversationView gives for `?sheet=`: the static
// build prerenders Month-end, and `useSearchParams` there needs a Suspense boundary the
// page does not have. Not `router.replace` either: on this server-rendered page that
// re-reads the month from the engine on every keystroke of a search. The App Router
// keeps its own state in step with `history.replaceState` (Next 14.1+), so a later
// `router.refresh()` keeps the query. Default values are removed, so a plain Month-end
// stays `/`. Pure helpers first, so the mapping is tested without a browser.

const KEYS = Object.freeze({ show: "show", group: "group", q: "q", decision: "decision", view: "view" });

/** The checklist's view from a query string: `{ filter, by, query }`, each defaulted. Pure. */
export function viewFromSearch(search) {
  const p = new URLSearchParams(typeof search === "string" ? search : "");
  const q = p.get(KEYS.q);
  return {
    filter: p.get(KEYS.show) === "assigned" ? "mine" : "all",
    by: p.get(KEYS.group) === "group" ? "group" : p.get(KEYS.group) === "status" ? "status" : null,
    query: typeof q === "string" ? q.slice(0, 200) : "",
    view: p.get(KEYS.view) === "checklist" || [KEYS.show, KEYS.group, KEYS.q, KEYS.decision].some((k) => p.has(k)) ? "checklist" : null,
  };
}

/** The decision page asked for, 1-based, or null. Pure. */
export function decisionFromSearch(search) {
  const raw = new URLSearchParams(typeof search === "string" ? search : "").get(KEYS.decision);
  if (!raw || !/^\d{1,4}$/.test(raw)) return null;
  const n = Number.parseInt(raw, 10);
  return n >= 1 ? n : null;
}

/**
 * The query string with `changes` applied: a value of null, "", or the default removes
 * the key. Returns "" or "?…". Pure.
 */
export function searchWith(search, changes) {
  const p = new URLSearchParams(typeof search === "string" ? search : "");
  const set = (key, value, fallback) => {
    if (value === null || value === undefined || value === "" || value === fallback) p.delete(key);
    else p.set(key, String(value));
  };
  if ("filter" in changes) set(KEYS.show, changes.filter === "mine" ? "assigned" : null, null);
  if ("by" in changes) set(KEYS.group, changes.by, "status");
  if ("query" in changes) set(KEYS.q, typeof changes.query === "string" ? changes.query.trim() : "", "");
  if ("decision" in changes) set(KEYS.decision, changes.decision, 1);
  if ("view" in changes) set(KEYS.view, changes.view === "checklist" ? "checklist" : null, null);
  const out = p.toString();
  return out ? `?${out}` : "";
}

/** Read the current address's query, or "" off the browser. */
export function currentSearch() {
  return typeof window !== "undefined" && window.location ? window.location.search : "";
}

/** Put `changes` into the address without a navigation. Never throws. */
export function replaceSearch(changes) {
  if (typeof window === "undefined" || !window.history || !window.location) return;
  try {
    const next = searchWith(window.location.search, changes);
    if (next === window.location.search || (next === "" && window.location.search === "")) return;
    window.history.replaceState(window.history.state, "", `${window.location.pathname}${next}${window.location.hash}`);
  } catch {
    // A sandboxed frame can refuse history writes; the view still works, unlinked.
  }
}
