"use client";

// components/month/CloseList.js — THE CLOSE, AS FIVE STEPS ON MONTH-END
// ==============================================================================
// Founder, 8 Nov 2026: Month-end is the list the founders close the books by, five
// steps, one row per job (close-list.js holds the list and the rules). Each row is the
// job, its status when Vert has a task for it, and one press:
//
//   Start    asks Vert to do the job in a new chat, which opens with the work drawn
//            inline (the press reads "Starting…" while the conversation is made);
//   Open     the job's conversation, already under way or done;
//   Answer   the same, when it waits on you.
//
// Nothing is counted on this card: a status is the engine's word or not drawn.

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, StatusMark } from "@/components/ui";
import { startConversation } from "@/lib/agent/actions";
import { callSafely } from "@/lib/decisions";
import { askFailureWords, askPeriod } from "./AskBox";
import { useShellReading } from "@/components/shell/live-shell";
import { readGrid } from "@/lib/cash-coding-client";
import { cashCodingNote, closeList } from "./close-list";

/**
 * `panels`: a job whose work Month-end already draws (the documents checklist, the
 * sign-off panel) opens it under its row instead of going anywhere (founder, 8 Nov 2026:
 * the same job was a row and, further down, a card of its own). `notes`: the row's words
 * from what that panel read ("2 missing", "Set the lock date"), when no task gives it a
 * status.
 */
export default function CloseList({ month, period, disabledReason = null, panels = {}, notes = {} }) {
  const router = useRouter();
  const [starting, setStarting] = useState(null);
  const [opened, setOpened] = useState(null);
  const [failed, setFailed] = useState(null);
  const shell = useShellReading();
  // The Cash coding row's state, read for the month shown (it has no task of its own).
  const [coding, setCoding] = useState(null);
  useEffect(() => {
    let live = true;
    setCoding(null);
    if (!period || disabledReason) return undefined;
    readGrid({ period }).then((got) => {
      if (live && got && got.ok) setCoding(cashCodingNote(got.body));
    });
    return () => {
      live = false;
    };
  }, [period, disabledReason]);
  notes = coding && !notes.cash_coding ? { ...notes, cash_coding: coding } : notes;
  const steps = closeList(month, period, shell && Array.isArray(shell.conversations) ? shell.conversations : []);

  async function start(job) {
    if (starting || disabledReason) return;
    setStarting(job.key);
    setFailed(null);
    const result = await callSafely(startConversation, { period: askPeriod(period), text: job.ask });
    if (!result.ok || !result.sessionId) {
      setStarting(null);
      setFailed({ key: job.key, words: askFailureWords(result) });
      return;
    }
    router.push(`/chat/${encodeURIComponent(result.sessionId)}`);
  }

  return (
    <section className="close-list" data-close-list="" aria-label="Close the books">
      <ol className="close-steps">
        {steps.map((step, i) => (
          <li key={step.key} className="close-step-group" data-close-step={step.key}>
            <h2 className="close-step-title">
              <span className="close-step-n num" aria-hidden="true">
                {i + 1}
              </span>
              {step.title}
            </h2>
            <ul className="close-jobs">
              {step.jobs.map((job) => {
                const panel = panels[job.key] || null;
                const note = !job.status ? notes[job.key] || null : null;
                const open = panel && opened === job.key;
                return (
                <li key={job.key} className="close-job" data-close-job={job.key} data-status={job.status || (note && note.tone) || undefined} data-open={open ? "true" : undefined}>
                  <span className="close-job-title">
                    {job.title}
                    {job.line ? <span className="close-job-line t-footnote">{job.line}</span> : null}
                  </span>
                  <span className="close-job-status">
                    {job.status ? <StatusMark word={job.status} /> : note ? <span className="close-job-note" data-tone={note.tone || undefined}>{note.words}</span> : null}
                  </span>
                  <span className="close-job-action">
                    {panel ? (
                      <Button variant={open ? "quiet" : "secondary"} size="sm" aria-expanded={open ? "true" : "false"} onClick={() => setOpened(open ? null : job.key)} data-close-open={job.key}>
                        {open ? "Close" : "Open"}
                      </Button>
                    ) : job.href ? (
                      <Button href={job.href} variant={job.action === "Answer" ? "secondary" : "quiet"} size="sm">
                        {job.action}
                      </Button>
                    ) : (
                      <Button variant="quiet" size="sm" busy={starting === job.key} busyLabel="Starting…" disabledReason={disabledReason || undefined} onClick={() => start(job)} data-close-start={job.key}>
                        {job.action}
                      </Button>
                    )}
                  </span>
                  {failed && failed.key === job.key ? (
                    <p className="close-job-failed" role="alert">
                      {failed.words}
                    </p>
                  ) : null}
                  {open ? <div className="close-job-panel">{panel}</div> : null}
                </li>
                );
              })}
            </ul>
          </li>
        ))}
      </ol>
    </section>
  );
}
