"use client";

// components/month/NewTaskProvider.js — ONE NEW-TASK FORM FOR THE WHOLE SHELL, AND openNewTask()
// ==============================================================================
// Founders, 22 Oct 2026: making a task is a first-class action, reached from the sidebar
// (beside New chat), from the Month-end toolbar, and from whatever the home page puts in
// its header. All of them open the SAME form (NewTaskSheet.js), mounted once here, so a
// draft typed from one is there when opened from another and nothing can drift into two
// forms.
//
// THE API A PAGE CALLS
//
//   const { openNewTask, available } = useNewTask();
//   openNewTask();                                          // the pick: presets + Start from scratch
//   openNewTask({ template: "accrual_schedule" });          // straight to its details, brief filled
//   openNewTask({ title, description, frequency: "monthly", period: "2026-09" });
//   openNewTask({ origin: event.currentTarget });            // grows out of what was pressed
//   openNewTask({ groups });                                // the month's groups, when the caller has them
//
// Outside React (or outside this provider) `openNewTask(options)` from this module sends
// the same request as a window event, `vert:new-task`, which the provider answers.
// `available` is false where no task can be made (no live service behind the page, or
// no client chosen): a caller draws no entry point then, never one that only refuses.
//
// THE GROUPS AND THE PRESETS are read on the press that opens the form, never in an
// effect (p0 quiet load: a page view sends nothing), and with a GET through
// app/api/tasks, never a Server Action (opening the form sent two `POST /`, walkthrough
// 27 Oct 2026). The presets are read once per page, the groups once until a form has them. A caller that has the month's groups
// (Month-end) hands them in; otherwise they are read then, and a failed read leaves the
// Group menu at "No group" and "New group…", which still work.

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import NewTaskSheet, { originFromTrigger, readPresets } from "./NewTaskSheet";

export const NEW_TASK_EVENT = "vert:new-task";

const NewTaskContext = createContext(null);

/** Ask the shell's form to open, from anywhere (the provider answers the event). */
export function openNewTask(options = {}) {
  if (typeof window === "undefined") return false;
  window.dispatchEvent(new CustomEvent(NEW_TASK_EVENT, { detail: options || {} }));
  return true;
}

/**
 * The client's task groups, through `GET /api/tasks?groups` (never the `listTaskGroups`
 * Server Action: that was a `POST /` on every open, walkthrough 27 Oct 2026). A read
 * that failed is no groups: the Group menu still offers No group and New group…, which
 * work. Never throws.
 */
export async function readTaskGroups(fetchImpl = globalThis.fetch) {
  try {
    const res = await fetchImpl("/api/tasks?groups", { cache: "no-store", headers: { accept: "application/json" } });
    const body = res && res.ok ? await res.json() : null;
    return body && body.ok === true && Array.isArray(body.groups) ? body.groups : [];
  } catch {
    return [];
  }
}

/** `{ openNewTask, available }`; outside the provider, the event form and not available. */
export function useNewTask() {
  return useContext(NewTaskContext) || { openNewTask, available: false };
}

/**
 * Whether a task can be made from this shell: a signed-in person (only a live service
 * has one), a client's month on screen, and not the firm's Clients view. Pure.
 */
export function canMakeTasks(shell, signedInAs, { firmMode = false } = {}) {
  return Boolean(signedInAs && shell && typeof shell.period === "string" && shell.period && !firmMode);
}

/** The options as the form takes them: a measured origin from an element, the rest as given. Pure over its inputs. */
export function openOptions(options, viewport) {
  const o = options && typeof options === "object" ? options : {};
  const { origin, ...rest } = o;
  let at = typeof origin === "string" ? origin : null;
  if (origin && typeof origin === "object" && typeof origin.getBoundingClientRect === "function" && viewport) {
    at = originFromTrigger(origin.getBoundingClientRect(), viewport);
  }
  return { ...rest, origin: at };
}

export function NewTaskProvider({ shell = null, signedInAs = null, firmMode = false, children }) {
  const available = canMakeTasks(shell, signedInAs, { firmMode });
  const [open, setOpen] = useState(false);
  // Not in the page's markup until first asked for (a closed form's commit would be an
  // accent there); then kept mounted, so a close and a re-open are one transition (U37).
  const [mounted, setMounted] = useState(false);
  const [request, setRequest] = useState(null);
  const [groups, setGroups] = useState(null);
  // undefined while reading, null when the read failed, else the list.
  const [presets, setPresets] = useState(undefined);
  const askPresets = useCallback(() => {
    setPresets(undefined);
    readPresets().then(setPresets);
  }, []);
  const [draft, setDraft] = useState(null);
  const returnTo = useRef(null);

  const show = useCallback(
    (options = {}) => {
      if (!available) return false;
      const viewport = typeof window === "undefined" ? null : { width: window.innerWidth, height: window.innerHeight };
      const o = openOptions(options, viewport);
      returnTo.current = typeof document !== "undefined" ? document.activeElement : null;
      if (Array.isArray(o.groups)) setGroups(o.groups);
      else if (!groups) {
        readTaskGroups().then(setGroups);
      }
      if (!Array.isArray(presets)) askPresets();
      // Handed nothing but where it grew from, the form opens on the kept draft.
      const asks = Boolean(o.template || o.title || o.description || o.step || o.frequency || o.period);
      setRequest(asks ? { ...o } : { origin: o.origin });
      setMounted(true);
      setOpen(true);
      return true;
    },
    [available, groups, presets, askPresets]
  );

  useEffect(() => {
    if (!available || typeof window === "undefined") return undefined;
    const onAsk = (event) => show((event && event.detail) || {});
    window.addEventListener(NEW_TASK_EVENT, onAsk);
    return () => window.removeEventListener(NEW_TASK_EVENT, onAsk);
  }, [available, show]);

  const close = useCallback(() => {
    setOpen(false);
    // Focus goes back to what opened it (WIG: a dialog returns focus on close).
    const back = returnTo.current;
    if (back && typeof back.focus === "function" && back.isConnected) window.setTimeout(() => back.focus(), 0);
  }, []);

  const value = useMemo(() => ({ openNewTask: show, available }), [show, available]);
  const initial = request && (request.template || request.title || request.description || request.step || request.frequency || request.period) ? request : null;

  return (
    <NewTaskContext.Provider value={value}>
      {children}
      {available && mounted ? (
        <NewTaskSheet
          open={open}
          onClose={close}
          period={shell.period}
          months={shell.months || []}
          groups={groups || []}
          presets={presets}
          onRetryPresets={askPresets}
          viewer={(signedInAs && signedInAs.person) || null}
          origin={request ? request.origin : null}
          draft={initial ? null : draft}
          onDraft={setDraft}
          initial={initial}
        />
      ) : null}
    </NewTaskContext.Provider>
  );
}
