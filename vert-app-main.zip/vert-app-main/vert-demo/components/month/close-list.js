// components/month/close-list.js — THE FOUNDER'S CLOSE LIST, FIVE STEPS
// ==============================================================================
// Founder, 8 Nov 2026: "this is the list we are trying to get through" — How to close
// the books, five steps, each a handful of jobs. Month-end draws it as the month's
// checklist (CloseList.js): each job one row, its status when Vert has a task for it,
// and one press. The press asks Vert to do the job in a chat, where the work is drawn
// inline (the cash coding grid, the aged receivables, the trial balance review…); a job
// whose task already has a conversation opens that conversation instead.
//
// A STATUS IS THE ENGINE'S OR NOTHING. A row shows the status word of the month's task
// it maps to (`GET /close`'s `tasks[].status`); a job Vert keeps no task for shows no
// status at all, never "Not started" or a tick it can't stand behind (an unread state is
// not a measured one). Nothing is counted here.
//
// Pure: the component draws what this returns, and tests hold the mapping.

import { periodLabel } from "@/lib/period";

/** The worst-first order of the four task words: the row shows the one that needs most. */
const RANK = { "Needs you": 0, "Vert's working": 1, Waiting: 2, Done: 3 };

/**
 * The five steps and their jobs. `templates` are the engine task templates whose status
 * the row shows (vert_engine/workflows/templates); `ask` is what the press asks Vert,
 * worded so the chat picks the tool that draws the job inline ({month} is the month's
 * name and year).
 */
export const CLOSE_STEPS = Object.freeze([
  {
    key: "capture",
    title: "Capture and code",
    jobs: [
      { key: "documents", title: "Collect documents", ask: "Which documents are missing for {month}?", templates: [] },
      { key: "bills", title: "Bills and invoices", ask: "Show the bill inbox for {month}", templates: [] },
      { key: "expenses", title: "Expenses and petty cash", ask: "Record petty cash and expense claims for {month}", templates: [] },
      { key: "cash_coding", title: "Cash coding", ask: "Complete cash coding for {month}", templates: [] },
    ],
  },
  {
    key: "reconcile",
    title: "Reconcile bank and cards",
    jobs: [
      { key: "bank_rec", title: "Bank and card reconciliation", ask: "Reconcile the bank for {month}", templates: ["bank_reconciliation", "card_reconciliation", "resolve_breaks", "payout_check"] },
      { key: "clearing", title: "Clear suspense and clearing accounts", ask: "Clear the suspense and clearing accounts for {month}", templates: ["clearing_accounts"] },
      { key: "bank_reports", title: "Bank reconciliation report", ask: "Show the bank reconciliation report for {month}", templates: [] },
    ],
  },
  {
    key: "review",
    title: "Subledgers and balance sheet",
    jobs: [
      { key: "receivables", title: "Receivables and overdue invoices", ask: "Show aged receivables for {month} and who to chase", templates: [] },
      { key: "payables", title: "Payables", ask: "Show aged payables for {month}", templates: [] },
      { key: "fixed_assets", title: "Fixed assets and depreciation", ask: "Run the fixed asset roll-forward and depreciation for {month}", templates: ["fixed_asset_rollforward", "fa_disposal"] },
      { key: "accruals", title: "Accruals and prepayments", ask: "Post accruals and prepayments for {month}", templates: ["accrual_schedule", "prepaid_schedule", "deferred_revenue", "amortization_schedule"] },
      { key: "payroll", title: "Payroll and super", ask: "Reconcile payroll and super for {month}", templates: ["payroll_reconciliation", "payroll_journal", "payroll_accrual"] },
      { key: "gl_recs", title: "Balance sheet reconciliations", ask: "Reconcile the balance sheet accounts for {month}", templates: ["gl_reconciliation", "balance_sheet_rollforward"] },
    ],
  },
  {
    key: "check",
    title: "Check for errors",
    jobs: [
      { key: "trial_balance", title: "Trial balance review", ask: "Review the trial balance for {month}", templates: ["unusual_balances"] },
      { key: "miscoding", title: "Miscoded transactions", ask: "Scan {month} for miscoded transactions", templates: ["misclassification_scan"] },
      { key: "feeds", title: "Integration feeds", ask: "Check the integration feeds for {month}", templates: ["integration_feeds"] },
    ],
  },
  {
    key: "publish",
    title: "Publish and lock",
    jobs: [
      { key: "statements", title: "Profit and loss, balance sheet, cash flow", ask: "Show the financial statements for {month}", templates: [] },
      // The month-end pack is Month-end's own download, opened under this row
      // (ClosePanel.js PackDownloads): no task's status stands for it.
      { key: "pack", title: "Reporting pack", ask: "Prepare the reporting pack for {month}", templates: [] },
      // Signing off is Month-end's own panel (ClosePanel.js), opened under this row.
      { key: "lock", title: "Sign off the month", ask: "Sign off {month}", templates: [] },
    ],
  },
]);

const chatHref = (id) => `/chat/${encodeURIComponent(String(id))}`;

/**
 * The job's row: `{ ...job, ask, status, href, action }`. `status` is the worst-first
 * status word of the month's tasks with one of its templates, or null when it has none;
 * `href` that task's conversation; `action` the press's label: "Answer" when it needs
 * you, "Open" when it has a conversation or a status, else "Start". Pure.
 */
/** The conversation a row's press already started: one titled with the row's ask (the
 * service titles a conversation from its first turn, cut at 60 characters), the newest
 * first. Pure. */
export function askedBefore(ask, conversations) {
  const want = String(ask || "").trim().toLowerCase();
  if (!want) return null;
  const same = (title) => {
    const t = String(title || "").trim().toLowerCase();
    if (!t) return false;
    if (t === want) return true;
    const cut = t.replace(/(…|\.\.\.)$/, "").trim();
    return cut !== t && cut.length >= 20 && want.startsWith(cut);
  };
  const hits = (Array.isArray(conversations) ? conversations : []).filter((c) => c && c.id && same(c.title));
  hits.sort((a, b) => (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0));
  return hits[0] || null;
}

export function closeJobRow(job, tasks, monthWords, conversations = []) {
  const mine = (Array.isArray(tasks) ? tasks : []).filter((t) => t && job.templates.includes(t.template) && Object.prototype.hasOwnProperty.call(RANK, t.status));
  mine.sort((a, b) => RANK[a.status] - RANK[b.status]);
  const lead = mine[0] || null;
  const ask = job.ask.replace("{month}", monthWords);
  // ONE CONVERSATION PER JOB (founder's walk, 8 Nov 2026): a row Vert keeps no task for
  // read "Start" after it was started, and each press made another conversation. The
  // conversation it started is opened instead.
  const before = askedBefore(ask, conversations);
  const session = lead && (typeof lead.sessionId === "string" || typeof lead.sessionId === "number") && String(lead.sessionId) ? lead.sessionId : before ? before.id : null;
  return {
    ...job,
    ask,
    status: lead ? lead.status : null,
    // WHAT IT WAITS ON, SAID (founder's walk, 8 Nov 2026): "Waiting" alone left the person
    // guessing; the task's own line says on what ("After the bank rec").
    line: lead && lead.status !== "Done" && typeof lead.line === "string" && lead.line.trim() && lead.line.trim() !== lead.status ? lead.line.trim() : null,
    href: session !== null ? chatHref(session) : null,
    // A job with a status but no conversation (a task done with nothing to decide) is
    // "Open": the press asks Vert for it, rather than "Start" beside "Done".
    action: lead && lead.status === "Needs you" && session !== null ? "Answer" : session !== null || lead ? "Open" : "Start",
  };
}

/** The five steps with their rows, for the month shown. Pure. */
export function closeList(month, period, conversations = []) {
  const tasks = month && Array.isArray(month.tasks) ? month.tasks : [];
  const p = period || (month && month.period) || null;
  const words = p ? periodLabel(p) : "this month";
  return CLOSE_STEPS.map((step) => ({ ...step, jobs: step.jobs.map((job) => closeJobRow(job, tasks, words, conversations)) }));
}

/**
 * The Collect documents row's words, from the documents checklist Month-end already read
 * (`GET /close/{period}/documents`): "2 missing" or "All in", or null when it wasn't
 * read. The engine's count, never one made here. Pure.
 */
export function documentsNote(body) {
  const missing = body && Number.isInteger(body.missing) && body.missing >= 0 ? body.missing : null;
  if (missing === null) return null;
  return missing > 0 ? { words: `${missing} missing`, tone: "attention" } : { words: "All in", tone: "done" };
}

/**
 * The Cash coding row's words, from the month's cash coding listing (`GET
 * /api/cash-coding?period=`, its accounts' engine counts): "Lines to code" while any
 * account has a line to code, "All coded" when every account read says none, or null
 * when the listing or an account wasn't read. No count is made here (founder's walk,
 * 8 Nov 2026: the row said nothing until pressed). Pure.
 */
export function cashCodingNote(body) {
  const accounts = body && Array.isArray(body.accounts) ? body.accounts : null;
  if (!accounts || !accounts.length) return null;
  if (accounts.some((a) => a && Number.isInteger(a.toCode) && a.toCode > 0)) return { words: "Lines to code", tone: "attention" };
  if (accounts.every((a) => a && a.toCode === 0)) return { words: "All coded", tone: "done" };
  return null;
}
