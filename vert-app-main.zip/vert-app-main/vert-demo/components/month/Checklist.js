"use client";

// components/month/Checklist.js — THE MONTH'S TASKS, GROUPED BY THE FOUR WORDS
// ==============================================================================
// Spec §3.2 and §4.4; visual spec §3. The decisions come first, as cards (NeedsYouList).
// Under them is ONE Checklist card listing every task of the month — Needs you, Vert's
// working, Waiting, Done, in that order — each group under a filled band (chevron, word,
// the payload's count) and each task a 2.5rem row: title, a count or reason chip, and
// the outlined status chip (TaskRow `listed`). A group with nothing in it is not drawn.
//
// WHY THE NEEDS-YOU TASKS ARE LISTED TWICE. Their decisions sit above as cards, where
// the person acts; the card below is the month's whole list, so it reads complete
// ("five tasks, three need you") instead of starting at Waiting (eval r1 §17.4).
//
// WHY THE BANDS ARE OPEN. Eval 30 Sep (S4) closed Waiting and Done to one line each,
// because the open Waiting rows sat beside the decisions and put six ideas in front of
// the person at once. They no longer sit beside them: the decisions are cards above, and
// this card is below them, so above the fold is still decisions only. A closed band
// hid the list the reference shows (two bare lines, "Waiting · 1", "Done · 1"), so a
// band stays open while it is short (SHORT_GROUP rows) and folds only when it is long.
//
// ...BUT NOT WHILE A DECISION WAITS ABOVE (eval final-b S4, 6 Oct). Mid-close a short
// open card ("No deposit found. Check the bank again?") lifted this card above the fold,
// and its open rows ("Approve journal entries", "Resolve payout breaks", "Build
// workpapers") put three more ideas beside the decision. While anything needs you, each
// band is one line — "Needs you · 5", "Waiting · 1", "Done · 3" — like the reference
// home's three counts, and opens with one press; the decisions above are the page's job.
// Once nothing needs you the bands open as before (keyed on it, so they re-mount open).
//
// DESIGN PASS, FIX ROUND 1 (Calm neutral, 10 Oct 2026; spec §6.5, critique r1 #6). With
// every band one line, the checklist showed no task at all until a band was pressed
// ("Needs you · 7", "Waiting · 2", "Done · 3", all closed). The spec opens Needs you by
// default and keeps the others closed, and that is what this does: while a decision
// waits, the Needs-you band (in the Group cut, each group holding a Needs-you task) is
// open and the rest are one line. The five-ideas measure is unaffected: it reads what
// sits above this card (tests/month.test.js beforeChecklist), and the card starts below
// the decision and its pager. Once nothing needs you, short bands open as before.
// The drawing: no card, a title-3 heading, one toolbar row, and bands that are
// disclosure rows over hairline-divided task rows.
//
// Every count on a band is the payload's `counts.*`, not the length of a list this page
// assembled — the one-count rule (UI-001) applies to every number on the page.
//
// ITERATION 3 (build plan §19.0.8, §19.5 F-CHK): ONE ROW TYPE, CUT TWO WAYS. A task is
// a conversation with an optional skill; the built-in templates are rows only where
// they apply.
//
// DESIGN-FIX-2 (DA2-034, DA2-077, DA2-080, DA2-088; 10 Oct 2026). The toolbar is three
// quiet 32 px controls: View ▾ (Show: All tasks / Assigned to you; Group by: Status /
// Group; New group…), the search glyph that opens a field, and New task… (GroupBy.js).
// New task… opens the new-task form (presets, or the person's own words; founders, 22
// Oct 2026: NewTaskSheet.js), the shell's one form when there is a shell. Each is drawn
// only when it can work: the Group cut and New task need the custom-tasks
// payload (`groups[]`), "Assigned to you" needs a named viewer. The view is in the address
// (`?show=assigned&group=group&q=bank`, url-state.js), so a narrowed list can be linked
// to and survives a reload. The Group cut with no groups is the flat list under a hint
// that makes the first group, not one "No group" band over every task. A narrowed list
// says so in words — "No tasks match “bank”." — with "Show all tasks" beside it, so no
// row is ever silently out of reach.

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, Disclosure } from "@/components/ui";
import NeedsYouList from "./NeedsYouList";
import TaskRow from "./TaskRow";
import ChecklistTools, { NewGroup, bandsFor, customTasksLive, listableTasks, readGroupBy, taskKey, writeGroupBy } from "./GroupBy";
import { currentSearch, replaceSearch, viewFromSearch } from "./url-state";
import NewTaskSheet, { originFromTrigger, readPresets } from "./NewTaskSheet";
import { useNewTask } from "./NewTaskProvider";
import { groupTasks, rowFigureOf } from "./model";
import { IconAdd } from "@/components/ui/icons";

// A short group is drawn open; a long one folds to its band (see header).
export const SHORT_GROUP = 6;

const COUNT_KEY = { "Needs you": "needsYou", "Vert's working": "working", Waiting: "waiting", Done: "done" };

/**
 * Whether a band with no rows is still drawn: only a firm-made group, in the Group cut,
 * when the list is not narrowed (W0c CO-23; eval r3 walkthrough F9: a group made on
 * screen was not drawn until a task joined it, so the press looked like it did nothing).
 * A status band, "No group" and a narrowed list's empty band are still not drawn: they
 * would be a heading over nothing that nobody made. Pure.
 */
export function drawsEmpty(band, { cut, narrowed }) {
  return Boolean(band) && cut === "group" && !narrowed && typeof band.key === "string" && band.key.startsWith("group:") && band.key !== "group:none";
}

/** The month's groups and the ones made on this page since it was read, each once. Pure. */
export function withMadeGroups(month, made) {
  if (!month || !Array.isArray(month.groups) || !Array.isArray(made) || !made.length) return month;
  const known = new Set(month.groups.map((g) => g && String(g.id)));
  const extra = made.filter((g) => g && (typeof g.id === "string" || typeof g.id === "number") && !known.has(String(g.id)));
  return extra.length ? { ...month, groups: [...month.groups, ...extra] } : month;
}

/* ── ONE TAB STOP FOR THE ROWS (ui-pass-1 #33, U45; apple-design A14) ─────────────
 * Every row title was its own Tab stop (twelve on the July checklist) and the arrow
 * keys did nothing, so reaching "Build workpapers" took a Tab per task. The rows are now
 * one composite with a roving tabindex, like the kit's Table: Tab enters on ONE row (the
 * last one used, else the first), ↑ ↓ move between rows, Home and End go to the ends,
 * Enter opens (the title is a link). Only rows that open a conversation take part, and
 * only rows in an OPEN band: a closed band's region is inert, so a row there cannot be
 * the one Tab enters on. The row's other controls (Mark complete, "⋯") keep their own
 * Tab stops. Pure helpers, so the order is tested without a browser.
 */

/** The keys of the rows the roving tabindex walks, in reading order. Pure. */
export function rovingKeys(bands, isOpen) {
  const out = [];
  bands.forEach((band, i) => {
    if (!isOpen(band, i)) return;
    for (const task of band.tasks) if (task && task.sessionId && taskKey(task)) out.push(taskKey(task));
  });
  return out;
}

/** The row Tab enters on: the last one used if it is still walkable, else the first. Pure. */
export function rovingEntry(keys, last) {
  return keys.includes(last) ? last : keys[0] ?? null;
}

/** Where a key press moves from `current`, or null for a key that does not move. Pure. */
export function rovingStep(keys, current, key) {
  if (!keys.length) return null;
  const at = Math.max(0, keys.indexOf(current));
  if (key === "ArrowDown") return keys[Math.min(keys.length - 1, at + 1)];
  if (key === "ArrowUp") return keys[Math.max(0, at - 1)];
  if (key === "Home") return keys[0];
  if (key === "End") return keys[keys.length - 1];
  return null;
}

function listedRows(tasks, { period, recounting, viewer, tabbable, onRowFocus, groups, showStatus, figures = null }) {
  return tasks.map((task) => (
    <TaskRow
      key={taskKey(task)}
      task={task}
      period={period}
      recounting={recounting}
      viewer={viewer}
      listed
      showStatus={showStatus}
      rowKey={taskKey(task)}
      tabbable={tabbable === taskKey(task)}
      onRowFocus={onRowFocus}
      groups={groups}
      figure={figures && taskKey(task) ? rowFigureOf(task, figures[taskKey(task)] || null) : null}
    />
  ));
}

function Band({ word, tasks, count, period, recounting, open, viewer, keepEmpty = false, repeats = false, onToggle = null, tabbable = null, onRowFocus = null, groups = null, showStatus = false, figures = null }) {
  if (!tasks.length && !keepEmpty) return null;
  const rows = listedRows(tasks, { period, recounting, viewer, tabbable, onRowFocus, groups, showStatus, figures });
  return (
    <section className="month-band" data-band={word} data-empty={tasks.length ? undefined : "true"}>
      <Disclosure
        summary={
          <>
            <span className="month-band-word">{word}</span>
            {count === null ? null : (
              <>
                <span className="sr-only"> · </span>
                <span className="month-band-count num" data-tone={word === "Needs you" ? "attention" : undefined}>
                  {count}
                </span>
              </>
            )}
          </>
        }
        defaultOpen={open}
        className="month-band-fold"
        onToggle={onToggle}
      >
        {tasks.length ? (
          // The open Needs-you band's rows are the tasks whose decisions the card above
          // pages through: marked as REPEATS, so the five-ideas measure (tests/month.test.js,
          // the live walker) reads them as nothing new. Only this band, only while deciding.
          repeats ? (
            <div className="month-band-rows" data-lexicon="repeat">
              {rows}
            </div>
          ) : (
            rows
          )
        ) : (
          <p className="checklist-narrowed t-footnote" data-band-empty="">
            No tasks in this group yet. Choose it when you add a task.
          </p>
        )}
      </Disclosure>
    </section>
  );
}

function payloadCount(month, key) {
  const n = month && month.counts ? month.counts[key] : null;
  return typeof n === "number" && Number.isInteger(n) && n >= 0 ? n : null;
}

/** The narrowed line's words (DA2-088): the query echoed in curly quotes. Pure. */
export function narrowedWords({ drawnAny, mine, query }) {
  const q = typeof query === "string" ? query.trim() : "";
  if (drawnAny) return mine ? "Showing only what's assigned to you." : "Showing only what matches your search.";
  if (q) return `No tasks match \u201c${q}\u201d.`;
  return mine ? "Nothing is assigned to you." : "Nothing here matches.";
}

/** Whether the month names any group of its own (the Group cut has something to cut by). Pure. */
export function namedGroups(month) {
  return month && Array.isArray(month.groups) ? month.groups.filter((g) => g && (typeof g.id === "string" || typeof g.id === "number") && typeof g.name === "string" && g.name.trim()) : [];
}

export default function Checklist({
  month,
  period,
  itemsByTask,
  ledger,
  ledgerName,
  clientName,
  disabledReason = null,
  doneOpen = false,
  recounting = false,
  onDecided = null,
  viewer = null,
  imports = undefined,
  figures = null,
  initialBy = "status",
  initialFilter = "all",
  initialQuery = "",
  sheetOpen = false,
}) {
  // Groups made on this page are drawn at once (CO-23), before the month is read again.
  const [made, setMade] = useState([]);
  const router = useRouter();
  month = withMadeGroups(month, made);
  const { groups } = groupTasks(month);
  const needsYou = groups["Needs you"];
  const live = customTasksLive(month);
  const canFilter = typeof viewer === "string" && viewer.trim().length > 0;
  const [by, setBy] = useState(initialBy);
  const [filter, setFilter] = useState(canFilter ? initialFilter : "all");
  const [query, setQuery] = useState(initialQuery);
  const [creating, setCreating] = useState(sheetOpen);
  // Once pressed open, the sheet STAYS MOUNTED and closes with open={false} (U37, verify
  // pass 2): unmounted on close, a press during its exit drew a second sheet entering
  // from the trigger while a copy of the first left, so the motion jumped 95 px (1440)
  // and 554 px (390). Mounted, the kit's CSS transition reverses from where it is.
  // Never mounted before the first press, so the page's markup has no hidden commit.
  const [taskSheetMounted, setTaskSheetMounted] = useState(sheetOpen);
  if (creating && !taskSheetMounted) setTaskSheetMounted(true);
  const [addingGroup, setAddingGroup] = useState(false);
  const [origin, setOrigin] = useState(null);
  // THE NEW TASK'S DRAFT LIVES HERE until the task is created (DA2-048): a sheet closed by
  // Esc, X or the scrim keeps nothing itself, so the words were lost; held here, they are
  // there when New task… is pressed again, and the sheet asks before throwing them away.
  const [draft, setDraft] = useState(null);
  const trigger = useRef(null);
  // The roving tabindex (see rovingKeys): the row last focused, and each band's open
  // state as the person left it (keyed like the band, so a re-keyed band starts afresh).
  const [lastRow, setLastRow] = useState(null);
  const [toggled, setToggled] = useState({});
  const listRef = useRef(null);
  // THE VIEW IS IN THE ADDRESS (DA2-080; url-state.js): read after mount, the server
  // render has no address; the remembered cut is the fallback when the address names none.
  useEffect(() => {
    const asked = viewFromSearch(currentSearch());
    setBy(asked.by || readGroupBy());
    if (asked.filter === "mine" && canFilter) setFilter("mine");
    if (asked.query) setQuery(asked.query);
    // Once, on arrival: later changes are written by the handlers below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const chooseBy = (value) => {
    setBy(value);
    writeGroupBy(value);
    replaceSearch({ by: value });
  };
  const chooseFilter = (value) => {
    setFilter(value);
    replaceSearch({ filter: value });
  };
  const chooseQuery = (value) => {
    setQuery(value);
    replaceSearch({ query: value });
  };
  const cut = live ? by : "status";
  const { bands, narrowed } = bandsFor(month, { by: cut, filter: canFilter ? filter : "all", viewer, query });
  // How many rows the month lists, for the register rule only (whether a search is
  // worth drawing); never printed.
  const rowCount = listableTasks(month).length;
  const listedAny = Object.values(groups).some((tasks) => tasks.length);
  const drawnAny = bands.some((b) => b.tasks.length);
  // A decision waits above this card: only the work that needs you is open (see header).
  const deciding = needsYou.length > 0;
  const holdsNeedsYou = (band) => band.key === "Needs you" || band.tasks.some((t) => t && t.status === "Needs you");
  // A status band's count is the payload's `counts.*`; a narrowed list shows none (a
  // month's count over a list of yours would be a claim about rows not drawn).
  const statusCount = (band) => {
    if (cut !== "status") return band.count;
    const word = band.label;
    return narrowed ? null : payloadCount(month, COUNT_KEY[word]);
  };
  // THE GROUP CUT WITH NO GROUPS (DA2-077): one "No group" band over every task said
  // nothing. The list stays flat, under a hint that says what a group is for and makes one.
  const flatGroupCut = cut === "group" && namedGroups(month).length === 0;

  const bandKey = (band) => `${band.key}:${deciding ? "folded" : "open"}:${narrowed ? "n" : "a"}`;
  const bandDefaultOpen = (band) => flatGroupCut || narrowed || (deciding ? holdsNeedsYou(band) : band.tasks.length <= SHORT_GROUP || (band.key === "Done" && doneOpen));
  const bandOpen = (band) => (Object.hasOwn(toggled, bandKey(band)) ? toggled[bandKey(band)] : bandDefaultOpen(band));
  const walk = rovingKeys(bands, bandOpen);
  const entry = rovingEntry(walk, lastRow);

  function onRowsKeyDown(event) {
    const from = event.target && event.target.getAttribute ? event.target.getAttribute("data-row-key") : null;
    if (!from) return;
    const next = rovingStep(walk, from, event.key);
    if (!next) return;
    event.preventDefault();
    setLastRow(next);
    const target = listRef.current && [...listRef.current.querySelectorAll("[data-row-key]")].find((el) => el.getAttribute("data-row-key") === next);
    if (target) target.focus();
  }

  // THE SHELL'S ONE FORM (NewTaskProvider.js) when the page sits in the shell; the sheet
  // here only where it does not (a render of this card alone).
  const shared = useNewTask();
  const [presets, setPresets] = useState(undefined);
  const askPresets = () => {
    setPresets(undefined);
    readPresets().then(setPresets);
  };
  function openSheet() {
    const el = trigger.current;
    if (shared.available) {
      shared.openNewTask({ origin: el, groups: Array.isArray(month.groups) ? month.groups : undefined });
      return;
    }
    if (el && typeof window !== "undefined") {
      setOrigin(originFromTrigger(el.getBoundingClientRect(), { width: window.innerWidth, height: window.innerHeight }));
    }
    if (!Array.isArray(presets)) askPresets();
    setCreating(true);
  }

  function showAll() {
    chooseFilter("all");
    chooseQuery("");
  }

  const groupMade = (group) => {
    setMade((m) => [...m, group]);
    router.refresh();
  };
  const rowProps = { period, recounting, viewer, tabbable: entry, onRowFocus: setLastRow, groups: live ? month.groups : null, showStatus: cut === "group", figures };

  return (
    <div className="month-checklist">
      {/* Always mounted while the month is open: it draws nothing when nothing is
          waiting, and it holds the plates (with Undo) of decisions made on this page
          after their task has left Needs you (NeedsYouList header; eval C8 / W12). */}
      <NeedsYouList
        tasks={needsYou}
        itemsByTask={itemsByTask}
        period={period}
        ledger={ledger}
        ledgerName={ledgerName}
        clientName={clientName}
        disabledReason={disabledReason}
        recounting={recounting}
        total={payloadCount(month, "decisions")}
        onDecided={onDecided}
        imports={imports}
      />
      {listedAny || live ? (
        <section className="month-checklist-card" aria-label="Checklist" ref={listRef} onKeyDown={onRowsKeyDown}>
          <div className="month-checklist-head">
            <h2 className="month-checklist-title">Checklist</h2>
          </div>
          {/* ONE TOOLBAR ROW, THREE ELEMENTS (DA2-034): View ▾ and the search on the
              left, New task… on the right; all 32 px and quiet, nothing shifts by mode. */}
          <div className="checklist-bar">
            <ChecklistTools
              by={cut}
              onBy={chooseBy}
              filter={canFilter ? filter : "all"}
              onFilter={chooseFilter}
              query={query}
              onQuery={chooseQuery}
              canGroup={live}
              canFilter={canFilter}
              total={rowCount}
              onNewGroup={live ? () => setAddingGroup(true) : null}
            />
            {live ? (
              <span ref={trigger} className="checklist-new">
                <Button variant="quiet" size="sm" icon={<IconAdd />} onClick={openSheet} aria-haspopup="dialog">
                  {/* At 390 the button is its glyph (month.css); the words stay its name. */}
                  <span className="checklist-new-label">New task…</span>
                </Button>
              </span>
            ) : null}
          </div>
          {live && addingGroup ? (
            <div className="checklist-new-group">
              <NewGroup
                initialOpen
                onCancel={() => setAddingGroup(false)}
                onCreated={(group) => {
                  setAddingGroup(false);
                  groupMade(group);
                }}
              />
            </div>
          ) : null}
          {narrowed ? (
            <p className="checklist-narrowed t-footnote" data-narrowed={drawnAny ? "some" : "none"}>
              <span>{narrowedWords({ drawnAny, mine: filter === "mine" && canFilter, query })}</span>
              <Button variant="quiet" size="sm" className="checklist-show-all" onClick={showAll}>
                Show all tasks
              </Button>
            </p>
          ) : null}
          {flatGroupCut ? (
            <>
              {!narrowed && !addingGroup ? (
                <div className="checklist-hint" data-checklist-hint="">
                  <p className="checklist-hint-text t-footnote">No groups yet. Group related tasks, e.g. Bank, Payroll.</p>
                  <NewGroup onCreated={groupMade} />
                </div>
              ) : null}
              <div className="month-band-rows month-flat-rows">{listedRows(bands.flatMap((b) => b.tasks), rowProps)}</div>
            </>
          ) : (
            bands.map((band) => (
              <Band
                key={bandKey(band)}
                word={band.label}
                tasks={band.tasks}
                count={statusCount(band)}
                period={period}
                recounting={recounting}
                viewer={viewer}
                keepEmpty={drawsEmpty(band, { cut, narrowed })}
                repeats={deciding && !narrowed && cut === "status" && band.key === "Needs you"}
                open={bandDefaultOpen(band)}
                onToggle={(isOpen) => setToggled((t) => ({ ...t, [bandKey(band)]: isOpen }))}
                tabbable={entry}
                onRowFocus={setLastRow}
                groups={live ? month.groups : null}
                showStatus={cut === "group"}
                figures={figures}
              />
            ))
          )}
        </section>
      ) : null}
      {/* Not in the page's markup until first pressed (a closed sheet's commit would
          be a green there); from then on mounted, so its close and a re-press during
          the close are one CSS transition reversing (U37). */}
      {live && (creating || taskSheetMounted) ? (
        <NewTaskSheet
          open={creating}
          onClose={() => setCreating(false)}
          groups={Array.isArray(month.groups) ? month.groups : []}
          presets={presets}
          onRetryPresets={askPresets}
          period={period}
          viewer={viewer}
          origin={origin}
          draft={draft}
          onDraft={setDraft}
        />
      ) : null}
    </div>
  );
}
