// components/month/month-reads.js — WHAT MONTH-END READS FROM THE TASKS' CONVERSATIONS
// ==============================================================================
// Moved out of app/page.js (verify pass 3, S-UI-11) so the reads can be walked by a
// test with the conversation read injected.

import { readConversation } from "@/lib/agent/client";
import { BANK_REC_TEMPLATE, bankRecFigureOf, monthState, openItems, pendingIds, taskKey } from "./model";
import { runOf } from "@/components/home/rows";
import { isLinkMonth } from "@/lib/return-path";
import { CLOSE_PANEL_STATES } from "./close-step";

/**
 * The month Month-end's address asks for (`/?period=2026-08`, p1/fix7 27 Oct 2026): its
 * first `period` when that is an ISO month that exists, else null. Pure.
 */
export function monthAsked(params) {
  const raw = params && typeof params === "object" ? params.period : null;
  const value = Array.isArray(raw) ? raw[0] : raw;
  return isLinkMonth(value) ? value : null;
}

/**
 * The page's `chosen` read: AN EXPLICIT `?period=` WINS OVER THE MONTH COOKIE (staging
 * walkthrough, 27 Oct 2026: `/?period=2026-08` drew July, the cookie's month). Otherwise,
 * and for an invalid period, `remembered` (lib/session.js visibleMonth), as before. The
 * month it names still goes through the listing's rule (app/page.js chooseMonth), so a
 * month too far ahead to show falls back safely.
 */
export function chosenMonth(params, remembered) {
  const asked = monthAsked(params);
  return asked ? () => Promise.resolve(asked) : remembered;
}

// Each needs-you task's open cards and questions, by row (model.js taskKey). A conversation that can't
// be read leaves its task with no cards (its row and count still show, from the month)
// rather than taking the page down.
//
// AND EACH READ CONVERSATION'S LATEST RUN, by session id (components/home/rows.js runOf),
// for the homepage board's line and step bar. The only conversations read for the board
// alone are the tasks Vert is working on now — the ones whose step is the news — so a
// page view asks no more than one read per running task, beside the reads it made already.
export async function readOpenItems(month, { read = readConversation } = {}) {
  const tasks = Array.isArray(month && month.tasks) ? month.tasks : [];
  const wanted = tasks.filter((t) => t && t.status === "Needs you" && t.sessionId);
  // The bank rec's conversation is read whatever its status (S-UI-11): its row states
  // the closing balance from it (model.js bankRecFigureOf). Read once when it is also
  // a Needs-you task.
  // The MONTH'S rec (a rec beside the checklist, one account's own, is a row of its own).
  const bank = tasks.find((t) => t && t.template === BANK_REC_TEMPLATE && t.sessionId && !t.beside) || null;
  const extra = bank && !wanted.includes(bank) ? [bank] : [];
  const working = tasks.filter((t) => t && t.status === "Vert's working" && t.sessionId && t !== bank);
  const pending = pendingIds(month);
  // A row beside the checklist shows only the cards the month counts on it: a card it
  // shares with a checklist row (a reversal's approval, also on Approve journal
  // entries) is listed `onChecklist: false` and drawn once, on the row that holds it.
  const counted = pending ? new Set(month.pendingActions.filter((a) => a && a.onChecklist !== false).map((a) => a.actionId).filter(Boolean)) : null;
  const asked = [...wanted, ...extra, ...working];
  const reads = await Promise.all(asked.map((t) => read(t.sessionId)));
  const out = {};
  wanted.forEach((task, i) => {
    const got = reads[i];
    // A recorded month's cards are drawn from its replays, which carry no pending list.
    // By row (model.js taskKey): 094's and 090's own recs share a template.
    out[taskKey(task)] = got && got.ok ? openItems(got.events, { pending: got.replay ? null : task.beside ? counted : pending }) : [];
  });
  const figures = {};
  if (bank) {
    const got = reads[wanted.includes(bank) ? wanted.indexOf(bank) : wanted.length];
    // Settled or not is the conversation's and the task's (verify pass 5, S-UI-11): a
    // result with a question still open after it is not "reconciled".
    const figure = got && got.ok ? bankRecFigureOf(got.events, { pending: got.replay ? null : pending, status: bank.status || null }) : null;
    if (figure) figures[taskKey(bank)] = figure;
  }
  const runs = {};
  asked.forEach((task, i) => {
    const got = reads[i];
    const run = got && got.ok ? runOf(got.events) : null;
    if (run) runs[task.sessionId] = run;
  });
  return { itemsByTask: out, figures, runs };
}


/**
 * Month-end's reads, each sent as soon as what it needs is known (staging smoke, 23 Oct
 * 2026: the page took 15.7 s, its reads queued eleven deep). Which month needs only the
 * months listing and this browser's choice, so the month, the ledger and then each
 * task's conversation go out beside the payout register (`reads.engine`), not after it;
 * the register is waited for only to name the month when the listing could not be read.
 * A first-run client (a listing that answered with no months, and setup needed) is
 * handed back before any month is read, as app/page.js always did; setup's reads are
 * made only for a listing with no months, the one case they can change the page.
 *
 * `reads` are the page's reads (each a function returning a promise that does not
 * reject); `choose(engine, periodsRead, chosen)` is the page's month rule and
 * `noMonths(periodsRead)` its empty-listing test. Injected, so a test can hold any read
 * and watch what has gone out.
 */
/**
 * The conversations the month's conversation list (`GET /agent/sessions?period=`, the
 * sidebar's read) says are worth reading before GET /close answers: each that needs you
 * or is working, and the bank rec's (its row states its closing balance). The list and
 * /close are two readings, so this is a head start, never the rule: readOpenItems still
 * asks /close's own choice, and a conversation asked here that /close doesn't want is
 * one read spent, its answer unused. Pure.
 */
export function earlyConversations(listRead) {
  const body = listRead && listRead.ok ? listRead.body : null;
  const rows = Array.isArray(body) ? body : body && Array.isArray(body.sessions) ? body.sessions : [];
  const out = [];
  for (const row of rows) {
    const id = row && (row.sessionId ?? row.id);
    if (typeof id !== "string" || !id) continue;
    if (row.state === "needs_you" || row.state === "working" || row.template === BANK_REC_TEMPLATE) out.push(id);
  }
  return out;
}

/** `read`, asked at most once per conversation id: the same promise to every caller. */
function readEachOnce(read) {
  const asked = new Map();
  return (id) => {
    if (!asked.has(id)) asked.set(id, read(id));
    return asked.get(id);
  };
}

export async function readMonthEnd(reads, { choose, noMonths }) {
  const engineRead = reads.engine();
  const identityRead = reads.identity();
  const documentsRead = reads.documents();
  const [periodsRead, chosen] = await Promise.all([reads.periods(), reads.chosen()]);

  // Setup is asked only of a client whose listing answered with no months: a listed
  // month is work to show whatever is connected, so its two reads were wasted.
  const setup = noMonths(periodsRead) ? await reads.setup() : null;
  if (setup) return { setup, periodsRead, chosen };

  // The month by the listing alone; the payload only when the listing named none.
  const period = choose(null, periodsRead, chosen) || choose((await engineRead).engine, periodsRead, chosen);
  const monthRead = reads.month(period);
  // THE TASKS' CONVERSATIONS DON'T WAIT FOR GET /close (board load, 27 Oct 2026). /close
  // is the slowest read a page makes (it assesses every task), and the conversations
  // were asked only once it answered: three engine hops in a row. The month's
  // conversation list answers first and names the ones that need you or are working, so
  // they are asked as soon as it lands, beside /close; then /close's own choice is asked,
  // each conversation once (readEachOnce). A list that couldn't be read starts nothing.
  const conversation = reads.conversation ? readEachOnce(reads.conversation) : null;
  if (conversation && reads.sessions && period) {
    Promise.resolve(reads.sessions(period))
      .then((list) => {
        for (const id of earlyConversations(list)) Promise.resolve(conversation(id)).catch(() => {});
      })
      .catch(() => {});
  }
  const itemsRead = monthRead.then((read) =>
    read && read.ok && read.month
      ? reads.openItems(read.month, conversation ? { read: conversation } : undefined)
      : { itemsByTask: {}, figures: {}, runs: {} }
  );
  // STEP 5, SIGN OFF AND LOCK (W4, 29 Oct 2026): the month's lock status, a GET that
  // re-reads the ledger's lock date. Asked only for a month the "Close the month" panel
  // is drawn for (started, done or closed), once /close has said which it is, beside
  // the conversations rather than after them; a month not started or not read asks
  // nothing of the ledger. Optional, so a caller with no `lock` read draws no panel.
  const lockRead = reads.lock
    ? monthRead.then((read) => (read && read.ok && read.month && CLOSE_PANEL_STATES.has(monthState(read.month)) ? reads.lock(period) : null))
    : Promise.resolve(undefined);
  // THE MONTH'S DOCUMENTS (w33, audit 1.1): statements, bills and receipts, in or missing.
  // A page read (no Xero), beside the month. Optional: a caller with none draws no card.
  const monthDocumentsRead = reads.monthDocuments && period ? Promise.resolve(reads.monthDocuments(period)).catch(() => null) : Promise.resolve(undefined);
  const [{ engine }, identity, documents, read, ledger, items, lock, monthDocuments] = await Promise.all([
    engineRead, identityRead, documentsRead, monthRead, reads.ledger(), itemsRead, lockRead, monthDocumentsRead,
  ]);
  return { setup, periodsRead, chosen, engine, identity, documents, period, monthRead: read, ledger, ...items, lock, monthDocuments };
}
