"use client";

// components/month/NotStarted.js — "SEPTEMBER HASN'T STARTED." AND ONE BUTTON
// ==============================================================================
// Spec §3.2 "Month not started"; build plan §0.2.
//
// ONE PRESS OPENS THE MONTH AND RUNS EVERY TASK THAT NEEDS NO PERSON (`POST
// /close/{period}`, lib/actions.js startMonth): the payout check, the breaks, the
// entries, the bank reconciliation and the workpapers, each to its first decision or its
// end, inside the request. There is no per-task Start (§12.1). While they run the button
// says "Starting September…" with `aria-busy`, and a status line says what Vert is doing;
// when the request returns the page re-reads the month and shows the decisions.
//
// THEN, WITHOUT WAITING: the existing sync action for any connected source older than a
// day (spec §6.4). Fire and forget — the month is already open, and freshness shows in
// words at the foot of the page whether or not that sync lands.
//
// A Start that fails leaves the page as it was and says "Not sent. Nothing was recorded."

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button, Notice, SourceLogo, sourceKey } from "@/components/ui";
import { IconCaretRight, IconJournal } from "@/components/ui/icons";
import { startSync } from "@/components/sync/actions";
import { startMonth } from "@/lib/actions";
import { callSafely } from "@/lib/decisions";
import { failureDetails } from "@/components/cards/words";
import { freshnessLine, monthName, monthSources, noPaymentSource, paymentSourcesOf, sourcesNeedingYou } from "./model";

// FIVE IDEAS AT MOST (§9.1 S4; W0c CO-21, eval r3 output-visual F15). The iteration-1
// lede named six things — payouts, breaks, entries, approval, the bank rec and
// decisions — and with the sources strip the July screen held six ideas before anyone
// pressed anything. What Start does in full is on the task rows once it has run.
//
// DESIGN-FIX-2 (DA2-075, DA2-089; 10 Oct 2026): THE START PANEL TEACHES. The sentence
// became three lines under "What Vert will do", each with the mark of what it reads
// (the payment sources the payload lists, the bank, then the matching), and the one
// commit. The ask box sits under the panel as the secondary way in. A quiet caption says
// which sources haven't been read yet and links to Connections, instead of "2 of 2 not
// read yet" with no subject under the ask box.
// Fix round (critique r1, DA2-075 residue): every line leads with a SOURCE MARK
// (SourceLogo, monochrome), not a generic list glyph: the payout source (Stripe), the
// bank, then the ledger the entries are drafted for.
export const NOT_STARTED_LEDE = "What Vert will do";

function joinNames(names) {
  if (names.length <= 1) return names.join("");
  return `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
}

/**
 * The things Start does, in words, each with the source it reads: the payment sources
 * the payload lists by name ("Read the Stripe payouts"), the bank, then the matching
 * that comes back as decisions. Pure; the names are the payload's.
 *
 * NO PROCESSOR, NO PAYOUT LINES (verify pass 1, S-E2E-1). When the payload's sources
 * were read and none is a payment processor (model.js noPaymentSource), the panel said
 * "Read your payment sources" beside a Stripe mark and "Match each payout to a deposit"
 * to a client with no payouts. Such a month reads the bank and reconciles it to the
 * ledger; that is what it says. Only a payload that names no sources at all keeps the
 * generic line, since unread is not none.
 */
export function startSteps(month) {
  const sources = monthSources(month) || [];
  const payments = paymentSourcesOf(month) || [];
  const names = payments.map((x) => x.label);
  const ledger = sources.find((x) => x.kind === "ledger");
  const ledgerMark = ledger && sourceKey(ledger.label) ? ledger.label : null;
  if (noPaymentSource(month)) {
    return [
      { id: "bank", text: "Read the bank", source: "bank" },
      { id: "reconcile", text: "Reconcile the bank to the ledger", source: ledgerMark },
    ];
  }
  return [
    {
      id: "payouts",
      text: names.length ? `Read the ${joinNames(names)} payouts` : "Read your payment sources",
      // With the sources unread, the mark is the payout source Vert reads (Stripe); the
      // words still say "your payment sources", so it names no source as connected.
      source: payments.length ? String(payments[0].kind).toLowerCase() : "stripe",
    },
    { id: "bank", text: "Read the bank", source: "bank" },
    // The entries are drafted for the ledger: its mark when the payload names it (the
    // QuickBooks mark for "QuickBooks Online"), else the journal glyph.
    { id: "match", text: "Match each payout to a deposit and draft the entries", source: ledgerMark },
  ];
}

/** What the busy Start says it is doing: no payouts are checked for a client with none. Pure. */
export function startingWords(month) {
  return noPaymentSource(month) ? "Reading the bank and reconciling it to the ledger…" : "Checking payouts, finding breaks and gathering entries…";
}

/** A source as the caption says it: a brand by its name ("Stripe"), anything else as a common noun ("the bank", "the ledger"). */
function sourceName(x) {
  if (x.kind === "bank_feed") return "the bank feed";
  if (/^bank\b/i.test(x.label) || x.kind === "bank") return "the bank";
  if (x.kind === "ledger") return "the ledger";
  return /^[A-Z][a-z]+[A-Z]|^(Stripe|Shopify|PayPal|Square)\b/.test(x.label) ? x.label : `the ${x.label.toLowerCase()}`;
}

/**
 * The caption under the panel: which sources haven't been read yet ("Stripe and the bank
 * haven't been read yet"), else the payload's freshness line, else nothing. Pure.
 *
 * Only the sources Month-end names (model.js monthSources): a source that isn't
 * connected is neither "not read yet" nor listed. On staging's July (smoke test, 23 Oct)
 * this read "Shopify Payments and Stripe haven't been read yet." about two processors the
 * client never connected, and said nothing of the bank feed read that morning; it now
 * reads "Bank statement up to date through 31 Jul, read 1 Jul; Bank feed up to date
 * through 17 Oct, read 23 Oct · Ledger up to date, read 23 Oct."
 */
export function startCaption(month) {
  const sources = monthSources(month) || [];
  const unread = sources.filter((x) => !x.freshness || !["fresh", "stale", "failed"].includes(x.freshness.state));
  if (unread.length) {
    const names = unread.map(sourceName);
    return `${joinNames(names).replace(/^the /, "The ")} ${unread.length === 1 ? "hasn't" : "haven't"} been read yet.`;
  }
  const line = freshnessLine(month);
  return line ? `${line.text.replace(/\.$/, "")}.` : null;
}

/**
 * One press of Start, with its effects handed in (the component passes the real ones).
 *
 * BUSY UNTIL THE STARTED MONTH IS ON SCREEN (verify pass 6, S-E2E-2 F14). The press used
 * to go back to idle the moment `POST /close` answered and then ask for a refresh, so for
 * the two seconds the refreshed page took to arrive the panel said "Start August" again,
 * at full strength, with nothing saying Vert had started it. Now the refresh runs as a
 * transition (`refresh`) whose pending flag keeps the button busy (startBusy), and it is
 * asked for BEFORE the press stands down, in the same turn, so no paint falls between.
 */
export async function pressStart({ period, month, setState, refresh, start = (p) => callSafely(startMonth, p), sync = () => callSafely(startSync) }) {
  setState({ phase: "busy", result: null });
  const result = await start(period);
  if (!result || !result.ok) {
    setState({ phase: "failed", result });
    return result;
  }
  if (sourcesNeedingYou(result.month || month).length) sync();
  refresh();
  setState({ phase: "idle", result: null });
  return result;
}

/** The button is busy while the start is in flight and while its page is re-read. Pure. */
export function startBusy(phase, refreshing) {
  return phase === "busy" || Boolean(refreshing);
}

export default function NotStarted({ month, period, disabledReason = null }) {
  const router = useRouter();
  const [state, setState] = useState({ phase: "idle", result: null });
  const [refreshing, startRefresh] = useTransition();
  const name = monthName(month, period);
  const steps = startSteps(month);
  const caption = startCaption(month);
  const busy = startBusy(state.phase, refreshing);

  function start() {
    return pressStart({ period, month, setState, refresh: () => startRefresh(() => router.refresh()) });
  }

  return (
    <section className="month-start" aria-labelledby="month-start-title">
      <div className="month-start-panel">
        {/* The header already says "September hasn't started." and the commit says
            "Start September": the panel's own head says what the press will do. */}
        <h2 className="month-start-title t-title-3" id="month-start-title">
          {NOT_STARTED_LEDE}
        </h2>
        <ol className="month-start-steps">
          {steps.map((step) => (
            <li key={step.id} className="month-start-step t-body">
              <span className="month-start-mark" aria-hidden="true">
                {step.source ? <SourceLogo source={step.source} size={16} /> : <IconJournal size={16} />}
              </span>
              <span>{step.text}</span>
            </li>
          ))}
        </ol>
        <div className="month-start-act">
          <Button variant="commit" onClick={start} busy={busy} busyLabel={`Starting ${name}…`} disabledReason={disabledReason}>
            {`Start ${name}`}
          </Button>
        </div>
        {busy ? (
          <Notice kind="status">{startingWords(month)}</Notice>
        ) : null}
        {state.phase === "failed" ? (
          <Notice kind="error" recorded="nothing" onRetry={start} details={failureDetails(state.result)}>
            Not sent.
          </Notice>
        ) : null}
      </div>
      {caption ? (
        <p className="month-start-caption t-caption">
          <span>{caption}</span>
          <Link className="month-start-link" href="/connections">
            Connections
            <IconCaretRight aria-hidden="true" />
          </Link>
        </p>
      ) : null}
    </section>
  );
}
