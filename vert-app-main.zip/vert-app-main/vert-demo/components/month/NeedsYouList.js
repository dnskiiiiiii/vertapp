"use client";

// components/month/NeedsYouList.js — THE DECISIONS, ONE CARD AT A TIME, PAGED
// ==============================================================================
// Spec §3.2; audit UI-064, UI-063, UI-018. DESIGN PASS, FIX ROUND 1 (10 Oct 2026;
// design spec §6.6, critique r1 #7): the open decision's card carries a pager in its
// head, "1 of 13 ‹ ›", and the "See all 13 decisions" fold row under it is gone. The
// earlier objection to a pager (it "hid how much was waiting", §12.1) is met by the
// pager's own words: it names how many there are, the section heading names the same
// unit ("13 decisions"), and ‹ › reach every one of them in place. A task with no card
// to show is a page too (its row, which opens its conversation), so nothing waiting is
// out of reach. The diagram below is the pre-pager list, kept for the fold rules
// foldPlan still applies to what is drawn around the open card.
//
//   Needs you
//   Resolve payout breaks · 4 decisions
//   ┌ Stripe payout · 2 Jul · $7,000.00 ─────────────── the first decision, OPEN
//   │ Use the 1 Jul deposit of $7,000.00? …  [■ Use this deposit]
//   └───────────────────────────────────
//   ▸ Stripe payout · 9 Jul · $6,000.00 — No deposit found. Check the bank again?
//   ▸ 2 more
//   ▸ Approve journal entries · 24 decisions
//
// WHAT IT DECIDES. Only which decision is open. The first decision on the page is open;
// every other one is a one-line row that opens in place, and the open one collapses back
// to its row. A task with several decisions shows its first row and "N more", which
// expands in place. There is no pager ("1 of 3 ‹ ›" hid how much was waiting, §12.1).
//
// WHAT IT DOES NOT DECIDE. The order is the engine's (money that can't be explained
// first, then value); the counts beside each task are the payload's; the cards are
// components/cards, which write through the existing routes. Nothing here adds up.
//
// A DECIDED CARD STAYS WHERE IT WAS as its one-line past-tense plate (with Undo) even
// after the page re-reads the month and the API no longer lists it — otherwise the
// completion would vanish on the frame after it appeared, and Undo with it (spec §5.2).
// The next open decision then opens.
//
// ...AND SO DOES ITS GROUP. When the decision was the LAST one in its task, the re-read
// moves the task out of Needs you, and the group — with the plate and its Undo — used to
// unmount with it (eval C8 / W12, 30 Sep: "Undo buttons 6 s later = 0"). A kept item
// now carries the task it was decided under, and a group whose task has left the
// payload's Needs you is still drawn for its kept plates, under the task's title with
// no count (the count is the payload's, and the payload no longer has one here). They
// stay until the page is left. Checklist mounts this list whenever the month is open,
// so emptying Needs you entirely does not drop them either.
//
// NO LABEL ROW ABOVE THE CARDS (eval S2/S4, 2 Oct). A "Resolve payout breaks · 4
// decisions" row above every group cost about a dozen words and a lexicon term per
// task, and said nothing the cards do not: each card's own line names the transaction,
// the header carries the total, and "N more" says what is folded. The group still
// carries its task and the payload's count — as `data-task` / `data-task-decisions`
// and as the group's accessible name — so a screen reader hears "Resolve payout breaks
// · 4 decisions" and the tests still join the row to the payload. The row comes back
// only when it carries something a card cannot: a problem with its Retry, or a task
// this page just finished (the Done plate group below). A task with no card to show is
// drawn as its row only once the fold is opened (foldPlan; build plan §19.3 W0d).

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import MonthFileQuestion from "@/components/chat/questions/MonthFileQuestion";
import { StatusMark } from "@/components/ui";
import { AskedInChatCard, CardFor, ChooseDepositQuestion } from "@/components/cards";
import { boundLabel, lineFor } from "@/components/cards/words";
import { planHref, planIdOf } from "@/lib/agent/plan";
import TaskRow from "./TaskRow";
import { questionHref } from "@/app/api/budgets/shared";
import { taskKey, taskRowText } from "./model";
import { approveRefusal } from "@/lib/roles";
import { useDuties } from "@/lib/store";

import { IconCaretDown, IconCaretLeft, IconCaretRight } from "@/components/ui/icons";
import { formatPosition } from "@/lib/format";
import { currentSearch, decisionFromSearch, replaceSearch } from "./url-state";
/**
 * The budget import's questions, as Needs you lists them (build plan §20.0 decision 2,
 * #10; F-WIRE). An import is on demand, so `GET /close` doesn't list it as a task; its
 * questions (phasing, which sheet, unmapped labels) are read from the month's import
 * conversations (lib/budgets.js importQuestions). Each is ONE row that opens that
 * conversation AT the question card (`/chat/{id}#question-<id>`), where it is answered;
 * Needs you answers nothing itself, so an answer is never given away from its evidence.
 * Pure: `[{sessionId, title, questions}]` → `[{key, sessionId, href, text}]`.
 */
export function importRows(imports, ledgerName = null) {
  const out = [];
  for (const imp of Array.isArray(imports) ? imports : []) {
    if (!imp || typeof imp.sessionId !== "string") continue;
    for (const q of Array.isArray(imp.questions) ? imp.questions : []) {
      if (!q || q.questionId == null) continue;
      out.push({
        key: `import:${imp.sessionId}:${q.questionId}`,
        sessionId: imp.sessionId,
        href: questionHref(imp.sessionId, q.questionId),
        text: boundLabel(q.title, q.figures, ledgerName) || "A question about the budget import",
      });
    }
  }
  return out;
}

/** The month's import questions through `GET /api/budgets?imports=`, or [] when unread. */
export async function readImports(period, fetchImpl = globalThis.fetch) {
  try {
    const res = await fetchImpl(`/api/budgets?imports=${encodeURIComponent(period)}`, { cache: "no-store", headers: { accept: "application/json" } });
    const body = res && res.ok ? await res.json() : null;
    return body && Array.isArray(body.imports) ? body.imports : [];
  } catch {
    return [];
  }
}

/** Read the import questions once per month shown. Never throws; unread lists nothing. */
function useImportRows(period, given, ledgerName) {
  const [imports, setImports] = useState(Array.isArray(given) ? given : null);
  useEffect(() => {
    if (Array.isArray(given)) {
      setImports(given);
      return undefined;
    }
    if (typeof period !== "string" || !period) return undefined;
    let live = true;
    // A GET, never the server action: a page view sends no POST (smoke test, 23 Oct;
    // tests/p0-quiet-page-load.test.js). Unread lists nothing, as before.
    readImports(period)
      .then((list) => {
        if (live) setImports(list);
      })
      .catch(() => {
        if (live) setImports([]);
      });
    return () => {
      live = false;
    };
  }, [period, given]);
  return useMemo(() => importRows(imports, ledgerName), [imports, ledgerName]);
}

/** The one line a closed decision reads as. Never an id: the transaction line and the
 *  proposal, figures bound from the event's own `figures`. */
export function decisionRowText(item, ledgerName = null, task = null) {
  // A plan's closed row names whose plan it is: "Start the Fixed assets plan?". The
  // engine's proposal, "Start this plan?", named no task, and the scan's and fixed
  // assets' plans read the same on one list (eval r1 #10).
  if (item.type === "action" && item.action && item.action.kind === "plan") {
    const title = task && typeof task.title === "string" && task.title.trim() ? task.title.trim() : null;
    return title ? `Start the ${title} plan?` : boundLabel(item.action.proposal, item.action.figures, ledgerName) || "A plan to start";
  }
  if (item.type === "question") {
    return boundLabel(item.question.title, item.question.figures, ledgerName) || "A question from Vert";
  }
  const a = item.action || {};
  const line = lineFor(a);
  const proposal = boundLabel(a.proposal, a.figures, ledgerName);
  // A colon, not an em-dash, between the line and its proposal (design pass §8: no "—"
  // in visible copy): "Stripe payout · 9 Jul · $6,000.00: No deposit found. Check…".
  return [line, proposal].filter(Boolean).join(": ") || "A decision";
}

/**
 * The collapsed group row for a task's other decisions: "2 more payout breaks ⌄".
 * A bare purple "2 more" between cards read as a stray link (eval iter2 r2, §17.4); one
 * quiet row naming WHAT is folded away reads as part of the list. The noun is the task's
 * own title without its verb ("Resolve payout breaks" -> "payout breaks"); a title that
 * gives no noun, or a single hidden item, says "decision(s)" rather than guess.
 */
export function moreRowText(hidden, title) {
  const n = Number.isInteger(hidden) && hidden > 0 ? hidden : 0;
  const words = typeof title === "string" ? title.trim().split(/\s+/) : [];
  const noun = words.length >= 2 ? words.slice(1).join(" ").toLowerCase() : null;
  if (n === 1) return "1 more decision";
  return `${n} more ${noun || "decisions"}`;
}

/** The one fold row under the open card: "See all 7 decisions". The number is the
 *  payload's `counts.decisions`, the header's own — never a count of cards, which is not
 *  a count of decisions ("Approve all 3" is a card beside the three it approves). With
 *  no payload count (a re-read pending), it says no number rather than guess one. */
export function foldRowText(total) {
  if (!Number.isInteger(total) || total <= 0) return "See all decisions";
  return total === 1 ? "See all 1 decision" : `See all ${total} decisions`;
}

/**
 * What each group draws (eval final-b S4, 6 Oct). FOLDED — the page's first state — a
 * group draws only its open decision and its kept plates; every other decision on the
 * page, in every group, sits behind ONE "N more decisions ⌄" row under them. The
 * one-line rows each named their own idea ("Approve this entry?", "2 more journal
 * entries", "Agree Atlassian's schedule…") and put seven above the fold mid-close; the
 * fold row names one, "decision", which the header already says. OPENED — one press —
 * every group is drawn as before: its first decision, then "N more <noun>" for the rest,
 * so each group still discloses one step at a time. A group with a label row that
 * carries something a card cannot (a problem with its Retry, a task finished on this
 * page) is always drawn; a task with no card to show folds with the rest until opened.
 * Pure, so the fold is tested without a browser.
 */
/**
 * WHERE THE PAGER SITS (ui-pass-1 walkthrough #2, W10). The pager is laid over the open
 * card's top-right corner, and only a card whose head keeps clear of it can carry it
 * there: the decision cards (`.dcard-head`, `.jcard-titlebar`) and the deposit question
 * pad their head for it (month.css). Every other body — a question answered in its
 * conversation ("… Answer in the conversation ›"), a statement upload, a plan's line —
 * has no such head, and the pager sat on top of its link: a press at the link's centre
 * landed on the pager. Those get the pager on its own line above them ("row"). Decided
 * from the same branch that picks the body, so the two cannot disagree. Pure.
 */
export function decisionBodyOf(item, task) {
  if (!item) return null;
  if (item.type === "action") return item.action && item.action.kind === "plan" ? "plan" : "card";
  const q = item.question || {};
  if (q.form && q.form.kind === "file" && task && task.sessionId) return "file";
  if (Array.isArray(q.options) && q.options.length && !q.form) return "deposit";
  return "static";
}

/** "head" (over the card's corner) or "row" (its own line above the body). Pure. */
export function pagerPlaceFor(body) {
  // A question answered in its conversation is drawn as the decision card's head and foot
  // (components/cards/AskedInChatCard.js, DA2-037), so its pager sits in that head too.
  return body === "card" || body === "deposit" || body === "static" ? "head" : "row";
}

export function foldPlan(groups, lists, active, kept, { expanded = new Set(), opened = false } = {}) {
  let folded = 0;
  const plan = groups.map(({ task, left }) => {
    const items = lists[taskKey(task)] || [];
    const labelled = Boolean(left || task.problem || !items.length);
    // A task with no card to show and nothing to retry is only a label: "Resolve payout
    // breaks · 1 decision", plain text above the open card that named a decision the
    // person could not reach from there and put two more ideas on every later screen
    // (eval iter2 polish, visual findings 1 and 3; build plan §19.3 W0d). Folded, it is
    // one more thing behind "See all N decisions"; opened, its row is drawn as before.
    const cardless = !left && !task.problem && !items.length;
    if (!opened && cardless) {
      folded += 1;
      return { task, left, labelled, visible: [], hidden: 0, drawn: false };
    }
    if (!opened) {
      const visible = items.filter((i) => i.key === active || kept.has(i.key));
      folded += items.length - visible.length;
      return { task, left, labelled, visible, hidden: 0, drawn: labelled || visible.length > 0 };
    }
    const showAll = expanded.has(taskKey(task)) || items.some((i, n) => n > 0 && (i.key === active || kept.has(i.key)));
    const visible = showAll ? items : items.slice(0, 1);
    return { task, left, labelled, visible, hidden: items.length - visible.length, drawn: true };
  });
  return { plan, folded: opened ? 0 : folded };
}

/**
 * The pages the pager walks (design spec §6.6): every undecided decision on the page, in
 * the engine's order, group by group, then (after all of them) each task with no card to
 * show as one page of its own (its row opens its conversation). A decided card is a plate, not a page. Pure:
 * `[{ key, task, item }]`, where a cardless task's page has `item: null` and the key
 * `task:<template>`.
 */
export function decisionPages(groups, lists, kept) {
  const out = [];
  const cardless = [];
  for (const { task, left } of groups || []) {
    if (left) continue;
    const items = (lists && lists[taskKey(task)]) || [];
    const open = items.filter((i) => !(kept && kept.has(i.key)));
    if (open.length) for (const item of open) out.push({ key: item.key, task, item });
    // Last, after every card: a page that is only a row is never the first thing shown
    // while a card can be (build plan §19.3 W0d: the card-less row above the open card).
    else if (!items.length && !task.problem) cardless.push({ key: `task:${taskKey(task)}`, task, item: null });
  }
  return [...out, ...cardless];
}

/**
 * AN OFFER IS NOT A DECISION THE MONTH IS WAITING ON (verify pass 3, W01/W10). Vert's
 * offer to change a skill ("Update the steps for Fixed assets", a `skill_update` card)
 * sits in the task's conversation beside its decisions, but the engine does not count
 * it: `counts.decisions` is what the task's own assessment puts up, and a skill update
 * is not one of those (vert_api/routers/close.py NOT_THE_TASKS_CARDS). Paged with the
 * decisions, September read "4 for you to decide" over a pager at "1 of 5". So an offer
 * is not a page: the pager walks the decisions the header counts, and each offer is
 * drawn under them, open, as Vert's suggestion. Pure.
 */
export const OFFER_KINDS = Object.freeze(new Set(["skill_update"]));

export function isOffer(item) {
  return Boolean(item && item.type === "action" && item.action && OFFER_KINDS.has(item.action.kind));
}

/** An offer's closed row: "Suggested: Update the steps for Fixed assets". Pure. */
export function offerRowText(item, ledgerName = null) {
  const a = (item && item.action) || {};
  const proposal = boundLabel(a.proposal, a.figures, ledgerName);
  return proposal ? `Suggested: ${proposal}` : "Suggested: a change to a skill";
}

/**
 * A SHORTCUT IS NOT A DECISION EITHER (verify pass 7, D02 / F-12). "Approve all 2
 * entries?" (`approve_many`) is a card beside the two approvals it covers, and the
 * engine counts it AS them (vert_engine/workflows/status.py `_decision_units`: a bulk
 * card and its rows count once). Paged as a decision of its own, July read "10 for you
 * to decide" over a pager at "1 of 11". So a shortcut is not a page: it is drawn in its
 * task's group, as one quiet row under that task's decisions, for a viewer who may
 * approve. A preparer is never offered it: every entry it covers already says, on its
 * own card, that a reviewer approves it (§20.12 H3), and a card whose only press is
 * refused is one more idea with nothing to do. Pure.
 */
export const SHORTCUT_KINDS = Object.freeze(new Set(["approve_many"]));

export function isShortcut(item) {
  return Boolean(item && item.type === "action" && item.action && SHORTCUT_KINDS.has(item.action.kind));
}

/** A task's items split: `{ decisions, offers, shortcuts }`, each in the order given. Pure. */
export function splitOffers(items) {
  const decisions = [];
  const offers = [];
  const shortcuts = [];
  for (const item of Array.isArray(items) ? items : []) (isOffer(item) ? offers : isShortcut(item) ? shortcuts : decisions).push(item);
  // A shortcut with nothing beside it (its entries' own cards not on the page) is the
  // only way to those decisions, so it is paged as them: the engine counts it as the
  // approvals it covers, and none of them is drawn otherwise.
  if (!decisions.length && shortcuts.length) return { decisions: shortcuts, offers, shortcuts: [] };
  return { decisions, offers, shortcuts };
}

/** The shortcuts a viewer is offered: none to one who may not approve (roles.js). Pure. */
export function shortcutsFor(items, duties) {
  if (approveRefusal(duties)) return [];
  return splitOffers(items).shortcuts;
}

/** "1 of 13": where the open page sits, or null when there is nothing to page. Pure. */
export function pagerWords(pages, active) {
  if (!Array.isArray(pages) || pages.length < 2) return null;
  const at = pages.findIndex((p) => p.key === active);
  if (at < 0) return null;
  return { index: at + 1, of: pages.length, text: `${at + 1} of ${pages.length}`, previous: at > 0 ? pages[at - 1].key : null, next: at < pages.length - 1 ? pages[at + 1].key : null };
}

/** The section heading's count, in its unit: "13 decisions". Null with no payload count. */
export function decisionsChipText(total) {
  if (!Number.isInteger(total) || total <= 0) return null;
  return total === 1 ? "1 decision" : `${total} decisions`;
}

// What a card is about, so two cards for the same decision can be told apart from two
// decisions: its kind and its target ("approve:po_2Bd"). A question has no target.
export function decisionTarget(item) {
  if (!item || item.type !== "action") return null;
  const a = item.action || {};
  const t = a.target || {};
  return a.kind && t.id ? `${a.kind}:${t.id}` : null;
}

/**
 * Keep a decided card mounted after a re-read drops it (see the header). `kept` maps an
 * item key to `{ item, reopened }`; the displayed list is the server's list with those
 * re-inserted where they were.
 *
 * A KEPT CARD THAT WAS UNDONE GIVES WAY TO THE SERVER'S NEW ONE. Undo withdraws the
 * approval and the API puts the decision back as a NEW card (a new action id, same
 * payout). Keeping the old card too drew the entry twice, and the old one's settle would
 * be refused as no longer pending. So a reopened kept card is dropped as soon as the
 * server lists a card for the same decision; until then it stays, so the entry is never
 * missing from the page between the Undo and the re-read.
 */
export function withKept(items, kept, previous) {
  const keys = new Set(items.map((i) => i.key));
  const targets = new Set(items.map(decisionTarget).filter(Boolean));
  const out = [...items];
  for (const [key, entry] of kept) {
    const item = entry && entry.item ? entry.item : entry;
    if (keys.has(key)) continue;
    if (entry && entry.reopened && targets.has(decisionTarget(item))) continue;
    const before = previous.findIndex((p) => p.key === key);
    const anchor = before > 0 ? out.findIndex((i) => i.key === previous[before - 1].key) : -1;
    out.splice(anchor + 1, 0, item);
  }
  return out;
}

/**
 * Which decision is open. The one the person opened, unless it has since been decided;
 * after an Undo (`target:approve:po_2Bd`), the server's card for that same decision once
 * it is listed; otherwise the first undecided item on the page.
 */
export function activeKey(openKey, groups, lists, kept, firstOpen) {
  if (openKey && openKey.startsWith("target:")) {
    const target = openKey.slice("target:".length);
    for (const { task } of groups) {
      for (const item of lists[taskKey(task)] || []) {
        if (!kept.has(item.key) && decisionTarget(item) === target) return item.key;
      }
    }
    return firstOpen;
  }
  return openKey && !kept.has(openKey) ? openKey : firstOpen;
}

/**
 * The task groups to draw: the payload's Needs you tasks, in its order, then any task
 * that has left it but still has a plate this page settled (see the header). Pure, so
 * the last-card case is tested without a browser. `kept` maps an item key to
 * `{ template, item, task }`.
 */
export function groupsShown(tasks, kept) {
  const out = (tasks || []).map((task) => ({ task, left: false }));
  const listed = new Set(out.map((g) => taskKey(g.task)));
  for (const [, entry] of kept || []) {
    // A kept entry names its row (`group`, model.js taskKey); an older one its template.
    const group = entry ? entry.group ?? entry.template : null;
    if (!entry || listed.has(group) || !entry.task) continue;
    listed.add(group);
    out.push({ task: entry.task, left: true });
  }
  return out;
}

export default function NeedsYouList({
  tasks,
  itemsByTask = {},
  period,
  ledger = null,
  ledgerName = null,
  clientName = null,
  disabledReason = null,
  recounting = false,
  total = null,
  onDecided = null,
  imports = undefined,
}) {
  const importList = useImportRows(period, imports, ledgerName);
  const [openKey, setOpenKey] = useState(null);
  const [expanded, setExpanded] = useState(() => new Set());
  // Which pager button the person last pressed: focus returns to it on the new page,
  // since the card (and the pager in its head) is drawn afresh for each decision.
  const pagedBy = useRef(null);
  const sectionRef = useRef(null);
  const [kept, setKept] = useState(() => new Map());
  const [openOffer, setOpenOffer] = useState(null);
  const [openShortcut, setOpenShortcut] = useState(null);
  const duties = useDuties();
  const previous = useRef({});

  const groups = useMemo(() => groupsShown(tasks, kept), [tasks, kept]);
  // The offers, out of the decisions the pager walks (see isOffer), drawn after them.
  const offers = useMemo(() => {
    const out = [];
    for (const { task, left } of groups) {
      if (left) continue;
      for (const item of splitOffers(itemsByTask[taskKey(task)]).offers) out.push({ task, item });
    }
    return out;
  }, [groups, itemsByTask]);
  const lists = useMemo(() => {
    const out = {};
    for (const { task } of groups) {
      const key = taskKey(task);
      const items = splitOffers(itemsByTask[key]).decisions;
      const keptHere = new Map([...kept].filter(([, v]) => (v.group ?? v.template) === key));
      out[key] = withKept(items, keptHere, previous.current[key] || []);
    }
    previous.current = out;
    return out;
  }, [groups, itemsByTask, kept]);

  // The pages the pager walks; the first is open unless the person paged to another.
  const pages = useMemo(() => decisionPages(groups, lists, kept), [groups, lists, kept]);
  const firstOpen = pages.length ? pages[0].key : null;
  const chosen = activeKey(openKey, groups, lists, kept, firstOpen);
  const active = chosen && (pages.some((p) => p.key === chosen) || kept.has(chosen)) ? chosen : firstOpen;
  const pager = pagerWords(pages, active);
  const activePage = pages.find((p) => p.key === active) || null;
  const folded = foldPlan(groups, lists, active, kept, { expanded });
  // A cardless task's page draws its row (foldPlan folds it away otherwise).
  const fold = activePage && !activePage.item
    ? { ...folded, plan: folded.plan.map((g) => (taskKey(g.task) === taskKey(activePage.task) ? { ...g, drawn: true } : g)) }
    : folded;

  useEffect(() => {
    const dir = pagedBy.current;
    if (!dir || !sectionRef.current) return;
    pagedBy.current = null;
    const buttons = [...sectionRef.current.querySelectorAll("[data-pager-go]")];
    const el = buttons.find((b) => b.dataset.pagerGo === dir && !b.hasAttribute("aria-disabled")) || buttons.find((b) => !b.hasAttribute("aria-disabled")) || buttons[0];
    if (el) el.focus();
  }, [active]);

  const goTo = (key, dir) => {
    if (!key) return;
    pagedBy.current = dir;
    setOpenKey(key);
    const at = pages.findIndex((p) => p.key === key);
    if (at >= 0) replaceSearch({ decision: at + 1 });
  };

  // `?decision=3` opens the third page, once, after mount (url-state.js says why it is
  // read from the address there). A number past the end opens the first.
  const askedPage = useRef(false);
  useEffect(() => {
    if (askedPage.current || !pages.length) return;
    askedPage.current = true;
    const n = decisionFromSearch(currentSearch());
    if (n && n <= pages.length && n > 1) setOpenKey(pages[n - 1].key);
  }, [pages]);
  // THE PAGER (design spec §6.6): "1 of 13" in caption ink-2, then ‹ › quiet 32 px icon
  // buttons, in the open card's head. The words are a polite live region, so a screen
  // reader hears the new position after each press. At the ends a button is
  // aria-disabled (still focusable, so focus is not dropped), never hidden.
  // THE PAGER (design-fix-2 §5.6, DA2-037): the kit Pager's shape and classes, "‹ 1 of 13 ›",
  // both chevrons always there (the one at an end aria-disabled, still focusable, so
  // focus is never dropped), the position tabular with non-breaking spaces. It is drawn
  // here rather than through <Pager> because the page's focus return and its tests read
  // its `data-pager-*` hooks. The words are a polite live region. Its position is in the
  // address (`?decision=3`, DA2-080), so a page of the queue can be linked to. It carries
  // the kit's `data-ui="Pager"`, which keeps the old register pager rule in globals.css
  // (a top hairline and 1rem padding) off it: critique r1 saw that hairline above it.
  const pagerEl = pager ? (
    <nav className="decision-pager pager" aria-label="Decisions" data-decision-pager="" data-ui="Pager">
      <button
        type="button"
        className="decision-pager-go pager-btn"
        data-pager-go="previous"
        aria-label="Previous decision"
        aria-disabled={!pager.previous || undefined}
        onClick={() => goTo(pager.previous, "previous")}
      >
        <IconCaretLeft size={14} aria-hidden="true" />
      </button>
      <span className="decision-pager-words pager-pos num" aria-live="polite" data-pager-words="">
        {formatPosition(pager.index, pager.of)}
      </span>
      <button
        type="button"
        className="decision-pager-go pager-btn"
        data-pager-go="next"
        aria-label="Next decision"
        aria-disabled={!pager.next || undefined}
        onClick={() => goTo(pager.next, "next")}
      >
        <IconCaretRight size={14} aria-hidden="true" />
      </button>
    </nav>
  ) : null;

  const onSettled = useCallback((task, item, done) => {
    setKept((prev) => new Map(prev).set(item.key, { template: task.template, group: taskKey(task), item, task, reopened: false }));
    setOpenKey(null);
    // The write answered with the month (done.reading), and MonthView has already drawn
    // it; without one, MonthView holds the counts back until the page's re-read arrives.
    if (onDecided) onDecided(done && done.reading ? done.reading : null);
  }, [onDecided]);

  // Undo reopened a kept card: it stays until the server lists the decision again, and
  // the decision stays OPEN across that swap — the person just undid it, so its card is
  // what they are looking at, not a one-line row somewhere below the first decision.
  const onReopened = useCallback((item) => {
    setKept((prev) => {
      const entry = prev.get(item.key);
      if (!entry) return prev;
      return new Map(prev).set(item.key, { ...entry, reopened: true });
    });
    const target = decisionTarget(item);
    if (target) setOpenKey(`target:${target}`);
  }, []);

  // Nothing waiting and nothing kept: no section at all. Checklist keeps
  // this component mounted so a kept plate outlives an emptied Needs you (see header).
  if (!groups.length && !importList.length && !offers.length) return null;

  return (
    <section className="month-group" aria-labelledby="group-needs-you" data-group="Needs you" ref={sectionRef}>
      {/* A SECTION HEAD (design-fix-2 §3.3; DA2-006): footnote 600 in the secondary ink,
          sentence case, and no count. The "13 decisions" chip that sat here said the
          pager's number a second time (and the sidebar badge a third); the pager in the
          open card's head owns it. */}
      <h2 className="month-group-title" id="group-needs-you">
        Needs you
      </h2>
      {fold.plan.map(({ task, left, labelled, visible, hidden, drawn }) => {
        const items = lists[taskKey(task)] || [];
        const approveEntries = items.filter((i) => i.type === "action" && i.action.kind === "approve").map((i) => i.action);
        // A shortcut ("Approve all 2 entries?") is not a page (isShortcut): one quiet row
        // under the group's decisions, opened in place. Once settled it is a kept plate,
        // drawn with the group's other plates, and its row goes.
        const shortcuts = left ? [] : shortcutsFor(itemsByTask[taskKey(task)], duties).filter((i) => !kept.has(i.key));
        // The label row is drawn only when it carries something the cards cannot: a
        // problem with its Retry, or a task with no card to show (see the header). A
        // group folded away whole keeps its element, hidden, so its task and payload
        // count stay on the page for the tests and the next press (foldPlan).
        return (
          <div
            className="month-task"
            key={taskKey(task)}
            data-task-group={taskKey(task)}
            hidden={drawn ? undefined : true}
            {...(labelled
              ? {}
              : {
                  "data-task": task.template,
                  "data-task-decisions": typeof task.decisions === "number" ? task.decisions : undefined,
                  role: "group",
                  "aria-label": taskRowText(task, { recounting }),
                })}
          >
            {activePage && !activePage.item && taskKey(activePage.task) === taskKey(task) && pagerEl ? (
              <div className="decision-paged-row">{pagerEl}</div>
            ) : null}
            {!labelled ? null : left ? (
              // Done here, on this page: the task's last decision was just made. Its row
              // says so with the Done mark, and its plates (with Undo) stay under it until
              // the page is left (e2e r3 D5).
              <div className="task-row" data-task={task.template} data-task-left="">
                <div className="task-row-main">
                  <StatusMark word="Done" compact />
                  <span className="task-row-title t-body">{typeof task.title === "string" ? task.title : "A task"}</span>
                </div>
              </div>
            ) : (
              <TaskRow task={task} period={period} retryDisabledReason={disabledReason} recounting={recounting} />
            )}
            {visible.length ? (
              <ul className="decision-list">
                {visible.map((item) => {
                  const body = decisionBodyOf(item, task);
                  const paged = item.key === active && !kept.has(item.key) && pagerEl ? pagerPlaceFor(body) : null;
                  return (
                  <li
                    key={item.key}
                    className="decision-item"
                    data-open={item.key === active || kept.has(item.key) ? "true" : "false"}
                    data-paged={paged === "head" ? "true" : undefined}
                  >
                    {paged === "head" ? pagerEl : paged === "row" ? <div className="decision-paged-row">{pagerEl}</div> : null}
                    {item.key === active || kept.has(item.key) ? (
                      body === "card" || body === "plan" ? (
                        <CardFor
                          action={item.action}
                          ledgerName={ledgerName}
                          ledger={ledger}
                          clientName={clientName}
                          entries={approveEntries}
                          sessionId={task.sessionId || null}
                          {...(item.action.kind === "plan" ? { task: { ...task, period: task.period || period } } : {})}
                          onSettled={(done) => onSettled(task, item, done)}
                          onReopened={() => onReopened(item)}
                        />
                      ) : body === "file" ? (
                        // The statement is dropped HERE, not after a trip to the
                        // conversation (eval iter2 r1, flow 4; MonthFileQuestion.js).
                        <MonthFileQuestion question={item.question} sessionId={task.sessionId} />
                      ) : body === "deposit" ? (
                        <ChooseDepositQuestion
                          question={item.question}
                          sessionId={task.sessionId}
                          ledgerName={ledgerName}
                          onSettled={(done) => onSettled(task, item, done)}
                        />
                      ) : (
                        // Answered in its conversation: the one decision card's head and
                        // foot, "Answer in chat" a secondary (DA2-037).
                        <AskedInChatCard text={decisionRowText(item, ledgerName, task)} sessionId={task.sessionId || null} />
                      )
                    ) : item.type === "action" && item.action.kind === "plan" && planHref(task.sessionId, planIdOf(item.action)) ? (
                      // A plan is reviewed in its conversation, so its row goes there in
                      // one press, at `?plan=<id>` so the conversation opens the plan (PlanCard).
                      <Link className="decision-row row" href={planHref(task.sessionId, planIdOf(item.action))}>
                        <span className="decision-row-text t-body">{decisionRowText(item, ledgerName, task)}</span>
                      </Link>
                    ) : (
                      <button type="button" className="decision-row row" aria-expanded="false" onClick={() => setOpenKey(item.key)}>
                        <span className="decision-row-text t-body">{decisionRowText(item, ledgerName, task)}</span>
                      </button>
                    )}
                  </li>
                  );
                })}
              </ul>
            ) : null}
            {hidden > 0 ? (
              <button
                type="button"
                className="decision-row decision-more row"
                aria-expanded="false"
                onClick={() => setExpanded((prev) => new Set(prev).add(taskKey(task)))}
              >
                <span className="decision-row-text t-body">{moreRowText(hidden, task.title)}</span>
                <IconCaretDown className="decision-more-chevron" aria-hidden="true" />
              </button>
            ) : null}
            {shortcuts.length ? (
              <ul className="decision-list">
                {shortcuts.map((item) => (
                  <li key={item.key} className="decision-item" data-open={openShortcut === item.key ? "true" : "false"} data-shortcut="">
                    {openShortcut === item.key ? (
                      <CardFor
                        action={item.action}
                        ledgerName={ledgerName}
                        ledger={ledger}
                        clientName={clientName}
                        entries={approveEntries}
                        sessionId={task.sessionId || null}
                        onSettled={(done) => onSettled(task, item, done)}
                        onReopened={() => onReopened(item)}
                      />
                    ) : (
                      <button type="button" className="decision-row row" aria-expanded="false" onClick={() => setOpenShortcut(item.key)}>
                        <span className="decision-row-text t-body">{decisionRowText(item, ledgerName, task)}</span>
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            ) : null}
          </div>
        );
      })}
      {offers.length ? (
        // Each offer is one quiet row until pressed (one purple and five ideas per page,
        // §13 / F-POL: an offer drawn open put its Apply beside the decision's commit).
        <div className="month-task month-offers" data-task-group="offers" role="group" aria-label="Suggested by Vert">
          <ul className="decision-list">
            {offers.map(({ task, item }) => (
              <li key={item.key} className="decision-item" data-open={openOffer === item.key ? "true" : "false"} data-offer="">
                {openOffer === item.key ? (
                  <CardFor
                    action={item.action}
                    ledgerName={ledgerName}
                    ledger={ledger}
                    clientName={clientName}
                    sessionId={task.sessionId || null}
                  />
                ) : (
                  <button type="button" className="decision-row row" aria-expanded="false" onClick={() => setOpenOffer(item.key)}>
                    <span className="decision-row-text t-body">{offerRowText(item, ledgerName)}</span>
                  </button>
                )}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
      {importList.length ? (
        <div className="month-task" data-task-group="budget_import" data-task="budget_import" role="group" aria-label="Import budget">
          <ul className="decision-list">
            {importList.map((row) => (
              <li key={row.key} className="decision-item" data-open="false">
                <Link className="decision-row row" href={row.href} data-import-question={row.key}>
                  <span className="decision-row-text t-body">{row.text}</span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </section>
  );
}
