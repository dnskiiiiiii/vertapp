// components/month/MonthHeader.js — "JULY 2026", AND HOW FAR IT HAS GOT
// ==============================================================================
// Spec §3.2. The page title (one per page, title-1) and where the month stands.
//
// DESIGN-FIX-2 (DA2-006, DA2-022; 10 Oct 2026). The header had no anchor: a title, a
// footnote verdict that repeated the decision count the pager and the sidebar already
// said, and a context chip naming the client and the month the sidebar already names.
// Now: the title on the left, and on the right ONE anchor figure, "2 / 12" in the display
// face with tabular figures, "tasks done" under it, and the open work in words in the
// quiet ink ("13 for you to decide"; verify pass 1 F-9). Every number is the payload's (model.js
// anchorFigure, decisionsLine); the percentage and a close-due date the audit suggested
// are not drawn, because the payload sends neither and this page computes nothing.
//
// The sentence a screen reader hears is the verdict, "2 of 12 tasks done" (model.js
// verdictLine), in `data-month-verdict`; the figure beside it is that sentence drawn
// large and is hidden from assistive tech, so it is said once.
//
// WHILE THE MONTH CATCHES UP OR RECOUNTS the anchor gives way to the words ("Catching
// up on what changed…", "Counting again…"): counts from before are not shown as current.

import { anchorFigure, monthLabel, monthState, verdictLine } from "./model";

//
// THE BOARD'S HEADER (the homepage, components/home): the same title and context chip,
// with `summary` — "3 need you · 2 working · 5 done of 12", the payload's counts in words
// (components/home/rows.js summaryLine) — as the line under the title in place of the
// anchor figure, which would say the done count twice, and `tools` (the view switch and
// New task) on the right.
export default function MonthHeader({ month, period, recounting = false, catchingUp = false, context = null, summary = undefined, tools = null }) {
  const boarded = summary !== undefined;
  const verdict = boarded ? summary : verdictLine(month, { recounting, catchingUp });
  const holding = recounting || catchingUp;
  const figure = holding || boarded ? null : anchorFigure(month);
  // No second count (9 Nov 2026): "6 for you to decide" sat over a band reading "Needs
  // you 9". The band, the pager and the sidebar badge all say the tasks; so does nothing
  // here.
  const open = null;
  return (
    <header className="month-head" data-anchored={figure ? "true" : undefined}>
      <div className="month-head-row">
        {/* The sources "•••" sits on the title's line, beside the name it belongs to
            (critique r1: it floated by the anchor, in no group). */}
        <div className="month-title-group">
          <h1 className="month-title t-title-1">{monthLabel(month, period)}</h1>
          {context}
        </div>
        <div className="month-head-side">
          {tools ? <div className="month-head-tools">{tools}</div> : null}
          {figure ? (
            <div className="month-anchor">
              <p className="month-anchor-figure t-title-2 num" aria-hidden="true" translate="no">
                {figure.done}
                <span className="month-anchor-of">{"\u2009/\u2009"}</span>
                {figure.total}
              </p>
              <p className="month-verdict sr-only" data-month-verdict="" aria-live="polite">
                {verdict}
              </p>
              <p className="month-anchor-label t-footnote" aria-hidden="true">
                {/* A finished month says only "done": the verdict beside it names the
                    month, and "tasks" would be one more idea on a quiet page (S4). */}
                {monthState(month) === "done" ? "done" : figure.total === 1 ? "task done" : "tasks done"}
              </p>
              {open ? <p className="month-anchor-open t-caption">{open}</p> : null}
            </div>
          ) : null}
        </div>
      </div>
      {!figure && verdict ? (
        <p className={boarded ? "month-verdict month-summary t-callout" : "month-verdict t-footnote"} data-month-verdict="" aria-live="polite" aria-busy={holding ? "true" : undefined}>
          {verdict}
        </p>
      ) : null}
    </header>
  );
}
