"use client";

// components/month/AskBox.js — "ASK VERT, OR TELL IT WHAT TO DO…"
// ==============================================================================
// Spec §3.2 and §4.1; build plan §0.3. The one box on the one home page. Anything typed
// here starts a conversation (`POST /agent/sessions {period, text}`), and the page moves
// to it. With the assistant live, the model answers or starts the right task; without
// it, the service answers at once with the tasks it can do now — so the box always
// leads somewhere, and never shows setup words (spec §10).
//
// THE SEND BUTTON FILLS ONLY ONCE THERE IS TEXT (spec §3.2): the page's one filled
// button is the open decision's commit, and an empty box has nothing to send.
//
// A SEND THAT FAILS KEEPS THE TEXT (UI-052) and says so under the box: "Not sent.
// Nothing was recorded." Enter sends; Shift+Enter is a new line.
//
// AT MOST THREE SUGGESTIONS under the box (build plan §4.6 FM item 1; model.js
// suggestionsFor): "Draft an entry", "Compare with last month" and, once nothing needs
// you, one question about the first task still open. Design-fix-2 (DA2-023, critique r1)
// puts the first two back while a decision waits: an empty hero box with nothing under
// it read as a search field; two small secondary chips sit under it, quieter than the
// decision's commit. On-demand work has no checklist row, so this is where
// it starts. A suggestion is a request already typed: one press sends it, exactly as
// Enter would, through the same `POST /agent/sessions`; or, when the month already has
// that task's conversation, opens it rather than starting a second. They are quiet
// outlined chips — the page's one filled control stays the open decision's commit
// (§4.0.9, purple means "this writes"). A failed send puts the suggestion's words in the
// box, so the retry is the same press as for anything typed.
//
// THE SEND IS THE COMPOSER'S ROUND "↑" (eval r2 §17.4 finding 4). It used to be a "›"
// chevron, so the home box and the conversation's composer drew the same act two ways.
// DESIGN PASS (Calm neutral, spec §6.9): with text it is the INK button, never the
// accent — sending is not a write, and the page's one green is the decision's commit.
//
// A TRAY JOINED UNDER THE BOX SAYS WHERE THE FIGURES COME FROM (visual spec §2, the
// reference's "Connect all of your apps" slot). It is SourcesLine in its tray place: the
// same words and the one Sync now, which appears only when a source is behind — so a
// fresh month adds names and a date under the box, not the idea of syncing (S4′).
//
// DESIGN-FIX-2 (DA2-023, 10 Oct 2026): THE HERO, NOT A SEARCH FIELD. 4rem tall, the card
// radius, a soft line and the resting shadow; focused, the evergreen 1 px edge and its
// 3 px halo with a deeper shadow (the focus treatment every field has, §5.3). A leading
// Paperclip attaches a file the way the conversation's composer does (only where the
// engine reads files): it is uploaded at once, shown as a chip, and the ask goes out
// with one "Attached file:" line per file, as a thread's message does. The send is the
// ArrowUp in ink once there is something to send, and a quiet grey disc before. The
// suggestions show only while the box is empty. `/?ask=1` (cmd-K's "New chat") focuses
// the box once, and the address drops the flag.
//
// THE BOX ALWAYS SENDS A MONTH (G4 eval r1, NF-1st). A new client with no month started
// handed this box `period: null`, the API refused it, and every ask said "Not sent.
// Nothing was recorded." The page now hands in the current close month for such a
// client (app/page.js); and should a caller ever hand in no month, the box sends the
// current close month itself (askPeriod) rather than one the API must refuse.

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { IconButton } from "@/components/ui";
import { MESSAGE_MAX, MESSAGE_NOT_SENT, MESSAGE_TOO_LONG, MessageCount, SendFailedLine, sendFailureWords } from "@/components/chat/Composer";
import { IconAttach, IconClose, IconSend } from "@/components/ui/icons";
import { againIfNoAnswer, startConversation } from "@/lib/agent/actions";
import { DOCUMENT_ACCEPT, attachmentLines, uploadFile } from "@/components/chat/results/DocumentView";
import { callSafely } from "@/lib/decisions";
import SourcesLine from "./SourcesLine";
import { freshnessLine } from "./model";
import { closeMonthOf, isPeriod } from "@/lib/period";
import SendingNow from "@/components/chat/SendingNow";
import { takeEarlyAsk } from "@/lib/early-ask";
import { markStarted } from "@/lib/agent/opening";

//: How long a send waits for its answer before looking for the conversation it started,
//: and how often it looks after that.
export const JUMP_AFTER_MS = 4000;
export const JUMP_EVERY_MS = 3000;

/**
 * The conversation an ask just started, from the sidebar's list, or null. Pure.
 *
 * OPEN THE CONVERSATION, DON'T WAIT FOR THE ANSWER (9 Nov 2026, the bookkeeper walk):
 * Vert writes its reply inside the start request, 20–60 s, and the Month-end page held
 * the person there; twice they read the emptied box as their question lost, and moved
 * on. A free chat's title is its first words (cut with "…"), so the conversation is the
 * one whose title starts the ask, touched since it was sent, that is not a task's.
 */
export function startedConversation(conversations, request, since) {
  const words = String(request || "").split("\n")[0].trim().toLowerCase();
  if (!words || !Array.isArray(conversations)) return null;
  for (const c of conversations) {
    if (!c || c.template || typeof c.title !== "string" || typeof c.href !== "string") continue;
    if (!(Number(c.updatedAt) >= since - 5000)) continue;
    const title = c.title.replace(/…$/, "").trim().toLowerCase();
    if (title.length >= 8 && (words === title || words.startsWith(title))) return c;
  }
  return null;
}

/** The month an ask is sent under: the page's, else the current close month. Pure. */
export function askPeriod(period, now = new Date()) {
  return isPeriod(period) ? period : closeMonthOf(now);
}

// WIG G9 (ui-pass-1 output-ui #37): a placeholder shows an example and ends in "…".
export const ASK_PLACEHOLDER = "Ask or tell Vert, e.g. reconcile the bank…";
// Below 600 px the example wrapped the placeholder to two lines in a one-line box
// (critique r1, DA2-023 at 390): the phone box says only what it is for.
export const ASK_PLACEHOLDER_SHORT = "Ask or tell Vert…";
export const ASK_SHORT_QUERY = "(max-width: 599.98px)";

/** What an ask goes out as: the words, then one line per attached file. Pure. */
export function askText(words, files) {
  const lines = attachmentLines(files);
  const typed = typeof words === "string" ? words.trim() : "";
  return [typed, ...lines].filter(Boolean).join("\n");
}

/**
 * WHAT THE ASK BOX SAYS WHEN A SEND FAILS (harsh wave 1, W1-45). A 6,000-character ask
 * was refused by the API with a 400 naming the 4,000-character limit, and the box said
 * "Vert's server didn't answer". The box now takes at most 4,000 characters (as the
 * thread's composer does), counts them from 3,500, refuses a longer ask (words plus
 * attachment lines) before it goes, and says any refusal in the API's own terms. Pure.
 */
export function askFailureWords(result) {
  return sendFailureWords(result);
}

/** Whether an ask is too long to send: the whole request, attachment lines and all. Pure. */
export function askTooLong(request) {
  return typeof request === "string" && request.length > MESSAGE_MAX;
}

/** Whether the address asks for the box to take focus (`?ask=1`, cmd-K "New chat"). Pure. */
export function asksForFocus(search) {
  return new URLSearchParams(typeof search === "string" ? search : "").get("ask") === "1";
}

export default function AskBox({ period, disabledReason = null, suggestions = [], month = null, syncDisabledReason = null, showTray = true, upload = uploadFile, documentsEnabled = false }) {
  const router = useRouter();
  const [text, setText] = useState("");
  const [state, setState] = useState("idle");
  // What is being sent, drawn as yours at once (p0): Vert answers inside the request.
  const [sent, setSent] = useState(null);
  const [failure, setFailure] = useState(MESSAGE_NOT_SENT);
  const [files, setFiles] = useState([]);
  const [reading, setReading] = useState(0);
  const [refusal, setRefusal] = useState(null);
  const [narrow, setNarrow] = useState(false);
  const inputRef = useRef(null);
  const pickerRef = useRef(null);

  // The short placeholder below 600 px. The server draws the long one; a phone swaps it
  // on hydration, before anyone has typed.
  useEffect(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return undefined;
    const mq = window.matchMedia(ASK_SHORT_QUERY);
    const sync = () => setNarrow(mq.matches);
    sync();
    if (typeof mq.addEventListener === "function") mq.addEventListener("change", sync);
    return () => {
      if (typeof mq.removeEventListener === "function") mq.removeEventListener("change", sync);
    };
  }, []);
  const ready = (text.trim().length > 0 || files.length > 0) && !disabledReason && !reading;

  // Files are offered only where the engine reads them; any doubt is off. The page says so
  // (`documentsEnabled`, read on the server by app/page.js): asking from here was a server
  // action, a POST on every page view (smoke test, 23 Oct; tests/p0-quiet-page-load.test.js).
  const attachable = documentsEnabled === true && !disabledReason;

  // WORDS TYPED WHILE THE PAGE LOADED (D40): the skeleton's box held them; the box opens
  // with them, focused, caret at the end. Sending stays a press: a page view never posts.
  useEffect(() => {
    const early = takeEarlyAsk();
    if (!early) return;
    setText(early.text);
    const el = inputRef.current;
    if (el) {
      el.focus({ preventScroll: true });
      requestAnimationFrame(() => el.setSelectionRange && el.setSelectionRange(early.text.length, early.text.length));
    }
  }, []);

  // `/?ask=1` focuses the box once, then the flag leaves the address.
  useEffect(() => {
    if (typeof window === "undefined" || !asksForFocus(window.location.search)) return;
    if (inputRef.current) inputRef.current.focus({ preventScroll: false });
    try {
      const p = new URLSearchParams(window.location.search);
      p.delete("ask");
      const q = p.toString();
      window.history.replaceState(window.history.state, "", `${window.location.pathname}${q ? `?${q}` : ""}${window.location.hash}`);
    } catch {
      // A refused history write leaves the flag; the focus already happened.
    }
  }, []);

  async function sendText(words, withFiles = files) {
    const request = askText(words, withFiles);
    if (!request || disabledReason || state === "sending") return;
    if (askTooLong(request)) {
      setFailure(MESSAGE_TOO_LONG);
      setState("failed");
      return;
    }
    // YOUR WORDS LEAVE THE BOX AND SHOW AS SENT, AT ONCE (p0, 23 Oct 2026): the reply is
    // written inside this request, up to a minute or more. A failure puts them back.
    setSent(request);
    setText("");
    setFiles([]);
    setState("sending");
    const since = Date.now();
    let settled = false;
    let jumped = false;
    // A GET of the sidebar's list, in this press's own handler (never an effect): when
    // the conversation exists, open it; it follows Vert's reply live.
    const look = async () => {
      if (settled || jumped) return;
      try {
        const res = await fetch(`/api/shell?period=${encodeURIComponent(askPeriod(period))}&close=0`, { cache: "no-store", credentials: "same-origin" });
        const body = res.ok ? await res.json() : null;
        const found = !settled && !jumped ? startedConversation(body && body.conversations, request, since) : null;
        if (found) {
          jumped = true;
          markStarted(found.id);
          router.push(found.href);
          return;
        }
      } catch {
        // A failed look changes nothing: the send's own answer still moves the page.
      }
      if (!settled && !jumped) setTimeout(look, JUMP_EVERY_MS);
    };
    setTimeout(look, JUMP_AFTER_MS);
    const result = await againIfNoAnswer(() => callSafely(startConversation, { period: askPeriod(period), text: request }));
    settled = true;
    if (jumped) return;
    if (!result.ok || !result.sessionId) {
      setText((now) => (now.trim() ? now : words));
      setFiles((now) => (now.length ? now : withFiles));
      setSent(null);
      setFailure(askFailureWords(result));
      setState("failed");
      return;
    }
    router.push(`/chat/${encodeURIComponent(result.sessionId)}`);
  }

  async function send(event) {
    if (event) event.preventDefault();
    if (!ready) return;
    await sendText(text);
  }

  function suggest(s) {
    if (disabledReason || state === "sending") return;
    // The words go in the box first, so a send that fails leaves them there to retry.
    setText(s.text);
    sendText(s.text);
  }

  async function take(list) {
    const chosen = Array.from(list || []).filter(Boolean);
    if (!chosen.length || !attachable) return;
    setRefusal(null);
    setReading((n) => n + chosen.length);
    for (const file of chosen) {
      const result = await upload(file, {});
      setReading((n) => n - 1);
      if (result && result.ok && result.chip) setFiles((prev) => (prev.some((c) => c.documentId === result.chip.documentId) ? prev : [...prev, result.chip]));
      else setRefusal((result && result.message) || `${file.name} wasn't read. Nothing was stored.`);
    }
    if (inputRef.current) inputRef.current.focus();
  }

  // The page hides the tray mid-close (MonthView.js `deciding`); the chip still says it.
  const tray = Boolean(showTray && month && freshnessLine(month));
  const offered = Array.isArray(suggestions) && !text.trim() && !files.length && state !== "sending" ? suggestions.slice(0, 3) : [];

  return (
    <form className="ask" onSubmit={send} aria-busy={state === "sending" ? "true" : undefined}>
      <label className="sr-only" htmlFor="ask-input">
        Ask Vert
      </label>
      <div className="ask-joined" data-tray={tray ? "true" : undefined}>
        <div className="ask-box" data-ready={ready ? "true" : "false"} data-files={files.length || reading ? "true" : undefined}>
          {files.length || reading ? (
            <ul className="ask-files" aria-label="Attached files">
              {files.map((chip) => (
                <li key={chip.documentId} className="ask-file" data-file-chip={chip.documentId}>
                  <span className="ask-file-name" translate="no">
                    {chip.name}
                  </span>
                  <button type="button" className="ask-file-remove icon-btn" aria-label={`Remove ${chip.name}`} onClick={() => setFiles((prev) => prev.filter((c) => c.documentId !== chip.documentId))}>
                    <IconClose size={12} aria-hidden="true" />
                  </button>
                </li>
              ))}
              {reading ? (
                <li className="ask-file ask-file-reading" aria-live="polite">
                  Reading {reading === 1 ? "the file" : `${reading} files`}…
                </li>
              ) : null}
            </ul>
          ) : null}
          <div className="ask-row">
            {attachable ? (
              <>
                <IconButton label="Attach a file" className="ask-attach" onClick={() => pickerRef.current && pickerRef.current.click()}>
                  <IconAttach aria-hidden="true" />
                </IconButton>
                <input
                  ref={pickerRef}
                  className="sr-only"
                  type="file"
                  name="askFile"
                  accept={DOCUMENT_ACCEPT}
                  multiple
                  tabIndex={-1}
                  aria-hidden="true"
                  onChange={(event) => {
                    take(event.target.files);
                    event.target.value = "";
                  }}
                />
              </>
            ) : null}
            <textarea
              id="ask-input"
              name="ask"
              autoComplete="off"
              ref={inputRef}
              className="ask-input"
              rows={1}
              placeholder={narrow ? ASK_PLACEHOLDER_SHORT : ASK_PLACEHOLDER}
              value={text}
              maxLength={MESSAGE_MAX}
              readOnly={Boolean(disabledReason)}
              aria-describedby={disabledReason ? "ask-reason" : undefined}
              onChange={(e) => {
                setText(e.target.value);
                if (state === "failed") setState("idle");
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) send(e);
              }}
            />
            <IconButton label={state === "sending" ? "Sending" : "Send"} type="submit" className="ask-send" aria-disabled={ready ? undefined : "true"}>
              <IconSend size={16} weight="bold" aria-hidden="true" />
            </IconButton>
          </div>
        </div>
        {tray ? <SourcesLine month={month} place="tray" disabledReason={syncDisabledReason} /> : null}
      </div>
      {state === "sending" && sent ? <SendingNow text={sent} className="ask-sending" /> : null}
      <MessageCount length={askText(text, files).length} className="ask-count" />
      {refusal ? (
        <p className="ask-refusal t-footnote" role="alert">
          {refusal}
        </p>
      ) : null}
      {offered.length ? (
        <ul className="ask-suggestions" aria-label="Suggestions">
          {offered.map((s) => (
            <li key={s.id}>
              {s.href && !disabledReason ? (
                <Link className="chip ask-suggestion" href={s.href} data-suggestion={s.id}>
                  {s.label}
                </Link>
              ) : (
                <button
                  type="button"
                  className="chip ask-suggestion"
                  data-suggestion={s.id}
                  aria-disabled={disabledReason ? "true" : undefined}
                  aria-describedby={disabledReason ? "ask-reason" : undefined}
                  onClick={() => suggest(s)}
                >
                  {s.label}
                </button>
              )}
            </li>
          ))}
        </ul>
      ) : null}
      {disabledReason ? (
        <p className="ask-reason t-footnote" id="ask-reason">
          {disabledReason}
        </p>
      ) : null}
      {/* One line under the box, its room kept (DA2-074): the cause, that the words are
          still here, and a quiet Try again. */}
      <SendFailedLine className="ask-send-failed" failures={state === "failed" ? 1 : 0} onRetry={() => send()} text={failure} />
    </form>
  );
}
