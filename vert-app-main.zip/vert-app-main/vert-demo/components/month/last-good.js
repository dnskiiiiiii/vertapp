// components/month/last-good.js — THE LAST BOARD THIS TAB READ, FOR A READ THAT TIMED OUT
// ==============================================================================
// Staging browser walk 1 (31 Oct 2026, D2). October's `GET /close` took 15.3 s at ~13:41,
// over the web's 15 s read limit (lib/engine-source.js REQUEST_TIMEOUT_MS), and three of
// three loads drew "This month couldn't be read just now. Nothing was changed." — no rows,
// no sign-off — for a board that had read fine a minute before and read fine again by
// 13:50. The limit stays: a page that waits a minute for a month is worse than one that
// says it couldn't read it. What a timed-out read draws now is the last board this tab
// read for the same client and month, said to be from then ("Couldn't refresh just now ·
// as at 1:41 pm"), while the page asks once more in the background.
//
// WHERE IT IS KEPT. `sessionStorage`: this tab only, gone when it closes, never sent
// anywhere. Under a key the server derives from the signed-in key and the client chosen
// (app/page.js boardKeyOf), so a board kept for one client is never drawn for another,
// nor for the next person to sign in on this tab. Storage that is missing or throws (a
// private window) keeps nothing: the page then says the read failed, as it always did.
//
// NOTHING HERE COUNTS. A kept board is the payload as it was read, drawn as it was.

import { formatTime } from "@/lib/format";

const PREFIX = "vert:board:";
const PERIOD = /^[0-9]{4}-(0[1-9]|1[0-2])$/;
// Past this a board is kept without its open cards (the rows and counts still draw).
const MAX_BYTES = 1_500_000;

function slot(key, period) {
  return typeof key === "string" && key && PERIOD.test(String(period || "")) ? `${PREFIX}${key}:${period}` : null;
}

/** A month worth keeping as a board: read, started, and the month asked for. */
function keepable(month, period) {
  return Boolean(month && typeof month === "object" && month.opened === true && Array.isArray(month.tasks) && (!month.period || month.period === period));
}

/**
 * Keep `{ month, itemsByTask, runs, figures }` read at `at` (an ISO instant) for this
 * client key and month. Returns whether it was kept. Never throws.
 */
export function keepBoard(storage, key, period, board, at) {
  const where = slot(key, period);
  if (!where || !storage || !board || !keepable(board.month, period) || typeof at !== "string") return false;
  const whole = { v: 1, at, month: board.month, itemsByTask: board.itemsByTask || {}, runs: board.runs || {}, figures: board.figures || {} };
  try {
    let text = JSON.stringify(whole);
    if (text.length > MAX_BYTES) text = JSON.stringify({ ...whole, itemsByTask: {} });
    storage.setItem(where, text);
    return true;
  } catch {
    return false;
  }
}

/** The board kept for this client key and month, or null. Never throws. */
export function keptBoard(storage, key, period) {
  const where = slot(key, period);
  if (!where || !storage) return null;
  try {
    const kept = JSON.parse(storage.getItem(where) || "null");
    if (!kept || kept.v !== 1 || typeof kept.at !== "string" || !keepable(kept.month, period)) return null;
    return { at: kept.at, month: kept.month, itemsByTask: kept.itemsByTask || {}, runs: kept.runs || {}, figures: kept.figures || {} };
  } catch {
    return null;
  }
}

/** This tab's storage, or null where there is none (the server, a blocked window). */
export function tabStorage() {
  try {
    return typeof window !== "undefined" && window.sessionStorage ? window.sessionStorage : null;
  } catch {
    return null;
  }
}

/**
 * A month read that may answer if asked again: no answer at all (the 15 s limit, a
 * dropped connection) or the service's own failure (5xx). A refusal (403, 404) is the
 * answer, and a board kept from before would hide it.
 */
export function transientMonthFailure(read) {
  if (!read || read.ok) return false;
  const status = read.status;
  return status === 0 || status === null || status === undefined || (Number.isInteger(status) && status >= 500);
}

/** "Couldn't refresh just now · as at 1:41 pm". */
export function staleWords(at) {
  let time = null;
  try {
    time = formatTime(at);
  } catch {
    time = null;
  }
  return time ? `Couldn't refresh just now · as at ${time}` : "Couldn't refresh just now";
}

/** The page's props with the kept board laid over the failed read. Pure. */
export function keptProps(props, kept) {
  return {
    ...props,
    month: kept.month,
    itemsByTask: kept.itemsByTask || {},
    runs: kept.runs || {},
    figures: kept.figures || {},
    staleAt: kept.at,
    // Not the month as it is now: nothing is caught up from it, and the error is not drawn.
    canCatchUp: false,
    unreadReason: null,
  };
}
