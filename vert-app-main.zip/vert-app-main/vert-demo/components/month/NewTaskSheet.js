"use client";

// components/month/NewTaskSheet.js — NEW TASK: PICK WHAT VERT KNOWS, OR SAY IT YOURSELF
// ==============================================================================
// Founders' meeting, 22 Oct 2026. One prompt box was the only way to make a task, and the
// co-founder's wireframes asked for a form instead: a task's NAME, a DESCRIPTION the
// person writes ("it gives the agent more of an idea rather than having to figure it
// out by itself, which is more subject to errors"), and its FREQUENCY, then set it off.
// The founder wanted PRESETS that already know the task. Agreed: both. So two steps:
//
//   1. PICK. Every task Vert can run, from the engine (`GET /tasks/presets`: each
//      template's own title and one-sentence brief), under "Month-end" and "Anytime",
//      with a search; and "Start from scratch". A preset is sent as `template`, so the
//      skill is the person's choice and nothing is guessed.
//   2. DETAILS. Name; "Tell Vert exactly what to do" (prefilled with the preset's brief,
//      editable; required from scratch); Once / Every month; the month; and, folded under
//      More options, group, assignee, approver and due day (kept from the old sheet).
//      Then CREATE AND START (the one accent: the task's conversation opens with the
//      person's words as their first message, and Vert begins) or CREATE (the task waits
//      on the checklist for Start; `start: false`).
//
// WHERE THE WORDS GO. The engine writes the name and description as the conversation's
// first turn (vert_engine/tasks/conversation.py brief_of), and the chat model reads the
// description from the task in every turn's prompt (vert_agent/chat/knows.py
// task_brief), so a monthly copy and a later edit are read too.
//
// SELF-CONTAINED. Everything it needs is a prop: the months, the groups, the viewer, the
// presets (`readPresets()`, which the opener calls on its press: a page view sends
// nothing). NewTaskProvider.js mounts one for the whole shell and gives `openNewTask()`;
// the Month-end toolbar and the sidebar call it.
//
// THE DRAFT IS NOT THROWN AWAY (DA2-048, kept): Esc, X or the scrim on a sheet holding
// words asks "Discard this task?" first, and a page unload gets the browser's warning.
// A REFUSAL KEEPS THE INPUT, in the engine's words (every action in lib/tasks.js says what
// was recorded). A FAILED SUBMIT PUTS FOCUS ON THE FIELD IT NAMES (DA2-047).
//
// A PHONE GETS THE WHOLE SCREEN (the kit's bottom sheet, drawn full height: month.css).
// On a desk it is the kit's modal grown from what was pressed (apple-design §7).

import { useEffect, useId, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, Disclosure, Segmented, Sheet } from "@/components/ui";
import { createTask, createTaskGroup } from "@/lib/tasks";
import { callSafely } from "@/lib/decisions";
import { periodLabel } from "@/lib/period";
import { NO_GROUP, NewGroup } from "./GroupBy";
import { IconAdd, IconCaretDown, IconCaretLeft, IconSearch } from "@/components/ui/icons";
import { NARROW_ROW_QUERY } from "@/lib/breakpoints";
import { showsRegisterChrome } from "@/components/shared/registerChrome";

const NOT_SENT = "Not sent. Nothing was recorded.";

// The panel's size on a desk, for placing its origin over the trigger (month.css
// .task-sheet.sheet-modal .sheet).
const PANEL = Object.freeze({ width: 640, height: 560 });

/**
 * The transform-origin that puts the centred panel's growth point on the trigger:
 * the trigger's centre, in the panel's own coordinates. Null without a measured rect.
 */
export function originFromTrigger(rect, viewport, panel = PANEL) {
  if (!rect || !viewport || !Number.isFinite(rect.left) || !Number.isFinite(viewport.width)) return null;
  const w = Math.min(panel.width, viewport.width);
  const h = Math.min(panel.height, viewport.height);
  const left = (viewport.width - w) / 2;
  const top = (viewport.height - h) / 2;
  const x = Math.round(rect.left + rect.width / 2 - left);
  const y = Math.round(rect.top + rect.height / 2 - top);
  return `${x}px ${y}px`;
}

/** The Group field's options: "No group", then each group by its name. Pure. */
export function groupOptions(groups) {
  const list = Array.isArray(groups) ? groups : [];
  return [
    { value: "", label: NO_GROUP },
    ...list.map((g) => ({
      value: String(g.id),
      label: typeof g.name === "string" && g.name.trim() ? g.name.trim() : NO_GROUP,
    })),
  ];
}

function trimmed(v) {
  return typeof v === "string" && v.trim() ? v.trim() : null;
}

/* ── presets (step 1) ─────────────────────────────────────────────────────────── */

const TEMPLATE_ID = /^[a-z][a-z0-9_]*$/;

/**
 * The engine's presets as the form lists them: each with a template id, a title and a
 * brief, in the engine's order; a row missing any of them is left out, never drawn
 * with a hole. `null` for a read that failed (said in words, never as "no tasks"). Pure.
 */
export function presetsFrom(result) {
  if (!result || result.ok !== true || !Array.isArray(result.presets)) return null;
  const seen = new Set();
  const out = [];
  for (const p of result.presets) {
    if (!p || typeof p.template !== "string" || !TEMPLATE_ID.test(p.template) || seen.has(p.template)) continue;
    const title = trimmed(p.title);
    if (!title) continue;
    seen.add(p.template);
    out.push({
      template: p.template,
      title,
      brief: trimmed(p.brief) || "",
      onDemand: p.onDemand === true,
    });
  }
  return out;
}

/** The presets a search leaves: every word of the query in the title or the brief. Pure. */
export function filterPresets(presets, query) {
  const list = Array.isArray(presets) ? presets : [];
  const words = String(query || "")
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);
  if (!words.length) return list;
  return list.filter((p) => {
    const hay = `${p.title} ${p.brief}`.toLowerCase();
    return words.every((w) => hay.includes(w));
  });
}

/** The two headings the presets fall under: the checklist's own work, then the rest. Pure. */
export function presetSections(presets) {
  const list = Array.isArray(presets) ? presets : [];
  return [
    {
      key: "month-end",
      label: "Month-end",
      presets: list.filter((p) => !p.onDemand),
    },
    {
      key: "anytime",
      label: "Anytime",
      presets: list.filter((p) => p.onDemand),
    },
  ].filter((s) => s.presets.length);
}

/**
 * The presets, read once per page (they are the build's, not the client's): the list,
 * or null for a read that failed (asked again next time). Called from the press that
 * opens the form, never from an effect: a page view sends nothing (p0 quiet load). A
 * GET through app/api/tasks, never the `listTaskPresets` Server Action: that was a
 * `POST /` on every open (walkthrough, 27 Oct 2026). Never throws.
 */
let presetsRead = null;
export function readPresets(fetchImpl = globalThis.fetch) {
  if (!presetsRead) {
    presetsRead = (async () => {
      try {
        const res = await fetchImpl("/api/tasks?presets", { cache: "no-store", headers: { accept: "application/json" } });
        return presetsFrom(res && res.ok ? await res.json() : null);
      } catch {
        return null;
      }
    })().then((list) => {
      if (list === null) presetsRead = null;
      return list;
    });
  }
  return presetsRead;
}

/** Forget the page's presets, so the next open reads them again. For tests. */
export function forgetPresets() {
  presetsRead = null;
}

/* ── the request ──────────────────────────────────────────────────────────────── */

//: What a task started from scratch is told when it says nothing.
export const WORDS_NEEDED = "Tell Vert what to do, in a sentence or two.";

/**
 * The request `createTask` sends (`POST /tasks`), from what the form holds, or
 * `{ error }` naming the one field that stops it. Only what was given is sent.
 *
 * `fields.frequency` is "once" or "monthly" (`monthly: true` is the old sheet's spelling,
 * still read). A preset sends its `template`. From scratch (`fields.scratch`), the
 * description is required: it is the only thing Vert has to go on. `start: false` is
 * the form's Create; Create and start sends nothing (the engine's default).
 */
export function taskRequest(fields, period, { start = true } = {}) {
  const f = fields || {};
  const title = trimmed(f.title);
  if (!title) return { error: { field: "title", message: "Give the task a name." } };
  const monthly = f.frequency === "monthly" || f.monthly === true;
  const request = { title, recurrence: monthly ? "monthly" : "none" };
  const month = trimmed(f.period) || period;
  if (month) request.period = month;
  const description = trimmed(f.description);
  if (description) request.description = description;
  else if (f.scratch === true) return { error: { field: "description", message: WORDS_NEEDED } };
  if (typeof f.template === "string" && TEMPLATE_ID.test(f.template)) request.template = f.template;
  if (f.group !== undefined && f.group !== null && f.group !== "") request.group = f.group;
  const assignee = trimmed(f.assignee);
  if (assignee) request.assignee = assignee;
  const approver = trimmed(f.approver);
  if (approver) request.approver = approver;
  const due = dueDay(f.due);
  if (due.message) return { error: { field: "due", message: due.message } };
  if (due.day !== null) request.due = due.day;
  if (start === false) request.start = false;
  return { request };
}

//: What an unusable due day is told, on blur and on Create alike.
export const DUE_DAY_MESSAGE = "Enter a day of the month, 1 to 31.";

/**
 * The due field read as a day of the month: `{ day, message }`. Empty is no due day
 * (`day: null`, no message); "5" is 5; anything else ("31 Feb 2026", "0", "32") is
 * `DUE_DAY_MESSAGE`. The ONE reading the sheet's blur and its submit share (verify pass
 * 1, U46). Pure.
 */
export function dueDay(value) {
  const text = typeof value === "number" ? String(value) : trimmed(value);
  if (!text) return { day: null, message: null };
  const day = /^\d{1,2}$/.test(text) ? Number.parseInt(text, 10) : NaN;
  if (!(day >= 1 && day <= 31)) return { day: null, message: DUE_DAY_MESSAGE };
  return { day, message: null };
}

/**
 * What the sheet's outcome becomes when the due field loses focus: the due field's own
 * error when its words are no day, cleared when they are (only a due error is cleared;
 * any other outcome is kept). Pure.
 */
export function outcomeOnDueBlur(outcome, value) {
  const { message } = dueDay(value);
  if (message) return { state: "invalid", field: "due", message };
  if (outcome && outcome.state === "invalid" && outcome.field === "due") return null;
  return outcome;
}

/** Where a created task's conversation is: the session the engine started, or null. */
export function conversationOf(result) {
  if (!result || result.ok !== true) return null;
  const id = result.sessionId || (result.task && result.task.sessionId) || null;
  return typeof id === "string" && id ? `/chat/${encodeURIComponent(id)}` : null;
}

/** "Created “Accrue rent”. It's on the checklist; press Start when you're ready." Pure. */
export function heldWords(title) {
  const name = trimmed(title);
  return `Created ${name ? `“${name}”` : "the task"}. It's on the checklist; press Start when you're ready.`;
}

/**
 * Create the task. Returns `{ state, message? }`: `invalid` (nothing sent), `refused`
 * (the engine's words), `opened` (Create and start: navigated to its conversation),
 * `created` (started, but the engine named no conversation: the month is read again),
 * or `made` (Create: it waits on the checklist for Start).
 */
export async function submitNewTask(fields, { period, start = true, create = createTask, navigate, refresh } = {}) {
  const { request, error } = taskRequest(fields, period, { start });
  if (error) return { state: "invalid", field: error.field, message: error.message };
  let result;
  try {
    result = await create(request);
  } catch {
    return { state: "refused", message: NOT_SENT };
  }
  if (!result || result.ok !== true) {
    return {
      state: "refused",
      message: (result && typeof result.message === "string" && result.message) || NOT_SENT,
    };
  }
  if (start === false) {
    if (refresh) refresh();
    return { state: "made", message: heldWords(request.title) };
  }
  const href = conversationOf(result);
  if (href) {
    if (navigate) navigate(href);
    return { state: "opened", href };
  }
  if (refresh) refresh();
  return {
    state: "created",
    message: "Created. Its conversation will appear when Vert starts it.",
  };
}

/** Which kit placement the sheet takes now: a phone's full-screen sheet, else the desk's modal. */
export function readSheetSide() {
  return typeof window !== "undefined" && window.matchMedia && window.matchMedia(NARROW_ROW_QUERY).matches ? "bottom" : "modal";
}

/** What a fresh form holds: the signed-in person as assignee, once, this month. Pure. */
export function blankFields(viewer = null, period = null) {
  return {
    title: "",
    description: "",
    template: null,
    presetTitle: null,
    scratch: false,
    frequency: "once",
    period: period || "",
    group: "",
    assignee: viewer || "",
    due: "",
    approver: "",
  };
}

/** A preset's fields: its title as the name, its brief as the words, its skill. Pure. */
export function fieldsFromPreset(preset, base) {
  const p = preset || {};
  return {
    ...base,
    title: p.title || "",
    description: p.brief || "",
    template: p.template || null,
    presetTitle: p.title || null,
    scratch: false,
  };
}

const DIRTY_KEYS = ["title", "description", "group", "assignee", "due", "approver", "frequency"];

/** Whether the form holds anything a person typed or chose beyond the defaults. Pure. */
export function isDirty(fields, viewer = null, period = null) {
  if (!fields) return false;
  const blank = blankFields(viewer, period);
  return DIRTY_KEYS.some((k) => (typeof fields[k] === "string" ? fields[k].trim() : (fields[k] ?? "")) !== (typeof blank[k] === "string" ? blank[k].trim() : (blank[k] ?? "")));
}

//: The Group menu's value that opens "New group…" instead of choosing a group.
export const NEW_GROUP_VALUE = "__new";

/** The months the form offers: the shell's, closed ones left out, the given one kept. Pure. */
export function monthChoices(months, period) {
  const list = (Array.isArray(months) ? months : []).filter((m) => m && typeof m.period === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(m.period) && m.closed !== true);
  const out = list.map((m) => ({
    value: m.period,
    label: trimmed(m.label) || periodLabel(m.period),
  }));
  if (period && !out.some((m) => m.value === period)) out.unshift({ value: period, label: periodLabel(period) });
  return out;
}

/** Where the form opens: the details for a preset or words handed in, else the pick. Pure. */
export function initialStep(initial) {
  const i = initial || {};
  return i.template || trimmed(i.title) || trimmed(i.description) || i.step === "details" ? "details" : "pick";
}

/** The form's fields for what `openNewTask(options)` handed in. Pure. */
export function initialFields(initial, { viewer = null, period = null, presets = null } = {}) {
  const i = initial || {};
  const base = { ...blankFields(viewer, trimmed(i.period) || period) };
  let fields = base;
  if (typeof i.template === "string" && i.template) {
    const known = (presets || []).find((p) => p.template === i.template) || {
      template: i.template,
      title: trimmed(i.title) || "",
      brief: "",
    };
    fields = fieldsFromPreset(known, base);
  } else if (i.step === "details" || trimmed(i.title) || trimmed(i.description)) {
    fields = { ...base, scratch: true };
  }
  if (trimmed(i.title)) fields.title = i.title.trim();
  if (trimmed(i.description)) fields.description = i.description.trim();
  if (i.frequency === "monthly" || i.frequency === "once") fields.frequency = i.frequency;
  return fields;
}

const FREQUENCIES = [
  { value: "once", label: "Once" },
  { value: "monthly", label: "Every month" },
];

export default function NewTaskSheet({
  open,
  onClose,
  period = null,
  months = [],
  groups: given = [],
  viewer = null,
  origin = null,
  presets: handed = undefined,
  onRetryPresets = null,
  create = createTask,
  createGroup = createTaskGroup,
  draft = null,
  onDraft = null,
  initial = null,
}) {
  const router = useRouter();
  const formId = useId();
  const [made, setMade] = useState([]);
  const groups = [...(Array.isArray(given) ? given : []), ...made].filter((g) => g && g.id !== undefined && g.id !== null);
  // The presets, as the opener read them on its press: a list, null (the read failed),
  // or undefined (still reading).
  const presets = useMemo(() => (Array.isArray(handed) ? presetsFrom({ ok: true, presets: handed }) : handed === null ? null : undefined), [handed]);
  const start = () => ({
    ...initialFields(initial, { viewer, period, presets }),
    ...(draft || {}),
  });
  const [fields, setFieldsRaw] = useState(start);
  const [step, setStep] = useState(() => (draft && (draft.template || draft.scratch) ? "details" : initialStep(initial)));
  const [query, setQuery] = useState("");
  const [outcome, setOutcome] = useState(null);
  const [busy, setBusy] = useState(null); // "start" | "create" | null
  const [addingGroup, setAddingGroup] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const dirty = isDirty(fields, viewer, period);
  useUnsavedWarning(open && dirty);

  const retryPresets = () => {
    if (onRetryPresets) onRetryPresets();
  };

  const setFields = setFieldsRaw;
  // The draft is handed up as it changes (after render, never inside an updater).
  const draftRef = useRef(onDraft);
  draftRef.current = onDraft;
  useEffect(() => {
    if (draftRef.current) draftRef.current(isDirty(fields, viewer, period) ? fields : null);
  }, [fields, viewer, period]);
  const set = (key) => (e) => {
    const value = e.target.value;
    if (key === "group" && value === NEW_GROUP_VALUE) {
      setAddingGroup(true);
      return;
    }
    setFields((f) => ({ ...f, [key]: value }));
    if (confirming) setConfirming(false);
  };

  const requestClose = () => {
    if (busy) return;
    if (confirming) {
      setConfirming(false);
      return;
    }
    if (dirty) {
      setConfirming(true);
      return;
    }
    if (onClose) onClose();
  };
  const discard = () => {
    if (onDraft) onDraft(null);
    setConfirming(false);
    setFieldsRaw(blankFields(viewer, period));
    setStep("pick");
    if (onClose) onClose();
  };

  const formRef = useRef(null);
  const bodyRef = useRef(null);
  const focusField = (name) => {
    const root = formRef.current || bodyRef.current;
    const input = root && root.querySelector(`[name="${name}"]`);
    if (input) input.focus({ preventScroll: false });
  };

  function pick(preset) {
    setFields((f) =>
      preset
        ? fieldsFromPreset(preset, {
            ...blankFields(viewer, f.period || period),
            assignee: f.assignee,
          })
        : {
            ...blankFields(viewer, f.period || period),
            assignee: f.assignee,
            scratch: true,
          }
    );
    setOutcome(null);
    setStep("details");
  }
  // Into the details, focus goes where the person writes next: the words for a preset
  // (its name is already right), the name from scratch.
  const [arrived, setArrived] = useState(0);
  useEffect(() => {
    if (step !== "details" || !open) return undefined;
    const timer = window.setTimeout(() => focusField(fields.template ? "description" : "title"), 30);
    return () => window.clearTimeout(timer);
    // On arriving at the step only.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, open, arrived]);
  function back() {
    setStep("pick");
    setOutcome(null);
    window.setTimeout(() => focusField("presetSearch"), 30);
  }

  async function submit(startNow) {
    if (busy) return;
    setBusy(startNow ? "start" : "create");
    const title = fields.title;
    const out = await submitNewTask(fields, {
      period,
      start: startNow,
      create,
      navigate: (href) => router.push(href),
      refresh: () => router.refresh(),
    });
    setBusy(null);
    if (out.state === "invalid") {
      setOutcome(out);
      if (out.field === "due") {
        setMore(true);
        setMoreKey((k) => k + 1);
        window.setTimeout(() => focusField("due"), 30);
      } else focusField(out.field === "description" ? "description" : "title");
      return;
    }
    if (out.state === "refused") {
      setOutcome(out);
      return;
    }
    // Made. The draft is spent.
    if (onDraft) onDraft(null);
    if (out.state === "made") {
      // Create: the sheet stays, back at the pick, saying what was made, so the next
      // task is one press away (it replaces the old "Create another").
      setFieldsRaw({
        ...blankFields(viewer, period),
        assignee: fields.assignee,
        period: fields.period,
        group: fields.group,
      });
      setStep("pick");
      setQuery("");
      setOutcome({ state: "made", message: heldWords(title) });
      // Create's button leaves with the details: focus goes to the search, not <body>.
      window.setTimeout(() => focusField("presetSearch"), 30);
      return;
    }
    setOutcome(out);
    // Opened (Create and start went to the conversation) or created: the form's work is
    // done. The shell's one form outlives the page, so it closes itself; left open, it
    // sat over the conversation it had just opened.
    if ((out.state === "opened" || out.state === "created") && onClose) onClose();
  }
  const onSubmit = (event) => {
    event.preventDefault();
    submit(true);
  };
  // ⌘↩ / Ctrl+↩ in the words is Create and start, as in the ask box.
  const onWordsKeyDown = (event) => {
    if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
      event.preventDefault();
      submit(true);
    }
  };

  // A PHONE GETS THE WHOLE SCREEN; the server render, which has no window, is the modal.
  const [side, setSide] = useState(readSheetSide);
  const [more, setMore] = useState(false);
  // Bumped to re-mount More options open (a due day refused on Create is inside it).
  const [moreKey, setMoreKey] = useState(0);
  // KEPT MOUNTED BETWEEN OPENS (U37): each open reads the window again and starts from
  // what was handed in (or the kept draft), with no outcome and no discard question up.
  const [wasOpen, setWasOpen] = useState(open);
  const [wasInitial, setWasInitial] = useState(initial);
  if (open !== wasOpen || (open && initial !== wasInitial)) {
    setWasOpen(open);
    setWasInitial(initial);
    if (open) {
      const now = readSheetSide();
      if (now !== side) setSide(now);
      const fresh = initial ? initialFields(initial, { viewer, period, presets }) : { ...blankFields(viewer, period), ...(draft || {}) };
      setFieldsRaw(fresh);
      setStep(initial ? initialStep(initial) : draft && (draft.template || draft.scratch) ? "details" : "pick");
      setQuery("");
      setOutcome(null);
      setConfirming(false);
      setArrived((n) => n + 1);
    }
  }
  // A preset handed in by id before the list was read gets its brief once it is.
  useEffect(() => {
    if (!presets || !fields.template || fields.presetTitle) return;
    const known = presets.find((p) => p.template === fields.template);
    if (known)
      setFieldsRaw((f) =>
        f.template === known.template && !f.presetTitle
          ? {
              ...f,
              presetTitle: known.title,
              title: f.title || known.title,
              description: f.description || known.brief,
            }
          : f
      );
  }, [presets, fields.template, fields.presetTitle]);

  // On a desk with a fine pointer the search takes focus on the pick (WIG: autoFocus only
  // where it is the single primary input, never on a phone's keyboard).
  useEffect(() => {
    if (!open || step !== "pick" || side !== "modal" || typeof window === "undefined" || !window.matchMedia) return undefined;
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return undefined;
    const timer = window.setTimeout(() => focusField("presetSearch"), 60);
    return () => window.clearTimeout(timer);
  }, [open, side, step]);

  const onDueBlur = (event) => {
    const value = event.target.value;
    setOutcome((o) => outcomeOnDueBlur(o, value));
  };
  const fieldError = (name) => (outcome && outcome.state === "invalid" && outcome.field === name ? outcome.message : undefined);
  const monthOptions = monthChoices(months, fields.period || period);
  const shown = useMemo(() => filterPresets(presets || [], query), [presets, query]);
  const sections = presetSections(shown);

  // ↓ from the search to the first task, ↑ ↓ between tasks, Enter in the search picks
  // the first match: a person who knows what they want types it and presses Enter.
  const onListKeyDown = (event) => {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    const root = bodyRef.current;
    if (!root) return;
    const items = [...root.querySelectorAll("[data-preset-item]")];
    const at = items.indexOf(document.activeElement);
    const inSearch = event.target && event.target.name === "presetSearch";
    let next = null;
    if (event.key === "ArrowDown") next = inSearch ? items[0] : items[Math.min(items.length - 1, at + 1)];
    else next = at <= 0 ? root.querySelector('[name="presetSearch"]') : items[at - 1];
    if (next) {
      event.preventDefault();
      next.focus();
    }
  };
  const onSearchKeyDown = (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      if (shown.length) pick(shown[0]);
      else if (query.trim()) pick(null);
    }
  };

  const confirmFoot = (
    <div className="task-sheet-foot task-sheet-confirm" role="alertdialog" aria-labelledby={`${formId}-discard`}>
      <p className="task-sheet-question t-body" id={`${formId}-discard`}>
        Discard this task?
      </p>
      <Button variant="quiet" size="sm" onClick={() => (setConfirming(false), focusField(step === "pick" ? "presetSearch" : "title"))}>
        Keep editing
      </Button>
      <Button variant="quiet" size="sm" className="btn-destructive" onClick={discard}>
        Discard
      </Button>
    </div>
  );
  const detailsFoot = (
    <div className="task-sheet-foot">
      {outcome && outcome.state === "refused" ? (
        <p className="task-sheet-said t-footnote task-sheet-refused" role="alert">
          {outcome.message}
        </p>
      ) : null}
      <Button
        variant="secondary"
        size="sm"
        onClick={() => submit(false)}
        busy={busy === "create"}
        busyLabel="Creating…"
        disabled={Boolean(busy) && busy !== "create"}
        data-create-only=""
      >
        Create
      </Button>
      <Button variant="commit" type="submit" form={formId} busy={busy === "start"} busyLabel="Starting…" disabled={Boolean(busy) && busy !== "start"}>
        Create and start
      </Button>
    </div>
  );

  return (
    <Sheet
      open={open}
      onClose={requestClose}
      side={side}
      title="New task"
      origin={origin}
      className="task-sheet"
      footer={confirming ? confirmFoot : step === "details" ? detailsFoot : null}
    >
      <div ref={bodyRef} className="task-sheet-body" data-step={step}>
        {step === "pick" ? (
          <div className="task-pick" onKeyDown={onListKeyDown}>
            {outcome && outcome.state === "made" ? (
              <p className="task-sheet-made t-footnote" role="status" data-task-made="">
                {outcome.message}
              </p>
            ) : null}
            <p className="task-pick-lede t-body">Pick a task Vert already knows, or describe your own.</p>
            {/* THE REGISTER RULE (components/shared/registerChrome.js): a search over a
                long list only. While the list is read its length is not known, so the
                field is drawn rather than arriving under the person's cursor. */}
            {presets === undefined || showsRegisterChrome(Array.isArray(presets) ? presets.length : 0) ? (
              <label className="task-pick-search" htmlFor={`${formId}-search`}>
                <IconSearch className="task-pick-search-glyph" size={16} aria-hidden="true" />
                <span className="sr-only">Find a task</span>
                <input
                  id={`${formId}-search`}
                  name="presetSearch"
                  type="search"
                  className="task-pick-search-input"
                  placeholder="Find a task, e.g. accruals…"
                  autoComplete="off"
                  spellCheck={false}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={onSearchKeyDown}
                  aria-controls={`${formId}-presets`}
                />
              </label>
            ) : null}
            <div className="task-pick-list" id={`${formId}-presets`}>
              <button type="button" className="task-preset task-preset-scratch" data-preset-item="" data-preset="scratch" onClick={() => pick(null)}>
                <span className="task-preset-glyph" aria-hidden="true">
                  <IconAdd size={16} />
                </span>
                <span className="task-preset-words">
                  <span className="task-preset-title">Start from scratch</span>
                  <span className="task-preset-brief">Describe the task in your own words.</span>
                </span>
              </button>
              {presets === undefined ? (
                <ul className="task-preset-grid" aria-busy="true" aria-label="Reading Vert's tasks">
                  {[0, 1, 2, 3].map((i) => (
                    <li key={i} className="task-preset-skeleton" aria-hidden="true">
                      <span />
                      <span />
                    </li>
                  ))}
                </ul>
              ) : presets === null ? (
                <div className="task-pick-unread" role="status">
                  <p className="t-footnote">Vert couldn&apos;t read its tasks just now. Start from scratch, or try again.</p>
                  {onRetryPresets ? (
                    <Button variant="quiet" size="sm" onClick={retryPresets}>
                      Try again
                    </Button>
                  ) : null}
                </div>
              ) : sections.length ? (
                sections.map((section) => (
                  <section key={section.key} className="task-preset-section" aria-labelledby={`${formId}-${section.key}`}>
                    <h3 className="task-preset-heading t-footnote" id={`${formId}-${section.key}`}>
                      {section.label}
                    </h3>
                    <ul className="task-preset-grid">
                      {section.presets.map((p) => (
                        <li key={p.template}>
                          <button type="button" className="task-preset" data-preset-item="" data-preset={p.template} onClick={() => pick(p)}>
                            <span className="task-preset-words">
                              <span className="task-preset-title">{p.title}</span>
                              {p.brief ? <span className="task-preset-brief">{p.brief}</span> : null}
                            </span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  </section>
                ))
              ) : (
                <p className="task-pick-none t-footnote" role="status">
                  No task matches &ldquo;{query.trim()}&rdquo;. Start from scratch and describe it.
                </p>
              )}
            </div>
          </div>
        ) : (
          <form id={formId} ref={formRef} className="task-sheet-form" onSubmit={onSubmit} noValidate>
            <div className="task-details-back">
              <Button variant="quiet" size="sm" icon={<IconCaretLeft size={14} />} onClick={back} data-task-back="">
                All tasks
              </Button>
              {fields.presetTitle ? (
                <p className="task-details-skill t-footnote" data-task-skill={fields.template || ""}>
                  Vert follows its steps for {fields.presetTitle}. You can change them from the task.
                </p>
              ) : null}
            </div>
            <FormRow id={`${formId}-title`} label="Name" error={fieldError("title")}>
              <input
                id={`${formId}-title`}
                className="field-input"
                name="title"
                autoComplete="off"
                placeholder="e.g. Accrue September rent…"
                value={fields.title}
                onChange={set("title")}
                aria-invalid={fieldError("title") ? "true" : undefined}
                aria-describedby={fieldError("title") ? `${formId}-title-error` : undefined}
              />
            </FormRow>
            <FormRow
              id={`${formId}-description`}
              label="Tell Vert exactly what to do"
              error={fieldError("description")}
              hint="Vert reads this before it starts, and every month the task repeats."
              className="task-field-words"
            >
              <textarea
                id={`${formId}-description`}
                className="field-input task-words"
                name="description"
                autoComplete="off"
                rows={4}
                value={fields.description}
                onChange={set("description")}
                onKeyDown={onWordsKeyDown}
                required={fields.scratch ? true : undefined}
                placeholder="e.g. Accrue the office rent. It's billed quarterly in arrears, so accrue a third each month…"
                aria-invalid={fieldError("description") ? "true" : undefined}
                aria-describedby={`${formId}-description-hint${fieldError("description") ? ` ${formId}-description-error` : ""}`}
              />
            </FormRow>
            <div className="task-details-row">
              <div className="form-field task-field task-field-frequency" role="group" aria-labelledby={`${formId}-frequency`}>
                <span className="field-label" id={`${formId}-frequency`}>
                  How often
                </span>
                <Segmented
                  label="How often"
                  options={FREQUENCIES}
                  value={fields.frequency === "monthly" ? "monthly" : "once"}
                  onChange={(v) => setFields((f) => ({ ...f, frequency: v }))}
                />
                <input type="hidden" name="frequency" value={fields.frequency === "monthly" ? "monthly" : "once"} />
              </div>
              {monthOptions.some((m) => m.value !== (fields.period || period)) ? (
                <FormRow id={`${formId}-period`} label={fields.frequency === "monthly" ? "Starting" : "Month"} className="field-select task-field-month" caret>
                  <select id={`${formId}-period`} name="period" className="field-input" autoComplete="off" value={fields.period || period || ""} onChange={set("period")}>
                    {monthOptions.map((m) => (
                      <option key={m.value} value={m.value}>
                        {m.label}
                      </option>
                    ))}
                  </select>
                </FormRow>
              ) : null}
            </div>
            <Disclosure
              key={`more-${moreKey}`}
              summary={<span className="task-more-label">More options</span>}
              defaultOpen={more}
              className="task-more"
              onToggle={(isOpen) => setMore(isOpen)}
            >
              <div className="task-more-grid">
                <FormRow id={`${formId}-group`} label="Group" className="field-select" caret>
                  <select id={`${formId}-group`} name="group" className="field-input" autoComplete="off" value={fields.group} onChange={set("group")}>
                    {groupOptions(groups).map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                    <option value={NEW_GROUP_VALUE}>New group…</option>
                  </select>
                </FormRow>
                <FormRow id={`${formId}-assignee`} label="Assignee">
                  <input
                    id={`${formId}-assignee`}
                    name="assignee"
                    className="field-input"
                    value={fields.assignee}
                    onChange={set("assignee")}
                    placeholder="Who does it…"
                    autoComplete="off"
                  />
                </FormRow>
                <FormRow id={`${formId}-approver`} label="Approver">
                  <input
                    id={`${formId}-approver`}
                    name="approver"
                    className="field-input"
                    value={fields.approver}
                    onChange={set("approver")}
                    placeholder="Who marks it complete…"
                    autoComplete="off"
                  />
                </FormRow>
                <FormRow id={`${formId}-due`} label="Due day" error={fieldError("due")}>
                  <input
                    id={`${formId}-due`}
                    name="due"
                    className="field-input"
                    inputMode="numeric"
                    value={fields.due}
                    onChange={set("due")}
                    onBlur={onDueBlur}
                    placeholder="Day of month, e.g. 5…"
                    autoComplete="off"
                    aria-invalid={fieldError("due") ? "true" : undefined}
                    aria-describedby={fieldError("due") ? `${formId}-due-error` : undefined}
                  />
                </FormRow>
              </div>
              {addingGroup ? (
                <div className="task-sheet-new-group-row">
                  <NewGroup
                    create={createGroup}
                    initialOpen
                    onCancel={() => setAddingGroup(false)}
                    onCreated={(group) => {
                      setMade((m) => [...m, group]);
                      setFields((f) => ({ ...f, group: String(group.id) }));
                      setAddingGroup(false);
                    }}
                  />
                </div>
              ) : null}
            </Disclosure>
          </form>
        )}
      </div>
    </Sheet>
  );
}

/** One labelled field in the kit's box, its error and hint under it (components/ui/fields.js). */
function FormRow({ id, label, error, hint, className, caret = false, children }) {
  return (
    <div className={["form-field", "task-field", error ? "field-invalid" : null, className].filter(Boolean).join(" ")} data-ui="Field">
      <label className="field-label" htmlFor={id}>
        {label}
      </label>
      <div className="field-box">
        {children}
        {caret ? <IconCaretDown className="task-field-caret" size={12} aria-hidden="true" /> : null}
      </div>
      {error ? (
        <p className="field-error" id={`${id}-error`} role="alert">
          {error}
        </p>
      ) : null}
      {hint ? (
        <p className="field-hint" id={`${id}-hint`}>
          {hint}
        </p>
      ) : null}
    </div>
  );
}

/** The browser's own "leave site?" while `dirty` (WIG: warn before losing unsaved input). */
export function useUnsavedWarning(dirty) {
  useEffect(() => {
    if (!dirty || typeof window === "undefined") return undefined;
    const warn = (event) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
}
