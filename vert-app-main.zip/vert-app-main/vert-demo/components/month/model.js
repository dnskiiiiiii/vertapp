// components/month/model.js — MONTH-END, FROM THE PAYLOAD, WITH NOTHING ADDED UP
// ==============================================================================
// Spec §3.2 and §4.4; build plan §2.3 (`GET /close/{period}`). Pure functions from the
// close payload (and each needs-you task's events) to what Month-end draws.
//
// EVERY COUNT ON THE PAGE IS THE PAYLOAD'S (UI-001). The header's "2 of 12 tasks
// done", the pager's decision count, the sidebar badge and each task row's "4 decisions" are `counts.decisions` and
// each task's `decisions`, read straight off `GET /close/{period}` — the engine computed
// them once (vert_engine/workflows/status.py) and the screen adds nothing. Nothing in
// this file sums, subtracts or recounts a number that is shown: tests/month.test.js holds
// the header, the sidebar's input and the rows to the same payload.
//
// ONLY THE PAYLOAD'S TASKS ARE LISTED (spec §1.9). A task appears because the API sent
// it, in the order it sent it (the engine's priority), under the word it sent — and a
// word outside the four is refused, not drawn in a guessed style (lib/status.js).
//
// UNMEASURED IS NEVER ZERO (spec §9.4). A payload with no counts is "not read yet" in
// words, never "0 decisions".

import { isStatusWord } from "@/lib/status";
import { isPeriod, monthName as periodMonthName, periodLabel } from "@/lib/period";
import { freshnessWords, shortDate } from "@/lib/agent/words";
import { ledgerAsAtOf as asAtWords } from "@/components/chat/answer/financial-statements";
import { accountName, formatMoney, metaLine } from "@/lib/format";

export const GROUP_ORDER = Object.freeze(["Needs you", "Vert's working", "Waiting", "Done"]);

function isCount(n) {
  return typeof n === "number" && Number.isInteger(n) && n >= 0;
}

/** "1 decision" / "29 decisions". */
export function decisionsWord(n) {
  return `${n} ${n === 1 ? "decision" : "decisions"}`;
}

/** The month's name as the payload labels it, else from the period. */
export function monthLabel(month, period = null) {
  if (month && typeof month.label === "string" && month.label.trim()) return month.label.trim();
  const p = (month && month.period) || period;
  return p ? periodLabel(p) : "This month";
}

/**
 * The month before this one by name, "June" for July: the comparison chip says the month
 * it compares with ("Compare with June"), not the idea of a month ("last month"). Null
 * when the period is not an ISO month.
 */
export function priorMonthName(month, period = null) {
  const p = (month && month.period) || period;
  if (!isPeriod(p)) return null;
  const [y, m] = String(p).split("-").map(Number);
  const prior = m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, "0")}`;
  return periodMonthName(prior);
}

/** Just the month's name, "September", for "Start September". */
export function monthName(month, period = null) {
  return monthLabel(month, period).split(" ")[0];
}

/**
 * Which of the four page states the payload is in (spec §3.2):
 *   not_read     the payload has no counts: nothing to say but that, in words
 *   not_started  the month has not been opened (Start September)
 *   closed       never opened, and closed in Vert: reviewed, never started (no Start)
 *   done         every task is Done
 *   running      anything else
 */
export function monthState(month) {
  if (!month || typeof month !== "object" || !month.counts || !isCount(month.counts.total)) return "not_read";
  // A CLOSED MONTH IS NOT A MONTH TO START (verify pass 7, S-BK-6; pass 6 F7). A month
  // closed in Vert (its close photograph, the engine's `changedAfterClose.closedAt`)
  // whose checklist was never run read "June was closed on 20 Oct." over "Start June":
  // the header had learnt the word, the state every other part of the page reads had
  // not. One state, so no part of the page can offer to start a closed month.
  if (month.opened === false) return closedOn(month) ? "closed" : "not_started";
  const c = month.counts;
  if (c.total > 0 && c.done === c.total) return "done";
  return "running";
}

/**
 * What the header says between a decision and the month's re-read. The card collapses
 * the moment the write is accepted (UI-012), but the count comes from the API and
 * arrives with the re-rendered page a second or two later; until then the number in
 * hand is the one from BEFORE the decision. The eval (30 Sep) read that number and
 * reported "25 → 25" for an approval that had landed. A figure that is no longer
 * current is not shown as if it were — the same rule as "unmeasured is never zero"
 * (spec §9.4) — so for that moment the header says what is happening instead.
 */
export const RECOUNTING = "Counting again…";

/**
 * What the header says while the month catches up (build plan §4.0.2). When the inputs
 * have moved since a task last ran, `GET /close` says `catchUp.needed`, and Month-end
 * calls `POST /close` once to bring every task's cards up to the month. Until that
 * lands, the counts in hand describe the cards as they were, so — like RECOUNTING — they
 * are not shown as current. The words add no lexicon idea ("Checking the sources for
 * changes…" would be a sixth idea on the page for one second's work).
 *
 * It used to borrow the status word, "Vert's working…". Eval r3 (output-visual F15,
 * CO-21) saw September say "Vert's working…" in the header while the progress legend
 * under it said "Vert's working 0": the same word for a task state and for the page's
 * own catch-up, one claiming work the other denied. The catch-up has its own words now,
 * and tests/month-iter4-cards.test.js holds the header off every status word.
 */
export const CATCHING_UP = "Catching up on what changed…";

/**
 * Whether the month asks to be caught up: the payload's own `catchUp.needed`, on a
 * month that is open (running or done). Read, never inferred: the page does not decide
 * a month is behind, the engine does (vert_api close.py `catch_up_state`).
 */
/**
 * A CLOSED MONTH THAT CHANGED AFTER IT CLOSED (verify pass 4, S-BK-6). `GET /close/{p}`
 * sends `changedAfterClose` when lines dated in a closed month arrived after its close
 * (a back-dated bill into June): the engine's sentence and each line, measured. Month-end
 * never drew it, so June read "June hasn't started" and nothing else while its closed
 * figures had moved. Shaped here, never worked out: each line's account, day, how and
 * amount are the engine's. `{ words, lines: [{ key, account, day, how, amount }] }`, or
 * null when the engine sent nothing to say. A read that could not be made
 * (`measured: false`) says so in words rather than reading as "unchanged". Pure.
 */
/**
 * The day a month was closed in Vert ("18 Oct"), or null. The engine sends
 * `changedAfterClose` with `closedAt` whenever the month has a close photograph, measured,
 * changed or not (vert_engine/analysis/after_close.py `closed_month_changes`); an unread
 * check (`measured: false`) or no photograph claims nothing. Pure.
 */
export function closedOn(month) {
  const c = month && typeof month === "object" ? month.changedAfterClose : null;
  if (!c || typeof c !== "object" || c.measured === false) return null;
  return typeof c.closedAt === "string" && c.closedAt ? shortDate(c.closedAt) : null;
}

export function changedAfterCloseOf(month, { open = false } = {}) {
  // An open month (reopened since its close) is never told it "changed after it was
  // closed … reopen it" (staging browser walk 3, W3-2): it is open.
  if (open) return null;
  const c = month && typeof month === "object" ? month.changedAfterClose : null;
  if (!c || typeof c !== "object") return null;
  const words = typeof c.words === "string" && c.words.trim() ? c.words.trim() : null;
  if (c.measured === false) {
    return { words: words || "Vert couldn't check whether this month changed after it was closed.", lines: [], measured: false };
  }
  const lines = (Array.isArray(c.lines) ? c.lines : [])
    .filter((l) => l && typeof l === "object")
    .map((l, i) => ({
      key: typeof l.lineId === "string" && l.lineId ? l.lineId : `line-${i}`,
      account: typeof l.accountName === "string" && l.accountName.trim() ? l.accountName.trim() : typeof l.account === "string" ? l.account : null,
      day: typeof l.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(l.date) ? l.date : null,
      how: typeof l.how === "string" && l.how ? l.how : null,
      // In a sentence, so the prose minus ("−$855.54"), never the table's parentheses.
      amount: Number.isInteger(l.cents) ? formatMoney(l.cents) : null,
    }));
  if (!words && !lines.length) return null;
  return { words: words || "This month changed after it was closed.", lines, measured: true };
}

export function catchUpNeeded(month) {
  const state = monthState(month);
  if (state !== "running" && state !== "done") return false;
  return Boolean(month.catchUp && typeof month.catchUp === "object" && month.catchUp.needed === true);
}

/**
 * The verdict: "2 of 12 tasks done". The payload's two counts and nothing else.
 *
 * DESIGN-FIX-2 (DA2-006, 10 Oct 2026): it used to add "· 13 decisions need you", and Home
 * said "13" four times — the sidebar badge, this line, a "13 decisions" chip on the
 * Needs-you head and the decision pager's "1 of 13". A fact is said once per view: the
 * pager in the open card's head owns the decision count, so the header says only how far
 * the month has got. The decisions are still the payload's (`counts.decisions`), read by
 * the pager and the sidebar, never by this line.
 */
export function verdictLine(month, { recounting = false, catchingUp = false } = {}) {
  const state = monthState(month);
  if (state === "not_read") return null;
  const c = month.counts;
  const name = monthName(month);
  // A month closed in Vert whose checklist was never run is not a month that "hasn't
  // started" (verify pass 5, S-BK-6): it was closed. Said from the engine's own
  // `changedAfterClose.closedAt` (the close's photograph), never inferred.
  if (state === "closed") return `${name} was closed on ${closedOn(month)}.`;
  if (state === "not_started") return `${name} hasn't started.`;
  // The month is being brought up to its cards (CATCHING_UP, above): the counts in hand
  // are from before, so the header says what is happening instead.
  if (catchingUp) return CATCHING_UP;
  // A decision was just made and the month is being read again: the counts in hand are
  // from before it, so they are not shown as current (RECOUNTING, below).
  if (recounting) return RECOUNTING;
  if (state === "done") return `${name} is done. ${c.done} of ${c.total}.`;
  return `${c.done} of ${c.total} ${c.total === 1 ? "task" : "tasks"} done`;
}

/**
 * The header's anchor figure (DA2-022): `{ done, total }` straight off the payload, or
 * null when either is unmeasured or the month is not open. Drawn "2 / 12" in the display
 * face beside the title; the sentence above is its accessible text.
 */
export function anchorFigure(month) {
  const state = monthState(month);
  if (state !== "running" && state !== "done") return null;
  const c = month.counts;
  return isCount(c.done) && isCount(c.total) ? { done: c.done, total: c.total } : null;
}

/**
 * The quiet line under the anchor: the open work in words, each count the payload's,
 * a word with nothing in it left out ("7 need you, 2 waiting, 1 with Vert"). Null when
 * any of the three is unmeasured: a missing count is never read as none.
 */
export function openWorkLine(month) {
  const c = month && month.counts;
  if (!c || ![c.needsYou, c.waiting, c.working].every(isCount)) return null;
  const parts = [];
  if (c.needsYou > 0) parts.push(`${c.needsYou} need${c.needsYou === 1 ? "s" : ""} you`);
  if (c.waiting > 0) parts.push(`${c.waiting} waiting`);
  if (c.working > 0) parts.push(`${c.working} with Vert`);
  return parts.length ? parts.join(", ") : null;
}

/**
 * The header's count of what waits on a person (checklist U61, verify pass 1 F-9): the
 * month's DECISIONS, "13 for you to decide", the figure the sidebar badge, the pager,
 * the task rows and `GET /close` all hold. The header used to say "6 need you" — six
 * TASKS — beside a pager reading "1 of 13", so the five counts could not agree. Null
 * when the count is unmeasured or nothing waits; the task words are the strip's
 * (Progress.js), with their glyphs.
 */
export function decisionsLine(month) {
  const n = month && month.counts ? month.counts.decisions : null;
  if (!isCount(n) || n === 0) return null;
  // "13 for you to decide": the decisions' count in a verb, so the header adds no sixth
  // idea above the fold (the S4 lexicon counts "decision" as one; W0d's five-idea limit).
  return `${n} for you to decide`;
}

/**
 * A stable key for a row, pure: a person's task's `id`; a row BESIDE the checklist (the
 * engine's `beside`: an account's own rec, a task run on demand, an entry asked for in
 * the chat) its conversation, `chat:<sessionId>`, since two of them may share a template
 * (094's rec and 090's) and the month's own row has it too; else its template. Every
 * per-row map on Month-end (the open cards, the figures, the kept plates) is keyed by it.
 */
export function taskKey(task) {
  if (!task || typeof task !== "object") return null;
  if (task.id) return task.id;
  if (task.beside && typeof task.sessionId === "string" && task.sessionId) return `chat:${task.sessionId}`;
  return task.template || null;
}

/**
 * The payload's tasks under their four words, each group in payload order. A task with
 * a word outside the four is dropped from every group and reported in `unknown`, so a
 * caller can refuse loudly rather than draw it.
 */
export function groupTasks(month) {
  const groups = { "Needs you": [], "Vert's working": [], Waiting: [], Done: [] };
  const unknown = [];
  const tasks = month && Array.isArray(month.tasks) ? month.tasks : [];
  for (const task of tasks) {
    if (!task || typeof task !== "object") continue;
    if (isStatusWord(task.status)) groups[task.status].push(task);
    else unknown.push(task);
  }
  return { groups, unknown };
}

/**
 * What a task's row says beside its title, or null: "4 decisions" (the task's own count
 * from the payload) for a task that needs you, else the engine's `line` ("after the
 * payout breaks and the bank rec"). The Checklist card draws it as a chip to the right
 * of the title (visual spec §3); a line that only repeats the status word is dropped,
 * because the status chip beside it already says it.
 */
export function taskRowChip(task, { recounting = false, statusShown = true } = {}) {
  // While the month is read again after a decision, a task's count is from before it.
  if (recounting && task.status === "Needs you") return null;
  if (task.status === "Needs you" && isCount(task.decisions) && task.decisions > 0) {
    return decisionsWord(task.decisions);
  }
  const line = typeof task.line === "string" && task.line.trim() ? task.line.trim() : null;
  // A ROW NEVER GOES BLANK BESIDE A STATUS IT DOES NOT DRAW (verify pass 3, S-E2E-1).
  // The line that only repeats the word is dropped where the row draws the word itself;
  // under a status band the row draws no word, and dropping it there left Deferred
  // revenue the one Done row with an empty column, where `GET /close` said "Done" — it
  // read as a status Vert had not worked out. There the line is kept.
  if (line && line === task.status) return statusShown ? null : line;
  return line;
}

/** "Resolve payout breaks · 4 decisions", with the task's own count from the payload. */
export function taskRowText(task, { recounting = false } = {}) {
  const title = typeof task.title === "string" ? task.title : "A task";
  const chip = taskRowChip(task, { recounting });
  return chip ? `${title} · ${chip}` : title;
}

/**
 * THE BANK REC'S CLOSING BALANCE ON ITS CHECKLIST ROW (verify pass 3, S-UI-11). The
 * chat, the bank-rec card and its workbook all state the account's closing balance;
 * Month-end stated none, so the one figure could not be checked on the fourth surface.
 * Read from the task's own conversation — the LATEST bank-rec result (`artifact`,
 * `kind: "bank_rec"`) and its named figures `books` and `statement` — never worked out
 * here. Written in the chat's prose convention, a leading true minus
 * ("−$389,063.90"), so the row and the sentence read the same.
 *
 *   null                                 the conversation was not read: nothing is said
 *   { state: "not_yet", text }           read, and no reconciliation in it yet
 *   { state: "reconciled", cents, text } the rec is SETTLED: nothing in its conversation is open
 *                                        and its task (when given) is Done
 *   { state: "open", cents, text }       a result is in, but a question or card after it is
 *                                        still open, or its task is not Done
 *   { state: "unmeasured", text }        a result whose balance Vert did not measure
 *   { state: "several", text }           results for more than one account: no one figure
 *
 * EVERY FIGURE SAYS WHOSE IT IS (verify pass 5, S-UI-11). Pass 4 made the bare word
 * "Closing" the statement's balance; pass 5 then saw stresslab July's row read "1 decision
 * · Closing −$382,478.90" — the bank's figure, unlabelled — while the chat, the pane and
 * the workbook all led with the books' −$387,463.90, and while the rec still had a
 * question and a draft open. So: the books' balance leads, labelled "Books"; the
 * statement's is beside it as "bank statement" when it differs; the bare "Closing" is
 * said only when the two agree, because then it is true of both. And a result is
 * "reconciled" only when the rec is settled: `pending` (the month's pending action ids,
 * as `openItems` takes it) and the task's `status` say whether anything is still open.
 *
 * Pure.
 */
export function bankRecFigureOf(events, { pending = null, status = null } = {}) {
  if (!Array.isArray(events)) return null;
  const results = events
    .filter((e) => e && e.type === "artifact" && e.payload && e.payload.kind === "bank_rec")
    .sort((a, b) => (a.seq || 0) - (b.seq || 0));
  // NO WORDS OF THE PAGE'S OWN (engine w3/int, staging browser walk 1, D3/D4). The row's
  // line is the engine's — "Not reconciled yet: Vert has a question to put to you", "1 of
  // 2 accounts reconciled" — so a rec with no result yet, or results for more than one
  // account, adds nothing beside it: it said "Not reconciled yet" twice.
  if (!results.length) return { state: "not_yet", text: null };
  const accounts = new Set(results.map((e) => (typeof e.payload.title === "string" ? e.payload.title : "")));
  if (accounts.size > 1) return { state: "several", text: null };
  const last = results[results.length - 1].payload;
  const read = (f) => Boolean(f && f.measured !== false && typeof f.cents === "number" && Number.isFinite(f.cents));
  const figures = last.figures || {};
  const statement = read(figures.statement) ? figures.statement.cents : null;
  const books = read(figures.books) ? figures.books.cents : null;
  if (statement == null && books == null) return { state: "unmeasured", text: "Closing balance not read" };
  const open = openItems(events, { pending }).length > 0 || (typeof status === "string" && status !== "Done");
  const state = open ? "open" : "reconciled";
  if (books != null && statement != null) {
    if (books === statement) return { state, cents: books, text: `Closing ${formatMoney(books)}` };
    return { state, cents: books, text: `Books ${formatMoney(books)} · bank statement ${formatMoney(statement)}` };
  }
  if (books != null) return { state, cents: books, text: `Books ${formatMoney(books)}` };
  return { state, cents: statement, text: `Bank statement ${formatMoney(statement)}` };
}

/**
 * The figure a rec's row draws beside its line, or null. A line the engine rolled up over
 * several accounts ("1 of 2 accounts reconciled", one conversation per account since
 * walk 1, D3) is not one account's: the month conversation's balance beside it would
 * read as the whole. Pure.
 */
export const ACCOUNTS_ROLL_UP = /^\d+ of \d+ accounts reconciled$/;
export function rowFigureOf(task, figure) {
  if (!figure || !figure.text) return null;
  const line = task && typeof task.line === "string" ? task.line.trim() : "";
  return ACCOUNTS_ROLL_UP.test(line) ? null : figure;
}

/** The template whose row carries the bank rec's closing balance. */
export const BANK_REC_TEMPLATE = "bank_reconciliation";

/**
 * What is still open in one task's conversation, in the order the task raised it:
 * decision cards (`action_request` with no `decision_settled` after it) and questions
 * (`clarification` with no `clarification_answered`).
 *
 * Read from the raw events rather than the chat's thread model on purpose: a card needs
 * its whole payload — `figures` included — and a question's title carries its amount as
 * `{{fig:amount}}`, which only the event's own `figures` can bind.
 *
 * `pending`, when given, is the set of action ids the API still lists as pending
 * (`pendingActions`). An action it no longer lists was settled — perhaps by the API's
 * re-verification, before its `decision_settled` reached this read — and is not drawn.
 */
export function openItems(events, { pending = null } = {}) {
  const list = Array.isArray(events) ? [...events].sort((a, b) => (a.seq || 0) - (b.seq || 0)) : [];
  const settled = new Set();
  const answered = new Set();
  for (const e of list) {
    const p = (e && e.payload) || {};
    if (e.type === "decision_settled" && p.actionId != null) settled.add(p.actionId);
    if (e.type === "clarification_answered" && p.questionId != null) answered.add(p.questionId);
  }
  const items = [];
  const seenQuestions = new Set();
  for (const e of list) {
    const p = (e && e.payload) || {};
    if (e.type === "action_request" && p.actionId != null && !settled.has(p.actionId)) {
      if (pending && !pending.has(p.actionId)) continue;
      items.push({ type: "action", key: `a:${p.actionId}`, action: { ...p, basis: e.basis ?? null } });
    } else if (e.type === "clarification" && p.questionId != null && !answered.has(p.questionId) && !seenQuestions.has(p.questionId)) {
      seenQuestions.add(p.questionId);
      items.push({
        type: "question",
        key: `q:${p.questionId}`,
        question: {
          questionId: p.questionId,
          title: typeof p.title === "string" ? p.title : "",
          why: typeof p.why === "string" ? p.why : "",
          options: Array.isArray(p.options) ? p.options.filter((o) => o && o.id != null) : [],
          allowSkip: p.allowSkip === true,
          form: p.form && typeof p.form === "object" ? p.form : null,
          figures: p.figures && typeof p.figures === "object" ? p.figures : {},
          // The evidence and the named ground travel with the question (eval r2, FJ-fix2
          // finding 4): ChooseDepositQuestion defaults the pin's ground from them, and
          // without them Month-end's card asked on the face what the chat card already
          // knew, and "Use this one" sat disabled on a guess the engine had evidenced.
          evidence: p.evidence && typeof p.evidence === "object" ? p.evidence : null,
          ground: typeof p.ground === "string" ? p.ground : null,
        },
      });
    }
  }
  return items;
}

/** The ids the payload lists as pending, or null when it lists none at all. */
export function pendingIds(month) {
  const list = month && Array.isArray(month.pendingActions) ? month.pendingActions : null;
  if (!list) return null;
  return new Set(list.map((a) => a && a.actionId).filter(Boolean));
}

/** Sources that need a person: stale or failed. Connected-but-fresh ones do not. */
export function sourcesNeedingYou(month) {
  const list = month && Array.isArray(month.sources) ? month.sources : [];
  return list.filter((s) => s && ((s.freshness && (s.freshness.state === "stale" || s.freshness.state === "failed")) || ledgerAsAtOf(s.asAt).behind));
}

/**
 * THE LEDGER'S AS-AT (staging browser walk 1, D5). The engine's ledger source row on
 * `GET /close/{period}` carries `asAt: {readAt, words, behind, behindWords, written}`,
 * and `/statements` and `/pack` the same as `ledgerAsAt`: "Xero as at 31 Oct 2026, 12:20
 * pm", and, when Vert has written to the ledger since that read, what it wrote and that
 * a sync brings it in. The engine's words, as sent: `{ words, behind, behindWords }`,
 * `words` null when none came. Pure.
 */
export function ledgerAsAtOf(raw) {
  return asAtWords(raw) || { words: null, behind: false, behindWords: null };
}

/**
 * WHEN THE PACK'S FIGURES WERE READ (staging browser walk 2, N8). The PDF and Excel pack
 * carry no as-at line; the pack's row on Month-end says it, from the month's own ledger
 * read (the same `asAt` the engine sends on `/pack` as `ledgerAsAt`): "Xero as at 1 Nov
 * 2026, 6:00 am", and what Vert wrote to the ledger since. Null when none was read. Pure.
 */
export function packAsAtOf(month) {
  const list = month && Array.isArray(month.sources) ? month.sources : [];
  for (const s of list) {
    const asAt = ledgerAsAtOf(s && s.asAt);
    if (asAt.words) return asAt.behindWords ? `${asAt.words}. ${asAt.behindWords}` : asAt.words;
  }
  return null;
}

/**
 * What one source's row says after its name: the ledger's as-at in the engine's words
 * ("as at 31 Oct 2026, 12:20 pm", the name the row already shows left off), then what
 * Vert wrote since, when it did; any other source's freshness in words. Pure.
 */
export function sourceWords(source) {
  const s = source && typeof source === "object" ? source : {};
  // A CONNECTED LEDGER POSTING CAN'T REACH YET (production, 3 Nov 2026): its read is
  // said as it stands, then, apart, what posting needs ("Posting needs the account
  // mapping."), never "not connected".
  const posting = s.posting && typeof s.posting.words === "string" && s.posting.words.trim() ? s.posting.words.trim() : null;
  const withPosting = (words) => (posting ? `${words}. ${posting}` : words);
  const asAt = ledgerAsAtOf(s.asAt);
  if (!asAt.words) return withPosting(freshnessWords(s.freshness));
  const label = typeof s.label === "string" ? s.label.trim() : "";
  const own = label && asAt.words.startsWith(`${label} `) ? asAt.words.slice(label.length + 1) : asAt.words;
  return withPosting(asAt.behindWords ? `${own}. ${asAt.behindWords}` : own);
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE ONE READING A WRITE ANSWERS WITH (e2e r3 D1)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * The month as a write's response counted it, or null when the response carries none.
 *
 * WHY THE WRITE'S OWN ANSWER, NOT A RE-RENDER. After a card was pressed the header, the
 * task rows and the sidebar badge each waited on a server re-render to learn the new
 * count, and they did not always get it at the same moment — the eval read the header at
 * "0" beside a badge still at "4", and a GST card saved with the header stuck at "4 → 4".
 * The API now answers settle, decline and withdraw with `month: {period, opened, counts,
 * tasks}`, counted by the SAME function `GET /close` counts with (vert_api close.py
 * `_count_month`). That one reading moves all three surfaces together.
 *
 * Where it arrives: `month` on a card write's result (lib/actions.js decideAndSettle and
 * declineDecision), or `body.month` on a direct route's (withdraw). A reading is accepted
 * only when it is whole — a period and counts with a whole-number `decisions` — because a
 * half-read month drawn as current is the "unmeasured shown as a number" defect again.
 */
export function monthReadingOf(result) {
  if (!result || typeof result !== "object") return null;
  const candidates = [result.month, result.body && result.body.month, result.settle && result.settle.month];
  for (const m of candidates) {
    if (!m || typeof m !== "object" || typeof m.period !== "string" || !m.counts) continue;
    if (!isCount(m.counts.decisions) || !isCount(m.counts.total)) continue;
    return {
      period: m.period,
      opened: m.opened !== false,
      counts: m.counts,
      tasks: Array.isArray(m.tasks) ? m.tasks : null,
    };
  }
  return null;
}

/**
 * The month to draw: the server's, with a newer reading's counts and task rows laid over
 * it when the reading is for the same month. Everything the reading does not carry — the
 * label, the sources, the pending list — stays the server's. Nothing is added up: the
 * reading's numbers replace the server's whole.
 */
export function withReading(month, reading) {
  if (!month || typeof month !== "object" || !reading) return month;
  if (reading.period !== month.period) return month;
  return {
    ...month,
    opened: reading.opened,
    counts: reading.counts,
    tasks: reading.tasks || month.tasks,
  };
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE ONE FRESHNESS LINE (eval iter1 final, S2/S4 and finding 4)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * The sources Month-end names: the payload's, less any that is NOT CONNECTED, or null
 * when the payload lists none at all (unread is never "none", spec §9.4). Pure.
 *
 * A SOURCE THAT ISN'T CONNECTED IS NOT A SOURCE OF THIS MONTH'S FIGURES. That was the
 * rule for a ledger; since the engine marks a processor with no active connection
 * `not_connected` too (p0/refresh-tenant 986b57f), it is the rule for every source. Before,
 * the caption under Start read "Shopify Payments and Stripe haven't been read yet." to a
 * client that never connected either (smoke test, 23 Oct). The chat's context sheet still
 * lists every source, each said as it is ("Stripe not connected, last read 1 Jul").
 */
export function monthSources(month) {
  if (!month || !Array.isArray(month.sources)) return null;
  return month.sources.filter((s) => s && s.label && !(s.freshness && s.freshness.state === "not_connected"));
}

/**
 * What the foot of Month-end says about where the figures come from, as ONE line.
 *
 * It used to be three Needs-you rows — "Shopify Payments hasn't synced since 1 Jul.
 * [Sync now]" once per source — plus a footer saying the same thing again: about 25 of
 * the page's 135 words above the fold, three buttons that all started the same sync, and
 * a "ledger" the page had nothing to do with. Now: the sources that are behind, named
 * once and grouped by the day they were last read, then those that are fine; and `sync`
 * true when any is behind, so the line carries the one Sync action.
 *
 * A SOURCE THAT ISN'T CONNECTED — A LEDGER OR A PROCESSOR — IS NOT A SOURCE OF THIS
 * MONTH'S FIGURES, so it is not listed here (monthSources); for a ledger the approve card
 * says what it means for posting, where it matters. A
 * source nobody has read is "not read yet", never omitted and never a clean state.
 */
export function freshnessLine(month) {
  const sources = monthSources(month);
  if (!sources) return null;
  if (!sources.length) return { text: "No sources have been read for this month yet.", sync: false };
  // Grouped by what is said about them, in the order the payload lists them: "Shopify
  // Payments, Stripe and Bank statement last read 1 Jul · Ledger up to date, read 30 Sep".
  const groups = new Map();
  let behind = false;
  const ledger = [];
  for (const s of sources) {
    const state = s.freshness && s.freshness.state;
    if (state === "stale" || state === "failed") behind = true;
    // The ledger's as-at is the engine's own sentence, said whole and never grouped
    // (D5): "Xero as at 31 Oct 2026, 12:20 pm", and what Vert wrote since, with Sync now.
    const asAt = ledgerAsAtOf(s.asAt);
    if (asAt.words) {
      ledger.push(asAt.behindWords ? `${asAt.words}. ${asAt.behindWords}` : asAt.words);
      if (asAt.behind) behind = true;
      continue;
    }
    const words = freshnessWords(s.freshness);
    if (!groups.has(words)) groups.set(words, []);
    groups.get(words).push(s.label);
  }
  const parts = [...[...groups].map(([words, names]) => `${joinNames(names)} ${words}`), ...ledger];
  return { text: metaLine(parts, { joiner: "; " }), sync: behind };
}

/**
 * The ask box's tray says the same freshness in ONE short status (eval r3, S2: the full
 * per-source line under the box was 27 words and wrapped at 1440, pushing Month-end past
 * 120 words above the fold). The per-source words stay in the context sheet, which
 * lists every source; the tray only says whether anything is behind, and keeps the one
 * Sync now when something is. An unread source is still said ("not read yet"), never
 * folded into "up to date".
 */
export function trayLine(month) {
  const full = freshnessLine(month);
  if (!full) return null;
  const all = monthSources(month);
  if (!all.length) return { text: "No sources read yet", sync: false, full: full.text };
  const stateOf = (s) => (s.freshness && s.freshness.state) || "not_read";
  // One source: its own words are already short ("Stripe last read 1 Jul").
  if (all.length === 1) return { text: full.text, sync: full.sync, full: full.text };
  const n = all.length;
  const failed = all.filter((s) => stateOf(s) === "failed").length;
  const stale = all.filter((s) => stateOf(s) === "stale" || (stateOf(s) !== "failed" && ledgerAsAtOf(s.asAt).behind)).length;
  const unread = all.filter((s) => !["fresh", "stale", "failed"].includes(stateOf(s))).length;
  const parts = [];
  if (failed) parts.push(`${failed} of ${n} sources couldn't be read`);
  if (stale) parts.push(`${stale} of ${n} sources behind`);
  if (unread) parts.push(`${unread} of ${n} not checked yet`);
  return { text: parts.length ? metaLine(parts, { joiner: "; " }) : "Sources up to date", sync: full.sync, full: full.text };
}

/**
 * THE SOURCES THAT ARE BEHIND, IN WORDS (staging browser walk 1, D14): "Bank feed only
 * through 17 Oct, read 30 Oct", or null when none is. The popover's rule (stale or failed
 * is behind; a source not connected isn't one of the month's) and its words, for any
 * surface that must say the same fact: the Integration feeds conversation draws it under
 * an answer that called the feeds current (components/chat/FeedsSourcesNote.js). Pure.
 */
export function sourcesBehindWords(sources) {
  const listed = monthSources({ sources });
  if (!listed) return null;
  const behind = listed.filter((s) => s.freshness && (s.freshness.state === "stale" || s.freshness.state === "failed"));
  if (!behind.length) return null;
  return metaLine(behind.map((s) => `${s.label} ${freshnessWords(s.freshness)}`), { joiner: "; " });
}

function joinNames(names) {
  if (names.length <= 1) return names.join("");
  return `${names.slice(0, -1).join(", ")} and ${names[names.length - 1]}`;
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE CONTEXT CHIP, AND WHAT THE ASK BOX SUGGESTS (build plan §4.6 FM)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * "Northwind · June": the client and the month, as the conversation's chip reads them
 * (spec §7, context shown once per place). The sources and their freshness live behind
 * it, in the sheet it opens, rather than as a footer line on the page.
 */
export function contextLabel(clientName, month, period = null) {
  // The client as the conversation's chip names it (lib/format.js accountName): the
  // page hands over the payload's `business`, which for a tenant created without a
  // display name is its id, and the chip read "northwind · July" here while every
  // conversation read "Northwind · July" (eval iter2 polish, visual finding 6).
  const client = typeof clientName === "string" && clientName.trim() ? accountName({ business: clientName }) : null;
  return [client, monthName(month, period)].filter(Boolean).join(" · ");
}

/** Whether any source of the month is behind (stale or failed), for the chip's dot. */
export function sourcesBehind(month) {
  return sourcesNeedingYou(month).length > 0;
}

//: The source kinds that are payment processors (their payouts are what the payout
//: tasks read). A bank, a ledger or an imported file is not one.
export const PAYMENT_KINDS = Object.freeze(["stripe", "shopify", "shopify_payments", "paypal", "square", "payments"]);

/**
 * The month's payment sources (`[{kind, label, ...}]`), or NULL when the payload names
 * no sources at all (unread is never "none", spec §9.4). An empty array is a measured
 * fact: this client has no payment processor connected, so no payout copy, mark or
 * chip may suggest one (verify pass 1, S-E2E-1: a client with no processor was told
 * Vert would "Read your payment sources" beside a Stripe mark, and offered "Which
 * payouts don't match?"). The one predicate the start panel and the ask box read. Pure.
 */
export function paymentSourcesOf(month) {
  // A processor that isn't connected is not one Vert reads (monthSources): Start must not
  // promise "Read the Stripe payouts" to a client with no Stripe connection.
  const sources = monthSources(month);
  if (!sources) return null;
  return sources.filter((x) => PAYMENT_KINDS.includes(String(x.kind || "").toLowerCase()));
}

/** True only when the payload's sources were read and none is a payment processor. Pure. */
export function noPaymentSource(month) {
  const list = paymentSourcesOf(month);
  return Array.isArray(list) && list.length === 0;
}

//: The ask box's task questions about payouts: never offered without a processor.
const PAYOUT_TEMPLATES = new Set(["payout_check", "resolve_breaks"]);

//: The most suggestions the ask box offers. Three, so the row reads at a glance and
//: never becomes a second checklist (§4.6 FM).
export const MAX_SUGGESTIONS = 3;

//: Words a suggestion may never be: every result chip already downloads ("Export"),
//: and reversing lives on the posted entry's own card ("Reverse"), §4.6 FM.
export const NEVER_SUGGESTED = /\b(export|download|reverse)/i;

// The one task-specific suggestion, by template: a question about the work that needs
// you first. Each names only what that task's own row already names above it, so the
// suggestion adds no idea the page has not already introduced (S4′). A template with no
// line here gets no task-specific suggestion, rather than a generic one.
const ABOUT_TASK = Object.freeze({
  resolve_breaks: { label: "Why don't these payouts match?", text: (m) => `Why don't the ${m} payouts match?` },
  payout_check: { label: "Which payouts don't match?", text: (m) => `Which ${m} payouts don't match the bank?` },
  approve_entries: { label: "What's in these entries?", text: (m) => `What's in the ${m} entries waiting for approval?` },
  bank_reconciliation: { label: "Where does the bank rec stand?", text: (m) => `Where does the ${m} bank rec stand?` },
  card_reconciliation: { label: "Where does the card rec stand?", text: (m) => `Where does the ${m} card rec stand?` },
  gl_reconciliation: { label: "Which accounts don't agree?", text: (m) => `Which accounts don't agree for ${m}?` },
  workpapers: { label: "What's left before the workpapers?", text: (m) => `What's left before the ${m} workpapers?` },
});

/**
 * At most three things the ask box offers to start, in order:
 *
 *   1. "Draft an entry"            — an on-demand task: it is never a checklist row, so
 *                                    the ask box is where it starts (§4.0.3).
 *   2. "Compare with last month"   — opens the comparison's conversation when the month
 *                                    already lists that task; otherwise asks for it.
 *   3. one question about the first task still open (ABOUT_TASK): Waiting, then
 *      Working, then any — the month has nothing that needs you by then (below).
 *
 * Each is `{id, label, text, href}`: pressing it sends `text` to a new conversation, as
 * if typed, or opens `href` when the task already has one. No "Export" (every chip on a
 * result downloads already) and no "Reverse an entry" (it lives on the posted card).
 * Only an open month gets suggestions: before Start, the page's one job is Start.
 *
 * THE THIRD ONLY WHEN NOTHING NEEDS YOU (eval S2, 2 Oct). With a decision waiting, the
 * open card is the page's job, and a question about another task pointed away from it.
 * Design-fix-2 (DA2-023; critique r1) asks for 2–3 small chips under the EMPTY box
 * always: an empty hero box with nothing under it read as a search field. So while a
 * decision waits, the box offers TWO that point AT the waiting work and carry no new
 * idea (the five-ideas rule, S4′, counts the words): "What's left to do?" and "Compare
 * with June" (the month before, by name). A task question ("Why don't these payouts
 * match?") or "Draft an entry" waits until nothing needs you: each was a sixth idea
 * beside some open card. "Nothing needs you" is the
 * payload's word on the tasks (or its `counts.needsYou`), never a count this page makes.
 */
export function suggestionsFor(month, period = null) {
  const state = monthState(month);
  if (state !== "running" && state !== "done") return [];
  const name = monthName(month, period);
  const tasks = Array.isArray(month.tasks) ? month.tasks.filter((t) => t && typeof t === "object") : [];
  const out = [{ id: "draft_entry", label: "Draft an entry", text: `Draft a journal entry for ${name}.`, href: null }];
  const flux = tasks.find((t) => t.template === "flux_analysis" && typeof t.sessionId === "string" && t.sessionId);
  out.push({
    id: "flux_analysis",
    // The month by name (critique r1 fix round): "last month" named the idea of a month,
    // one more idea above the fold; "Compare with June" names the month itself.
    label: priorMonthName(month, period) ? `Compare with ${priorMonthName(month, period)}` : "Compare with last month",
    text: `Compare ${name} with last month.`,
    href: flux ? `/chat/${encodeURIComponent(flux.sessionId)}` : null,
  });
  const needsYou = isCount(month.counts && month.counts.needsYou) ? month.counts.needsYou > 0 : false;
  if (needsYou || tasks.some((t) => t.status === "Needs you")) {
    return [{ id: "whats_left", label: "What's left to do?", text: `What's left to do for ${name}?`, href: null }, out[1]];
  }
  // No processor, no payout question: "Which payouts don't match?" asked of a client with
  // no payouts names a source it doesn't have (noPaymentSource, above).
  const noPayouts = noPaymentSource(month);
  const askable = (t) => ABOUT_TASK[t.template] && !(noPayouts && PAYOUT_TEMPLATES.has(t.template));
  const first = ["Waiting", "Working", null].map((w) => tasks.find((t) => (w === null || t.status === w) && askable(t))).find(Boolean);
  if (first) {
    const about = ABOUT_TASK[first.template];
    out.push({ id: `about:${first.template}`, label: about.label, text: about.text(name), href: null });
  }
  return out.filter((s) => !NEVER_SUGGESTED.test(s.label)).slice(0, MAX_SUGGESTIONS);
}

/**
 * Whether a row offers Start: a person's task made with Create, not Done. `held` is the
 * live engine's own word (`GET /close`); a recording never carries it. The checklist row
 * (TaskRow.js) and the board row (components/home/rows.js) both ask this. Pure.
 */
export function canStartHeld(task) {
  return Boolean(task && task.held === true && task.id && task.status !== "Done");
}

/**
 * Whether the task recurs every month: the task's own `recurrence` (lib/tasks.js FIELDS;
 * the engine's `"monthly" | "none"`). Absent — an engine that doesn't send it yet for a
 * built-in row — is not monthly: nothing is guessed. Pure.
 */
export function recursMonthly(task) {
  return Boolean(task && task.recurrence === "monthly");
}
