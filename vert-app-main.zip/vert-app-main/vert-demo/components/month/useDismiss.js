"use client";

// components/month/useDismiss.js — HOW A MENU ON MONTH-END CLOSES
// ==============================================================================
// Design-fix-2 §8.2 ("menus close on Tab out / focusout and return focus to the
// trigger"). One rule for the checklist's View menu, its search and a row's "•••": Esc
// closes and puts focus back on the trigger; a press outside closes; focus leaving the
// root (Tab out) closes. `onDismiss(reason)` runs once per close with "escape",
// "outside" or "blur", so a caller can keep state on one and not another (the search
// keeps its words on Esc).

import { useEffect } from "react";

export default function useDismiss(open, rootRef, onDismiss, triggerRef = null) {
  useEffect(() => {
    if (!open) return undefined;
    const root = () => rootRef.current;
    const onKey = (event) => {
      if (event.key !== "Escape" || event.isComposing) return;
      if (!root() || !root().contains(document.activeElement)) return;
      event.stopPropagation();
      onDismiss("escape");
      if (triggerRef && triggerRef.current) triggerRef.current.focus();
    };
    const onPointer = (event) => {
      if (root() && !root().contains(event.target)) onDismiss("outside");
    };
    const onFocusOut = (event) => {
      const next = event.relatedTarget;
      if (next && root() && !root().contains(next)) onDismiss("blur");
    };
    const el = root();
    document.addEventListener("keydown", onKey, true);
    document.addEventListener("pointerdown", onPointer);
    if (el) el.addEventListener("focusout", onFocusOut);
    return () => {
      document.removeEventListener("keydown", onKey, true);
      document.removeEventListener("pointerdown", onPointer);
      if (el) el.removeEventListener("focusout", onFocusOut);
    };
  }, [open, rootRef, onDismiss, triggerRef]);
}
