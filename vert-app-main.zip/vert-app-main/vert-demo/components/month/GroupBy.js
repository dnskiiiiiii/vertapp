"use client";

// components/month/GroupBy.js — HOW THE CHECKLIST IS CUT: BY STATUS OR BY GROUP, ALL OR MINE
// ==============================================================================
// Build plan §19.0.8 and §19.5 F-CHK. A task is one row type, with an optional skill;
// the month's checklist can be read by its four status words (the default, and the
// only cut before the custom-tasks payload arrives) or by the person's own groups, and
// narrowed to "Assigned to you" or by a search, as the reference product does.
//
// WHY THE CUT NEVER LOSES A ROW. Grouping is a partition, not a filter: every task the
// payload listed lands in exactly one band, and a task whose group the payload does not
// name lands under "No group" rather than nowhere. A narrowing (Assigned to you, or a
// search) is said in words with the way back beside it, so a row that is not drawn is
// one press away and never silently gone (acceptance: "grouping and filtering keep
// every row"; tests/checklist-tasks.test.js holds both).
//
// WHY THE COUNTS GO WHEN THE LIST IS NARROWED. Every number on Month-end is the
// payload's (UI-001). The four status counts describe the whole month, so on a list
// narrowed to "yours" or to a search they would be a claim about rows that are not
// drawn; and this page does not count rows itself. A narrowed band shows its word only.
// A custom group shows a count only when the payload sent one for it.
//
// WHAT IS DRAWN ONLY WHEN IT CAN WORK (spec §1.9, no-false-affordance). The Status /
// Group control needs the payload's `groups[]` (build plan §19.2 `GET /close` gains
// `groups[]`), so before that payload it is absent, not dead. "Assigned to you" needs
// to know who you are (`GET /session` `person`, lib/session-contract.js), so with no
// person named it is absent too: a filter that guessed "you" would be a lie about whose
// work this is. The search is pure reading and always works.
//
// THE SEARCH FOLLOWS THE REGISTER RULE (components/shared/registerChrome.js): a search
// field over a list a person can read whole is chrome taller than the rows, so it is
// drawn only once the month has more tasks than one screen's reading (or while a search
// is still in force, so it can be cleared where it was typed).
//
// The choice of cut is remembered per viewer in localStorage, read and written under
// try/catch: a private window or blocked storage just starts at "Status".

import { useCallback, useEffect, useId, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui";
import { IconAdd, IconCaretDown, IconCheck, IconClose, IconSearch } from "@/components/ui/icons";
import useDismiss from "./useDismiss";
import { MONTHS } from "@/lib/format";
import { showsRegisterChrome } from "@/components/shared/registerChrome";
import { isStatusWord } from "@/lib/status";
import { createTaskGroup } from "@/lib/tasks";

export const GROUP_ORDER = Object.freeze(["Needs you", "Vert's working", "Waiting", "Done"]);

/** The band for a task whose group the payload does not name. */
export const NO_GROUP = "No group";

/** The localStorage key the viewer's cut is remembered under. */
export const GROUP_BY_KEY = "vert.checklist.groupBy";

const CUTS = new Set(["status", "group"]);

/** The remembered cut, or "status". Never throws: storage can be missing or blocked. */
export function readGroupBy(storage) {
  try {
    const store = storage === undefined ? (typeof window !== "undefined" ? window.localStorage : null) : storage;
    const value = store ? store.getItem(GROUP_BY_KEY) : null;
    return CUTS.has(value) ? value : "status";
  } catch {
    return "status";
  }
}

/** Remember the cut. Returns whether it was kept; a refusal is not an error. */
export function writeGroupBy(value, storage) {
  if (!CUTS.has(value)) return false;
  try {
    const store = storage === undefined ? (typeof window !== "undefined" ? window.localStorage : null) : storage;
    if (!store) return false;
    store.setItem(GROUP_BY_KEY, value);
    return true;
  } catch {
    return false;
  }
}

function isCount(n) {
  return typeof n === "number" && Number.isInteger(n) && n >= 0;
}

/** Whether the payload is the custom-tasks one (TSK, build plan §19.2): it names its groups. */
export function customTasksLive(month) {
  return Boolean(month && Array.isArray(month.groups));
}

/**
 * The tasks the checklist may draw, in payload order. A built-in template whose
 * `applies` is false for this client is not a row (§19.0.8); a status word outside the
 * four is refused, as the status cut always has (lib/status.js).
 */
export function listableTasks(month) {
  const tasks = month && Array.isArray(month.tasks) ? month.tasks : [];
  return tasks.filter((t) => t && typeof t === "object" && t.applies !== false && isStatusWord(t.status));
}

/** A stable key for a row (model.js taskKey): a custom task's id, a row beside the
 *  checklist its conversation, else its template. */
export { taskKey } from "./model";

function personName(value) {
  return typeof value === "string" && value.trim() ? value.trim() : null;
}

function matches(task, query) {
  const q = query.toLowerCase();
  return [task.title, task.description, task.assignee, task.approver].some((v) => typeof v === "string" && v.toLowerCase().includes(q));
}

/**
 * The bands to draw. `{ by: "status"|"group", filter: "all"|"mine", viewer, query }`.
 * Returns `{ bands: [{ key, label, tasks, count }], narrowed, mine }`. A band with no
 * rows is still returned (the caller does not draw it). A custom group's `count` is the
 * payload's or null; a status band's is null here, because Checklist reads the four
 * status counts straight off `counts.*` itself (the one-count rule, tests/month.test.js).
 */
export function bandsFor(month, { by = "status", filter = "all", viewer = null, query = "" } = {}) {
  const who = personName(viewer);
  const mine = filter === "mine" && Boolean(who);
  const q = typeof query === "string" ? query.trim() : "";
  let tasks = listableTasks(month);
  if (mine) tasks = tasks.filter((t) => personName(t.assignee) === who);
  if (q) tasks = tasks.filter((t) => matches(t, q));
  const narrowed = mine || Boolean(q);

  if (by === "group" && customTasksLive(month)) {
    const groups = month.groups.filter((g) => g && typeof g === "object" && (typeof g.id === "string" || typeof g.id === "number"));
    const known = new Set(groups.map((g) => String(g.id)));
    const bands = groups.map((g) => ({
      key: `group:${g.id}`,
      label: typeof g.name === "string" && g.name.trim() ? g.name.trim() : NO_GROUP,
      tasks: tasks.filter((t) => t.group !== undefined && t.group !== null && String(t.group) === String(g.id)),
      count: !narrowed && isCount(g.count) ? g.count : null,
    }));
    bands.push({
      key: "group:none",
      label: NO_GROUP,
      tasks: tasks.filter((t) => t.group === undefined || t.group === null || !known.has(String(t.group))),
      count: null,
    });
    return { bands, narrowed, mine };
  }

  const bands = GROUP_ORDER.map((word) => ({
    key: word,
    label: word,
    tasks: tasks.filter((t) => t.status === word),
    count: null,
  }));
  return { bands, narrowed, mine };
}

/** "Sam Lee" → "SL"; one name → its first letter. Null for no name. */
export function initials(name) {
  const who = personName(name);
  if (!who) return null;
  const parts = who.split(/\s+/).filter(Boolean);
  const first = parts[0][0];
  const last = parts.length === 1 ? "" : parts[parts.length - 1][0];
  return `${first}${last}`.toUpperCase();
}

const ORDINAL = (d) => {
  const tens = d % 100;
  if (tens >= 11 && tens <= 13) return `${d}th`;
  return `${d}${{ 1: "st", 2: "nd", 3: "rd" }[d % 10] || "th"}`;
};

/** A task's due day as the row says it: "Due 5th". Null when no day is set. */
export function dueWords(due) {
  if (typeof due === "number" && Number.isInteger(due) && due >= 1 && due <= 31) return `Due ${ORDINAL(due)}`;
  if (typeof due === "string" && /^\d{4}-\d{2}-(\d{2})$/.test(due)) {
    const d = Number.parseInt(due.slice(8), 10);
    return d >= 1 && d <= 31 ? `Due ${ORDINAL(d)}` : null;
  }
  return null;
}

/**
 * A task's due day as a date (design-fix-2 DA2-060): "Due 5 Aug", and whether it has
 * passed. The engine stores a day of the month (vert_api tasks `due`, 1–31); a close is
 * worked in the month after the one it closes, so July's "due 5" is 5 August. A full date
 * ("2026-10-05") is read as itself. Returns `{ text, iso, overdue }` or null. A day past
 * the month's end lands on its last day. Pure; `now` is injectable.
 */
export function dueDate(due, period, { now = new Date(), done = false } = {}) {
  let y;
  let m;
  let d;
  if (typeof due === "string" && /^\d{4}-\d{2}-\d{2}$/.test(due)) {
    [y, m, d] = due.split("-").map((n) => Number.parseInt(n, 10));
  } else if (typeof due === "number" && Number.isInteger(due) && due >= 1 && due <= 31 && typeof period === "string" && /^\d{4}-\d{2}$/.test(period)) {
    const [py, pm] = period.split("-").map((n) => Number.parseInt(n, 10));
    y = pm === 12 ? py + 1 : py;
    m = pm === 12 ? 1 : pm + 1;
    d = Math.min(due, new Date(Date.UTC(y, m, 0)).getUTCDate());
  } else {
    return null;
  }
  if (!(m >= 1 && m <= 12 && d >= 1 && d <= 31)) return null;
  const iso = `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
  const today = now instanceof Date && !Number.isNaN(now.getTime()) ? `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}` : null;
  return { text: `Due ${d}\u00a0${MONTHS[m - 1]}`, iso, overdue: Boolean(!done && today && today > iso) };
}

/* ── Making a group (eval r1 WP #2: "a custom group can't be created on screen") ──
 *
 * WHY THIS IS HERE AND NOT ONLY IN SETTINGS. The reference cuts its checklist by the
 * firm's own groups ("Assets & prepaids", "Revenue & receivables"), and a cut you can
 * choose but never add to is a control that promises more than it does: before this,
 * `createTaskGroup` (lib/tasks.js) worked against the engine and nothing on screen
 * called it. So the Group cut carries "New group", and so does the new-task sheet's
 * Group field, both through `submitNewGroup` below.
 *
 * A GROUP IS MADE ONLY WHEN THE ENGINE READ IT BACK. `createTaskGroup` answers ok only
 * on `verified: true`; anything else (a refused duplicate name, no service, an
 * unconfirmed write) keeps the typed name and says why in the engine's words. The new
 * group is never added to the list on hope: the month is read again (the Group cut),
 * or the sheet selects the group the engine returned, by its id.
 */

const NAME_MAX = 80;
const GROUP_NOT_SENT = "Not sent. Nothing was recorded.";

/** The name `createTaskGroup` would send, or `{ error }`. Mirrors the engine's 1–80. */
export function groupRequest(name) {
  const clean = typeof name === "string" ? name.trim() : "";
  if (!clean) return { error: "Give the group a name." };
  if (clean.length > NAME_MAX) return { error: `Keep the name to ${NAME_MAX} characters.` };
  return { name: clean };
}

/**
 * Make a group. Returns `{ state, group?, message? }`: `invalid` (nothing sent),
 * `refused` (the engine's words, or "Not sent"), or `created` with the engine's group.
 */
export async function submitNewGroup(name, { create = createTaskGroup } = {}) {
  const { name: clean, error } = groupRequest(name);
  if (error) return { state: "invalid", message: error };
  let result;
  try {
    result = await create(clean);
  } catch {
    return { state: "refused", message: GROUP_NOT_SENT };
  }
  const group = result && result.ok === true ? result.group : null;
  if (!group || (typeof group.id !== "string" && typeof group.id !== "number")) {
    return { state: "refused", message: (result && typeof result.message === "string" && result.message) || GROUP_NOT_SENT };
  }
  return { state: "created", group };
}

/**
 * "New group": a quiet button that opens an inline name field and "Add group". Not a
 * <form>, because it also sits inside the new-task sheet's form; Enter in the field
 * adds the group without submitting the task. Never purple (the sheet's one commit is
 * "Create task"). `onCreated(group)` runs only after the engine confirmed the group.
 */
export function NewGroup({ create = createTaskGroup, onCreated = null, initialOpen = false, onCancel = null }) {
  const router = useRouter();
  const [open, setOpen] = useState(initialOpen);
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [outcome, setOutcome] = useState(null);
  const nameRef = useRef(null);
  // Opened (by its own button, or mounted open from the View menu), the name field takes
  // focus, so "New group…" then typing is one motion.
  useEffect(() => {
    if (open && nameRef.current) nameRef.current.focus();
  }, [open]);

  async function add() {
    if (busy) return;
    setBusy(true);
    const out = await submitNewGroup(name, { create });
    setBusy(false);
    setOutcome(out);
    if (out.state !== "created") return;
    setName("");
    setOpen(false);
    if (onCancel) onCancel();
    if (onCreated) onCreated(out.group);
    else router.refresh();
  }

  if (!open) {
    return (
      <Button variant="quiet" size="sm" className="new-group-open" icon={<IconAdd />} onClick={() => (setOutcome(null), setOpen(true))}>
        New group…
      </Button>
    );
  }
  const said = outcome && outcome.state !== "created" ? outcome.message : null;
  return (
    <div className="new-group" role="group" aria-label="New group">
      <input
        ref={nameRef}
        className="field-input new-group-name t-footnote"
        name="groupName"
        aria-label="Group name"
        placeholder="Group name…"
        autoComplete="off"
        maxLength={NAME_MAX}
        value={name}
        onChange={(e) => setName(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            add();
          } else if (e.key === "Escape") {
            e.stopPropagation();
            setOpen(false);
            if (onCancel) onCancel();
          }
        }}
      />
      <Button variant="secondary" size="sm" onClick={add} busy={busy} busyLabel="Adding…">
        Add group
      </Button>
      <Button
        variant="quiet"
        size="sm"
        onClick={() => {
          setOpen(false);
          if (onCancel) onCancel();
        }}
      >
        Cancel
      </Button>
      {said ? (
        <p className="new-group-said t-footnote" role="alert">
          {said}
        </p>
      ) : null}
    </div>
  );
}

/* ── THE TOOLBAR (design-fix-2 DA2-034) ─────────────────────────────────────────────
 * It was two segmented controls of different widths, a fixed outlined search, a "New
 * group" that appeared only in the Group cut (shifting the bar) and an outlined "+ New
 * task" pushed to the far right: four control styles in one row. Now three elements, all
 * 32 px, in one style family, and nothing appears or shifts by mode:
 *
 *   View ▾     a quiet menu holding Show (All tasks / Assigned to you), Group by
 *              (Status / Group) and, with the groups payload, "New group…"
 *   🔍         an icon button that opens a 15rem field; Esc closes it and keeps the words
 *   New task…  a quiet button with a Plus, drawn by Checklist.js
 *
 * Each choice is drawn only when it can work (the rules above): no viewer, no "Assigned
 * to you"; no groups payload, no Group cut and no New group. A menu with nothing to
 * hold is not drawn. The choices are radios in labelled groups (one is always chosen),
 * the chosen one marked by a Check and its weight, never the accent.
 */

function Choice({ checked, onChoose, children }) {
  return (
    <button type="button" role="radio" aria-checked={checked ? "true" : "false"} className="menu-item view-choice" onClick={onChoose}>
      <span className="view-choice-mark" aria-hidden="true">
        {checked ? <IconCheck size={14} /> : null}
      </span>
      {children}
    </button>
  );
}

export function ViewMenu({ by, onBy, filter, onFilter, canGroup, canFilter, onNewGroup = null, initiallyOpen = false }) {
  const [open, setOpen] = useState(initiallyOpen);
  const id = useId();
  const root = useRef(null);
  const toggle = useRef(null);
  const close = useCallback(() => setOpen(false), []);
  useDismiss(open, root, close, toggle);
  if (!canGroup && !canFilter) return null;
  const choose = (fn, value) => () => {
    fn(value);
    setOpen(false);
    if (toggle.current) toggle.current.focus();
  };
  return (
    <span className="view-menu" ref={root}>
      <button
        ref={toggle}
        type="button"
        className="btn btn-quiet btn-sm view-menu-toggle"
        aria-expanded={open ? "true" : "false"}
        aria-controls={id}
        onClick={() => setOpen((v) => !v)}
      >
        View
        <IconCaretDown className="view-menu-caret" aria-hidden="true" />
      </button>
      <span className="popover view-menu-list" id={id} hidden={!open}>
        {canFilter ? (
          <span className="view-menu-group" role="radiogroup" aria-label="Show">
            <span className="view-menu-head t-caption" aria-hidden="true">
              Show
            </span>
            <Choice checked={filter !== "mine"} onChoose={choose(onFilter, "all")}>
              All tasks
            </Choice>
            <Choice checked={filter === "mine"} onChoose={choose(onFilter, "mine")}>
              Assigned to you
            </Choice>
          </span>
        ) : null}
        {canGroup ? (
          <span className="view-menu-group" role="radiogroup" aria-label="Group by">
            <span className="view-menu-head t-caption" aria-hidden="true">
              Group by
            </span>
            <Choice checked={by !== "group"} onChoose={choose(onBy, "status")}>
              Status
            </Choice>
            <Choice checked={by === "group"} onChoose={choose(onBy, "group")}>
              Group
            </Choice>
          </span>
        ) : null}
        {canGroup && onNewGroup ? (
          <span className="view-menu-group">
            <button
              type="button"
              className="menu-item view-new-group"
              onClick={() => {
                setOpen(false);
                onNewGroup();
              }}
            >
              <IconAdd size={14} aria-hidden="true" />
              New group…
            </button>
          </span>
        ) : null}
      </span>
    </span>
  );
}

/**
 * The search: a 32 px icon button that opens a 15rem field. Esc closes the field and
 * keeps the words (the narrowed line under the bar still says so, with "Show all
 * tasks"); X clears them. A field holding words, or one asked for open, starts open.
 */
export function ChecklistSearch({ query, onQuery, initiallyOpen = false }) {
  const filled = typeof query === "string" && query !== "";
  const [open, setOpen] = useState(initiallyOpen || filled);
  const root = useRef(null);
  const toggle = useRef(null);
  const input = useRef(null);
  // Where focus goes on the next render: the field once it opens from the toggle, the
  // toggle once Esc closes the field.
  const focusNext = useRef(null);
  const filledRef = useRef(filled);
  filledRef.current = filled;
  const close = useCallback((reason) => {
    if (reason === "escape") {
      focusNext.current = "toggle";
      setOpen(false);
    } else if (!filledRef.current) {
      // A press elsewhere leaves a filled field open, so its words stay in view.
      setOpen(false);
    }
  }, []);
  useDismiss(open, root, close);
  useEffect(() => {
    const target = focusNext.current === "toggle" ? toggle.current : focusNext.current === "input" ? input.current : null;
    focusNext.current = null;
    if (target) target.focus();
  }, [open]);
  if (!open) {
    return (
      <span className="checklist-search" ref={root} data-open="false">
        <button
          ref={toggle}
          type="button"
          className="icon-btn icon-btn-sm checklist-search-toggle"
          aria-label={filled ? `Search tasks: ${query}` : "Search tasks"}
          aria-pressed={filled ? "true" : undefined}
          onClick={() => {
            focusNext.current = "input";
            setOpen(true);
          }}
        >
          <IconSearch aria-hidden="true" />
        </button>
      </span>
    );
  }
  return (
    <span className="checklist-search" ref={root} data-open="true" data-filled={filled ? "true" : undefined}>
      <label className="checklist-search-field">
        <IconSearch className="checklist-search-glyph" size={14} aria-hidden="true" />
        <input
          ref={input}
          type="search"
          className="checklist-search-input"
          name="checklistSearch"
          aria-label="Search the checklist"
          placeholder="Search tasks…"
          autoComplete="off"
          spellCheck={false}
          value={query}
          onChange={(e) => onQuery(e.target.value)}
        />
      </label>
      {filled ? (
        <button
          type="button"
          className="icon-btn checklist-search-clear"
          aria-label="Clear the search"
          onClick={() => {
            onQuery("");
            if (input.current) input.current.focus();
          }}
        >
          <IconClose size={12} aria-hidden="true" />
        </button>
      ) : null}
    </span>
  );
}

/**
 * The checklist's tools: the View menu and the search. Controlled by the caller; New task
 * is drawn beside them by Checklist.js. Returns null when nothing can be drawn.
 */
export default function ChecklistTools({ by, onBy, filter, onFilter, query, onQuery, canGroup, canFilter, total = null, onNewGroup = null }) {
  const canSearch = showsRegisterChrome(total) || (typeof query === "string" && query.trim() !== "");
  if (!canGroup && !canFilter && !canSearch) return null;
  return (
    <div className="checklist-tools">
      <ViewMenu by={by} onBy={onBy} filter={filter} onFilter={onFilter} canGroup={canGroup} canFilter={canFilter} onNewGroup={onNewGroup} />
      {canSearch ? <ChecklistSearch query={query} onQuery={onQuery} /> : null}
    </div>
  );
}
