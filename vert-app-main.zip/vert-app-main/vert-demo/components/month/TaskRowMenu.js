"use client";

// components/month/TaskRowMenu.js — A CHECKLIST ROW'S "⋯": OPEN SKILL, MOVE TO A GROUP
// ==============================================================================
// ui-pass-1 walkthrough #5 (W02, 10 Oct 2026): a group could be made on screen, but a
// task already on the checklist could not be put in it. The row's "⋯" held only "Open
// skill", and `PATCH /tasks/{id}` (lib/tasks.js updateTask), which takes `group`, had no
// caller. So "create 'Assets & prepaids' and move two tasks into it" stopped at the
// first half, and a group made for existing work stayed empty for good.
//
// WHAT IT OFFERS. "Move to" with the month's groups and "No group", the current one
// marked. A press sends `PATCH /tasks/{id} {group}` (null for No group) and, once the
// engine's read-back confirms it, reads the month again so the row moves band from the
// payload, like every other change on this page. A refusal or an unconfirmed change is
// said under the menu in the engine's words; the row does not move on hope.
//
// WHERE IT IS DRAWN. Only on a person's task (`id`): a built-in template row has no id
// and no group on the wire (vert_api/routers/tasks.py task_row; the engine queue has
// the item), so a Move on it would be a control that cannot work. Only when the month
// names its groups (`groups[]`) and has at least one. "Open skill" keeps its own rule
// (components/skills/TaskMenu.js): a signed-in viewer and a skill-bound task.
//
// Design-fix-2: Esc, a press outside and Tab out close it (useDismiss.js), and focus
// goes back to the "•••".
//
// IT IS DRAWN IN THE TOP LAYER (verify pass 3, W02). The list was an absolutely placed
// child of the row, inside the status band's collapsible region, whose `overflow-y:
// clip` (kit.css .disclosure-inner, there for the band's collapse) cut it at the band's
// foot; and the rows after it, each its own stacking context, painted over the rest. On
// the last row of Waiting, "Assets & prepaids" lay under the Done band's first row and
// a press on it opened "Compare with last month". No z-index can lift a child out of a
// clipping ancestor, so the list is a manual `popover`: in the top layer it is clipped
// by nothing and painted over everything, and it stays the toggle's next sibling in the
// DOM, so Tab still walks from the "•••" into its items. It is placed beside the "•••"
// by `menuPlacement` (below it, flipped above when the viewport has no room under it),
// and placed again on scroll and resize while open. Where the popover API is missing
// it falls back to the old absolute placement.
//
// A disclosure, not an ARIA menu (the reason components/shell/AccountMenu.js gives);
// Esc and a press outside close it, and focus goes back to the "⋯".

import { useCallback, useId, useLayoutEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { IconMore, IconSkill } from "@/components/ui/icons";
import OpenSkill from "@/components/skills/OpenSkill";
import { callSafely } from "@/lib/decisions";
import { updateTask } from "@/lib/tasks";
import { NO_GROUP } from "./GroupBy";
import useDismiss from "./useDismiss";

/**
 * The groups a task can be moved to, "No group" first, the current one marked. Pure.
 *
 * NOT ON A DONE TASK (verify pass 1, W02). The engine keeps a done task as a record and
 * refuses any edit to it (`PATCH /tasks/{id}` → 409 immutable_record, "This task is
 * done, and a done task is not edited"), so a Move offered on a Done row was a control
 * that could only be refused. A Done task offers none; its "Edit steps" is unaffected.
 */
export function moveTargets(task, groups) {
  if (!task || !task.id || !Array.isArray(groups)) return [];
  if (task.status === "Done") return [];
  const named = groups.filter((g) => g && (typeof g.id === "string" || typeof g.id === "number") && typeof g.name === "string" && g.name.trim());
  if (!named.length) return [];
  const current = task.group === undefined || task.group === null ? null : String(task.group);
  const known = new Set(named.map((g) => String(g.id)));
  return [
    { id: null, label: NO_GROUP, current: current === null || !known.has(current) },
    ...named.map((g) => ({ id: String(g.id), label: g.name.trim(), current: current === String(g.id) })),
  ];
}

/** The gap between the "•••" and the list, and the list and the viewport's edge, in px. */
const MENU_GAP = 4;
const VIEW_MARGIN = 8;

/**
 * Where the open list goes, in viewport px: `{ top, left, flipped }`. Under the toggle,
 * its right edge on the toggle's; above it when the room below is too small for the list
 * and the room above is larger; kept inside the viewport on every side. Pure, so the
 * flip at a band's foot is tested without a browser.
 *
 * `anchor` is the toggle's client rect, `size` the list's `{ width, height }`,
 * `viewport` `{ width, height }`.
 */
export function menuPlacement(anchor, size, viewport) {
  const a = anchor || {};
  const w = Math.max(0, Number(size && size.width) || 0);
  const h = Math.max(0, Number(size && size.height) || 0);
  const vw = Math.max(0, Number(viewport && viewport.width) || 0);
  const vh = Math.max(0, Number(viewport && viewport.height) || 0);
  const below = vh - (a.bottom || 0) - MENU_GAP - VIEW_MARGIN;
  const above = (a.top || 0) - MENU_GAP - VIEW_MARGIN;
  const flipped = h > below && above > below;
  let top = flipped ? (a.top || 0) - MENU_GAP - h : (a.bottom || 0) + MENU_GAP;
  top = Math.max(VIEW_MARGIN, Math.min(top, vh - VIEW_MARGIN - h));
  let left = (a.right || 0) - w;
  left = Math.max(VIEW_MARGIN, Math.min(left, vw - VIEW_MARGIN - w));
  return { top: Math.round(top), left: Math.round(left), flipped };
}

/** Whether this browser can put an element in the top layer as a popover. */
function canPopover(el) {
  return Boolean(el && typeof el.showPopover === "function" && typeof el.hidePopover === "function");
}

/** Move a task: `{ state: "moved" | "refused", message? }`. Collaborators injectable. */
export async function moveTask(task, groupId, { update = updateTask } = {}) {
  const result = await callSafely(update, task.id, { group: groupId });
  if (!result || result.ok !== true) {
    return { state: "refused", message: (result && result.message) || "Not moved. Nothing was changed." };
  }
  return { state: "moved" };
}

export default function TaskRowMenu({ task, title, viewer = null, groups = null, initiallyOpen = false }) {
  const router = useRouter();
  const [open, setOpen] = useState(initiallyOpen);
  const [outcome, setOutcome] = useState(null);
  const [busy, setBusy] = useState(null);
  const id = useId();
  const root = useRef(null);
  const toggle = useRef(null);
  const list = useRef(null);
  const skill = Boolean(viewer && task && task.template);
  const targets = moveTargets(task, groups);

  const close = useCallback(() => setOpen(false), []);
  useDismiss(open, root, close, toggle);

  // THE TOP LAYER (see the header): shown as a popover while open, placed beside the
  // "•••" before paint, and placed again when the page scrolls or the window resizes.
  useLayoutEffect(() => {
    const el = list.current;
    if (!open || !canPopover(el)) return undefined;
    const place = () => {
      if (!toggle.current) return;
      const at = menuPlacement(
        toggle.current.getBoundingClientRect(),
        { width: el.offsetWidth, height: el.offsetHeight },
        { width: window.innerWidth, height: window.innerHeight }
      );
      el.style.top = `${at.top}px`;
      el.style.left = `${at.left}px`;
      el.dataset.flipped = at.flipped ? "true" : "false";
    };
    try {
      if (!el.matches(":popover-open")) el.showPopover();
    } catch {
      return undefined;
    }
    el.dataset.layer = "top";
    place();
    window.addEventListener("scroll", place, true);
    window.addEventListener("resize", place);
    return () => {
      window.removeEventListener("scroll", place, true);
      window.removeEventListener("resize", place);
      try {
        if (el.matches(":popover-open")) el.hidePopover();
      } catch {
        /* already closed */
      }
      delete el.dataset.layer;
    };
  }, [open, outcome, busy]);

  if (!skill && !targets.length) return null;

  // "EDIT HOW VERT DOES THIS" (founders, 22 Oct 2026: customise a task's procedure from
  // the task, as in Ramp; it said "Edit steps"). It opens the skill sheet.
  // ONE ACTION IS A BUTTON, NOT A MENU (design-fix-2 DA2-035, DA2-064): a "•••" that
  // opens a list of one ("Edit steps") is a press too many. With nothing to move, the
  // skill opens from its own icon button, named for what it does.
  if (!targets.length) {
    return (
      <OpenSkill template={task.template} title={title} className="icon-btn icon-btn-sm task-menu-toggle task-skill-direct">
        <IconSkill aria-hidden="true" />
        <span className="sr-only">{`Edit how Vert does ${title}`}</span>
      </OpenSkill>
    );
  }

  async function move(target) {
    if (busy || target.current) return;
    setBusy(target.id ?? "none");
    setOutcome(null);
    const out = await moveTask(task, target.id);
    setBusy(null);
    if (out.state !== "moved") {
      setOutcome(out);
      return;
    }
    setOpen(false);
    router.refresh();
  }

  return (
    <span className="task-menu" ref={root}>
      <button
        ref={toggle}
        type="button"
        className="task-menu-toggle"
        aria-expanded={open ? "true" : "false"}
        aria-controls={id}
        aria-label={`More for ${title}`}
        onClick={() => setOpen((v) => !v)}
      >
        <IconMore aria-hidden="true" />
      </button>
      <span className="task-menu-list" id={id} hidden={!open} popover="manual" ref={list}>
        {skill ? (
          <OpenSkill template={task.template} title={title} className="row menu-item skill-open">
            Edit how Vert does this
          </OpenSkill>
        ) : null}
        {targets.length ? (
          <span className="task-move" role="group" aria-label={`Move ${title} to`} data-task-move="">
            <span className="task-move-label t-caption" aria-hidden="true">
              Move to
            </span>
            {targets.map((t) => (
              <button
                key={t.id ?? "none"}
                type="button"
                className="row menu-item task-move-item"
                data-move-to={t.id ?? ""}
                aria-current={t.current ? "true" : undefined}
                aria-disabled={t.current ? "true" : undefined}
                aria-busy={busy === (t.id ?? "none") ? "true" : undefined}
                onClick={() => move(t)}
              >
                {busy === (t.id ?? "none") ? "Moving…" : t.label}
              </button>
            ))}
          </span>
        ) : null}
        {outcome && outcome.state === "refused" ? (
          <span className="task-move-said t-footnote" role="alert">
            {outcome.message}
          </span>
        ) : null}
      </span>
    </span>
  );
}
