"use client";

// components/month/SourcesLine.js — WHERE THE MONTH'S FIGURES COME FROM, IN ONE LINE
// ==============================================================================
// Spec §3.2 (foot of the page) and §6.4. One quiet line, and at most one action:
//
//   Shopify Payments, Stripe and Bank statement last read 1 Jul · Sync now
//
// WHY ONE LINE (eval iter1 final, S2/S4 finding 4). Month-end used to raise each stale
// source as its own Needs-you row — "Stripe hasn't synced since 1 Jul. [Sync now]", three
// times — and then say the same thing again in a footer. That was about 25 of the page's
// 135 words above the fold, three buttons that all started the SAME sync (startSync
// takes no source), and a stale feed dressed as a decision when it is not one. The
// freshness is now said once, grouped by what is true of each source (model.js
// freshnessLine), with one Sync now beside it when anything is behind.
//
// A source nobody has read is "not read yet", never blank and never a clean state
// (spec §9.4). A failed sync says nothing was recorded and why, in the failure's own
// words (cards/words.js failureSentence), never "This is a sample month" about a
// customer's own books (eval C6).

import { Button } from "@/components/ui";
import { SyncPressResult, useSyncPress } from "@/components/sync/SyncOutcome";
import { freshnessLine, trayLine } from "./model";

export default function SourcesLine({ month, disabledReason = null, place = "sheet" }) {
  // In the ask box's tray (visual spec §2) the line folds to one short status and keeps
  // its one action (trayLine, eval r3 S2); the per-source words stay in the sheet.
  const tray = place === "tray";
  const line = tray ? trayLine(month) : freshnessLine(month);
  // The press, and its answer once it came back: what was read, said by SyncOutcome.
  const sync = useSyncPress();
  const state = sync.state;
  if (!line) return null;

  return (
    <div className={tray ? "ask-tray" : "month-sources"} data-sources-line={place}>
      <p className={tray ? "ask-tray-text t-footnote" : "month-sources-text t-footnote"} title={tray ? line.full : undefined}>
        {line.text}
      </p>
      {line.sync && state !== "done" ? (
        <Button variant="quiet" size="sm" busy={state === "busy"} busyLabel="Syncing…" disabledReason={disabledReason} onClick={sync.press}>
          Sync now
        </Button>
      ) : null}
      <SyncPressResult sync={sync} className="month-sources-outcome" />
    </div>
  );
}
