// components/month/close-step.js — SIGN OFF AND LOCK: WHICH STEP, IN WHICH WORDS
// ==============================================================================
// W4 Step 5 of the close list (29 Oct 2026). Closing a month is two acts, by two hands:
// Vert closes it on its side (it keeps this month's balances as the baseline for next
// month), and a person sets the lock date in Xero, which Vert can't set for them. The
// engine says which of the three steps the month is at (`GET /close/{period}/lock`, the
// same object `POST /close/{period}/sign-off` answers with):
//
//   sign_off   not signed off in Vert yet: one press, "Sign off September 2026";
//   set_lock   signed off; the ledger's lock date is before the month's last day: where to
//              set it, and Check again (a read: it asks the ledger again);
//   done       signed off and locked to the month's end or later.
//
// The step is the engine's, never worked out here from the dates: the lock date read is
// drawn as the engine read it, and a lock date it couldn't read is said in its words,
// never as "not set". XERO IS NAMED because the lock date is Xero's own setting, at
// Xero's own path (tests/claims.test.js lists this file where the vendor is the fact).
//
// Pure: Month-end's panel (ClosePanel.js) draws what this returns, and a test can hold
// every step without a browser.

import { actorWords, displayDayOf, formatDate } from "@/lib/format";
import { monthName, periodLabel } from "@/lib/period";

const STEPS = new Set(["sign_off", "set_lock", "done"]);

/** The month states Month-end draws the panel for (MonthView.js), and reads the status for
 *  (month-reads.js): a month started, done or closed. Not read or not started: neither. */
export const CLOSE_PANEL_STATES = Object.freeze(new Set(["running", "done", "closed"]));
const PERIOD = /^[0-9]{4}-(0[1-9]|1[0-2])$/;
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
/** An ISO day, null, or undefined when it is neither (not a date). */
const dayOrNull = (v) => (v === null || v === undefined ? null : typeof v === "string" && ISO_DAY.test(v) ? v : undefined);

// Short (walk 2 copy list): labels and dates, not explanations.
export const SIGN_OFF_EXPLAINED = "Keeps this month's balances.";
export const LOCK_PATH = "Settings → Advanced → Financial settings → Lock dates";
//: The engine's lock line for a month not signed off (vert_engine close_lock.py).
export const LOCK_READ_AFTER_SIGN_OFF = "It's read once the month is signed off.";

function ledgerLockOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean") return null;
  const lockDate = dayOrNull(raw.lockDate);
  const periodLockDate = dayOrNull(raw.periodLockDate);
  const endOfYearLockDate = dayOrNull(raw.endOfYearLockDate);
  if (lockDate === undefined || periodLockDate === undefined || endOfYearLockDate === undefined) return null;
  const words = text(raw.words);
  // Not read, with no words saying why, has nothing true to say.
  if (!raw.measured && !words) return null;
  return { measured: raw.measured, words, lockDate: raw.measured ? lockDate : null, periodLockDate, endOfYearLockDate };
}

/** The actor of the month's latest reopening in `history` (oldest first), or null. */
function lastReopenActor(history) {
  if (!Array.isArray(history)) return null;
  for (let i = history.length - 1; i >= 0; i -= 1) {
    const e = history[i];
    if (isObj(e) && e.kind === "reopened") return text(e.actor);
  }
  return null;
}

/**
 * The engine's reopen sentence with who reopened it worded for the viewer (UI walk 2,
 * N5): "Reopened by walk2-reviewer's key (why)…" reads "Reopened by you (why)…" to that
 * key, "another access code" to another, and a person's name to anyone, through the
 * rule every other "by" line uses (lib/format.js actorWords). Only the name is replaced;
 * the rest is the engine's. Unchanged when the engine named nobody. Pure.
 */
export function reopenedWords(status, signedIn = null) {
  const words = status ? status.words : null;
  if (!words || !status.reopenedBy) return words;
  const who = actorWords(status.reopenedBy, { signedIn });
  if (!who) return words;
  return words.replace(/^Reopened by .+? \(/, () => `Reopened by ${who} (`);
}

/** The engine's lock status, checked and normalised, or null when it isn't one. Pure. */
export function lockStatusOf(raw) {
  if (!isObj(raw) || typeof raw.period !== "string" || !PERIOD.test(raw.period)) return null;
  if (typeof raw.lastDay !== "string" || !ISO_DAY.test(raw.lastDay)) return null;
  if (!STEPS.has(raw.step) || typeof raw.signedOff !== "boolean" || typeof raw.done !== "boolean") return null;
  if (raw.locked !== true && raw.locked !== false && raw.locked !== null) return null;
  const ledgerLock = ledgerLockOf(raw.ledgerLock);
  if (!ledgerLock) return null;
  return {
    period: raw.period,
    lastDay: raw.lastDay,
    signedOff: raw.signedOff,
    signedOffAt: text(raw.signedOffAt),
    ledgerLock,
    locked: raw.locked,
    done: raw.done,
    step: raw.step,
    words: text(raw.words),
    // Review 29 Oct: a signed-off month can be reopened (with a reason); the engine says
    // whether this one was, and keeps who did what.
    reopened: raw.reopened === true,
    // WHO REOPENED IT, as stored ("key: founder"), from the month's own history: worded
    // only where it is drawn (reopenedWords), by the same rule as `signedOffBy` (UI walk 2,
    // N5: the reopening key read "Reopened by walk2-reviewer's key" about itself).
    reopenedBy: raw.reopened === true ? lastReopenActor(raw.history) : null,
    // WHO SIGNED IT OFF, AND WHAT THEY CONFIRMED (engine w3/int, UI walk D3): the stored
    // actor as recorded ("key: founder"), worded only where it is drawn (signedByWords),
    // and the open rows they confirmed could wait, in the engine's words, or null.
    signedOffBy: raw.signedOff ? text(raw.signedOffBy) : null,
    // WHO, IN THE ENGINE'S OWN WORDS (engine w15, walk 2 N9): the person or key's name as
    // the engine says it, drawn for anyone but the one who signed it off ("you").
    signedOffByWords: raw.signedOff ? text(raw.signedOffByWords) : null,
    signedOffNote: raw.signedOff ? text(raw.signedOffNote) : null,
    // WHEN IT CAN BE SIGNED OFF (staging browser walk 1, D15): the first day after the
    // month, and whether it has come in the client's own time zone, as the engine says.
    signOffFrom: typeof raw.signOffFrom === "string" && ISO_DAY.test(raw.signOffFrom) ? raw.signOffFrom : null,
    monthEnded: typeof raw.monthEnded === "boolean" ? raw.monthEnded : null,
  };
}

/** "2026-10-31" → "2026-11-01", on the calendar alone. Null for anything else. Pure. */
function dayAfter(day) {
  if (typeof day !== "string" || !ISO_DAY.test(day)) return null;
  const [y, m, d] = day.split("-").map(Number);
  const next = new Date(Date.UTC(y, m - 1, d + 1));
  return next.toISOString().slice(0, 10);
}

/** Today on the books' calendar (lib/format.js DISPLAY_TIME_ZONE), "YYYY-MM-DD". */
export function closeToday(now = new Date()) {
  return displayDayOf(now.toISOString());
}

/**
 * WHY SIGN OFF WAITS, OR NULL (staging browser walk 1, D15): "October can be signed off
 * from 1 Nov 2026", while the month hasn't ended. The engine's `monthEnded` decides when
 * it sends one (the client's own time zone); an engine that doesn't is read from the
 * status's `lastDay` against `today`. The day is the engine's `signOffFrom`, or the day
 * after `lastDay`. Today unknown, and no word from the engine: no claim. Pure.
 */
export function signOffWait(status, today = null) {
  if (!status || status.signedOff) return null;
  const from = status.signOffFrom || dayAfter(status.lastDay);
  if (!from) return null;
  const ended = typeof status.monthEnded === "boolean" ? status.monthEnded : typeof today === "string" && ISO_DAY.test(today) ? today >= from : null;
  if (ended !== false) return null;
  const month = monthName(status.period) || periodLabel(status.period);
  return `${month} can be signed off from ${formatDate(from)}`;
}

/**
 * "Signed off by you on 29 Oct 2026." — who signed the month off: "you" to the one who
 * did, else the engine's `signedOffByWords`, else lib/format.js approverLabel (another
 * key by its label, "founder's key"; a person their name), never the stored "key: …".
 * Null when the engine names nobody. Pure.
 */
export function signedByWords(status, signedIn = null) {
  if (!status || !status.signedOff || (!status.signedOffBy && !status.signedOffByWords)) return null;
  const mine = actorWords(status.signedOffBy, { signedIn }) === "you";
  const who = mine ? "you" : status.signedOffByWords || actorWords(status.signedOffBy, { signedIn });
  if (!who) return null;
  let on = "";
  try {
    on = status.signedOffAt ? ` on ${formatDate(status.signedOffAt)}` : "";
  } catch {
    on = "";
  }
  return `Signed off by ${who}${on}.`;
}

/**
 * THE MONTH'S OPEN ROWS, AS A SIGN-OFF REFUSED OVER THEM NAMES THEM (engine w3/int, UI
 * walk D3: September was signed off with five tasks "Needs you" and the confirm named
 * none). `error.detail.openItems` → `[{ key, title, status, line, decisions }]`, each
 * with a key and a title; anything else is dropped. Pure.
 */
export function openItemsOf(raw) {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((i) => isObj(i) && text(i.key) && text(i.title))
    .map((i) => ({ key: i.key, title: text(i.title), status: text(i.status) || "", line: text(i.line) || "", decisions: Number.isInteger(i.decisions) ? i.decisions : 0 }));
}

/** What the sheet says above the open rows: how many, and that confirming keeps them. Pure. */
export function openItemsWords(period, items) {
  const n = Array.isArray(items) ? items.length : 0;
  const month = periodLabel(period);
  return n === 1 ? `${month} · 1 open item` : `${month} · ${n} open items`;
}

/**
 * What signing off does, said before the press confirms it (review, 29 Oct 2026):
 * "Signing off October keeps its balances and stops Vert drafting journals, bills or
 * coded transactions dated in October. You can reopen it." Pure.
 */
export function signOffConfirmWords(period) {
  const month = monthName(period) || periodLabel(period);
  return `Stops drafts dated ${month}. You can reopen.`;
}

/** What reopening does, said beside the reason box. Pure. */
export function reopenWords(period) {
  const month = monthName(period) || periodLabel(period);
  return `Drafts in ${month} again. Lock date still applies. Say why.`;
}

/** Whether the tenant's ledger is Xero, by the name `/approvals/ledger` gives it. Pure. */
export function isXero(ledgerName) {
  return typeof ledgerName === "string" && /^xero\b/i.test(ledgerName.trim());
}

/**
 * "Xero lock date: 30 Jun 2008" on a Xero tenant; on any other (or one whose ledger isn't
 * known) "Your ledger's lock date: …" — never Xero's name or its menu path on a ledger
 * that isn't Xero (live check, 29 Oct 2026: a QuickBooks-shaped tenant read "Xero lock
 * date"). Not read is said in the engine's words. Pure.
 */
export function lockLine(ledgerLock, ledgerName = null, { signedOff = null } = {}) {
  if (!ledgerLock) return null;
  const xero = isXero(ledgerName);
  const head = xero ? "Xero lock date" : "Your ledger's lock date";
  // NOT SIGNED OFF YET (engine w3/int, staging browser walk 1, D1): the lock date is read
  // only for a signed-off month, so before then it is unread by design, said in the
  // engine's words ("It's read once the month is signed off."), never "not read".
  // WHAT TO DO, NOT ONLY WHEN IT IS READ (founder's walk, 8 Nov 2026): the close list's
  // last step is setting the lock date, and the line said only when Vert reads it. On
  // Xero it says where it is set (apps can't set it), then that Vert checks it.
  if (!ledgerLock.measured && signedOff === false && ledgerLock.words === LOCK_READ_AFTER_SIGN_OFF) {
    return xero ? `${head}: after you sign off, set it to the month's last day in Xero (${LOCK_PATH}). Vert checks it then.` : `${head}: ${ledgerLock.words}`;
  }
  if (!ledgerLock.measured) return `${head}: not read. ${ledgerLock.words || "Vert couldn't read it just now."}`;
  if (ledgerLock.lockDate) return `${head}: ${formatDate(ledgerLock.lockDate)}`;
  return xero ? "No lock date set in Xero" : "No lock date set in your ledger";
}

/** After Check again, what the ledger said, when it isn't locked yet. */
function afterCheck(ledgerLock, ledgerName) {
  const xero = isXero(ledgerName);
  const whose = xero ? "Xero's" : "Your ledger's";
  if (!ledgerLock.measured) return `${whose} lock date couldn't be read. ${ledgerLock.words || "Vert couldn't read it just now."}`;
  if (ledgerLock.lockDate) return `${whose} lock date is still ${formatDate(ledgerLock.lockDate)}.`;
  return xero ? "Xero still has no lock date set." : "Your ledger still has no lock date set.";
}

// The engine stores the sign-off note cut at this many characters (close_lock.py
// OPEN_NOTE_MAX), wherever the cut lands.
const NOTE_CUT_AT = 500;

/**
 * THE SIGNED-OFF NOTE, ENDING ON A WHOLE ITEM (staging browser walk 4, W4-8). The engine
 * keeps the first 500 characters of "Signed off with 8 open, confirmed as able to wait:
 * A (Needs you: 6 decisions); B (…)", and the full stop added here made the cut read
 * "Business bank account (Needs.". A note whose last item is cut (a bracket left open,
 * or a note at the cut length not ending on one) ends at the last whole item and says
 * "and more."; a whole note gains only its full stop. Pure.
 */
export function signedNoteWords(note) {
  const text = typeof note === "string" ? note.trim() : "";
  if (!text) return null;
  const open = (text.match(/\(/g) || []).length > (text.match(/\)/g) || []).length;
  const cut = open || (text.length >= NOTE_CUT_AT && !/[).!?]$/.test(text));
  if (cut) {
    const at = text.lastIndexOf("; ");
    if (at > 0) return `${text.slice(0, at)}; and more.`;
  }
  return /[.!?]$/.test(text) ? text : `${text}.`;
}

/**
 * What the panel draws for a lock status (`lockStatusOf`'s): `{ step, lockLine, done,
 * lines, after, action, signedBy, signedNote }`. `done` is the line drawn with a tick; `lines` explain the step;
 * `after` is what a Check again found (only once one was asked: `checked`); `action` is
 * the one press, `{ kind: "signOff" | "check", label }`, or null. Pure.
 */
export function closeStepOf(status, { checked = false, ledgerName = null, signedIn = null, today = null } = {}) {
  if (!status) return null;
  const month = periodLabel(status.period);
  const xero = isXero(ledgerName);
  // Named where the tenant's ledger is known; Xero's own menu path only on Xero.
  const where = xero ? "Xero" : typeof ledgerName === "string" && ledgerName.trim() ? ledgerName.trim() : "your ledger";
  // `signedBy`: who signed it off, worded; `signedNote`: the open rows they confirmed.
  const base = {
    step: status.step,
    lockLine: lockLine(status.ledgerLock, ledgerName, { signedOff: status.signedOff }),
    done: null,
    lines: [],
    after: null,
    action: null,
    signedBy: signedByWords(status, signedIn),
    // A sentence, with its full stop (UI walk 2, N7: the list of open rows had none),
    // never cut mid-item (walk 4, W4-8).
    signedNote: status.signedOff && status.signedOffNote ? signedNoteWords(status.signedOffNote) : null,
  };
  const reopen = status.signedOff ? { kind: "reopen", label: `Reopen ${month}` } : null;
  if (status.step === "sign_off") {
    // A reopened month says who reopened it and why (the engine's words) above the press.
    const lines = status.reopened && status.words ? [reopenedWords(status, signedIn), SIGN_OFF_EXPLAINED] : [SIGN_OFF_EXPLAINED];
    // Not ended yet: the press is drawn, disabled, with the day it can be pressed.
    return { ...base, lines, action: { kind: "signOff", label: `Sign off ${month}`, disabledReason: signOffWait(status, today) }, reopen: null };
  }
  if (status.step === "set_lock") {
    return {
      ...base,
      done: "Signed off in Vert",
      lines: xero ? [`Set Xero lock date: ${formatDate(status.lastDay)}`, LOCK_PATH] : [`Set ${where} lock date: ${formatDate(status.lastDay)}`],
      after: checked ? afterCheck(status.ledgerLock, ledgerName) : null,
      action: { kind: "check", label: "Check again" },
      reopen,
    };
  }
  const to = status.ledgerLock.lockDate ? ` to ${formatDate(status.ledgerLock.lockDate)}` : "";
  return { ...base, done: `Signed off and locked in ${where}${to}`, reopen };
}

const LOCK_NOTE = { sign_off: { words: "Not signed off", tone: null }, set_lock: { words: "Set the lock date", tone: "attention" }, done: { words: "Signed off and locked", tone: "done" } };

/** The close list's Sign off row words, from the engine's close step, or null (CloseList.js). Pure. */
export function lockNote(status) {
  const step = status && typeof status.step === "string" ? status.step : null;
  return step && LOCK_NOTE[step] ? LOCK_NOTE[step] : null;
}
