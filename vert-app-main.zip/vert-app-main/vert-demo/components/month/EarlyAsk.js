"use client";
// components/month/EarlyAsk.js — THE ASK BOX, WHILE MONTH-END LOADS (D40, 8 Nov 2026)
// ==============================================================================
// The loading skeleton drew a grey block where the ask box lands, and words typed into
// it went nowhere. This is a real box in the same place and shape (the ask box's own
// classes): what is typed is held (lib/early-ask.js) and the real box opens with it,
// focused. Sending stays a press in the real box: a page view never posts on its own.

import { useState } from "react";
import { holdEarlyAsk } from "@/lib/early-ask";
import { ASK_PLACEHOLDER } from "./AskBox";

export default function EarlyAsk() {
  const [text, setText] = useState("");
  const [waiting, setWaiting] = useState(false);
  return (
    <div className="ask early-ask">
      <label className="sr-only" htmlFor="early-ask-input">
        Ask or tell Vert
      </label>
      <div className="ask-box" data-ready="false">
        <div className="ask-row">
          <textarea
            id="early-ask-input"
            name="early-ask"
            className="ask-input"
            rows={1}
            autoComplete="off"
            placeholder={ASK_PLACEHOLDER}
            value={text}
            onChange={(e) => {
              setText(e.target.value);
              holdEarlyAsk(e.target.value);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing && text.trim()) {
                e.preventDefault();
                setWaiting(true);
              }
            }}
          />
        </div>
      </div>
      {waiting ? <p className="ask-reason ink-2" aria-live="polite">Month-end is opening. Your words will be in the box: press Enter again to send.</p> : null}
    </div>
  );
}
