"use client";

// components/month/ClosePanel.js — CLOSE THE MONTH: STATEMENTS, THE PACK, SIGN OFF AND LOCK
// ==============================================================================
// W4 Step 5 of the close list (29 Oct 2026). One compact panel on Month-end for the
// month shown, in the order the step is done:
//
//   1. the ledger's lock date, as the engine read it ("Xero lock date: 30 Jun 2008"), or
//      that none is set, or that it wasn't read, in the engine's words;
//   2. the way to the month's statements (app/statements, Month-end's section, not a
//      sidebar item) and the month-end pack, as a PDF and as Excel (plain downloads);
//   3. the one step the engine says is next (close-step.js): "Sign off September 2026";
//      or "Signed off in Vert" with where to set the lock date and Check again; or
//      "Signed off and locked in Xero to 30 Sep 2026".
//
// SIGNING OFF IS CONFIRMED, AND CAN BE UNDONE (review, 29 Oct 2026). The press first
// says what it does ("Signing off October keeps its balances and stops Vert drafting
// journals, bills or coded transactions dated in October. You can reopen it."); a
// signed-off month offers Reopen, which asks why and keeps the reason with the name.
//
// OPEN WORK IS NAMED, AND CONFIRMED BY NAME (engine w3/int, UI walk D3, 30 Oct 2026).
// September was signed off with five tasks "Needs you" and the confirm named none. A
// sign-off over open checklist rows is refused (409 `open_items_unacknowledged`) with
// each row; the confirm then lists them (title and line) under a second, explicit "Sign
// off with these open", which resends exactly their keys. Nothing is acknowledged for
// the person: the 409 only draws the rows. The signed-off month says who signed it off
// (lib/format.js approverLabel: "you", "another access code", or the person's name,
// never "key: …") and the rows they confirmed, in the engine's words.
//
// A PAGE VIEW SENDS NO WRITE (tests/p0-quiet-page-load.test.js). The status is read by
// app/page.js on the server and handed in as `initial`; this panel calls the app's route
// (lib/close-client.js) only from a press: Sign off is the one write, Check again a read.
// After a sign-off lands the page is re-read (router.refresh), so the header and the
// sidebar learn the month is closed from the engine, not from this panel.

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui";
import { IconCheck, IconDownload } from "@/components/ui/icons";
import { readLockStatus, reopenMonth, signOffMonth } from "@/lib/close-client";
import { useSignedInActor } from "@/lib/store";
import { announceMonthClose } from "@/components/shell/live-shell";
import { commitLock } from "@/lib/commit-lock";

/** Sign off, Reopen and Check take one press at a time (lead LX-2: a double-click on Reopen
 * answered "nothing to reopen" right after it worked; `busy` state is stale in one tick). */
const CLOSE_LOCK = "close-panel";
import { LOCK_READ_AFTER_SIGN_OFF, closeStepOf, closeToday, lockStatusOf, openItemsOf, openItemsWords, reopenWords, signOffConfirmWords } from "./close-step";

const PERIOD = /^[0-9]{4}-(0[1-9]|1[0-2])$/;
export const SAMPLE_CLOSE_WORDS = "This sample has no ledger behind it, so there's no lock date to read and no month to sign off here.";
const UNREAD_WORDS = "Vert couldn't read the month's close status just now.";

/**
 * The month's open rows, as the refused sign-off named them, and the second, explicit
 * press that signs off over them. Drawn inside the sign-off confirm; `onConfirm` resends
 * the rows' keys, `onCancel` goes back without signing off.
 */
export function SignOffOpenItems({ period, items, busy = false, onConfirm, onCancel }) {
  return (
    <div className="close-panel-open" data-close-open-items="">
      <p className="close-panel-words">{openItemsWords(period, items)}</p>
      <ul className="close-panel-open-list">
        {items.map((i) => (
          <li key={i.key} className="close-panel-open-item">
            <span className="close-panel-open-title">{i.title}</span>
            {i.line || i.status ? <span className="close-panel-open-line">{i.line || i.status}</span> : null}
          </li>
        ))}
      </ul>
      <div className="close-panel-actions">
        <Button variant="commit" size="sm" busy={busy} busyLabel="Signing off…" onClick={onConfirm} data-close-sign-off-open="">
          Sign off with these open
        </Button>
        <Button variant="secondary" size="sm" onClick={onCancel} disabled={busy}>
          Cancel
        </Button>
      </div>
    </div>
  );
}

/**
 * The month's tasks not Done, from the payload's counts, or null when unread. Pure.
 * 9 Nov 2026, the bookkeeper walk: Sign off and the pack showed nothing about six open
 * tasks until Sign off was pressed; the count is said beside both, before any press.
 */
export function openTasksOf(month) {
  // The three open words' counts, as the payload sent them (no figure is derived from
  // the month's total: tests/no-arithmetic.test.js).
  const c = month && month.counts;
  if (!c || ![c.needsYou, c.working, c.waiting].every(Number.isInteger)) return null;
  return c.needsYou + c.working + c.waiting;
}

/** "6 tasks are still open", or null for none or unread. Pure. */
export function openTasksWords(n) {
  if (!Number.isInteger(n) || n <= 0) return null;
  return `${n} ${n === 1 ? "task is" : "tasks are"} still open`;
}

export default function ClosePanel({ period, initial = null, unreadWords = null, sample = false, ledgerName = null, today = undefined, asAt = null, onStatus = null, open = null }) {
  const router = useRouter();
  const [status, setStatus] = useState(() => lockStatusOf(initial));
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState(null);
  // Review 29 Oct: signing off is confirmed in words first; reopening asks why.
  const [confirming, setConfirming] = useState(false);
  const [reopening, setReopening] = useState(false);
  const [reason, setReason] = useState("");
  // The open rows a refused sign-off named, or null: only ever set from the engine's 409.
  const [openItems, setOpenItems] = useState(null);
  const signedIn = useSignedInActor();
  // The page learns where a press left the month at once (walk 4, W4-10: Catch up stayed
  // offered on a month just signed off until the re-read landed).
  // The sidebar's month switcher learns it too (walk 5, W5-5: "Closed" after a reopen).
  const report = (next) => {
    if (typeof onStatus === "function") onStatus(next);
    announceMonthClose(next);
  };

  // A new server reading (the page was re-read) replaces what this panel holds. Nothing
  // is asked here: the reading is the page's.
  useEffect(() => {
    setStatus(lockStatusOf(initial));
    setChecked(false);
  }, [initial]);

  // The chat's "Open sign-off" (/?period=…#sign-off) lands here. The panel is drawn only
  // once the month's close is read, after the browser's own jump to the anchor found
  // nothing, so it brings itself into view when it arrives (staging check, 4 Nov 2026).
  const anchor = useRef(null);
  useEffect(() => {
    if (typeof window === "undefined" || window.location.hash !== "#sign-off") return;
    if (anchor.current) anchor.current.scrollIntoView({ block: "start" });
  }, []);

  if (!PERIOD.test(String(period || ""))) return null;
  if (sample) {
    return (
      <section id="sign-off" ref={anchor} className="close-panel" data-close-panel="" data-close-step="sample" aria-label="Close the month">
        <h2 className="close-panel-title">Close the month</h2>
        <p className="close-panel-words">{SAMPLE_CLOSE_WORDS}</p>
      </section>
    );
  }

  // The tenant's own ledger names the lock date (live check, 29 Oct): Xero's words and
  // path only on Xero, "your ledger" otherwise.
  const view = closeStepOf(status, { checked, ledgerName, signedIn, today: today === undefined ? closeToday() : today });

  // `keys`: the open rows the person confirmed, from the second press only; the first
  // press sends none.
  const signOff = async (keys = null) => {
    if (busy || !commitLock.acquire(CLOSE_LOCK)) return;
    let got;
    try {
      setBusy("signOff");
      setError(null);
      got = await signOffMonth(period, keys ? { acknowledgeOpen: keys } : undefined);
      setBusy(null);
    } finally {
      commitLock.release(CLOSE_LOCK);
    }
    if (!got.ok) {
      const named = openItemsOf(got.openItems);
      if (got.code === "open_items_unacknowledged" && named.length) {
        // The month has open work: show it, in the confirm, and wait for the person.
        setOpenItems(named);
        setConfirming(true);
        return;
      }
    }
    setConfirming(false);
    setOpenItems(null);
    const next = got.ok ? lockStatusOf(got.body) : null;
    if (!next) {
      setError(got.ok ? "Vert answered, but its answer couldn't be read. Press Check again to read where the month stands." : got.message);
      return;
    }
    setStatus(next);
    report(next);
    setChecked(false);
    router.refresh();
  };
  const signOffWithOpen = () => signOff(openItems.map((i) => i.key));
  const cancelSignOff = () => {
    setConfirming(false);
    setOpenItems(null);
  };

  const reopen = async () => {
    if (busy || !reason.trim() || !commitLock.acquire(CLOSE_LOCK)) return;
    let got;
    try {
      setBusy("reopen");
      setError(null);
      got = await reopenMonth(period, reason);
      setBusy(null);
    } finally {
      commitLock.release(CLOSE_LOCK);
    }
    const next = got.ok ? lockStatusOf(got.body) : null;
    if (!next) {
      setError(got.ok ? "Vert answered, but its answer couldn't be read. Press Check again to read where the month stands." : got.message);
      return;
    }
    setStatus(next);
    report(next);
    setReopening(false);
    setReason("");
    setChecked(false);
    router.refresh();
  };

  const check = async () => {
    if (busy || !commitLock.acquire(CLOSE_LOCK)) return;
    let got;
    try {
      setBusy("check");
      setError(null);
      got = await readLockStatus(period);
      setBusy(null);
    } finally {
      commitLock.release(CLOSE_LOCK);
    }
    const next = got.ok ? lockStatusOf(got.body) : null;
    if (!next) {
      setError(got.ok ? "Vert's answer couldn't be read. Nothing was changed." : got.message);
      return;
    }
    setStatus(next);
    report(next);
    setChecked(true);
  };

  return (
    <section id="sign-off" ref={anchor} className="close-panel" data-close-panel="" data-close-step={view ? view.step : "unread"} aria-label="Close the month">
      <div className="close-panel-head">
        <h2 className="close-panel-title">Close the month</h2>
      </div>
      <div className="close-panel-step">
        {view && view.done ? (
          <p className="close-panel-done" data-close-done="">
            <IconCheck className="close-panel-tick" aria-hidden="true" />
            <span>{view.done}</span>
          </p>
        ) : null}
        {view && view.signedBy ? (
          <p className="close-panel-words" data-close-signed-by="">
            {view.signedBy}
          </p>
        ) : null}
        {view && view.signedNote ? (
          <p className="close-panel-words close-panel-note" data-close-signed-note="">
            {view.signedNote}
          </p>
        ) : null}
        {view ? view.lines.map((line) => (
          <p key={line} className="close-panel-words">
            {line}
          </p>
        )) : null}
        {view && view.after ? (
          <p className="close-panel-after" role="status" data-close-after="">
            {view.after}
          </p>
        ) : null}
        {error ? (
          <p className="close-panel-error" role="alert">
            {error}
          </p>
        ) : null}
        {view && view.action && view.action.kind === "signOff" && !confirming && openTasksWords(open) ? (
          <p className="close-panel-words" data-close-open-note="">
            {openTasksWords(open)}: Vert names each one before the month is signed off.
          </p>
        ) : null}
        {view && view.action && view.action.kind === "signOff" && !confirming ? (
          <Button variant="commit" size="sm" busy={busy === "signOff"} busyLabel="Signing off…" disabledReason={view.action.disabledReason || undefined} onClick={() => setConfirming(true)} data-close-sign-off="">
            {view.action.label}
          </Button>
        ) : null}
        {view && view.action && view.action.kind === "signOff" && confirming ? (
          <div className="close-panel-confirm" role="group" aria-label="Confirm sign-off" data-close-confirm="">
            <p className="close-panel-words">{signOffConfirmWords(period)}</p>
            {openItems ? (
              <SignOffOpenItems period={period} items={openItems} busy={busy === "signOff"} onConfirm={signOffWithOpen} onCancel={cancelSignOff} />
            ) : (
              <div className="close-panel-actions">
                <Button variant="commit" size="sm" busy={busy === "signOff"} busyLabel="Signing off…" onClick={() => signOff()} data-close-confirm-sign-off="">
                  {view.action.label}
                </Button>
                <Button variant="secondary" size="sm" onClick={cancelSignOff} disabled={busy === "signOff"}>
                  Cancel
                </Button>
              </div>
            )}
          </div>
        ) : null}
        {view && view.reopen && !reopening ? (
          <Button variant="secondary" size="sm" onClick={() => setReopening(true)} data-close-reopen="">
            {view.reopen.label}
          </Button>
        ) : null}
        {view && view.reopen && reopening ? (
          <div className="close-panel-confirm" role="group" aria-label="Reopen the month" data-close-reopen-form="">
            <p className="close-panel-words">{reopenWords(period)}</p>
            <label className="close-panel-reason">
              <span>Why reopen it?</span>
              <textarea name="reopenReason" autoComplete="off" value={reason} maxLength={500} rows={2} required onChange={(e) => setReason(e.target.value)} data-close-reason="" />
            </label>
            <div className="close-panel-actions">
              <Button variant="commit" size="sm" busy={busy === "reopen"} busyLabel="Reopening…" disabled={!reason.trim()} onClick={reopen} data-close-confirm-reopen="">
                {view.reopen.label}
              </Button>
              <Button variant="secondary" size="sm" onClick={() => { setReopening(false); setReason(""); }} disabled={busy === "reopen"}>
                Cancel
              </Button>
            </div>
          </div>
        ) : null}
        {!view || (view.action && view.action.kind === "check") ? (
          <Button variant="secondary" size="sm" busy={busy === "check"} busyLabel="Checking…" onClick={check} data-close-check="">
            Check again
          </Button>
        ) : null}
      </div>
      {/* IN THE ORDER IT'S DONE (founder's walk, 8 Nov 2026): sign off above, then the
          ledger's lock date, then the month's pack. The statements are their own row of the
          close list, so no link here leaves for their page. */}
      <div className="close-panel-next">
        <p className="close-panel-lock" data-close-lock={status ? (status.ledgerLock.measured ? "read" : !status.signedOff && status.ledgerLock.words === LOCK_READ_AFTER_SIGN_OFF ? "later" : "unread") : "unread"}>
          {view ? view.lockLine : unreadWords || UNREAD_WORDS}
        </p>
      </div>
      <PackDownloads period={period} asAt={asAt} open={open} />
    </section>
  );
}

/**
 * The month-end pack (vert_engine.reporting_pack: executive summary, profit and loss,
 * balance sheet, cash flow, trial balance, aged receivables and payables, commentary),
 * as a PDF snapshot and as Excel. Drawn under Sign off and, on its own, under the close
 * list's Reporting pack row (founder's walk, 8 Nov 2026: the row showed the payout
 * workpapers' "Waiting · After the bank rec" while the pack was one press away).
 */
export function PackDownloads({ period, asAt = null, open = null }) {
  const unfinished = openTasksWords(open);
  return (
    <>
      {unfinished ? (
        <p className="close-panel-words" data-pack-open="">
          {unfinished}, so the pack's figures may still change.
        </p>
      ) : null}
      <div className="close-panel-links">
        <a className="link close-panel-download" href={`/api/close/${period}/pack?format=pdf`} download data-pack-download="pdf">
          <IconDownload aria-hidden="true" />
          <span>Download month-end pack</span>
        </a>
        <a className="link" href={`/api/close/${period}/pack?format=xlsx`} download data-pack-download="xlsx">
          Excel
        </a>
      </div>
      {/* When the pack's figures were read (walk 2, N8): the engine's words. */}
      {asAt ? (
        <p className="t-footnote close-panel-asat" data-pack-as-at="">
          {asAt}
        </p>
      ) : null}
    </>
  );
}
