"use client";

// components/month/DocumentsCard.js — THE MONTH'S DOCUMENTS, ONE COMPACT CARD
// ==============================================================================
// Audit 1.1 (3 Nov 2026), the close checklist's Step 1 "Collect documents":
//
//   Documents                         2 October documents missing.
//   Statements   2 of 3 in, 1 missing.
//                091 · Business Savings Account — Nothing after 30 Sep.   Import
//   Bills        1 of 1 monthly supplier not in yet. Telstra
//   Receipts     1 receipt or bill waiting to be coded and approved.      Bills & invoices
//
// Drawn on Month-end (app/page.js reads GET /close/{period}/documents on the server, a
// page read: no Xero) and in the chat's answer (`shape.documents`). Only what's missing
// is listed by name; what's in is counted in the engine's words. A part that wasn't read
// is its words ("Not measured: …"), never a zero.
//
// A PAGE VIEW SENDS NOTHING (tests/p0-quiet-page-load.test.js). Xero's bills are read
// only on the person's press, "Check bills": a GET of the app's route with ?live=1.

import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui";
import { readDocumentsChecklist } from "@/lib/close-client";
import { documentsShapeOf } from "@/components/chat/answer/documents";
import BankStatementImport from "@/components/settings/BankStatementImport";
import InboxSheet from "@/components/bills/InboxSheet";

// A DOCUMENT CHECKLIST, AS DOCUMENT TOOLS DRAW ONE (founder, 8 Nov 2026: "fix them to
// function in a way it is used in other softwares"). Every statement the month needs is a
// row, received or not, with its mark and the engine's words; a missing one is uploaded
// on its own row (the import opens there, on that account) instead of on Connections.
// "Done" closes the import and reads the checklist again, so the row turns received.

/** A statement row's mark: received, needs a file, or neither. Pure. */
export function statementMark(status) {
  if (status === "received") return "received";
  if (status === "missing" || status === "partial") return "missing";
  return "neutral";
}

/**
 * `checkOnOpen`: the card was opened by a person's press (Month-end's Collect documents
 * row), so it reads the ledger's bills at once rather than asking for a second press
 * (founder's walk, 8 Nov 2026: "Not measured … when you press Check bills" under a panel
 * just opened). A page load never reads the ledger; this is the press.
 */
export default function DocumentsCard({ period, initial = null, unreadWords = null, sample = false, live = true, checkOnOpen = false }) {
  const [body, setBody] = useState(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [uploading, setUploading] = useState(null);
  const [inboxOpen, setInboxOpen] = useState(false);
  const view = documentsShapeOf(body);
  const reread = async ({ bills = false } = {}) => {
    if (busy) return;
    setBusy(true);
    setError(null);
    const got = await readDocumentsChecklist(period, { live: bills });
    setBusy(false);
    if (got.ok && documentsShapeOf(got.body)) setBody(got.body);
    else setError(got.ok ? "Vert's answer couldn't be read. Nothing was changed." : got.message);
  };
  const checkBills = () => reread({ bills: true });
  const checked = useRef(false);
  useEffect(() => {
    if (!checkOnOpen || checked.current || sample || !live || !view || view.bills.measured) return;
    checked.current = true;
    checkBills();
    // Once per opening: a read that fails leaves Check bills to press.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [checkOnOpen]);
  const doneUploading = () => {
    setUploading(null);
    reread();
  };
  return (
    <section className="close-panel docs-card" data-documents-card="" aria-label="The month's documents">
      <div className="close-panel-body">
        <h2 className="close-panel-title t-headline">Documents</h2>
        {!view ? (
          <p className="close-panel-words">{sample ? "These are the sample books, so there are no documents to check." : unreadWords || "Vert couldn't read the month's documents just now."}</p>
        ) : (
          <>
            <p className="close-panel-words" data-documents-words="">{view.words}</p>
            <div className="docs-part" data-documents-part="statements">
              <h3 className="docs-part-title">Statements</h3>
              {!view.statements.measured ? <p className="docs-part-words">{view.statements.words}</p> : null}
              <ul className="docs-rows">
                {view.statements.rows.map((r) => {
                  const mark = statementMark(r.status);
                  const canUpload = live && !sample && r.status !== "received" && r.status !== "not_due";
                  return (
                    <li key={r.id} className="docs-row" data-doc-status={r.status}>
                      <span className="docs-mark" data-mark={mark} aria-hidden="true" />
                      <span className="docs-name" translate="no">
                        {r.label}
                      </span>
                      <span className="docs-words">{r.words}</span>
                      <span className="docs-action">
                        {canUpload ? (
                          <Button variant={uploading === r.id ? "quiet" : "secondary"} size="sm" aria-expanded={uploading === r.id ? "true" : "false"} onClick={() => (uploading === r.id ? doneUploading() : setUploading(r.id))} data-documents-upload={r.id}>
                            {uploading === r.id ? "Done" : "Upload"}
                          </Button>
                        ) : null}
                      </span>
                      {uploading === r.id ? (
                        <div className="docs-upload" data-documents-upload-form={r.id}>
                          <BankStatementImport account={r.id} compact />
                        </div>
                      ) : null}
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="docs-part" data-documents-part="bills">
              <h3 className="docs-part-title">Bills from regular suppliers</h3>
              <p className="docs-part-words">{view.bills.words}</p>
              {view.missingBills.length ? (
                <ul className="docs-rows">
                  {view.missingBills.map((r) => (
                    <li key={r.contact} className="docs-row" data-doc-status="missing">
                      <span className="docs-mark" data-mark="missing" aria-hidden="true" />
                      <span className="docs-name" translate="no">
                        {r.contact}
                      </span>
                      <span className="docs-words">Not in yet</span>
                    </li>
                  ))}
                </ul>
              ) : null}
              {!view.bills.measured && live && !sample ? (
                <Button variant="secondary" size="sm" busy={busy} busyLabel="Reading the ledger…" onClick={checkBills} data-documents-check-bills="">
                  Check bills
                </Button>
              ) : null}
            </div>
            <div className="docs-part" data-documents-part="receipts">
              <h3 className="docs-part-title">Receipts</h3>
              <p className="docs-part-words">
                {view.receipts.words}
                {view.receipts.awaitingCoding ? (
                  <>
                    {" "}
                    <button type="button" className="link bill-row-open" aria-haspopup="dialog" onClick={() => setInboxOpen(true)} data-documents-receipts="">
                      Code them
                    </button>
                  </>
                ) : null}
              </p>
            </div>
            {inboxOpen ? <InboxSheet onClose={() => setInboxOpen(false)} /> : null}
            {error ? (
              <p className="close-panel-error" role="alert">
                {error}
              </p>
            ) : null}
          </>
        )}
      </div>
    </section>
  );
}
