"use client";

// components/month/MonthContext.js — "NORTHWIND · JUNE ▾", AND WHERE THE FIGURES COME FROM
// ==============================================================================
// Build plan §4.6 FM item 2; spec §7 (context is shown once per place).
//
// WHY THE SOURCES MOVED HERE. Month-end used to end in a freshness line — "Shopify
// Payments, Stripe and Bank statement last read 1 Jul · Sync now" — which put the idea
// of a source in front of the person on every visit, beside decisions that had nothing
// to do with it. Above the fold the page now holds at most five ideas (S4′), and a
// source is not one of them unless something is wrong with one. So the client and the
// month are one chip beside the title, as they are in a conversation, and the chip
// opens a sheet with the sources, their freshness in words, the one Sync now, and the
// way to Connections.
//
// A SOURCE THAT IS BEHIND IS NOT HIDDEN BY THIS. The chip's accessible name says "some
// sources are behind", whenever the payload marks one stale or failed — the same test
// the old line used to offer Sync now — and opening the sheet says which, in the same
// words (SourcesLine, model.js freshnessLine). Once nothing needs you, the tray under
// the ask box says it on the page too.
//
// DESIGN PASS (Calm neutral, 9 Oct 2026; spec §6.7). The chip is a quiet button — the
// client and month in footnote ink with a chevron — and no longer carries an amber dot:
// a colour with no word beside it broke "colour never alone", and the audit (§1 P2)
// counted it as a second, unexplained status on the title's line.
//
// DESIGN-FIX-2 (DA2-006, 10 Oct 2026). The sidebar names the client and the month, so
// the title's line no longer says them a second time: the chip is now a quiet "•••"
// beside the anchor figure, named "Sources for Northwind · July" (and "Some sources are
// behind" when one is), opening the same sheet. On a phone the top bar keeps the
// context title, so the head drops it there (month.css).
//
// FIX ROUND (critique r1, DA2-038 on Home; 10 Oct 2026). The "•••" opened the old
// full-height right sheet, with a second card floating inside it, a blur smudge and no
// scrim, while the conversation's own "•••" had already become an anchored popover. Home
// now opens the SAME kind of thing: the kit's popover material (`--r-md`, `--float-bg`),
// anchored under the button, growing from the corner it hangs from on the snappy spring,
// no inner card and no scrim. The "•••" sits beside the title, as a 32 px icon button on
// the title's line, so it belongs to the page's name rather than floating by the anchor.
// Inside: the client and month, each source with its mark (SourceLogo) and its
// freshness in words (the conversation's list), the one Sync now when a source is
// behind, and the way to Connections. Esc, a press outside, or Tab out of it closes it,
// and focus goes back to the button.

import Link from "next/link";
import { useCallback, useEffect, useId, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, SourceLogo } from "@/components/ui";
import { failureSentence } from "@/components/cards/words";
import { SyncPressResult, useSyncPress } from "@/components/sync/SyncOutcome";
import { callSafely } from "@/lib/decisions";
import { startConversation } from "@/lib/agent/actions";
import { monthName } from "@/lib/period";
import { contextLabel, ledgerAsAtOf, monthSources, monthState, sourceWords, sourcesBehind } from "./model";

import { IconCaretRight, IconMore } from "@/components/ui/icons";

export default function MonthContext({ month, period, clientName = null, disabledReason = null }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef(null);
  const chipRef = useRef(null);
  const panelRef = useRef(null);
  const popId = useId();
  const titleId = useId();
  const label = contextLabel(clientName, month, period);
  const behind = sourcesBehind(month);
  const close = useCallback((refocus = true) => {
    setOpen(false);
    if (refocus && chipRef.current) chipRef.current.focus();
  }, []);

  useEffect(() => {
    if (!open) return undefined;
    const first = panelRef.current ? panelRef.current.querySelector("button:not([aria-disabled='true']), a[href]") : null;
    if (first) first.focus();
    function onKey(event) {
      if (event.key === "Escape") {
        event.stopPropagation();
        close(true);
      }
    }
    function onPointer(event) {
      if (rootRef.current && !rootRef.current.contains(event.target)) close(false);
    }
    function onFocusOut(event) {
      if (rootRef.current && event.relatedTarget && !rootRef.current.contains(event.relatedTarget)) close(false);
    }
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onPointer);
    const node = rootRef.current;
    if (node) node.addEventListener("focusout", onFocusOut);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onPointer);
      if (node) node.removeEventListener("focusout", onFocusOut);
    };
  }, [open, close]);

  if (!label) return null;
  return (
    <div className="month-context-wrap" ref={rootRef}>
      <button
        ref={chipRef}
        type="button"
        className="month-context icon-btn icon-btn-sm"
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? popId : undefined}
        aria-label={behind ? `Sources for ${label}. Some sources are behind.` : `Sources for ${label}`}
        title="Sources"
        data-sources-behind={behind ? "true" : undefined}
        onClick={() => setOpen((was) => !was)}
      >
        <IconMore size={18} weight="bold" aria-hidden="true" />
      </button>
      {/* Drawn only while open: closed, the page carries none of its words (the five
          ideas above the fold are counted on what is in the page, spec S4). */}
      {open ? (
        <div className="popover month-context-pop" id={popId} role="dialog" aria-labelledby={titleId} ref={panelRef} data-open="true">
          <p className="month-pop-title" id={titleId} translate="no">
            {label}
          </p>
          <p className="month-pop-label">Sources</p>
          <SourceList month={month} disabledReason={disabledReason} />
          <ImportBudget month={month} period={period} disabledReason={disabledReason} />
          <p className="month-pop-link">
            <Link href="/connections">
              Connections
              <IconCaretRight className="caret-trailing" aria-hidden="true" />
            </Link>
          </p>
        </div>
      ) : null}
    </div>
  );
}

/** Each source with its mark and its freshness in words; then the one Sync now if one is behind. */
function SourceList({ month, disabledReason }) {
  const sync = useSyncPress();
  const state = sync.state;
  const all = month && Array.isArray(month.sources) ? month.sources.filter((s) => s && s.label) : null;
  if (all === null) return <p className="month-pop-note">Vert couldn't read your sources just now.</p>;
  // The sources Month-end names: none that isn't connected (model.js monthSources).
  const list = monthSources(month);
  if (!list.length) return <p className="month-pop-note">No sources have been read for this month yet.</p>;
  const behind = sourcesBehind(month);

  return (
    <>
      <dl className="month-pop-sources" data-sources-line="popover">
        {list.map((s, i) => {
          const st = s.freshness && s.freshness.state;
          return (
            <div key={`${s.kind}-${i}`} data-behind={st === "stale" || st === "failed" || ledgerAsAtOf(s.asAt).behind ? "true" : undefined}>
              <dt>
                <SourceLogo source={s.kind || s.label} size={16} className="month-pop-logo" />
                <span translate="no">{s.label}</span>
              </dt>
              <dd>{sourceWords(s)}</dd>
            </div>
          );
        })}
      </dl>
      {behind && state !== "done" ? (
        <div className="month-pop-actions">
          <Button variant="secondary" size="sm" busy={state === "busy"} busyLabel="Syncing…" disabledReason={disabledReason} onClick={sync.press}>
            Sync now
          </Button>
        </div>
      ) : null}
      <SyncPressResult sync={sync} className="month-pop-note" />
    </>
  );
}

// IMPORT A BUDGET FROM MONTH-END (verify pass 1, D30). The budget sheet was reachable only
// from a budget-vs-actual answer's "Budgets" chip, so a firm that had never asked one
// had no way in. The budget is where the month's comparison figures come from, so it
// sits here, under the sources. The press is the answer's own "Import a budget"
// (`POST /agent/sessions {period, template: "budget_import"}`): the engine records a
// NEW import request on the month's import conversation and queues its turn, which asks
// where the budget is (vert_api routers/budgets.py press_import). Then the conversation
// opens. A refusal is said under the button in the engine's words; nothing moves.
//
// NOT BEFORE THE MONTH STARTS, AND NEVER THE ROUTE (verify pass 2, D30). On a month not
// yet started the press went to the engine, which refused with 409 `period_not_open`
// and a sentence written for a developer — "Start the month (POST /close/2026-09)…" —
// and that sentence was echoed to the accountant under the button. Two causes, two
// fixes: the press is not offered as live before the month is started (it is drawn
// inert, its reason "Start September first." beside it, under the panel whose one
// commit is Start September); and a refusal is said in words that never carry a route,
// an HTTP verb or an operator's constant (`importRefusalWords`) — the not-started code
// in our sentence, anything else in the engine's own words only when they are plain.
export const IMPORT_BUDGET_LABEL = "Import a budget";

// A refusal message written for a developer: a route, an HTTP verb, a URL, markup or an
// operator's CONSTANT_NAME. Such a message is never put on screen as it came.
const DEVELOPER_TEXT = /\b(?:POST|GET|PATCH|PUT|DELETE)\s+\/|https?:\/\/|\bHTTP\b|[{}<>]|\b[A-Z][A-Z0-9]*_[A-Z0-9_]+\b|(?:^|[\s(])\/[a-z][\w-]*\//;

/** Why the import can't be pressed yet, or null: a month not started has none to import into. */
export function importBlockedReason(month, period) {
  const state = monthState(month);
  if (state === "closed") return `${monthName(period)} is closed.`;
  return state === "not_started" ? `Start ${monthName(period)} first.` : null;
}

/** What a refused import says under its button: plain words, never a route. Pure. */
export function importRefusalWords(result, period) {
  const r = result && typeof result === "object" ? result : {};
  if (r.code === "period_not_open") return `Start ${monthName(period)} first. Nothing was started.`;
  const message = typeof r.message === "string" ? r.message.trim() : "";
  if (message && !DEVELOPER_TEXT.test(message)) return message;
  return failureSentence(r, { source: null });
}
export const IMPORT_TEMPLATE = "budget_import";

/** Start the import and open its conversation: `{ state: "opened" | "refused", href?, message? }`. */
export async function startBudgetImport(period, { start = startConversation, navigate = null } = {}) {
  if (typeof period !== "string" || !period) return { state: "refused", message: "Pick a month first. Nothing was started." };
  const result = await callSafely(start, { period, template: IMPORT_TEMPLATE });
  if (!result || result.ok !== true || typeof result.sessionId !== "string" || !result.sessionId) {
    const words = result && (result.code || result.message) ? importRefusalWords(result, period) : "Not started. Nothing was recorded.";
    return { state: "refused", message: words };
  }
  const href = `/chat/${encodeURIComponent(result.sessionId)}`;
  if (navigate) navigate(href);
  return { state: "opened", href };
}

export function ImportBudget({ month, period, disabledReason }) {
  const blocked = importBlockedReason(month, period);
  const router = useRouter();
  const [state, setState] = useState({ phase: "idle", message: null });
  async function press() {
    setState({ phase: "busy", message: null });
    const out = await startBudgetImport(period, { navigate: (href) => router.push(href) });
    setState(out.state === "opened" ? { phase: "idle", message: null } : { phase: "failed", message: out.message });
  }
  return (
    <div className="month-pop-budget" data-import-budget="">
      <p className="month-pop-label">Budget</p>
      <Button variant="secondary" size="sm" busy={state.phase === "busy"} busyLabel="Starting…" disabledReason={disabledReason || blocked} onClick={press}>
        {IMPORT_BUDGET_LABEL}
      </Button>
      {state.phase === "failed" ? (
        <p className="month-pop-note" role="alert">
          {state.message}
        </p>
      ) : null}
    </div>
  );
}
