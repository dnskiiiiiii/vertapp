"use client";

// components/bills/InboxSheet.js — BILLS & INVOICES, BESIDE THE CHAT
// ==============================================================================
// Founder, 8 Nov 2026: work the close list the way other software does, in the chat.
// "Open Bills & invoices" and "Upload in Bills & invoices" sent the person to Scheduled's
// sheet, and from there each bill to its own page. A bill tool's inbox is one place: the
// drop zone, the list with its filters and bulk approve, and a bill's review in the same
// panel with Back to the list. That is BillsScreen.js, drawn here in a wide side sheet;
// the list is read when the sheet opens, and again after each change.

import { useCallback, useEffect, useState } from "react";
import { Sheet } from "@/components/ui/Sheet";
import { listInbox } from "@/lib/bills-client";
import BillsScreen from "./BillsScreen";

/** Whether an address is the Bills & invoices inbox (Scheduled's sheet or /bills). Pure. */
export function opensInbox(href) {
  if (typeof href !== "string") return false;
  return /^\/scheduled\?(?:[^#]*&)?task=bills(?:[&#]|$)/.test(href) || /^\/bills\/?(?:[?#].*)?$/.test(href);
}

export default function InboxSheet({ onClose, openId = null }) {
  const [read, setRead] = useState(null);
  const load = useCallback(async () => {
    const got = await listInbox({});
    setRead(got);
  }, []);
  useEffect(() => {
    load();
  }, [load]);
  return (
    <Sheet open side="right" title="Bills & invoices" onClose={onClose} className="bill-sheet">
      {read ? (
        <BillsScreen key={read.ok ? "read" : "unread"} initial={read} openId={openId} embedded onReread={load} />
      ) : (
        <p className="ink-2" role="status">
          Reading the inbox…
        </p>
      )}
    </Sheet>
  );
}
