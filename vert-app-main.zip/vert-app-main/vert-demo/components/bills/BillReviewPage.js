"use client";

// components/bills/BillReviewPage.js — ONE ITEM'S REVIEW, ON ITS OWN PAGE (/bills/<id>)
// ==============================================================================
// The Scheduled section's Bills & invoices sheet lists what is waiting, and each row's
// Review opens this page (scheduled-spec.md). The review itself is BillReview, unchanged:
// approving still only happens on the person's press. Back is the sheet.

import { useRouter } from "next/navigation";
import { useState } from "react";

import { Notice } from "@/components/ui";

import BillReview from "./BillReview";

export const BACK_HREF = "/scheduled?task=bills";

export default function BillReviewPage({ item: initial = null, xero = null, failure = null }) {
  const router = useRouter();
  const [item, setItem] = useState(initial);
  const [outcome, setOutcome] = useState(null);
  if (!item) {
    return (
      <div className="bills" data-bills-unread={(failure && failure.kind) || "refused"}>
        <Notice kind="error" recorded="unknown" details={failure && failure.code ? `Code: ${failure.code}` : null}>
          {(failure && failure.message) || "Vert couldn't open that bill just now."}
        </Notice>
        <p>
          <a className="link" href={BACK_HREF}>
            Bills &amp; invoices
          </a>
        </p>
      </div>
    );
  }
  return (
    <div className="bills" data-bills="">
      <BillReview
        key={item.id}
        item={item}
        xero={xero}
        outcome={outcome}
        onItem={(next, view = null) => {
          if (next) setItem(next);
          if (view) setOutcome(view);
        }}
        onBack={() => router.push(BACK_HREF)}
      />
    </div>
  );
}
