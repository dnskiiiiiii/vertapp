"use client";

// components/bills/UploadZone.js — DROP BILLS, INVOICES, SPREADSHEETS OR A FORWARDED EMAIL
// ==============================================================================
// One drop target and one file picker, several files at once: PDF, PNG, JPEG, TIFF, CSV,
// XLSX, and a forwarded email saved as .eml (which the app sends to the engine's email
// route). The files go to this app's /api/bills route (lib/bills-client.js upload), a
// route rather than a Server Action because a scanned bill is over 1 MB.
//
// The drop target is the Vert green tint while a file is dragged over it, and only then
// (design-calm-neutral §2: the tint means "a file drop target while dragging", nothing
// else). Adding files never approves anything: each new item waits in the list.

import { useId, useRef, useState } from "react";

import { Button, Notice, Segmented } from "@/components/ui";
import { IconUpload } from "@/components/ui/icons";
import * as api from "@/lib/bills-client";
import { KINDS, UPLOAD_ACCEPT, readWords, refusedLine, uploadPlanOf } from "@/lib/bills-model";

// `compact`: the Scheduled section's Bills & invoices sheet (scheduled-spec.md: "Drop
// bills here"). The same drop target and picker, in that section's short words.
export default function UploadZone({ onUploaded, compact = false }) {
  const inputId = useId();
  const input = useRef(null);
  const [kind, setKind] = useState("bill");
  const [over, setOver] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);

  async function send(fileList) {
    const files = Array.from(fileList || []);
    if (!files.length || busy) return;
    const plan = uploadPlanOf(files);
    if (!plan.documents.length && !plan.emails.length) {
      setResult({ ok: true, items: [], refused: plan.refused, emails: [] });
      return;
    }
    setBusy(true);
    setResult(null);
    const answer = await api.upload([...plan.documents, ...plan.emails], { kind });
    setBusy(false);
    if (input.current) input.current.value = "";
    if (!answer.ok) {
      setResult({ ok: false, message: answer.message, kind: answer.kind, refused: plan.refused });
      return;
    }
    setResult({ ok: true, items: answer.items || [], refused: [...plan.refused, ...(answer.refused || [])], emails: answer.emails || [] });
    if (answer.items && answer.items.length && onUploaded) onUploaded(answer.items);
  }

  return (
    <section className="bills-upload" aria-label="Add bills and invoices">
      <div
        className="bills-drop"
        data-over={over ? "true" : undefined}
        aria-busy={busy ? "true" : undefined}
        onDragOver={(event) => {
          event.preventDefault();
          if (!over) setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(event) => {
          event.preventDefault();
          setOver(false);
          send(event.dataTransfer && event.dataTransfer.files);
        }}
      >
        <IconUpload className="bills-drop-icon" size={20} />
        <p className="bills-drop-words">
          {busy ? "Reading…" : compact ? "Drop bills here" : "Drop bills, invoices, spreadsheets or a forwarded email here"}
        </p>
        {compact ? null : <p className="bills-drop-hint">PDF, PNG, JPEG, TIFF, CSV, XLSX or .eml, up to 25 MB each</p>}
        <input
          ref={input}
          id={inputId}
          className="sr-only"
          type="file"
          name="files"
          multiple
          accept={UPLOAD_ACCEPT}
          onChange={(event) => send(event.target.files)}
          disabled={busy}
        />
        <Button variant="secondary" size="sm" onClick={() => input.current && input.current.click()} busy={busy} busyLabel="Reading…">
          {compact ? "Choose files" : "Choose files…"}
        </Button>
      </div>
      <div className="bills-kind">
        <span className="bills-kind-label" id={`${inputId}-kind`}>
          These are
        </span>
        <Segmented options={KINDS} value={kind} onChange={setKind} label="These are" size="sm" />
      </div>
      {result && compact ? <CompactResult result={result} onDismiss={() => setResult(null)} /> : result ? <UploadResult result={result} onDismiss={() => setResult(null)} /> : null}
    </section>
  );
}

// The compact result: a count, or the refusal's short words; each refused file by name,
// with the reason it was refused (walk 4, W4-6: a HEIC said only "Not read").
export function CompactResult({ result, onDismiss }) {
  const refused = result.refused || [];
  return (
    <div className="bills-upload-result" role={result.ok ? "status" : "alert"} data-bills-upload-result="">
      <p className="bills-upload-words">{result.ok ? (result.items.length ? readWords(result.items.length) : "Nothing read") : "Not read"}</p>
      {/* Every file refused (a 422): the engine's reason, not "Not read" alone (W4-6). */}
      {!result.ok && result.message && !refused.length ? <p className="bills-problem">{result.message}</p> : null}
      {refused.length ? (
        <ul className="bills-refused">
          {refused.map((r, i) => (
            <li key={`${r.filename}-${i}`} className="bills-problem">
              {refusedLine(r)}
            </li>
          ))}
        </ul>
      ) : null}
      <Button variant="quiet" size="sm" onClick={onDismiss}>
        Dismiss
      </Button>
    </div>
  );
}

function UploadResult({ result, onDismiss }) {
  const refused = result.refused || [];
  if (!result.ok) {
    return (
      <Notice kind="error" recorded={result.kind === "unreachable" ? "unconfirmed" : "nothing"} onDismiss={onDismiss}>
        {result.message}
      </Notice>
    );
  }
  return (
    <div className="bills-upload-result" role="status" data-bills-upload-result="">
      <p className="bills-upload-words">
        {result.items.length ? `${readWords(result.items.length)}. Each one waits below for you to check and approve.` : "Nothing was read."}
      </p>
      {result.emails.map((email) => (
        <p className="bills-upload-email" key={email.filename}>
          From {email.from || "an unknown sender"}
          {email.subject ? <>: &ldquo;{email.subject}&rdquo;</> : null}, {email.attachments.length} {email.attachments.length === 1 ? "attachment" : "attachments"}
          {email.attachments.length ? ` (${email.attachments.map((a) => a.filename).join(", ")})` : ""}.
        </p>
      ))}
      {refused.length ? (
        <ul className="bills-refused">
          {refused.map((r, i) => (
            <li key={`${r.filename}-${i}`} className="bills-problem">
              {r.message}
            </li>
          ))}
        </ul>
      ) : null}
      <Button variant="quiet" size="sm" onClick={onDismiss}>
        Dismiss
      </Button>
    </div>
  );
}
