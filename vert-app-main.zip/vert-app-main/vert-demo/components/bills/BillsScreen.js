"use client";

// components/bills/BillsScreen.js — THE BILLS INBOX
// ==============================================================================
//   Bills & invoices
//   Drop bills here…                         Xero: connected for reading only. …
//   [ Drop files, or choose… ]   These are: (Bills to pay | Invoices to send)
//   All  Ready to approve 3  Needs review 1  Duplicate in Xero 1  …
//   [ ] Acme Pty Ltd  INV-1043   Bill   12 Oct 2026   $1,100.00   ● Ready to approve
//   [Approve & send selected (2)]
//
// A row opens its review (BillReview.js) in place of the list; "All bills" comes back.
// The list's words come from lib/bills-model.js, and every call goes through this app's
// routes (lib/bills-client.js), never the engine.
//
// NEVER AUTO-APPROVED. Nothing here approves on arrival, on upload or on a timer. The
// bulk commit asks once more ("Send 3 bills to Xero as drafts?", or "… as awaiting
// payment?" when the client's documents go in approved) before it sends, and only the
// rows the person ticked, and only those the model says may be approved now, are sent.

import { useEffect, useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";

import { Button, Notice, NoticeLine } from "@/components/ui";
import { formatDate } from "@/lib/format";
import * as api from "@/lib/bills-client";
import {
  CHECK_XERO_IN_REVIEW_WORDS,
  CONFIRM_IN_REVIEW_WORDS,
  bulkConfirmOf,
  bulkLabel,
  bulkOf,
  duplicateMarkOf,
  filterItems,
  filtersOf,
  isItemId,
  kindWords,
  leadWords,
  moneyText,
  noLedgerWord,
  outcomeView,
  statusWords,
  xeroView,
} from "@/lib/bills-model";

import BillReview from "./BillReview";
import BillStatus from "./BillStatus";
import UploadZone from "./UploadZone";

function dateText(value) {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value) ? formatDate(value) : null;
}

/** The Xero connection line, from the list response. */
export function XeroLine({ xero }) {
  const view = xeroView(xero);
  return (
    <div className="bills-xero" data-xero-state={view.state} role="status">
      <p className="bills-xero-words">{view.words}</p>
      {view.explain ? <p className="bills-xero-explain">{view.explain}</p> : null}
      {view.state === "disconnected" || view.state === "read-only" ? (
        <a className="link bills-xero-link" href="/connections">
          Open Connections
        </a>
      ) : null}
    </div>
  );
}

function replaceItem(list, item) {
  if (!item || !isItemId(item.id)) return list;
  const at = list.findIndex((x) => x.id === item.id);
  if (at === -1) return [item, ...list];
  const next = list.slice();
  next[at] = item;
  return next;
}

/**
 * `embedded`: drawn in the chat's Bills & invoices sheet (InboxSheet.js, founder, 8 Nov
 * 2026), not as a page: the address isn't rewritten, a re-read is `onReread` rather
 * than a page refresh, and the sheet's own title stands for the page heading.
 */
export default function BillsScreen({ initial, openId = null, embedded = false, onReread = null }) {
  const read = Boolean(initial && initial.ok);
  const router = useRouter();
  const [rereading, startReread] = useTransition();
  const reread = () => startReread(() => (embedded && onReread ? onReread() : router.refresh()));
  const [items, setItems] = useState(read ? initial.items : []);
  const [counts, setCounts] = useState(read ? initial.counts : null);
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState(() => new Set());
  const [open, setOpen] = useState(openId);
  const [confirming, setConfirming] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [bulkResult, setBulkResult] = useState(null);
  const [outcomes, setOutcomes] = useState({});
  const xero = read ? initial.xero : null;

  // The address names the open item, so a review can be linked and reloaded.
  useEffect(() => {
    if (typeof window === "undefined" || embedded) return;
    const url = new URL(window.location.href);
    if (open) url.searchParams.set("item", open);
    else url.searchParams.delete("item");
    window.history.replaceState(window.history.state, "", url);
  }, [open, embedded]);

  const listedCount = Array.isArray(items) ? items.length : null;
  const filters = useMemo(() => filtersOf(counts, xero, listedCount), [counts, xero, listedCount]);
  const shown = filterItems(items, filter);
  const bulk = bulkOf(items, selected);

  // A count is the engine's; after a change on this page it is re-read, not adjusted.
  async function refreshList() {
    const answer = await api.listInbox();
    if (answer.ok) {
      setItems(answer.items);
      setCounts(answer.counts);
    }
  }

  function onItem(item, outcome = null) {
    setItems((list) => replaceItem(list, item));
    if (outcome) setOutcomes((all) => ({ ...all, [item.id]: outcome }));
    refreshList();
  }

  function onUploaded(newItems) {
    setItems((list) => {
      let next = list;
      for (const item of [...newItems].reverse()) next = replaceItem(next, item);
      return next;
    });
    refreshList();
  }

  function toggle(id) {
    setBulkResult(null);
    setConfirming(false);
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function toggleAllShown() {
    setBulkResult(null);
    setConfirming(false);
    const ids = shown.map((i) => i.id);
    const all = ids.length > 0 && ids.every((id) => selected.has(id));
    setSelected((s) => {
      const next = new Set(s);
      for (const id of ids) {
        if (all) next.delete(id);
        else next.add(id);
      }
      return next;
    });
  }

  async function approveSelected() {
    if (!bulk.ready.length) return;
    setBulkBusy(true);
    const answer = await api.approveMany(bulk.ready);
    setBulkBusy(false);
    setConfirming(false);
    if (!answer.ok) {
      setBulkResult({ ok: false, message: answer.message, kind: answer.kind });
      return;
    }
    const lines = [];
    let list = items;
    const nextOutcomes = {};
    for (const r of answer.results) {
      if (r.item) list = replaceItem(list, r.item);
      const view = r.ok ? outcomeView(r.outcome, r.item) : null;
      if (view) nextOutcomes[r.itemId] = view;
      const name = (r.item && r.item.document && r.item.document.contactName) || (items.find((i) => i.id === r.itemId) || {}).filename || "A bill";
      const before = items.find((i) => i.id === r.itemId);
      const needsConfirm = (r.item && r.item.needsConfirm) || (before && before.needsConfirm) || /confirm_duplicate/.test(String(r.code || r.reason || ""));
      const checkXero = (before && before.status === "unconfirmed") || /check_ledger|check_candidates/.test(String(r.code || r.reason || ""));
      const words = view ? view.words : checkXero ? CHECK_XERO_IN_REVIEW_WORDS : needsConfirm ? CONFIRM_IN_REVIEW_WORDS : noLedgerWord(r.message) || "Not approved.";
      lines.push({ id: r.itemId, name, ok: r.ok, words, url: view ? view.url : null });
    }
    setItems(list);
    setOutcomes((all) => ({ ...all, ...nextOutcomes }));
    setSelected(new Set());
    setBulkResult({ ok: true, lines });
    refreshList();
  }

  // A link to one item (the chat's `/bills?item=<id>`) that the list didn't carry is read
  // on its own, so the review opens rather than a "not in this list" line.
  const [looked, setLooked] = useState(false);
  useEffect(() => {
    if (!read || !open || looked || items.some((i) => i.id === open)) return;
    setLooked(true);
    api.readItem(open).then((answer) => {
      if (answer.ok && answer.item) setItems((list) => replaceItem(list, answer.item));
    });
  }, [read, open, looked, items]);

  const current = open ? items.find((i) => i.id === open) || null : null;

  return (
    <div className={embedded ? "bills bills-embedded" : "bills"} data-bills="">
      <header className="bills-head">
        {embedded ? null : <h1 className="t-title-1 bills-title">Bills &amp; invoices</h1>}
        <p className="bills-lead">
          {leadWords(xero)}
        </p>
        {read ? <XeroLine xero={xero} /> : null}
      </header>

      {!read ? (
        <div className="bills-unread" data-bills-unread={initial ? initial.kind || "refused" : "refused"}>
          <Notice kind="error" recorded="unknown" details={initial && initial.code ? `Code: ${initial.code}` : null}>
            {(initial && initial.message) || "Vert couldn't list its bills just now."} This isn&rsquo;t an empty inbox: the list wasn&rsquo;t read.
          </Notice>
          {/* A failed read is never a dead end (lead L1-1): read again here, and uploading
              never needed the list, so the upload box stays. The sample books, with no
              service behind them ("unavailable"), have nothing to retry or upload to. */}
          {initial && initial.kind === "unavailable" ? null : (
            <>
              <p className="bills-retry">
                <Button variant="secondary" size="sm" busy={rereading} busyLabel="Reading…" onClick={reread} data-bills-retry="">
                  Retry
                </Button>
              </p>
              <UploadZone onUploaded={reread} />
            </>
          )}
        </div>
      ) : open && current ? (
        <BillReview key={current.id} item={current} xero={xero} outcome={outcomes[current.id] || null} onItem={onItem} onBack={() => setOpen(null)} />
      ) : (
        <>
          {open && !current && looked ? (
            <NoticeLine tone="info" actionLabel="Show all" onAction={() => setOpen(null)}>
              That bill isn&rsquo;t in this list. It may belong to another client.
            </NoticeLine>
          ) : null}
          <UploadZone onUploaded={onUploaded} />

          {initial.unreadable > 0 ? (
            <p className="bills-note" role="status">
              {initial.unreadable} {initial.unreadable === 1 ? "item" : "items"} Vert sent couldn&rsquo;t be read, so {initial.unreadable === 1 ? "it isn't" : "they aren't"} listed.
            </p>
          ) : null}

          <div className="bills-bar">
            <div className="bills-filter" role="group" aria-label="Show">
              {/* A status that holds nothing has no chip, unless it is the one shown. */}
              {filters.filter((f) => f.id === "all" || f.count !== 0 || f.id === filter).map((f) => (
                <button key={f.id} type="button" className="chip" data-filter={f.id} aria-pressed={filter === f.id ? "true" : "false"} onClick={() => setFilter(f.id)}>
                  {f.words}
                  {f.count !== null ? <span className="bills-count num"> {f.count}</span> : null}
                </button>
              ))}
            </div>
          </div>

          {items.length === 0 ? (
            <p className="bills-empty" data-bills-empty="">
              No bills or invoices yet. Add one above, or forward a supplier&rsquo;s email as an .eml file.
            </p>
          ) : shown.length === 0 ? (
            <p className="bills-empty">
              None of the {items.length} {items.length === 1 ? "item is" : "items are"} marked &ldquo;{statusWords({ status: filter })}&rdquo;.{" "}
              <button type="button" className="link" onClick={() => setFilter("all")}>
                Show all
              </button>
            </p>
          ) : (
            <BillsList items={shown} selected={selected} onToggle={toggle} onToggleAll={toggleAllShown} onOpen={setOpen} outcomes={outcomes} />
          )}

          {selected.size > 0 ? (
            <div className="bills-bulk" data-bills-bulk="">
              <p className="bills-bulk-words">
                {selected.size} selected
                {bulk.held.length - bulk.confirm.length - bulk.checkXero.length > 0 ? `. ${bulk.held.length - bulk.confirm.length - bulk.checkXero.length} of them can't be approved yet and will be left as they are.` : "."}
              </p>
              {bulk.checkXero.length ? (
                <p className="bills-bulk-words" data-bulk-check-xero="">
                  {bulk.checkXero.length === 1 ? "1 may already have reached Xero and is left out. " : `${bulk.checkXero.length} may already have reached Xero and are left out. `}
                  {CHECK_XERO_IN_REVIEW_WORDS}.
                </p>
              ) : null}
              {bulk.confirm.length ? (
                <p className="bills-bulk-words" data-bulk-confirm="">
                  {bulk.confirm.length === 1 ? "1 may be a duplicate and is left out. " : `${bulk.confirm.length} may be duplicates and are left out. `}
                  {CONFIRM_IN_REVIEW_WORDS}.
                </p>
              ) : null}
              {confirming ? (
                <div className="bills-bulk-confirm">
                  <p className="bills-bulk-question">
                    {bulkConfirmOf(xero, bulk.ready.length).question}
                  </p>
                  <Button variant="quiet" onClick={() => setConfirming(false)}>
                    Cancel
                  </Button>
                  <Button variant="commit" onClick={approveSelected} busy={bulkBusy} busyLabel="Approving…">
                    {bulkConfirmOf(xero, bulk.ready.length).button}
                  </Button>
                </div>
              ) : (
                <Button
                  variant="commit"
                  onClick={() => setConfirming(true)}
                  disabledReason={bulk.ready.length ? null : "None of those selected can be approved yet. Open each to see why."}
                >
                  {bulkLabel(xero, bulk.ready.length)}
                </Button>
              )}
            </div>
          ) : null}

          {bulkResult ? <BulkResult result={bulkResult} onDismiss={() => setBulkResult(null)} /> : null}
        </>
      )}
    </div>
  );
}

function BulkResult({ result, onDismiss }) {
  if (!result.ok) {
    return (
      <Notice kind="error" recorded={result.kind === "unreachable" || result.kind === "unconfirmed" ? "unconfirmed" : "nothing"} onDismiss={onDismiss}>
        {result.message}
      </Notice>
    );
  }
  return (
    <div className="bills-bulk-result" role="status" data-bills-bulk-result="">
      <ul className="bills-result-list">
        {result.lines.map((line) => (
          <li key={line.id} data-ok={line.ok ? "true" : "false"}>
            <span className="bills-result-name" translate="no">
              {line.name}
            </span>
            <span className={line.ok ? "bills-result-words" : "bills-result-words bills-problem"}>{line.words}</span>
            {line.url ? (
              <a className="link" href={line.url} target="_blank" rel="noreferrer">
                Open in Xero
              </a>
            ) : null}
          </li>
        ))}
      </ul>
      <Button variant="quiet" size="sm" onClick={onDismiss}>
        Dismiss
      </Button>
    </div>
  );
}

function BillsList({ items, selected, onToggle, onToggleAll, onOpen, outcomes }) {
  const all = items.length > 0 && items.every((i) => selected.has(i.id));
  return (
    <div className="table-scroll bills-table">
      <table className={["table", items.length >= 5 ? "table-ruled" : null].filter(Boolean).join(" ")}>
        <caption className="sr-only">Bills and invoices</caption>
        <thead>
          <tr>
            <th scope="col" className="bills-check-col">
              <label className="cbx-hit">
                <input type="checkbox" className="cbx" aria-label="Select every item shown" checked={all} onChange={onToggleAll} />
              </label>
            </th>
            <th scope="col">Contact</th>
            <th scope="col">Number</th>
            <th scope="col">Kind</th>
            <th scope="col">Issued</th>
            <th scope="col" className="num-col">
              Total
            </th>
            <th scope="col">Status</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => {
            const doc = item.document || {};
            const name = (typeof doc.contactName === "string" && doc.contactName.trim()) || item.filename || "Unnamed document";
            const issued = dateText(doc.issueDate);
            const outcome = outcomes[item.id];
            return (
              <tr key={item.id} className="row" aria-selected={selected.has(item.id) ? "true" : undefined} data-status={item.status}>
                <td className="bills-check-col" data-label="Select">
                  <label className="cbx-hit">
                    <input type="checkbox" className="cbx" aria-label={`Select ${name}`} checked={selected.has(item.id)} onChange={() => onToggle(item.id)} />
                  </label>
                </td>
                <td data-label="Contact">
                  <button type="button" className="link bills-open" onClick={() => onOpen(item.id)} translate="no">
                    {name}
                  </button>
                  {item.filename && item.filename !== name ? (
                    <span className="bills-file" translate="no">
                      {item.filename}
                    </span>
                  ) : null}
                </td>
                <td data-label="Number" translate="no">
                  {doc.invoiceNumber || <span className="ink-2">Not read</span>}
                </td>
                <td data-label="Kind">{kindWords(item.kind)}</td>
                <td data-label="Issued">{issued || <span className="ink-2">Not read</span>}</td>
                <td data-label="Total" className="num-col num" translate="no">
                  {moneyText(doc.totalCents)}
                  {Number.isInteger(doc.totalCents) && doc.currency ? <span className="bills-currency"> {doc.currency}</span> : null}
                </td>
                <td data-label="Status">
                  <BillStatus item={item} />
                  {duplicateMarkOf(item) ? (
                    <span className="bills-dup-mark" data-duplicate-mark={item.id}>
                      {duplicateMarkOf(item)}
                    </span>
                  ) : null}
                  {outcome && outcome.url ? (
                    <a className="link bills-xero-open" href={outcome.url} target="_blank" rel="noreferrer">
                      Open in Xero
                    </a>
                  ) : null}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
