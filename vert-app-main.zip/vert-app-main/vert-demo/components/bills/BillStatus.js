// components/bills/BillStatus.js — AN INBOX ITEM'S STATUS: A GLYPH AND ITS WORDS
// ==============================================================================
// The kit's StatusMark holds the four task words only (lib/status.js), and an inbox
// item's states are not tasks' states, so this draws the same mark (a glyph and a
// caption-500 word in the status's ink, no fill, no border) with the words from
// lib/bills-model.js. The words always carry the state; the ink only repeats it.

import { IconProblem, IconStatusAttention, IconStatusDone, IconStatusWaiting } from "@/components/ui/icons";
import { statusTone, statusWords } from "@/lib/bills-model";
import { useSignedInActor } from "@/lib/store";

const MARKS = {
  attention: { className: "status-attention", Glyph: IconStatusAttention },
  neutral: { className: "status-neutral", Glyph: IconStatusWaiting },
  done: { className: "status-done", Glyph: IconStatusDone },
  problem: { className: "bills-status-problem", Glyph: IconProblem },
  unknown: { className: "status-neutral", Glyph: IconStatusWaiting },
};

export default function BillStatus({ item }) {
  const tone = statusTone(item && item.status);
  const signedIn = useSignedInActor();
  const { className, Glyph } = MARKS[tone] || MARKS.unknown;
  return (
    <span className={`status-mark bills-status ${className}`} data-bill-status={(item && item.status) || "unknown"}>
      <span className="status-glyph" aria-hidden="true">
        <Glyph size="100%" />
      </span>
      <span className="status-word">{statusWords(item, { signedIn })}</span>
    </span>
  );
}
