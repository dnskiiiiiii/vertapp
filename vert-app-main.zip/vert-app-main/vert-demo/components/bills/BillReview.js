"use client";

// components/bills/BillReview.js — ONE BILL: THE DOCUMENT BESIDE WHAT VERT READ FROM IT
// ==============================================================================
//   ‹ All bills
//   Acme Pty Ltd                        ● Ready to approve · Bill · Uploaded
//   [ the PDF, as stored ]   | Contact: Matched to Acme Pty Ltd in Xero by ABN.
//                            | ABN, email, number, dates, currency, amounts are
//                            | Line 1: description, qty, unit, tax, amount, account, tax type
//                            |   Other suggestions: [6100 Office expenses]
//                            | Subtotal · Tax · Total (Vert's reading)
//                            | [Save changes]  [Approve and send to Xero as a draft]
//                              (or "… as awaiting payment" when the client's documents go
//                              in approved: the ledger's `documentMode`, 4 Nov 2026)
//
// EVERY FLAG SITS BESIDE ITS FIELD, in words, led by "Must fix" (a block) or "Check" (a
// review); flags about no one field are listed above the fields. A low or medium
// confidence reading is marked quietly beside its label.
//
// APPROVAL IS THE PERSON'S PRESS AND NOTHING ELSE. Approve is offered only when
// lib/bills-model.js approvalOf says so (the engine's canApprove, no blocking flag, not a
// duplicate, no unsaved edits); otherwise its reason is printed beside it. The engine
// checks again, and its refusal is shown in its own words.
//
// The item shown is this component's own copy, replaced only by the answers to its own
// presses, so a list refresh behind it never throws away what the person is typing.
//
// A SALES INVOICE IS CALLED AN INVOICE (UI walk D6, 30 Oct 2026). Every sentence drawn
// here, this page's and the engine's, goes through `say` (lib/bills-model.js wordedFor
// over the item's kind), and the flags are worded before they are placed.

import { useEffect, useMemo, useRef, useState } from "react";

import { Button, DateField, Notice, RememberTick, RuleSaved } from "@/components/ui";
import { IconBack, IconBlocked, IconExternal, IconWarning } from "@/components/ui/icons";
import { actorWords, actorsInWords, formatDate } from "@/lib/format";
import { useSignedInActor } from "@/lib/store";
import * as api from "@/lib/bills-client";
import { readChartOnce } from "@/components/cards/chart-read";
import { useWritesEnabled } from "@/lib/engine-context";
import {
  AMOUNTS_ARE,
  LINE_CELLS,
  UNCONFIRMED_WORDS,
  candidatesOf,
  retryStepOf,
  TOTALS,
  contactFlagsOf,
  flagsBeyond,
  methodNoteOf,
  pushNotesOf,
  NEW_CONTACT_WORDS,
  approvalOf,
  approveLabel,
  confidenceWords,
  contactView,
  draftOf,
  keepEditsSince,
  editedLineCells,
  pendingOnEdit,
  duplicateView,
  emptyLine,
  fieldConfidence,
  flagLead,
  flagsByField,
  flagsFor,
  isDirty,
  itemNoun,
  kindWords,
  lineAccountChoices,
  lineFlags,
  lineTaxChoices,
  moneyText,
  noLedgerWord,
  noticeText,
  confirmStepOf,
  sameFileOf,
  outcomeView,
  paidByOf,
  patchOf,
  settledOutcome,
  sourceView,
  statusWords,
  supplierOf,
  unplacedFlags,
  wordedFor,
} from "@/lib/bills-model";

import BillStatus from "./BillStatus";

// Only when the outcome carried no words at all; outcomeView words a send from what Xero
// returned (lib/bills-model.js), so a bill Xero holds approved never reads as a draft.
const OUTCOME_WORDS = {
  sent: "Sent to Xero",
  approved: "Approved: enter these in Xero",
  already_in_xero: "Sent to Xero (Vert found the earlier send and kept it)",
  unconfirmed: UNCONFIRMED_WORDS,
};
// A failure that may have reached Xero is said as not known, never as nothing recorded.
const recordedOf = (answer) => (answer.kind === "unreachable" || answer.kind === "unconfirmed" ? "unconfirmed" : "nothing");
const SOURCE_WORDS = { upload: "Uploaded", "email-forward": "Forwarded email", csv: "From a spreadsheet" };

function dayOf(value) {
  try {
    return typeof value === "string" && value ? formatDate(value) : null;
  } catch {
    return null;
  }
}

/** A flag, in words, beside the field it is about. */
function FlagLine({ flag }) {
  const block = flag.severity === "block";
  const pending = flag.severity === "pending";
  const Glyph = block ? IconBlocked : IconWarning;
  return (
    <p className={block ? "bill-flag bill-flag-block" : pending ? "bill-flag bill-flag-pending" : "bill-flag bill-flag-review"} data-flag={flag.code || ""} data-severity={block ? "block" : pending ? "pending" : "review"}>
      <Glyph size={14} />
      <span>
        <span className="bill-flag-lead">{flagLead(flag)}:</span> {noLedgerWord(flag.words) || "Vert flagged this field."}
      </span>
    </p>
  );
}

function Flags({ flags }) {
  if (!flags || !flags.length) return null;
  return (
    <div className="bill-flags">
      {flags.map((flag, i) => (
        <FlagLine key={`${flag.code || "flag"}-${i}`} flag={flag} />
      ))}
    </div>
  );
}

function Confidence({ words }) {
  return words ? <span className="bill-confidence">{words}</span> : null;
}

/** A labelled input with its confidence marker, its flags and its error, in the kit's field frame. */
function BillField({ id, label, value, onChange, flags = [], confidence = null, error = null, children, className, ...input }) {
  const errorId = error ? `${id}-error` : undefined;
  const flagged = flags.length > 0;
  return (
    <div className={["form-field", "bill-field", error ? "field-invalid" : null, flagged ? "bill-field-flagged" : null, className].filter(Boolean).join(" ")} data-field={id}>
      <div className="bill-field-label">
        <label className="field-label" htmlFor={id}>
          {label}
        </label>
        <Confidence words={confidence} />
      </div>
      <div className="field-box">
        {children || (
          <input
            id={id}
            name={id}
            className="field-input"
            autoComplete="off"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            aria-invalid={error || flags.some((f) => f.severity === "block") ? "true" : undefined}
            aria-describedby={errorId}
            {...input}
          />
        )}
      </div>
      {error ? (
        <p className="field-error" id={errorId} role="alert">
          {error}
        </p>
      ) : null}
      <Flags flags={flags} />
    </div>
  );
}

/**
 * A date on the document, in the house format ("Sun 28 Sep 2026", UI walk 2, N8: the
 * fields showed "2026-09-28"), picked from the app's month grid (components/ui DateField)
 * rather than typed as ISO. The value stays the ISO day the engine reads and takes.
 */
function BillDateField({ id, label, value, onChange, flags = [], confidence = null, error = null }) {
  return (
    <div className={["bill-field", flags.length ? "bill-field-flagged" : null].filter(Boolean).join(" ")} data-field={id}>
      <DateField id={id} name={id} label={label} aside={<Confidence words={confidence} />} value={value} onChange={onChange} error={error} />
      <Flags flags={flags} />
    </div>
  );
}

function SourcePane({ item }) {
  const view = sourceView(item);
  const name = item.filename || "The document";
  return (
    <section className="bill-source" aria-label="The document">
      {view.kind === "frame" ? (
        <iframe className="bill-source-frame" src={view.href} title={name} />
      ) : (
        <div className="bill-source-none">
          <p>{view.words}</p>
          {item.sourceRef && view.kind !== "typed" ? (
            <p className="ink-2" translate="no">
              {item.sourceRef}
            </p>
          ) : null}
        </div>
      )}
      {view.href && view.kind === "typed" ? (
        <a className="link bill-source-open" href={view.href} data-source-chat="">
          Open the conversation
        </a>
      ) : view.href ? (
        <a className="link bill-source-open" href={view.href} target="_blank" rel="noreferrer" translate="no">
          Open {name}
          <IconExternal size={12} />
        </a>
      ) : null}
    </section>
  );
}

function OutcomePanel({ outcome, notes = [], say, statusSaid = null }) {
  if (!outcome) return null;
  const words = noLedgerWord(outcome.words) || OUTCOME_WORDS[outcome.status] || "Vert didn't say what the approval did. Reload to see.";
  // Said once (walk 3 copy list): the status beside the title already says "Sent to Xero
  // as a draft", so the panel doesn't say it again.
  const repeats = typeof statusSaid === "string" && words.replace(/\.$/, "") === statusSaid.replace(/\.$/, "");
  return (
    <section className="bill-outcome" data-outcome={outcome.status} role="status" aria-label="What approving did">
      {repeats ? null : <p className="bill-outcome-words">{say(words)}</p>}
      {outcome.url ? (
        <a className="link" href={outcome.url} target="_blank" rel="noreferrer">
          Open in Xero
          <IconExternal size={12} />
        </a>
      ) : null}
      {outcome.status === "unconfirmed" ? (
        <p className="bill-outcome-note ink-2">{say("Approving again looks in Xero first and keeps the bill it finds there, so it won\u2019t make a second one.")}</p>
      ) : null}
      {notes.map((note) => (
        <p className="bill-outcome-note ink-2" key={note}>
          {say(note)}
        </p>
      ))}
      {outcome.fields.length ? (
        <dl className="bill-manual">
          {outcome.fields.map((f, i) => (
            <div className="bill-manual-row" key={`${f.label}-${i}`}>
              <dt>{f.label}</dt>
              {/* A day is said as the house says one ("28 Sep 2026"), which Xero's own date
                  fields take as typed (UI walk 2, D14d). */}
              <dd translate="no">{(typeof f.value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(f.value) && dayOf(f.value)) || f.value || <span className="ink-2">Leave blank</span>}</dd>
            </div>
          ))}
        </dl>
      ) : outcome.status === "approved" ? (
        <p className="ink-2">Vert didn&rsquo;t send the fields to enter. Open the document and enter it from there.</p>
      ) : null}
      {/* Remember was ticked and the engine saved the supplier's rule: the grid's words. */}
      {outcome.remembered ? (
        <p className="bill-outcome-note ink-2">
          <RuleSaved remembered={outcome.remembered} />
        </p>
      ) : null}
    </section>
  );
}

/** Bills in Xero a retry found that might be this one, each with its link when it is Xero's. */
function Candidates({ item, say }) {
  const list = candidatesOf(item);
  if (!list.length) return null;
  return (
    <ul className="bill-candidates" aria-label={say("Bills in Xero that might be this one")}>
      {list.map((c) => (
        <li key={c.id}>
          <span translate="no">{say(c.words)}</span>
          {c.url ? (
            <a className="link" href={c.url} target="_blank" rel="noreferrer">
              Open in Xero
              <IconExternal size={12} />
            </a>
          ) : null}
        </li>
      ))}
    </ul>
  );
}

function DuplicatePanel({ duplicate, say }) {
  const view = duplicateView(duplicate);
  if (!view) return null;
  return (
    <section className={view.blocking ? "bill-duplicate bill-duplicate-block" : "bill-duplicate"} data-duplicate={view.status} aria-label="Already in Xero?">
      <p className="bill-duplicate-words">
        {view.blocking ? <IconBlocked size={14} /> : <IconWarning size={14} />}
        <span>{say(view.words)}</span>
      </p>
      {view.url ? (
        <a className="link" href={view.url} target="_blank" rel="noreferrer">
          Open the one in Xero
          <IconExternal size={12} />
        </a>
      ) : null}
    </section>
  );
}

/**
 * "EMPLOYEE PAID": WHO TO PAY BACK (staging browser walk 3, W3-5). A staff member's café
 * receipt could be made payable to them only by retyping the café as the employee and
 * clearing the ABN. The picker searches Vert's stored copy of the Xero contacts
 * (`GET /api/bills/contacts?q=`); choosing one is the bill's `paidBy` (PATCH), and the
 * printed supplier is kept as the bill's reference by the engine. `initial` is a test's.
 */
export function PaidByPicker({ initial = null, onChoose, onCancel, busy = false }) {
  const [q, setQ] = useState("");
  const [got, setGot] = useState(initial);
  useEffect(() => {
    if (initial) return undefined;
    let live = true;
    const timer = setTimeout(
      () => {
        api.searchContacts(q).then((a) => {
          if (live) setGot(a && a.ok ? { ok: true, contacts: Array.isArray(a.contacts) ? a.contacts : [], asAt: a.asAt || null } : { ok: false, words: (a && a.message) || "Not read" });
        });
      },
      q ? 250 : 0
    );
    return () => {
      live = false;
      clearTimeout(timer);
    };
  }, [q, initial]);
  return (
    <div className="bill-paid-by-picker" data-paid-by-picker="">
      {/* Enter searches; it never submits the review's form (Save changes). */}
      <BillField id="paid-by-search" label="Search contacts" enterKeyHint="search" value={q} onChange={setQ} onKeyDown={(e) => e.key === "Enter" && e.preventDefault()} />
      {got === null ? (
        <p className="ink-2 bill-contact-detail" role="status">
          Searching…
        </p>
      ) : !got.ok ? (
        <p className="ink-2 bill-contact-detail" role="status">
          {got.words}
        </p>
      ) : !got.contacts.length ? (
        <p className="ink-2 bill-contact-detail">{got.asAt ? "No contacts found" : "Contacts not synced"}</p>
      ) : (
        <ul className="bill-paid-by-list">
          {got.contacts.map((c) => (
            <li key={c.contactId}>
              <button type="button" className="bill-contact-option bill-paid-by-choose" data-paid-by-choose={c.contactId} disabled={busy} onClick={() => onChoose && onChoose(c)}>
                <span translate="no">{c.name}</span>
                {c.isEmployee ? <span className="bill-confidence">Employee</span> : null}
              </button>
            </li>
          ))}
        </ul>
      )}
      <Button variant="quiet" size="sm" onClick={onCancel}>
        Cancel
      </Button>
    </div>
  );
}

/** Paid by an employee: who, the supplier kept, and Clear; or the press that asks who. */
function PaidBy({ item, settled, dirty, busy, onChoose, onClear }) {
  const [picking, setPicking] = useState(false);
  const paidBy = paidByOf(item);
  if (paidBy) {
    const supplier = supplierOf(item);
    return (
      <div className="bill-paid-by" data-paid-by={paidBy.contactId}>
        <p className="bill-contact-words">
          Paid by <span translate="no">{paidBy.name}</span>
        </p>
        {supplier ? (
          <p className="bill-contact-detail ink-2">
            Supplier <span translate="no">{supplier}</span>
          </p>
        ) : null}
        {settled ? null : (
          <Button variant="quiet" size="sm" onClick={onClear} busy={busy} busyLabel="Clearing…" disabledReason={dirty ? "Save or undo your changes first." : null} data-paid-by-clear="">
            Clear
          </Button>
        )}
      </div>
    );
  }
  if (settled) return null;
  if (picking) {
    return (
      <PaidByPicker
        busy={busy}
        onCancel={() => setPicking(false)}
        onChoose={async (c) => {
          const done = await onChoose(c);
          if (done) setPicking(false);
        }}
      />
    );
  }
  // ASKED FOR, SO DRAWN AS A BUTTON (founder's walk, 8 Nov 2026): the must-fix line said
  // "choose who paid it under Employee paid" over a quiet button that read as a label.
  const asked = Array.isArray(item.flags) && item.flags.some((f) => f && f.code === "contact_payer");
  return (
    <Button variant={asked ? "secondary" : "quiet"} size="sm" onClick={() => setPicking(true)} disabledReason={dirty ? "Save or undo your changes first." : null} data-paid-by-open="" data-paid-by-asked={asked ? "" : undefined}>
      Employee paid
    </Button>
  );
}

function ContactPanel({ item, draft, setDraft, error, flags, settled, say, paidBy = null }) {
  const view = contactView(item.contact);
  // Paid by an employee: the Xero contact is theirs, so the supplier's isn't chosen here.
  if (paidByOf(item)) {
    return (
      <fieldset className="bill-contact" data-contact="paid-by" disabled={settled}>
        <legend className="bill-section-head">Contact in Xero</legend>
        {paidBy}
      </fieldset>
    );
  }
  const matched = view.status === "matched" && view.contactId ? [{ contactId: view.contactId, name: (item.contact && item.contact.name) || "The matched contact", taxNumber: null, matched: true }] : [];
  const options = [...matched, ...view.candidates.filter((c) => !matched.some((m) => m.contactId === c.contactId))];
  const choose = (patch) => setDraft((d) => ({ ...d, ...patch }));
  return (
    <fieldset className="bill-contact" data-contact={view.status} disabled={settled}>
      <legend className="bill-section-head">Contact in Xero</legend>
      <p className="bill-contact-words">{say(view.words)}</p>
      {view.detail ? <p className="bill-contact-detail ink-2">{say(view.detail)}</p> : null}
      {view.status !== "unread" && options.length ? (
        <div className="bill-contact-options" role="radiogroup" aria-label="Which contact this belongs to">
          {options.map((c) => (
            <label className="bill-contact-option" key={c.contactId}>
              <input
                type="radio"
                name={`contact-${item.id}`}
                checked={draft.contactChoice === "existing" && draft.contactId === c.contactId}
                onChange={() => choose({ contactChoice: "existing", contactId: c.contactId })}
              />
              <span translate="no">{c.name}</span>
              {c.taxNumber ? <span className="ink-2 num"> ABN {c.taxNumber}</span> : null}
              {c.matched ? <span className="bill-confidence">Matched</span> : null}
            </label>
          ))}
          <label className="bill-contact-option">
            <input type="radio" name={`contact-${item.id}`} checked={draft.contactChoice === "new"} onChange={() => choose({ contactChoice: "new", contactId: "" })} />
            <span>Create a new contact</span>
          </label>
        </div>
      ) : null}
      {view.status !== "unread" && draft.contactChoice === "new" ? (
        <BillField
          id={`new-contact-${item.id}`}
          label="New contact's name"
          value={draft.newContactName}
          onChange={(v) => choose({ newContactName: v })}
          error={error}
        />
      ) : error ? (
        <p className="field-error" role="alert">
          {error}
        </p>
      ) : null}
      {draft.contactChoice === "new" && options.length ? <p className="ink-2 bill-contact-detail">{say(NEW_CONTACT_WORDS)}</p> : null}
      {/* A flag that only repeats the panel's own line is not said twice (N7). */}
      <Flags flags={flagsBeyond(flags, view.words, view.detail)} />
      {paidBy}
    </fieldset>
  );
}

function LineBlock({ index, line, saved = null, original, setLine, removeLine, errors, flags: engineFlags, canRemove, settled, say, chart = null, item = null }) {
  const id = (k) => `line-${index}-${k}`;
  // A "Must fix" on a cell the person has changed waits on the save (D9).
  const changed = editedLineCells(saved, line);
  const flags = pendingOnEdit(engineFlags, (f) => (f.cell ? changed.has(f.cell) : changed.size > 0));
  const cell = (k) => flags.filter((f) => f.cell === k);
  // A flag about the line, or about a cell this block doesn't draw, leads the line.
  const whole = flags.filter((f) => !f.cell || !LINE_CELLS.includes(f.cell));
  const alternatives = original && Array.isArray(original.alternatives) ? original.alternatives : [];
  // THE ACCOUNT IS PICKED, NOT REMEMBERED (staging browser walk 1, D11): Vert's
  // suggestions, then the chart, as the Journals editor lists it. The tax rate by name.
  const accounts = lineAccountChoices({ original, current: line.accountCode, chart: chart && chart.accounts });
  const taxes = lineTaxChoices({ item, original, current: line.taxType });
  const accountError = cell("accountCode").some((f) => f.severity === "block") ? "true" : undefined;
  return (
    <fieldset className="bill-line" data-line={index} disabled={settled}>
      <legend className="bill-line-head">
        Line {index + 1}
        {original ? <Confidence words={confidenceWords(original.codingConfidence) ? `Coding: ${confidenceWords(original.codingConfidence).toLowerCase()}` : null} /> : null}
      </legend>
      <Flags flags={whole} />
      <BillField id={id("description")} label="Description" value={line.description} onChange={(v) => setLine({ description: v })} flags={cell("description")} error={errors[`lines[${index}].description`]} className="bill-line-wide" />
      <div className="bill-line-figures">
        <BillField id={id("quantity")} label="Qty" value={line.quantity} onChange={(v) => setLine({ quantity: v })} flags={cell("quantity")} error={errors[`lines[${index}].quantity`]} inputMode="decimal" className="num" />
        <BillField id={id("unit")} label="Unit amount" value={line.unitAmount} onChange={(v) => setLine({ unitAmount: v })} flags={cell("unitAmountCents")} error={errors[`lines[${index}].unitAmount`]} inputMode="decimal" className="num" />
        <BillField id={id("tax")} label="Tax" value={line.tax} onChange={(v) => setLine({ tax: v })} flags={cell("taxCents")} error={errors[`lines[${index}].tax`]} inputMode="decimal" className="num" placeholder="None" />
        <BillField id={id("amount")} label="Amount" value={line.lineAmount} onChange={(v) => setLine({ lineAmount: v })} flags={cell("lineAmountCents")} error={errors[`lines[${index}].lineAmount`]} inputMode="decimal" className="num" />
      </div>
      <div className="bill-line-coding">
        <BillField id={id("account")} label="Account" flags={cell("accountCode")}>
          <select
            id={id("account")}
            name={id("account")}
            className="field-input"
            autoComplete="off"
            translate="no"
            value={line.accountCode || ""}
            onChange={(e) => setLine({ accountCode: e.target.value })}
            aria-invalid={accountError}
          >
            <option value="" disabled>
              Choose an account
            </option>
            {accounts.groups.map((g) => (
              <optgroup key={g.label} label={g.label}>
                {g.options.map((o) => (
                  <option key={o.value} value={o.value}>
                    {o.label}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
        </BillField>
        <BillField id={id("taxtype")} label="Tax rate" flags={cell("taxType")}>
          <select id={id("taxtype")} name={id("taxtype")} className="field-input" autoComplete="off" value={line.taxType || ""} onChange={(e) => setLine({ taxType: e.target.value })}>
            {taxes.map((t) => (
              <option key={t.value || "own"} value={t.value}>
                {t.label}
              </option>
            ))}
          </select>
        </BillField>
      </div>
      {chart && chart.note ? <p className="bill-line-basis ink-2">{chart.note} Vert&rsquo;s suggestions are listed.</p> : null}
      {original && original.codingBasis && line.accountCode === original.accountCode ? <p className="bill-line-basis ink-2">{say(noLedgerWord(original.codingBasis))}</p> : null}
      {alternatives.length && !settled ? (
        <div className="bill-alternatives" role="group" aria-label={`Other coding for line ${index + 1}`}>
          <span className="ink-2">Other suggestions</span>
          {alternatives.map((alt, i) => {
            const chosen = alt.accountCode === line.accountCode && (alt.taxType || "") === (line.taxType || "");
            return (
              <button
                key={`${alt.accountCode}-${alt.taxType}-${i}`}
                type="button"
                className="chip bill-alternative"
                aria-pressed={chosen ? "true" : "false"}
                title={alt.basis || undefined}
                onClick={() => setLine({ accountCode: alt.accountCode || "", taxType: alt.taxType || "" })}
              >
                <span translate="no">
                  {alt.accountCode} {alt.accountName}
                  {alt.taxName ? `, ${alt.taxName}` : ""}
                </span>
              </button>
            );
          })}
        </div>
      ) : null}
      {canRemove && !settled ? (
        <Button variant="quiet" size="sm" destructive onClick={removeLine}>
          Remove line {index + 1}
        </Button>
      ) : null}
    </fieldset>
  );
}

/** The item with each flag's words said in its own noun (D6). Its other fields as they are. */
function wordedFlags(item) {
  if (!item || !Array.isArray(item.flags)) return item;
  return { ...item, flags: item.flags.map((f) => (f && typeof f.words === "string" ? { ...f, words: wordedFor(f.words, item.kind) } : f)) };
}

export default function BillReview({ item: initialItem, xero, outcome: initialOutcome = null, onItem, onBack, chart: givenChart = null }) {
  const [item, setItem] = useState(initialItem);
  // Typed in the chat (D10/D26): no document, so nothing was "uploaded", "printed" or "misread".
  const typed = Boolean(item && item.sourceRef === "typed");
  // The chart, for each line's Account picker: the editors' one GET, after the first paint.
  const writesEnabled = useWritesEnabled();
  const [chart, setChart] = useState(() => givenChart || { accounts: [], note: null });
  useEffect(() => {
    if (givenChart || !writesEnabled) return undefined;
    let live = true;
    readChartOnce().then((answer) => {
      if (live) setChart(answer && answer.ok ? { accounts: answer.accounts, note: null } : { accounts: [], note: (answer && answer.message) || null });
    });
    return () => {
      live = false;
    };
  }, [givenChart, writesEnabled]);
  const signedIn = useSignedInActor();
  const [draft, setDraft] = useState(() => draftOf(initialItem));
  // The form as last drawn, read when a save lands (D46).
  const latestDraft = useRef(draft);
  latestDraft.current = draft;
  const [errors, setErrors] = useState({});
  const [outcome, setOutcome] = useState(initialOutcome || settledOutcome(initialItem));
  const [busy, setBusy] = useState(null);
  const [failure, setFailure] = useState(null);
  const [saved, setSaved] = useState(false);
  const [confirmDiscard, setConfirmDiscard] = useState(false);
  const [confirming, setConfirming] = useState(null);
  // REMEMBER (founder decision, 3 Nov 2026; engine w36): the bill's coding becomes the
  // supplier's rule only when the person ticks this. Unticked unless they do.
  const [remember, setRemember] = useState(false);

  // The item's own noun in every sentence (D6), and in every flag before it is placed.
  // The item's noun, and any stored actor worded for the viewer (D16).
  const say = (text) => actorsInWords(wordedFor(text, item.kind), { signedIn });
  const worded = useMemo(() => wordedFlags(item), [item]);
  const byField = useMemo(() => flagsByField(worded), [worded]);
  // The form as last saved, so a "Must fix" on a field changed since says it waits on
  // the save (D9).
  const savedDraft = useMemo(() => draftOf(item), [item]);
  const fieldFlags = (key) => pendingOnEdit(flagsFor(byField, key), () => String(savedDraft[key] ?? "") !== String(draft[key] ?? ""));
  const unplaced = useMemo(() => unplacedFlags(worded), [worded]);
  const contactFlags = contactFlagsOf(byField);
  // SAID ONCE (UI walk 3, W3-4): "Vert couldn't check Xero for this bill already being
  // there…" headed the review and was the Invoice number's "Check:" word for word. The
  // duplicate panel says it; a flag on the number that only repeats it is not drawn.
  const duplicatePanel = duplicateView(item.duplicate);
  const duplicateWords = duplicatePanel ? say(duplicatePanel.words) : null;
  const methodNote = say(methodNoteOf(item));
  const dirty = isDirty(item, draft);
  const approval = approvalOf(item, { dirty });
  const settled = item.status === "sent" || item.status === "approved" || item.status === "discarded";
  const doc = item.document || {};
  const originals = Array.isArray(doc.lines) ? doc.lines : [];
  const name = (typeof doc.contactName === "string" && doc.contactName.trim()) || item.filename || "Unnamed document";

  function take(next, nextOutcome = null) {
    setItem(next);
    setDraft(draftOf(next));
    setErrors({});
    if (nextOutcome) setOutcome(nextOutcome);
    if (onItem) onItem(next, nextOutcome);
  }

  const set = (field) => (value) => {
    setSaved(false);
    setDraft((d) => ({ ...d, [field]: value }));
  };
  const setLine = (index) => (patch) => {
    setSaved(false);
    setDraft((d) => ({ ...d, lines: d.lines.map((l, i) => (i === index ? { ...l, ...patch } : l)) }));
  };

  async function save(event) {
    if (event) event.preventDefault();
    if (busy) return;
    const sent = draft;
    const patch = patchOf(item, sent);
    setErrors(patch.errors);
    setFailure(null);
    if (!patch.ok || !patch.body) return;
    setBusy("save");
    const answer = await api.save(item.id, patch.body);
    setBusy(null);
    if (!answer.ok) {
      setFailure({ message: answer.message, recorded: recordedOf(answer) });
      return;
    }
    // AN EDIT MADE WHILE THE SAVE RAN IS KEPT (D46): the saved item is the base, each
    // field changed since the save was sent goes back on top.
    const next = answer.item;
    setItem(next);
    setDraft((current) => keepEditsSince(draftOf(next), sent, current));
    setErrors({});
    if (onItem) onItem(next, null);
    setSaved(latestDraft.current === sent);
  }

  // Employee paid (W3-5): its own PATCH, `{ paidBy }` or `{ paidBy: null }`. True when saved.
  async function savePaidBy(contact) {
    if (busy) return false;
    setFailure(null);
    setBusy("paidBy");
    const answer = await api.setPaidBy(item.id, contact);
    setBusy(null);
    if (!answer.ok) {
      setFailure({ message: answer.message, recorded: recordedOf(answer) });
      return false;
    }
    take(answer.item);
    return true;
  }

  async function answered(answer) {
    setBusy(null);
    if (!answer.ok) {
      // A retry of an unconfirmed send stays unconfirmed whatever the refusal, and a
      // check may have found candidates: the item is read again so they are shown.
      if (answer.kind === "blocked" && (item.status === "unconfirmed" || answer.reason === "check_candidates")) {
        const fresh = await api.readItem(item.id);
        if (fresh.ok && fresh.item) take(fresh.item);
      }
      // The engine asks for a second press it needs: check Xero, or confirm a duplicate.
      // Its words are shown as written.
      const step = retryStepOf(answer.reason);
      if (step) {
        setConfirming({ kind: step, words: answer.message || approval.confirm || (step === "check_ledger" ? UNCONFIRMED_WORDS : "This may already be in Xero.") });
        return;
      }
      setConfirming(null);
      setFailure({ message: answer.message, recorded: recordedOf(answer), approving: true });
      return;
    }
    setConfirming(null);
    const view = outcomeView(answer.outcome, answer.item);
    take(answer.item, view && answer.remembered ? { ...view, remembered: answer.remembered } : view);
  }

  // The first press. A possible duplicate, or a retry of a send that may have landed, is
  // not sent: it asks for a second press.
  async function approve() {
    if (!approval.can || busy) return;
    setFailure(null);
    if (approval.confirm) {
      setConfirming({ kind: approval.confirmKind, words: approval.confirm });
      return;
    }
    setBusy("approve");
    await answered(await api.approve(item.id, { remember }));
  }

  // The second press, after the person has read why: and only here is the engine told
  // they checked Xero ({checkedLedger}) or confirmed a possible duplicate ({confirmDuplicate}).
  async function approveConfirmed() {
    if (!approval.can || busy || !confirming) return;
    setFailure(null);
    setBusy("approve");
    const answer = confirming.kind === "check_ledger" ? await api.approve(item.id, { checkedLedger: true, remember }) : await api.approve(item.id, { confirmDuplicate: true, remember });
    await answered(answer);
  }

  async function refresh() {
    setBusy("refresh");
    setFailure(null);
    const answer = await api.readItem(item.id, { refresh: true });
    setBusy(null);
    if (!answer.ok) {
      setFailure({ message: answer.message, recorded: "nothing" });
      return;
    }
    take(answer.item);
  }

  async function discard() {
    setBusy("discard");
    setFailure(null);
    const answer = await api.discard(item.id);
    setBusy(null);
    setConfirmDiscard(false);
    if (!answer.ok) {
      setFailure({ message: answer.message, recorded: recordedOf(answer) });
      return;
    }
    take(answer.item);
  }

  // Who approved it: the engine's `approvedByWords` ("browser-walk's key", walk 1 D16);
  // an engine that sends none has the stored actor worded against the viewer.
  const approver = (typeof item.approvedByWords === "string" && item.approvedByWords.trim()) || actorWords(item.approvedBy, { signedIn });
  const approvedLine = [approver ? `Approved by ${approver}` : null, dayOf(item.approvedAt)].filter(Boolean).join(", ");

  return (
    <article className="bill-review" data-bill={item.id} data-status={item.status}>
      <header className="bill-review-head">
        <button type="button" className="records-back bill-back" onClick={onBack}>
          <IconBack className="caret-leading" />
          All {itemNoun(item.kind, { many: true })}
        </button>
        <h2 className="t-title-2 bill-title" translate="no">
          {name}
        </h2>
        <p className="bill-meta">
          <BillStatus item={item} />
          <span className="ink-2">
            {" "}
            · {kindWords(item.kind)} · {typed ? "Typed in chat" : SOURCE_WORDS[item.source] || "Added"}
            {item.filename && !typed ? (
              <>
                {" "}
                · <span translate="no">{item.filename}</span>
              </>
            ) : null}
          </span>
        </p>
        {approvedLine ? <p className="bill-meta ink-2">{approvedLine}</p> : null}
        {methodNote ? (
          <p className="bill-meta ink-2" data-method-note="">
            {methodNote}
          </p>
        ) : null}
        <div className="bill-head-actions">
          {!settled ? (
            <Button variant="secondary" size="sm" onClick={refresh} busy={busy === "refresh"} busyLabel="Checking Xero…" disabledReason={dirty ? "Save or undo your changes first." : null}>
              Check Xero again
            </Button>
          ) : null}
          {!settled ? (
            confirmDiscard ? (
              <span className="bill-confirm">
                <span>Set this aside? It won&rsquo;t be sent to Xero.</span>
                <Button variant="quiet" size="sm" onClick={() => setConfirmDiscard(false)}>
                  Cancel
                </Button>
                <Button variant="quiet" size="sm" destructive onClick={discard} busy={busy === "discard"} busyLabel="Setting aside…">
                  Set aside
                </Button>
              </span>
            ) : (
              <Button variant="quiet" size="sm" destructive onClick={() => setConfirmDiscard(true)}>
                Set aside…
              </Button>
            )
          ) : null}
        </div>
      </header>

      <OutcomePanel outcome={outcome} notes={pushNotesOf(item, { said: outcome && outcome.words })} say={say} statusSaid={statusWords(item, { signedIn })} />
      <DuplicatePanel duplicate={item.duplicate} say={say} />
      {failure ? (
        <Notice kind="error" recorded={failure.recorded} onDismiss={() => setFailure(null)}>
          {say(noticeText(failure.message, failure.recorded))}
        </Notice>
      ) : null}

      <div className="bill-review-grid">
        <SourcePane item={item} />

        <form className="bill-fields" onSubmit={save} noValidate>
          {unplaced.length ? (
            <section className="bill-general" aria-label="What Vert flagged">
              <Flags flags={unplaced} />
            </section>
          ) : null}

          <ContactPanel
            item={item}
            draft={draft}
            setDraft={setDraft}
            error={errors.contact}
            flags={contactFlags.choice}
            settled={settled}
            say={say}
            paidBy={item.kind !== "bill" ? null : <PaidBy item={item} settled={settled} dirty={dirty} busy={busy === "paidBy"} onChoose={(c) => savePaidBy(c)} onClear={() => savePaidBy(null)} />}
          />

          <fieldset className="bill-details" disabled={settled}>
            <legend className="bill-section-head">Details</legend>
            <div className="bill-grid">
              <BillField id="contactName" label="Contact name" value={draft.contactName} onChange={set("contactName")} flags={contactFlags.name} confidence={fieldConfidence(item, "contactName")} error={errors.contactName} />
              <BillField id="taxNumber" label="ABN or tax number" value={draft.taxNumber} onChange={set("taxNumber")} flags={fieldFlags("taxNumber")} confidence={fieldConfidence(item, "taxNumber")} error={errors.taxNumber} className="num" />
              <BillField id="email" label="Email" type="email" value={draft.email} onChange={set("email")} flags={fieldFlags("email")} confidence={fieldConfidence(item, "email")} error={errors.email} />
              <BillField id="invoiceNumber" label="Invoice number" value={draft.invoiceNumber} onChange={set("invoiceNumber")} flags={flagsBeyond(fieldFlags("invoiceNumber"), duplicateWords)} confidence={fieldConfidence(item, "invoiceNumber")} error={errors.invoiceNumber} />
              <BillDateField id="issueDate" label="Issue date" value={draft.issueDate} onChange={set("issueDate")} flags={fieldFlags("issueDate")} confidence={fieldConfidence(item, "issueDate")} error={errors.issueDate} />
              <BillDateField id="dueDate" label="Due date" value={draft.dueDate} onChange={set("dueDate")} flags={fieldFlags("dueDate")} confidence={fieldConfidence(item, "dueDate")} error={errors.dueDate} />
              <BillField id="currency" label="Currency" value={draft.currency} onChange={(v) => set("currency")(v.toUpperCase())} flags={fieldFlags("currency")} confidence={fieldConfidence(item, "currency")} error={errors.currency} maxLength={3} />
              <BillField id="amountsAre" label="Amounts are" flags={fieldFlags("amountsAre")} confidence={fieldConfidence(item, "amountsAre")} error={errors.amountsAre}>
                <select id="amountsAre" name="amountsAre" autoComplete="off" className="field-input" value={draft.amountsAre} onChange={(e) => set("amountsAre")(e.target.value)}>
                  {draft.amountsAre && !AMOUNTS_ARE.some((o) => o.value === draft.amountsAre) ? <option value={draft.amountsAre}>{draft.amountsAre}</option> : null}
                  {!draft.amountsAre ? (
                    <option value="" disabled>
                      Not read
                    </option>
                  ) : null}
                  {AMOUNTS_ARE.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </BillField>
            </div>
          </fieldset>

          <section className="bill-lines" aria-label="Lines">
            <h3 className="bill-section-head">Lines</h3>
            <Flags flags={fieldFlags("lines")} />
            {draft.lines.length === 0 ? <p className="ink-2">Vert read no lines from this document.</p> : null}
            {draft.lines.map((line, i) => (
              <LineBlock
                key={i}
                index={i}
                line={line}
                original={Number.isInteger(line.origin) ? originals[line.origin] || null : null}
                setLine={setLine(i)}
                removeLine={() => {
                  setSaved(false);
                  setDraft((d) => ({ ...d, lines: d.lines.filter((_, j) => j !== i) }));
                }}
                errors={errors}
                flags={lineFlags(byField, i)}
                saved={Number.isInteger(line.origin) ? savedDraft.lines.find((l) => l.origin === line.origin) || null : null}
                canRemove={draft.lines.length > 1}
                settled={settled}
                say={say}
                chart={chart}
                item={item}
              />
            ))}
            {!settled ? (
              <Button variant="quiet" size="sm" onClick={() => setDraft((d) => ({ ...d, lines: [...d.lines, emptyLine()] }))}>
                Add a line
              </Button>
            ) : null}
          </section>

          <fieldset className="bill-totals" disabled={settled}>
            <legend className="bill-section-head">{typed ? "Totals" : "Totals, as printed on the document"}</legend>
            <div className="bill-totals-grid">
              {[
                ["subtotal", "Subtotal"],
                ["tax", "Tax"],
                ["total", "Total"],
              ].map(([k, label]) => (
                <div className={k === "total" ? "bill-total-row bill-total" : "bill-total-row"} key={k} data-figure={TOTALS[k]}>
                  <BillField
                    id={`total-${k}`}
                    label={doc.currency ? `${label} (${doc.currency})` : label}
                    value={draft[k]}
                    onChange={set(k)}
                    flags={pendingOnEdit(flagsFor(byField, TOTALS[k]), () => savedDraft[k] !== draft[k])}
                    confidence={fieldConfidence(item, TOTALS[k])}
                    error={errors[TOTALS[k]]}
                    inputMode="decimal"
                    placeholder={totalPlaceholder(k, draft, doc)}
                    className="num"
                  />
                </div>
              ))}
            </div>
            <p className="bill-totals-note ink-2">
              {dirty
                ? `Read ${moneyText(doc.totalCents, "no total")} · checked on Save`
                : !typed && totalsUnsure(item, byField, draft)
                  ? "Fix any misread figures"
                  : null}
            </p>
          </fieldset>

          <footer className="bill-foot">
            <p className="bill-foot-note" role="status">
              {saved && !dirty ? "Saved. Vert checked the fields again." : dirty ? "You have changes that aren't saved." : null}
            </p>
            {dirty && !settled ? (
              <>
                <Button variant="quiet" onClick={() => setDraft(draftOf(item))}>
                  Undo changes
                </Button>
                <Button variant="secondary" type="submit" busy={busy === "save"} busyLabel="Saving…">
                  Save changes
                </Button>
              </>
            ) : null}
            {!settled && approval.confirm && !confirming ? (
              <div className="bill-confirm-why" data-needs-confirm={approval.confirmKind}>
                <p className="bill-confirm-words">
                  <IconWarning size={14} />
                  <span>{say(approval.confirm)}</span>
                </p>
                {approval.confirmKind === "check_ledger" ? <Candidates item={item} say={say} /> : null}
              </div>
            ) : null}
            {/* Beside Approve, for the first press and the second alike. */}
            {!settled ? <RememberTick name="remember" label="Remember this supplier's coding as a rule" checked={remember} onChange={setRemember} /> : null}
            {!settled && confirming ? (
              <div className="bill-confirm-step" role="group" aria-label={confirming.kind === "check_ledger" ? "Check Xero before sending again" : "Confirm it isn't a duplicate"} data-confirm-step={confirming.kind}>
                <p className="bill-confirm-words">
                  <IconWarning size={14} />
                  <span>{say(confirming.words)}</span>
                </p>
                {confirming.kind === "check_ledger" ? <Candidates item={item} say={say} /> : null}
                {confirming.kind !== "check_ledger" && sameFileOf(item) ? (
                  <p className="bill-confirm-earlier">
                    Uploaded before as{" "}
                    <a className="link" href={sameFileOf(item).href}>
                      {say(sameFileOf(item).words)}
                    </a>
                  </p>
                ) : null}
                {confirmStepOf(confirming.kind, xero).after ? <p className="bill-confirm-after">{say(confirmStepOf(confirming.kind, xero).after)}</p> : null}
                <Button variant="quiet" onClick={() => setConfirming(null)}>
                  Cancel
                </Button>
                <Button variant="commit" onClick={approveConfirmed} busy={busy === "approve"} busyLabel="Approving…" disabledReason={approval.can ? null : say(approval.reason)}>
                  {say(confirmStepOf(confirming.kind, xero).button)}
                </Button>
              </div>
            ) : !settled ? (
              <Button variant="commit" onClick={approve} busy={busy === "approve"} busyLabel="Approving…" disabledReason={approval.can ? null : say(approval.reason)}>
                {say(approveLabel(xero))}
              </Button>
            ) : null}
          </footer>
        </form>
      </div>
    </article>
  );
}

/**
 * Whether the printed totals ask to be checked (walk 4 copy: a clean read still said
 * "Fix any misread figures"): a total not read, flagged, or read with less than high
 * confidence. Pure.
 */
export function totalsUnsure(item, byField, draft) {
  const confidence = (item && item.document && item.document.confidence) || {};
  return Object.entries(TOTALS).some(([k, field]) => {
    if (k === "subtotal" && subtotalNotPrinted(draft, item && item.document)) return false;
    const value = draft && typeof draft[k] === "string" ? draft[k].trim() : draft && draft[k];
    if (value === "" || value === null || value === undefined) return true;
    if (flagsFor(byField, field).length) return true;
    return confidence[field] !== "high";
  });
}

// A tax-inclusive receipt prints its total and the tax in it, and often no subtotal: an
// empty subtotal there is not printed, not unread (walk 4 copy: "Not read").
function subtotalNotPrinted(draft, doc) {
  const are = (draft && draft.amountsAre) || (doc && doc.amountsAre);
  const subtotal = draft && typeof draft.subtotal === "string" ? draft.subtotal.trim() : "";
  return are === "Inclusive" && !subtotal && Number.isInteger(doc && doc.totalCents);
}

/** The placeholder an empty printed total shows. Pure. */
export function totalPlaceholder(k, draft, doc) {
  return k === "subtotal" && subtotalNotPrinted(draft, doc) ? "Not printed" : "Not read";
}
