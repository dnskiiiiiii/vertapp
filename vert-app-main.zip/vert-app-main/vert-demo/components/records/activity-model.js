// components/records/activity-model.js — RECORDS' ACCOUNTS TAB, READ ONE WAY (verify pass 3, S-BK-8)
// ==============================================================================
// The chart, and one account's lines for the month, as the engine's ledger routes
// answer them (lib/ledger-activity.js). Every figure is the engine's: the totals and
// the line count are the WHOLE month's on every page (never the lines on screen added
// up), and a page's position is the engine's `offset`. An unread chart or account is
// said in words; it is never an empty list or a $0.00.
//
// Pure, so the paging, the stale-cursor refusal and the words are tested without a
// browser.

import { periodEnd } from "@/lib/period";
import { formatCount, metaLine } from "@/lib/format";

const ISO_MONTH = /^(\d{4})-(0[1-9]|1[0-2])$/;
const CURRENCY = /^[A-Z]{3}$/;

/** The first and last day of a month: `{ from, to }`, or null. */
export function periodRange(period) {
  if (!ISO_MONTH.test(String(period ?? ""))) return null;
  return { from: `${period}-01`, to: periodEnd(period) };
}

/** `/records?tab=accounts[&account=…][&period=…]`. */
export function accountsHref({ account = null, period = null } = {}) {
  const params = new URLSearchParams({ tab: "accounts" });
  if (typeof account === "string" && account) params.set("account", account);
  if (ISO_MONTH.test(String(period ?? ""))) params.set("period", period);
  return `/records?${params}`;
}

/** "1020 Business Cheque", from the chart's number and name. */
function accountLabel(a) {
  const name = typeof a.name === "string" && a.name.trim() ? a.name.trim() : null;
  const number = typeof a.number === "string" && a.number.trim() ? a.number.trim() : null;
  return [number, name].filter(Boolean).join(" ") || String(a.qboId);
}

/**
 * The chart as the tab lists it: `{ read, rows, words }`. Each row is
 * `{ id, label, section, currency }`, active accounts only, in the chart's number
 * order as the engine gave it.
 */
export function accountsView(answer) {
  if (!answer || !answer.ok || !Array.isArray(answer.accounts)) {
    return { read: false, rows: [], words: (answer && answer.message) || "Vert couldn't read your chart of accounts just now." };
  }
  const rows = answer.accounts
    .filter((a) => a && typeof a.qboId === "string" && a.qboId && a.active !== false)
    .map((a) => ({
      id: a.qboId,
      label: accountLabel(a),
      section: typeof a.section === "string" && a.section ? a.section.replace(/_/g, " ").replace(/^./, (c) => c.toUpperCase()) : null,
      currency: typeof a.currency === "string" && CURRENCY.test(a.currency) ? a.currency : null,
    }));
  const words = rows.length ? `${rows.length} ${rows.length === 1 ? "account" : "accounts"}` : "No accounts on the chart yet.";
  return { read: true, rows, words };
}

/** One line as a row of the table. */
function lineRow(line) {
  const cents = Number.isInteger(line.amountMinor) ? line.amountMinor : null;
  const who = [line.counterparty, line.memo].filter((t) => typeof t === "string" && t.trim()).map((t) => t.trim());
  return {
    id: String(line.lineId || line.qboId),
    date: typeof line.date === "string" ? line.date : null,
    type: typeof line.txnType === "string" && line.txnType ? line.txnType : null,
    number: typeof line.docNumber === "string" && line.docNumber ? line.docNumber : null,
    about: metaLine(who) || null,
    cents,
    measured: cents !== null,
  };
}

/**
 * One page of the account's lines: `{ read, measured, label, rows, offset, next,
 * lineCount, debit, credit, net, words, inWords }`. `read: false` with the words when
 * the read failed; `measured: false` with the engine's reason when it read the account
 * and could not measure the month (no rows, no totals, and no zero said).
 */
export function activityView(answer) {
  if (!answer || !answer.ok || !answer.body) {
    return { read: false, stale: Boolean(answer && answer.code === "stale_cursor"), rows: [], words: (answer && answer.message) || "Vert couldn't read this account's lines just now." };
  }
  const b = answer.body;
  const label = typeof b.accountLabel === "string" && b.accountLabel ? b.accountLabel : null;
  if (b.measured !== true) {
    return { read: true, measured: false, label, rows: [], words: b.notMeasuredReason || b.inWords || "Vert hasn't read this account's lines for this month." };
  }
  const lines = Array.isArray(b.lines) ? b.lines.filter((l) => l && (l.lineId || l.qboId)) : [];
  const offset = Number.isInteger(b.offset) && b.offset >= 0 ? b.offset : 0;
  const lineCount = Number.isInteger(b.lineCount) ? b.lineCount : null;
  const end = offset + lines.length;
  const of = lineCount === null ? "" : ` of ${formatCount(lineCount)}`;
  const words = lines.length
    ? `${formatCount(offset + 1)} to ${formatCount(end)}${of} ${lineCount === 1 ? "line" : "lines"}`
    : lineCount === 0
      ? "No lines on this account this month."
      : "No more lines.";
  return {
    read: true,
    measured: true,
    label,
    rows: lines.map(lineRow),
    offset,
    next: typeof b.nextCursor === "string" && b.nextCursor ? b.nextCursor : null,
    lineCount,
    debit: Number.isInteger(b.debitMinor) ? b.debitMinor : null,
    credit: Number.isInteger(b.creditMinor) ? b.creditMinor : null,
    net: Number.isInteger(b.netMinor) ? b.netMinor : null,
    words,
    inWords: typeof b.inWords === "string" ? b.inWords : null,
  };
}

/**
 * The list after another page arrives: the pages so far with the new one's rows after
 * them, its cursor and words; a page that failed keeps what is on screen and says why.
 * A row already listed (a line id seen on an earlier page) is not listed twice. Pure.
 */
export function withPage(shown, page) {
  if (!shown || !page) return shown || page;
  if (!page.read || page.measured === false) return { ...shown, next: page.stale ? null : shown.next, error: page.words, stale: Boolean(page.stale) };
  const seen = new Set(shown.rows.map((r) => r.id));
  const rows = [...shown.rows, ...page.rows.filter((r) => !seen.has(r.id))];
  const words = page.lineCount === null ? `${formatCount(rows.length)} lines` : `1 to ${formatCount(rows.length)} of ${formatCount(page.lineCount)} lines`;
  return { ...page, rows, offset: 0, words, error: null, stale: false };
}
