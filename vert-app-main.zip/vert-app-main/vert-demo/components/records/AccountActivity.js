"use client";

// components/records/AccountActivity.js — AN ACCOUNT'S LINES FOR THE MONTH (verify pass 3, S-BK-8)
// ==============================================================================
// Records' Accounts tab. Without an account it lists the chart, each account opening
// its lines; with one (`?account=102`) it lists that account's lines for the month the
// page is on, the engine's whole-month totals above them:
//
//   ‹ Accounts
//   1020 Business Cheque · August
//   5,104 lines · Debits $2,563,770.29 · Credits $0.00 · Net $2,563,770.29
//   Date     Type      No.   About                 Amount
//   1 Aug    Deposit   2261  STRIPE AU PAYOUT      $1,240.00
//   …
//   1 to 1,000 of 5,104 lines                [ Show the next 1,000 ]
//
// The engine pages the lines (lib/ledger-activity.js, at most 1,000 a page, its
// `nextCursor` to the next); "Show the next 1,000" asks for the next page and adds it
// under the rows already listed, so a 10,000-line month is read a page at a time and
// never as one 10,000-line answer. A cursor from before a newer sync is refused by the
// engine (409): the list keeps what it has and says to start again, with the way to.
// Amounts are the ledger's convention, debits positive, a credit in brackets, as the
// workbook writes them.

import Link from "next/link";
import { useState } from "react";

import { Button, Figure, Table } from "@/components/ui";
import { formatCount, formatDay, formatMoney } from "@/lib/format";
import { readAccountActivity } from "@/lib/ledger-activity";
import { accountsHref, activityView, withPage } from "./activity-model";

const LINE_COLUMNS = [
  { key: "date", label: "Date" },
  { key: "type", label: "Type" },
  { key: "number", label: "No." },
  { key: "about", label: "About" },
  { key: "amount", label: "Amount", numeric: true },
];

const ACCOUNT_COLUMNS = [
  { key: "account", label: "Account" },
  { key: "section", label: "Section" },
];

function lineCells(row) {
  return {
    date: row.date ? formatDay(row.date) : <span className="ink-2">No date</span>,
    type: row.type || <span className="ink-2">Not recorded</span>,
    // A blank cell, read out as words (verify pass 4, S-BK-13): the word "None" down a
    // column of 5,000 lines read like a number the ledger had sent. On a phone's stacked
    // row the empty "No." pair is left out (records.css), not drawn blank.
    number: row.number || (
      <span data-no-number="">
        <span className="sr-only">No number</span>
      </span>
    ),
    about: row.about || <span className="ink-2">No memo</span>,
    amount: row.measured ? (
      <span className="num" {...{ "data-cents": String(row.cents) }} translate="no">
        {formatMoney(row.cents, { style: "table" })}
      </span>
    ) : (
      <span className="ink-2">Not read</span>
    ),
  };
}

/** The chart, each account a link to its lines for the month. */
export function AccountsList({ view, period = null }) {
  if (!view || !view.read) {
    return (
      <p className="records-count" role="status" data-accounts-unread="">
        {(view && view.words) || "Vert couldn't read your chart of accounts just now."}
      </p>
    );
  }
  const rows = view.rows.map((r) => ({
    id: r.id,
    href: accountsHref({ account: r.id, period }),
    cells: {
      account: (
        // Two lines at most, cut with an ellipsis, the whole name in the title (verify
        // pass 4, S-BK-13 / S-UI-3): a 200-character name ran to seven lines at 390.
        <Link className="link records-account-name" href={accountsHref({ account: r.id, period })} data-account={r.id} title={r.label}>
          {r.label}
        </Link>
      ),
      section: r.section || <span className="ink-2">Not classified</span>,
    },
  }));
  return (
    <div className="records-accounts" data-accounts="">
      <div className="records-bar">
        <p className="records-count">{view.words}</p>
      </div>
      {rows.length ? <Table columns={ACCOUNT_COLUMNS} rows={rows} caption="Accounts" className="records-table" /> : null}
    </div>
  );
}

/** One account's lines for the month, a page at a time. */
export default function AccountActivity({ first, request, month = null, period = null }) {
  const [shown, setShown] = useState(first);
  const [busy, setBusy] = useState(false);

  async function more() {
    if (busy || !shown || !shown.next) return;
    setBusy(true);
    let answer;
    try {
      answer = await readAccountActivity({ ...request, cursor: shown.next });
    } catch {
      answer = { ok: false, message: "Vert couldn't read the next page just now. What's listed is kept." };
    }
    setShown((prev) => withPage(prev, activityView(answer)));
    setBusy(false);
  }

  const back = (
    <Link href={accountsHref({ period })} className="records-back records-accounts-back">
      All accounts
    </Link>
  );

  if (!shown || !shown.read || shown.measured === false) {
    return (
      <div className="records-activity" data-activity="unread">
        {back}
        <p className="records-count" role="status">
          {(shown && shown.words) || "Vert couldn't read this account's lines just now."}
        </p>
      </div>
    );
  }

  const rows = shown.rows.map((row) => ({ id: row.id, cells: lineCells(row) }));
  const heading = `${shown.label || "This account"}${month ? ` · ${month}` : ""}`;
  const pageSize = request && Number.isInteger(request.limit) ? request.limit : 1000;
  return (
    <div className="records-activity" data-activity="" data-account-id={request && request.account}>
      {back}
      {/* One line, cut with an ellipsis, the whole name in its title (verify pass 4,
          S-BK-13): a 200-character account name wrapped to six lines at 390 px. */}
      <h2 className="t-title-3 records-activity-title" title={heading}>
        {heading}
      </h2>
      {/* The engine's whole-month totals, never the rows on screen added up. */}
      <p className="records-count records-activity-totals" data-activity-totals="">
        <span>{shown.lineCount === null ? "Lines not counted" : `${formatCount(shown.lineCount)} ${shown.lineCount === 1 ? "line" : "lines"}`}</span>
        <span className="ink-2"> · Debits </span>
        <Figure cents={shown.debit} measured={shown.debit !== null} unread="not read" style="table" figure="activity/debits" />
        <span className="ink-2"> · Credits </span>
        <Figure cents={shown.credit} measured={shown.credit !== null} unread="not read" style="table" figure="activity/credits" />
        <span className="ink-2"> · Net </span>
        <Figure cents={shown.net} measured={shown.net !== null} unread="not read" style="table" figure="activity/net" />
      </p>
      {rows.length ? <Table columns={LINE_COLUMNS} rows={rows} caption={`${shown.label || "Account"} lines`} className="records-table records-activity-table" /> : null}
      <div className="records-activity-foot">
        <p className="records-count" aria-live="polite" data-activity-words="">
          {shown.words}
        </p>
        {shown.next ? (
          <Button variant="secondary" size="sm" onClick={more} busy={busy} busyLabel="Reading…" data-activity-more="">
            {`Show the next ${formatCount(pageSize)}`}
          </Button>
        ) : null}
      </div>
      {shown.error ? (
        <p className="task-problem t-footnote" role="alert" data-activity-error="">
          {shown.error}{" "}
          {shown.stale ? <a href={accountsHref({ account: request.account, period })}>Start again</a> : null}
        </p>
      ) : null}
    </div>
  );
}
