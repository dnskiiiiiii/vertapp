"use client";

// components/records/AskAboutThis.js — "Ask Vert about this ›"
// ==============================================================================
// Spec §3.5 and §4.1: a record starts a conversation scoped to itself. The press calls
// `POST /agent/sessions {period, subject}` through the conversation's own server action
// (lib/agent/actions.js) and goes to the conversation it returns. Starting a
// conversation writes nothing to the books, so this is a secondary control, never the
// accent (spec §11.2: the accent means "this writes").
//
// IN THE STATIC DEMO there is no service to hold a conversation, so the control is
// `aria-disabled` with its reason printed beside it (UI-014), never hidden: the reader
// learns the door exists and why it is shut.
//
// A FAILED START KEEPS THE SHEET and says so, in the shape every failure takes here:
// what happened, that nothing was recorded, and Try again (UI-002, spec §11.5).

import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button, Notice } from "@/components/ui";
import { useWritesEnabled } from "@/lib/engine-context";
import { startConversation } from "@/lib/agent/actions";

import { IconCaretRight } from "@/components/ui/icons";
export const ASK_LABEL = "Ask Vert about this";
export const ASK_SAMPLE_REASON = "Conversations need your own books, not the sample.";

export default function AskAboutThis({ period, subject }) {
  const router = useRouter();
  const live = useWritesEnabled();
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(false);

  async function ask() {
    setBusy(true);
    setFailed(false);
    let result;
    try {
      result = await startConversation({ period, subject });
    } catch {
      result = { ok: false };
    }
    if (result && result.ok && result.sessionId) {
      router.push(`/chat/${encodeURIComponent(result.sessionId)}`);
      return;
    }
    setBusy(false);
    setFailed(true);
  }

  return (
    <div className="record-ask">
      <Button
        variant="secondary"
        onClick={ask}
        busy={busy}
        busyLabel="Opening…"
        disabledReason={live ? null : ASK_SAMPLE_REASON}
      >
        {ASK_LABEL}
        <IconCaretRight className="caret-trailing" />
      </Button>
      {failed ? (
        <Notice kind="error" recorded="nothing" onRetry={ask}>
          Vert couldn&rsquo;t start that conversation.
        </Notice>
      ) : null}
    </div>
  );
}
