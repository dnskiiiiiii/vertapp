// components/records/entry-people.js — WHO DREW, APPROVED AND POSTED AN ENTRY (verify pass 2, P19)
// ==============================================================================
// The Records sheet for a journal entry said "Posted · Journal entry 1" and named
// nobody, although the ledger memo it came from names the approver. Read off the
// engine's own `GET /journal/{id}` answer, never worked out: the approver is the
// memo trail's (`backReference.approvedBy`), else the actor of the decision that
// stands now (an approve as the LATEST decision; an approval taken back names no one).
// The engine records no separate poster (Approve and post is one person's press);
// the post's own date is shown, and the poster is said only when the engine names one.

const PERSON = (actor) => {
  const text = typeof actor === "string" ? actor.trim() : "";
  const name = text.startsWith("user:") ? text.slice(5).trim() : text;
  return name || null;
};

import { displayDayOf } from "@/lib/format";
import { ledgerAbsence } from "@/lib/ledger-shape";
import { ledgerStatusOf } from "@/components/cards/words";
import { outcomeWordOf, postedOf, rejectedOf } from "./model";

const ISO_DAY = /^\d{4}-\d{2}-\d{2}/;

// A conversation id as the routes name one ("c-13", "2026-07-deferred_revenue").
const CONVERSATION = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$/;

/** The conversation the entry was drafted in, or null. Never a URL from the payload. */
function conversationOf(entry, back) {
  const manual = entry.manual && typeof entry.manual === "object" ? entry.manual : {};
  for (const id of [back.conversationId, manual.sessionId, entry.sessionId]) {
    if (typeof id === "string" && CONVERSATION.test(id)) return id;
  }
  return null;
}

/**
 * `{ read, draftedBy, draftedByVert, approvedBy, selfApproved, posted, postedAt, postedBy }`
 * from a `GET /journal/{id}` body, or `{ read: false }` when there is no entry in it. Pure.
 */
export function entryPeopleOf(body) {
  const entry = body && typeof body === "object" && body.entry && typeof body.entry === "object" ? body.entry : null;
  if (!entry) return { read: false };
  const back = entry.backReference && typeof entry.backReference === "object" ? entry.backReference : {};
  const decisions = Array.isArray(entry.decisions) ? entry.decisions.filter((d) => d && typeof d === "object") : [];
  const last = decisions.length ? decisions[decisions.length - 1] : null;
  const standing = last && last.decision === "approve" ? last : null;
  const approvedBy = PERSON(back.approvedBy) || (standing ? PERSON(standing.actor) : null);
  const posted = entry.status === "posted" || entry.approvalState === "posted";
  return {
    read: true,
    draftedBy: PERSON(back.draftedBy),
    draftedByVert: back.draftedByVert === true,
    // A shared key typed it (live check, 29 Oct 2026): the credential as recorded, worded
    // by approverLabel as a key's approval is, never as "Vert".
    draftedByKey: typeof back.draftedByKey === "string" && back.draftedByKey.trim() ? back.draftedByKey.trim() : null,
    approvedBy,
    selfApproved: Boolean(standing && standing.selfApproved === true),
    posted,
    // The post's day ON THE DISPLAY CALENDAR (verify pass 3, D08), never the instant's
    // first ten characters: those are its UTC day, a day early every Sydney morning.
    postedAt: posted && typeof entry.postedAt === "string" && ISO_DAY.test(entry.postedAt) ? displayDayOf(entry.postedAt) : null,
    postedBy: posted ? PERSON(entry.postedBy) || PERSON(back.postedBy) : null,
    // WHAT THE LEDGER HOLDS OF IT (p1/fix5): "draft" | "posted", or null when the engine
    // did not say; and the ledger's display name from the same answer.
    ledgerStatus: posted ? ledgerStatusOf(entry) : null,
    ledgerName: body.ledger && typeof body.ledger.displayName === "string" && body.ledger.displayName.trim() ? body.ledger.displayName.trim() : null,
    // WHAT IS STILL TO BE PRESSED ON IT (verify pass 3, S-E2E-7). The sheet said "Needs
    // you · Entry ready to approve" and offered nothing to press: the approver had to
    // find the conversation, and a hand-drafted entry's conversation need not hold its
    // card at all. `awaiting`: the approval is still to come (the engine's approval
    // state, `awaiting`); `approvedUnposted`: approved and not yet in the ledger.
    awaiting: !posted && entry.approvalState === "awaiting",
    approvedUnposted: !posted && entry.approvalState === "approved",
    conversationId: conversationOf(entry, back),
    // MAY IT BE REJECTED (w16 contract, walk 3 W3-6): the engine's `entry.mayReject`, true
    // while it is unposted and not already rejected. A recurring draft offered only
    // Approve, so walk 2's and walk 3's drafts were stuck. Not said: not offered.
    mayReject: !posted && entry.mayReject === true,
    // WHO REJECTED IT, AND WHY (staging browser walk 4, W4-5): the reject decision's actor
    // as stored and the reason they gave, or null. The sheet said "Needs you · Entry
    // ready to approve" after Reject, and "Not worked out yet" on reload.
    rejected: rejectionOf(entry, decisions),
    // The deployment's ledger, when it is known to be absent (verify pass 4, P24): the
    // engine's reason and remedy, `{ short, reason, remedy }`, else null.
    noLedger: ledgerAbsence(body.ledger),
    // REVERSE FROM THE SHEET (staging D4, 27 Oct 2026): the month the entry belongs to,
    // the entry it itself reverses (a reversal is not reversed from here), and the
    // reversal standing against it, as the engine reads them back.
    period: typeof entry.period === "string" && /^\d{4}-\d{2}$/.test(entry.period) ? entry.period : null,
    reverses: typeof entry.reverses === "string" && entry.reverses ? entry.reverses : null,
    reversal: reversalOf(entry.reversal),
    // WHERE IT STANDS NOW (UI walk D9, 30 Oct 2026): the engine's status word and the
    // ledger's number from this same read, so the sheet's header moves with an approve
    // or a post it made instead of keeping the list's word from when it opened.
    current: {
      statusWord: typeof entry.statusWord === "string" ? entry.statusWord : null,
      statusWordReason: typeof entry.statusWordReason === "string" && entry.statusWordReason.trim() ? entry.statusWordReason.trim() : null,
      // Rejected, Withdrawn, Replaced: the engine's word for an entry set aside, which
      // none of the four status words is true of (`statusWord` is null then).
      outcomeWord: outcomeWordOf(entry),
      posted: postedOf(entry, body.ledger),
    },
  };
}

/**
 * The standing reject decision, `{ by, note }`, or null: the decision's stored actor
 * (worded for the viewer where drawn, so the rejecting key reads "you"), else the
 * engine's `entry.rejected` (w18 contract: `{by, reason, at}`, `by` already in words).
 */
function rejectionOf(entry, decisions) {
  if (entry.approvalState !== "rejected") return null;
  const last = [...decisions].reverse().find((d) => d.decision === "reject");
  if (!last) return rejectedOf(entry);
  const by = typeof last.actor === "string" && last.actor.trim() ? last.actor.trim() : null;
  const note = typeof last.note === "string" && last.note.trim() ? last.note.trim() : null;
  return by || note ? { by, note } : null;
}

/** The reversal standing against the entry (`{ entryId, state, conversationId }`), or null. */
function reversalOf(value) {
  if (!value || typeof value !== "object" || typeof value.entryId !== "string" || !value.entryId) return null;
  const sid = typeof value.sessionId === "string" && CONVERSATION.test(value.sessionId) ? value.sessionId : null;
  return { entryId: value.entryId, state: typeof value.state === "string" ? value.state : null, conversationId: sid };
}
