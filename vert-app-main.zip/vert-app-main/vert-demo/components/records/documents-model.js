// components/records/documents-model.js — RECORDS' DOCUMENTS TAB, READ ONE WAY (verify pass 2, S-UI-2)
// ==============================================================================
// Every file Vert holds for this client, as `GET /documents` listed it, a page at a
// time. Every word on a row is the engine's: the file's own name, its kind, its pages
// (or why they were not counted), who uploaded it and when. Nothing is computed but the
// page's position, and a list that was not read says so — it is never "no documents".

import { displayDayOf } from "@/lib/format";

export const DOCUMENTS_PAGE = 50;

const DAY = /^\d{4}-\d{2}-\d{2}/;

/** The offset a query names, or 0. */
export function documentsOffset(value) {
  const n = Number(Array.isArray(value) ? value[0] : value);
  return Number.isInteger(n) && n >= 0 && n <= 1_000_000 ? n : 0;
}

/** `{ read, rows, total, offset, next, previous, words }` from a `listDocuments` answer. Pure. */
export function documentsView(answer, { offset = 0, limit = DOCUMENTS_PAGE } = {}) {
  if (!answer || !answer.ok || !Array.isArray(answer.items)) {
    return { read: false, rows: [], total: null, offset, next: null, previous: null, words: (answer && answer.message) || "Vert couldn't list its files just now." };
  }
  const rows = answer.items
    .filter((d) => d && typeof d.documentId === "string" && d.documentId)
    .map((d) => ({
      id: d.documentId,
      name: typeof d.originalFilename === "string" && d.originalFilename.trim() ? d.originalFilename.trim() : "A file with no name",
      kind: d.kind === "workbook" ? "Workbook" : d.kind === "pdf" ? "PDF" : "File",
      pages: Number.isInteger(d.pageCount) ? `${d.pageCount} ${d.pageCount === 1 ? "page" : "pages"}` : d.kind === "workbook" ? "Sheets, not pages" : "Not counted",
      by: typeof d.uploadedBy === "string" && d.uploadedBy.trim() ? d.uploadedBy.trim().replace(/^user:/, "") : null,
      day: typeof d.uploadedAt === "string" && DAY.test(d.uploadedAt) ? displayDayOf(d.uploadedAt) : null,
    }));
  const total = Number.isInteger(answer.total) ? answer.total : null;
  const end = offset + rows.length;
  const next = total !== null ? (end < total ? end : null) : rows.length === limit ? end : null;
  const previous = offset > 0 ? Math.max(0, offset - limit) : null;
  let words;
  if (!rows.length) words = offset > 0 ? "No more files." : "No files yet. A file attached in a conversation is kept here.";
  else if (total !== null) words = `${offset + 1} to ${end} of ${total} ${total === 1 ? "file" : "files"}`;
  else words = `${rows.length} ${rows.length === 1 ? "file" : "files"}`;
  return { read: true, rows, total, offset, next, previous, words };
}
