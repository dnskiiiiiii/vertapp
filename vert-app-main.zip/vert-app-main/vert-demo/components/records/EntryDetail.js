"use client";

// components/records/EntryDetail.js — A JOURNAL ENTRY THAT NO PAYOUT OWNS
// ==============================================================================
// Build plan §4.6 FS. A payout's entry opens the payout's record sheet (PayoutDetail),
// because that entry IS the payout's decision and its evidence is the payout's. A
// prepaid release, a manual entry or a reversal has no payout behind it, so its sheet
// says what the row says, in full: what it is, its reference, its date, its total and
// its status — the engine's figures and the engine's word, nothing worked out here.
//
// THE LINES ARE NOT REDRAWN HERE. The entry's card in its conversation is the one place
// an entry's lines are drawn and edited (components/cards/JournalCard.js); a second
// line table here would be a second renderer of the same lines, which is the drift
// §4.0.3 ("one table, three readers") exists to prevent.

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, Field, Figure, Notice } from "@/components/ui";
import { approveEntry, rejectEntry } from "@/lib/journal";
import { EntryPost } from "./RecordPost";
import { callSafely } from "@/lib/decisions";
import { SEGREGATION_REASON, approveRefusal } from "@/lib/roles";
import { useDuties, useSignedInActor } from "@/lib/store";
import { actorWords, approverLabel, formatDate, isCredentialActor } from "@/lib/format";
import { ledgerStatusTerm } from "@/components/cards/words";
import { readEntry } from "./entry-read-client";
import { RecordStatus } from "./PostedMark";
import EntryDocuments, { useEntryDocuments } from "@/components/cards/EntryDocuments";
import { useWritesEnabled } from "@/lib/engine-context";
import { startConversation } from "@/lib/agent/actions";
import { quotable, referenceWords } from "./model";
import { isStatusWord } from "@/lib/status";
import { NO_LEDGER_ROW } from "@/lib/ledger-shape";
import { closedPostReason, useMonthSignedOff } from "@/components/month/useMonthSignedOff";

// WHO (verify pass 2, P19): the sheet names who drafted, approved and posted the entry,
// as the ledger memo does — read from the engine (entry-people.js), said in words while
// it is being read or when it could not be.
//
// "YOU" IS THE VIEWER (UI walk D2, 30 Oct 2026). A key's act is worded by approverLabel
// against the signed-in actor: k2 opening k1's draft was told "Drafted by: you" and then
// asked to approve it, because no actor was passed and every key read as "you".

/** The people rows the sheet shows, `[{ term, text }]`, from a reading. Pure. */
export function peopleRows(people, { signedIn = null } = {}) {
  if (!people) return [{ term: "Approved by", text: "Reading…", quiet: true }];
  if (!people.read) return [{ term: "Approved by", text: "Vert couldn't read who approved this entry just now.", quiet: true }];
  const who = (actor) => approverOrPerson(actor, signedIn);
  const rows = [];
  if (people.draftedBy) rows.push({ term: "Drafted by", text: who(people.draftedBy) });
  else if (people.draftedByKey) rows.push({ term: "Drafted by", text: approverLabel({ recorded: people.draftedByKey, signedIn }) });
  else if (people.draftedByVert) rows.push({ term: "Drafted by", text: "Vert" });
  // A set-aside entry (Rejected, Withdrawn, Replaced) will not be approved: its header
  // says who set it aside and why, and "Approved by · Nobody yet" beside it read as still
  // waiting (staging browser walk 5).
  const setAside = Boolean(people.rejected || (people.current && people.current.outcomeWord));
  if (people.approvedBy) {
    rows.push({ term: "Approved by", text: people.selfApproved ? `${who(people.approvedBy)} (who also drafted it)` : who(people.approvedBy) });
  } else if (!setAside) {
    rows.push({ term: "Approved by", text: "Nobody yet", quiet: true });
  }
  if (people.posted) {
    const when = people.postedAt ? formatDate(people.postedAt) : null;
    const by = people.postedBy ? who(people.postedBy) : null;
    // The act's name says what the ledger holds (p1/fix5): "Sent to Xero as a draft",
    // "Posted in Xero"; with no ledger state said, "Posted" as before.
    rows.push({ term: ledgerStatusTerm(people.ledgerStatus, people.ledgerName), text: [by ? `by ${by}` : null, when ? `on ${when}` : null].filter(Boolean).join(" ") || "Yes" });
  }
  return rows;
}

function approverOrPerson(actor, signedIn) {
  return isCredentialActor(actor) ? approverLabel({ recorded: actor, signedIn }) : actor;
}

/**
 * THE ROW THE SHEET'S HEADER IS DRAWN FROM (UI walk D9, 30 Oct 2026). The header read the
 * list row the sheet opened with, so after Approve it still said "Needs you · Entry ready
 * to approve" beside "Approved by", and after Post "Not posted yet" beside "Posted by",
 * until a reload. The sheet reads the entry again after every press it makes; its status
 * word, its reason and the ledger's number come from that read when it has them. A read
 * that failed, or one with no word, keeps the row as listed.
 *
 * A REJECTED ENTRY SAYS SO (staging browser walk 4, W4-5). The engine gives a set-aside
 * entry no status word, only its outcome ("Rejected"), so the sheet kept "Needs you ·
 * Entry ready to approve" after Reject. It now reads "Rejected by <who> · <reason>",
 * the person worded for the viewer (`signedIn`). Pure.
 */
export function sheetRowOf(row, people, { signedIn = null } = {}) {
  const now = people && people.read && people.current ? people.current : null;
  if (!row || !now) return row;
  if (now.posted) return { ...row, posted: now.posted, reference: now.posted.number || row.reference };
  if (!isStatusWord(now.statusWord) && now.outcomeWord) {
    const rejected = people.rejected || null;
    const by = rejected && rejected.by ? actorWords(rejected.by, { signedIn }) : null;
    return { ...row, posted: null, status: null, setAside: { word: now.outcomeWord, reason: now.statusWordReason, by, note: rejected ? rejected.note : null } };
  }
  if (!isStatusWord(now.statusWord)) return row;
  const unpostable = Boolean(people.noLedger && people.approvedUnposted);
  return { ...row, posted: null, status: { word: now.statusWord, reason: unpostable ? NO_LEDGER_ROW : now.statusWordReason, decisions: null } };
}

/**
 * WHAT THE SHEET OFFERS ON AN ENTRY STILL TO BE DECIDED (verify pass 3, S-E2E-7), or
 * null. The sheet said "Needs you · Entry ready to approve" with nothing to press, and
 * the approver had to find a conversation — which, for an entry drafted by hand, need
 * not hold its card at all. So:
 *
 *   awaiting approval  → Approve, here, through the same engine route the card uses
 *                         (lib/journal.js approveEntry), held behind the same duty gate
 *                         (lib/roles.js approveRefusal: a preparer, or the drafter where
 *                         the firm keeps duties apart, is told why before pressing; the
 *                         engine refuses them either way)
 *
 * THE DRAFTER IS NOT OFFERED APPROVE, WHATEVER SIGNED IN (UI walk D13, 30 Oct 2026). A
 * shared key reports no role and no segregation setting, so approveRefusal had nothing to
 * go on and drew Approve live for the key that typed the entry; the engine then refused
 * it (`drafter_cannot_approve`). The drafter is the person's name or the key as recorded
 * (`draftedByKey`), compared with the actor this session signs as, and only a firm that
 * relaxed the rule (`segregation: false`) is offered the press.
 *   approved, unposted → said in words; the post is made where its post sheet restates
 *                         the lines, and the conversation is linked when there is one
 *   approved, no ledger → the engine's ledger reason and remedy (verify pass 4, P24):
 *                         no post sheet can open, so none is promised
 *
 *   approved, month signed off → Post held, with the reason (UI walk 2, N2): the engine
 *                         refuses a post into a signed-off month, so the press is drawn
 *                         disabled and says what to do, never offered to be refused
 *
 * Pure: `{ kind: "approve", gate, conversation } | { kind: "post", conversation, closed? }
 *       | { kind: "noledger", conversation, ledger }`. `signedOff`: the entry's month
 * as read from `GET /close/{period}/lock` (true, false, or null when not read).
 */
export { closedPostReason };

export function entryDecisionOf(people, { duties = null, actor = null, signedOff = null } = {}) {
  if (!people || !people.read) return null;
  const conversation = people.conversationId ? `/chat/${encodeURIComponent(people.conversationId)}` : null;
  if (people.awaiting) {
    const drafter = people.draftedBy || people.draftedByKey || null;
    const relaxed = Boolean(duties && duties.segregation === false);
    const own = !relaxed && drafter && actor && drafter === actor ? SEGREGATION_REASON : null;
    return { kind: "approve", gate: approveRefusal(duties, { drafter, actor }) || own, conversation, ...(people.mayReject === true ? { reject: true } : {}) };
  }
  // Nothing can post it (verify pass 4, P24): the engine's reason, never "post sheet".
  if (people.approvedUnposted && people.noLedger) return { kind: "noledger", conversation, ledger: people.noLedger };
  // The reason names what this sheet offers (W3-3): no Reject and no Undo here, so the
  // approval is undone in its conversation, when there is one to open.
  if (people.approvedUnposted) return { kind: "post", conversation, ...(people.mayReject === true ? { reject: true } : {}), ...(signedOff === true ? { closed: closedPostReason(people.period, { undo: conversation ? "conversation" : null }) } : {}) };
  return null;
}



/*
 * REVERSE, FROM THE SHEET (staging walkthrough D4, 27 Oct 2026). Vert entry 41's sheet
 * offered no Reverse, and the chat answered "reverse Vert entry 41" for the month. A
 * posted entry now offers it here, and the press opens or continues THAT entry's
 * reversal conversation through the same task the chat runs (`POST /agent/sessions
 * {period, template: "reverse_entry", subject: {kind: "entry", id}}`): one
 * conversation per entry, found again by a second press, and the task says plainly
 * when the original is only a draft in the ledger before drafting anything. A press
 * only: nothing is sent when the sheet opens.
 */
export const REVERSE_LABEL = "Reverse…";
export const OPEN_REVERSAL_LABEL = "Open its reversal";
export const REVERSE_SAMPLE_REASON = "Reversing needs your own books, not the sample.";
export const REJECT_SAMPLE_REASON = "Rejecting needs your own books, not the sample.";

const ENTRY_ID = /^[a-z]{1,16}:[0-9a-f]{6,64}$/;
const PERIOD = /^\d{4}-\d{2}$/;

/** What the sheet offers to reverse, or null: `{ kind: "reverse" | "reversed", label }`. Pure. */
export function entryReverseOf(people) {
  if (!people || !people.read || !people.posted || people.reverses) return null;
  if (people.reversal) return { kind: "reversed", label: OPEN_REVERSAL_LABEL };
  return { kind: "reverse", label: REVERSE_LABEL };
}

/** The conversation start the press sends, or null when it can't be named. Pure. */
export function reverseRequestOf(entryId, period) {
  if (typeof entryId !== "string" || !ENTRY_ID.test(entryId)) return null;
  if (typeof period !== "string" || !PERIOD.test(period)) return null;
  return { period, template: "reverse_entry", subject: { kind: "entry", id: entryId } };
}

function EntryReverse({ offer, entryId, period }) {
  const router = useRouter();
  const live = useWritesEnabled();
  const [state, setState] = useState({ busy: false, failed: false });
  if (!offer) return null;
  const request = reverseRequestOf(entryId, period);
  async function reverse() {
    if (!request) return;
    setState({ busy: true, failed: false });
    let result;
    try {
      result = await startConversation(request);
    } catch {
      result = { ok: false };
    }
    if (result && result.ok && result.sessionId) {
      router.push(`/chat/${encodeURIComponent(result.sessionId)}`);
      return;
    }
    setState({ busy: false, failed: true });
  }
  return (
    <div className="record-next" data-entry-reverse={offer.kind}>
      <Button variant="secondary" size="sm" onClick={reverse} busy={state.busy} busyLabel="Opening…" disabledReason={!live ? REVERSE_SAMPLE_REASON : !request ? "Vert doesn't know this entry's month." : null} data-entry-reverse-press="">
        {offer.label}
      </Button>
      {state.failed ? (
        <Notice kind="error" recorded="nothing" onRetry={reverse}>
          Vert couldn&rsquo;t open the reversal.
        </Notice>
      ) : null}
    </div>
  );
}

/**
 * REJECT, WHEN THE ENGINE SAYS IT MAY BE (staging browser walk 3, W3-6; `entry.mayReject`).
 * A recurring journal's draft offered only Approve, so a draft nobody wanted could not be
 * taken back. "Reject…" asks why in one line (the engine requires a reason), then sends
 * the existing `POST /journal/{id}/reject`. Nothing is sent until Reject is pressed.
 */
function EntryReject({ entryId, onDecided }) {
  const live = useWritesEnabled();
  const [asking, setAsking] = useState(false);
  const [reason, setReason] = useState("");
  const [state, setState] = useState({ busy: false, message: null });
  async function reject() {
    const why = reason.trim();
    if (!why || state.busy) return;
    setState({ busy: true, message: null });
    const result = await callSafely(rejectEntry, entryId, why);
    if (!result || !result.ok) {
      setState({ busy: false, message: (result && result.message) || "Not rejected. Nothing was recorded." });
      return;
    }
    setState({ busy: false, message: null });
    setAsking(false);
    onDecided();
  }
  if (!asking) {
    return (
      <Button variant="quiet" size="sm" destructive onClick={() => setAsking(true)} disabledReason={!live ? REJECT_SAMPLE_REASON : null} data-entry-reject="">
        Reject…
      </Button>
    );
  }
  return (
    <div className="record-reject" data-entry-reject-form="">
      <Field label="Why" value={reason} onChange={(e) => setReason(e.target.value)} maxLength={500} />
      <Button variant="quiet" size="sm" onClick={() => setAsking(false)}>
        Cancel
      </Button>
      <Button variant="secondary" size="sm" destructive onClick={reject} busy={state.busy} busyLabel="Rejecting…" disabledReason={reason.trim() ? null : "Say why first."} data-entry-reject-confirm="">
        Reject
      </Button>
      {state.message ? (
        <p className="task-problem t-footnote" role="alert">
          {state.message}
        </p>
      ) : null}
    </div>
  );
}

/** The decision area under the facts. Reads again after an approval it made. */
export function EntryDecision({ decision, entryId, onDecided, onRefused = null }) {
  const [state, setState] = useState({ busy: false, message: null });
  if (!decision) return null;
  async function approve() {
    setState({ busy: true, message: null });
    const result = await callSafely(approveEntry, entryId);
    if (!result || !result.ok) {
      setState({ busy: false, message: (result && result.message) || "Not approved. Nothing was recorded." });
      return;
    }
    setState({ busy: false, message: null });
    onDecided();
  }
  return (
    <div className="record-next" data-entry-decision={decision.kind}>
      {decision.kind === "approve" ? (
        <>
          {/* Disabled with its reason beside it, as a bill's Approve is (D13). */}
          <Button variant="commit" size="sm" onClick={approve} busy={state.busy} busyLabel="Approving…" disabledReason={decision.gate || null} data-entry-approve="">
            Approve
          </Button>
          {state.message ? (
            <p className="task-problem t-footnote" role="alert">
              {state.message}
            </p>
          ) : null}
        </>
      ) : decision.kind === "noledger" ? (
        <div className="t-footnote ink-2" data-entry-no-ledger="">
          <p>Approved, not posted. {decision.ledger.reason}</p>
          {decision.ledger.remedy ? <p>{decision.ledger.remedy}</p> : null}
        </div>
      ) : (
        // APPROVED, NOT POSTED: Post… here (verify pass 5, D01/D07), through the post
        // sheet that restates the lines before anything is written.
        <EntryPost entryId={entryId} onPosted={onDecided} onRefused={onRefused} closedReason={decision.closed || null} />
      )}
      {decision.reject ? <EntryReject entryId={entryId} onDecided={onDecided} /> : null}
      {decision.conversation ? (
        <Button variant="quiet" size="sm" href={decision.conversation} data-entry-conversation="">
          Open its conversation
        </Button>
      ) : null}
    </div>
  );
}

export default function EntryDetail({ row: listed, documents: given = undefined, period = null, onDecided = null }) {
  // The files filed against the entry (D08): the same chips the card draws, read from
  // the stored entry, so a posted entry keeps its evidence here too.
  const documents = useEntryDocuments(listed && listed.entryId, given);
  const entryId = listed.entryId || listed.id;
  const [people, setPeople] = useState(null);
  const [reads, setReads] = useState(0);
  // A post refused because the month is closed reads the month's lock again (UI walk 3,
  // W3-2): after Cancel, the refusal sat beside a live Post until the sheet was reopened.
  const [lockReads, setLockReads] = useState(0);
  const onRefused = () => setLockReads((n) => n + 1);
  const router = useRouter();
  const duties = useDuties();
  const actor = useSignedInActor();
  useEffect(() => {
    let live = true;
    setPeople(null);
    // A GET, shared with the documents read below (D4: two POSTs on every open).
    readEntry(entryId).then(
      (r) => live && setPeople(r && r.people ? r.people : { read: false }),
      () => live && setPeople({ read: false })
    );
    return () => {
      live = false;
    };
  }, [entryId, reads]);
  // Only an approved, unposted entry that a ledger can take asks whether its month is
  // signed off (a GET; a lock not read gates nothing).
  const signedOff = useMonthSignedOff(people && people.read && people.approvedUnposted && !people.noLedger ? people.period : null, lockReads);
  const decision = entryDecisionOf(people, { duties, actor, signedOff });
  // The list's row, moved on by this sheet's own last read (D9).
  const row = sheetRowOf(listed, people, { signedIn: actor });
  return (
    <div className="record-detail" data-entry-kind={row.kind || "unknown"}>
      <p className="record-status">
        <RecordStatus row={row} full />
      </p>
      <dl className="record-ids record-facts">
        <dt>Kind</dt>
        <dd>{row.kindLabel}</dd>
        <dt>Reference</dt>
        <dd>{quotable(row.reference) || <span className="ink-2" data-reference="none">{referenceWords(row)}</span>}</dd>
        <dt>Date</dt>
        <dd>{row.day || <span className="ink-2">No date</span>}</dd>
        <dt>Total</dt>
        <dd>
          <Figure cents={row.cents} measured={row.measured} unread="Total not available yet" style="table" figure={`entries/${row.id}/amount`} />
        </dd>
        {peopleRows(people, { signedIn: actor }).map((p) => (
          <div key={p.term} className="record-fact-pair" data-entry-people={p.term}>
            <dt>{p.term}</dt>
            <dd>{p.quiet ? <span className="ink-2">{p.text}</span> : p.text}</dd>
          </div>
        ))}
      </dl>
      <EntryDecision
        decision={decision}
        entryId={entryId}
        onRefused={onRefused}
        onDecided={() => {
          setReads((n) => n + 1);
          // The list behind the sheet moves with it (W8-2): Records reads it again.
          if (typeof onDecided === "function") onDecided();
          router.refresh();
        }}
      />
      <EntryReverse offer={entryReverseOf(people)} entryId={entryId} period={(people && people.period) || period} />
      <EntryDocuments documents={documents} className="record-documents" />
    </div>
  );
}
