"use client";

// components/records/PayoutDetail.js — ONE PAYOUT, AS THE RECORD SHEET SHOWS IT
// ==============================================================================
// Spec §3.5: "A row opens the record sheet: the breakdown, the evidence, ids under
// Details, and Ask Vert about this ›". This is the sheet's body, kept apart from the
// sheet so the harness (static markup, no clicks) can render it straight.
//
// VERDICT FIRST (spec §1.5). The status word and its reason lead; then what the payout
// is made of; then the bank; then the entry Vert drew, closed. Ids — the payout's, the
// processor's reference, the bank line's — sit under Details and nowhere above it.
//
// EVERY FIGURE IS THE ENGINE'S. Group nets, the difference, the entry's totals: each
// is a field on the payload, drawn through <Figure> and the one formatter. Nothing
// here adds a column or works out a difference; where the engine did not read a value
// the sheet says so in words (spec §9.4).
//
// ONE GAP FIGURE (the one-gap-figure guard). A payout whose parts do not match its
// deposit shows the engine's difference once, in the breakdown, and nowhere else.

import Link from "next/link";

import { Disclosure, Figure, FigureInText } from "@/components/ui";
import { bankLineLabel } from "@/lib/format";
import { CATEGORY_META } from "@/lib/payouts";
import { plainNarration } from "./model";
import { RecordStatus } from "./PostedMark";
import RecordPost, { approvedUnposted } from "./RecordPost";
import { unmeasuredOrderSplitReason } from "@/lib/trace/citations";
import { legAccount } from "@/components/cards/words";

import { IconCaretRight } from "@/components/ui/icons";
function paperHref(id, suffix = "") {
  return `/reconciliation/papers/${encodeURIComponent(id)}${suffix}`;
}

function bankLineById(engine, id) {
  const lines = Array.isArray(engine && engine.bankLines) ? engine.bankLines : [];
  return lines.find((line) => line.id === id) || null;
}

/** A bank line in words: the narration without its ids, its amount bound to the
 *  engine's line (rubric C1). */
function BankLineText({ line }) {
  const text = bankLineLabel({ ...line, description: plainNarration(line.description) });
  return <FigureInText text={text} cents={line.amount} figure={`bank/${line.id}/amount`} />;
}

/** What the bank says about this payout, in one sentence plus the line itself. */
function BankEvidence({ engine, recon }) {
  const tie = recon.tie || {};
  const inTransit = recon.payout && recon.payout.status === "in_transit";
  if (tie.status === "matched" && tie.bankId) {
    const line = bankLineById(engine, tie.bankId);
    return (
      <>
        <p className="record-lead">Matches the bank.</p>
        <p className="record-line">{line ? <BankLineText line={line} /> : "The bank line itself isn't in this close."}</p>
      </>
    );
  }
  if (tie.status === "ambiguous") {
    const candidates = (tie.candidates || []).map((id) => bankLineById(engine, id)).filter(Boolean);
    return (
      <>
        <p className="record-lead">More than one deposit could be it.</p>
        <ul className="record-list">
          {candidates.map((line) => (
            <li key={line.id} className="record-line">
              <BankLineText line={line} />
            </li>
          ))}
        </ul>
      </>
    );
  }
  if (inTransit) {
    return <p className="record-lead">On its way to the bank. It matches when the deposit lands.</p>;
  }
  return <p className="record-lead">No deposit found.</p>;
}

/** What the payout is made of: the engine's groups, and its difference if it has one. */
function Breakdown({ recon, id }) {
  const decomp = recon.decomp || {};
  const groups = Array.isArray(decomp.groups) ? decomp.groups : [];
  const currency = recon.payout && recon.payout.currency;
  if (recon.unreconcilable || groups.length === 0) {
    return (
      <p className="record-lead">
        Vert hasn&rsquo;t read what this payout is made of yet.
        {recon.unreconcilable ? <span className="record-why"> {recon.unreconcilable}</span> : null}
      </p>
    );
  }
  return (
    <>
      <ul className="record-rows">
        {groups.map((g) => (
          <li key={g.category} className="record-row">
            <span className="record-row-label">
              {(CATEGORY_META[g.category] && CATEGORY_META[g.category].label) || g.category}
              {Number.isInteger(g.count) ? <span className="record-row-detail"> · {g.count}</span> : null}
            </span>
            <Figure cents={g.net} measured={Number.isInteger(g.net)} unread="Not available yet" style="table" figure={`payouts/${id}/decomp/${g.category}/net`} />
          </li>
        ))}
      </ul>
      {decomp.integrityOk === false && Number.isInteger(decomp.delta) ? (
        <p className="record-gap">
          The parts don&rsquo;t match the payout. Difference{" "}
          <Figure cents={decomp.delta} unread="not available yet" figure={`payouts/${id}/decomp/delta`} />
          {currency ? ` ${currency}` : ""}.
        </p>
      ) : null}
    </>
  );
}

/**
 * The journal entry Vert drew, with the engine's totals.
 *
 * A PART-STATED ORDER SPLIT IS SAID ON THE ENTRY, IN THE ENGINE'S OWN WORDS, WHOLE.
 * When the processor stated only part of a split (product and shipping, no GST figure),
 * the engine withholds `orderSplit` and sends `orderSplitUnmeasuredReason` instead. The
 * register's entry printed that sentence above its lines; when G1 deleted the register
 * (2026-09-30) the sentence reached no screen at all, and tests/order-split-unmeasured
 * went red on exactly that. It is restored here, above the lines it qualifies, because
 * the GST line below it would otherwise read as a figure the source supplied.
 */
export function EntryLines({ recon, id }) {
  const je = recon.je || {};
  const lines = Array.isArray(je.lines) ? je.lines : [];
  if (!lines.length) return <p className="record-lead">No entry has been drawn for this payout yet.</p>;
  const splitUnmeasured = unmeasuredOrderSplitReason(recon.payout);
  return (
    <>
    {splitUnmeasured ? (
      <p className="record-why" data-split-unmeasured="">
        {splitUnmeasured}
      </p>
    ) : null}
    <table className="record-entry">
      <thead>
        <tr>
          <th scope="col">Account</th>
          <th scope="col" className="num-col">Debit</th>
          <th scope="col" className="num-col">Credit</th>
        </tr>
      </thead>
      <tbody>
        {lines.map((line, i) => (
          <tr key={`${line.account}-${i}`}>
            {/* The account named the way the cards name it, "1020 · Business Cheque"
                (cards/words.js legAccount), not the leg's raw words: Records and the
                approve card disagreed on one entry (bug bash 10 Oct 2026). */}
            <td translate="no">{legAccount(line)}</td>
            <td className="num-col num">{line.dr ? <Figure cents={line.dr} style="table" figure={`entries/${id}/lines/${i}/dr`} /> : null}</td>
            <td className="num-col num">{line.cr ? <Figure cents={line.cr} style="table" figure={`entries/${id}/lines/${i}/cr`} /> : null}</td>
          </tr>
        ))}
        <tr className="record-entry-total">
          <td>Total</td>
          <td className="num-col num">
            <Figure cents={je.sumDr} measured={Number.isInteger(je.sumDr)} unread="not available" style="table" figure={`entries/${id}/sumDr`} />
          </td>
          <td className="num-col num">
            <Figure cents={je.sumCr} measured={Number.isInteger(je.sumCr)} unread="not available" style="table" figure={`entries/${id}/sumCr`} />
          </td>
        </tr>
      </tbody>
    </table>
    </>
  );
}

/**
 * The sheet body. `row` is the payoutRecords row (its line and status); `focus` is
 * "entry" when it was opened from Journal entries, which opens the entry first.
 */
export default function PayoutDetail({ engine, row, focus = "payout" }) {
  const recon = engine && engine.reconciliations ? engine.reconciliations[row.id] : null;
  if (!recon) return <p className="record-lead">This payout isn&rsquo;t in this close.</p>;
  const payout = recon.payout || {};
  const tie = recon.tie || {};
  const entryFirst = focus === "entry";

  const entry = (
    <section className="record-section" aria-label="Journal entry">
      {entryFirst ? (
        <>
          <h3 className="record-heading t-label">Journal entry</h3>
          <EntryLines recon={recon} id={row.id} />
        </>
      ) : (
        <Disclosure summary="Journal entry">
          <EntryLines recon={recon} id={row.id} />
        </Disclosure>
      )}
    </section>
  );

  return (
    <div className="record-detail" data-record={row.id}>
      <p className="record-status">
        {/* The record's one status (PostedMark.js RecordStatus): opened from Journal
            entries, the row is the payout's ENTRY, and a posted entry reads as posted
            here exactly as it does in the row that opened it. */}
        <RecordStatus row={row} full />
      </p>

      {/* APPROVED, NOT POSTED: the post is offered here (verify pass 5, D01/D07). */}
      {approvedUnposted(engine, row.id) ? <RecordPost payoutId={row.id} line={row.line || null} /> : null}

      {entryFirst ? entry : null}

      <section className="record-section" aria-label="Breakdown">
        <h3 className="record-heading t-label">Breakdown</h3>
        <Breakdown recon={recon} id={row.id} />
      </section>

      <section className="record-section" aria-label="Bank">
        <h3 className="record-heading t-label">Bank</h3>
        <BankEvidence engine={engine} recon={recon} />
      </section>

      {entryFirst ? null : entry}

      <section className="record-section record-papers" aria-label="Working paper">
        <h3 className="record-heading t-label">Working paper</h3>
        <p className="record-links">
          <a className="link" href={paperHref(row.id)} target="_blank" rel="noopener">
            Open the working paper<IconCaretRight className="caret-trailing" />
          </a>
          <a className="link" href={paperHref(row.id, "?download=1")} title={`Download the working paper for ${row.line} as a file`}>
            Download
          </a>
          <a className="link" href={paperHref(row.id, "/xlsx")}>
            Excel
          </a>
        </p>
      </section>

      <Disclosure summary="Details" className="record-details">
        <dl className="record-ids">
          <dt>Payout</dt>
          <dd><code>{row.id}</code></dd>
          {payout.external_id && payout.external_id !== row.id ? (
            <>
              <dt>Processor reference</dt>
              <dd><code>{payout.external_id}</code></dd>
            </>
          ) : null}
          {tie.bankId ? (
            <>
              <dt>Bank line</dt>
              <dd><code>{tie.bankId}</code></dd>
            </>
          ) : null}
          {tie.bankId && bankLineById(engine, tie.bankId) && bankLineById(engine, tie.bankId).description ? (
            <>
              <dt>Narration</dt>
              <dd>{String(bankLineById(engine, tie.bankId).description)}</dd>
            </>
          ) : null}
          {payout.clearing ? (
            <>
              <dt>Clearing account</dt>
              <dd>{payout.clearing}</dd>
            </>
          ) : null}
        </dl>
      </Disclosure>
    </div>
  );
}

/** A bank line's sheet body: the line, and the payout it matches, if any. */
export function BankLineDetail({ row, onOpenPayout }) {
  // Every figure traceable (eval C2): the sheet leads with where the line was read and
  // the line itself, then the payout it matches — rows behind the number, not a title.
  const origin = row.origin || { from: "From your bank statement.", recorded: false };
  // The narration without its ids; the bank's own words are under Details (S6).
  const lineLabel = [row.day, row.description].filter(Boolean).join(" · ") || "The deposit";
  return (
    <div className="record-detail" data-record={row.id}>
      <section className="record-section" aria-label="Where this comes from">
        <h3 className="record-heading t-label">Where this comes from</h3>
        <p className="record-from">{origin.from}</p>
        {origin.recorded ? null : (
          <p className="record-why t-footnote">The file and row weren&rsquo;t recorded with this line.</p>
        )}
        <ul className="record-rows" data-source-rows="">
          <li className="record-row" data-source="bank">
            <span className="record-row-label">
              {lineLabel}
              <span className="record-row-detail"> · on the statement</span>
            </span>
            <Figure cents={row.cents} measured={row.measured} unread="Not available yet" style="table" figure={`bank/${row.id}/amount`} />
          </li>
          <li className="record-row" data-source="payout">
            <span className="record-row-label">
              {row.matched ? (
                onOpenPayout ? (
                  <button type="button" className="link" onClick={() => onOpenPayout(row.matched.id)}>
                    Matches <FigureInText text={row.matched.line} cents={row.matched.cents} measured={row.matched.measured} figure={`payouts/${row.matched.id}/amount`} /><IconCaretRight className="caret-trailing" />
                  </button>
                ) : (
                  <Link className="link" href={`/records?payout=${encodeURIComponent(row.matched.id)}`}>
                    Matches <FigureInText text={row.matched.line} cents={row.matched.cents} measured={row.matched.measured} figure={`payouts/${row.matched.id}/amount`} /><IconCaretRight className="caret-trailing" />
                  </Link>
                )
              ) : (
                "No payout matches this deposit."
              )}
            </span>
          </li>
        </ul>
      </section>
      <Disclosure summary="Details" className="record-details">
        <dl className="record-ids">
          <dt>Bank line</dt>
          <dd><code>{row.id}</code></dd>
          {row.narration && row.narration !== row.description ? (<><dt>Narration</dt><dd>{row.narration}</dd></>) : null}
          {origin.file ? (<><dt>File</dt><dd>{origin.file}</dd></>) : null}
          {origin.row !== null && origin.row !== undefined ? (<><dt>Row</dt><dd>{origin.row}</dd></>) : null}
        </dl>
      </Disclosure>
    </div>
  );
}
