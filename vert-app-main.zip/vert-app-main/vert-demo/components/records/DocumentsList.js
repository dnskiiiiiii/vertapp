"use client";

// components/records/DocumentsList.js — EVERY FILE VERT HOLDS FOR THIS CLIENT (verify pass 2, S-UI-2)
// ==============================================================================
// Records' fourth tab. A page of the engine's list at a time (documents-model.js), each
// file opening through the app (never the engine's own path), with Previous and Next
// as links so a page is an address. Search filters the page on screen.

import Link from "next/link";
import { useState } from "react";

import { Table } from "@/components/ui";
import { showsRegisterChrome } from "@/components/shared/registerChrome";
import { actorWords, formatDate } from "@/lib/format";
import { useSignedInActor } from "@/lib/store";
import { fileHref } from "@/components/chat/results/DocumentView";
import WorkbookView from "./WorkbookView";
import { workbookHref } from "./workbook-model";

const COLUMNS = [
  { key: "name", label: "File" },
  { key: "kind", label: "Kind" },
  { key: "pages", label: "Pages" },
  { key: "added", label: "Added" },
];

function pageHref(offset) {
  return offset > 0 ? `/records?tab=documents&offset=${offset}` : "/records?tab=documents";
}

export default function DocumentsList({ view, workbook = null }) {
  const [query, setQuery] = useState("");
  // Who added a file, as recorded ("key: founder"), worded against the viewer.
  const signedIn = useSignedInActor();
  if (!view || !view.read) {
    return (
      <p className="records-count" role="status" data-documents-unread="">
        {(view && view.words) || "Vert couldn't list its files just now."}
      </p>
    );
  }
  const q = query.trim().toLowerCase();
  const shown = q ? view.rows.filter((r) => r.name.toLowerCase().includes(q)) : view.rows;
  const rows = shown.map((r) => ({
    id: r.id,
    cells: {
      // A workbook opens its sheets here (verify pass 4, S-FL-7); any other file opens itself.
      name:
        r.kind === "Workbook" ? (
          <Link className="link" href={workbookHref(r.id, view.offset)} translate="no" aria-current={workbook && workbook.documentId === r.id ? "true" : undefined}>
            {r.name}
          </Link>
        ) : (
          <a className="link" href={fileHref(r.id)} target="_blank" rel="noreferrer" translate="no">
            {r.name}
          </a>
        ),
      kind: r.kind,
      pages: r.pages,
      added: [r.day ? formatDate(r.day) : null, r.by ? `by ${actorWords(r.by, { signedIn })}` : null].filter(Boolean).join(" ") || <span className="ink-2">Not recorded</span>,
    },
  }));
  return (
    <div className="records-documents" data-documents="">
      {workbook ? <WorkbookView view={workbook} backHref={view.offset > 0 ? `/records?tab=documents&offset=${view.offset}` : "/records?tab=documents"} /> : null}
      <div className="records-bar">
        <p className="records-count">{view.words}</p>
        {showsRegisterChrome(view.rows.length) ? (
          <label className="checklist-search-field records-documents-search">
            <input
              type="search"
              name="documentSearch"
              className="checklist-search-input"
              aria-label="Search the files on this page"
              placeholder="Search files…"
              autoComplete="off"
              spellCheck={false}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </label>
        ) : null}
      </div>
      {rows.length ? (
        <Table columns={COLUMNS} rows={rows} caption="Documents" className="records-table" />
      ) : q ? (
        <p className="records-count">No file on this page matches &ldquo;{query.trim()}&rdquo;.</p>
      ) : null}
      {view.previous !== null || view.next !== null ? (
        <nav className="records-documents-pages" aria-label="Pages of files">
          {view.previous !== null ? (
            <Link className="btn btn-secondary btn-sm" href={pageHref(view.previous)}>
              Previous
            </Link>
          ) : null}
          {view.next !== null ? (
            <Link className="btn btn-secondary btn-sm" href={pageHref(view.next)}>
              Next
            </Link>
          ) : null}
        </nav>
      ) : null}
    </div>
  );
}
