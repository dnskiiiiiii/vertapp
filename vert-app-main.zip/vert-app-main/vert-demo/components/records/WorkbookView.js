// components/records/WorkbookView.js — A STORED WORKBOOK'S SHEETS, IN RECORDS (verify pass 4, S-FL-7)
// ==============================================================================
// Opened from Records › Documents (`?document=<id>`). What the engine's reader found in
// the file, said to a person: each sheet with its state (a hidden or very hidden sheet
// says so), its merged ranges (or why they were not read), every formula as written
// with the value the FILE carries — "No value in the file" for one it never computed,
// never 0 — and a formula that links to another workbook marked as such. Then the
// sheet's cells, as written. Nothing here is recalculated (workbook-model.js).

import Link from "next/link";

import { Disclosure, Table } from "@/components/ui";
import { fileHref } from "@/components/chat/results/DocumentView";

const FORMULA_COLUMNS = [
  { key: "cell", label: "Cell" },
  { key: "formula", label: "Formula" },
  { key: "value", label: "Value in the file" },
];

const CELL_COLUMNS = [
  { key: "cell", label: "Cell" },
  { key: "content", label: "Content" },
];

function valueOf(c) {
  if (c.value !== null) return <span translate="no">{c.value}</span>;
  return <span className="ink-2">{c.valueWords}</span>;
}

function Sheet({ sheet }) {
  return (
    <section className="records-workbook-sheet" data-sheet={sheet.name} data-sheet-state={sheet.state || "unread"}>
      <h3 className="t-headline records-workbook-sheet-name" title={sheet.name}>
        <span translate="no">{sheet.name}</span>
        <span className="records-workbook-state" data-hidden={sheet.state && sheet.state !== "visible" ? "true" : undefined} data-state-word="">
          {sheet.stateWord}
        </span>
      </h3>
      {sheet.stateNote ? <p className="t-footnote ink-2">{sheet.stateNote}</p> : null}
      <dl className="record-ids record-facts records-workbook-facts">
        <dt>Size</dt>
        <dd>{sheet.size}</dd>
        <dt>Merged cells</dt>
        <dd data-merged={sheet.merged.read ? "read" : "unread"}>
          {sheet.merged.ranges.length ? <span translate="no">{sheet.merged.ranges.join(", ")}</span> : <span className="ink-2">{sheet.merged.words}</span>}
        </dd>
      </dl>
      {sheet.formulas.length ? (
        <Table
          columns={FORMULA_COLUMNS}
          rows={sheet.formulas.map((f) => ({
            id: f.coordinate,
            cells: {
              cell: f.coordinate,
              formula: (
                <span className="records-workbook-formula" data-external={f.external ? "true" : undefined}>
                  <code translate="no">{f.formula}</code>
                  {f.external ? <span className="ink-2"> · Links to another file</span> : null}
                </span>
              ),
              value: valueOf(f),
            },
          }))}
          caption={`Formulas on ${sheet.name}`}
          className="records-table records-workbook-table"
        />
      ) : null}
      {/* Every cell as written, folded: what the reader found is said above it, and at
          390 the stacked list ran to thousands of pixels before the next sheet. */}
      {sheet.cells.length ? (
        <Disclosure summary={`All ${sheet.cellsCut || sheet.cells.length} ${(sheet.cellsCut || sheet.cells.length) === 1 ? "cell" : "cells"} as written`} className="records-workbook-cells">
          <Table
            columns={CELL_COLUMNS}
            rows={sheet.cells.map((c) => ({
              id: c.coordinate,
              cells: { cell: c.coordinate, content: c.formula ? <code translate="no">{c.formula}</code> : valueOf(c) },
            }))}
            caption={`Cells on ${sheet.name}`}
            className="records-table records-workbook-table"
          />
        </Disclosure>
      ) : (
        <p className="t-footnote ink-2">No cells with anything in them.</p>
      )}
      {sheet.cellsCut ? <p className="t-footnote ink-2">The first {sheet.cells.length} of {sheet.cellsCut} cells. Open the file for the rest.</p> : null}
    </section>
  );
}

export default function WorkbookView({ view, backHref = "/records?tab=documents" }) {
  if (!view) return null;
  return (
    <section className="records-workbook" data-workbook={view.documentId} aria-labelledby="records-workbook-title">
      <div className="records-workbook-head">
        <h2 id="records-workbook-title" className="t-title-3 records-workbook-title" title={view.name || undefined}>
          {view.name || "Workbook"}
        </h2>
        <div className="records-workbook-links t-footnote">
          <Link className="link" href={backHref}>
            Close
          </Link>
          {view.documentId ? (
            <a className="link" href={fileHref(view.documentId)} target="_blank" rel="noreferrer">
              Open the file
            </a>
          ) : null}
        </div>
      </div>
      {!view.read ? (
        <p className="records-count" role="status" data-workbook-unread="">
          {view.words}
        </p>
      ) : (
        <>
          <p className="records-count" data-workbook-summary="">
            {view.summary}
          </p>
          {view.note ? <p className="t-footnote ink-2 records-workbook-note">{view.note}</p> : null}
          {view.sheets.map((s) => (
            <Sheet key={s.key} sheet={s} />
          ))}
        </>
      )}
    </section>
  );
}
