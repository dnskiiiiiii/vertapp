// components/records/entry-read-client.js — ONE JOURNAL ENTRY, READ FROM THE BROWSER WITH A GET
// ==============================================================================
// Staging walkthrough D4 (27 Oct 2026): opening Vert entry 41 on Records sent two
// `POST /records` requests with a `Next-Action` header before anyone pressed anything.
// The sheet's people (lib/entry-read.js readEntryPeople) and its filed documents
// (lib/journal.js readPostedEntry) were Server Actions called from effects: reads on
// the engine's side, writes on the wire, each riding back with a fresh render of the
// page. Both are one `GET /journal/{id}` upstream.
//
// Now: one `GET /api/journal?entry=<id>` (app/api/journal/route.js), answering both
// shapes at once — `{ ok, people, posted }` — and shared by every reader of the same
// entry while it is in flight (the sheet's people and its documents ask together).
// Nothing is cached past the answer, so a read after an approval asks again.
//
// A failed read is said as one (`people: { read: false }`, no documents), never an
// empty answer standing in for "nobody approved it" or "no files".

const ENTRY_ID = /^[a-z]{1,16}:[0-9a-f]{6,64}$/;

const UNREAD = Object.freeze({ ok: false, people: Object.freeze({ read: false }), posted: null });

const inFlight = new Map();

function unread() {
  return { ok: false, people: { read: false }, posted: null };
}

async function ask(entryId, fetchImpl) {
  try {
    const response = await fetchImpl(`/api/journal?entry=${encodeURIComponent(entryId)}`, {
      method: "GET",
      headers: { accept: "application/json" },
      cache: "no-store",
      credentials: "same-origin",
    });
    const body = response && typeof response.json === "function" ? await response.json().catch(() => null) : null;
    if (!response || !response.ok || !body || body.ok !== true) return unread();
    return {
      ok: true,
      people: body.people && typeof body.people === "object" ? body.people : { read: false },
      posted: body.posted && typeof body.posted === "object" ? body.posted : null,
    };
  } catch {
    return unread();
  }
}

/** `{ ok, people, posted }` for one entry, read with a GET. Never throws. */
export function readEntry(entryId, fetchImpl = null) {
  if (typeof entryId !== "string" || !ENTRY_ID.test(entryId)) return Promise.resolve(unread());
  const doFetch = fetchImpl || (typeof window !== "undefined" && typeof window.fetch === "function" ? window.fetch.bind(window) : null);
  if (!doFetch) return Promise.resolve(unread());
  const pending = inFlight.get(entryId);
  if (pending) return pending;
  const read = ask(entryId, doFetch).finally(() => inFlight.delete(entryId));
  inFlight.set(entryId, read);
  return read;
}

const NOT_READ = Object.freeze({ ok: false, confirmed: false, glExternalId: null, entryUrl: null, status: null });

/**
 * The posted reading (lib/journal.js readPostedEntry's shape: drafter, documents,
 * sources, ledgerStatus, je…) by the same GET, for a card's effect (staging D4 retest:
 * readPostedEntry from an effect was a POST /chat/<id> on arrival). Never throws.
 */
export async function readPostedByGet(entryId, fetchImpl = null) {
  const answer = await readEntry(entryId, fetchImpl);
  return answer && answer.ok && answer.posted ? answer.posted : { ...NOT_READ };
}

/**
 * Every journal entry again (`GET /api/journal?list`), after a decision in an entry's
 * sheet (staging browser walk 8, W8-2), or null when the read failed: the list then
 * stays as it was, never empty. Never throws.
 */
export async function readJournalList(fetchImpl = null) {
  const doFetch = fetchImpl || (typeof window !== "undefined" && typeof window.fetch === "function" ? window.fetch.bind(window) : null);
  if (!doFetch) return null;
  try {
    const response = await doFetch("/api/journal?list", {
      method: "GET",
      headers: { accept: "application/json" },
      cache: "no-store",
      credentials: "same-origin",
    });
    const body = response && typeof response.json === "function" ? await response.json().catch(() => null) : null;
    if (!response || !response.ok || !body || body.ok !== true) return null;
    return body.journal && Array.isArray(body.journal.entries) ? body.journal : null;
  } catch {
    return null;
  }
}

/** For tests: forget the reads in flight. */
export function forgetEntryReads() {
  inFlight.clear();
}

export { UNREAD };
