"use client";

// components/records/NewEntry.js — "NEW ENTRY": A ONE-OFF JOURNAL, WRITTEN BY HAND
// ==============================================================================
// scheduled-spec.md: Journals is no longer a module. Repeating journals live in
// Scheduled; a one-off journal is Month-end → Records "New entry" (or chat). The same
// editor the Journals page opened (components/cards/JournalEditor.js `create`), in a
// sheet: Save drafts the entry, which waits for a person's approval like any other.

import { useRouter } from "next/navigation";
import { useState } from "react";

import JournalEditor from "@/components/cards/JournalEditor";
import { Button, Notice, Sheet } from "@/components/ui";
import { IconAdd } from "@/components/ui/icons";
// The editor sheet's width (46rem, so Credit fits), as the Journals page drew it.
import "@/components/journals/journals.css";

export default function NewEntry({ period = null }) {
  const router = useRouter();
  const [writing, setWriting] = useState(false);
  const [saved, setSaved] = useState(null);
  return (
    <>
      <Button variant="secondary" icon={<IconAdd size={14} />} onClick={() => setWriting(true)} aria-haspopup="dialog" data-records-new-entry="">
        New entry
      </Button>
      {saved ? (
        <Notice kind="completion" onDismiss={() => setSaved(null)}>
          {saved}
        </Notice>
      ) : null}
      <Sheet open={writing} onClose={() => setWriting(false)} title="New journal entry" className="journals-editor-sheet">
        {writing ? (
          <JournalEditor
            create={{ period }}
            onDone={() => setWriting(false)}
            onSaved={(made) => {
              setWriting(false);
              const words = made && made.body && typeof made.body.words === "string" ? made.body.words : "Saved as a draft. Nothing is posted until someone approves it.";
              setSaved(words);
              router.refresh();
            }}
          />
        ) : null}
      </Sheet>
    </>
  );
}
