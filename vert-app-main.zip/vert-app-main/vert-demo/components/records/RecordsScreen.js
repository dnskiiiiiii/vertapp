"use client";

// components/records/RecordsScreen.js — RECORDS: THE EVIDENCE BEHIND THE MONTH
// ==============================================================================
// Spec §3.5; audit UI-001, UI-007, UI-031, UI-056, UI-063, UI-064.
//
//   ‹ September
//   Payouts · September
//   Payouts   Journal entries   Bank lines
//   31 payouts · [Needs you (4)]                                   Search
//   Stripe payout   2 Jul   $7,000.00   ● Needs you               ›
//
// WHAT IT REPLACES. /payouts, /approvals and /exceptions were three registers, each
// with a KPI strip, filter chrome, a pager and a status vocabulary of its own, and the
// same payout read "Blocked", "Exception" and "Awaiting you" a screen apart. Here there
// is one list per kind of record, one status column in the four words (the engine's,
// read by lib/payoutStatus.js), one filter — Needs you — and no pager: a list that
// scrolls hides nothing, where "page 1 of 3" hid how much was waiting.
//
// NOT A DESTINATION. Records is not in the sidebar (spec §2.1). It is reached from a
// figure's source sheet and a task row's "See all ›", and it leads back with
// "‹ September" to Month-end.
//
// THE CHROME IS EARNED. No search field at ten rows or fewer (components/shared/
// registerChrome.js, the register-chrome guard); above ten, one field, and nothing
// else. The Needs-you toggle's count is the length of the list it would show, and it
// is withheld when the payload carries no status words to count (spec §9.4).
//
// ONE MONTH, THE SIDEBAR'S (eval r1, S7/S9). `period` is the month the sidebar shows
// and counts its badge for (app/records/page.js reads it the same way); the lists are
// that month's records (model.js `scopeToMonth`), so "Needs you (4)" here and the
// badge's 4 are the same month's count. Without a period it lists every month's
// records under no month name, rather than naming a month it was not given.
//
// A ROW OPENS THE RECORD SHEET, a right sheet (a bottom sheet on a phone, where the
// kit's Table has already stacked the rows), with the breakdown, the bank, the entry,
// the working paper and "Ask Vert about this ›". `?payout=<id>` opens it on arrival —
// the old /payouts?payout= deep link, carried by the redirect, lands here — as do
// `?line=` and `?entry=` (the ledger memo's back-link). The record a link names is
// shown in its own month (model.js deepLinkScope), and `?period=` names a month outright.

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";

import { Figure, FigureInText, Notice, Sheet, Table } from "@/components/ui";
import EmptyState from "@/components/shared/EmptyState";
import { showsRegisterChrome } from "@/components/shared/registerChrome";
import { useEngine } from "@/lib/engine-context";
import { bankLineLabel } from "@/lib/format";
import { monthName } from "@/lib/period";
import { overlayCaveat } from "@/lib/assertion-overlay";

import AskAboutThis from "./AskAboutThis";
import DocumentsList from "./DocumentsList";
import AccountActivity, { AccountsList } from "./AccountActivity";
import EntryDetail from "./EntryDetail";
import { readJournalList } from "./entry-read-client";
import NewEntry from "./NewEntry";
import { RecordStatus, statusReasonFor } from "./PostedMark";
import PayoutDetail, { BankLineDetail } from "./PayoutDetail";
import {
  BANK_FILTERS,
  NEEDS_YOU_FILTER,
  TABS,
  bankFilterFrom,
  entryTotalFor,
  filterBankLines,
  journalAfterDecision,
  journalRecords,
  countWords,
  deepLinkScope,
  matchesQuery,
  needsYouOf,
  quotable,
  recordsHref,
  referenceWords,
  rowsFor,
  scopeToMonth,
  statusNoteFor,
  tabMeta,
} from "./model";

import { IconCaretLeft, IconCaretRight } from "@/components/ui/icons";
const STATEMENT_NOTE = "Your statement didn't carry a running balance, so none is shown.";

// The list's status cell is the record's one status (PostedMark.js RecordStatus), the
// same component its sheet draws, so the row and its sheet cannot say two words.
export { statusReasonFor };

function statusCell(row) {
  return <RecordStatus row={row} />;
}

function columnsFor(tab, { balances = false } = {}) {
  if (tab === "bank") {
    return [
      { key: "day", label: "Date" },
      { key: "description", label: "Bank line" },
      { key: "amount", label: "Amount", numeric: true },
      ...(balances ? [{ key: "balance", label: "Balance", numeric: true }] : []),
      { key: "matches", label: "Matches" },
    ];
  }
  if (tab === "entries") {
    // Every owner kind (build plan §4.6 FS): what the entry is for, then its kind and
    // the reference a bookkeeper quotes back, then the date, the total and the word.
    return [
      { key: "name", label: "Entry for" },
      { key: "kind", label: "Kind" },
      { key: "reference", label: "Reference" },
      { key: "day", label: "Date" },
      { key: "amount", label: "Total", numeric: true },
      { key: "status", label: "Status" },
    ];
  }
  return [
    { key: "name", label: tab === "entries" ? "Entry for" : "Payout" },
    { key: "day", label: "Date" },
    { key: "amount", label: tab === "entries" ? "Total" : "Amount", numeric: true },
    { key: "status", label: "Status" },
  ];
}

function cellsFor(tab, row) {
  // The reference names the record and the field, so a check can ask the API for it.
  const amount = <Figure cents={row.cents} measured={row.measured} unread="Amount not available yet" style="table" figure={`${tab}/${row.id}/amount`} />;
  if (tab === "bank") {
    return {
      day: row.day || "No date",
      description: row.description || "No description",
      amount,
      balance: <Figure cents={row.balance} measured={row.balance !== null} unread="Not on the statement" style="table" figure={`bank/${row.id}/balance`} />,
      matches: row.matched ? (
        <FigureInText text={row.matched.line} cents={row.matched.cents} measured={row.matched.measured} figure={`payouts/${row.matched.id}/amount`} />
      ) : (
        <span className="ink-2">No payout</span>
      ),
    };
  }
  if (tab === "entries") {
    return {
      name: row.name,
      kind: row.kindLabel || "Payout",
      reference: quotable(row.reference) ? <span className="records-ref">{quotable(row.reference)}</span> : <span className="ink-2" data-reference="none">{referenceWords(row)}</span>,
      day: row.day || "No date",
      amount,
      status: statusCell(row),
    };
  }
  return { name: row.name, day: row.day || "No date", amount, status: statusCell(row) };
}

/**
 * A RECORD IN ANOTHER MONTH IS SHOWN THERE, AND THE PERSON'S MONTH IS LEFT ALONE
 * (verify pass 3, S-E2E-7). Pass 2 (P19) made a link into another month move the
 * sidebar with it, so opening August's reversal from July switched Sam's month to
 * August, and Month-end with it. The list is still the record's own month (deepLinkScope),
 * but the visible month is the person's choice: the screen says the record is
 * elsewhere and offers the way back, in one quiet line. Null when nothing moved. Pure.
 */
export function elsewhereLine({ moved, scope, period, tab }) {
  if (!moved || !scope || !period || scope === period) return null;
  const there = monthName(scope);
  const here = monthName(period);
  if (!there || !here) return null;
  const what = tab === "bank" ? "This bank line" : tab === "entries" ? "This entry" : "This payout";
  return {
    text: `${what} is in ${there}. Your month is still ${here}.`,
    back: `Show ${here}`,
    href: recordsHref({ tab }),
  };
}

export default function RecordsScreen({ tab = "payouts", filter = null, payoutId = null, lineId = null, entryId = null, period = undefined, pinned = false, journal: journalRead0 = null, entryPeriod = null, documents = null, workbook = null, accounts = null, activity = null }) {
  const engine = useEngine();
  const router = useRouter();
  // THE LIST MOVES WITH ITS SHEET (staging browser walk 8, W8-2): a decision pressed in
  // an entry's sheet reads the journal again, and that reading is the list until the
  // page's next one arrives. Before, a Reject left "Needs you (3)" and the month's total
  // with the rejected entry in it until a reload.
  const [journal, setJournal] = useState(journalRead0);
  useEffect(() => setJournal(journalRead0), [journalRead0]);
  const entryDecided = useCallback(async () => {
    const reread = await readJournalList();
    setJournal((now) => journalAfterDecision(now, reread));
  }, []);
  const meta = tabMeta(tab);

  // Every record of this kind (a deep link may name one from another month), and the
  // month's own — which is what the list, the count and the Needs-you toggle are of.
  const all = useMemo(() => rowsFor(engine, tab, journal), [engine, tab, journal]);
  // The record a link names: a bank line, else an entry (the memo's back-link), else a
  // payout. ITS month is the month shown (model.js deepLinkScope, P19): scoped only when
  // told the month — the page always tells it — and a render that names none (a test of
  // the whole corpus) lists everything.
  const initial = tab === "bank" ? lineId : (tab === "entries" && entryId) || payoutId;
  const linked = deepLinkScope(all, initial, period ?? null);
  const scope = linked.period ?? null;
  // The month travels in the tabs and filters only when it is not the sidebar's.
  const keepPeriod = pinned || linked.moved ? scope : null;
  const openOnArrival = linked.found ? linked.rowId : null;
  const journalRead = tab === "entries" ? journalRecords(engine, journal).journalRead : true;
  const scoped = useMemo(() => scopeToMonth(all, scope), [all, scope]);
  const listed = scoped.rows;
  const month = (scoped.scoped && monthName(scope)) || null;
  const needs = useMemo(() => needsYouOf(listed), [listed]);
  const statusNote = statusNoteFor(listed);
  const filterable = tab !== "bank" && needs.measured;
  const [needsOnly, setNeedsOnly] = useState(filterable && filter === NEEDS_YOU_FILTER);
  const [query, setQuery] = useState("");
  const [bankFilter, setBankFilter] = useState(tab === "bank" ? bankFilterFrom(filter) : "all");

  // The sheet: which record is open. A deep link opens its record on arrival.
  const [openId, setOpenId] = useState(() => openOnArrival);
  const [used, setUsed] = useState(Boolean(openId));
  useEffect(() => {
    setOpenId(openOnArrival);
  }, [openOnArrival]);

  const chrome = showsRegisterChrome(listed.length);
  const base = tab === "bank" ? filterBankLines(listed, bankFilter) : needsOnly ? needs.rows : listed;
  // The statement's own balance column, shown only when the statement carried one.
  const balances = tab === "bank" && listed.some((row) => row.balance !== null);
  // The month's total, the ENGINE's (model.js `entryTotalFor`); words when it sent none.
  const total = tab === "entries" && scoped.scoped ? entryTotalFor(journal, scope) : null;
  const shown = chrome ? base.filter((row) => matchesQuery(row, query)) : base;

  function toggleNeeds() {
    showNeeds(!needsOnly);
  }

  function showNeeds(next) {
    setNeedsOnly(next);
    router.replace(recordsHref({ tab, filter: next ? NEEDS_YOU_FILTER : null, period: keepPeriod }), { scroll: false });
  }

  function showBank(next) {
    setBankFilter(next);
    router.replace(recordsHref({ tab, filter: next === "all" ? null : next, period: keepPeriod }), { scroll: false });
  }

  function open(id) {
    setUsed(true);
    setOpenId(id);
  }

  const rows = shown.map((row) => ({
    id: row.id,
    selected: row.id === openId,
    onOpen: () => open(row.id),
    cells: cellsFor(tab, row),
  }));

  const openRow = openId ? all.find((row) => row.id === openId) : null;
  // A bank line's sheet can hand over to the payout it matches.
  const payoutRows = useMemo(() => (tab === "bank" ? rowsFor(engine, "payouts") : null), [engine, tab]);
  const [handedTo, setHandedTo] = useState(null);
  const handedRow = handedTo && payoutRows ? payoutRows.find((row) => row.id === handedTo) : null;
  const sheetRow = handedRow || openRow;

  // A file is the client's, not a month's: the Documents tab names no month.
  const title = tab === "documents" ? meta.label : tab === "accounts" ? `${meta.label}${period ? ` · ${monthName(period)}` : ""}` : `${meta.label}${month ? ` · ${month}` : ""}`;
  // WHEN THE API COULD NOT APPLY A REVIEWER'S RECORDED ANSWERS, the figures below are
  // the vendor's unamended reading, and the list says so ABOVE them — the fact on the
  // face, the explanation and the engine's own reason one press down. The register
  // carried this (components/shared/OverlayCaveat.js) until G1 deleted it with the
  // register screens on 2026-09-30; tests/assertion-overlay.test.js found Records, which
  // replaced it, silent on the same payload, and holds this call site now. Null on the
  // static showpiece (no overlay layer to lose) and on a read that applied them.
  const caveat = overlayCaveat(engine);
  const elsewhere = elsewhereLine({ moved: linked.moved, scope, period, tab });
  const filteredOut = base.length === 0 && needsOnly && listed.length > 0;

  return (
    <div className="records">
      <header className="records-head">
        {/* Back goes to Month-end, which shows the sidebar's month: it is named only
            when that is the month on this screen. */}
        <Link href="/" className="records-back">
          <IconCaretLeft className="caret-leading" />{(!keepPeriod && month) || "Month-end"}
        </Link>
        <div className="records-title-row">
          <h1 className="t-title-1 records-title">{title}</h1>
          {tab === "entries" ? <NewEntry period={entryPeriod || period || null} /> : null}
        </div>
        {elsewhere ? (
          <p className="records-elsewhere t-footnote" data-records-elsewhere="">
            {elsewhere.text}{" "}
            <Link href={elsewhere.href}>{elsewhere.back}</Link>
          </p>
        ) : null}
      </header>

      <nav className="records-tabs" aria-label="Records">
        {TABS.map((t) => (
          <Link
            key={t.id}
            href={recordsHref({ tab: t.id, period: keepPeriod })}
            className="records-tab"
            aria-current={t.id === tab ? "page" : undefined}
          >
            {t.label}
          </Link>
        ))}
      </nav>

      {tab === "documents" ? <DocumentsList view={documents} workbook={workbook} /> : null}
      {tab === "accounts" ? (
        activity ? (
          <AccountActivity key={activity.request ? activity.request.account : "none"} first={activity.first} request={activity.request} month={period ? monthName(period) : null} period={pinned ? period : null} />
        ) : (
          <AccountsList view={accounts} period={pinned ? period : null} />
        )
      ) : null}
      {tab === "documents" || tab === "accounts" ? null : (
      <>
      <div className="records-bar">
        <p className="records-count">
          <span>{countWords(tab, listed.length)}</span>
          {tab !== "bank" && statusNote ? <span className="ink-2" data-status-note="">{` · ${statusNote}`}</span> : null}
          {scoped.undated > 0 ? (
            <span className="ink-2">
              {" "}
              · {countWords(tab, scoped.undated)} with no date {scoped.undated === 1 ? "isn't" : "aren't"} in any month
            </span>
          ) : null}
        </p>
        {filterable ? (
          <div className="records-filter" role="group" aria-label="Show">
            <button
              type="button"
              className="chip records-needs"
              aria-pressed={needsOnly ? "true" : "false"}
              onClick={() => showNeeds(true)}
            >
              Needs you ({needs.count})
            </button>
            <button type="button" className="chip records-all" aria-pressed={needsOnly ? "false" : "true"} onClick={() => showNeeds(false)}>
              All ({listed.length})
            </button>
          </div>
        ) : null}
        {tab === "bank" && listed.length > 0 ? (
          <div className="records-filter" role="group" aria-label="Show">
            {BANK_FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                className="chip"
                data-filter={f.id}
                aria-pressed={bankFilter === f.id ? "true" : "false"}
                onClick={() => showBank(f.id)}
              >
                {f.label} ({filterBankLines(listed, f.id).length})
              </button>
            ))}
          </div>
        ) : null}
        {chrome ? (
          <label className="records-search">
            <span className="sr-only">Search {meta.many}</span>
            <input
              type="search"
              className="field-input"
              name="recordsSearch"
              autoComplete="off"
              placeholder={`Search ${meta.many}…`}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </label>
        ) : null}
      </div>

      {linked.found === false ? (
        // A link named a record that is not among the ones Vert read: said, not a list
        // that silently lacks it (P19: a 200 on a page without the entry).
        <p className="records-note" role="status" data-link-unfound="">
          {`The ${meta.one} this link names isn't among the ${meta.many} Vert read just now. Nothing was changed.`}
        </p>
      ) : null}
      {!journalRead ? (
        <p className="records-note" data-journal-unread="">
          Payout entries only. Vert couldn't read its other entries (prepaid, manual and reversing) just now.
        </p>
      ) : null}
      {tab === "bank" && listed.length > 0 && !balances ? (
        <p className="records-note" data-statement-note="">{STATEMENT_NOTE}</p>
      ) : null}

      {caveat ? (
        <Notice kind="warning" details={[caveat.body, caveat.detail].filter(Boolean).join(" ")} className="records-caveat">
          <span data-overlay-state={caveat.state}>{`${caveat.title}. ${caveat.short}`}</span>
        </Notice>
      ) : null}

      {listed.length === 0 ? (
        <EmptyState lead={`No ${meta.many}${month ? ` for ${month}` : ""} yet.`}>
          {tab === "bank" ? (
            <>
              They arrive with a bank statement. <Link className="link" href="/connections">Connections<IconCaretRight className="caret-trailing" /></Link>
            </>
          ) : tab === "entries" ? (
            "Vert drafts an entry once it has read what a payout is made of."
          ) : (
            <>
              They arrive when Stripe syncs. <Link className="link" href="/connections">Connections<IconCaretRight className="caret-trailing" /></Link>
            </>
          )}
        </EmptyState>
      ) : tab === "bank" && base.length === 0 ? (
        <EmptyState lead={`No ${bankFilter === "matched" ? "matched" : "unmatched"} bank lines${month ? ` in ${month}` : ""}.`} total={listed.length} onClear={() => showBank("all")} clearLabel={`Show all ${listed.length}`}>
          {countWords(tab, listed.length)} are hidden by the filter.
        </EmptyState>
      ) : filteredOut ? (
        <EmptyState lead={`Nothing needs you in ${month ? `${month}'s ` : "these "}${meta.many}.`} total={listed.length} onClear={toggleNeeds} clearLabel={`Show all ${listed.length}`}>
          {countWords(tab, listed.length)} are hidden by the Needs-you filter.
        </EmptyState>
      ) : rows.length === 0 ? (
        <EmptyState lead={`No ${meta.many} match “${query}”.`} total={listed.length} onClear={() => setQuery("")} clearLabel="Clear the search">
          {countWords(tab, base.length)} are hidden by the search.
        </EmptyState>
      ) : (
        <Table
          columns={columnsFor(tab, { balances })}
          rows={rows}
          caption={title}
          className="records-table"
          foot={tab === "entries" && scoped.scoped ? { cells: entryFoot(total, month) } : null}
        />
      )}
      </>
      )}

      {used ? (
        <Sheet
          open={Boolean(sheetRow)}
          onClose={() => {
            setOpenId(null);
            setHandedTo(null);
          }}
          side="right"
          title={
            sheetRow ? (
              tab === "bank" && !handedRow ? (
                sheetLineTitle(sheetRow)
              ) : tab === "entries" && !sheetRow.payoutId ? (
                <FigureInText text={sheetRow.name} cents={sheetRow.cents} measured={sheetRow.measured} figure={`entries/${sheetRow.id}/amount`} />
              ) : (
                <FigureInText text={sheetRow.line} cents={sheetRow.payoutCents ?? sheetRow.cents} measured={sheetRow.measured} figure={`payouts/${sheetRow.payoutId || sheetRow.id}/amount`} />
              )
            ) : (
              ""
            )
          }
          className="record-sheet"
          footer={
            // An entry no payout owns has no subject a conversation can open on yet
            // (the engine's subjects are a payout and a bank line), so it offers none.
            sheetRow && !(tab === "entries" && !sheetRow.payoutId) ? (
              <AskAboutThis
                period={scope || engine.period}
                subject={tab === "bank" && !handedRow ? { kind: "bank_line", id: sheetRow.id } : { kind: "payout", id: sheetRow.payoutId || sheetRow.id }}
              />
            ) : null
          }
        >
          {sheetRow ? (
            tab === "bank" && !handedRow ? (
              <BankLineDetail row={sheetRow} onOpenPayout={(id) => setHandedTo(id)} />
            ) : tab === "entries" && !sheetRow.payoutId ? (
              <EntryDetail row={sheetRow} period={scope || engine.period} onDecided={entryDecided} />
            ) : (
              <PayoutDetail engine={engine} row={sheetRow.payoutId && sheetRow.payoutId !== sheetRow.id ? { ...sheetRow, id: sheetRow.payoutId } : sheetRow} focus={tab === "entries" ? "entry" : "payout"} />
            )
          ) : null}
        </Sheet>
      ) : null}
    </div>
  );
}

/**
 * The period total row's cells. The figure is the engine's month total, never a sum of
 * the rows (a filtered list would sum to whatever is on screen); without one the row
 * says so in words, so the row is there and nothing on it is invented.
 */
function entryFoot(total, month) {
  const label = `Total for ${month || "the month"}`;
  if (!total) {
    return { name: label, amount: <span className="figure-unread">Not totalled by Vert yet</span> };
  }
  return {
    name: label,
    amount: <Figure cents={total.cents} measured={total.measured} unread="Not totalled by Vert yet" style="table" figure="entries/period/total" />,
  };
}

function sheetLineTitle(row) {
  return bankLineLabel({ cents: row.cents, measured: row.measured, date: row.date, description: row.description });
}
