// components/records/workbook-model.js — A STORED WORKBOOK, AS THE ENGINE READ IT (verify pass 4, S-FL-7)
// ==============================================================================
// Records › Documents listed a workbook and opened nothing but the file itself, so what
// the engine's reader found in it — a hidden sheet, merged ranges, a formula whose file
// carries no result, a link to another workbook — was never shown to a person. This
// shapes `GET /documents/{id}/workbook` for the view (WorkbookView.js). Every fact is
// the engine's: the sheets and their state, the merged ranges (or why they were not
// read), each cell's formula as written and its value as the FILE caches it. Nothing is
// recalculated or summed here. The one reading made here is of a formula's own text: a
// reference in square brackets (`'[Budget 2027.xlsx]Sheet1'!B2`) names another file.

export const WORKBOOK_CELLS_SHOWN = 200;

/** What a formula's value is, said once above the sheets. */
export const FORMULA_NOTE = "Formulas are shown as written, each with the value the file itself carries from its last save. Vert doesn't recalculate them, so a formula the file never calculated has no value here.";

const DOCUMENT_ID = /^[A-Za-z0-9][A-Za-z0-9_-]{5,63}$/;

/** The document id a `?document=` names, or null. */
export function documentParam(value) {
  const v = Array.isArray(value) ? value[0] : value;
  return typeof v === "string" && DOCUMENT_ID.test(v) ? v : null;
}

/** `/records?tab=documents&document=<id>` (keeping the list's page). */
export function workbookHref(documentId, offset = 0) {
  const page = Number.isInteger(offset) && offset > 0 ? `&offset=${offset}` : "";
  return `/records?tab=documents${page}&document=${encodeURIComponent(documentId)}`;
}

const STATE_WORDS = {
  visible: "Visible",
  hidden: "Hidden",
  veryHidden: "Very hidden",
};

const STATE_NOTES = {
  hidden: "Hidden in the file. Excel lists it under Unhide.",
  veryHidden: "Very hidden in the file. Excel's own menus don't list it at all.",
};

/** Does this formula point at another workbook? `[Book.xlsx]` or a path before `[`. */
export function linksElsewhere(formula) {
  return typeof formula === "string" && /\[[^\]]+\.(xls[xmb]?|csv|ods)\]/i.test(formula);
}

const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const count = (n, one, many) => `${n} ${n === 1 ? one : many}`;

function cellOf(c) {
  const formula = text(c.formula);
  const uncached = c.valueKind === "uncached";
  return {
    coordinate: text(c.coordinate) || "?",
    formula,
    value: c.value === null || c.value === undefined ? null : String(c.value),
    // The engine's own reason a value is not known ("it is not zero and not blank").
    valueWords: uncached ? "No value in the file" : c.value === null || c.value === undefined ? text(c.valueNotMeasuredReason) || "Empty" : null,
    uncached,
    external: linksElsewhere(formula),
  };
}

function sheetOf(s, i) {
  const cells = (Array.isArray(s.cells) ? s.cells : []).filter((c) => c && typeof c === "object").map(cellOf);
  const state = typeof s.state === "string" && STATE_WORDS[s.state] ? s.state : null;
  const mergedRead = Array.isArray(s.mergedRanges);
  return {
    key: `${i}-${text(s.name) || "sheet"}`,
    name: text(s.name) || `Sheet ${i + 1}`,
    state,
    stateWord: state ? STATE_WORDS[state] : "Visibility not read",
    stateNote: state ? STATE_NOTES[state] || null : null,
    size:
      Number.isInteger(s.maxRow) && Number.isInteger(s.maxColumn)
        ? `${count(s.maxRow, "row", "rows")} by ${count(s.maxColumn, "column", "columns")}, ${count(Number.isInteger(s.cellCount) ? s.cellCount : cells.length, "cell", "cells")} with something in them`
        : `${count(cells.length, "cell", "cells")} with something in them`,
    merged: mergedRead
      ? { read: true, ranges: s.mergedRanges.filter((r) => typeof r === "string" && r), words: s.mergedRanges.length ? null : "No merged cells" }
      : { read: false, ranges: [], words: text(s.mergedRangesNotMeasuredReason) || "Vert couldn't read this sheet's merged cells." },
    formulas: cells.filter((c) => c.formula),
    cells: cells.slice(0, WORKBOOK_CELLS_SHOWN),
    cellsCut: cells.length > WORKBOOK_CELLS_SHOWN ? cells.length : null,
  };
}

/**
 * `{ read, words, documentId, name, note, summary, sheets }` from a read of
 * `GET /documents/{id}/workbook` (`{ ok, body }` | `{ ok: false }`). Pure.
 */
export function workbookView(answer, documentId) {
  const body = answer && answer.ok && answer.body && typeof answer.body === "object" ? answer.body : null;
  if (!body) {
    const words = answer && answer.status === 400 ? "This file isn't a workbook, so it has no sheets to show." : answer && answer.status === 404 ? "That file isn't one of this client's." : "Vert couldn't read this workbook just now.";
    return { read: false, words, documentId, name: null, note: null, summary: null, sheets: [] };
  }
  const name = text(body.originalFilename) || "This workbook";
  if (body.measured === false) {
    return { read: false, words: text(body.notMeasuredReason) || "Vert couldn't read this workbook's sheets.", documentId, name, note: null, summary: null, sheets: [] };
  }
  const sheets = (Array.isArray(body.sheets) ? body.sheets : []).filter((s) => s && typeof s === "object").map(sheetOf);
  const hidden = sheets.filter((s) => s.state === "hidden").length;
  const veryHidden = sheets.filter((s) => s.state === "veryHidden").length;
  // Counts of what is listed below, never a figure: each is the length of a list.
  const formulas = sheets.flatMap((s) => s.formulas);
  const merged = sheets.flatMap((s) => s.merged.ranges).length;
  const uncached = formulas.filter((f) => f.uncached).length;
  const external = formulas.filter((f) => f.external).length;
  // Sentences, not a run of middle dots (DA2-033).
  const sheetsSaid = [count(sheets.length, "sheet", "sheets")];
  if (hidden) sheetsSaid.push(`${hidden} hidden`);
  if (veryHidden) sheetsSaid.push(`${veryHidden} very hidden`);
  const parts = [`${sheetsSaid.join(", ")}.`];
  if (merged) parts.push(`${count(merged, "merged range", "merged ranges")}.`);
  if (external) parts.push(`${count(external, "formula links", "formulas link")} to another file.`);
  if (uncached) parts.push(`${count(uncached, "formula has", "formulas have")} no value in the file.`);
  return {
    read: true,
    words: null,
    documentId,
    name,
    // Vert's own sentence, not the engine's formulaNote: that one is written for an API
    // reader ("shown with valueKind 'uncached'"), and a person read it in Records.
    note: FORMULA_NOTE,
    summary: parts.join(" "),
    sheets,
  };
}
