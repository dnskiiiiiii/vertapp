"use client";

// components/records/RecordPost.js — POST… ON AN APPROVED ENTRY, IN RECORDS
// ==============================================================================
// Verify pass 5 (D01/D07, F-2; pass 4 F-5): an entry approved with "Approve only" on a
// configured ledger could be posted nowhere in the app. It left the approve-entries
// answer (which proposes drafts), its card in the conversation had folded, and Records
// said "Waiting" with nothing to press — while /payouts said "Approved, ready to post".
// Records is where every entry can be found, so the post is offered here: the same
// label rule as every card (words.js postActionLabel, worded by createsDraft), the
// ledger's own posting-effect sentence beside it, and the same post sheet the card
// opens, which restates the lines before anything is written. The engine's post route
// stays the gate (roles, the ledger, the tie-outs at the moment of posting).

import { useState } from "react";
import { Button } from "@/components/ui";
import PostSheet from "@/components/cards/PostSheet";
import { useCardLedger } from "@/components/cards/useCardLedger";
import { JournalPostSheet } from "@/components/cards/JournalCard";
import { callSafely } from "@/lib/decisions";
import { postEntry, readPostedEntry } from "@/lib/journal";
import { postingEffectOf } from "@/components/cards/ledger-effect";
import { unpostedLedgerNote } from "@/components/cards/ledger-note";
import { ledgerDisplayName } from "@/components/cards/journal-model";
import { failureSentence, ledgerStatusLead, ledgerStatusOf, postActionLabel } from "@/components/cards/words";
import DutyGate from "@/components/cards/DutyGate";
import { canPost, holdsAsDraft } from "@/lib/ledger-shape";
import { payoutStatus } from "@/lib/payoutStatus";
import { approveRefusal } from "@/lib/roles";
import { useDuties, useSignedInActor } from "@/lib/store";
import { closedMonthRefusal } from "@/components/month/useMonthSignedOff";

/** Whether the payout's recorded entry is approved and not yet posted. Pure. */
export function approvedUnposted(engine, payoutId) {
  const ps = payoutId ? payoutStatus(engine, payoutId) : null;
  return Boolean(ps && ps.recorded && ps.recorded.status === "approved");
}

/**
 * What the Records sheet draws for an approved, unposted payout entry, given the
 * ledger and the viewer's duty gate. Pure:
 *   { kind: "post", label, effect }   a ledger can take it
 *   { kind: "gate", words }           the viewer may not post (a preparer)
 *   { kind: "noledger", words }       nothing can post it; said, never promised
 */
export function recordPostOf(ledger, gate = null) {
  if (!canPost(ledger)) return { kind: "noledger", words: `Approved, not posted. ${unpostedLedgerNote(ledger)}` };
  if (gate) return { kind: "gate", words: gate };
  const name = ledgerDisplayName(ledger);
  return { kind: "post", label: `${postActionLabel(name, { draft: holdsAsDraft(ledger) })}…`, effect: postingEffectOf(ledger) };
}

/** The synthetic action the post sheet commits against: a plain post, settling no card. */
export function recordPostAction(payoutId, line = null) {
  return { kind: "records_post", actionId: null, target: { kind: "payout", id: payoutId }, prefill: { payoutId }, line: line || null, figures: {} };
}

/**
 * The line a Records post leaves behind (p1/fix5): "Sent to Xero as a draft · approve
 * it in Xero to post.", "Posted in Xero.", or "Posted." when the answer said nothing of
 * what the ledger holds. `answer` is the journal road's post result (`body.posted`) or
 * the post sheet's settle (`settled.result.body.posted`). Pure.
 */
export function recordPostedWords(answer, ledgerName = null) {
  const a = answer && typeof answer === "object" ? answer : {};
  const fromSettle = a.settled && a.settled.result && a.settled.result.body ? a.settled.result.body.posted : null;
  const status = ledgerStatusOf(a.body && a.body.posted, fromSettle);
  return `${ledgerStatusLead(status, ledgerName)}.`;
}

export default function RecordPost({ payoutId, line = null, ledger: given = null, onPosted = null }) {
  const ledger = useCardLedger(given);
  const gate = approveRefusal(useDuties(), { actor: useSignedInActor() });
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [posted, setPosted] = useState(null);
  const view = recordPostOf(ledger, gate);
  if (posted) {
    return (
      <p className="t-footnote" data-record-posted="">
        {recordPostedWords(posted, ledgerDisplayName(ledger))}
      </p>
    );
  }
  return (
    <div className="record-next" data-record-post={view.kind}>
      {view.kind === "post" ? (
        <>
          {view.effect ? (
            <p className="jcard-effect t-footnote" data-ledger-effect="">
              {view.effect}
            </p>
          ) : null}
          <Button
            variant="commit"
            size="sm"
            onClick={() => {
              setMounted(true);
              setOpen(true);
            }}
            data-record-post-open=""
          >
            {view.label}
          </Button>
          {mounted ? (
            <PostSheet
              open={open}
              onClose={() => setOpen(false)}
              action={recordPostAction(payoutId, line)}
              ledger={ledger}
              onPosted={(done) => {
                setOpen(false);
                setPosted(done || {});
                if (onPosted) onPosted(done);
              }}
            />
          ) : null}
        </>
      ) : view.kind === "gate" ? (
        <DutyGate reason={view.words} />
      ) : (
        <p className="t-footnote ink-2" data-entry-no-ledger="">
          {view.words}
        </p>
      )}
    </div>
  );
}

/**
 * POST… ON AN APPROVED MANUAL ENTRY (same finding): the entry is read from the API
 * (`GET /journal/{id}`, the lines the sheet restates), and the post goes through the
 * journal road's own route (lib/journal.js postEntry, with the entry's date).
 *
 * A REFUSED POST IS SAID IN THE CONFIRM THAT WAS PRESSED (UI walk 2, N2). The refusal was
 * drawn on the sheet behind the still-open "Record as posted" dialog, so the press seemed
 * to do nothing. It is now the confirm's own failure notice (JournalPostSheet `failure`,
 * as the card's is), and it stays on the sheet once the confirm is closed.
 * `closedReason`: the entry's month is signed off (EntryDetail reads it), so Post is drawn
 * disabled with that reason instead of being offered.
 *
 * A REFUSAL THAT SAYS THE MONTH IS CLOSED (UI walk 3, W3-2) is handed to `onRefused`, so
 * the sheet reads the month's lock again: after Cancel, the refusal sat beside a live
 * "Post to …" until the sheet was opened afresh. Opening the confirm again starts clean.
 */
export function EntryPost({ entryId, ledger: given = null, onPosted = null, onRefused = null, closedReason = null }) {
  const ledger = useCardLedger(given);
  const gate = approveRefusal(useDuties(), { actor: useSignedInActor() });
  const [open, setOpen] = useState(false);
  const [je, setJe] = useState(null);
  const [state, setState] = useState({ busy: false, message: null, failure: null, posted: null });
  const view = recordPostOf(ledger, gate);
  async function openSheet() {
    if (!je) {
      const reading = await callSafely(readPostedEntry, entryId);
      if (!reading || !reading.je) {
        setState({ busy: false, message: "Vert couldn't read the entry's lines just now, so nothing was posted.", failure: null, posted: null });
        return;
      }
      setJe(reading.je);
    }
    setState({ busy: false, message: null, failure: null, posted: null });
    setOpen(true);
  }
  async function confirm() {
    setState({ busy: true, message: null, failure: null, posted: null });
    const result = await callSafely(postEntry, entryId, je && je.date ? { entryDate: je.date } : undefined);
    if (!result || !result.ok) {
      // Said in words (failureSentence: the ledger's refusal in its words, engine w3/int
      // W3-1; the engine's own sentence, with no stored id), inside the open confirm.
      const failure = result && typeof result === "object" ? result : { ok: false, kind: "refused" };
      setState({ busy: false, message: failureSentence(result), failure, posted: null });
      if (onRefused && closedMonthRefusal(failure)) onRefused(failure);
      return;
    }
    setOpen(false);
    setState({ busy: false, message: null, failure: null, posted: result });
    if (onPosted) onPosted(result);
  }
  if (state.posted) {
    return (
      <p className="t-footnote" data-record-posted="">
        {recordPostedWords(state.posted, ledgerDisplayName(ledger))}
      </p>
    );
  }
  return (
    <div className="record-next" data-record-post={view.kind}>
      {view.kind === "post" ? (
        <>
          {view.effect ? (
            <p className="jcard-effect t-footnote" data-ledger-effect="">
              {view.effect}
            </p>
          ) : null}
          <Button variant="commit" size="sm" onClick={openSheet} disabledReason={closedReason || null} data-record-post-open="">
            {view.label}
          </Button>
          {je ? (
            <JournalPostSheet
              open={open}
              onClose={() => setOpen(false)}
              je={je}
              ledgerName={ledgerDisplayName(ledger)}
              draft={holdsAsDraft(ledger)}
              effect={view.effect}
              approving={false}
              busy={state.busy}
              failure={state.failure}
              disabledReason={closedReason || undefined}
              onConfirm={confirm}
            />
          ) : null}
        </>
      ) : view.kind === "gate" ? (
        <DutyGate reason={view.words} />
      ) : (
        <p className="t-footnote ink-2" data-entry-no-ledger="">
          {view.words}
        </p>
      )}
      {/* While the confirm is open its own notice says it; closed, the sheet keeps it. */}
      {state.message && !(open && state.failure) ? (
        <p className="task-problem t-footnote" role="alert">
          {state.message}
        </p>
      ) : null}
    </div>
  );
}
