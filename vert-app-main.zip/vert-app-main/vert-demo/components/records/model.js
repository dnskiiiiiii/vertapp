// components/records/model.js — WHAT RECORDS LISTS, AS PLAIN DATA
// ==============================================================================
// Spec §3.5. Records is evidence, not a destination: three lists — Payouts, Journal
// entries, Bank lines — reached from a figure's source sheet or a task row's "See all".
// Everything a row shows is read off the payload here, in one place, so the screen,
// the record sheet and the tests all see the same rows. Pure functions, no React: the
// harness renders static markup only, and a list that can be checked as data is a list
// whose counts can be checked without a browser.
//
// NOTHING HERE DOES ARITHMETIC. Every amount is an engine integer in cents that is
// carried, never combined; the only count on the page is the length of a list that is
// on the page (spec §13.9: compute the count from the list, or leave it out).
//
// ONE STATUS, FROM THE ENGINE. A row's status is `statusWordOf` (lib/payoutStatus.js),
// which reads the engine's word off the payload and never works one out. A payload
// that carries no word gives `null`, and the row says so in words; the Needs-you
// count is then withheld rather than printed as a zero nobody measured (spec §9.4).
//
// IDS NEVER LEAD. A row leads with its transaction ("Stripe payout · 2 Jul"); the id
// travels on the row for the sheet's Details and for the link, and is not a cell.

import { feedsFor } from "@/lib/feeds";
import { formatDay, journalNumberOf, ledgerNumber, metaLine, payoutLine, sourceName } from "@/lib/format";
import { entryIsDrafted, statusWordOf } from "@/lib/payoutStatus";
import { isStatusWord } from "@/lib/status";
import { NO_LEDGER_ROW, ledgerAbsence } from "@/lib/ledger-shape";
import { ledgerStatusOf } from "@/components/cards/words";

export const TABS = Object.freeze([
  { id: "payouts", label: "Payouts", one: "payout", many: "payouts" },
  { id: "entries", label: "Journal entries", one: "journal entry", many: "journal entries" },
  { id: "bank", label: "Bank lines", one: "bank line", many: "bank lines" },
  // The files Vert holds for this client (verify pass 2 S-UI-2: 1,000 documents and no
  // list of them anywhere but a conversation's context sheet). Not scoped to a month:
  // a file is the client's, not the month's.
  { id: "documents", label: "Documents", one: "document", many: "documents" },
  // One account's lines for the month (verify pass 3, S-BK-8: the engine pages a
  // 10,000-line month, and nothing in the app listed an account's lines at all).
  // Month-scoped, read a page at a time (AccountActivity.js, activity-model.js).
  { id: "accounts", label: "Accounts", one: "account", many: "accounts" },
]);

export const NEEDS_YOU_FILTER = "needs-you";

/** The tab a query string names, or Payouts. `approvals` was the old word for entries. */
export function tabFrom(value) {
  const v = typeof value === "string" ? value : "";
  if (v === "approvals") return "entries";
  return TABS.some((t) => t.id === v) ? v : "payouts";
}

export function tabMeta(tab) {
  return TABS.find((t) => t.id === tab) || TABS[0];
}

/**
 * `/records?tab=…&filter=…&payout=…&entry=…&period=…`, leaving out whatever is the
 * default. `period` is carried only when the screen was pinned to a month other than
 * the sidebar's (a `?period=` link, or a deep link to a record of another month), so
 * moving between tabs does not drop the person back into a month they did not ask for.
 */
export function recordsHref({ tab = "payouts", filter = null, payout = null, line = null, entry = null, period = null } = {}) {
  const params = new URLSearchParams();
  if (tab && tab !== "payouts") params.set("tab", tab);
  if (filter === NEEDS_YOU_FILTER && tab !== "bank") params.set("filter", NEEDS_YOU_FILTER);
  else if (tab === "bank" && (filter === "matched" || filter === "unmatched")) params.set("filter", filter);
  if (payout) params.set("payout", payout);
  if (line) params.set("line", line);
  if (entry) params.set("entry", entry);
  if (ISO_MONTH.test(String(period ?? ""))) params.set("period", period);
  const qs = params.toString();
  return qs ? `/records?${qs}` : "/records";
}

/** "N payouts" / "1 payout" — the noun for the tab, counted from the list shown. */
export function countWords(tab, n) {
  const meta = tabMeta(tab);
  return `${n} ${n === 1 ? meta.one : meta.many}`;
}

function amountOf(payout) {
  return Number.isInteger(payout && payout.amount) ? payout.amount : null;
}

/** The transaction line for a payout header, amount included. Never an id. */
export function transactionLine(header) {
  return payoutLine({
    source: header.source,
    date: header.arrival_date,
    cents: amountOf(header),
    measured: amountOf(header) !== null,
  });
}

/**
 * One row per payout, in the payload's order (the register's: oldest arrival first).
 *
 * `{ id, name, day, cents, measured, line, status }` — `name` is "Stripe payout",
 * `day` is "2 Jul" (null when the payload carries no date: a date is never invented),
 * `status` is `{ word, reason, decisions }` or null.
 */
export function payoutRecords(engine) {
  const { PAYOUTS } = feedsFor(engine);
  return PAYOUTS.map((header) => {
    const cents = amountOf(header);
    const name = sourceName(header.source);
    return {
      id: header.id,
      name: name ? `${name} payout` : "Payout",
      // The ISO date, carried for the month scope (`scopeToMonth`); `day` is what shows.
      date: typeof header.arrival_date === "string" && header.arrival_date ? header.arrival_date : null,
      day: typeof header.arrival_date === "string" && header.arrival_date ? formatDay(header.arrival_date) : null,
      cents,
      measured: cents !== null,
      line: transactionLine(header),
      // The processor's own reference for the settlement, the Reference a payout's
      // entry carries in Records. Null when the payload names none.
      reference: typeof header.external_id === "string" && header.external_id ? header.external_id : null,
      status: statusWordOf(engine, header.id),
    };
  });
}

/**
 * One row per journal entry Vert drew. An entry exists when it has lines
 * (lib/payoutStatus.js `entryIsDrafted`, the one place that is decided); a payout
 * with no transaction detail has no entry and is not listed as one with $0.00 on it.
 *
 * `cents` is the engine's own debit total (`je.sumDr`), carried, not added up.
 */
export function entryRecords(engine) {
  return payoutRecords(engine)
    .map((row) => {
      const je = engine.reconciliations[row.id] && engine.reconciliations[row.id].je;
      if (!entryIsDrafted(je)) return null;
      const total = Number.isInteger(je.sumDr) ? je.sumDr : null;
      const posted = payoutPosted(engine, row.id);
      return {
        ...row,
        // The ledger's own number once posted, as every other entry row quotes it.
        reference: quotable((posted && posted.number) || row.reference),
        payoutCents: row.cents,
        cents: total,
        measured: total !== null,
        balanced: je.balanced === true,
        lineCount: je.lines.length,
        kind: "payout",
        kindLabel: ENTRY_KINDS.payout,
        payoutId: row.id,
        posted,
      };
    })
    .filter(Boolean);
}

/**
 * One row per bank line the engine read, with the payout the engine tied to it.
 *
 * The match is the engine's (`matchedPayoutId` on the line, else a payout whose tie
 * names this line). A line nothing ties to says so; it is not a problem by itself —
 * most of a bank statement is not payouts.
 */
// A BANK LINE'S NARRATION IS THE BANK'S, AND IT CARRIES IDS (round-3 S6). Stripe
// writes its payout id into the statement narration ("STRIPE AU PAYOUT po_13Nt"),
// so the line as the bank printed it puts a raw id on the main path. The main path
// shows the narration with id-shaped tokens taken out; the bank's own words, ids
// and all, sit under Details as "Narration", where a bookkeeper matching a statement
// by hand can still find them.
const NARRATION_IDS = /\b(?:po|pi|ch|py|tr|txn|re|evt|ba|cus|acct|in|ipi|pyr)_[A-Za-z0-9]{3,}\b|\bSP-[A-Z0-9][\w-]*/g;

/** The bank's narration with processor and fixture ids removed, or "" if nothing is left. */
export function plainNarration(text) {
  return String(text ?? "")
    .replace(NARRATION_IDS, " ")
    .replace(/\s+/g, " ")
    .replace(/\s*[·:,;-]\s*$/, "")
    .trim();
}

export function bankLineRecords(engine) {
  const lines = Array.isArray(engine && engine.bankLines) ? engine.bankLines : [];
  const payouts = new Map(payoutRecords(engine).map((row) => [row.id, row]));
  const tiedBy = new Map();
  for (const id of payouts.keys()) {
    const tie = engine.reconciliations[id] && engine.reconciliations[id].tie;
    if (tie && tie.status === "matched" && tie.bankId) tiedBy.set(tie.bankId, id);
  }
  return lines.map((line) => {
    const cents = Number.isInteger(line.amount) ? line.amount : null;
    const payoutId = (line.matchedPayoutId && payouts.has(line.matchedPayoutId) && line.matchedPayoutId) || tiedBy.get(line.id) || null;
    const payout = payoutId ? payouts.get(payoutId) : null;
    return {
      id: line.id,
      day: typeof line.date === "string" && line.date ? formatDay(line.date) : null,
      date: line.date || null,
      description: plainNarration(line.description),
      narration: String(line.description ?? "").trim(),
      cents,
      measured: cents !== null,
      matched: payout ? { id: payout.id, line: payout.line, cents: payout.cents, measured: payout.measured } : null,
      // THE STATEMENT'S OWN RUNNING BALANCE, carried when the bank printed one
      // (`balance`, cents). Never accumulated here: a balance summed over the lines on
      // screen is wrong the moment one line is filtered out, or the month starts mid
      // statement. Null when the statement carried none, and the screen says so once.
      balance: Number.isInteger(line.balance) ? line.balance : Number.isInteger(line.runningBalance) ? line.runningBalance : null,
      origin: bankLineOrigin(line),
    };
  });
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * WHERE A BANK LINE CAME FROM (eval r2, C2: "every figure traceable")
 *
 * A bank line's sheet opened with its title and a link, and no row behind the
 * number: pressed, "$15,942.24" said nothing about where $15,942.24 was read. Every
 * other figure's sheet names its source; a deposit is the most source-shaped record
 * Vert holds — it IS a line of a statement — and its sheet was the one that didn't.
 *
 * The origin is read off the line, never worked out. The engine's `/bank-lines` view
 * today carries `{id, date, amount, description, matchedPayoutId}` and nothing about
 * provenance, so the sheet says "From your bank statement." and, in words, that the
 * file and row were not recorded with the line. It does NOT parse a row number out of
 * the id: "11 Jun line 9" happens to be a line number in the demo corpus, and an id
 * minted by a CSV import or a ledger feed is not — a row number read out of an id is
 * a row number made up. When the payload does carry provenance (`source: {kind, file,
 * feed, row}`, or the flat `sourceFile` / `feed` / `rowNumber` spellings the import
 * route already uses), the sentence names the file or the feed and the row.
 * ══════════════════════════════════════════════════════════════════════════ */

function textField(...values) {
  for (const v of values) {
    if (typeof v === "string" && v.trim()) return v.trim();
  }
  return null;
}

function rowField(...values) {
  for (const v of values) {
    if (Number.isInteger(v) && v > 0) return v;
  }
  return null;
}

/**
 * `{ from, file, feed, row, recorded }` for one bank line. `from` is the sentence the
 * sheet prints; `recorded` is false when the payload names neither a file nor a feed,
 * and the sheet then says so rather than leaving the gap unmarked.
 */
export function bankLineOrigin(line = {}) {
  const src = line && typeof line.source === "object" && line.source ? line.source : {};
  const file = textField(src.file, src.filename, line.sourceFile, line.source_file, line.file);
  const feed = file ? null : textField(src.feed, src.name, line.feed, typeof line.source === "string" ? line.source : null);
  const row = rowField(src.row, src.row_number, src.rowNumber, line.rowNumber, line.row_number);
  const parts = ["From your bank statement"];
  if (file) parts.push(file);
  else if (feed) parts.push(feed);
  if (row !== null) parts.push(`row ${row}`);
  return { from: `${metaLine(parts)}.`, file, feed, row, recorded: Boolean(file || feed) };
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * EVERY JOURNAL ENTRY, OF EVERY OWNER (build plan §4.6 FS; audit 16/19)
 *
 * Records listed only the entries Vert drew for payouts, because the close payload is
 * built around payouts. Iteration 2 drafts entries from four places — a payout, a
 * prepaid schedule, a person's own manual entry, and a reversal of any of those — and
 * an entry a bookkeeper approved from chat that Records then could not find is an
 * entry they cannot audit. The engine lists them all at `GET /journal?state=all`; the
 * page reads that (app/records/page.js) and hands it here as `journal`.
 *
 * WITHOUT THAT LIST (the static showpiece, or a read that failed) the payout entries
 * in the payload are still listed, and `journalRead` says the others were not read —
 * a list of payout entries is not "every entry", and the screen says so in words.
 *
 * THE REFERENCE is what a bookkeeper would quote back: the ledger's own number once
 * the entry is posted, else the processor's reference for a payout's entry, else
 * NOTHING — the cell then says why in words (`referenceWords`: "Not posted yet").
 * Vert's own entry key (`je:…`) is never a reference: it is an engine id no
 * bookkeeper can quote to the ledger, and verify pass 2 (U10, U63) found it printed in
 * this column. It stays on the row as `entryId`, for links and the API, never as words.
 * The reference is a column, never the row's lead: the row leads with what it is for.
 *
 * THE STATUS is the engine's word. A payout's entry carries its payout's word (the
 * entry IS that payout's decision); any other entry carries `statusWord` when the
 * engine sends one, and `null` otherwise — never a word worked out here from its
 * approval state, which is exactly the second vocabulary lib/status.js exists to end.
 * ══════════════════════════════════════════════════════════════════════════ */

export const ENTRY_KINDS = Object.freeze({
  payout: "Payout",
  prepaid: "Prepaid",
  schedule: "Schedule",
  asset: "Fixed asset",
  payroll: "Payroll",
  reclass: "Reclass",
  manual: "Manual",
  reversal: "Reversal",
});

function isoText(...values) {
  for (const v of values) if (typeof v === "string" && v.trim()) return v.trim();
  return null;
}

const ISO_PERIOD = /^\d{4}-(?:0[1-9]|1[0-2])$/;

/* ITERATION 3 OWNERS (build plan §19.10 F-POL). Iteration 3 drafts entries from four
 * more roads: a schedule's release (deferred revenue, amortisation, accruals), the
 * asset register's depreciation, a payroll accrual, and the capitalisation reclass a
 * fixed-asset roll-forward proposes. Each one listed as "Unknown source" or "Manual"
 * was an entry a bookkeeper could not tell apart from one they wrote by hand.
 *
 * WHERE THE OWNER IS READ, in this order:
 *   1. the entry's own SOURCE kind (`source.kind`, the `journal_entries.source`
 *      column): `schedule` and `fixed_asset` are stored on the entry by the engine's
 *      schedule and asset roads, so they are read first. The record's kind is not
 *      enough on its own: `_owner` names every schedule-owned entry
 *      `prepaid_schedule`, whichever schedule road drew it.
 *   2. an explicit origin when the engine sends one (`origin`, `manual.origin` or the
 *      record's kind): `payroll`, `reclass`, `depreciation`.
 *   3. a manual draft whose memo is one of the engine's OWN memo templates —
 *      "Accrue {month} payroll" (payroll_accrual.draft_bodies), "Capitalise {what} to
 *      {cost}" and "{month} depreciation from the asset register"
 *      (fixed_asset_rollforward RECLASS_MEMO / DEPRECIATION_MEMO). Those roads save
 *      their drafts through `POST /journal/drafts`, so the stored owner is a manual
 *      draft and nothing else says where it came from; the memo is the engine's
 *      sentence, matched whole (anchored), never a guess from a word in a person's
 *      memo. When the engine stores an origin, (2) wins and this is never reached.
 */
const PAYROLL_MEMO = /^Accrue [A-Z][a-z]+(?: \d{4})? payroll$/;
const RECLASS_MEMO = /^Capitalise .+ to .+$/;
const DEPRECIATION_MEMO = /^[A-Z][a-z]+(?: \d{4})? depreciation from the asset register$/;
const ORIGINS = Object.freeze({ payroll: "payroll", reclass: "reclass", depreciation: "asset", fixed_asset: "asset", asset: "asset", schedule: "schedule" });

/** The owner kind of one `GET /journal` entry, in ENTRY_KINDS' keys, or null. */
export function entryKindOf(entry) {
  const manual = entry && entry.manual && typeof entry.manual === "object" ? entry.manual : null;
  if (isoText(entry && entry.reverses, manual && manual.reverses)) return "reversal";
  const source = entry && entry.source && typeof entry.source === "object" ? entry.source : {};
  const owner = source.record ? source.record.kind : null;
  if (owner === "payout") return "payout";
  if (source.kind === "schedule") return "schedule";
  if (source.kind === "fixed_asset" || owner === "fixed_asset") return "asset";
  const origin = isoText(entry && entry.origin, manual && manual.origin, owner);
  if (origin && Object.hasOwn(ORIGINS, origin)) return ORIGINS[origin];
  // The engine's owner kind for a schedule's release (vert_api/routers/journal.py
  // `_owner`). Matched by its prefix: the full spelling is also a task template's id,
  // and no-false-affordance holds screens to naming only built tasks.
  if (typeof owner === "string" && /^prepaid/.test(owner)) return "prepaid";
  if (owner === "manual_journal") {
    const memo = isoText(entry.memo) || "";
    if (PAYROLL_MEMO.test(memo)) return "payroll";
    if (RECLASS_MEMO.test(memo)) return "reclass";
    if (DEPRECIATION_MEMO.test(memo)) return "asset";
    return "manual";
  }
  return null;
}

/* THE SPECIFIC KIND (W3, 27 Oct 2026). "Schedule" said which ROAD drew an entry, not what
 * it is: an accrual, an amortisation and a revenue release all read "Schedule", and a
 * recurring rent entry read "Manual". The engine now reports each entry's kind
 * (`entryKind`: the one its writer chose, else its inference) and the recurring template
 * that drafted it (`recurring`), so the Kind column names the entry itself. Read, never
 * worked out here; an entry the engine sends neither for keeps its owner's word.
 *
 * EVERY TYPE THE NEW-ENTRY PICKER OFFERS (UI walk D5, 30 Oct 2026): an entry typed
 * Adjusting listed as "Adjusting" on Journals and "Manual" here, because adjusting,
 * other and reversal had no word. Each is named as Journals names it. */
const SPECIFIC_KINDS = Object.freeze({
  adjusting: "Adjusting",
  other: "Other",
  reversal: "Reversal",
  accrual: "Accrual",
  amortisation: "Amortisation",
  revenue_release: "Revenue release",
  depreciation: "Depreciation",
  payroll: "Payroll",
  reclass: "Reclass",
  prepaid_release: "Prepaid",
});

/** The Kind column's words for one GET /journal entry whose owner kind is `kind`. Pure. */
export function kindLabelOf(entry, kind) {
  if (entry && entry.recurring && typeof entry.recurring === "object") return "Recurring";
  if (kind === "payout" || kind === "reversal") return ENTRY_KINDS[kind];
  const said = entry && typeof entry.entryKind === "string" ? entry.entryKind : null;
  if (said && Object.hasOwn(SPECIFIC_KINDS, said)) return SPECIFIC_KINDS[said];
  return kind ? ENTRY_KINDS[kind] : "Unknown source";
}

// Vert's own entry key, `je:` and its content hash: an id, never words on a screen.
const ENGINE_ENTRY_ID = /^je:/i;

/** A reference a bookkeeper can quote, or null — never Vert's own entry key. Pure. */
export function quotable(ref) {
  const text = isoText(ref);
  // Nor is a ledger's GUID (staging browser walk 1, D17: a Xero manual journal's id
  // printed as its Reference): Records says "Posted, no number" instead.
  return text && !ENGINE_ENTRY_ID.test(text) && ledgerNumber(text) ? text : null;
}

/**
 * What the Reference cell says when the entry has no reference: why, in words. A posted
 * entry the ledger has not numbered is "Posted, no number"; an entry that is Done
 * without being posted (replaced by an edit, discarded) will never have one — "Not
 * posted"; anything else is still on its way to the ledger — "Not posted yet".
 */
export function referenceWords(row) {
  if (!row) return "Not posted yet";
  const ref = quotable(row.reference);
  if (ref) return ref;
  if (row.posted) return row.posted.ledgerStatus === "draft" ? "Sent as a draft, no number" : "Posted, no number";
  if (row.status && row.status.word === "Done") return "Not posted";
  return "Not posted yet";
}

/** The engine's outcome word for an entry set aside (never "Posted": that is `posted`). */
export function outcomeWordOf(entry) {
  const word = entry && typeof entry.outcomeWord === "string" ? entry.outcomeWord.trim() : "";
  return word && word !== "Posted" ? word : null;
}

/** The engine's `entry.rejected` (w18 contract, W4-5) as `{ by, note }`, or null. */
export function rejectedOf(entry) {
  const r = entry && entry.rejected && typeof entry.rejected === "object" ? entry.rejected : null;
  if (!r) return null;
  const by = typeof r.by === "string" && r.by.trim() ? r.by.trim() : null;
  const note = typeof r.reason === "string" && r.reason.trim() ? r.reason.trim() : null;
  return by || note ? { by, note } : null;
}

/** One `GET /journal` entry as a Records row. */
function journalRow(engine, entry, payouts, byId, absence = null, ledger = null) {
  const kind = entryKindOf(entry);
  const manual = entry.manual && typeof entry.manual === "object" ? entry.manual : null;
  const ownerId = entry.source && entry.source.record ? entry.source.record.id : null;
  const payout = kind === "payout" && ownerId ? payouts.get(ownerId) || null : null;
  const reverses = isoText(entry.reverses, manual && manual.reverses);
  const reversed = reverses ? byId.get(reverses) : null;
  const date = isoText(entry.entryDate, manual && manual.entryDate, entry.date) || (payout ? payout.date : null);
  const occurrence = isoText(entry.occurrence);
  const period = isoText(entry.period, manual && manual.period) || (occurrence && ISO_PERIOD.test(occurrence) ? occurrence : null);
  const memo = isoText(entry.memo);
  const name =
    kind === "payout" ? (payout ? payout.name : "Payout entry")
    : kind === "prepaid" ? memo || "Prepaid expense release"
    : kind === "schedule" ? memo || "Schedule release"
    : kind === "asset" ? memo || "Depreciation"
    : kind === "payroll" ? memo || "Payroll accrual"
    : kind === "reclass" ? memo || "Capitalisation reclass"
    : kind === "reversal" ? (reversed && isoText(reversed.memo) ? `Reverses ${isoText(reversed.memo)}` : memo || "Reversing entry")
    : kind === "manual" ? memo || "Manual entry"
    : memo || "Entry";
  const total = Number.isInteger(entry.sumDr) ? entry.sumDr : null;
  const posted = postedOf(entry, ledger);
  // NOTHING CAN POST IT (verify pass 4, P24): with no ledger configured the engine's
  // reason is still "Approved, ready to post"; the row says why it will not be posted.
  const unpostable = Boolean(absence && !posted && entry.approvalState === "approved");
  const reason = unpostable ? NO_LEDGER_ROW : isoText(entry.statusWordReason);
  const word = isStatusWord(entry.statusWord) ? { word: entry.statusWord, reason, decisions: null } : null;
  // Set aside (walk 4, W4-5): no status word, the engine's outcome ("Rejected") instead.
  const outcome = !word && !posted ? outcomeWordOf(entry) : null;
  return {
    id: isoText(entry.externalId) || `${kind}:${ownerId}`,
    entryId: isoText(entry.externalId),
    kind,
    kindLabel: kindLabelOf(entry, kind),
    name,
    reference: quotable((posted && posted.number) || isoText(entry.number, entry.docNumber) || (payout && payout.reference)),
    date,
    period,
    day: date ? formatDay(date) : null,
    cents: total,
    measured: total !== null,
    payoutId: payout ? payout.id : null,
    payoutCents: payout ? payout.cents : undefined,
    line: payout ? payout.line : name,
    status: word || (payout ? payout.status : null),
    setAside: outcome && !payout ? { word: outcome, reason, ...(rejectedOf(entry) || { by: null, note: null }) } : null,
    posted,
    // `{ short, reason, remedy }` when this approved entry waits on a ledger that is not
    // there (lib/ledger-shape.js ledgerAbsence), else null.
    noLedger: unpostable ? absence : null,
  };
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * POSTED IS SAID ONE WAY (iteration 3 W0c; carry-over item 4, eval polish C6)
 *
 * Records called a posted entry "Done" — "Done · Posted" in its sheet — while
 * Month-end, the thread and the plate all said "Posted · Journal entry 3". Two
 * spellings of one fact a screen apart is the drift lib/status.js exists to end. The
 * engine's word for a posted entry is still Done, and it is still what Records COUNTS
 * (a Done row needs nobody); what the row SAYS is the plate's head, through the same
 * function (components/cards/PostedPlate.js postedHead), so the two cannot drift.
 *
 * Posted is read off the entry — its stored state or its approval road — never worked
 * out from a word. The number is the ledger's (`glExternalId`, as the post answered
 * it); an entry the ledger has not numbered says "Posted" and no number, never one
 * nobody read.
 * ══════════════════════════════════════════════════════════════════════════ */

// The number is lib/format.js ledgerNumber's: a Xero manual journal's GUID is its id,
// not a number (staging browser walk 1, D17), so it reads "Posted, no number".

/**
 * `{ number }` for a posted `GET /journal` (or payout-state) entry, else null; with
 * `{ ledgerStatus, ledgerName }` beside it when the engine said what the ledger holds
 * (p1/fix5: a Xero draft is "sent as a draft", never "Posted"). `ledgerName` is the
 * ledger's display name from the same answer (`GET /journal`'s `ledger`). Pure.
 */
export function postedOf(entry, ledger = null) {
  if (!entry || typeof entry !== "object") return null;
  const isPosted = entry.status === "posted" || entry.approvalState === "posted";
  if (!isPosted) return null;
  const held = ledgerStatusOf(entry);
  if (!held) return { number: journalNumberOf(entry) };
  const name = ledger && typeof ledger.displayName === "string" && ledger.displayName.trim() ? ledger.displayName.trim() : null;
  return { number: journalNumberOf(entry), ledgerStatus: held, ledgerName: name };
}

/** The payout's posted entry, from the reconciliation's recorded entries, or null. */
function payoutPosted(engine, payoutId) {
  const recon = engine && engine.reconciliations ? engine.reconciliations[payoutId] : null;
  const entries = recon && recon.state && Array.isArray(recon.state.entries) ? recon.state.entries : [];
  const posted = entries.map(postedOf).filter(Boolean);
  return posted.length ? posted[posted.length - 1] : null;
}

/**
 * `{ rows, journalRead }` — every journal entry of the month's records. `journal` is
 * the body of `GET /journal?state=all`, or null when it was not read; the payout
 * entries in the payload are listed either way.
 */
export function journalRecords(engine, journal = null) {
  const entries = journal && Array.isArray(journal.entries) ? journal.entries : null;
  if (!entries) return { rows: entryRecords(engine), journalRead: false };
  const payouts = new Map(payoutRecords(engine).map((row) => [row.id, row]));
  const byId = new Map(entries.map((e) => [e.externalId, e]));
  const absence = ledgerAbsence(journal.ledger);
  const ledger = journal.ledger && typeof journal.ledger === "object" ? journal.ledger : null;
  return { rows: entries.map((e) => journalRow(engine, e, payouts, byId, absence, ledger)), journalRead: true };
}

/**
 * THE LIST AFTER A DECISION IN ITS SHEET (staging browser walk 8, W8-2). After Reject the
 * sheet read "Rejected by you" while the list kept "Needs you (3)", the row's Needs you
 * and the month's $312.00 until a reload. The journal read again after the press is the
 * list from then on: its rows, its Needs-you count and the engine's total move together.
 * A read that failed, or one with no entries, keeps the list as it was. Pure.
 */
export function journalAfterDecision(journal, reread) {
  return reread && typeof reread === "object" && Array.isArray(reread.entries) ? reread : journal;
}

/**
 * The engine's total for one month's entries, `{ cents, measured }`, or null when the
 * engine sent none. NEVER ADDED UP HERE (tests/no-arithmetic.test.js): a total the
 * view layer summed is a figure nobody can trace, and on a list that is filtered,
 * scoped and searched it would be a total of whatever happened to be on screen.
 * `journal.totals` is `[{ period, debitCents, creditCents }]`.
 */
export function entryTotalFor(journal, period) {
  const totals = journal && Array.isArray(journal.totals) ? journal.totals : [];
  const t = totals.find((x) => x && x.period === period);
  if (!t || !Number.isInteger(t.debitCents)) return null;
  return { cents: t.debitCents, measured: true, balanced: Number.isInteger(t.creditCents) && t.creditCents === t.debitCents };
}

/* ── bank lines: matched, and the statement's own running balance (audit 18) ── */

export const BANK_FILTERS = Object.freeze([
  { id: "all", label: "All" },
  { id: "matched", label: "Matched" },
  { id: "unmatched", label: "Not matched" },
]);

export function bankFilterFrom(value) {
  return BANK_FILTERS.some((f) => f.id === value) ? value : "all";
}

/** The bank lines a filter keeps. */
export function filterBankLines(rows, filter) {
  if (filter === "matched") return rows.filter((row) => row.matched);
  if (filter === "unmatched") return rows.filter((row) => !row.matched);
  return rows;
}

/** The rows a tab lists, before any filter or month. */
export function rowsFor(engine, tab, journal = null) {
  if (tab === "entries") return journalRecords(engine, journal).rows;
  if (tab === "bank") return bankLineRecords(engine);
  if (tab === "documents" || tab === "accounts") return [];
  return payoutRecords(engine);
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE MONTH RECORDS IS ABOUT (eval r1, rubric S7 and S9)
 *
 * Records listed the whole register whatever month was chosen. With July chosen and
 * the sidebar badge at 4, /records said "Payouts · June", listed 31 payouts across two
 * months and offered "Needs you (29)" — three numbers about one screen, none of them
 * the month the person was looking at.
 *
 * A record belongs to the month its date falls in: a payout to the month it arrived
 * (the engine's close is built the same way — a month's decisions are its arrivals'
 * decisions, which the export bears out: 25 in June and 4 in July, the same 25 and 4
 * `GET /close/{period}` counts), a journal entry to its payout's month, a bank line to
 * its value date. That is a FILTER on a date the payload carries, not a figure worked
 * out here.
 *
 * A ROW WITH NO DATE BELONGS TO NO MONTH, and is not quietly dropped: `undated` is how
 * many were left out, and the screen says so in words. An undated payout shown under
 * every month would be counted twice; one hidden without a word would be a record
 * nobody could find.
 * ══════════════════════════════════════════════════════════════════════════ */

const ISO_MONTH = /^\d{4}-(?:0[1-9]|1[0-2])$/;

/** Does an ISO date ("2026-07-02", or a timestamp) fall in an ISO month ("2026-07")? */
export function inMonth(date, period) {
  return typeof date === "string" && ISO_MONTH.test(String(period)) && date.slice(0, 8) === `${period}-`;
}

/**
 * The rows of one month: `{ rows, undated }`. A period that is not an ISO month (none
 * chosen, or none the payload names) scopes nothing — every row, and `undated: 0`.
 */
export function scopeToMonth(rows, period) {
  if (!ISO_MONTH.test(String(period ?? ""))) return { rows, undated: 0, scoped: false };
  return {
    // A row that states its accounting period (a manual entry, a prepaid release) is
    // that period's, whatever day it is dated; any other row is its date's month.
    rows: rows.filter((row) => (row.period ? row.period === period : inMonth(row.date, period))),
    undated: rows.filter((row) => !row.period && !(typeof row.date === "string" && row.date)).length,
    scoped: true,
  };
}

/**
 * THE RECORD A LINK NAMES DECIDES THE MONTH (ui-pass-1 / engine-pass P19, P28; §20.12 M5).
 * The ledger memo's back-link is `/records?tab=entries&entry=je:…`, and a payout's is
 * `?payout=po_…`. Records scoped every list to the sidebar's month and only then looked
 * for the record, so with July chosen an August reversal's link opened "Journal entries
 * · July" without the entry (HTTP 200 on a page that did not show it), and a
 * `?period=2026-08` beside it was not read at all.
 *
 * Now: a record the link names is looked for in EVERY month's rows; when it is found
 * outside the month in hand, the screen moves to that record's own month (its stated
 * accounting period, else its date's month) and opens it. `{ period, moved, found }`:
 * `found` is false when a link named a record nobody read, so the screen can say so in
 * words rather than show a list that silently lacks it. Pure.
 */
export function deepLinkScope(rows, id, period) {
  if (!id) return { period, moved: false, found: null };
  const row = (rows || []).find((r) => r && (r.id === id || r.entryId === id));
  if (!row) return { period, moved: false, found: false };
  const own = ISO_MONTH.test(String(row.period ?? "")) ? row.period : typeof row.date === "string" && ISO_MONTH.test(row.date.slice(0, 7)) ? row.date.slice(0, 7) : null;
  if (!ISO_MONTH.test(String(period ?? "")) || !own || own === period) return { period, moved: false, found: true, rowId: row.id };
  return { period: own, moved: true, found: true, rowId: row.id };
}

/**
 * The Needs-you filter's state for a list: whether every row carries the engine's
 * word (only then is a count a measurement), and the rows that need you.
 */
export function needsYouOf(rows) {
  const measured = rows.length > 0 && rows.every(statusShown);
  const needing = rows.filter((row) => row.status && row.status.word === "Needs you");
  return { measured, rows: needing, count: needing.length };
}

/**
 * Whether a row's status cell shows a status: a post (PostedMark.js RecordStatus draws
 * it as posted whatever the word) or one of the engine's words. The one predicate the
 * list's header and its Needs-you count read, so neither can say "not worked out" about
 * a row the column beside it has worked out. Pure.
 */
export function statusShown(row) {
  return Boolean(row && (row.posted || (row.status && row.status.word) || row.setAside));
}

/**
 * The header's status note, DERIVED FROM THE ROWS (verify pass 1, ST9): "11 payouts ·
 * status not worked out yet" sat above ten rows that each showed a status and one that
 * did not, because the note was the negation of "every row has one". It now counts the
 * rows whose cell says "Not worked out yet": none → no note; all → "status not worked
 * out yet"; some → "1 not worked out yet". Null for an empty list. Pure.
 */
export function statusNoteFor(rows) {
  const list = Array.isArray(rows) ? rows : [];
  if (!list.length) return null;
  const unread = list.filter((row) => !statusShown(row)).length;
  if (unread === 0) return null;
  if (unread === list.length) return "status not worked out yet";
  return `${unread} not worked out yet`;
}

/** A case-insensitive match over what the row shows — its line, its bank text. */
export function matchesQuery(row, query) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return true;
  const hay = [row.line, row.name, row.day, row.description, row.matched && row.matched.line]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  return hay.includes(q);
}
