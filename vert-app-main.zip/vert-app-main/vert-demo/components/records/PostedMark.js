// components/records/PostedMark.js — A POSTED ENTRY'S STATUS, SAID AS THE PLATE SAYS IT
// ==============================================================================
// Iteration 3 W0c (carry-over item 4). Records' status cell and its entry sheet drew a
// posted entry as the engine's word with its reason — "Done · Posted" — where every
// other surface says "Posted · Journal entry 3". The glyph and tone stay the word's
// (Done, from lib/status.js), so the column still reads as one vocabulary at a glance;
// the TEXT is the plate's head (components/cards/PostedPlate.js postedHead), the one
// function that spells a post, so Records cannot drift from the plate again.
//
// The line itself is words ("Posted · Journal entry 3"), so the status is never colour
// or glyph alone, and no second word is read out before it.

import { statusStyle } from "@/lib/status";
import { postedHead } from "@/components/cards/PostedPlate";
import { StatusMark } from "@/components/ui";
import { STATUS_NOT_READ } from "@/lib/payoutStatus";

/**
 * "Posted · Journal entry 3", or "Posted" when the ledger's number was not read; with
 * the ledger's state when the engine said it (p1/fix5): "Sent to Xero as a draft ·
 * approve it in Xero to post · Journal entry 41", "Posted in Xero · Journal entry 41".
 */
export function postedText(posted) {
  const p = posted && typeof posted === "object" ? posted : {};
  return postedHead(p.number || null, null, { status: p.ledgerStatus || null, ledgerName: p.ledgerName || null });
}

export default function PostedMark({ posted }) {
  // A draft in its ledger waits on someone there: the attention mark, never Done's.
  const word = posted && posted.ledgerStatus === "draft" ? "Needs you" : "Done";
  return (
    <span className={`status-mark ${statusStyle(word)}`} data-ui="StatusMark" data-posted="" data-ledger-status={(posted && posted.ledgerStatus) || undefined}>
      <span className="status-glyph" aria-hidden="true" />
      <span className="status-word">{postedText(posted)}</span>
    </span>
  );
}

/**
 * The reason drawn beside a row's word in the list. Waiting says what it waits on; and a
 * Done that was NOT posted says why it is done (P28): a set-aside, replaced or rejected
 * entry keeps the engine's "Done" — one of the four words — and its `statusWordReason`
 * ("Rejected. Nothing was posted"), so it cannot read as a posted entry beside one that
 * was. Pure.
 */
export function statusReasonFor(row) {
  if (!row || !row.status || typeof row.status.reason !== "string" || !row.status.reason.trim()) return null;
  if (row.status.word === "Waiting") return row.status.reason;
  if (row.status.word === "Done" && !row.posted) return row.status.reason;
  return null;
}

/**
 * "Rejected by <who> · <reason>" for a set-aside entry, or the engine's outcome word
 * (staging browser walk 4, W4-5). The engine gives it no status word (none of the four
 * is true of it), so the row and its sheet read "Not worked out yet" or kept "Needs
 * you". The list says the word; the sheet says who and why when it read them, else the
 * engine's reason ("Rejected. Nothing was posted"). The neutral mark: nothing to do.
 */
export function setAsideText(setAside, { full = false } = {}) {
  const s = setAside && typeof setAside === "object" ? setAside : {};
  const word = typeof s.word === "string" && s.word.trim() ? s.word.trim() : "Set aside";
  if (!full) return word;
  if (s.by || s.note) return [s.by ? `${word} by ${s.by}` : word, s.note].filter(Boolean).join(" · ");
  const reason = typeof s.reason === "string" && s.reason.trim() ? s.reason.trim() : null;
  if (!reason) return word;
  return reason.toLowerCase().startsWith(word.toLowerCase()) ? reason : `${word} · ${reason}`;
}

function SetAsideMark({ setAside, full }) {
  // The sheet's full line ("Rejected by <who> · <reason>") wraps: on a phone it ran off
  // the right edge, the reason unread (staging browser walk 5, W5-6).
  return (
    <span className={`status-mark ${statusStyle("Waiting")}`} data-ui="StatusMark" data-set-aside={setAside.word || ""} data-wrap={full ? "" : undefined}>
      <span className="status-glyph" aria-hidden="true" />
      <span className="status-word">{setAsideText(setAside, { full })}</span>
    </span>
  );
}

/**
 * ONE RECORD, ONE STATUS, WHEREVER IT IS DRAWN (verify pass 1, P28 residue). The list's
 * status cell and the record sheet each spelled a record's status themselves, and they
 * disagreed: a posted payout entry read "Posted · Journal entry 1" in the table and
 * "Done" in its sheet, because the sheet (PayoutDetail) drew the payout's engine word and
 * never looked at the entry's post. Every Records surface now draws a record's status
 * through this one component, so the word cannot differ between the row and its sheet.
 * `full` lets the sheet, which leads with its verdict, say the engine's reason in full
 * beside the SAME word; it never changes the word.
 */
export function RecordStatus({ row, full = false }) {
  if (!row) return null;
  // A posted entry reads as the plate reads it, never "Done".
  if (row.posted) return <PostedMark posted={row.posted} />;
  if (row.setAside) return <SetAsideMark setAside={row.setAside} full={full} />;
  if (!row.status) return <span className="figure-unread">{STATUS_NOT_READ}</span>;
  return <StatusMark word={row.status.word} reason={full ? row.status.reason : statusReasonFor(row)} />;
}
