// components/settings/ConnectionsSkeleton.js — WHAT IS COMING, HELD STILL, WHILE IT IS READ
// ==============================================================================
// `readConnections` is a network call to the API. Before this existed, `await`ing it
// sat in the page body, so the whole route blocked and a person got a blank frame of
// unknown length with nothing on it — no title, no heading, no clue whether the click
// had registered. The read is the slowest thing on this screen and it had the least
// to say about itself.
//
// A SKELETON AND NOT A SPINNER, and the difference is what each one claims. A spinner
// says "something is happening somewhere". This says "three provider cards are coming,
// they are this tall, and the page will not jump underneath you when they land" —
// which is the fact a person actually needs, and the reason the layout below is drawn
// to the real component's proportions rather than to three identical grey bars.
//
// IT IS MOTIONLESS ON PURPOSE. The obvious skeleton has a gradient sweeping across it
// forever. That is the "thinking" shimmer PRODUCT.md lists as an anti-reference — the
// generic-AI-product tell — and it also breaks this app's motion rule, which is
// 150–250ms on a STATE CHANGE, not a loop that runs for as long as a socket is slow.
// The state change here is the ARRIVAL, and that is what carries the 200ms fade
// (`.skel-in`, applied by the caller). Waiting is not a state change and gets nothing.
//
// IT IS NOT AN EMPTY STATE AND IT IS NOT AN ERROR, and the copy is the guard.
// ------------------------------------------------------------------
// This screen already distinguishes "the read failed" from "you have connected
// nothing" — that was the bug the empty states fixed on three registers, and
// ConnectionsScreen.js does not repeat it. A loading state is the THIRD member of that
// family and it is the one most easily collapsed into either: grey placeholder cards
// look exactly like "Not connected" rows, and a slow read looks exactly like a dead
// one. So this says, in words, that the question has been asked and not yet answered
// — and it says it in the live region, not only in the pixels.
//
// THE BLOCKS ARE `aria-hidden` AND THE SENTENCE IS NOT. Grey rectangles are worth
// nothing to a screen reader; announcing eleven of them is worse than announcing none.
// The region is `aria-busy` with one `role="status"` sentence inside it.

import "../setup/connections.css";

export default function ConnectionsSkeleton({ cards = 3 }) {
  return (
    <div aria-busy="true" className="conn-skeleton">
      {/* THE ONLY THING HERE THAT IS READ ALOUD, and the only thing here that is a
          claim. It says the question is outstanding — never that the answer is
          "nothing", which is what a bare list of grey rows silently implies. */}
      <p className="conn-note" role="status">
        Checking what&rsquo;s connected. These are placeholders, not a report on them.
      </p>

      <div aria-hidden="true" className="conn-list">
        {Array.from({ length: cards }, (_, index) => (
          <div className="skel-card conn-row" key={index}>
            {/* The row's own proportions (the source glyph, a name, its state beneath,
                the action at the right) so nothing shifts when the answer lands. */}
            <div className="skel conn-glyph" />
            <div className="conn-main">
              <div className="skel skel-line skel-name" />
              <div className="skel skel-line skel-state" />
            </div>
            <div className="skel skel-pill" />
          </div>
        ))}
      </div>
    </div>
  );
}
