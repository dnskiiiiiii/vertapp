"use client";

// components/settings/BankStatementImport.js — CHOOSING THE FILE IS READING THE FILE
// ==============================================================================
// TWO CALLS, AND THE SPLIT IS THE SAFETY. `POST /bank-statements` parses the file and
// proposes a mapping and imports NOTHING; `POST /bank-statements/{id}/confirm` is the
// only call that writes, and it carries six answers a person stated. An importer that
// did both in one press would be an importer that had already guessed by the time
// anybody looked — which is the defect the whole design of §3.4 is arranged against.
//
// THAT SPLIT IS BETWEEN THE READ AND THE WRITE. IT IS NOT A SPLIT BETWEEN CHOOSING A
// FILE AND READING IT, AND IT USED TO BE BOTH.
// ------------------------------------------------------------------
// This screen asked for a file with a picker, then asked for a second press on a
// button labelled "Inspect the file". Two presses, no work between them, and nothing
// on screen in between that a person could check — and the founder, importing a real
// statement on 2026-08-17, could not get past it: the attachment did not survive to
// the second press and the screen went back to asking for a file. A step that exists
// only to be pressed adds no safety and is a place for the payload to be lost.
//
// Choosing a file now submits the form that CONTAINS it, in the same interaction, with
// `requestSubmit()` — so the file travels as part of the real form submission rather
// than out of anything this component was holding on its behalf. There is exactly one
// submission path, which is what makes it impossible for the picker and the request to
// disagree about which file is attached, and the button stays for the keyboard and for
// a browser that has not run this script yet. The gate that matters is untouched: the
// service still writes nothing here, and still refuses to import until the six answers
// below have been stated and read back.
//
// The mapping form is a separate component and takes the inspection as a PROP rather
// than reading it out of this one's state. That is deliberate: it makes the
// "you must choose" behaviour renderable, and therefore testable, without a browser.

// STATEMENT FOR AN ACCOUNT (close list step 1, 29 Oct 2026). A bank, card or loan
// statement, CSV or a text PDF, imported against the account picked from the chart. For a
// bank or card the account's name, currency and sign go with the upload as PROPOSALS the
// mapping form shows as "Vert suggests" and the engine echoes; a loan statement is stored,
// read by the engine for its closing balance, interest and repayments, shown, and filed
// as that loan's statement by a second press.

import { startTransition, useActionState, useEffect, useState } from "react";

import { inspectStatementAction, readLoanStatementAction } from "./actions";
import { ImportRefusal } from "./BankImportOutcome";
import BankStatementMapping from "./BankStatementMapping";
import LoanStatementReading from "./LoanStatementReading";
import { KIND_WORDS, statedForImport } from "@/lib/statement-accounts";
import { accountIdFor } from "@/components/setup/connections-link";

const LABEL = { display: "block", fontSize: "var(--t-footnote)", fontWeight: 500, color: "var(--text-2)", marginBottom: 6 };

/** The chart's statement accounts, read once the sheet is open (a GET), unless handed in. */
function useStatementAccounts(given, givenWhy) {
  const [read, setRead] = useState(() => (given !== undefined ? { accounts: given, why: givenWhy || null } : { accounts: null, why: null, loading: true }));
  useEffect(() => {
    if (given !== undefined) return undefined;
    let live = true;
    // One read, and one more a moment later if it fails (founder's walk, 8 Nov 2026: a
    // read that failed once left the form asking for the account its row had named).
    const once = () =>
      fetch("/api/statements/accounts", { cache: "no-store" })
        .then((r) => r.json().catch(() => null))
        .catch(() => null);
    const settle = (body) => {
      if (!live) return true;
      if (body && body.ok && Array.isArray(body.accounts)) {
        setRead({ accounts: body.accounts, why: null });
        return true;
      }
      return false;
    };
    once().then((first) => {
      if (settle(first)) return;
      setTimeout(() => {
        once().then((second) => {
          if (!settle(second) && live) setRead({ accounts: null, why: (second && second.message) || "Vert couldn't read your chart of accounts just now." });
        });
      }, 1500);
    });
    return () => {
      live = false;
    };
  }, [given]);
  return read;
}

/**
 * `compact`: drawn under a statement's row (the documents checklist, founder, 8 Nov
 * 2026), where the row already says what it is for: no heading or explainer, no account
 * picker once the row's account is found, and the file is a drop zone that reads on drop.
 */
export default function BankStatementImport({ canWrite = true, disabledReason = null, accounts: givenAccounts, accountsWhy = null, account: askedAccount = null, compact = false }) {
  const [state, inspect, pending] = useActionState(inspectStatementAction, null);
  const [loan, readLoan, reading] = useActionState(readLoanStatementAction, null);
  const chart = useStatementAccounts(givenAccounts, accountsWhy);
  const accounts = Array.isArray(chart.accounts) ? chart.accounts : [];
  // The account the link named is picked once the chart is read (D4); never over a pick.
  const [pickedId, setPickedId] = useState(() => accountIdFor(accounts, askedAccount));
  useEffect(() => {
    const id = accountIdFor(accounts, askedAccount);
    if (id) setPickedId((was) => was || id);
  }, [accounts.length, askedAccount]); // eslint-disable-line react-hooks/exhaustive-deps
  const picked = accounts.find((a) => a.id === pickedId) || null;
  const isLoan = Boolean(picked && picked.kind === "loan");
  const stated = statedForImport(picked);

  // NO `action` PROP ON THE FORM (UI walk D10, 30 Oct 2026), for the reason
  // BankStatementMapping gives at length: React 19 resets a `<form action={fn}>` once the
  // action settles, and the controlled "Statement for" select has no default for a
  // reset to restore. After "Read the file" it showed "Choose the account…" while the
  // account's proposals rode on below it. The submission is the form's own, still: its
  // FormData, file and hidden answers included, handed to the action in a transition.
  function read(event) {
    event.preventDefault();
    if (!canWrite) return;
    const data = new FormData(event.currentTarget);
    startTransition(() => (isLoan ? readLoan(data) : inspect(data)));
  }

  // The form that owns the field, submitted by the field. `requestSubmit` runs the
  // form's own submit with its own FormData — the same code path the button below
  // takes — rather than assembling a request out of `event.target.files`, which is the
  // version where a picker and a payload can come apart.
  function readImmediately(event) {
    if (!event.target.files || event.target.files.length === 0) return;
    if (!canWrite) return;
    const form = event.target.form;
    if (form && typeof form.requestSubmit === "function") form.requestSubmit();
  }

  return (
    <div>
      <form onSubmit={read} aria-labelledby="bank-import-title" className={compact ? "stmt-import-compact" : undefined}>
        <h3 id="bank-import-title" className={compact ? "sr-only" : "pnl-sub"}>Import a statement</h3>
        {compact ? null : (
          <p className="constraint-line" style={{ marginBottom: 12 }}>
            A bank, credit card or loan statement: a CSV, or a PDF with its text in it. Vert reads
            it and shows you what it found. Nothing is imported until you confirm.
          </p>
        )}

        {compact && picked ? null : accounts.length ? (
          <div style={{ marginBottom: 12 }}>
            <label htmlFor="statement-account" style={LABEL}>
              Statement for
            </label>
            <span className="fsel" style={{ width: "100%" }}>
              <select id="statement-account" name="statement-account" autoComplete="off" value={pickedId} disabled={pending || reading || !canWrite} onChange={(e) => setPickedId(e.target.value)} style={{ width: "100%" }} aria-describedby="statement-account-help">
                <option value="">Choose the account…</option>
                {["bank", "card", "loan"].map((kind) =>
                  accounts.some((a) => a.kind === kind) ? (
                    <optgroup key={kind} label={KIND_WORDS[kind]}>
                      {accounts
                        .filter((a) => a.kind === kind)
                        .map((a) => (
                          <option key={a.id} value={a.id}>
                            {a.label}
                          </option>
                        ))}
                    </optgroup>
                  ) : null
                )}
              </select>
            </span>
            <p id="statement-account-help" className="constraint-line" style={{ marginTop: 6, marginBottom: 0 }}>
              {isLoan
                ? "Vert reads the lender's closing balance, interest and repayments, and shows them before anything is filed."
                : "Vert suggests this account's name, currency and sign on the next step. Check them."}
            </p>
          </div>
        ) : compact && chart.loading ? null : chart.why ? (
          <p className="constraint-line" role="note" style={{ marginBottom: 12 }}>
            {chart.why} Name the account on the next step instead.
          </p>
        ) : null}

        {stated ? (
          <>
            <input type="hidden" name="account_id" value={stated.account_id} />
            {stated.currency ? <input type="hidden" name="currency" value={stated.currency} /> : null}
            <input type="hidden" name="deposits_are_positive" value={stated.deposits_are_positive} />
            {stated.kind ? <input type="hidden" name="kind" value={stated.kind} /> : null}
          </>
        ) : null}
        {isLoan ? <input type="hidden" name="loan_account_id" value={picked.id} /> : null}

        {compact ? (
          // A DROP ZONE (as document tools draw one): the file field covers the zone, so a
          // drop or a press lands in the form's own field, which reads on change.
          <label className="stmt-drop" data-busy={pending || reading ? "true" : undefined}>
            <input id="file" name="file" type="file" accept=".csv,.pdf" required disabled={pending || reading || !canWrite} onChange={readImmediately} className="stmt-drop-input" />
            <span className="stmt-drop-words">
              {pending || reading ? "Reading the statement…" : "Drop the statement here, or choose a file"}
            </span>
            <span className="stmt-drop-hint">CSV or PDF. Nothing is imported until you confirm.</span>
          </label>
        ) : (
          <>
            <label htmlFor="file" style={LABEL}>
              Statement file (CSV or PDF)
            </label>
            <input
              id="file"
              name="file"
              type="file"
              accept=".csv,.pdf"
              required
              disabled={pending || reading || !canWrite}
              onChange={readImmediately}
              aria-describedby="file-help"
              style={{ display: "block", marginBottom: 10, fontSize: 13 }}
            />
            <p id="file-help" className="constraint-line" style={{ marginBottom: 14 }}>
              Importing the same statement twice is safe: lines already in are skipped.
            </p>
          </>
        )}

        {/* THE SAME SUBMISSION, BY HAND. Not a second step: with this script running,
            the field above has already pressed it. It is here for a keyboard that
            reached the field without firing a change, and for the seconds before this
            component hydrates. */}
        <button type="submit" className={compact ? "btn sr-only" : "btn"} disabled={pending || reading || !canWrite}>
          {pending ? "Reading the file…" : reading ? "Reading the statement…" : "Read the file"}
        </button>
        {!canWrite && <p className="constraint-line" style={{ marginTop: 8 }}>{disabledReason}</p>}
      </form>

      {isLoan && loan && !loan.ok ? <ImportRefusal outcome={loan} title="The statement was not read" /> : null}
      {isLoan && loan && loan.ok ? (
        <div style={{ marginTop: 16 }}>
          <LoanStatementReading key={loan.documentId} reading={loan.reading} documentId={loan.documentId} canWrite={canWrite} />
        </div>
      ) : null}

      {/* THE SERVICE'S DIAGNOSIS, THEN ITS REMEDY — composed in BankImportOutcome's
          `ImportRefusal`, so this branch and the import's own outcome cannot drift. */}
      {!isLoan && state && !state.ok && <ImportRefusal outcome={state} title="The file was not read" />}

      {!isLoan && state && state.ok && (
        <div style={{ marginTop: 16 }}>
          {/* KEYED ON THE INSPECTION: a new upload is a new import, so it gets a new
              component (its answers are seeded once, from the proposal). */}
          <BankStatementMapping
            key={state.inspection && state.inspection.inspectionId}
            inspection={state.inspection}
            fileName={state.fileName}
            stated={state.stated || null}
          />
        </div>
      )}
    </div>
  );
}
