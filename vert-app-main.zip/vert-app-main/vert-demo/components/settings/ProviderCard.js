"use client";

// components/settings/ProviderCard.js — ONE PROVIDER, AS ONE ROW OF CONNECTIONS
// ==============================================================================
// Spec §3.6; audit UI-067. Providers are ROWS on one surface — name, state in words,
// one action at the right — not a card each, nested three and four boxes deep with the
// page head inside one of them. The name is kept (ProviderCard) because every guard
// below is written against it; what it draws is a row. The action slot (`action`) is
// the list's: Connect opens a sheet (components/setup/ConnectionsList.js), and this
// row does not decide what connecting means for any one vendor.
//
// ==============================================================================
// Four facts per provider and not one of them is inferred here: connected or not,
// which account, when it last synced, and what action is available. Every one comes
// from lib/connections-shape.js, which builds the row from the API's own summary.
//
// NO SECRET IS RENDERED, and it is stronger than "no component prints one": the row
// this card is handed HAS no secret field — `providerRows` copies seven named keys
// and drops everything else — so there is no expression that could be written here
// that would put a credential on screen. Not masked, not last-4. A last-4 is not a
// safety measure, it is four characters of a live key plus a habit of showing keys.
//
// NOTHING HERE IS GREEN. Green is the status colour for Done (spec §11.2), a word
// about a bookkeeper's work; a connection is a setting. The state is a neutral chip —
// a glyph and the word in ink (design-pass spec §7.1) — and "Not connected" is not
// dressed as a problem either: it is a fact about this client.
//
// THE DISCONNECT IS A REAL FORM WITH A REAL ACTION, so it works with the keyboard and
// it works before hydration. `useActionState` is what carries the refusal back under
// the button; it is not what makes the control function.
//
// IT ASKS FIRST, AND IT ASKS INLINE — NOT IN A MODAL.
// ------------------------------------------------------------------
// Disconnecting is destructive and it is not symmetrical: reconnecting means going
// back to the vendor and connecting again with a NEW credential, because the vendor
// shows one once and this app deliberately keeps no copy. So a mis-click costs a trip to
// Stripe, not an undo.
//
// The confirmation is a `<details>` — a real disclosure, not a dialog. That is the
// progressive alternative the modal ban asks to be exhausted first, and here it is
// strictly better than a modal on every axis that matters: it works with JavaScript
// off and before hydration (the browser opens it natively), it traps no focus and
// steals none, it needs no escape key and no scroll lock, it does not cover the row
// whose fate is being decided, and two providers can be considered side by side. A
// modal would buy exactly one thing over this — forcing the eye — and the second,
// differently-worded press already does that.
//
// THE CONFIRM BUTTON IS NOT RED. Red is a Problem line, never a control (spec §11.2). The gravity is carried by the sentence and by the fact that a second,
// re-worded press is required, which is where gravity belongs. A red button is a
// colour telling somebody to be careful; a sentence naming what it costs is the
// product telling them why.

import { useActionState, useState } from "react";

import { IconConnections } from "@/components/shell/icons";
import { SourceLogo } from "@/components/ui/SourceLogo";
import { IconClock, IconQuestion, IconStatusDone, IconStatusWaiting } from "@/components/ui/icons";
import { accountLine, stateLine } from "@/lib/connections-shape";
import { formatDate, metaLine } from "@/lib/format";
import { disconnectProviderAction } from "./actions";
import DisconnectOutcome from "./DisconnectOutcome";

/** The state, in words: the four answers a row can give. */
export function stateWords(row) {
  if (row.connect === "unavailable") return "Not available yet";
  if (row.measured === false) return "Not checked";
  return row.connected ? "Connected" : "Not connected";
}

/**
 * The state as a key the row's chip is drawn from (design-pass spec §7.1; audit §13): a
 * glyph and the word, in ink on a neutral fill. Never a status colour: a connection is
 * a setting, not a bookkeeper's Done.
 */
export function stateKey(row) {
  if (row.connect === "unavailable") return "unavailable";
  if (row.measured === false) return "unchecked";
  return row.connected ? "connected" : "disconnected";
}

// THE SOURCE GLYPH (spec §7.1: a settings list leads each row with what it reads
// from). The list hands it in (`glyph`), keyed by the kind of source; this row names no
// vendor and decides nothing about one. Never a vendor's logo: a wall of brand colours
// would be four accents on one screen.
/**
 * The state's glyph (design-fix-2 DA2-040): Connected is the Done mark (a filled tick in
 * the quiet done ink, never green); Not checked is a neutral question mark; Not connected
 * a plain ring; Not available a clock (not yet). Always beside the word, never alone.
 */
const STATE_GLYPHS = { connected: IconStatusDone, unchecked: IconQuestion, disconnected: IconStatusWaiting, unavailable: IconClock };

/** The row's leading glyph, decoration beside the name. */
export function SourceGlyph({ icon: Icon = IconConnections }) {
  return (
    <span className="conn-glyph" aria-hidden="true">
      <Icon width="18" height="18" />
    </span>
  );
}

/**
 * When it last synced, in words, or nothing. `last_synced_at` is null on every row the
 * connections route serves today (the service does not claim to know), and a null is
 * not "never" — so it prints nothing rather than a sentence about what it cannot say.
 */
export function syncedWords(row) {
  if (!row.connected || !row.lastSyncedAt) return null;
  try {
    return `synced ${formatDate(row.lastSyncedAt)}`;
  } catch {
    return null;
  }
}

function StateGlyph({ state }) {
  const Glyph = STATE_GLYPHS[state] || IconStatusWaiting;
  return (
    <span className="conn-state-glyph" data-state={state} aria-hidden="true">
      <Glyph size={12} />
    </span>
  );
}

// "NOT CHECKED" IS THE WHOLE OF A ROW'S ANSWER WHEN THE READ FAILED. Each row used to
// add "Nothing was read about this connection, so this row is not saying whether Stripe
// is connected — the question was never answered": one sentence, four times, under a
// verdict line that had already said it (eval r1, rubric S6). The list says it once;
// the row says the two words.
//
// `whyOpen` is the disclosure's starting state, for a render that needs the reason
// on it (a test, a deep link); a person opens it by pressing "Why?".
// `whyInSheet`: the list's row action opens a sheet that carries the reason (design-fix-2
// DA2-040 round 2: every row has one action), so the inline "Why?" would say it twice.
// `detail` is one more line under the state, the list's to fill (verify pass 5, X-h: the
// connected ledger's posting choice, said on the row with its own Change).
export default function ProviderCard({ row, canWrite = true, disabledReason = null, action = null, whyOpen = false, whyInSheet = false, glyph = undefined, source = null, detail = null }) {
  const [outcome, disconnect, pending] = useActionState(disconnectProviderAction, null);
  // THE REASON IS MOUNTED WHEN IT IS ASKED FOR, not before. A closed <details> still
  // carries its text in the document, so Shopify's catalogue paragraph was on every
  // visit's page — read by a screen reader walking the list and counted by anything
  // that reads the page (eval r1 counted it above the fold).
  const [why, setWhy] = useState(whyOpen);

  const account = accountLine(row);
  const synced = syncedWords(row);
  const status = stateLine(row);
  const facts = [row.connected ? account : null, synced].filter(Boolean);

  return (
    <section className="conn-row" aria-labelledby={`provider-${row.id}`} data-provider={row.id} data-state={stateKey(row)}>
      {source ? <SourceLogo source={source} tile className="conn-glyph" /> : <SourceGlyph icon={glyph} />}
      <div className="conn-main">
        <h2 id={`provider-${row.id}`} className="conn-name" translate="no">
          {row.name}
        </h2>
        {/* THREE ANSWERS, NOT TWO. "Not connected" is a fact about this client; "Not
            checked" is a fact about this page — a read that never answered must not
            render as a customer's Stripe being disconnected. `connect === "unavailable"`
            is checked first: Shopify being unavailable is a fact about the catalogue,
            not something the service was asked, so a failed read cannot soften it.
            The state is a glyph and the word, with no pill (DA2-040), and the facts
            (which account, when it synced) follow it on the same line. */}
        <div className="conn-status">
          <StateGlyph state={stateKey(row)} />
          <span className="conn-chip">{stateWords(row)}</span>
          {facts.length ? <span className="conn-state">{metaLine(facts)}</span> : null}
          {/* THE REASON THERE IS NO ACTION, inline after the state as a small "Why?"
              that opens the reason in a bubble (DA2-040). `row.connect` is catalogue
              data, so no component decides whether a vendor may be connected. A native
              disclosure: there for whoever asks, not read aloud to everyone who doesn't. */}
          {!row.connected && row.why && !whyInSheet ? (
            <details className="conn-why" open={why} onToggle={(event) => setWhy(event.currentTarget.open)}>
              <summary>Why?</summary>
              {why ? <span className="conn-note conn-why-tip" role="note">{row.why}</span> : null}
            </details>
          ) : null}
        </div>
      </div>
      {action ? <div className="conn-action">{action}</div> : null}
      {detail ? <div className="conn-detail">{detail}</div> : null}

      {/* "YOU DISCONNECTED THIS" AND "YOU HAVE NEVER CONNECTED THIS" ARE DIFFERENT
          SENTENCES; the service returns revoked rows so the screen can write both. */}
      {!row.connected && row.state === "revoked" && <p className="conn-note">{status}</p>}


      {row.connected && (
        <form action={disconnect} className="conn-disconnect">
          <input type="hidden" name="provider" value={row.id} />

          {/* THE ARM. Pressing this writes nothing and sends nothing — it opens the
              question. A `<summary>`, so it is in the tab order, answers Enter and
              Space, and works with no JavaScript at all. */}
          <details className="confirm">
            <summary>Disconnect {row.name}</summary>
            <div className="confirm-body">
              <p className="conn-note">
                {canWrite
                  ? "The credential is revoked at the vendor where the vendor supports it, then " +
                    "deleted here. Anything already imported stays; nothing new arrives."
                  : disabledReason}
              </p>
              {/* WHAT IT COSTS TO UNDO — the fact a bare "Are you sure?" withholds. */}
              {canWrite && (
                <p className="conn-note">
                  This cannot be undone from here. Vert keeps no copy of the credential, so
                  reconnecting means creating a new one at the vendor and connecting again.
                </p>
              )}
              <div className="confirm-row">
                <button type="submit" className="btn" disabled={pending || !canWrite}>
                  {/* THE SECOND PRESS IS WORDED DIFFERENTLY FROM THE FIRST, so it gets read. */}
                  {pending ? "Disconnecting…" : `Yes, disconnect ${row.name}`}
                </button>
                <span className="conn-note">Or leave this closed and nothing happens.</span>
              </div>
            </div>
          </details>
        </form>
      )}

      {/* A DISCONNECT THAT ONLY HALF HAPPENED SAYS SO. Outside the `row.connected`
          branch on purpose: a successful disconnect revalidates, the row re-renders as
          not connected, and a report inside that branch would unmount at the moment it
          became true (DisconnectOutcome.js). */}
      <DisconnectOutcome outcome={outcome} />
    </section>
  );
}
