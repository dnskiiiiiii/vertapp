"use client";

// components/settings/BankStatementMapping.js — THE SIX ANSWERS, AND THE ONE THAT
// MATTERS MOST: A FIELD THE SERVER WOULD NOT GUESS IS DRAWN AS A QUESTION
// ==============================================================================
// The server has read the file and proposed what it could. Where it proposed nothing
// THAT IS A DELIBERATE REFUSAL TO GUESS, and this screen renders it as a required
// choice — never as a blank that looks finished, and never as a quietly-selected
// first column. The failure being prevented is specific: a wrong amount column
// produces a bank statement that balances, looks clean, and is wrong, and every
// deposit tie built on it inherits the error without a single check firing.
//
// So there are three visibly different states per field, and the middle one is the
// whole point:
//
//   PROPOSED     the server's suggestion is selected AND labelled as a proposal, so
//                a person knows it was a machine's reading and can overrule it.
//   MUST CHOOSE  nothing is selected, the control says so in words, and the confirm
//                button will not submit until it is answered.
//   NEVER PROPOSED  the sign convention and the currency. Not knowable from a file
//                at all — see lib/bank-import.js — so no server proposal is read for
//                them even if one arrives.
//
// The logic for all three is in lib/bank-import.js and is tested directly, including
// by deleting the refusal and watching a test go red. This file renders it.
//
// KEYBOARD AND LABELS. Every control is a real <select> or <input type="radio"> with
// a real <label htmlFor>, in a real <form> with a real action. The help text and the
// "you must choose" line are wired with aria-describedby so a screen reader hears the
// requirement, not just sees it.

import { startTransition, useActionState, useEffect, useRef, useState } from "react";
import { markShellStale } from "@/components/shell/live-shell";

import {
  DATE_FORMATS,
  confirmFormData,
  importGateView,
  initialMapping,
  mappingChoices,
  signConventionSentence,
} from "@/lib/bank-import";
import { confirmStatementAction } from "./actions";
import BankImportGate from "./BankImportGate";
import BankImportOutcome from "./BankImportOutcome";

const FORMAT_LABELS = new Map(DATE_FORMATS.map((f) => [f.value, f.label]));

/** The suggestion as the select names it: a format by its label, anything else as is. */
export function suggestedWords(choice, value) {
  if (choice && choice.kind === "sign") return value === "yes" ? "money arriving is a positive number" : value === "no" ? "money arriving is a negative number" : value;
  return choice && choice.kind === "format" ? FORMAT_LABELS.get(value) || value : value;
}

/**
 * What a field's help line opens with: "choose" ("Choose one.") while a field Vert
 * proposed nothing for is unanswered; null once the person has answered it (verify
 * pass 4, S-E2E-4: "Choose one." stayed under AUD and a typed account, and saying
 * "Vert suggests" for the person's own answer would be false); "suggest" for a field
 * Vert proposed. Pure.
 */
export function helpLead(choice, value) {
  if (!choice || !choice.mustChoose) return "suggest";
  return String(value ?? "").trim() ? null : "choose";
}

export default function BankStatementMapping({ inspection, fileName, onImported = null, stated = null }) {
  // `stated`: the account picked on the import (lib/statement-accounts.js), proposed.
  const choices = mappingChoices(inspection, { stated });
  const [mapping, setMapping] = useState(() => initialMapping(choices));
  const [answered, confirm, pending] = useActionState(confirmStatementAction, null);
  // A CONFIRM WHOSE ANSWER WAS LOST AND THEN READ BACK (CC2-1): "Check again" found the
  // import, so it stands in for the answer that never came, for this press only.
  const [settled, setSettled] = useState(null);
  const outcome = settled && settled.after === answered ? settled.outcome : answered;

  // A STATEMENT ASKED FOR IN A CONVERSATION (components/chat/questions/FileQuestion.js)
  // is imported through this same form and this same two-press gate; the question only
  // needs to hear, once, which import was committed, so its answer can name it. Told
  // after the commit and never before it: the id exists only once the service wrote.
  const reported = useRef(null);
  const told = useRef(null);
  useEffect(() => {
    if (!outcome || !outcome.ok || !outcome.importId) return;
    // The month's figures move once a statement is in (verify pass 5, S-E2E-1 F16): the
    // sidebar re-reads its badge from the engine rather than keeping the pre-import 4.
    if (told.current !== outcome.importId) {
      told.current = outcome.importId;
      markShellStale();
    }
    if (typeof onImported !== "function") return;
    if (reported.current === outcome.importId) return;
    reported.current = outcome.importId;
    onImported(outcome);
  }, [outcome, onImported]);

  const state = (key, value) => setMapping((current) => ({ ...current, [key]: value }));
  const echo = signConventionSentence(mapping);

  // THE WHOLE OF THE TWO-PRESS GATE, DECIDED IN lib/bank-import.js AND NOT HERE.
  //
  // The answers the echo was produced from come back on the outcome itself
  // (`stated`, set by confirmStatementAction from the body it actually sent), so
  // there is no second piece of component state to keep in step with this one — the
  // `submitted` useState this replaces was a copy of the request made BEFORE the
  // request, and a copy that could be right while the request was not.
  //
  // Changing any answer retracts the agreement, because the comparison stops
  // matching. That is the staleness check, and it is what stops somebody agreeing in
  // good faith to a sentence that no longer describes what they have said.
  const gate = importGateView(outcome, mapping, { pending });

  // ══════════════════════════════════════════════════════════════════════════
  // NO `action` PROP ON THE FORM, AND THAT IS THE FIX RATHER THAN A STYLE CHOICE.
  //
  // MEASURED IN A BROWSER, 2026-08-23. With `<form action={confirm}>`, React 19
  // resets this form once the action settles. A reset restores every control to its
  // DEFAULT, and a controlled `<select value={…}>` has none — React emits no
  // `selected` attribute on any option — so all five dropdowns landed on their empty
  // "Choose the …" placeholder and both radios cleared, the instant the service
  // answered with its echo. `mapping` was untouched: the echo and the token went on
  // rendering, and typing one character in the account field re-rendered the controls
  // and brought every answer straight back. Nothing re-rendered them on its own.
  //
  // So the second press — "Yes — import these lines" — submitted six blank answers.
  // The service refused and re-issued the not-confirmed gate; `BankImportOutcome`
  // stands down on a review stage by design; the screen redrew identically, button
  // still enabled, saying nothing. Pressing it again did the same. THE BANK IMPORT
  // COULD NOT BE COMPLETED FROM THIS SCREEN AT ALL, and 974 green tests did not see
  // it because the render harness cannot press a button twice.
  //
  // Submitting through `startTransition` instead of the `action` prop is the
  // documented way to keep React's hands off the form. The answers therefore stay on
  // screen, which is the half that matters: `confirmFormData` below would have sent
  // the right body either way, and a right body under a screen showing blanks is a
  // worse product than the bug it replaces.
  //
  // WHAT THIS GIVES UP is the no-JS submit that an `action` prop provides. Nothing is
  // lost: every control here is driven by `mapping`, the echo is client state, and the
  // whole two-press gate is decided from this component's own outcome. A browser that
  // has not run this script has no gate to submit through.
  function submit(event) {
    event.preventDefault();
    // FROM STATE, NEVER FROM THE DOM. See `confirmFormData`. The token goes only when
    // it still describes what is on screen, exactly as the hidden input did.
    const data = confirmFormData(mapping, {
      inspectionId: inspection.inspectionId || "",
      confirmation: gate.confirmation,
    });
    startTransition(() => confirm(data));
  }

  return (
    <form aria-labelledby="mapping-title" onSubmit={submit}>
      <h3 id="mapping-title" className="pnl-sub">Map the columns</h3>

      {/* WHAT THE SERVER READ. Its columns and its row count, printed as they
          arrived — this app does not open the file and must not appear to have. */}
      <p className="constraint-line" style={{ marginBottom: 12 }}>
        {fileName ? <b>{fileName}</b> : null}{" "}
        {inspection.rowCount === null
          ? "The service did not report how many rows it read."
          : `${inspection.rowCount} ${inspection.rowCount === 1 ? "row" : "rows"} read.`}{" "}
        Columns found: {inspection.columns.length ? inspection.columns.join(", ") : "none"}.
      </p>

      {inspection.warnings.map((warning) => (
        <p key={warning} className="constraint-line">{warning}</p>
      ))}

      {choices.map((choice) => {
        const helpId = `${choice.key}-help`;
        return (
          <div key={choice.key} style={{ marginBottom: 16 }}>
            <label
              htmlFor={choice.key}
              style={{ display: "block", fontSize: "var(--t-footnote)", fontWeight: 500, color: "var(--text-2)", marginBottom: 6 }}
            >
              {choice.label}
              {/* The required marker is a word, not an asterisk. All six are required
                  and an asterisk beside every one of them says nothing. */}
              <span className="k"> (required)</span>
            </label>

            {choice.kind === "sign" ? (
              // TWO RADIOS AND NOT A CHECKBOX. A checkbox has two states and the
              // question has three: positive, negative, and NOT YET STATED. An
              // unchecked box would silently mean "deposits are negative", which is a
              // claim nobody made and the exact class of default this screen refuses.
              <fieldset style={{ border: 0, padding: 0, margin: 0 }} aria-describedby={helpId}>
                <legend className="sr-only">{choice.label}</legend>
                <label style={{ display: "block", marginBottom: 4 }}>
                  <input
                    type="radio"
                    name="deposits_are_positive"
                    value="yes"
                    checked={mapping.deposits_are_positive === "yes"}
                    onChange={() => state("deposits_are_positive", "yes")}
                  />{" "}
                  Money arriving is a positive number
                </label>
                <label style={{ display: "block" }}>
                  <input
                    type="radio"
                    name="deposits_are_positive"
                    value="no"
                    checked={mapping.deposits_are_positive === "no"}
                    onChange={() => state("deposits_are_positive", "no")}
                  />{" "}
                  Money arriving is a negative number
                </label>
              </fieldset>
            ) : choice.kind === "text" ? (
              // A FREE FIELD, EMPTY, WITH NO SUGGESTION IN IT. Not the file's name,
              // not the last account used, not a placeholder that looks like an
              // answer. File identity is deliberately excluded from the line's
              // identity, so seeding this from the file name would re-open the double
              // import that exclusion exists to close — and a person who accepts a
              // pre-filled account is a person who never chose one.
              <input
                id={choice.key}
                name={choice.key}
                type="text"
                required
                className="inp"
                value={mapping[choice.key]}
                aria-describedby={helpId}
                autoComplete="off"
                placeholder="e.g. anz-cheque"
                onChange={(event) => state(choice.key, event.target.value)}
                style={{ width: "100%" }}
              />
            ) : (
              <span className="fsel" style={{ width: "100%" }}>
                <select
                  id={choice.key}
                  name={choice.key}
                  autoComplete="off"
                  required
                  value={mapping[choice.key]}
                  aria-describedby={helpId}
                  onChange={(event) => state(choice.key, event.target.value)}
                  style={{ width: "100%" }}
                >
                  {/* The placeholder carries the empty string, which is what an
                      unanswered field IS. It is selected whenever the server proposed
                      nothing, so the control shows a question rather than an answer. */}
                  <option value="">Choose the {choice.label.toLowerCase()}…</option>
                  {choice.options.map((option) => (
                    <option key={option} value={option}>
                      {choice.kind === "format" ? FORMAT_LABELS.get(option) || option : option}
                    </option>
                  ))}
                </select>
              </span>
            )}

            <p id={helpId} className="constraint-line" style={{ marginTop: 6, marginBottom: 0 }}>
              {/* "Choose one." only while the field is still unanswered (verify pass 4,
                  S-E2E-4: it stayed under AUD and under a typed account name, so a
                  filled form read as one still asking). */}
              {helpLead(choice, mapping[choice.key]) === null ? null : helpLead(choice, mapping[choice.key]) === "choose" ? (
                <>
                  {/* THE SENTENCE THIS WHOLE SCREEN EXISTS FOR. */}
                  {/* Short field help in a bookkeeper's words (verify pass 1 SM4): the old
                      paragraph explained the design to the person using it, every field. */}
                  <b>Choose one.</b>{" "}
                </>
              ) : (
                <>
                  {/* A date format in words ("YYYY-MM-DD: 2026-02-01 is 1 February
                      2026"), never the parser's "%Y-%m-%d" (verify pass 3, S-E2E-4). */}
                  <b>Vert suggests {suggestedWords(choice, mapping[choice.key] || choice.proposed)}.</b> Check it.{" "}
                </>
              )}
              {choice.help}
            </p>
          </div>
        );
      })}

      {/* THE SIGN CONVENTION, IN ENGLISH, BEFORE THE BUTTON. A boolean is not a
          sentence, and the check that catches an inverted statement is reading a
          plain statement of what has just been said with its consequence attached. */}
      <div className={echo ? "note" : "note plain"} style={{ marginBottom: 16 }}>
        {echo || (
          <>
            Choose how a deposit is written and this says what will be imported.
          </>
        )}
      </div>

      {/* THE GATE — the echo, the only button that writes, and the sentence beside
          it. All three come off one view (lib/bank-import.js `importGateView`), so a
          commit label can never be drawn beside a "nothing has been written yet"
          sentence. components/settings/BankImportGate.js. */}
      {/* ONE IMPORT PER UPLOAD (founder's manual test, 7 Nov 2026, D15): after the
          service wrote the lines, the confirm stayed on screen for the spent upload, and
          each press answered "Nothing was imported · There is no uploaded statement with
          this inspection id" over an import that had worked. Once imported, the gate
          goes; the outcome below says what was written and the way on. */}
      {outcome && outcome.ok ? null : <BankImportGate view={gate} />}

      {/* The follow-on (CC2-1) runs from here only when no conversation is told of the
          import: a question that is (onImported) runs its own rec on the answer, and
          running both at once would answer it twice. */}
      <BankImportOutcome
        outcome={outcome}
        runFollowOn={typeof onImported !== "function"}
        onSettled={(found) => setSettled({ after: answered, outcome: found })}
      />
    </form>
  );
}
