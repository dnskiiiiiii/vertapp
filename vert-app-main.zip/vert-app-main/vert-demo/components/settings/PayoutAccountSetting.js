"use client";

// components/settings/PayoutAccountSetting.js — WHICH BANK ACCOUNT A PROCESSOR PAYS INTO
// ==============================================================================
// Stripe test run 1 Nov 2026, S-3. Northwind's Stripe pays into its own bank account
// (094). The sync read all six deposits there and every payout still said "no matching
// bank deposit found": a payout could tie only to the ledger's chosen account or an
// imported statement, and nothing let a person say which account was Stripe's.
//
// The accounts are the ledger's bank accounts, from the list Connections already reads
// (passed in; no read on open). The save is a Server Action, as the post mode's is: it
// works from the keyboard and before hydration, and carries the engine's own answer or
// refusal back. Secondary, not the accent: a setting is not a posting.
//
// Walk 4, W4-1: once picked, the choice could not be taken back. "None" (shown only
// while an account is set) sends `{"accountId": null}`, which clears it.

import { useActionState, useId, useState } from "react";

import { Button } from "@/components/ui";
import { PAYOUT_ACCOUNT_NONE, payoutAccountChoices, payoutAccountSaved } from "@/lib/connections-shape";
import { setPayoutAccountAction } from "./actions";

export default function PayoutAccountSetting({ row, bankState, canWrite = true, disabledReason = null }) {
  const [outcome, save, pending] = useActionState(setPayoutAccountAction, null);
  const choices = payoutAccountChoices(bankState);
  const [picked, setPicked] = useState(row && row.bankAccountId ? row.bankAccountId : "");
  const selectId = useId();
  const label = (choices.find((c) => c.id === picked) || {}).label || "";

  if (!choices.length) {
    // No list to pick from: the ledger's accounts weren't read. Said, never an empty menu.
    return (
      <p className="conn-note" data-payout-account-unread="">
        Vert couldn&rsquo;t list your bank accounts. Connect your ledger, then try again.
      </p>
    );
  }

  return (
    <form action={save} className="conn-mode" data-payout-account-setting="">
      <input type="hidden" name="provider" value={row.id} />
      <input type="hidden" name="label" value={label} />
      <label htmlFor={selectId} className="field-label">
        Bank account
      </label>
      <select
        id={selectId}
        name="accountId"
        className="inp"
        autoComplete="off"
        value={picked}
        onChange={(e) => setPicked(e.target.value)}
      >
        <option value="">Choose an account…</option>
        {(row && row.bankAccountId) || picked === PAYOUT_ACCOUNT_NONE ? <option value={PAYOUT_ACCOUNT_NONE}>None</option> : null}
        {choices.map((c) => (
          <option key={c.id} value={c.id}>
            {c.label}
          </option>
        ))}
      </select>
      <p className="conn-note">The account {row.name} pays your payouts into.</p>
      <div className="conn-sheet-actions">
        <Button type="submit" variant="secondary" size="sm" busy={pending} busyLabel="Saving…" disabledReason={!canWrite ? disabledReason || "Nothing can be changed here." : picked ? null : "Choose an account"}>
          Save
        </Button>
      </div>
      {outcome && outcome.ok ? (
        <p role="status" className="conn-note conn-mode-outcome" data-payout-account-saved={outcome.accountId || ""}>
          {payoutAccountSaved(outcome.label, outcome.name, { cleared: outcome.cleared === true })}
        </p>
      ) : null}
      {outcome && outcome.ok === false ? (
        <p role="alert" className="conn-note conn-mode-outcome" data-payout-account-refused="">
          {outcome.remedy}
        </p>
      ) : null}
    </form>
  );
}
