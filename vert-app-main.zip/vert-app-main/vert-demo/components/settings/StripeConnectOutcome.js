"use client";

// components/settings/StripeConnectOutcome.js — WHAT THE SERVICE SAID ABOUT THE KEY
// ==============================================================================
// Four things can come back from `POST /connections/stripe` and they send a merchant
// to four different places, which is the entire reason this is not one error box:
//
//   201  the key works — and it names WHICH ACCOUNT it resolved. That sentence is the
//        product feature: connecting the wrong account is the obvious mistake and the
//        alternative to catching it here is catching it at month end.
//   422  malformed — fix the paste.
//   401  rejected — wrong or revoked key.
//   403  a permission is missing — AND IT IS NAMED. This is the common case, and
//        "invalid key" here would send somebody to revoke a perfectly good key and
//        create another one with the same three permissions (spec §3.3).
//   503  Stripe unreachable — wait and retry. Nothing is wrong with the key.
//
// This component does not classify any of that. The service does, in `remedy`, and
// the named permissions arrive in `missing_permissions`; lib/connections-shape.js
// reads both. What is decided here is only where they go on the page.
//
// THE SUCCESS PLATE IS VIOLET AND NOT GREEN. A validated key is the machine
// completing something, not a human verifying a figure, and app/globals.css:57 says
// those two colours must not be collapsed.
//
// NO KEY IS RENDERED IN EITHER BRANCH. The outcome object does not carry one — see
// components/settings/actions.js, which returns the resolved account and nothing else.

import { missingPermissionSentence } from "@/lib/connections-shape";

export default function StripeConnectOutcome({ outcome }) {
  if (!outcome) return null;

  if (outcome.ok) {
    return (
      <div className="note" role="status" style={{ marginTop: 12 }}>
        <b>
          Connected to {outcome.account || "Stripe"}
          {outcome.accountId ? ` (${outcome.accountId})` : ""}.
        </b>{" "}
        {/* THE CHECK, IN THE SAME BREATH AS THE SUCCESS. A person who reads only the
            first half has confirmed nothing; the account name is only useful beside
            the instruction to look at it. */}
        That is the account Vert will read payouts from. If it is not the one you meant,
        disconnect it here and paste a key created inside the right account; a key
        cannot be moved between accounts.
        {outcome.accountId ? null : (
          <>
            {" "}
            The service did not return an account id, so this build cannot show which
            account it resolved beyond the name above.
          </>
        )}
        {/* A FULL SECRET KEY CONNECTS, WITH THE ENGINE'S WARNING (S-8): the guide promised
            one and none was shown. */}
        {outcome.warning ? (
          <p className="conn-note" role="note" data-key-warning="">
            {outcome.warning}
          </p>
        ) : null}
      </div>
    );
  }

  const named = missingPermissionSentence(outcome.missingPermissions);

  return (
    <div className="verify blocked" role="alert" style={{ marginTop: 12 }}>
      <div>
        <div className="v-title">Stripe was not connected</div>
        {/* THE NAMED PERMISSION FIRST, when there is one. It is the specific
            instruction, and the remedy below it is the general one. */}
        {named && <div className="v-body">{named}</div>}
        {/* The service's own remedy. Never its `error` slug: "stripe_key_rejected" is
            a word for a log, and a bookkeeper reading it has to guess what to do. */}
        {outcome.remedy && <div className="v-body">{outcome.remedy}</div>}
        {!named && !outcome.remedy && (
          <div className="v-body">
            The service refused the key and did not say what would fix it. Nothing was
            stored. Tell whoever runs Vert: a refusal with no remedy is a defect on
            the service, not something you can act on from here.
          </div>
        )}
      </div>
    </div>
  );
}
