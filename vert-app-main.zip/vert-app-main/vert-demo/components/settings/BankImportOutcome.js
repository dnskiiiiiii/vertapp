"use client";

// components/settings/BankImportOutcome.js — WHAT THE IMPORT DID, OR WHY IT DID NOT
// ==============================================================================
// Two numbers on success and never one. "142 lines imported" over a file of 200 is
// true as far as it goes, and the 58 it leaves out are either the idempotency working
// — a re-exported period, two overlapping download windows — or a file that half
// failed, and a person who cannot see the number cannot tell those apart. The
// sentence is written in lib/bank-import.js `importedLine`, which is tested directly.
//
// On a refusal: the REMEDY, and the ROW NUMBER when the service gave one. A refusal
// that says "an amount could not be parsed exactly" sends somebody through eleven
// hundred rows; the same refusal saying "row 412" is a thirty-second fix. Neither is
// composed here — `importRefusalLine` is the one place that joins them.
//
// VIOLET, NOT GREEN. Importing a statement is the machine completing something. Green
// on this app means a human verified a figure (app/globals.css:57) and no human has
// verified anything by choosing a file.

import { useEffect, useRef, useState } from "react";
import { Button, Disclosure } from "@/components/ui";
import {
  followOnLine,
  importRefusalLine,
  importRefusalReason,
  importedLine,
  lateImportLine,
  skippedLine,
  skippedRows,
  unconfirmedImportLine,
} from "@/lib/bank-import";
import { recheckImportAction, statementFollowOnAction } from "./actions";

/* ══════════════════════════════════════════════════════════════════════════ *
 * A REFUSAL ABOUT THE FILE, OR VERT BEING UNABLE TO IMPORT AT ALL — TWO SHAPES.
 *
 * A refusal about the FILE is the person's to fix, and the service's diagnosis and
 * remedy are the two lines they act on ("Row 4, column 'Credit': the cell is empty").
 * Those stay on the face, exactly as before.
 *
 * A failure on VERT'S side is not theirs to fix, and the service's words for it are
 * written for whoever runs it. Eval r1 (tester j2b) imported a statement against a
 * service started without its connections port and the sheet printed, on its face:
 * "Run the API through `vert_connect.serve`, which builds the connections port … 
 * `vert_api.main:app` deliberately never does". That is one plain line now — "Vert
 * can't import statements right now. Nothing was imported." — with the service's words
 * under Details (rubric S6, C7; spec §11.5: the code and anything an engineer needs go
 * under Details, closed).
 *
 * WHICH SHAPE is decided by what is known: the transport never reached the service or
 * the build has none (`kind`), the service answered 5xx or refused the credential
 * (`status`), or its words carry an operator's markers — a backtick, a module, a host,
 * a port, an environment variable. The last is a backstop for a 4xx the service
 * authored for an operator, and it can only move a sentence under Details, never drop
 * it: nothing the service said is lost.
 * ══════════════════════════════════════════════════════════════════════════ */

export const IMPORT_UNAVAILABLE = "Vert can't import statements right now. Nothing was imported.";

const OPERATOR_TEXT =
  /`|\bvert_[a-z_]+|\.py\b|https?:\/\/|127\.0\.0\.1|localhost|\bports?\b|environment variable|NEXT_PUBLIC|\bwhoever runs\b|\bAPI\b|\bentry point\b/i;

/** Has this sentence been written for whoever runs the service rather than for you? */
export function isOperatorText(text) {
  return typeof text === "string" && OPERATOR_TEXT.test(text);
}

/**
 * How a refusal reads: `{ serviceSide, lines, details }`. `lines` are the sentences on
 * the face (the diagnosis, then the remedy); `details` is what goes under Details, or
 * null. Pure, so both call sites (the file read and the import) render one decision.
 */
export function importFailureView(outcome) {
  const o = outcome || {};
  const reason = importRefusalReason(o);
  const line = importRefusalLine(o);
  const said = [reason, line].filter(Boolean);
  const status = Number.isInteger(o.status) ? o.status : null;
  const serviceSide =
    o.kind === "unreachable" ||
    o.kind === "unavailable" ||
    (status !== null && (status >= 500 || status === 401 || status === 403)) ||
    said.some(isOperatorText);
  if (serviceSide) {
    return {
      serviceSide: true,
      lines: [],
      details: said.length ? said.join(" ") : status ? `The service answered ${status} and gave no reason.` : null,
    };
  }
  return {
    serviceSide: false,
    // A refusal with no remedy at all is still a sentence, not an empty box.
    lines: said.length ? said : ["Vert refused the file and didn't say what would fix it."],
    details: null,
  };
}

/** The alert for a refusal. `title` is the file-side heading; Vert's side has its own. */
export function ImportRefusal({ outcome, title }) {
  const view = importFailureView(outcome);
  return (
    <div className="verify blocked" role="alert" style={{ marginTop: 12 }}>
      <div>
        <div className="v-title">{view.serviceSide ? IMPORT_UNAVAILABLE : title}</div>
        {view.lines.map((text, i) => (
          <div className="v-body" key={i}>
            {text}
          </div>
        ))}
        {view.details ? (
          <Disclosure summary="Details" className="import-details">
            <p className="import-detail">{view.details}</p>
          </Disclosure>
        ) : null}
      </div>
    </div>
  );
}

/**
 * THE WORK AFTER AN IMPORT, SAID AS PENDING AND THEN AS DONE (CC2-1). The engine
 * answers the confirm once the lines are stored; releasing what the file unblocked and
 * bringing its months' recs up to date is the follow-on, pressed here once, after the
 * person has been told the import landed.
 */
export function ImportFollowOn({ followOn, run = statementFollowOnAction }) {
  const [result, setResult] = useState(null);
  const started = useRef(null);
  useEffect(() => {
    if (!followOn || started.current === followOn.import_id) return;
    started.current = followOn.import_id;
    let live = true;
    Promise.resolve()
      .then(() => run(followOn))
      .catch(() => ({ ok: false }))
      .then((ran) => {
        if (live) setResult(ran || { ok: false });
      });
    return () => {
      live = false;
    };
  }, [followOn, run]);
  if (!followOn) return null;
  return (
    <div className="import-follow-on" role="status" aria-live="polite">
      {followOnLine(result)}
    </div>
  );
}

/**
 * AN IMPORT WHOSE ANSWER DID NOT ARRIVE (CC2-1): not a refusal, and never "Nothing was
 * imported". It says what the read-back found and offers the same read again; a read
 * that finds the import hands it to `onSettled`, as a confirm's own answer would be.
 */
export function ImportUnconfirmed({ outcome, onSettled = null, recheck = recheckImportAction }) {
  const [busy, setBusy] = useState(false);
  const [shown, setShown] = useState(outcome);
  async function again() {
    if (busy) return;
    setBusy(true);
    let next = null;
    try {
      next = await recheck(outcome.inspectionId);
    } catch {
      next = { ok: false, stage: "unconfirmed", inspectionId: outcome.inspectionId, read: null };
    }
    setBusy(false);
    if (next && next.ok && typeof onSettled === "function") onSettled(next);
    else setShown(next || shown);
  }
  return (
    <div className="verify" role="status" style={{ marginTop: 12 }}>
      <div>
        <div className="v-body">{unconfirmedImportLine(shown)}</div>
        <div style={{ marginTop: 8 }}>
          <Button type="button" size="sm" variant="secondary" busy={busy} busyLabel="Checking…" onClick={again}>
            Check again
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function BankImportOutcome({ outcome, onSettled = null, runFollowOn = true }) {
  if (!outcome) return null;

  if (outcome.stage === "unconfirmed") {
    return <ImportUnconfirmed key={outcome.inspectionId} outcome={outcome} onSettled={onSettled} />;
  }

  // THE PREVIEW IS NOT A FAILURE, AND MUST NOT BE DRESSED AS ONE. The service answers
  // the un-confirmed first pass with a 422 carrying the echo and the token — it read
  // the file, refused nothing, and is waiting for a person to agree. Rendered here as
  // "Nothing was imported" in a red alert, it reads as a broken import, and somebody
  // goes back to change answers that were correct. BankStatementMapping renders the
  // echo and the confirm control instead; this component stands down.
  if (outcome.stage === "review") return null;

  if (outcome.ok) {
    // THE THIRD COUNT. `importedLine` accounts for the rows the service WROTE and the
    // rows it recognised as already there; this accounts for the rows that were
    // neither, which is the difference between the two numbers above and the file the
    // person actually chose. Null only when the service sent a list and it was empty —
    // an absent list prints hardest of all, because that is the state that used to be
    // indistinguishable from a clean import. See lib/bank-import.js `skippedLine`.
    const skipped = skippedRows(outcome);
    const skippedSentence = skippedLine(outcome);
    return (
      <div className="note" role="status" style={{ marginTop: 12 }}>
        <b>{outcome.late ? lateImportLine(outcome) : importedLine(outcome)}</b>{" "}
        {outcome.importId ? (
          <>
            {/* THE IMPORT'S ID IS NOT SHOWN (UI walk D10, 30 Oct 2026): "csvimport:da9a…"
                is Vert's key for the import, not words a bookkeeper reads or quotes.
                Each line still carries it, its file and its row; this says so. */}
            Every line carries this import, its file and its row number, so any one of
            them can be traced back to the row it came from.
          </>
        ) : (
          <>
            The service did not return an import id, so these lines cannot be quoted
            back to a single import from this screen.
          </>
        )}
        {skippedSentence && (
          <>
            {" "}
            <span className="import-skipped">{skippedSentence}</span>
          </>
        )}
        {/* EVERY ROW THE SERVICE NAMED, WITH ITS OWN REASON, and not a count with the
            reasons folded away. The count says how many; only the sentence says
            whether they are a fact about the file or a fact about the mapping the
            person just answered, and those two call for opposite next actions.
            A row the service named but this build could not read is dropped by
            `skippedRows`, so the count above and this list can differ — which is why
            the count comes off the wire's own length and not off this list. */}
        {skipped.rows.length > 0 && (
          <ul className="import-skipped-rows">
            {skipped.rows.map((row, i) => (
              <li key={`${row.rowNumber ?? "?"}-${i}`}>
                {row.rowNumber === null
                  ? "A row the service did not number"
                  : `Row ${row.rowNumber}`}
                {": "}
                {row.reason ||
                  "the service named this row and recorded no reason for it, so nothing here says why it was not imported."}
              </li>
            ))}
          </ul>
        )}
        <ImportFollowOn followOn={runFollowOn ? outcome.followOn || null : null} />
        {/* THE WAY ON (founder's manual test, 7 Nov 2026, D12): the panel ended on the
            counts, and "5 lines skipped … up to date" read as stuck. The account's
            reconciliation is on Month-end. Not drawn inside a conversation's question,
            which carries on by itself. */}
        {runFollowOn ? (
          <p style={{ marginTop: 8, marginBottom: 0 }}>
            <a className="link" href="/" data-import-way-on="">
              Open Month-end
            </a>
          </p>
        ) : null}
      </div>
    );
  }

  // WHAT IS WRONG, THEN WHAT TO DO — two lines, never merged into one.
  //
  // MEASURED, 2026-08-23. `importRefusal` collapsed the service's diagnosis into its
  // remedy with a `||`, so a statement refused at row 4 for an empty Credit cell drew
  // "Row 4: Correct the mapping, the date format, the sign convention or the currency"
  // — four things to check on a file where the service had already named the one cell.
  // The diagnosis is the half a person acts on and it reached no screen. See
  // lib/bank-import.js `importRefusal` for the whole finding. `ImportRefusal` above
  // keeps the two lines, and moves a failure on Vert's side under Details.
  return <ImportRefusal outcome={outcome} title="Nothing was imported" />;
}
