// components/settings/ConnectionReturn.js — THE FIRST THING YOU SEE COMING BACK
// ==============================================================================
// Renders the outcome of an OAuth round trip at the top of /connections, above every
// other block on the page, because it is the answer to the question the person is
// holding when they arrive: did that work?
//
// IT IS THE FIX FOR A PAGE THAT SAID NOTHING. Until 2026-08-23 all four outcomes of
// `GET /connections/{provider}/callback` redirected to a bare settings URL, so a
// decline, a rejected state, a broken token exchange and a successful connection were
// indistinguishable — the person landed on the page they had left. The engine now
// names the outcome in the query string; this is the half that says it out loud.
//
// THE COMPONENT DECIDES NOTHING. `connectionReturn` in lib/connection-return.js maps
// the marker to a tone and two sentences, and that is where every word lives and where
// they are pinned. What is decided here is only where they go on the page and which
// plate they sit on — the same division StripeConnectOutcome states about itself.
//
// THE PLATES, AND WHY THESE THREE.
//   done      `.note`, violet. The machine completed something. NOT `.verify.ok`,
//             which is green, and green on this app means A HUMAN VERIFIED A FIGURE
//             (app/globals.css:57). An OAuth exchange is the machine finishing a job,
//             and collapsing those two is the one rule this colour vocabulary has.
//   caution   `.verify.caution`, amber — the app's existing slot for "a person has to
//             look at this". Carries the decline and the unreadable marker: in neither
//             case has anything broken, and in both the errand the person set out on
//             did not finish. A grey aside would be how that goes unnoticed.
//   blocked   `.verify.blocked`, red. Something went wrong and it was not their doing.
//
// ROLE FOLLOWS THE PLATE, NOT THE HOUSE STYLE OF THE FILE. `role="alert"` on the two
// red outcomes, because a screen reader user who has just been redirected back from
// another origin has no reason to go hunting for a plate they were never told about;
// `role="status"` on the rest, which announces politely without interrupting.
//
// `data-vert-return` IS FOR TESTS AND IT IS ON THE PLATE ITSELF. Asserting a sentence
// against the whole page is how a mutation survives its test on this project — a
// page-wide regex is satisfied by any sentence anywhere, including the one the
// mutation did not touch. This attribute makes the element addressable so an
// assertion can be scoped to it.

import { connectionReturn } from "@/lib/connection-return";

export default function ConnectionReturn({ params }) {
  const outcome = connectionReturn(params);
  // No marker, no plate. An ordinary visit to Connections is not a return leg, and a
  // permanent "we don't know what happened" banner shown to everybody forever is a
  // false alarm rather than an honest absence. See lib/connection-return.js.
  if (!outcome) return null;

  const marker = outcome.result || "unknown";

  if (outcome.tone === "done") {
    return (
      <div className="note" role="status" data-vert-return={marker} style={{ marginBottom: 12 }}>
        <b>{outcome.title}</b> {outcome.body}
      </div>
    );
  }

  return (
    <div
      className={`verify ${outcome.tone}`}
      role={outcome.tone === "blocked" ? "alert" : "status"}
      data-vert-return={marker}
      style={{ marginBottom: 12 }}
    >
      <div>
        <div className="v-title">{outcome.title}</div>
        <div className="v-body">{outcome.body}</div>
      </div>
    </div>
  );
}
