"use server";

// components/settings/actions.js — THE WRITES BEHIND THE CONNECTIONS SCREEN
// ==============================================================================
// Server Actions rather than browser fetches, for the reason lib/actions.js gives and
// one stronger reason that belongs to this screen alone: THE RESTRICTED KEY MUST
// NEVER BE IN A PAGE. A client-side fetch would put a live credential to a merchant's
// Stripe account into the browser bundle's request path, into any error reporter
// attached to it, and into whatever a browser extension can read. Here it arrives in
// the body of a POST to this server, is handed to the API, and is not returned, not
// logged and not echoed into any outcome below.
//
// EVERY ACTION RETURNS THE SHAPE `useActionState` HOLDS, and none of them throws:
//
//   { ok: true,  ... }                         the named facts the screen renders
//   { ok: false, remedy, missingPermissions }  a refusal, in the words of the service
//
// `remedy` and never `error`. That is the house rule and the contract writes it into
// the wire format: every 4xx/5xx body carries a sentence a bookkeeper can act on
// beside a slug meant for a log. The reading is done by lib/connections-shape.js and
// lib/bank-import.js — pure functions, tested directly — so nothing here words a
// refusal and no component re-decides how one is read.

import { statedFromForm } from "@/lib/statement-stated";
import { revalidatePath } from "next/cache";

import { DOCUMENT_MODES, PAYOUT_ACCOUNT_NONE, POST_MODES, PROVIDERS, authorizeRefusal, disconnectReport, documentModeRefusal, payoutAccountRefusal, postModeRefusal, refusalOf } from "@/lib/connections-shape";
import { EXPIRED_CODE, importGate, importReadBack, importRefusal, inspectionSummary } from "@/lib/bank-import";
import { authorizationUrl } from "@/lib/connections";
import { fileLoanStatement, readLoanStatement, uploadDocument } from "@/lib/documents";
import {
  confirmBankStatement,
  connectStripe,
  disconnectProvider,
  followOnStatement,
  inspectBankStatement,
  setDocumentMode,
  setPayoutAccount,
  setPostMode,
  statementOutcome,
} from "@/lib/connections";

// Connecting, disconnecting and importing all move durable state that the layout and
// every screen under it render from — what is connected, and, after an import, the
// bank lines a payout ties against. The layout is their common ancestor, which is why
// the scope is "layout", exactly as lib/actions.js does it.
function refresh() {
  revalidatePath("/", "layout");
}

// One refusal shape for every action, built from the service's own body. `message` is
// the transport's sentence and appears ONLY where the service never answered at all —
// no build configured, or nothing on the other end — so a refusal the API worded is
// never overwritten by one this app worded.
function refused(result) {
  const refusal = refusalOf(result.status, result.body);
  return {
    ok: false,
    kind: result.kind,
    status: result.status,
    remedy: refusal.remedy || result.message || null,
    missingPermissions: refusal.missingPermissions,
  };
}

/**
 * Connect Stripe from a pasted restricted key.
 *
 * ON SUCCESS IT NAMES THE ACCOUNT. The 201 carries `external_id` and `display_name`
 * resolved from a live authenticated read, and putting them on screen is the whole
 * point of validating before storing: connecting the wrong account is the obvious
 * user error, and the alternative to catching it here is catching it at month end
 * when a register is empty and nobody knows why (spec §3.3).
 */
export async function connectStripeAction(_previous, formData) {
  const key = String(formData.get("restricted_key") || "").trim();
  if (!key) {
    // Refused before the wire is spent, in the same words the API would use. The
    // control saying so, never a second rule: the API refuses an empty key too.
    return {
      ok: false,
      kind: "refused",
      status: 0,
      remedy:
        "Paste the restricted key you created in Stripe. It begins with rk_ and is " +
        "shown once, when it is created.",
      missingPermissions: [],
    };
  }

  const result = await connectStripe(key);
  if (!result.ok) return refused(result);

  refresh();
  const body = result.body || {};
  return {
    ok: true,
    // THE KEY IS NOT HERE, not masked and not truncated. What comes back is who the
    // key turned out to be.
    account: typeof body.display_name === "string" ? body.display_name : null,
    accountId: typeof body.external_id === "string" ? body.external_id : null,
    connected: body.connected === true,
    // The engine's warning for a full secret key (S-8), or null.
    warning: typeof body.warning === "string" && body.warning.trim() ? body.warning.trim() : null,
  };
}

/**
 * Disconnect a provider. Revokes at the vendor where possible, then locally.
 *
 * 204 carries no body, so there is nothing to quote back — the honest report is the
 * name of what was disconnected plus the fact that the next render reads the database
 * rather than this outcome.
 */
// TWO ACTIONS WERE HERE — `loadChartMappingAction` and `saveChartMappingAction` — and
// both called `/ledger/map`, a route the engine does not have and never has. They are
// gone with it; see lib/connections.js and components/settings/AccountMappingNote.js
// for where the mapping actually comes from and who loads it.

// `refusalMessage` WENT WITH THEM. Its only callers were the two mapping actions above;
// it is not deleted for tidiness but because a helper with no caller is a helper that
// drifts from what it once described — its own comment was about a sentence rendered by
// ChartMapping, on a screen that no longer exists.


/** Begin an OAuth connection. Returns the consent URL for the browser to follow.
 *
 * WHY THIS EXISTS AT ALL. The QuickBooks card used to say the callback "is not in this
 * build", and withheld the button on that basis. The callback shipped; the sentence
 * did not change. So the one control standing between a decomposed payout and a posted
 * entry was withheld by a claim that had stopped being true — and the person whose
 * books they are could not switch it on, which is the exact failure the panel's own
 * header says it exists to prevent.
 *
 * It returns the URL rather than redirecting, because a `redirect()` inside a Server
 * Action called from a client component throws a control-flow error the caller has to
 * know not to catch. Handing back a URL and letting the browser navigate keeps the
 * refusal path — an expired session, a service with no OAuth key — renderable as an
 * ordinary sentence next to the button.
 */
export async function beginAuthorizationAction(provider) {
  const named = typeof provider === "string" ? provider.trim() : "";
  if (!named) {
    return { ok: false, message: "No provider was named, so nothing was sent." };
  }
  // A REQUEST THAT TIMES OUT OR DROPS IS A SENTENCE, NOT A CRASH (production, 3 Nov 2026):
  // a cold service took longer than the request allows, the fetch threw, and the throw
  // reached the page's error boundary ("This page stopped working") instead of the button.
  let result;
  try {
    result = await authorizationUrl(named);
  } catch {
    return { ok: false, kind: "unreachable", message: "Vert couldn't reach the service just now. Nothing was changed. Try again." };
  }
  if (result.ok) return { ok: true, url: result.url };

  // Read by lib/connections-shape.js, tested there: the tenant's OTHER ledger being
  // connected (409 another_ledger_connected) comes back as a calm notice naming it with
  // the engine's remedy; anything else is the service's own sentence, and where it said
  // nothing, that there is nowhere to send them (never a status code: spec §8, and this
  // sentence is rendered under the Connect button a first-run tenant meets).
  const refusal = authorizeRefusal(result.status, result.body);
  return { ok: false, ...refusal, message: refusal.kind === "refused" ? refusal.message : refusal.title };
}

export async function disconnectProviderAction(_previous, formData) {
  const provider = String(formData.get("provider") || "").trim();
  if (!provider) {
    return {
      ok: false,
      kind: "refused",
      status: 0,
      remedy: "No provider was named, so nothing was sent to the service.",
      missingPermissions: [],
    };
  }

  const result = await disconnectProvider(provider);
  if (!result.ok) return refused(result);

  refresh();
  // A 200 WITH A BODY IS NOT A CLEAN BREAK. The service answers 204 only when nothing
  // is left live anywhere; a body means the local row is revoked and the credential
  // still exists at the vendor, and the remedy is the instruction to go and delete it.
  // Returning `{ok: true}` here — which is what this did — put "disconnected" on screen
  // over a live key to a merchant's payment processor that nobody would ever remove.
  const report = disconnectReport(result.status, result.body);
  return { ok: true, provider, report };
}

/**
 * Choose what happens to an entry once it is approved: posted, or sent as a draft
 * (17 Oct 2026). `PUT /connections/{provider}/post-mode`.
 *
 * ON SUCCESS IT SAYS WHAT THE ENGINE SAYS IS SET, not what was asked for: the 200 is the
 * updated connection row, and its `postMode` is the answer. A row that names none is a
 * save that landed with the setting unsaid, and the screen says exactly that.
 *
 * A REFUSAL IS THE ENGINE'S SENTENCE (lib/connections-shape.js `postModeRefusal`), and
 * where nothing answered at all, the transport's own sentence — never a generic error.
 * The ledger status the post sheets read (`/approvals/ledger`) follows the mode, so the
 * layout is revalidated exactly as a connect is.
 */
export async function setPostModeAction(_previous, formData) {
  const provider = String(formData.get("provider") || "").trim();
  const mode = String(formData.get("mode") || "").trim();
  const name = (PROVIDERS.find((p) => p.id === provider) || {}).name || null;
  if (!provider || !POST_MODES.includes(mode)) {
    return {
      ok: false,
      status: 0,
      code: null,
      remedy: provider
        ? "Choose one of the two, then save again. Nothing was sent."
        : "No ledger was named, so nothing was sent.",
    };
  }

  const result = await setPostMode(provider, mode);
  if (!result.ok) {
    const refusal = postModeRefusal(result.status, result.body, { name });
    return {
      ok: false,
      status: result.status,
      code: refusal.code,
      // The transport's sentence only where the service never answered (no build, no
      // socket): a refusal the engine worded is never overwritten by one worded here.
      remedy: result.body === null && result.message ? result.message : refusal.remedy,
    };
  }

  refresh();
  const row = result.body && typeof result.body === "object" ? result.body : {};
  return { ok: true, provider, mode: POST_MODES.includes(row.postMode) ? row.postMode : null };
}

/**
 * Choose how an approved bill, invoice or credit note reaches the ledger: a draft there,
 * or approved, awaiting payment (4 Nov 2026). `PUT /connections/{provider}/document-mode`.
 *
 * The same shape as `setPostModeAction`: ON SUCCESS IT SAYS WHAT THE ENGINE SAYS IS SET
 * (the 200's row's `documentMode`), never what was asked for; a row that names none is a
 * save that landed with the setting unsaid. A refusal is the engine's sentence
 * (`documentModeRefusal`), or the transport's where nothing answered at all.
 */
export async function setDocumentModeAction(_previous, formData) {
  const provider = String(formData.get("provider") || "").trim();
  const mode = String(formData.get("mode") || "").trim();
  const name = (PROVIDERS.find((p) => p.id === provider) || {}).name || null;
  if (!provider || !DOCUMENT_MODES.includes(mode)) {
    return {
      ok: false,
      status: 0,
      code: null,
      remedy: provider
        ? "Choose one of the two, then save again. Nothing was sent."
        : "No ledger was named, so nothing was sent.",
    };
  }

  const result = await setDocumentMode(provider, mode);
  if (!result.ok) {
    const refusal = documentModeRefusal(result.status, result.body, { name });
    return {
      ok: false,
      status: result.status,
      code: refusal.code,
      remedy: result.body === null && result.message ? result.message : refusal.remedy,
    };
  }

  refresh();
  const row = result.body && typeof result.body === "object" ? result.body : {};
  return { ok: true, provider, mode: DOCUMENT_MODES.includes(row.documentMode) ? row.documentMode : null };
}

/**
 * "Payouts land in" (Stripe test run 1 Nov 2026, S-3): which ledger bank account a
 * processor pays into. `provider` and `accountId` come from the form; `label` is the
 * account's words, said back on the saved line. "None" (walk 4, W4-1) clears the choice:
 * `{"accountId": null}`. Never throws.
 */
export async function setPayoutAccountAction(_previous, formData) {
  const provider = String(formData.get("provider") || "").trim();
  const accountId = String(formData.get("accountId") || "").trim();
  const name = (PROVIDERS.find((p) => p.id === provider) || {}).name || null;
  if (!provider || !accountId) {
    return { ok: false, status: 0, remedy: "Pick an account, then save. Nothing was sent." };
  }
  const cleared = accountId === PAYOUT_ACCOUNT_NONE;
  const result = await setPayoutAccount(provider, cleared ? null : accountId);
  if (!result.ok) {
    return {
      ok: false,
      status: result.status,
      remedy: result.body === null && result.message ? result.message : payoutAccountRefusal(result.status, result.body),
    };
  }
  refresh();
  const row = result.body && typeof result.body === "object" ? result.body : {};
  return {
    ok: true,
    provider,
    name,
    accountId: typeof row.bank_account_id === "string" ? row.bank_account_id : null,
    label: cleared ? null : String(formData.get("label") || "").trim() || null,
    cleared,
  };
}

/**
 * Step one of the import: inspect the file. NOTHING IS WRITTEN.
 *
 * The response is the server's reading of the file — its columns, its row count, and
 * a proposal that may be silent on any field. The silence is carried through as
 * silence; see lib/bank-import.js, which is where refusing to fill it in is enforced.
 */
export async function inspectStatementAction(_previous, formData) {
  const file = formData.get("file");
  if (!file || typeof file === "string" || !file.name) {
    return {
      ok: false,
      kind: "refused",
      status: 0,
      // No longer "then press Inspect": choosing the file is what reads it, and the
      // second press that used to be here is the step the attachment was lost on
      // (BankStatementImport.js). A remedy naming a control that no longer exists
      // sends somebody looking for a button that is not there.
      remedy: "Choose a CSV file exported from your bank.",
      reason: null,
      rowNumber: null,
      inspection: null,
    };
  }

  const forward = new FormData();
  forward.append("file", file, file.name);
  // THE ACCOUNT PICKED ON THE IMPORT (lib/statement-accounts.js), sent as the proposals
  // the engine previews under; the mapping form shows each as "Vert suggests", and the
  // echo repeats them before anything is written. Never applied unseen.
  // `kind` is read for the sign field and never forwarded (D48b).
  const stated = statedFromForm(formData);
  if (stated.account_id) forward.append("account_id", stated.account_id);
  if (stated.currency) forward.append("currency", stated.currency);
  if (stated.deposits_are_positive === "yes" || stated.deposits_are_positive === "no") {
    forward.append("deposits_are_positive", stated.deposits_are_positive === "yes" ? "true" : "false");
  }

  const result = await inspectBankStatement(forward);
  if (!result.ok) {
    const refusal = importRefusal(result.body);
    return {
      ok: false,
      kind: result.kind,
      status: result.status,
      // BOTH HALVES OF THE SERVICE'S REFUSAL. `reason` is what is wrong and `remedy`
      // is what to do; lib/bank-import.js `importRefusal` records why they stopped
      // being one field. A refusal this app composed itself carries `reason: null` —
      // it has no diagnosis beyond the sentence it already wrote.
      reason: refusal.reason,
      remedy: refusal.remedy || result.message || null,
      rowNumber: refusal.rowNumber,
      inspection: null,
    };
  }

  const inspection = inspectionSummary(result.body);
  if (!inspection.inspectionId) {
    return {
      ok: false,
      kind: "refused",
      status: result.status,
      remedy:
        "The service read the file but did not return an inspection id, so there is " +
        "nothing to confirm against. Nothing was imported.",
      reason: null,
      rowNumber: null,
      inspection: null,
    };
  }

  return {
    ok: true,
    // The file's own name, which becomes the provenance of every line imported from
    // it. Held here so the confirm step can print what it is about to commit.
    fileName: file.name,
    // Carries the RAW proposal inside it, absences and all, because lib/bank-import.js
    // is what decides what a missing field means and this action must not pre-empt it.
    inspection,
    // The picked account's proposals, for the mapping form to SUGGEST (never to state).
    stated: Object.keys(stated).length ? stated : null,
  };
}

/**
 * A lender's statement: stored as a document, then read by the engine for its closing
 * balance, interest and repayments (`POST /loan-statements/read`, writes nothing). The
 * figures are shown before the person files it as the loan's statement.
 */
export async function readLoanStatementAction(_previous, formData) {
  const file = formData.get("file");
  const accountId = String(formData.get("loan_account_id") || "").trim();
  if (!file || typeof file === "string" || !file.name) {
    return { ok: false, kind: "refused", status: 0, remedy: "Choose the lender's statement: a CSV or a PDF.", reason: null };
  }
  if (!accountId) {
    return { ok: false, kind: "refused", status: 0, remedy: "Choose which loan this statement is for.", reason: null };
  }
  const upload = new FormData();
  upload.append("file", file, file.name);
  const stored = await uploadDocument(upload);
  if (!stored.ok) return { ok: false, kind: stored.kind, status: stored.status || 0, remedy: stored.message || "The statement wasn't stored. Nothing was read.", reason: null };
  const documentId = stored.document.documentId;
  const read = await readLoanStatement(documentId, accountId);
  if (!read.ok) return { ok: false, kind: read.kind, status: read.status, remedy: read.message || "Vert couldn't read the statement.", reason: null };
  return { ok: true, fileName: file.name, documentId, accountId, reading: read.body };
}

/** File the read statement as the loan's (`POST /loan-statements`). 409: it already is. */
export async function fileLoanStatementAction(documentId, accountId) {
  const result = await fileLoanStatement(documentId, accountId);
  if (result.ok) refresh();
  return result;
}

/**
 * Step two: commit the statement under a stated mapping.
 *
 * THE MAPPING IS READ OFF THE FORM, FIELD BY FIELD, AND NOTHING IS DEFAULTED. A field
 * the person did not state arrives as the empty string and is refused here — never
 * substituted, never inferred from the file, never quietly dropped from the body so
 * the server can pick. That last one is the subtle version of the same defect and it
 * is why every field is required explicitly below.
 */
export async function confirmStatementAction(_previous, formData) {
  const inspectionId = String(formData.get("inspection_id") || "").trim();
  const stated = {
    date_column: String(formData.get("date_column") || "").trim(),
    description_column: String(formData.get("description_column") || "").trim(),
    amount_column: String(formData.get("amount_column") || "").trim(),
    date_format: String(formData.get("date_format") || "").trim(),
    deposits_are_positive: String(formData.get("deposits_are_positive") || "").trim(),
    currency: String(formData.get("currency") || "").trim(),
    account_id: String(formData.get("account_id") || "").trim(),
  };

  // The token from the echo the person has just read, when they are agreeing to it.
  // Read off the form rather than held on this server: it belongs to a statement of
  // intent the browser is holding, and a token cached here would outlive the sentence
  // it was issued against. Absent on the first pass, which is what makes the first
  // pass a preview.
  const confirmation = String(formData.get("confirmation") || "").trim();

  if (!inspectionId) {
    return {
      ok: false,
      kind: "refused",
      status: 0,
      remedy: "This upload has no inspection to confirm against. Upload the file again.",
      reason: null,
      rowNumber: null,
    };
  }

  const unstated = Object.entries(stated)
    .filter(([, value]) => value === "")
    .map(([key]) => key.replace(/_/g, " "));
  if (unstated.length) {
    return {
      ok: false,
      kind: "refused",
      status: 0,
      remedy:
        `Nothing was imported: ${unstated.join(", ")} ${unstated.length === 1 ? "was" : "were"} ` +
        `not stated. Every one of them has to be answered: a column this screen ` +
        `guessed at would produce a statement that balances and is wrong.`,
      reason: null,
      rowNumber: null,
    };
  }

  const result = await confirmBankStatement(inspectionId, {
    date_column: stated.date_column,
    description_column: stated.description_column,
    amount_column: stated.amount_column,
    date_format: stated.date_format,
    // The one field that changes type on the way to the wire. "yes"/"no" exists so
    // that UNSTATED is representable in the control; the boolean is the contract's.
    deposits_are_positive: stated.deposits_are_positive === "yes",
    currency: stated.currency,
    // Required by the service, absent from the pinned contract. Never defaulted from
    // the file name — see lib/bank-import.js MAPPING_FIELDS.
    account_id: stated.account_id,
    // Sent ONLY when the person has one, which is only after they have been shown the
    // echo. This action never mints one and never re-sends one it invented: calling
    // the service twice here — once to obtain a token, once to hand it straight back —
    // is one line, and that line would convert the gate into decoration while leaving
    // every test that asserts "committing works" green.
    ...(confirmation ? { confirmation } : {}),
  });

  if (!result.ok && result.unconfirmed && confirmation) {
    // THE ANSWER DID NOT COME BACK, AND THAT IS NOT "NOTHING WAS IMPORTED" (staging
    // cash-coding check 2, CC2-1). The commit went out and timed out: the lines may be
    // in Vert. Read back what the confirm did and say that; when the read can't
    // settle it, say "couldn't confirm" and offer the same read again.
    const outcome = importReadBack(await statementOutcome(inspectionId), inspectionId);
    if (outcome.ok) refresh();
    return outcome;
  }

  if (!result.ok) {
    // THE PREVIEW, WHICH IS A 422 AND IS NOT A FAILURE. The service parsed the file,
    // applied every refusal, minted every line and wrote nothing, and is waiting for
    // the person answerable for this close to read what is about to happen. Rendered
    // as a refusal — which is what this did — the import could never complete at all:
    // the screen said "nothing was imported", which was true, and gave no way to say
    // yes.
    const gate = importGate(result.body);
    if (gate) {
      return {
        ok: false,
        // Not "refused". A distinct stage, so the component can render the echo and a
        // confirm control rather than a red alert box about a failure.
        stage: "review",
        kind: result.kind,
        status: result.status,
        echo: gate.echo,
        // THE ANSWERS THIS REQUEST ACTUALLY CARRIED, so the screen can tell whether
        // the echo it is showing still describes what is on screen. It used to keep a
        // copy of the answers taken in the browser BEFORE the request went out, which
        // is a copy that can be right while the request was not; this is the body that
        // was sent. lib/bank-import.js `reviewInForce` is the comparison, and it is the
        // staleness half of the two-press gate — the token digests these exact facts,
        // so an edit between the two presses must retract the agreement rather than
        // leave somebody agreeing in good faith to a sentence that has stopped being
        // true of their answers.
        stated,
        // Handed straight back to the form, which sends it with the next submission.
        // It digests the exact facts in the echo above, so if any answer changes the
        // service refuses it. It travelled as a hidden input until 2026-08-23 and now
        // goes through `confirmFormData` — see BankStatementMapping, where an `action`
        // prop on the form was found blanking every answer the token digests.
        confirmation: gate.confirmation,
        reason: null,
        rowNumber: null,
      };
    }

    const refusal = importRefusal(result.body);
    return {
      ok: false,
      kind: result.kind,
      status: result.status,
      // BOTH HALVES OF THE SERVICE'S REFUSAL. `reason` is what is wrong and `remedy`
      // is what to do; lib/bank-import.js `importRefusal` records why they stopped
      // being one field. A refusal this app composed itself carries `reason: null` —
      // it has no diagnosis beyond the sentence it already wrote.
      reason: refusal.reason,
      remedy: refusal.remedy || result.message || null,
      rowNumber: refusal.rowNumber,
      // An upload that was held and is now too old is a DIFFERENT instruction from an
      // id this service never issued: "do that again" against "this is not the preview
      // you think it is". The component uses this to send the person back to the file
      // picker rather than leaving them pressing confirm on an id that is gone.
      expired: refusal.code === EXPIRED_CODE,
    };
  }

  refresh();
  const body = result.body || {};
  return {
    ok: true,
    // The service's own counts, carried and never combined. Both are printed.
    imported: body.imported,
    duplicates_skipped: body.duplicates_skipped,
    // THE THIRD COUNT, AND THE ONE THAT USED TO VANISH BETWEEN THE SERVICE AND THIS
    // SCREEN. Rows that were neither imported nor duplicates — a totals row, a
    // carried-forward balance, a blank separator, a line with nothing in the amount
    // column — with a row number and a reason each.
    //
    // COPIED WITHOUT A DEFAULT. `body.skipped` is passed through exactly as it
    // arrived, including `undefined` from a service too old to send it, because
    // lib/bank-import.js `skippedRows` distinguishes "sent an empty list" from "sent
    // nothing" and a `|| []` here would destroy that distinction at the one place it
    // is still recoverable. An empty list is a measurement; a missing key is not.
    skipped: body.skipped,
    importId: typeof body.import_id === "string" ? body.import_id : null,
    // WHAT IS STILL TO RUN (CC2-1): the engine answers once the lines are stored and
    // hands back the body of the follow-on, which the screen presses next and says
    // as pending. Null from a service that ran it all in the confirm.
    followOn: followOnOf(body.follow_on),
  };
}

function followOnOf(raw) {
  if (!raw || typeof raw !== "object" || raw.state !== "pending") return null;
  if (typeof raw.import_id !== "string" || typeof raw.account_id !== "string") return null;
  return { import_id: raw.import_id, account_id: raw.account_id };
}

/**
 * Check again: read back what the confirm did to `inspectionId` (CC2-1). The same
 * read the confirm makes when its answer times out; writes nothing.
 */
export async function recheckImportAction(inspectionId) {
  const id = String(inspectionId || "").trim();
  if (!id) return importReadBack(null, id);
  const outcome = importReadBack(await statementOutcome(id), id);
  if (outcome.ok) refresh();
  return outcome;
}

/**
 * After an import: the follow-on the confirm handed back (`POST
 * /bank-statements/follow-on`). `{ok, months, reconciled, stale}` or `{ok: false}`.
 */
export async function statementFollowOnAction(followOn) {
  const body = followOnOf(followOn && { state: "pending", ...followOn });
  if (!body) return { ok: false };
  const result = await followOnStatement(body);
  if (!result.ok) return { ok: false };
  refresh();
  const ran = result.body || {};
  return {
    ok: true,
    months: Array.isArray(ran.months) ? ran.months : null,
    reconciled: Array.isArray(ran.reconciled) ? ran.reconciled : null,
    stale: Array.isArray(ran.stale) ? ran.stale : null,
  };
}
