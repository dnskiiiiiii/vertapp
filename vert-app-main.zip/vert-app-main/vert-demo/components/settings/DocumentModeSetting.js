"use client";

// components/settings/DocumentModeSetting.js — HOW AN APPROVED BILL, INVOICE OR CREDIT NOTE
// REACHES THE LEDGER
// ==============================================================================
// 4 Nov 2026: for a ledger that offers it (Xero), each client chooses whether a supplier
// bill, sales invoice or bad-debt credit note approved in Vert arrives as a DRAFT that
// somebody approves again in the ledger (today's behaviour, the default) or APPROVED,
// awaiting payment. A sales invoice is approved, never emailed to the customer; a
// bad-debt credit note sent approved is also allocated to the invoice it writes off.
//
// The twin of PostModeSetting.js beside it, and drawn beside it in the connected ledger's
// sheet (components/setup/ConnectionsList.js), only for a row whose catalogue entry says
// `documentModes`. The words are the catalogue's (lib/connections-shape.js
// `documentModeChoices`), named by the row, so this file spells no vendor.
//
// THE SELECTED CHOICE IS THE ENGINE'S ANSWER, NEVER A DEFAULT: `row.documentMode` is null
// when the row did not say, and then neither choice is selected and the sheet says so.
// The saved line says what the engine returned, not what was asked.

import { useActionState, useId, useState } from "react";

import { Button } from "@/components/ui";
import { documentModeChoices, documentModeSaved } from "@/lib/connections-shape";
import { setDocumentModeAction } from "./actions";

export default function DocumentModeSetting({ row, canWrite = true, disabledReason = null, initial = null }) {
  const [outcome, save, pending] = useActionState(setDocumentModeAction, initial);
  const savedMode = outcome && outcome.ok === true && outcome.mode ? outcome.mode : row.documentMode;
  const [chosen, setChosen] = useState(savedMode);
  const legendId = useId();
  const choices = documentModeChoices(row);
  const savedStands = outcome && outcome.ok === true && (outcome.mode === null || outcome.mode === chosen);

  return (
    <form action={save} className="conn-mode" data-document-mode-setting="">
      <input type="hidden" name="provider" value={row.id} />
      <fieldset className="conn-mode-set" aria-labelledby={legendId}>
        <legend id={legendId} className="conn-mode-legend">
          When you approve a bill, invoice or credit note
        </legend>
        {choices.map((choice) => {
          const id = `${legendId}-${choice.value}`;
          return (
            <label key={choice.value} className="conn-mode-choice" htmlFor={id} data-chosen={chosen === choice.value ? "" : undefined}>
              <input
                type="radio"
                id={id}
                name="mode"
                value={choice.value}
                checked={chosen === choice.value}
                onChange={() => setChosen(choice.value)}
                aria-describedby={`${id}-help`}
              />
              <span className="conn-mode-text">
                <span className="conn-mode-label">{choice.label}</span>
                <span className="conn-mode-help" id={`${id}-help`}>
                  {choice.help}
                </span>
              </span>
            </label>
          );
        })}
      </fieldset>
      {row.documentMode === null && !(outcome && outcome.ok) ? (
        <p className="conn-note">Vert couldn&rsquo;t read which one is set for this client.</p>
      ) : null}
      <div className="conn-sheet-actions">
        <Button type="submit" variant="secondary" size="sm" busy={pending} busyLabel="Saving…" disabledReason={canWrite ? null : disabledReason || "Nothing can be changed here."}>
          Save
        </Button>
      </div>
      {savedStands ? (
        <p role="status" className="conn-note conn-mode-outcome" data-document-mode-saved={outcome.mode || ""}>
          {documentModeSaved(outcome.mode, row.name)}
        </p>
      ) : null}
      {outcome && outcome.ok === false ? (
        <p role="alert" className="conn-note conn-mode-outcome" data-document-mode-refused={outcome.code || ""}>
          {outcome.remedy}
        </p>
      ) : null}
    </form>
  );
}
