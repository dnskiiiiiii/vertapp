"use client";

// components/settings/DisconnectOutcome.js — WHAT A DISCONNECT ACTUALLY MANAGED TO DO
// ==============================================================================
// A DISCONNECT IS TWO WRITES AND THEY CAN DISAGREE. The local row is revoked here; the
// credential itself lives at the vendor and has to be revoked there too. Revoking only
// locally leaves a live credential this system has merely forgotten about — which is
// strictly worse than not disconnecting at all, because the screen now says it is gone
// and nobody will ever go and delete it.
//
// So the service reserves 204 — no body — for the case where nothing is left live:
// there was no connection, or both halves succeeded. Anything else is 200 WITH a body
// naming what was done, what was not, and what the person still has to do. THE
// PRESENCE OF A BODY IS THE SIGNAL. An earlier draft of the contract had this route
// always answer 204; it was withdrawn precisely because 204 cannot express the
// half-done case it would most often be describing.
//
// This build cannot revoke a restricted key at the payment processor — there is no API
// for it, the merchant deletes it on the vendor's own key screen — so a 200 with a
// remedy is the ORDINARY outcome of disconnecting a live Stripe connection, not an
// exotic one. Rendering it as a plain success is the failure this component exists to
// prevent.
//
// A SEPARATE COMPONENT, TAKING THE OUTCOME AS A PROP, for the reason
// BankStatementMapping gives about itself: it makes the behaviour renderable, and
// therefore testable, without a browser and without driving a Server Action.
//
// THE STILL-LIVE CASE IS AN ALERT AND NOT A NOTE. There is something for a person to
// do, and a quiet grey line is how it does not get done.

export default function DisconnectOutcome({ outcome }) {
  if (!outcome) return null;

  if (!outcome.ok) {
    return (
      <div className="verify blocked" role="alert" style={{ marginTop: 10 }}>
        <div>
          <div className="v-title">Not disconnected</div>
          {/* The service's remedy, verbatim. Never its `error` slug — and never an
              empty box: some refusals on these routes carry a message and no remedy,
              and lib/connections-shape.js falls back to it rather than to nothing. */}
          <div className="v-body">
            {outcome.remedy ||
              "The service refused the disconnect and did not say what would fix it. Tell " +
                "whoever runs Vert: a refusal with no remedy is a defect on the service, " +
                "not something you can act on from here."}
          </div>
        </div>
      </div>
    );
  }

  if (outcome.report) {
    return (
      <div className="verify blocked" role="alert" style={{ marginTop: 10 }}>
        <div>
          <div className="v-title">
            Disconnected here. The credential is still live at the vendor
          </div>
          {/* The service's own instruction. It names the screen to open and the key to
              delete, which is the only part a person can act on. */}
          <div className="v-body">{outcome.report.remedy}</div>
          {/* THREE VALUES, NOT TWO. `null` means revoking at the vendor is not
              something this build can attempt for this provider; `false` means it was
              attempted and failed. Those lead to different words, and the second one
              is not going to resolve itself. */}
          {outcome.report.revokedAtVendor === false && (
            <div className="v-body">
              Revoking it at the vendor was attempted and did not succeed, so this will not
              resolve on its own.
            </div>
          )}
        </div>
      </div>
    );
  }

  // 204. Nothing is left live anywhere and there is nothing to do — which is the only
  // circumstance in which this screen may say so.
  return (
    <div className="note" role="status" style={{ marginTop: 10 }}>
      Disconnected. Nothing is left live: the credential was revoked at the vendor as well
      as here, so there is nothing further to do.
    </div>
  );
}
