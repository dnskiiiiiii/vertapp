// components/settings/BankImportGate.js — THE ONLY BUTTON IN THIS APP THAT WRITES
// TO SOMEBODY'S BANK STATEMENT, AND THE SENTENCE THEY READ BEFORE PRESSING IT
// ==============================================================================
// Two presses, and the split is the safety. The first sends no token: the service
// reads the whole file, applies every refusal, mints every line and WRITES NOTHING,
// then answers with a sentence describing exactly what would happen and a token that
// digests it. The second press sends the token back.
//
// The reason it is a person and not a checksum: a statement read under the wrong sign
// convention is confidently wrong rather than obviously wrong. Every deposit becomes a
// withdrawal, the file still parses, the count is right, the arithmetic balances, and
// every payout tie downstream inherits it while continuing to look healthy. Nothing
// later catches it. The echo below is the only place it can be caught.
//
// WHY THIS IS ITS OWN COMPONENT, taking a `view` prop rather than reading state.
// Until round 19 all of this lived inside BankStatementMapping, driven by
// `useActionState`'s value and a second `useState`. Neither is a prop, so both are
// null under `renderToStaticMarkup`, so the armed half of the gate — the echo panel,
// the commit label, the sentence saying the press writes — could not be rendered by
// any test at all, and dropping the staleness check left the whole suite green.
// It takes a value now, decided by `importGateView` in lib/bank-import.js, which is
// exactly what BankImportOutcome beside it already does with a refusal.
//
// IT DECIDES NOTHING. Every string here comes off the view. A second opinion about
// whether the press writes, formed in a component, is how a commit label ends up
// beside a "nothing has been written yet" sentence.

export default function BankImportGate({ view }) {
  return (
    <>
      {view.armed && (
        <div className="verify" role="status" style={{ marginBottom: 16 }}>
          <div>
            <div className="v-title">{view.title}</div>
            {/* THE SERVICE'S SENTENCE, not summarised: it counts the lines, names the
                account and the currency, says which columns were read for what, states
                the sign convention in its consequences, and gives the first and last
                date as the format read them. Every one of those is a fact this app
                would have to compute to restate — and this app computes nothing. Its
                notation is put in words before it reaches here (lib/bank-import.js
                echoInWords; UI walk D10). */}
            <div className="v-body" style={{ whiteSpace: "pre-wrap" }}>{view.echo}</div>
          </div>
        </div>
      )}

      <button type="submit" className="btn primary wide" disabled={view.disabled}>
        {view.label}
      </button>

      <p className="constraint-line" style={{ marginTop: 8 }}>{view.sentence}</p>
    </>
  );
}
