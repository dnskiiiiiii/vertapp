"use client";

// components/settings/StripeConnectForm.js — PASTE A RESTRICTED KEY, AND KNOW WHOSE
// ==============================================================================
// Stripe needs no approval and no Connect application: the merchant creates a
// restricted key with Read on four resources and pastes it (spec §3.3). That makes
// this the one provider a real customer can wire up end to end today, and this form
// the whole of the onboarding.
//
// THE FOUR PERMISSIONS ARE NAMED, WITH THEIR LEVEL, AND SO IS "EVERYTHING ELSE NONE".
// A merchant who is told "create a restricted key" and left to it will either grant
// too little — and get a 403 whose named permission this app renders, but only after
// a round trip — or grant write scopes to be safe, which hands a reconciliation
// product the ability to move their money. Both are avoided by printing the list.
//
// IT IS A REAL FORM WITH A REAL ACTION. Submit works from the keyboard, works before
// hydration, and posts to a Server Action so the key never sits in a browser bundle's
// request path. `useActionState` carries the refusal back under the field and
// disables the button in flight; it is not what makes the control function.
//
// THE FIELD IS `type="password"`. This is a live credential to a customer's Stripe
// account and setup is exactly the moment somebody is sharing their screen with the
// person walking them through it — the same argument components/auth/SignInForm.js
// makes about the API key, and the same conclusion.

import { useActionState, useState } from "react";

import { STRIPE_PERMISSIONS } from "@/lib/connections-shape";
import { connectStripeAction } from "./actions";
import StripeConnectOutcome from "./StripeConnectOutcome";

// HOW MANY PERMISSIONS, COUNTED FROM THE LIST THAT NAMES THEM (UI-037). The sentence
// said "these four" over a list of five after Account information was added, and a
// person who trusted the count left one off and had the key refused. A count beside a
// list is computed from that list or left out (spec §13.9).
const COUNT_WORDS = ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"];
export function permissionCountWords(list = STRIPE_PERMISSIONS) {
  return COUNT_WORDS[list.length] || String(list.length);
}

/**
 * The warning for a full secret key, before it is sent (Stripe test run 1 Nov 2026, S-8:
 * the guide says an `sk_` key "works, but it will warn you", and nothing did). Reads the
 * prefix only. Pure.
 */
export const FULL_KEY_WARNING = "This is a full secret key. It works, but a restricted key (rk_) is safer.";
export function keyWarning(value) {
  return typeof value === "string" && value.trim().startsWith("sk_") ? FULL_KEY_WARNING : null;
}

export default function StripeConnectForm({ canWrite = true, disabledReason = null }) {
  const [outcome, connect, pending] = useActionState(connectStripeAction, null);
  // A boolean, never the key: whether what is pasted is a full secret key.
  const [fullKey, setFullKey] = useState(false);

  return (
    <form action={connect} aria-labelledby="stripe-connect-title" className="conn-form">
      <h3 id="stripe-connect-title" className="sr-only">Connect Stripe</h3>

      <ol className="conn-steps">
        <li>
          In Stripe, open <b>Developers → API keys</b> and choose <b>Create restricted key</b>.
        </li>
        <li>
          Set exactly these {permissionCountWords()} to <b>Read</b>:
          {/* Named, with their level, from lib/connections-shape.js — the same list
              the 403 is checked against, in one place, so the instruction and the
              refusal cannot drift apart. */}
          <ul className="conn-permissions">
            {STRIPE_PERMISSIONS.map((permission) => (
              <li key={permission.resource}>
                <b>{permission.resource}</b>: {permission.level}
              </li>
            ))}
          </ul>
        </li>
        <li>
          Leave <b>every other permission at None</b>. Vert only ever reads, and nothing here
          needs a key that can move money.
        </li>
        <li>Create the key, copy it once, and paste it below.</li>
      </ol>

      <label htmlFor="restricted_key" className="field-label">
        Stripe restricted key
      </label>
      <input
        id="restricted_key"
        name="restricted_key"
        className="field-input"
        type="password"
        autoComplete="off"
        spellCheck={false}
        required
        placeholder="rk_live_…"
        aria-describedby="stripe-key-help"
        onChange={(e) => setFullKey(Boolean(keyWarning(e.target.value)))}
      />
      {fullKey ? (
        <p className="conn-note" role="note" data-key-warning="">
          {FULL_KEY_WARNING}
        </p>
      ) : null}

      <p id="stripe-key-help" className="conn-note">
        Vert checks it with Stripe before storing it, shows you which account it belongs to,
        and never displays it again.
      </p>

      <button type="submit" className="btn btn-commit btn-wide" disabled={pending || !canWrite}>
        {pending ? "Checking the key with Stripe…" : "Connect Stripe"}
      </button>
      {!canWrite && <p className="conn-note">{disabledReason}</p>}

      <StripeConnectOutcome outcome={outcome} />
    </form>
  );
}
