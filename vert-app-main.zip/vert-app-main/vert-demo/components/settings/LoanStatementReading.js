"use client";

// components/settings/LoanStatementReading.js — WHAT A LENDER'S STATEMENT SAYS, THEN FILE IT
// ==============================================================================
// The engine's reading of a loan statement (lib/loan-statement.js), shown before anything
// is filed: a figure it couldn't read is "Not read" with its words, never $0.00. One press
// files it as the loan's statement, which the GL reconciliation then ties the loan to.

import { useState } from "react";

import { fileLoanStatementAction } from "./actions";
import { formatDay, formatMoney } from "@/lib/format";
import { loanFiledLine, loanReadingView, monthOf } from "@/lib/loan-statement";

/**
 * What the engine read off a lender's statement, and the one press that files it as the
 * loan's. A figure the engine couldn't read is "Not read" with its words, never $0.00.
 */
export default function LoanStatementReading({ reading, documentId = null, canWrite = true }) {
  const view = loanReadingView(reading);
  const [filing, setFiling] = useState({ busy: false, said: null, filed: false });
  if (!view) return null;
  const month = monthOf(view.statementDate) || "the statement's month";
  const file = async () => {
    if (!documentId || !view.accountId) return;
    setFiling({ busy: true, said: null, filed: false });
    let result;
    try {
      result = await fileLoanStatementAction(documentId, view.accountId);
    } catch {
      result = { ok: false, message: "The request didn't reach Vert. Nothing was filed." };
    }
    setFiling({ busy: false, said: loanFiledLine(result, view.accountName), filed: Boolean(result && (result.ok || result.status === 409)) });
  };
  return (
    <section className="loan-reading" aria-label={`${view.accountName}'s statement`} data-loan-reading="">
      <h4 className="pnl-sub">What {view.accountName}&rsquo;s statement says</h4>
      {view.measured ? (
        <dl className="bankrec-fields">
          {view.rows.map((r) => (
            <div key={r.key}>
              <dt>{r.label}</dt>
              <dd className={r.cents != null ? "num" : undefined}>{r.key === "date" ? (r.day ? formatDay(r.day) : r.words) : r.cents != null ? formatMoney(r.cents) : r.words}</dd>
            </div>
          ))}
        </dl>
      ) : null}
      {view.measured && view.creditLine ? <p className="constraint-line">{view.creditLine}</p> : null}
      {view.notRead.map((line) => (
        <p key={line} className="constraint-line">
          {line}
        </p>
      ))}
      {view.measured ? (
        <>
          <p className="constraint-line">
            Vert reconciles the loan in the GL reconciliation: ask &lsquo;reconcile {view.accountName} for {month}&rsquo;. You can also type the closing balance there.
          </p>
          {!filing.filed ? (
            <button type="button" className="btn" disabled={filing.busy || !canWrite || !documentId} onClick={file}>
              {filing.busy ? "Filing…" : `File as ${view.accountName}'s statement`}
            </button>
          ) : null}
          {filing.said ? (
            <p className="constraint-line" role="status">
              {filing.said}
            </p>
          ) : null}
        </>
      ) : (
        <p className="constraint-line">You can type the closing balance in the GL reconciliation instead: ask &lsquo;reconcile {view.accountName}&rsquo;.</p>
      )}
    </section>
  );
}
