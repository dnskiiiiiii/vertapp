"use client";

// ConnectProviderButton.js — the control that starts an OAuth connection.
// ==============================================================================
// The QuickBooks card carried a sentence saying the callback "is not in this build"
// and withheld its button on that basis. The callback shipped; the sentence did not
// change. So the one control between a cleanly decomposed payout and a posted entry
// was withheld by a claim that had stopped being true, and the person whose books
// they are could not switch it on — which is the failure BankAccountPanel's own
// header says this screen exists to prevent.
//
// THE NAVIGATION HAPPENS HERE, NOT IN THE ACTION. A `redirect()` inside a Server
// Action reaches a client component as a thrown control-flow signal, and any caller
// that wrapped it in a try/catch would swallow the navigation and show nothing. The
// action returns a URL; this assigns it. A refusal comes back as a sentence and is
// rendered next to the button, because a disabled control with no reason beside it
// is a control that looks broken.

import { useState, useTransition } from "react";

import { IconInfo } from "@/components/ui/icons";

import { beginAuthorizationAction } from "./actions";

/**
 * WHAT A REFUSED PRESS SAYS, beside the button that was pressed.
 *
 * The tenant's other ledger being connected (the engine's 409 `another_ledger_connected`,
 * read by lib/connections-shape.js `authorizeRefusal`) is a STATE of their books, not a
 * fault, so it is a calm notice: a status, the connected ledger named, the engine's own
 * remedy under it, in the ink and never the problem colour. Anything else that stopped
 * the press is still an alert, in the service's words.
 */
export function ConnectRefusal({ refusal }) {
  if (!refusal) return null;
  if (refusal.kind === "another_ledger") {
    return (
      <div className="conn-held" role="status" data-ledger-held={refusal.connectedProvider || ""}>
        <IconInfo size={16} className="conn-held-icon" />
        <div>
          <p className="conn-held-title">{refusal.title}</p>
          <p className="conn-held-remedy">{refusal.remedy}</p>
        </div>
      </div>
    );
  }
  return (
    <p role="alert" className="muted">
      {refusal.message}
    </p>
  );
}

export default function ConnectProviderButton({ provider, name, canWrite, disabledReason }) {
  const [pending, start] = useTransition();
  const [refusal, setRefusal] = useState(null);

  function go() {
    setRefusal(null);
    start(async () => {
      const answer = await beginAuthorizationAction(provider);
      if (answer.ok) {
        // A full navigation, not a router push: the destination is the vendor's, and
        // Next's client router would try to treat it as an internal route.
        window.location.assign(answer.url);
        return;
      }
      setRefusal(answer);
    });
  }

  return (
    <div>
      {/* `.btn.primary`, not `btn-primary`: app/globals.css defines the first and has
          never defined the second, so this drew as a white secondary. It is the only
          control on /setup step 2, where a filled violet primary is what says which
          thing to press. */}
      <button
        type="button"
        className="btn primary"
        onClick={go}
        disabled={pending || !canWrite}
        aria-busy={pending || undefined}
      >
        {pending ? `Opening ${name}…` : `Connect ${name}`}
      </button>
      {!canWrite && disabledReason && <p className="muted">{disabledReason}</p>}
      <ConnectRefusal refusal={refusal} />
    </div>
  );
}
