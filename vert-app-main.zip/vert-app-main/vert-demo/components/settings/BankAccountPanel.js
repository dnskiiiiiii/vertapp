"use client";

// components/settings/BankAccountPanel.js — THE ONE CHOICE THAT WAS ONLY MAKEABLE
// FROM A TERMINAL
// ==============================================================================
// The bank tie refuses until somebody names which account to read, and it is right to:
// "a company with a Checking and a Savings has two plausible answers, and picking wrong
// yields a register in which no payout appears" — a silent, total failure of the tie.
// Until this panel existed the only way to answer was a `python -m` entry point, which
// meant the one thing standing between a cleanly decomposed payout and a posted entry
// could not be switched on by the person whose books they are.
//
// IT WAS CALLED ConnectionsPanel AND IT DREW A SECOND "Connections" SECTION.
// ------------------------------------------------------------------
// Under a page already titled Connections, on which ConnectionsScreen had already
// listed every provider and named the account each one resolved to, this file opened
// with its own `<h2>Connections</h2>` and a "General ledger" row restating the
// QuickBooks card from a second source (`GET /approvals/ledger` rather than
// `GET /connections`). Two headings with one word between them and two answers to one
// question — spec §7 lists it as the duplicate section, and it is the reason a real
// customer scrolled 1800px looking for the thing they had already passed.
//
// The heading and the restatement are gone. What is left is the choice nothing else on
// the page makes, under the block that owns it: Account mapping. Which of THEIR
// accounts is which — the chart mapping above it, the bank account here.
//
// A REFUSAL IS RENDERED, NOT HIDDEN. "No QuickBooks connection yet" is the state most
// tenants are in, and the worker answers it 200 with a sentence. A screen that showed
// an empty list there would be telling a bookkeeper their company has no bank
// accounts, which is a different and false claim.
//
// A TRANSPORT FAILURE IS NOT THAT SENTENCE, AND NO LONGER RENDERS AS ONE. Both used to
// arrive here as `{ok: false, message}` and both were printed as plain text, so the
// worker's raw "answered HTTP 500 with no error envelope" sat on a customer's screen in
// the slot reserved for advice. `kind` now distinguishes them at the action, and the
// unreachable case goes to ServiceUnavailable — a stated outcome and a retry.
//
// That paragraph was written before it was true, and said so for a month. The transport
// answered "refused" for EVERY non-2xx — the exact 500 it names included — so the branch
// below never matched the case it was built for, and the write path had no branch at
// all. Both are closed now: worker-transport.js decides the kind by whether the worker
// spoke, and the save renders the same stated outcome the read does.

import { useCallback, useEffect, useState, useTransition } from "react";

import ServiceUnavailable from "@/components/shell/ServiceUnavailable";
import { chooseBankAccountAction } from "@/components/sync/actions";
// The list is a GET (app/api/sync?accounts), not the listBankAccountsAction Server Action:
// opening the sheet is a look, and a look sends no POST (tests/p0-quiet-page-load.test.js).
// Saving the choice stays a Server Action, from its press.
import { readBankAccounts } from "@/components/sync/sync-read";

export default function BankAccountPanel() {
  const [state, setState] = useState({ loading: true, ok: false, kind: null, message: null, accounts: [], chosen: null });
  const [picked, setPicked] = useState("");
  const [saved, setSaved] = useState(null);
  const [pending, start] = useTransition();

  // One read, called on mount and by the retry, so the two cannot drift.
  const load = useCallback(() => {
    let live = true;
    setState((current) => ({ ...current, loading: true }));
    readBankAccounts().then((answer) => {
      if (!live) return;
      setState({ loading: false, ...answer });
      setPicked(answer.chosen || "");
    });
    return () => {
      live = false;
    };
  }, []);

  useEffect(() => load(), [load]);

  function save() {
    start(async () => {
      const answer = await chooseBankAccountAction(picked);
      setSaved(answer);
      if (answer.ok) setState((s) => ({ ...s, chosen: answer.accountId }));
    });
  }

  // "Nothing answered" against "the worker answered, with this". Only the first is an
  // outage, and only the first is worth a retry button.
  //
  // THE TEST IS `kind`, AND IT ONLY STARTED BEING TRUE ON 2026-08-18. This predicate was
  // written against a transport that answered "refused" for every non-2xx, so a 500 with
  // no error envelope — the case this whole file's header is about — fell through to the
  // plain `.tieline` below and printed the transport's own diagnostic as advice.
  // components/sync/worker-transport.js now decides the kind by whether the worker spoke
  // at all, so the two branches here finally split where the header says they do.
  const transportFailed = (kind) => kind === "unreachable" || kind === "unavailable";
  const unreachable = !state.loading && !state.ok && transportFailed(state.kind);
  // THE SAVE PATH HAD NO SUCH CHECK AT ALL. `chooseBankAccountAction` carries the same
  // `kind` for the same reason the read does, and it was rendered straight into the
  // tieline — so every transport failure on the one WRITE this panel makes landed on
  // screen as a sentence about the customer's books. Same split, same component.
  const saveFailed = saved && !saved.ok && transportFailed(saved.kind);

  return (
    <div>
      <h3 id="bank-account-title" className="pnl-sub">Bank account for the tie</h3>
      <p className="constraint-line" style={{ marginTop: 0 }}>
        Which account in your ledger Vert reads to confirm a payout actually landed.
        {/* THE IDENTIFIER IS NOT THE SENTENCE. This read "every settlement stays
            blocked on `bank_unmatched`", which is the engine's exception code printed
            at somebody who has never seen the engine. The code is not deleted — it is
            on the exception itself and in the audit trail, where it is the right word —
            but here the fact is said in the words a bookkeeper would use. */}
        {" "}Until one is chosen, every payout stays blocked as a deposit nobody has
        seen: the arithmetic ties, and no account has been read to confirm the money
        arrived.
      </p>

      {state.loading && <p className="muted">Reading your connected company…</p>}

      {unreachable && (
        // WHICH LIST, AND FROM WHICH SERVICE. This said "The accounts in your ledger
        // could not be listed" and "the service that reads your ledger did not
        // answer" — printed directly under a chart mapping that had just rendered
        // every account in that same ledger, read from `GET /ledger/map` on the API.
        // Two panels, one ledger, opposite claims. This panel is served by the sync
        // worker's `/bank-accounts`, which is a different service and the only one
        // failing, so it is the only one named. Same correction as the step 4 card on
        // /setup, which is the other place this outcome surfaces.
        <ServiceUnavailable
          title="The bank accounts could not be listed"
          body={
            "Nothing has changed and no account has been chosen: the sync service that " +
            "lists them did not answer. Your chart of accounts is not affected; it is " +
            "read from the ledger itself and is what the mapping above is answered " +
            "against. This is a problem with the connection to one service, not with " +
            "your books."
          }
          // THE WAY THROUGH, NOT JUST THE APOLOGY. Added 2026-08-20 after driving this
          // as a bookkeeper: with the listing failing, Retry was the only control on
          // the screen, it failed identically three times running, and every payout
          // stayed blocked on a step that could not be completed. The bank statement
          // import answers the same question — which account confirms the deposit —
          // from a file instead of from the ledger, it is on this very page, and
          // nothing pointed at it. It is described lower down as the fallback "when a
          // bank feed is not available"; a listing that will not answer IS that case,
          // so this is where it has to be offered.
          alternative={
            <>
              While this is down, a bank statement answers the same question from a
              file:{" "}
              <a href="#bank-import-title">import a statement</a> and Vert reads the
              deposits out of it. Nothing on this panel has to be chosen first.
            </>
          }
          onRetry={load}
          retrying={state.loading}
        />
      )}

      {!state.loading && !state.ok && !unreachable && (
        // The worker's own sentence. It names what is missing and what to set, and it
        // is the only text here that describes the actual deployment.
        <p className="tieline">{state.message || "No bank accounts could be listed."}</p>
      )}

      {!state.loading && state.ok && (
        <>
          <div className="row" style={{ gap: 8, alignItems: "center" }}>
            <select
              name="bank-account"
              autoComplete="off"
              className="inp"
              value={picked}
              onChange={(e) => setPicked(e.target.value)}
              aria-label="Bank account"
            >
              <option value="">Choose an account…</option>
              {state.accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}{a.currency ? ` (${a.currency})` : ""}
                </option>
              ))}
            </select>
            <button type="button" className="btn primary" disabled={!picked || pending} onClick={save}>
              {pending ? "Saving…" : "Use this account"}
            </button>
          </div>

          {/* THE CURRENCY WARNING, BEFORE THE FETCH RATHER THAN AFTER IT. A register
              denominated differently from the payouts is refused at read time and
              writes nothing; finding that out here is the difference between a warning
              and a wasted close. */}
          {picked && (() => {
            const account = state.accounts.find((a) => a.id === picked);
            return account?.currency ? (
              <p className="muted" style={{ marginTop: 8 }}>
                Deposits in this account are in {account.currency}. A payout settling in
                any other currency will not tie against it, and no lines will be
                imported for it.
              </p>
            ) : null;
          })()}

          {saveFailed && (
            <ServiceUnavailable
              title="Your choice of bank account could not be saved"
              body={
                "Nothing has changed. The account Vert reads is the one it was before, " +
                "and the service that records the choice did not answer. This is a " +
                "problem with the connection to it, not with your books."
              }
              onRetry={save}
              retrying={pending}
            />
          )}

          {saved && !saveFailed && (
            <p className={saved.ok ? "tieline" : "tieline var-bad"} style={{ marginTop: 12 }}>
              {saved.ok
                ? `Vert will read ${saved.accountName} for this tenant's bank deposits. ` +
                  `Run a sync to pull the register.`
                : saved.message}
            </p>
          )}
        </>
      )}
    </div>
  );
}
