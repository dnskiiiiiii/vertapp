"use client";

// components/settings/PostModeSetting.js — WHAT HAPPENS TO AN ENTRY ONCE IT IS APPROVED
// ==============================================================================
// The founder's decision, 17 Oct 2026: for a ledger that has a draft step (Xero), each
// client chooses whether an approved journal is POSTED — the default, in the reports at
// once, corrected by a reversing entry Vert drafts — or SENT AS A DRAFT that somebody in
// the ledger approves. The setting lives in the connected ledger's own sheet on
// Connections (components/setup/ConnectionsList.js), because it is a fact about that
// connection and the engine stores it on the connection row (`postMode`).
//
// THE WORDS ARE THE CATALOGUE'S (lib/connections-shape.js `postModeChoices`), named by
// the row, so this file spells no vendor and decides nothing about which one has a
// draft step: the list draws this only for a row whose catalogue entry says `postModes`.
//
// THE SELECTED CHOICE IS THE ENGINE'S ANSWER, NEVER A DEFAULT. `row.postMode` is null
// when the row did not say, and then neither choice is selected and the sheet says so:
// "your entries are posted straight away" is a claim about somebody's books, and an
// unread setting is not a measured one.
//
// A REAL FORM WITH A SERVER ACTION, like the disconnect beside it (ProviderCard.js): it
// works with the keyboard and before hydration, and `useActionState` carries the outcome
// back — the saved state in the engine's own answer, or a refusal in the engine's own
// words (409 `not_connected`, 422 `invalid_post_mode` / `post_mode_unsupported`), read by
// `postModeRefusal`. Never a generic error, never the slug.
//
// SAVE IS SECONDARY. The accent means "this writes to the books" (components/ui/
// Button.js), and a setting is not a posting; Connections has no filled button at all
// (tests/connections.test.js).

import { useActionState, useId, useState } from "react";

import { Button } from "@/components/ui";
import { postModeChoices, postModeSaved } from "@/lib/connections-shape";
import { setPostModeAction } from "./actions";

export default function PostModeSetting({ row, canWrite = true, disabledReason = null, initial = null }) {
  const [outcome, save, pending] = useActionState(setPostModeAction, initial);
  const savedMode = outcome && outcome.ok === true && outcome.mode ? outcome.mode : row.postMode;
  const [chosen, setChosen] = useState(savedMode);
  const legendId = useId();
  const choices = postModeChoices(row);
  // The saved line describes what is set; once the person picks the other choice it no
  // longer does, so it steps aside until the next save answers.
  const savedStands = outcome && outcome.ok === true && (outcome.mode === null || outcome.mode === chosen);

  return (
    <form action={save} className="conn-mode" data-post-mode-setting="">
      <input type="hidden" name="provider" value={row.id} />
      <fieldset className="conn-mode-set" aria-labelledby={legendId}>
        <legend id={legendId} className="conn-mode-legend">
          When you approve an entry
        </legend>
        {choices.map((choice) => {
          const id = `${legendId}-${choice.value}`;
          return (
            <label key={choice.value} className="conn-mode-choice" htmlFor={id} data-chosen={chosen === choice.value ? "" : undefined}>
              <input
                type="radio"
                id={id}
                name="mode"
                value={choice.value}
                checked={chosen === choice.value}
                onChange={() => setChosen(choice.value)}
                aria-describedby={`${id}-help`}
              />
              <span className="conn-mode-text">
                <span className="conn-mode-label">{choice.label}</span>
                <span className="conn-mode-help" id={`${id}-help`}>
                  {choice.help}
                </span>
              </span>
            </label>
          );
        })}
      </fieldset>
      {row.postMode === null && !(outcome && outcome.ok) ? (
        <p className="conn-note">Vert couldn&rsquo;t read which one is set for this client.</p>
      ) : null}
      <div className="conn-sheet-actions">
        <Button type="submit" variant="secondary" size="sm" busy={pending} busyLabel="Saving…" disabledReason={canWrite ? null : disabledReason || "Nothing can be changed here."}>
          Save
        </Button>
      </div>
      {savedStands ? (
        <p role="status" className="conn-note conn-mode-outcome" data-post-mode-saved={outcome.mode || ""}>
          {postModeSaved(outcome.mode, row.name)}
        </p>
      ) : null}
      {outcome && outcome.ok === false ? (
        <p role="alert" className="conn-note conn-mode-outcome" data-post-mode-refused={outcome.code || ""}>
          {outcome.remedy}
        </p>
      ) : null}
    </form>
  );
}
