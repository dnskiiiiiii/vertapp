"use client";

// components/cash-coding/CashCodingScreen.js — XERO'S CASH CODING, IN VERT
// ==============================================================================
// The co-founder asked Vert to "cash code" and got a full bank reconciliation report
// (3 Nov 2026). Cash coding is a bulk grid: one bank account's uncoded lines, each with
// an account and a tax rate, ticked and saved together. This is that grid, for one
// account and month (w25 contract v1), drawn the way Xero's reads:
//
//   Reconcile | Cash coding                       the bank rec beside it, as Xero's tabs
//   Select all · Select high confidence · Clear   then the count, the total, Code N lines
//   ☐ Date Payee Reference Description Account Tax rate Spent Received
//
// Every rule (what starts ticked, which rates an account may take, the body sent, how
// a result lands on its row) is lib/cash-coding-model.js, held by
// tests/cash-coding-model.test.js. This file only draws it and wires the presses.
//
// SKIP IS NOT DRAWN: the engine's POST /cash-coding/skip isn't built yet (contract v2
// change log), and a button that can only fail is not offered.
// A ROW VERT FILLED carries a quiet confidence mark; its basis shows on hover or focus.
// A ROW WITH NO PROPOSAL shows an empty Account asking to be filled and is never ticked.
// PAYEE IS A FIELD, as in Xero's grid (engine w27/cc-proposals): the engine's payee, or
// empty under a "Payee" placeholder when it knows none (it never invents one). Typing
// suggests the payees the grid already names; a new one is created by Xero. A row with
// no payee or no account can't be ticked, and says why beside its box ("Add payee").
// THE ENGINE'S ALTERNATIVES: on a row with no account or a low-confidence one, up to
// three "Suggested" chips under the account; a press sets the account and its rate.
// A RATE THE ENGINE ASKS (AU interest with Input Taxed archived): the tax cell is empty,
// "Choose rate", the engine's basis is on a line under the row, and the box waits.
// AFTER "CODE N LINES" each row says what the engine did: a coded row says what Xero
// now holds and leaves the selection; a refused row stays, its reason under it; then
// the engine's summary and, when it names one, the link to Xero's Reconcile tab, where
// the person clicks OK (Xero lets no app reconcile).
//
// A LINE WAITING FOR APPROVAL (staging check CC-1) says who prepared it, its account and
// its rate. Its approver ticks it, and the press reads "Approve N lines"; its preparer
// reads "Waiting for approval", with nothing to press. Who may approve is the model's
// mayApproveWaiting, over the signed-in actor and duties the app's store holds.
//
// AT 390 PX the table stacks into one card per row with the same fields
// (app/styles/cash-coding.css); no page scrolls sideways.

import Link from "next/link";
import { createContext, useContext, useId, useReducer, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button, Disclosure } from "@/components/ui";
import { SetVisibleMonth } from "@/components/shell/MonthControl";
import { IconCaretLeft, IconExternal } from "@/components/ui/icons";
import { actorWords, formatDay, formatMoney } from "@/lib/format";
import { useDuties, useSignedInActor } from "@/lib/store";
import { periodLabel } from "@/lib/period";
import { codeLines, linkStatement } from "@/lib/cash-coding-client";
import {
  accountMatches,
  cashCodingHref,
  reconcileHref,
  CODED_WORDS,
  accountText,
  codeBody,
  freshGrid,
  codeLabel,
  gridKey,
  gridOf,
  highConfidenceCount,
  initialState,
  ledgerLinkOf,
  makeReducer,
  payeeSuggestions,
  preparerWords,
  selectionOf,
  selectionWords,
  stateFor,
  suggestionsFor,
  taxChoices,
  visibleRows,
} from "@/lib/cash-coding-model";

const CONFIDENCE_WORDS = { high: "High", medium: "Medium", low: "Low" };

/**
 * HOW THE GRID IS READ AGAIN. On this page, the page itself is read again
 * (router.refresh). In the chat's answer (components/chat/answer/CashCodingPanel.js) the
 * grid is the browser's own read, so the panel provides its own re-read here. Either
 * way it returns a promise, so Retry stays busy until the read is back.
 */
const RefreshContext = createContext(null);
export const CashCodingRefresh = RefreshContext.Provider;

function useRefresh() {
  const router = useRouter();
  const own = useContext(RefreshContext);
  return own || (async () => router.refresh());
}

/**
 * `initial`: lib/cash-coding.js readCashCoding's answer. `state` and `outcome` start the
 * grid somewhere other than Vert's proposals (tests draw a row after an edit or a code).
 * `viewer` (`{ actor, duties }`) is the signed-in person, from the store unless given.
 */
export default function CashCodingScreen({ initial, period = null, state = null, outcome = null, viewer: given = null }) {
  const actor = useSignedInActor();
  const duties = useDuties();
  const viewer = given || { actor, duties };
  // THE LAST PRESS'S ANSWER, FOR THIS READ (staging check CC-6): its list read after the
  // press stands until the page's own fresh read arrives, which replaces `initial`.
  const [answered, setAnswered] = useState(() => (outcome ? { for: initial, answer: outcome } : null));
  if (!initial || !initial.ok) {
    return (
      <Frame period={period}>
        <p className="cc-words" role="status" data-cc-unread="">
          {(initial && initial.message) || "Vert couldn't read the lines to code just now."}
        </p>
        <Retry />
      </Frame>
    );
  }
  const read = gridOf(initial.body);
  const grid = answered && answered.for === initial ? freshGrid(read, answered.answer) : read;
  if (!grid) {
    return (
      <Frame period={period}>
        <p className="cc-words" role="status" data-cc-unread="">
          Vert&rsquo;s lines to code couldn&rsquo;t be read as they were sent, so they aren&rsquo;t drawn here.
        </p>
      </Frame>
    );
  }
  const month = grid.period || period;
  return (
    <Frame period={month} grid={grid}>
      <Switcher grid={grid} period={month} />
      {grid.account && grid.lines.length ? (
        // A new account or month is a new grid: its own state, from its own proposals.
        <Grid key={gridKey(grid)} grid={grid} viewer={viewer} initialState={state} initialOutcome={outcome} onCoded={(answer) => setAnswered({ for: initial, answer })} />
      ) : (
        <Empty grid={grid} period={month} />
      )}
    </Frame>
  );
}

function Frame({ period, grid = null, children }) {
  const title = grid && grid.account ? grid.account.label : "Cash coding";
  const month = (grid && grid.periodLabel) || (period ? periodLabel(period) : null);
  return (
    <div className="page cc-page" data-cash-coding="">
      {/* The page's month is the app's month (staging check CC-13), as a conversation's is. */}
      {period ? <SetVisibleMonth period={period} /> : null}
      <Link className="link cc-back t-footnote" href={period ? `/?period=${period}` : "/"}>
        <IconCaretLeft aria-hidden="true" />
        <span>Month-end</span>
      </Link>
      <header className="page-head cc-head">
        <div>
          <h1 className="t-title-1" translate="no">{title}</h1>
          {month ? <p className="page-head-sub">{month}</p> : null}
        </div>
      </header>
      <nav className="tabs-ink cc-tabs" aria-label="Bank views">
        <Link className="tab-ink" href={reconcileHref(period)}>
          Reconcile
        </Link>
        <span className="tab-ink" aria-current="page">
          Cash coding
        </span>
      </nav>
      {children}
    </div>
  );
}

/**
 * The account switcher: every imported statement account, with its count (contract
 * `accounts`), whenever there is more than one, or none is chosen yet. An account with
 * nothing left to code stays in it (staging check CC-3): it was the only way back.
 */
function Switcher({ grid, period }) {
  const listed = grid.accounts;
  if (listed.length < 2 && grid.account) return null;
  if (!listed.length) return null;
  return (
    <nav className="cc-accounts" aria-label="Bank account">
      <ul>
        {listed.map((a) => {
          const current = Boolean(grid.account && grid.account.id === a.id);
          return (
            <li key={a.id}>
              <Link className="cc-account" href={cashCodingHref(a.id, period)} aria-current={current ? "page" : undefined} translate="no">
                <span>{a.label}</span>
                {Number.isInteger(a.toCode) ? <span className="cc-account-count num">{a.toCode}</span> : null}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}

/**
 * A READ THAT FAILED OFFERS ANOTHER (staging check CC-4): one load said "Vert couldn't
 * read the lines to code just now" and the next worked, but only a reload got there.
 * Retry reads the page again, here, with the same address.
 */
export function Retry() {
  const refresh = useRefresh();
  const [pending, start] = useTransition();
  return (
    <p className="cc-retry">
      <Button variant="secondary" size="sm" busy={pending} busyLabel="Reading…" onClick={() => start(() => refresh())}>
        Retry
      </Button>
    </p>
  );
}

/** What couldn't be read this time (contract w26 `unread`), each in the engine's words. */
function Unread({ grid }) {
  if (!grid.unread.length) return null;
  return (
    <ul className="cc-unread t-footnote" data-cc-unread="">
      {grid.unread.map((w) => (
        <li key={w}>{w}</li>
      ))}
    </ul>
  );
}

/** No lines (or no account picked): the engine's words, and its next step when it names one. */
export function Empty({ grid, period }) {
  return (
    <div className="cc-empty" data-cc-empty={grid.why || ""}>
      {grid.words ? <p className="cc-words" role="status">{grid.words}</p> : null}
      <Unread grid={grid} />
      {grid.link ? <LinkQuestion grid={grid} period={period} /> : null}
      {grid.why === "unread" ? <Retry /> : null}
      {grid.nextStep ? (
        <p>
          <Button variant="secondary" href={grid.nextStep.href}>
            {grid.nextStep.label}
          </Button>
        </p>
      ) : null}
    </div>
  );
}

/**
 * An unlinked statement's question, asked here (founder, 7 Nov 2026): which Xero bank
 * account it is. One press links it and the page re-reads with the account's lines —
 * no second screen, the way Xero asks it on the reconcile tab itself.
 */
function LinkQuestion({ grid, period }) {
  const refresh = useRefresh();
  const [busy, setBusy] = useState(null);
  const [failed, setFailed] = useState(null);
  const choices = Array.isArray(grid.link.choices) ? grid.link.choices : [];

  async function pick(id) {
    if (busy) return;
    setBusy(id);
    setFailed(null);
    const answer = await linkStatement({ period: period || grid.period, account: grid.account.id, glAccount: id });
    if (answer.ok) {
      await refresh();
      return;
    }
    setBusy(null);
    setFailed(answer.message || "That couldn't be linked just now. Try again.");
  }

  return (
    <div className="cc-link" data-cc-link="">
      <p className="cc-link-q" id="cc-link-q">
        {grid.link.question}
      </p>
      <ul className="cc-link-choices" aria-labelledby="cc-link-q">
        {choices.map((c) => (
          <li key={c.id}>
            <Button variant="secondary" size="sm" busy={busy === c.id} busyLabel="Linking…" disabled={Boolean(busy) && busy !== c.id} onClick={() => pick(c.id)} translate="no">
              {c.label}
            </Button>
          </li>
        ))}
      </ul>
      {failed ? (
        <p className="cc-link-failed" role="alert">
          {failed}
        </p>
      ) : null}
    </div>
  );
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE GRID
 * ══════════════════════════════════════════════════════════════════════════ */

export function Grid({ grid, viewer, initialState: given, initialOutcome, onCoded }) {
  const refresh = useRefresh();
  const [kept, dispatch] = useReducer(makeReducer(grid), given, (s) => s || initialState(grid, viewer));
  // A fresh read of this grid keeps what the person did and adds any new line.
  const state = stateFor(grid, kept);
  const [busy, setBusy] = useState(false);
  const [outcome, setOutcome] = useState(initialOutcome);
  const selection = selectionOf(grid, state);
  const rows = visibleRows(grid, state);
  const codable = grid.account.codable && grid.pickerRead;
  const payeesId = useId();
  const payees = payeeSuggestions(grid);

  async function code() {
    if (busy) return;
    const body = codeBody(grid, state);
    if (!body) return;
    setBusy(true);
    const answer = await codeLines(body);
    setBusy(false);
    setOutcome(answer);
    if (answer.ok) {
      dispatch({ type: "coded", answer });
      onCoded(answer);
      // The headline, the counts and the switcher, read again (CC-6). The person's rows
      // and this answer stay: the same account's fresh read keeps them (stateFor).
      refresh();
    }
  }

  // Reference only when some line has one (CC-7): an always-empty column is noise.
  const refs = grid.lines.some((l) => l.reference);
  const why = !codable ? grid.account.why || "Nothing can be coded to this account just now." : !selection.count ? "Tick the lines to code." : null;
  const link = outcome && outcome.ok ? ledgerLinkOf(outcome) : null;

  return (
    <section className="cc-work" aria-label="Lines to code">
      {grid.words ? <p className="cc-words">{grid.words}</p> : null}
      <Unread grid={grid} />
      {grid.leftOut ? <p className="cc-words cc-left-out">{grid.leftOut}</p> : null}
      <div className="cc-toolbar" role="toolbar" aria-label="Selection">
        <div className="cc-select">
          <Button variant="quiet" size="sm" onClick={() => dispatch({ type: "selectAll" })}>
            Select all
          </Button>
          {/* Offered only when some line is high confidence (founder, 8 Nov 2026: a greyed
              button and its "None high confidence" note were two things saying nothing). */}
          {highConfidenceCount(grid, state) ? (
            <Button variant="quiet" size="sm" onClick={() => dispatch({ type: "selectHigh" })}>
              Select high confidence
            </Button>
          ) : null}
          <Button variant="quiet" size="sm" onClick={() => dispatch({ type: "clear" })}>
            Clear
          </Button>
          {selection.changed ? (
            <Button variant="quiet" size="sm" onClick={() => dispatch({ type: "discard" })}>
              Discard changes
            </Button>
          ) : null}
        </div>
        <div className="cc-commit">
          {/* Said to a screen reader as it changes; on screen, "Code N lines" says it. */}
          <p className="cc-count sr-only" aria-live="polite">{selectionWords(selection)}</p>
          <SelectionTotal selection={selection} />
          <Button variant="commit" onClick={code} busy={busy} busyLabel="Coding…" disabledReason={busy ? null : why}>
            {codeLabel(selection.count, selection.approvals)}
          </Button>
        </div>
      </div>

      {outcome ? <Outcome outcome={outcome} link={link} /> : null}

      <table className="cc-grid">
        <caption className="sr-only">
          Lines to code, {grid.account.label}, {grid.periodLabel || periodLabel(grid.period)}
        </caption>
        <thead>
          <tr>
            <th scope="col" className="cc-col-check">
              <span className="sr-only">Selected</span>
            </th>
            <th scope="col" className="cc-h-date">Date</th>
            <th scope="col" className="cc-h-payee">Payee</th>
            {refs ? <th scope="col" className="cc-h-ref">Reference</th> : null}
            <th scope="col" className="cc-h-desc">Description</th>
            <th scope="col" className="cc-col-account">Account</th>
            <th scope="col" className="cc-col-tax">Tax rate</th>
            <th scope="col" className="num-col cc-h-spent">Spent</th>
            <th scope="col" className="num-col cc-h-recv">Received</th>
            <th scope="col" className="cc-col-actions">
              <span className="sr-only">Row actions</span>
            </th>
          </tr>
        </thead>
        {rows.map((r) => (
          <Row key={r.line.id} grid={grid} row={r} viewer={viewer} refs={refs} payees={payees.length ? payeesId : null} dispatch={dispatch} />
        ))}
      </table>
      {/* The payees the grid names, suggested as one is typed (the GET sends no contact list). */}
      {payees.length ? (
        <datalist id={payeesId}>
          {payees.map((p) => (
            <option key={p} value={p} />
          ))}
        </datalist>
      ) : null}
    </section>
  );
}

function SelectionTotal({ selection }) {
  const parts = [];
  if (selection.spentCents) parts.push(`${formatMoney(selection.spentCents)} spent`);
  if (selection.receivedCents) parts.push(`${formatMoney(selection.receivedCents)} received`);
  if (!parts.length) return null;
  return (
    <p className="cc-total t-footnote num" translate="no">
      {parts.join(", ")}
    </p>
  );
}

function Outcome({ outcome, link }) {
  if (!outcome.ok) {
    return (
      <p className="cc-outcome cc-outcome-problem" role="alert">
        {outcome.message}
      </p>
    );
  }
  return (
    <div className="cc-outcome" role="status">
      {outcome.words ? <p>{outcome.words}</p> : null}
      {outcome.partial ? <p className="cc-outcome-problem">{outcome.partial.message}</p> : null}
      {link ? (
        <p>
          <a className="link" href={link} target="_blank" rel="noreferrer">
            Open Xero&rsquo;s Reconcile tab
            <IconExternal aria-hidden="true" />
          </a>
        </p>
      ) : null}
    </div>
  );
}

/* ── one row ─────────────────────────────────────────────────────────────────── */

function Row({ grid, row, viewer, refs, payees, dispatch }) {
  const { line, value, result, waiting } = row;
  const id = useId();
  const who = value.payee.trim() || line.payee || line.description || "this line";
  const done = row.done;
  // Coded, or waiting: the coding as it was saved, not edited here.
  const fixed = done || Boolean(waiting);
  const refused = Boolean(result && result.status === "refused");
  const proposal = line.proposal;
  // The rate the engine asks: its basis is the question, said on the row, not in a tooltip.
  // Asked only until a rate is chosen (demo rehearsal D10: it stayed once answered).
  const ask = !fixed && line.askRate && !value.taxType && proposal && proposal.basis ? proposal.basis : null;
  const showConfidence = Boolean(proposal && proposal.confidence && !row.changed && !done && line.status === "to_code" && !ask);
  const taxes = taxChoices(grid, value.accountCode);
  const taxName = (taxes.find((t) => t.value === value.taxType) || {}).label || (proposal && proposal.taxType === value.taxType ? proposal.taxName : null) || value.taxType;
  const needsAccount = !value.accountCode && !fixed;
  const suggested = fixed ? [] : suggestionsFor(grid, line);
  const spent = line.spentCents !== null ? formatMoney(line.spentCents) : "";
  const received = line.receivedCents !== null ? formatMoney(line.receivedCents) : "";
  return (
    <tbody className="cc-row-group" data-line={line.id} data-changed={row.changed ? "true" : "false"} data-refused={refused ? "true" : undefined} data-done={done ? "true" : undefined}>
      <tr className={["cc-row", row.selected ? "cc-row-selected" : null].filter(Boolean).join(" ")}>
        <td className="cc-col-check" data-label="Select">
          {done ? null : (
            <label className="cbx-hit">
              <input
                type="checkbox"
                className="cbx"
                aria-label={`Select ${who}, ${spent || received}`}
                aria-describedby={row.why ? `${id}-why` : undefined}
                checked={row.selected}
                disabled={!row.tickable}
                onChange={() => dispatch({ type: "toggle", id: line.id })}
              />
            </label>
          )}
        </td>
        <td data-label="Date" className="cc-date num">{line.date ? formatDay(line.date) : ""}</td>
        {fixed ? (
          <td data-label="Payee" className="cc-payee" translate="no">{value.payee || ""}</td>
        ) : (
          <td data-label="Payee" className="cc-payee">
            <input
              type="text"
              className="field-input cc-payee-input"
              name={`payee-${line.id}`}
              aria-label={`Payee for ${line.description || "this line"}`}
              autoComplete="off"
              translate="no"
              placeholder="Payee"
              list={payees || undefined}
              maxLength={255}
              value={value.payee}
              onChange={(e) => dispatch({ type: "payee", id: line.id, value: e.target.value })}
            />
          </td>
        )}
        {refs ? <td data-label="Reference" className="cc-ref">{line.reference || ""}</td> : null}
        <td data-label="Description" className="cc-desc">{line.description || ""}</td>
        <td data-label="Account" className="cc-col-account" data-needs-account={needsAccount ? "true" : undefined}>
          {fixed ? (
            <span translate="no">{accountText(grid, line, value.accountCode)}</span>
          ) : (
            <div className="cc-account-cell">
              <AccountPicker grid={grid} line={line} value={value.accountCode} label={`Account for ${who}`} onPick={(code) => dispatch({ type: "account", id: line.id, code })} />
              {showConfidence ? <Confidence id={`${id}-basis`} confidence={proposal.confidence} basis={proposal.basis} /> : null}
              {row.changed ? <span className="cc-changed t-caption">Changed</span> : null}
              {suggested.length ? (
                <div className="cc-suggest" role="group" aria-label={`Suggested accounts for ${line.description || who}`}>
                  <span className="cc-suggest-head t-caption">Suggested</span>
                  {suggested.map((x) => (
                    <button
                      key={x.index}
                      type="button"
                      className="cc-chip t-footnote"
                      title={x.basis || undefined}
                      aria-pressed={value.accountCode === x.code ? "true" : "false"}
                      data-cc-alternative={x.index}
                      translate="no"
                      onClick={() => dispatch({ type: "alternative", id: line.id, index: x.index })}
                    >
                      {x.label}
                    </button>
                  ))}
                </div>
              ) : null}
            </div>
          )}
        </td>
        <td data-label="Tax rate" className="cc-col-tax" data-needs-rate={line.askRate && !fixed && value.accountCode && !value.taxType ? "true" : undefined}>
          {fixed ? (
            <span>{taxName || ""}</span>
          ) : (
            <select
              className="field-input cc-tax"
              name={`tax-${line.id}`}
              autoComplete="off"
              aria-label={`Tax rate for ${who}`}
              value={value.taxType || ""}
              disabled={!value.accountCode}
              onChange={(e) => dispatch({ type: "tax", id: line.id, taxType: e.target.value })}
            >
              {!value.accountCode ? <option value="">No rate yet</option> : null}
              {value.accountCode && !value.taxType ? <option value="">{line.askRate ? "Choose rate" : "Account default"}</option> : null}
              {taxes.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          )}
        </td>
        <td data-label="Spent" className="num-col num" translate="no">{spent}</td>
        <td data-label="Received" className="num-col num" translate="no">{received}</td>
        <td data-label="Actions" className="cc-col-actions">
          {fixed ? null : (
            <div className="cc-actions">
              {/* Why the row's box can't be ticked yet, in a few words (its description). */}
              {row.why ? (
                <span className="cc-why t-caption" id={`${id}-why`}>
                  {row.why}
                </span>
              ) : null}
              <span className="cc-remember t-footnote">
                <label className="cbx-hit">
                  <input type="checkbox" className="cbx" name={`remember-${line.id}`} aria-label={`Remember ${who}'s coding as a rule`} checked={value.remember} onChange={() => dispatch({ type: "remember", id: line.id })} />
                  <span>Remember</span>
                </label>
              </span>
            </div>
          )}
        </td>
      </tr>
      {ask ? (
        <tr className="cc-result-row cc-ask-row">
          <td colSpan={refs ? 10 : 9}>
            <p className="cc-row-ask t-footnote" data-cc-ask="">
              {ask}
            </p>
          </td>
        </tr>
      ) : null}
      {result || waiting ? (
        <tr className="cc-result-row">
          <td colSpan={refs ? 10 : 9}>
            {result ? <RowResult result={result} viewer={viewer} /> : <Waiting by={waiting.by} viewer={viewer} approve />}
          </td>
        </tr>
      ) : null}
    </tbody>
  );
}

/** "Waiting for approval · Prepared by …": a tick beside it when this viewer approves it. */
function Waiting({ by, viewer, approve = false }) {
  const name = preparerWords(by, viewer, actorWords);
  return (
    <p className="cc-row-waiting t-footnote" data-cc-waiting="" data-cc-approve={approve ? "" : undefined}>
      <span>Waiting for approval</span>
      {name ? <span> · Prepared by {name}</span> : null}
    </p>
  );
}

function RowResult({ result, viewer }) {
  if (result.status === "waiting") return <Waiting by={result.by} viewer={viewer} />;
  if (result.status === "refused") {
    return (
      <p className="cc-row-problem t-footnote" role="alert">
        {result.words}
      </p>
    );
  }
  // A CODED ROW READS AS XERO'S CODED STATE (staging check CC-7): its account and rate
  // in their columns, and a few words here. The engine's sentence and the fields Xero
  // holds (ten of them) are one press away, never printed on every row.
  const short = CODED_WORDS[result.outcome] || null;
  const fields = Array.isArray(result.fields) && result.fields.length ? result.fields : null;
  const more = (short && result.words && result.words !== short) || fields;
  return (
    <div className="cc-row-done t-footnote">
      <p>
        {short || result.words}
        {/* REMEMBER SAID NOTHING (staging check CC-8): the rule's own sentence on hover. */}
        {result.remembered ? (
          <span className="cc-remembered" title={result.remembered}>
            {" · "}Rule saved
          </span>
        ) : null}
      </p>
      {more ? (
        <Disclosure summary="Details" className="cc-details">
          {short && result.words !== short ? <p>{result.words}</p> : null}
          {fields ? (
            <dl className="cc-fields">
              {fields.map((f) => (
                <div key={f.label}>
                  <dt>{f.label}</dt>
                  <dd translate="no">{f.value}</dd>
                </div>
              ))}
            </dl>
          ) : null}
        </Disclosure>
      ) : null}
    </div>
  );
}

/** A quiet mark of Vert's confidence; its basis on hover or focus (a tooltip). */
function Confidence({ id, confidence, basis }) {
  const word = CONFIDENCE_WORDS[confidence] || null;
  if (!word) return null;
  return (
    <span className="cc-conf" data-confidence={confidence}>
      <button type="button" className="cc-conf-mark t-caption" aria-describedby={basis ? id : undefined} aria-label={`${word} confidence`}>
        {word}
      </button>
      {basis ? (
        <span className="cc-conf-tip t-footnote" role="tooltip" id={id}>
          {basis}
        </span>
      ) : null}
    </span>
  );
}

/* ── the account picker: a searchable combobox over the contract's accounts ──── */

function AccountPicker({ grid, line, value, label, onPick }) {
  const listId = useId();
  const [query, setQuery] = useState(null);
  const [active, setActive] = useState(0);
  const open = query !== null;
  const shown = accountText(grid, line, value);
  const matches = open ? accountMatches(grid, query).slice(0, 60) : [];

  function pick(match) {
    if (match) onPick(match.code);
    setQuery(null);
  }

  function onKeyDown(event) {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      if (!open) setQuery("");
      setActive((i) => Math.min(i + 1, Math.max(0, matches.length - 1)));
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setActive((i) => Math.max(0, i - 1));
    } else if (event.key === "Enter" && open) {
      event.preventDefault();
      pick(matches[active]);
    } else if (event.key === "Escape" && open) {
      event.preventDefault();
      setQuery(null);
    }
  }

  const activeId = open && matches[active] ? `${listId}-${active}` : undefined;
  return (
    <div className="cc-picker">
      <input
        type="text"
        className="field-input cc-picker-input"
        role="combobox"
        name={`account-${line.id}`}
        aria-label={label}
        aria-expanded={open ? "true" : "false"}
        aria-controls={listId}
        aria-autocomplete="list"
        aria-activedescendant={activeId}
        autoComplete="off"
        translate="no"
        placeholder={open && shown ? shown : "Choose account"}
        value={open ? query : shown}
        onFocus={() => {
          setQuery("");
          setActive(0);
        }}
        onBlur={() => setQuery(null)}
        onChange={(e) => {
          setQuery(e.target.value);
          setActive(0);
        }}
        onKeyDown={onKeyDown}
      />
      <ul className="cc-picker-list" role="listbox" id={listId} aria-label={label} hidden={!open}>
        {matches.map((m, i) => (
          <li
            key={m.code}
            id={`${listId}-${i}`}
            role="option"
            aria-selected={i === active ? "true" : "false"}
            className="cc-picker-option"
            translate="no"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => pick(m)}
          >
            {m.label}
          </li>
        ))}
        {open && !matches.length ? <li className="cc-picker-none" role="presentation">No account matches</li> : null}
      </ul>
    </div>
  );
}
