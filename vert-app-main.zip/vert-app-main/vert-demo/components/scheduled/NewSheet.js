"use client";

// components/scheduled/NewSheet.js — "+ NEW": WHAT, WHEN, CREATE
// ==============================================================================
// scheduled-spec.md:
//
//   What    Journal · Bills & invoices · Reminders · Sync
//   When    Daily · Weekly · Monthly      [ 9:00 am ]
//                                             Create
//
// Weekly adds the weekday; Monthly the day of the month or "Last day". Journal opens
// the existing journal editor's lines inside the sheet (components/cards/JournalEditor.js
// `schedule`), and its Create sends the recurring journal as `config`. A recurring
// journal repeats by the month, so Journal's When is Monthly only.
//
// Create sends `POST /scheduled` `{ kind, name?, cadence, config? }` and nothing else
// (lib/scheduled-model.js newTaskBody). A choice row wraps on a phone rather than
// scrolling sideways: each option is a chip (aria-pressed), one choice per row.

import { useState } from "react";

import JournalEditor from "@/components/cards/JournalEditor";
import { Button, Sheet } from "@/components/ui";
import { IconCaretDown } from "@/components/ui/icons";
import * as api from "@/lib/scheduled-client";
import { JOURNAL_EVERY, JOURNAL_TIME, clockWords, MONTH_DAY_OPTIONS, NEW_EVERY, NEW_KINDS, TIME_OPTIONS, WEEKDAYS, cadenceBody, firstMonthlyDate, todayIn } from "@/lib/scheduled-model";

export const NEW_DEFAULTS = Object.freeze({ kind: "journal", every: "month", time: "09:00", weekday: 1, monthDay: 1 });

export function Choices({ label, options, value, onChange, name }) {
  return (
    <div className="sched-choices" role="group" aria-label={label} data-choices={name}>
      {options.map((o) => (
        <button key={o.value} type="button" className="chip sched-chip" aria-pressed={o.value === value ? "true" : "false"} onClick={() => onChange(o.value)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

/** A native select in the kit's field box, named for assistive tech only (its value says what it is). */
function Pick({ label, name, value, options, onChange, num = false }) {
  return (
    <label className="sched-select">
      <span className="sr-only">{label}</span>
      <span className="field-box">
        <select className={num ? "field-input num" : "field-input"} name={name} autoComplete="off" value={value} onChange={(e) => onChange(e.target.value)}>
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
        <IconCaretDown className="sched-select-caret" size={12} />
      </span>
    </label>
  );
}

/** The cadence the form names (Journal is always monthly). Pure, for the tests. */
export function formCadence(form) {
  const f = { ...NEW_DEFAULTS, ...(form || {}) };
  const journal = f.kind === "journal";
  return cadenceBody({ every: journal ? "month" : f.every, time: journal ? JOURNAL_TIME : f.time, weekday: f.weekday, monthDay: f.monthDay });
}

export function NewForm({ timezone, onCreated, initial = null, create = api.create }) {
  const [form, setForm] = useState(() => ({ ...NEW_DEFAULTS, ...(initial || {}) }));
  const [busy, setBusy] = useState(false);
  const [failed, setFailed] = useState(null);
  const set = (patch) => {
    setFailed(null);
    setForm((f) => ({ ...f, ...patch }));
  };
  const journal = form.kind === "journal";
  const every = journal ? "month" : form.every;
  const cadence = formCadence(form);

  async function submit(config = null, name = null) {
    const answer = await create({ kind: form.kind, name, cadence, config });
    // What the create drafted at once is said on the page (walk 3, W3-6).
    if (answer.ok && onCreated) onCreated(answer.task || null, answer.drafted);
    return answer;
  }

  async function createRoutine() {
    if (busy) return;
    setBusy(true);
    const answer = await submit();
    setBusy(false);
    if (!answer.ok) setFailed(answer.message || "Not saved");
  }

  return (
    <div className="sched-new" data-sched-new-form="">
      <div className="sched-field">
        <span className="sched-field-label">What</span>
        <Choices label="What" name="what" options={NEW_KINDS} value={form.kind} onChange={(kind) => set({ kind })} />
      </div>
      <div className="sched-field">
        <span className="sched-field-label">When</span>
        <div className="sched-when-row">
          <Choices label="When" name="when" options={journal ? JOURNAL_EVERY : NEW_EVERY} value={every} onChange={(next) => set({ every: next })} />
          {every === "week" ? <Pick label="Day" name="weekday" value={String(form.weekday)} options={WEEKDAYS.map((d) => ({ value: String(d.value), label: d.label }))} onChange={(v) => set({ weekday: Number(v) })} /> : null}
          {every === "month" ? <Pick label="Day" name="month-day" value={String(form.monthDay)} options={MONTH_DAY_OPTIONS} onChange={(v) => set({ monthDay: v === "last" ? "last" : Number(v) })} /> : null}
          {journal ? <span className="sched-fixed-time num" data-sched-time="">{clockWords(JOURNAL_TIME)}</span> : <Pick label="Time" name="time" num value={form.time} options={TIME_OPTIONS} onChange={(v) => set({ time: v })} />}
        </div>
      </div>

      {journal ? (
        <JournalEditor
          key="journal"
          schedule={{
            date: firstMonthlyDate(todayIn(timezone), cadence.monthDay),
            label: "Create",
            onCreate: (config) => submit(config, config && config.memo ? config.memo : null),
          }}
        />
      ) : (
        <div className="sched-actions sched-new-actions">
          {failed ? (
            <span className="sched-failed t-footnote" role="alert">
              {failed}
            </span>
          ) : null}
          <Button variant="commit" busy={busy} busyLabel="Creating…" onClick={createRoutine} data-sched-create="">
            Create
          </Button>
        </div>
      )}
    </div>
  );
}

export default function NewSheet({ open = false, timezone, onClose, onCreated }) {
  return (
    <Sheet open={open} onClose={onClose} side="right" title="New" className="sched-sheet sched-new-sheet">
      {open ? <NewForm timezone={timezone} onCreated={onCreated} /> : null}
    </Sheet>
  );
}
