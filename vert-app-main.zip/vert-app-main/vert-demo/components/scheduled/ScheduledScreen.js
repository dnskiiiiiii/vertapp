"use client";

// components/scheduled/ScheduledScreen.js — THE ROUTINES, BY HOW OFTEN THEY RUN
// ==============================================================================
// research/2026-10-27-w3-build/scheduled-spec.md (founder approved 31 Oct 2026):
//
//   Scheduled                                        + New
//   Daily
//     Sync Xero               6:00 am     Done 6:01        ●
//     Bills & invoices        9:00 am     3 to review      ●
//   Weekly
//     Overdue reminders       Mon 9:00    9 drafted        ●
//   Monthly
//     Rent accrual            1st         Next 1 Nov       ●
//
// Row = name · when · last result or next run · on/off. A row opens its side sheet
// (TaskSheet.js); the switch is its own control beside the row, never inside it. An
// empty group draws no header. Words are labels, numbers and dates only.
//
// `openTask` ("bills", a kind, or a task id; the address's `?task=`) opens that task's
// sheet on arrival: /bills is redirected to /scheduled?task=bills (next.config.mjs).

import { useEffect, useMemo, useState } from "react";

import { Button, Switch } from "@/components/ui";
import { IconAdd } from "@/components/ui/icons";
import * as api from "@/lib/scheduled-client";
import { createdParts, groupTasks, resultWords, taskName, whenWords } from "@/lib/scheduled-model";

import NewSheet from "./NewSheet";
import TaskSheet, { Facts } from "./TaskSheet";

/** The task `?task=` names: its id, else the first task of that kind. */
export function taskFor(tasks, wanted) {
  if (!wanted || !Array.isArray(tasks)) return null;
  return tasks.find((t) => t.id === wanted) || tasks.find((t) => t.kind === wanted) || null;
}

/** The sheet's task: the listed one, else the one just ended there (walk 3, N13). */
export function sheetTask(tasks, openId, ended) {
  if (!openId) return null;
  const listed = Array.isArray(tasks) ? tasks.find((t) => t.id === openId) : null;
  return listed || (ended && ended.id === openId ? ended : null);
}

/** The `?task=` the address keeps: the open task's id while it is still listed. */
export function addressTask(tasks, openId) {
  return openId && Array.isArray(tasks) && tasks.some((t) => t.id === openId) ? openId : null;
}

export function TaskRow({ task, timezone, onOpen, onToggle, busy = false, now = undefined }) {
  const name = taskName(task);
  return (
    <li className="sched-row" data-task={task.id} data-kind={task.kind} data-enabled={task.enabled ? "true" : "false"}>
      <button type="button" className="sched-row-open" aria-haspopup="dialog" onClick={(event) => onOpen && onOpen(task.id, event.currentTarget)}>
        <span className="sched-name">{name}</span>
        <span className="sched-when num">{whenWords(task.cadence)}</span>
        <span className="sched-result num" data-sched-result="">
          {resultWords(task, timezone, now)}
        </span>
      </button>
      <Switch className="sched-switch" checked={task.enabled} label={name} busy={busy} onChange={(next) => onToggle && onToggle(task, next)} />
    </li>
  );
}

export default function ScheduledScreen({ initial = null, openTask = null, detail: givenDetail = null, created: givenCreated = null, now = undefined }) {
  const read = Boolean(initial && initial.ok);
  const timezone = read ? initial.timezone : undefined;
  const [tasks, setTasks] = useState(read ? initial.tasks : []);
  const [openId, setOpenId] = useState(() => (read && taskFor(initial.tasks, openTask) ? taskFor(initial.tasks, openTask).id : null));
  const [making, setMaking] = useState(false);
  const [pending, setPending] = useState(() => new Set());
  const [failed, setFailed] = useState(null);
  const [ended, setEnded] = useState(null);
  // What the last Create drafted at once (walk 3, W3-6: "1 draft · 30 Nov"), or null.
  const [created, setCreated] = useState(givenCreated);
  const createdSaid = created ? createdParts(created.drafted, timezone) : [];

  // The address names the open task, so a sheet can be linked and reloaded; a task that
  // is gone (ended) is not named (walk 3, N13).
  const named = addressTask(tasks, openId);
  useEffect(() => {
    if (typeof window === "undefined") return;
    const url = new URL(window.location.href);
    if (named) url.searchParams.set("task", named);
    else url.searchParams.delete("task");
    window.history.replaceState(window.history.state, "", url);
  }, [named]);

  const groups = useMemo(() => groupTasks(tasks), [tasks]);
  const open = sheetTask(tasks, openId, ended);

  function replace(task) {
    if (!task) return;
    setTasks((list) => (list.some((t) => t.id === task.id) ? list.map((t) => (t.id === task.id ? task : t)) : [...list, task]));
  }

  async function relist() {
    const answer = await api.list();
    if (answer.ok && Array.isArray(answer.tasks)) setTasks(answer.tasks);
  }

  // On or off: shown at once, sent as `PATCH { enabled }`, and put back if it was refused.
  async function toggle(task, next) {
    if (pending.has(task.id)) return;
    setFailed(null);
    setPending((s) => new Set(s).add(task.id));
    replace({ ...task, enabled: next });
    const answer = await api.patch(task.id, { enabled: next });
    setPending((s) => {
      const n = new Set(s);
      n.delete(task.id);
      return n;
    });
    if (!answer.ok) {
      replace(task);
      setFailed({ id: task.id, words: answer.message || "Not saved" });
      return;
    }
    replace(answer.task || { ...task, enabled: next });
  }

  return (
    <div className="page sched" data-scheduled="">
      <header className="page-head sched-head">
        <h1 className="t-title-1">Scheduled</h1>
        <Button variant="secondary" icon={<IconAdd size={14} />} onClick={() => setMaking(true)} aria-haspopup="dialog" data-sched-new="">
          New
        </Button>
      </header>

      {createdSaid.length ? (
        <p className="sched-said sched-created t-footnote num" role="status" data-sched-created={created.id || ""}>
          <Facts parts={createdSaid} />
        </p>
      ) : null}

      {!read ? (
        <p className="sched-unread" role="status" data-sched-unread={(initial && initial.kind) || "refused"}>
          {(initial && initial.message) || "Not read"}
        </p>
      ) : !tasks.length ? (
        <p className="sched-empty" data-sched-empty="">
          No tasks
        </p>
      ) : (
        groups.map((g) => (
          <section className="sched-group" key={g.every} aria-labelledby={`sched-${g.every}`} data-group={g.every}>
            <h2 className="sched-group-title" id={`sched-${g.every}`}>
              {g.label}
            </h2>
            <ul className="sched-list">
              {g.tasks.map((t) => (
                <TaskRow key={t.id} task={t} timezone={timezone} busy={pending.has(t.id)} onOpen={setOpenId} onToggle={toggle} now={now} />
              ))}
            </ul>
          </section>
        ))
      )}

      {failed ? (
        <p className="sched-failed t-footnote" role="alert" data-sched-failed={failed.id}>
          {failed.words}
        </p>
      ) : null}

      <TaskSheet
        open={Boolean(open)}
        task={open}
        timezone={timezone}
        detail={givenDetail}
        busy={open ? pending.has(open.id) : false}
        ended={Boolean(open && ended && ended.id === open.id)}
        onToggle={toggle}
        onTask={(t) => {
          replace(t);
          relist();
        }}
        onEnded={(t) => {
          setEnded(t);
          setTasks((list) => list.filter((x) => x.id !== t.id));
          relist();
        }}
        onClose={() => {
          setOpenId(null);
          setEnded(null);
        }}
      />
      <NewSheet
        open={making}
        timezone={timezone}
        onClose={() => setMaking(false)}
        onCreated={(task, drafted) => {
          setMaking(false);
          if (task) replace(task);
          setCreated(task ? { id: task.id, drafted } : null);
          relist();
        }}
      />
    </div>
  );
}
