"use client";

// components/scheduled/TaskSheet.js — ONE ROUTINE, IN THE SIDE SHEET
// ==============================================================================
// scheduled-spec.md's side sheets. The header line is the same for every kind:
//
//   Bills & invoices                         Daily · 9:00   ●   ✕
//
// and the body is the kind's (`GET /scheduled/{id}` `detail`):
//
//   bills     the drop zone (components/bills/UploadZone.js, compact), "To review N"
//             with each item's Review → its existing review page (/bills/<id>),
//             "Sent N" and History
//   journal   the lines (account, Dr/Cr), "Next" three dates (or "Paused"), Pause and
//             End; once ended, "Ended" (walk 3, N13)
//   others    Run now and History (status · summary · date)
//
// A run only drafts: nothing here sends to Xero. (The reminders' "Drafted N" opens the
// drafts, each sent only by its own Approve & send, as in the aged receivables answer.)
// The sheet is the app's one Sheet (components/ui/Sheet.js), from the right; on a phone
// it fills the screen (kit.css).
// `detail` is handed in only by a test; the page reads it when the sheet opens.

import Link from "next/link";
import { useEffect, useId, useState } from "react";

import { Button, IconButton, Sheet, Switch } from "@/components/ui";
import { SkeletonBlock } from "@/components/ui/marks";
import { IconClose } from "@/components/shell/icons";
import UploadZone from "@/components/bills/UploadZone";
import ReminderDrafts from "@/components/chat/answer/ReminderDrafts";
import { requestDrafts } from "@/lib/reminders-client";
import { moneyText } from "@/lib/bills-model";
import { formatAccount } from "@/lib/format";
import * as api from "@/lib/scheduled-client";
import { cadenceWords, dayWords, draftedDays, entryHref, historyOf, historyParts, journalStatus, linesOf, nextDays, ranWords, reviewHref, reviewOf, taskName } from "@/lib/scheduled-model";

/** Facts on one line, set apart by the stylesheet's middle dot (.sched-facts). */
export function Facts({ parts, className }) {
  return (
    <span className={["sched-facts", className].filter(Boolean).join(" ")}>
      {parts.map((p, i) => (
        <span key={`${p}-${i}`}>{p}</span>
      ))}
    </span>
  );
}

function amountText(cents, currency) {
  const text = moneyText(cents);
  return currency && currency !== "AUD" && Number.isInteger(cents) ? `${text} ${currency}` : text;
}

/** `next` (an instant or null): a history with no runs says when the first is (walk 3, N17). */
export function History({ runs, timezone, next = null }) {
  const nextDay = next ? dayWords(next, timezone) : null;
  return (
    <section className="sched-section" data-sched-history="">
      <h3 className="sched-section-title">History</h3>
      {runs.length ? (
        <ul className="sched-history">
          {runs.map((r, i) => (
            <li key={`${r.at || "run"}-${i}`} className="sched-history-row num" data-status={r.status || undefined}>
              <Facts parts={historyParts(r, timezone)} />
            </li>
          ))}
        </ul>
      ) : (
        <p className="sched-none num">{nextDay ? `Next ${nextDay}` : "No runs"}</p>
      )}
    </section>
  );
}

function Stat({ label, value, children = null }) {
  return (
    <div className="sched-stat" data-sched-stat={label}>
      <span className="sched-stat-label">{label}</span>
      <span className="sched-stat-value num">{value}</span>
      {children}
    </div>
  );
}

export function BillsBody({ task = null, detail, timezone, onChanged }) {
  const review = reviewOf(detail);
  const sent = detail && Number.isInteger(detail.sentCount) ? detail.sentCount : null;
  return (
    <>
      <UploadZone compact onUploaded={onChanged} />
      <section className="sched-section" data-sched-review="">
        <h3 className="sched-section-title">
          To review <span className="sched-count num">{review.length}</span>
        </h3>
        {review.length ? (
          <ul className="sched-review">
            {review.map((r) => (
              <li key={r.itemId} className="sched-review-row" data-item={r.itemId}>
                <span className="sched-review-contact">{r.contact || "No contact"}</span>
                <span className="sched-review-amount num">{amountText(r.totalCents, r.currency)}</span>
                <Link className="link sched-review-open" href={reviewHref(r.itemId)}>
                  Review
                </Link>
              </li>
            ))}
          </ul>
        ) : null}
      </section>
      <Stat label="Sent" value={sent === null ? "Not read" : String(sent)} />
      <History runs={historyOf(detail)} timezone={timezone} next={task ? task.nextRunAt : null} />
    </>
  );
}

export function JournalBody({ task, detail, timezone, onChanged, onEnded }) {
  const lines = linesOf(detail);
  const status = journalStatus(detail);
  const next = nextDays(detail, timezone);
  const drafted = draftedDays(detail, timezone);
  const paused = status === "paused" || (status !== "ended" && !task.enabled);
  const [busy, setBusy] = useState(null);
  const [confirming, setConfirming] = useState(false);
  const [failed, setFailed] = useState(null);

  async function press(which) {
    if (busy) return;
    setFailed(null);
    setBusy(which);
    const answer = which === "end" ? await api.end(task.id) : await api.patch(task.id, { enabled: which === "resume" });
    setBusy(null);
    setConfirming(false);
    if (!answer.ok) {
      setFailed(answer.message || "Not saved");
      return;
    }
    // An ended journal leaves the list: the sheet says Ended rather than vanishing
    // (walk 3, N13), and nothing re-reads a task that is gone.
    if (which === "end" && onEnded) onEnded(task);
    else if (onChanged) onChanged(answer.task || null);
  }

  return (
    <>
      <table className="sched-lines" data-sched-lines="">
        <thead className="sr-only">
          <tr>
            <th scope="col">Account</th>
            <th scope="col">Side</th>
            <th scope="col">Amount</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={`${l.account}-${i}`}>
              <td className="sched-line-account" translate="no">
                {formatAccount(l.account, l.accountName) || "No account"}
              </td>
              <td className="sched-line-side" data-side={l.side || undefined}>
                {l.side}
              </td>
              <td className="sched-line-amount num">{l.cents === null ? "" : moneyText(l.cents).replace("$", "")}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {status === "ended" ? (
        <Stat label="Ended" value="" />
      ) : (
        <>
          {/* What it has drafted, each day to its entry, before what is next (walk 3, W3-6). */}
          {drafted.length ? (
            <Stat
              label="Drafted"
              value={
                <span className="sched-facts">
                  {drafted.map((d) => (
                    <span key={d.entryId} data-drafted-status={d.status}>
                      <Link className="link" href={entryHref(d.entryId)}>
                        {d.day}
                      </Link>
                      {d.status === "rejected" ? <span className="ink-2"> · Rejected</span> : null}
                    </span>
                  ))}
                </span>
              }
            />
          ) : null}
          {paused ? <Stat label="Paused" value="" /> : <Stat label="Next" value={next.length ? <Facts parts={next} /> : "None"} />}
          <div className="sched-actions">
            <Button variant="secondary" size="sm" busy={busy === "pause" || busy === "resume"} onClick={() => press(paused ? "resume" : "pause")} data-sched-pause="">
              {paused ? "Resume" : "Pause"}
            </Button>
            {confirming ? (
              <Button variant="quiet" size="sm" destructive busy={busy === "end"} onClick={() => press("end")} data-sched-end-confirm="">
                Confirm end
              </Button>
            ) : (
              <Button variant="quiet" size="sm" destructive onClick={() => setConfirming(true)} data-sched-end="">
                End
              </Button>
            )}
          </div>
        </>
      )}
      {failed ? (
        <p className="sched-failed t-footnote" role="alert">
          {failed}
        </p>
      ) : null}
    </>
  );
}

/**
 * "Drafted 9", and the drafts behind it (staging browser walk 3, N12: it led nowhere).
 * Reminder drafts are kept nowhere but where they are drawn, so pressing the count drafts
 * them again as at today (`POST /reminders/drafts`, which sends nothing) and draws them
 * here, each with its own Approve & send, as the aged receivables answer does.
 */
export function DraftedStat({ count }) {
  const [open, setOpen] = useState(false);
  const [read, setRead] = useState(null);

  async function toggle() {
    const next = !open;
    setOpen(next);
    if (!next || (read && read.ok)) return;
    setRead({ busy: true });
    const got = await requestDrafts(null);
    setRead(got.ok && got.body && got.body.reminders ? { ok: true, reminders: got.body.reminders } : { ok: false, words: got.message || "Not read" });
  }

  return (
    <>
      <Stat
        label="Drafted"
        value={
          count > 0 ? (
            <button type="button" className="link sched-stat-link num" aria-expanded={open ? "true" : "false"} onClick={toggle} data-sched-drafts="">
              {String(count)}
            </button>
          ) : (
            String(count)
          )
        }
      />
      {open && read ? (
        read.busy ? (
          <div className="sched-loading" role="status" aria-label="Loading">
            <SkeletonBlock height="1.25rem" width="60%" />
          </div>
        ) : read.ok ? (
          <ReminderDrafts reminders={read.reminders} />
        ) : (
          <p className="sched-unread" role="status">
            {read.words}
          </p>
        )
      ) : null}
    </>
  );
}

export function RoutineBody({ task, detail, timezone, onChanged }) {
  const [busy, setBusy] = useState(false);
  const [said, setSaid] = useState(null);
  const drafted = task.kind === "reminders" && detail && Number.isInteger(detail.drafted) ? detail.drafted : null;

  async function runNow() {
    if (busy) return;
    setBusy(true);
    setSaid(null);
    const answer = await api.run(task.id);
    setBusy(false);
    setSaid(answer.ok ? { ok: true, words: ranWords(answer) } : { ok: false, words: answer.message || "Didn't run" });
    if (answer.ok && onChanged) onChanged(answer.task || null);
  }

  return (
    <>
      {drafted !== null ? <DraftedStat count={drafted} /> : null}
      <div className="sched-actions">
        <Button variant="secondary" size="sm" busy={busy} busyLabel="Running…" onClick={runNow} data-sched-run="">
          Run now
        </Button>
        {said ? (
          <span className="sched-said t-footnote" role={said.ok ? "status" : "alert"}>
            {said.words}
          </span>
        ) : null}
      </div>
      <History runs={historyOf(detail)} timezone={timezone} next={task.nextRunAt} />
    </>
  );
}

export function TaskBody({ task, detail, timezone, onChanged, onEnded }) {
  if (task.kind === "bills") return <BillsBody task={task} detail={detail} timezone={timezone} onChanged={onChanged} />;
  if (task.kind === "journal") return <JournalBody task={task} detail={detail} timezone={timezone} onChanged={onChanged} onEnded={onEnded} />;
  return <RoutineBody task={task} detail={detail} timezone={timezone} onChanged={onChanged} />;
}

export default function TaskSheet({ open = false, task = null, timezone, detail: given = null, busy = false, ended = false, onToggle, onTask, onEnded, onClose }) {
  const titleId = useId();
  const id = task ? task.id : null;
  // What was read, and for which task: another task's detail is never drawn under this one.
  const [got, setGot] = useState(null);
  const [tick, setTick] = useState(0);
  const read = given ? { ok: true, detail: given } : got && got.id === id ? got : null;

  useEffect(() => {
    if (!open || !id || given || ended) return undefined;
    let live = true;
    api.read(id).then((answer) => {
      if (live) setGot(answer.ok ? { id, ok: true, detail: answer.detail || null } : { id, ok: false, words: answer.message || "Not read" });
    });
    return () => {
      live = false;
    };
  }, [open, id, given, ended, tick]);

  // A change in the sheet re-reads it (its counts are the engine's, never adjusted here).
  function changed(t) {
    if (t && onTask) onTask(t);
    else if (onTask && task) onTask(task);
    setTick((n) => n + 1);
  }

  const name = task ? taskName(task) : "";
  return (
    <Sheet open={open} onClose={onClose} side="right" labelledBy={titleId} className="sched-sheet">
      {task ? (
        <>
          <header className="sched-sheet-head">
            <h2 className="t-title-2 sched-sheet-title" id={titleId} tabIndex={-1}>
              {name}
            </h2>
            <span className="sched-sheet-cadence num">{cadenceWords(task.cadence)}</span>
            {ended ? null : <Switch className="sched-switch" checked={task.enabled} label={name} busy={busy} onChange={(next) => onToggle && onToggle(task, next)} />}
            <IconButton label="Close" onClick={onClose} className="sheet-close">
              <IconClose />
            </IconButton>
          </header>
          <div className="sched-sheet-body" data-sheet-kind={task.kind}>
            {ended ? (
              <Stat label="Ended" value="" />
            ) : read && read.ok ? (
              <TaskBody task={task} detail={read.detail} timezone={timezone} onChanged={changed} onEnded={onEnded} />
            ) : read ? (
              <p className="sched-unread" role="status">
                {read.words}
              </p>
            ) : (
              <div className="sched-loading" role="status" aria-label="Loading">
                <SkeletonBlock height="2.5rem" />
                <SkeletonBlock height="1.25rem" width="60%" />
                <SkeletonBlock height="1.25rem" width="40%" />
              </div>
            )}
          </div>
        </>
      ) : null}
    </Sheet>
  );
}
