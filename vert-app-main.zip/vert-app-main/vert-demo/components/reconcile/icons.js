// components/reconcile/icons.js — THE LEGACY SURFACES' MARKS, NOW PHOSPHOR
// ==============================================================================
// Founder decision D7 (10 Oct 2026); design-fix-2 spec §4. Re-exports of the one icon set
// (components/ui/icons.js) under the names the reconciliation, records, checklist and
// sync call sites use. Every one is decorative and aria-hidden, beside words that
// already say the thing. Owners move their imports to "@/components/ui/icons"; then this
// file is deleted.

import {
  IconAdd,
  IconCaretDown,
  IconCaretRight,
  IconCheck,
  IconSpinner as UiSpinner,
  IconStatusDone,
  IconWarning,
} from "@/components/ui/icons";

export {
  IconClock,
  IconInTransit,
  IconDollar,
  IconHash,
  IconBank,
  IconCurrency,
  IconLedger,
  IconSearch,
  IconClose,
  IconExpand as IconExpandArrows,
  IconFilter as IconFunnel,
  IconRows,
  IconRowsCompact,
  IconDownload,
  IconExternal,
  IconEye,
  IconList,
  IconMoreVertical as IconKebab,
  IconStar,
  IconShare,
  IconCalendar,
  IconEdit as IconPencil,
  IconSend as IconArrowUp,
  IconPerson,
  IconPersonCheck,
  IconRepeat,
  IconPayments as IconPayouts,
} from "@/components/ui/icons";

export function IconCheckCircle(props) {
  return <IconStatusDone size={16} {...props} />;
}
export function IconTick(props) {
  return <IconCheck size={14} {...props} />;
}
export function IconAlert(props) {
  return <IconWarning size={16} {...props} />;
}
/** Pointing right; `.pt-chev` rotates it when the row opens. */
export function IconChevron(props) {
  return <IconCaretRight size={16} {...props} />;
}
export function IconChevronDown(props) {
  return <IconCaretDown size={16} {...props} />;
}
export function IconSpinner(props) {
  return <UiSpinner size={16} {...props} />;
}
export function IconPlus(props) {
  return <IconAdd size={16} {...props} />;
}
