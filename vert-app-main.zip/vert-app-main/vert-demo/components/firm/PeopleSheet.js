"use client";

// components/firm/PeopleSheet.js — WHO IN THE FIRM DOES WHAT (build plan §20.12 H3, M4)
// ==============================================================================
// Owner: F-SEC. A sheet from the account menu (no new page: §20 rule 6), listing the
// firm's people with their role — Admin, Reviewer or Preparer — and what each role
// means, in one line each: reviewers approve and post, preparers draft, and payroll is
// for admins only. An admin changes a person's role here; everyone else reads it.
//
// THE ENGINE'S ROLES, NEVER THE SHEET'S. Every row is the engine's read. A change is
// sent, then read back, and the row moves only when the read-back agrees
// (lib/people.js setRole). A role the screen doesn't know is "Role not read", never a
// guessed one. With no roles in the engine yet the sheet says what is true today —
// everyone sees and does everything — rather than drawing three empty choices.
//
// Not purple: changing a role is a setting, not the view's commit (§13).

import { useEffect, useState } from "react";
import { Sheet } from "@/components/ui";
import { setRole as setRoleAction } from "@/lib/people";
import { ASSIGN_REASON, ROLE_WORDS } from "@/lib/roles";
import { ROLES_NOT_ON, ROLE_OPTIONS, changeWords, isUnassigned, noticeOf, roleLabel, segregationWords } from "./people-model";
import "./duties.css";

/** Read the people through the app's route. `{ state, people?, segregation?, notice? }`. */
export async function fetchPeople(fetchImpl = globalThis.fetch) {
  try {
    const res = await fetchImpl("/api/firm/people", { cache: "no-store" });
    const body = await res.json();
    if (body && body.ok && Array.isArray(body.people)) return { state: "read", people: body.people, segregation: body.segregation ?? null, notice: noticeOf(body), unassigned: body.unassigned ?? null };
    if (body && body.kind === "not_built") return { state: "not_built" };
    return { state: "failed" };
  } catch {
    return { state: "failed" };
  }
}

export function PeopleList({ read, you = null, canAssign = false, busyPerson = null, onChange }) {
  return (
    <ul className="people-list" aria-label="People in your firm">
      {read.people.map((p) => {
        const mine = you && p.person === you;
        const unset = !p.role && isUnassigned(read, p.person);
        return (
          <li key={p.person} className="people-row" data-person-role={p.role || (unset ? "unset" : "unread")}>
            <span className="people-name">
              {p.person}
              {mine ? <span className="people-you t-footnote"> · you</span> : null}
            </span>
            {canAssign && !mine ? (
              <label className="people-role-pick">
                <span className="sr-only">{`Role for ${p.person}`}</span>
                <select
                  name="role"
                  autoComplete="off"
                  className="field-input"
                  value={p.role || ""}
                  disabled={busyPerson === p.person}
                  onChange={(event) => onChange && onChange(p.person, event.target.value)}
                >
                  {p.role ? null : (
                    <option value="" disabled>
                      {unset ? "No role yet" : "Role not read"}
                    </option>
                  )}
                  {ROLE_OPTIONS.map((o) => (
                    <option key={o.role} value={o.role}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </label>
            ) : (
              <span className="people-role t-footnote">{roleLabel(p.role, { unassigned: unset })}</span>
            )}
          </li>
        );
      })}
    </ul>
  );
}

export function PeopleBody({ read, you = null, role = null, busyPerson = null, message = null, onChange }) {
  if (!read) return <p className="t-body people-state" role="status">Reading your firm's people…</p>;
  if (read.state === "not_built") return <p className="t-body people-state">{ROLES_NOT_ON}</p>;
  if (read.state !== "read") return <p className="t-body people-state" role="alert">Vert couldn't read your firm's people just now.</p>;
  const canAssign = role === "admin";
  const segregation = segregationWords(read.segregation);
  const notice = noticeOf(read);
  return (
    <div className="people-body">
      {notice ? (
        <p className="t-body people-notice" role="status" data-people-notice="">
          {notice}
        </p>
      ) : null}
      {role ? (
        <p className="t-body">
          You're {/^[aeiou]/i.test(ROLE_WORDS[role]) ? "an" : "a"} <strong>{ROLE_WORDS[role].toLowerCase()}</strong> here.
          {canAssign ? " You can change anyone else's role." : ` ${ASSIGN_REASON}`}
        </p>
      ) : null}
      <PeopleList read={read} you={you} canAssign={canAssign} busyPerson={busyPerson} onChange={onChange} />
      {message ? (
        <p className="t-footnote people-message" role="status">
          {message}
        </p>
      ) : null}
      <dl className="people-duties">
        {ROLE_OPTIONS.map((o) => (
          <div key={o.role} className="people-duty">
            <dt>{o.label}</dt>
            <dd className="t-footnote">{o.duty}</dd>
          </div>
        ))}
      </dl>
      {segregation ? <p className="t-footnote people-segregation">{segregation}</p> : null}
    </div>
  );
}

export default function PeopleSheet({ open, onClose, you = null, role = null, setRole = setRoleAction, initial = undefined }) {
  const [read, setRead] = useState(initial === undefined ? null : initial);
  const [busyPerson, setBusyPerson] = useState(null);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    if (!open || initial !== undefined) return undefined;
    let live = true;
    setRead(null);
    fetchPeople().then((r) => {
      if (live) setRead(r);
    });
    return () => {
      live = false;
    };
  }, [open, initial]);

  async function change(person, next) {
    setBusyPerson(person);
    setMessage(null);
    let result = null;
    try {
      result = await setRole(person, next);
    } catch {
      result = null;
    }
    setBusyPerson(null);
    if (result && result.ok) setRead({ state: "read", people: result.people, segregation: result.segregation ?? null, notice: noticeOf(result), unassigned: result.unassigned ?? null });
    setMessage(changeWords(result, person, next));
  }

  return (
    <Sheet open={open} onClose={onClose} side="right" title="People and roles" className="people-sheet">
      <PeopleBody read={read} you={you} role={role} busyPerson={busyPerson} message={message} onChange={change} />
    </Sheet>
  );
}
