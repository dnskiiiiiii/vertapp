// components/firm/people-model.js — THE PEOPLE SHEET'S RULES, WITHOUT REACT OR THE NETWORK
// ==============================================================================
// Owner: F-SEC (build plan §20.12 H3). The engine's `GET /firm/people` body, read one
// way; the words the sheet says about it; and the read-back rule a role change must
// pass before the sheet says it happened. Pure, so tests hold it without a session.
//
// THE CONTRACT ASKED OF THE ENGINE (SEC-B; until it lands the read is a 404 and the
// sheet says roles are not on yet, which is today's truth: security-review H3):
//
//   GET  /firm/people                → { people: [{ person, role }], segregation: bool,
//                                        admins: int, unassigned: [string],
//                                        notice: string | null }
//                                      (`notice` is the engine's words for a firm with
//                                      people and no admin: nobody can give a role yet)
//   POST /firm/people/{person}/role  { role } → 200 { person, role }
//                                    403 role_assign_forbidden (not an admin)
//                                    409 last_admin (the firm would have no admin)

import { ROLES, ROLE_DUTIES, ROLE_WORDS, roleOf } from "@/lib/roles";

/** The engine's notice, as it wrote it, or null. A firm with people and no admin
 * cannot turn roles on from this sheet (only an admin assigns one), so the sheet says
 * the engine's sentence rather than drawing what looks like an ordinary list of unset
 * roles (G4 eval-r1 H3, W0a-fix1). Words are the engine's; none are made up here. */
export function noticeOf(body) {
  const n = body && typeof body.notice === "string" ? body.notice.trim() : "";
  return n || null;
}

/** `{ people, segregation, admins, notice, unassigned }` from the engine's body, or null when it
 * is not that shape. `admins` is null when the engine didn't count them: an unread
 * count is never 0. */
export function peopleOf(body) {
  if (!body || typeof body !== "object" || !Array.isArray(body.people)) return null;
  const people = [];
  for (const p of body.people) {
    const person = p && typeof p.person === "string" ? p.person.trim() : "";
    if (!person) continue;
    // A role this screen doesn't know is shown as unread, never as a guessed one.
    people.push({ person, role: roleOf(p.role) });
  }
  people.sort((a, b) => a.person.localeCompare(b.person));
  return {
    people,
    segregation: typeof body.segregation === "boolean" ? body.segregation : null,
    admins: Number.isInteger(body.admins) && body.admins >= 0 ? body.admins : null,
    notice: noticeOf(body),
    // Who has no role and so is held to drafting (W0a-fix2), by name; null when the
    // engine didn't say, never [] for an unread list.
    unassigned: Array.isArray(body.unassigned)
      ? body.unassigned.filter((n) => typeof n === "string" && n.trim()).map((n) => n.trim())
      : null,
  };
}

/** Whether a read-back shows `person` holding `role`: the only proof a change landed. */
export function roleConfirmed(read, person, role) {
  if (!read || !Array.isArray(read.people)) return false;
  const row = read.people.find((p) => p.person === person);
  return Boolean(row && row.role === role);
}

/** The firm's segregation setting, in words; null when the engine didn't say. */
export function segregationWords(segregation) {
  if (segregation === true) return "The person who drafts an entry can't approve or post it. Someone else in the firm does.";
  if (segregation === false) return "In this firm, the person who drafts an entry can also approve and post it.";
  return null;
}

/** What the sheet says when the engine has no roles yet: today's state, plainly. */
export const ROLES_NOT_ON =
  "Roles aren't switched on for your firm yet, so everyone in it can see every client, payroll included, and approve and post.";

/** The role options, in the order the sheet offers them, each with its duty line. */
export const ROLE_OPTIONS = Object.freeze(ROLES.map((role) => ({ role, label: ROLE_WORDS[role], duty: ROLE_DUTIES[role] })));

/** A person the engine NAMED as having no role (W0a-fix2): read, and held to drafting.
 * Different from "Role not read", which is a role this screen couldn't read. */
export const UNSET_LABEL = "No role yet · drafts only";

/** Whether the engine named `person` as having no role. */
export function isUnassigned(read, person) {
  return Boolean(read && Array.isArray(read.unassigned) && read.unassigned.includes(person));
}

/** "Reviewer", or words for a role the engine sent that this screen doesn't know. */
export function roleLabel(role, { unassigned = false } = {}) {
  if (!ROLE_WORDS[role] && unassigned) return UNSET_LABEL;
  return ROLE_WORDS[role] || "Role not read";
}

/** The sentence after a role change, from the action's result. */
export function changeWords(result, person, role) {
  if (result && result.ok) return `${person} is now ${/^[aeiou]/i.test(ROLE_WORDS[role]) ? "an" : "a"} ${ROLE_WORDS[role].toLowerCase()}.`;
  const code = result && result.code;
  if (code === "role_assign_forbidden") return "Only an admin can change roles. Nothing was changed.";
  if (code === "last_admin") return "Your firm needs at least one admin. Nothing was changed.";
  if (code === "not_read_back") return "Vert couldn't confirm the change. Open this again to check.";
  return "Nothing was changed. Try again.";
}
