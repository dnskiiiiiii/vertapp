"use client";

// components/setup/ConnectionsList.js — WHAT VERT READS FROM, AS ONE LIST OF ROWS
// ==============================================================================
// Spec §3.6 and §3.2; audit UI-011, UI-037, UI-061, UI-062, UI-067.
//
//   No ledger is connected yet, so entries can't be posted. Connect Xero or QuickBooks Online.
//   Stripe          Connected · Harper & Co (acct_1Pq…)            Sync now
//   Xero            Not connected                                  Connect
//   QuickBooks      Not connected                                  Connect
//   Shopify         Not available yet                              Details
//   Bank statement  Import a CSV when there's no bank feed          Import
//
// ONE LIST, TWO PLACES. This is Connections (/connections, from the account menu) and
// it is Month-end's first-run state (F3's FirstRun renders it), so setting up and
// checking later are the same rows — the old /setup errand and the /connections page
// said the Stripe instructions twice and disagreed about which step came next (UI-061).
//
// ROWS, AND SHEETS FOR THE WORK. Each provider is one row (components/settings/
// ProviderCard.js) with one action at the right. "Connect" and "Import" open a sheet
// with the form in it (UI-067): the list stays a list, and the instructions a person
// needs once are not printed above everyone's rows forever. A sheet's content is
// mounted on first open and not before, so a closed sheet's words are not on the page.
//
// ONE FILLED BUTTON. The accent means "this writes" (spec §11.2), and Connect writes a
// credential — but a page with three filled Connects has no next step. The first
// provider that needs connecting gets the filled button; the rest are secondary.
//
// NO ASSISTANT ROW, NO OPERATOR TEXT (spec §3.6, §10). Vert supplies the assistant and
// reports its health to operators through the API; nothing here names a model, a
// provider key, a CLI or an administrator. tests/connections.test.js reads the
// rendered text for those words.
//
// SYNC NAMES ONLY WHAT IS CONNECTED (UI-062), and a failed sync is a sentence and
// Retry (UI-011): components/sync/useSync.js now catches the network failure it used
// to let fall through a `finally`, and SyncReport prints it.
//
// DESIGN-FIX-2 (DA2-040). The failed read is a one-line problem notice that names its
// cause and what did not happen ("Couldn't check what's connected: Vert's server didn't
// answer. Nothing has changed.") with a quiet Try again on the same line; the service's
// own words stay one press down under Details. Each row is a source's monochrome mark in
// a 32 px tile, the name, its state as a glyph and a word with no pill, and ONE action in
// ONE style (secondary) on every row that has one: Connect, Import, Change. The page's
// title is title-1 Archivo; rows are a fixed 64 px.
//
// A READ THAT FAILED IS ONE SENTENCE, RETRY, AND DETAILS (eval r1, rubric S6). It was
// a red plate with a paragraph ("This screen could not ask what is connected, so the
// rows below are the services Vert supports, not a report on …"), the service's own
// message on the face, and then every row repeating "Nothing was read about this
// connection … the question was never answered" — 185 to 226 words above the fold
// against a limit of 100. Now: the verdict line says it once, Try again re-reads, the
// service's words sit under Details closed, and each row says "Not checked".

import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button, Disclosure, Portal, Sheet, SourceLogo } from "@/components/ui";
import { IconProblem } from "@/components/ui/icons";
import BankAccountPanel from "@/components/settings/BankAccountPanel";
import BankStatementImport from "@/components/settings/BankStatementImport";
import ConnectProviderButton from "@/components/settings/ConnectProviderButton";
import PayoutAccountSetting from "@/components/settings/PayoutAccountSetting";
import PostModeSetting from "@/components/settings/PostModeSetting";
import DocumentModeSetting from "@/components/settings/DocumentModeSetting";
import ProviderCard from "@/components/settings/ProviderCard";
import StripeConnectForm from "@/components/settings/StripeConnectForm";
import SyncFreshness from "@/components/sync/SyncFreshness";
import { SyncPressResult, useSyncPress } from "@/components/sync/SyncOutcome";
import SyncReport from "@/components/sync/SyncReport";
import useSync from "@/components/sync/useSync";
import { formatAccount } from "@/lib/format";
import { connectedLedgers, ledgerChoiceWords, ledgerConflictLine, payoutAccountLine, postModeLine, providerRows, secondLedgerReason } from "@/lib/connections-shape";

import { readBankAccount } from "./steps";
import "./connections.css";

// The sentence the sample build shows instead of the service's own, which is written
// for whoever runs the service (it names an environment variable). A bookkeeper on
// the sample books needs to know one thing: nothing here is theirs to connect.
export const SAMPLE_BOOKS_LINE = "These are the sample books, so there is nothing to connect here.";

// THE LEDGER IS WHICHEVER LEDGER ROW IS CONNECTED, never a vendor id written here. This
// read `const LEDGER_ID = "quickbooks"` until Xero became the first ledger (16 Oct 2026),
// which would have told a tenant with Xero connected that their ledger was not, and hidden
// the bank account their ledger reads. lib/connections-shape.js answers "which rows are
// ledgers" from the catalogue (`ledger: true`), in its order: Xero first.

// Each row leads with its source's own mark, monochrome in the ink (design-fix-2 DA2-027,
// DA2-040; components/ui/SourceLogo.js): a provider row hands SourceLogo its catalogue id,
// which is the mark's key for every provider with one (Stripe, Xero, QuickBooks, Shopify);
// the bank and a CSV statement take Phosphor glyphs. No vendor is spelled in this file.

/** The POS and inventory row (w48, audit row 4.3): not connected, and one question. */
export const POS_ROW = Object.freeze({ name: "POS & inventory", state: "Not connected", question: "Do you use Unleashed, Cin7 or Lightspeed?" });

/**
 * The one line under the title: what is missing, and what that stops — or that
 * nothing is. Derived from the same rows the list draws, so it cannot disagree with
 * them (spec §13.9).
 */
export function connectionsVerdict(answer, rows) {
  if (!answer || answer.ok !== true) {
    if (answer && answer.kind === "unavailable") return SAMPLE_BOOKS_LINE;
    return `Couldn't check what's connected: ${failureCause(answer)}. Nothing has changed.`;
  }
  const byId = Object.fromEntries(rows.map((row) => [row.id, row]));
  const stripe = byId.stripe;
  // TWO LEDGERS IS SAID FIRST. It is the one state on this page the product refuses, and
  // "Everything Vert reads from is connected" over it would be the verdict line saying
  // all is well about the one thing that is not.
  const conflict = ledgerConflictLine(rows);
  if (conflict) return conflict;
  // THE LEDGER FIRST (production walk, 8 Nov 2026): Stripe is an optional source.
  if (!connectedLedgers(rows).length) {
    return `No ledger is connected yet, so entries can't be posted. Connect ${ledgerChoiceWords(rows)}.`;
  }
  if (stripe && !stripe.connected) return "Your books are connected. Connect Stripe too if you take card payments through it.";
  return "Everything Vert reads from is connected.";
}

/**
 * Why the read failed, in a bookkeeper's words (DA2-040: an error says what happened and
 * why). Classified from the answer's shape, never its message (that is written for whoever
 * runs the service and stays under Details): a refusal, or no answer at all.
 */
export function failureCause(answer) {
  const status = answer && Number(answer.status);
  if (status === 401 || status === 403) return "Vert's server refused the request";
  if (status >= 400 && status < 500) return "Vert's server couldn't read the request";
  // AN ANSWER IS NOT SILENCE (round 2, seen on a local stack): 501 is a server that
  // answered and said it holds no vendor connections; "didn't answer" was untrue there.
  if (status === 501) return "this Vert server isn't set up to read connections";
  if (status >= 500) return "Vert's server ran into a problem";
  return "Vert's server didn't answer";
}

/**
 * What sits under Details when the read failed: the service's own words, or what is
 * known about there being none. Never on the face — it is written for whoever runs the
 * service, and a bookkeeper can act on none of it.
 */
export function connectionsFailureDetail(answer) {
  if (!answer) return null;
  if (answer.message) return answer.message;
  return answer.status
    ? `The service answered ${answer.status} and gave no reason.`
    : "The service gave no reason.";
}

/**
 * The bank account row's state: the account chosen, by its code and name (staging
 * browser walk 1, D9: it said "Reading 13918178-849a-4823-9a31-57b7eac713d7"). The id
 * is matched against the worker's own list; one it doesn't list is said without the id.
 */
export function bankAccountWords(bankRead) {
  const state = bankRead && typeof bankRead === "object" && "chosen" in bankRead && "accounts" in bankRead && typeof bankRead.ok === "boolean" ? bankRead : readBankAccount(bankRead);
  if (!state || !state.ok) return "Not checked";
  if (!state.chosen) return "Not chosen yet, so no deposit can be confirmed";
  // By id, as the worker records the choice; or by name, as an older worker answered it.
  const accounts = (state.accounts || []).filter((a) => a && typeof a === "object");
  const account = accounts.find((a) => String(a.id) === state.chosen) || accounts.find((a) => a.name === state.chosen);
  const name = account ? formatAccount(account.code, account.name && account.name !== String(account.id) ? account.name : null) : "";
  return name ? `Reading ${name}` : "Reading the account you chose";
}

// SYNC NOW FOR A CONNECTED LEDGER (staging browser walk 1, D9). The Xero row offered only
// Reconnect; the one way to read a Xero client's bank accounts and ledger was the "⋯"
// beside Month-end's title. It is the same press (startSync) and the same answer
// (SyncOutcome) as Month-end's, drawn under the row.
function LedgerSyncAction({ row, sync, disabledReason }) {
  return (
    <Button
      variant="secondary"
      size="sm"
      onClick={sync.press}
      busy={sync.state === "busy"}
      busyLabel="Syncing…"
      disabledReason={disabledReason}
      aria-label={`Sync ${row.name} now`}
      data-ledger-sync={row.id}
    >
      Sync now
    </Button>
  );
}

function SyncAction({ sync }) {
  return (
    <Button
      variant="secondary"
      size="sm"
      onClick={sync.press}
      busy={sync.busy}
      busyLabel="Syncing…"
      disabledReason={sync.enabled ? null : "Sample books"}
      aria-label="Sync Stripe now"
    >
      Sync now
    </Button>
  );
}

/**
 * The view's one filled action: "connect", "import", or null (nothing to write).
 *
 * TRY AGAIN IS NOT A COMMIT (design-pass spec §3.2, §6.1; audit §13). The accent means
 * "this writes", and re-reading what is connected writes nothing, so after a failed
 * read the view has no filled button: Try again is secondary. It was the filled one
 * under the old one-filled-button rubric (S5), which counted fills rather than writes.
 */
//
// ONE STYLE ON EVERY ROW (design-fix-2 DA2-040). Each row's action is a secondary button,
// whatever it is: a settings list is a list of equals, and a filled Connect on one row
// read as "this one first" when the order is the person's to choose. So this page has no
// filled button; `connectionsPrimary` still names the action the verdict line points at.
export function connectionsPrimary({ failed, writable, noService, hasToConnect }) {
  if (noService) return null;
  if (failed) return null;
  if (!writable) return null;
  return hasToConnect ? "connect" : "import";
}

export default function ConnectionsList({ connections, bank = null, canWrite = true, disabledReason = null, openSheet = null, importAccount = null }) {
  const answer = connections || { ok: false, connections: [], message: null };
  const rows = providerRows(answer.connections, { measured: answer.ok === true });
  const noService = !answer.ok && answer.kind === "unavailable";
  const writable = canWrite && !noService;
  const whyNot = writable ? null : noService ? SAMPLE_BOOKS_LINE : disabledReason;

  const [sheet, setSheet] = useState(openSheet);
  const [opened, setOpened] = useState(() => new Set(openSheet ? [openSheet] : []));
  function open(id) {
    setOpened((was) => new Set(was).add(id));
    setSheet(id);
  }

  const sync = useSync();
  const ledgerSync = useSyncPress();
  const router = useRouter();
  // The OTHER ledger already connected, when `row` is a ledger that is not: connecting it
  // would make the two-ledger state the product refuses. Null otherwise.
  const secondLedgerFor = (row) => (row.ledger && !row.connected ? heldLedgers.find((held) => held.id !== row.id) || null : null);
  const failed = !answer.ok && !noService;
  const byId = Object.fromEntries(rows.map((row) => [row.id, row]));
  // The connected ledger, or null. With two connected (refused, and said so) the first in
  // catalogue order stands in for "a ledger is connected" — the bank row lists what the
  // service can read, and the notice above says which state this is.
  const heldLedgers = connectedLedgers(rows);
  const ledger = heldLedgers[0] || null;
  const conflict = answer.ok === true ? ledgerConflictLine(rows) : null;
  const bankState = bank ? readBankAccount(bank) : null;

  // ON THE SAMPLE BOOKS THERE IS NO ACTION TO OFFER. The verdict says so once; a row
  // of dead Connect buttons each repeating it would be three copies of one sentence
  // and three controls that look like they work (spec §1.9).
  //
  // EVERY OTHER ROW HAS ONE WAY FORWARD (design-fix-2 DA2-040, critic round 1: with the
  // read failed, Stripe, QuickBooks and Shopify had no action and the page read as a
  // status list). Which one is decided by the row's facts, never by a vendor's id:
  //   not available yet   Details    the reason, and what to use meanwhile
  //   not checked         Manage     what Vert couldn't check, and Check again
  //   connected (key)     Sync now
  //   connected (oauth)   Reconnect  sign in again, the same round trip as Connect
  //   connected ledger    Sync now and Reconnect (staging browser walk 1, D9)
  //   not connected       Connect
  function actionFor(row) {
    if (noService) return null;
    const secondary = (label, id, extra = {}) => (
      <Button variant="secondary" size="sm" onClick={() => open(id)} {...extra}>
        {label}
      </Button>
    );
    if (row.connect === "unavailable") return secondary("Details", `details-${row.id}`, { "aria-label": `${row.name} details` });
    if (!row.measured) return secondary("Manage", `manage-${row.id}`, { "aria-label": `Manage ${row.name}` });
    if (row.connected) {
      if (row.connect === "key") return <SyncAction sync={sync} />;
      if (row.connect === "oauth" && row.ledger) {
        return (
          <span className="conn-actions">
            <LedgerSyncAction row={row} sync={ledgerSync} disabledReason={writable ? null : whyNot} />
            {secondary("Reconnect", row.id, { disabledReason: writable ? null : whyNot })}
          </span>
        );
      }
      if (row.connect === "oauth") return secondary("Reconnect", row.id, { disabledReason: writable ? null : whyNot });
      return null;
    }
    // ONE LEDGER AT A TIME, SAID ON THE BUTTON (verify pass 5, X-h): with Xero connected,
    // QuickBooks offered an active Connect that led to a sheet saying it couldn't.
    return secondary("Connect", row.id, { disabledReason: writable ? secondLedgerReason(row, heldLedgers) : whyNot });
  }

  // THE POSTING CHOICE, ON THE CONNECTED ROW (verify pass 5, X-h). It lived only inside the
  // Reconnect sheet; now the row says what is set, with Change opening the setting alone.
  function detailFor(row) {
    if (noService || !row.measured) return null;
    const line = postModeLine(row);
    // WHERE THE PAYOUTS LAND (Stripe test run 1 Nov 2026, S-3), on the processor's row.
    const payout = payoutAccountLine(row, bankState);
    // The connected ledger's Sync now answers under its own row.
    const synced = row.connected && row.ledger && row.connect === "oauth" && ledgerSync.state !== "idle" && ledgerSync.state !== "busy" ? <SyncPressResult sync={ledgerSync} className="conn-sync-outcome" /> : null;
    if (!line && !synced && !payout) return null;
    return (
      <>
        {payout ? (
          <p className="conn-mode-line" data-payout-account-line={row.bankAccountId || ""}>
            <span className="conn-mode-now">{payout}</span>
            <Button variant="quiet" size="sm" onClick={() => open(`payout-${row.id}`)} disabledReason={writable ? null : whyNot} aria-label={`Choose where ${row.name} payouts land`}>
              {row.bankAccountId ? "Change" : "Pick"}
            </Button>
          </p>
        ) : null}
        {line ? (
          <p className="conn-mode-line" data-post-mode-line={row.postMode || ""}>
            <span className="conn-mode-now">{line}</span>
            <Button variant="quiet" size="sm" onClick={() => open(`mode-${row.id}`)} aria-label={`Change what happens to approved entries in ${row.name}`}>
              Change
            </Button>
          </p>
        ) : null}
        {synced}
      </>
    );
  }

  return (
    <div className="conn" data-ui="ConnectionsList">
      {failed ? (
        // One line: the cause, what did not happen, Try again; the service's words under
        // Details (DA2-040). Re-runs the server read, which is where the rows come from.
        <div className="conn-notice" role="alert" data-tone="problem">
          <IconProblem className="conn-notice-icon" />
          <p className="conn-verdict conn-notice-text">{connectionsVerdict(answer, rows)}</p>
          <div className="conn-retry">
            <Button variant="quiet" size="sm" onClick={() => router.refresh()}>
              Try again
            </Button>
          </div>
          {/* Under the sentence, not beside Try again: an open (or merely measured)
              Details widened the action column and wrapped the sentence. */}
          <Disclosure summary="Details" className="conn-details">
            <p className="conn-note">{connectionsFailureDetail(answer)}</p>
          </Disclosure>
        </div>
      ) : conflict ? (
        // ONLY ONE LEDGER (16 Oct 2026). A notice and not the plain verdict line: it is a
        // state the product refuses, and the way out is on the rows below (each ledger's
        // own Disconnect), so the notice carries no action of its own.
        <div className="conn-notice" role="alert" data-tone="problem" data-ledger-conflict="">
          <IconProblem className="conn-notice-icon" />
          <p className="conn-verdict conn-notice-text">{conflict}</p>
        </div>
      ) : (
        <p className="conn-verdict t-callout">{connectionsVerdict(answer, rows)}</p>
      )}

      <div className="conn-list">
        {rows.map((row) => (
          <ProviderCard key={row.id} row={row} canWrite={writable} disabledReason={whyNot} action={actionFor(row)} detail={detailFor(row)} whyInSheet={!noService && row.connect === "unavailable"} source={row.id} />
        ))}

        {ledger ? (
          <section className="conn-row" aria-labelledby="provider-bank-account" data-provider="bank-account">
            <SourceLogo source="bank" tile className="conn-glyph" />
            <div className="conn-main">
              <h2 id="provider-bank-account" className="conn-name">Bank account</h2>
              <p className="conn-state">{bankAccountWords(bankState)}</p>
            </div>
            <div className="conn-action">
              <Button variant="secondary" size="sm" onClick={() => open("bank-account")} disabledReason={writable ? null : whyNot}>
                {bankState && bankState.chosen ? "Change" : "Choose"}
              </Button>
            </div>
          </section>
        ) : null}

        <section className="conn-row" aria-labelledby="provider-bank-statement" data-provider="bank-statement">
          <SourceLogo source="csv" tile className="conn-glyph" />
          <div className="conn-main">
            <h2 id="provider-bank-statement" className="conn-name">Bank statement</h2>
            <p className="conn-state">Import a CSV when there&rsquo;s no bank feed</p>
          </div>
          {noService ? null : (
            <div className="conn-action">
              <Button variant="secondary" size="sm" onClick={() => open("bank-statement")} disabledReason={writable ? null : whyNot}>
                Import
              </Button>
            </div>
          )}
        </section>

        {/* POS AND INVENTORY (w48, audit row 4.3): no connector reads them yet, so the
            row says so and asks the one question. There is no place for connection
            notes to keep an answer in, so nothing is asked for here (no field). Drawn
            on an answered read only: under "Couldn't check what's connected" no row says
            "Not connected" (tests/connection-states.test.js). */}
        {failed ? null : (
          <section className="conn-row" aria-labelledby="provider-pos-inventory" data-provider="pos-inventory">
            <SourceLogo source="other" tile className="conn-glyph" />
            <div className="conn-main">
              <h2 id="provider-pos-inventory" className="conn-name">
                {POS_ROW.name}
              </h2>
              <p className="conn-state">{POS_ROW.state}</p>
              <p className="conn-note">{POS_ROW.question}</p>
            </div>
          </section>
        )}
      </div>

      {byId.stripe && byId.stripe.connected ? <SyncFreshness register={sync.register} /> : null}
      <SyncReport run={sync.run} refusal={sync.refusal} onRetry={sync.press} asked={sync.asked} pending={sync.pending} />

      {/* EVERY SHEET HERE IS PORTALLED INTO <body> (components/ui/Portal.js, DA2-001): this
          list is drawn inside a `.skel-in` section (app/connections/page.js), a stacking
          context the phone top bar sits above, so in place a sheet's head was under the
          bar at 390 px (live check, 29 Oct 2026). */}
      {/* Only while Stripe is NOT connected: a second paste over a live connection is
          a way to silently change which account the payouts are read from. */}
      {opened.has("stripe") && byId.stripe && !byId.stripe.connected ? (
        <Portal>
          <Sheet open={sheet === "stripe"} onClose={() => setSheet(null)} side="right" title="Connect Stripe">
            <StripeConnectForm canWrite={writable} disabledReason={whyNot} />
          </Sheet>
        </Portal>
      ) : null}
      {rows
        .filter((row) => row.connect === "oauth" && row.measured && opened.has(row.id))
        .map((row) => (
          <Portal key={row.id}>
            <Sheet open={sheet === row.id} onClose={() => setSheet(null)} side="right" title={`${row.connected ? "Reconnect" : "Connect"} ${row.name}`}>
              <p className="conn-note">{row.what}</p>
              {/* WHAT SENDING A JOURNAL HERE DOES, before anybody connects it: the vendor's
                  own fact from the catalogue (Xero holds a draft; QuickBooks has none). */}
              {row.posting ? <p className="conn-note" data-ledger-posting="">{row.posting}</p> : null}
              {/* WHAT HAPPENS ONCE AN ENTRY IS APPROVED (17 Oct 2026): posted, or sent as a
                  draft, per client — only on a connected ledger whose catalogue entry offers
                  the choice, so QuickBooks (no draft step) is never asked. */}
              {row.connected && row.postModes ? (
                <PostModeSetting row={row} canWrite={writable} disabledReason={whyNot} />
              ) : null}
              {/* HOW AN APPROVED BILL, INVOICE OR CREDIT NOTE ARRIVES (4 Nov 2026): a draft,
                  or approved, awaiting payment — only where the catalogue offers it. */}
              {row.connected && row.documentModes ? (
                <DocumentModeSetting row={row} canWrite={writable} disabledReason={whyNot} />
              ) : null}
              {secondLedgerFor(row) ? (
                // ONE LEDGER AT A TIME. With another ledger already connected, this sheet
                // does not offer to make the refused state; it names the way out instead.
                <p className="conn-note" role="note" data-ledger-second="">
                  {`${secondLedgerFor(row).name} is already connected. Vert works with one ledger at a time, so disconnect ${secondLedgerFor(row).name} before connecting ${row.name}.`}
                </p>
              ) : (
                <>
                  <p className="conn-note">
                    {row.connected
                      ? `You’ll sign in to ${row.name} again to renew Vert’s access, and come straight back here. Nothing already read changes.`
                      : `You’ll sign in to ${row.name} to allow it, and come straight back here.`}
                  </p>
                  {row.consentHint ? <p className="conn-note">{row.consentHint}</p> : null}
                  <ConnectProviderButton provider={row.id} name={row.name} canWrite={writable} disabledReason={whyNot} />
                </>
              )}
            </Sheet>
          </Portal>
        ))}
      {/* THE POSTING CHOICE ON ITS OWN (verify pass 5, X-h), opened from the row's Change. */}
      {rows
        .filter((row) => row.connected && (row.postModes || row.documentModes) && row.measured && opened.has(`mode-${row.id}`))
        .map((row) => (
          <Portal key={`mode-${row.id}`}>
            <Sheet open={sheet === `mode-${row.id}`} onClose={() => setSheet(null)} side="right" title={`Approved entries in ${row.name}`}>
              {row.posting ? <p className="conn-note" data-ledger-posting="">{row.posting}</p> : null}
              {row.postModes ? <PostModeSetting row={row} canWrite={writable} disabledReason={whyNot} /> : null}
              {row.documentModes ? <DocumentModeSetting row={row} canWrite={writable} disabledReason={whyNot} /> : null}
            </Sheet>
          </Portal>
        ))}
      {/* "PAYOUTS LAND IN" (S-3), opened from the processor row's Pick / Change. */}
      {rows
        .filter((row) => row.payouts && row.connected && row.measured && opened.has(`payout-${row.id}`))
        .map((row) => (
          <Portal key={`payout-${row.id}`}>
            <Sheet open={sheet === `payout-${row.id}`} onClose={() => setSheet(null)} side="right" title="Payouts land in">
              <PayoutAccountSetting row={row} bankState={bankState} canWrite={writable} disabledReason={whyNot} />
            </Sheet>
          </Portal>
        ))}
      {/* NOT CHECKED: what this row would read, why it says "Not checked", and the one
          thing to do. No connect form here: over a connection that may already be live,
          a second key could silently change which account the payouts come from. */}
      {rows
        .filter((row) => !row.measured && row.connect !== "unavailable" && opened.has(`manage-${row.id}`))
        .map((row) => (
          <Portal key={`manage-${row.id}`}>
            <Sheet open={sheet === `manage-${row.id}`} onClose={() => setSheet(null)} side="right" title={row.name}>
              <p className="conn-note">{row.what}</p>
              <p className="conn-note">
                Vert couldn&rsquo;t check {row.name}: {failureCause(answer)}. Once it can, this row says
                whether {row.name} is connected and offers what fits.
              </p>
              <div className="conn-sheet-actions">
                <Button variant="secondary" size="sm" onClick={() => { setSheet(null); router.refresh(); }}>
                  Check again
                </Button>
              </div>
            </Sheet>
          </Portal>
        ))}
      {/* NOT AVAILABLE YET: the catalogue's reason, and what covers the gap meanwhile. */}
      {rows
        .filter((row) => row.connect === "unavailable" && opened.has(`details-${row.id}`))
        .map((row) => (
          <Portal key={`details-${row.id}`}>
            <Sheet open={sheet === `details-${row.id}`} onClose={() => setSheet(null)} side="right" title={row.name}>
              <p className="conn-note">{row.what}</p>
              {row.why ? <p className="conn-note" role="note">{row.why}</p> : null}
              <p className="conn-note">Meanwhile, payouts that reach your bank are covered by a bank statement import.</p>
              <div className="conn-sheet-actions">
                <Button variant="secondary" size="sm" onClick={() => open("bank-statement")} disabledReason={writable ? null : whyNot}>
                  Import a statement
                </Button>
              </div>
            </Sheet>
          </Portal>
        ))}
      {opened.has("bank-account") ? (
        <Portal>
          <Sheet open={sheet === "bank-account"} onClose={() => setSheet(null)} side="right" title="Bank account">
            <BankAccountPanel />
          </Sheet>
        </Portal>
      ) : null}
      {opened.has("bank-statement") ? (
        <Portal>
          <Sheet open={sheet === "bank-statement"} onClose={() => setSheet(null)} side="right" title="Import a bank statement">
            <BankStatementImport canWrite={writable} disabledReason={whyNot} account={importAccount} />
          </Sheet>
        </Portal>
      ) : null}
    </div>
  );
}
