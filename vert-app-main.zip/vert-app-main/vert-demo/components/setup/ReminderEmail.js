"use client";

// components/setup/ReminderEmail.js — "EMAIL FOR REMINDERS", ONE ROW ON /connections
// ==============================================================================
// W3 feature 1 (28 Oct 2026). Payment reminders go out by email, so this client's email
// is something Vert connects to, beside the ledger and the bank: one row in the same
// style as the rows above it (components/setup/ConnectionsList.js), its state in words,
// one action, and a sheet for the work.
//
//   Email for reminders   Sending from accounts@client.example through Gmail   Change
//
// THE SHEET offers the two ways the engine sends (lib/reminder-email.js backendChoices):
// Vert's own address (Resend), where the client's address takes the replies, offered
// only where this server has one and otherwise shown disabled with why; or the client's
// own Gmail, signed in with an app password. Save is `PUT /reminders/email` (the engine
// checks a Gmail login before it stores anything and says why when it refuses);
// Disconnect is `DELETE`, behind a confirmation; "Send test email to myself" is
// `POST /reminders/email/test`, and its result is the engine's words.
//
// THE APP PASSWORD is a `type="password"` field with autocomplete off. It starts empty
// whatever is stored (the engine never returns it), goes to the engine in the PUT's body
// through app/api/reminders/email, and is cleared from the field once saved. Nothing in
// this file logs. The settings and the sent list are read on the server
// (app/connections/page.js), so a view of this page asks nothing from the browser. The
// test email takes no address (contract v2): it goes to the connected sender only, and a
// rate-limit refusal (429) is shown in the engine's words.

import { useRouter } from "next/navigation";
import { useState } from "react";

import { Button, Field, Portal, Sheet, SourceLogo } from "@/components/ui";
import { disconnectReminderEmail, saveReminderEmail, sendTestReminderEmail } from "@/lib/reminders-client";
import { backendChoices, clientAddressOf, emailFormRequest, emailRowWords, looksLikeEmail } from "@/lib/reminder-email";
import SentReminders from "@/components/chat/answer/SentReminders";

import "./connections.css";

const SAMPLE_LINE = "Not available on the sample books";

export default function ReminderEmail({ answer, sent = null, canWrite = true }) {
  const router = useRouter();
  const noService = Boolean(answer && !answer.ok && answer.kind === "unavailable");
  const failed = !noService && !(answer && answer.ok);
  const [settings, setSettings] = useState(() => (answer && answer.ok ? answer.settings : null));
  const [open, setOpen] = useState(false);
  const [opened, setOpened] = useState(false);
  const state = noService ? SAMPLE_LINE : failed ? "Not checked" : emailRowWords(settings);
  const show = () => {
    setOpened(true);
    setOpen(true);
  };
  return (
    <div className="conn conn-reminders" data-ui="ReminderEmail">
      <div className="conn-list">
      <section className="conn-row" aria-labelledby="provider-reminder-email" data-provider="reminder-email" data-connected={settings && settings.connected ? "" : undefined}>
        <SourceLogo source="email" tile className="conn-glyph" />
        <div className="conn-main">
          <h2 id="provider-reminder-email" className="conn-name">
            Email for reminders
          </h2>
          <p className="conn-state">{state}</p>
          {failed && answer && answer.message ? <p className="conn-note">{answer.message}</p> : null}
        </div>
        {noService ? null : (
          <div className="conn-action">
            {failed ? (
              <Button variant="secondary" size="sm" onClick={() => router.refresh()}>
                Check again
              </Button>
            ) : (
              <Button variant="secondary" size="sm" onClick={show} aria-label={settings && settings.connected ? "Change email for reminders" : "Connect email for reminders"}>
                {settings && settings.connected ? "Change" : "Connect"}
              </Button>
            )}
          </div>
        )}
      </section>
      </div>
      {opened && settings ? (
        // Into <body> (components/ui/Portal.js, DA2-001): drawn in place, inside the
        // section's `.skel-in` stacking context, the sheet's head sat under the phone
        // top bar at 390 px and couldn't be closed (live check, 29 Oct 2026).
        <Portal>
        <Sheet open={open} onClose={() => setOpen(false)} side="right" title="Email for reminders">
          <EmailForm
            settings={settings}
            canWrite={canWrite}
            onChange={(next) => {
              setSettings(next);
              router.refresh();
            }}
          />
          {/* What was sent (contract v2): read on the server with the settings; the list
              every "check Sent reminders" sentence points at. */}
          {sent ? <SentReminders sends={sent.ok ? { sends: sent.sends } : null} words={sent.ok ? null : sent.message} id="sent-reminders-settings" /> : null}
        </Sheet>
        </Portal>
      ) : null}
    </div>
  );
}

/** The sheet's body: what is set now, the test email, Disconnect, and the form. */
export function EmailForm({ settings, canWrite = true, initial = null, onChange = null }) {
  const start = initial && typeof initial === "object" ? initial : {};
  const choices = backendChoices(settings);
  const firstChoice = choices.find((c) => !c.disabled) || choices[choices.length - 1];
  const [backend, setBackend] = useState(() => start.backend || (settings && settings.backend) || firstChoice.value);
  const [address, setAddress] = useState(() => clientAddressOf(settings) || "");
  const [appPassword, setAppPassword] = useState("");
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState(() => start.error || null);
  const [saved, setSaved] = useState(null);
  const [test, setTest] = useState(() => start.test || null);
  const [confirmDisconnect, setConfirmDisconnect] = useState(() => Boolean(start.confirmDisconnect));
  const connected = Boolean(settings && settings.connected);
  const chosen = choices.find((c) => c.value === backend) || firstChoice;
  const whyNot = !canWrite
    ? "Your role can't change this client's connections."
    : busy
      ? "Wait for Vert to answer."
      : chosen.disabled
        ? chosen.why
        : !looksLikeEmail(address)
          ? "Enter the client's email address first."
          : backend === "smtp" && !appPassword.trim()
            ? "Enter the Gmail app password first."
            : null;

  const done = (got, words) => {
    if (got.ok && got.body && got.body.settings) {
      setSaved(words);
      if (typeof onChange === "function") onChange(got.body.settings);
      return true;
    }
    setError(got.ok ? "Vert's answer about email couldn't be read." : got.message);
    return false;
  };

  const save = async (event) => {
    event.preventDefault();
    if (whyNot) return;
    setBusy("save");
    setError(null);
    setSaved(null);
    const got = await saveReminderEmail(emailFormRequest({ backend, address, appPassword }));
    setBusy(null);
    if (done(got, "Saved. Reminders will go out this way.")) setAppPassword("");
  };

  const disconnect = async () => {
    setBusy("disconnect");
    setError(null);
    setSaved(null);
    const got = await disconnectReminderEmail();
    setBusy(null);
    setConfirmDisconnect(false);
    done(got, "Disconnected. No reminder can be sent until email is connected again.");
  };

  const sendTest = async () => {
    setBusy("test");
    setError(null);
    setTest(null);
    const got = await sendTestReminderEmail();
    setBusy(null);
    if (got.ok && got.body && got.body.test) setTest(got.body.test);
    else setError(got.ok ? "Vert didn't say whether the test email went." : got.message);
  };

  return (
    <div className="conn-form reminder-email-form" data-reminder-email-form="">
      {connected ? (
        <div className="reminder-email-now">
          <p className="conn-note">
            {emailRowWords(settings)}
            {settings.updatedBy ? `. Set up by ${settings.updatedBy}.` : "."}
          </p>
          <div className="conn-sheet-actions">
            <Button variant="secondary" size="sm" busy={busy === "test"} busyLabel="Sending…" disabledReason={canWrite ? (busy && busy !== "test" ? "Wait for Vert to answer." : undefined) : "Your role can't send a test email."} onClick={sendTest}>
              Send test email to myself
            </Button>
            {confirmDisconnect ? null : (
              <Button variant="quiet" size="sm" destructive disabledReason={canWrite ? undefined : "Your role can't change this client's connections."} onClick={() => setConfirmDisconnect(true)}>
                Disconnect
              </Button>
            )}
          </div>
          {test ? (
            <p className="conn-note" role="status" data-test-status={test.status}>
              {test.words || (test.status === "sent" ? `Sent a test email${test.to ? ` to ${test.to}` : ""}.` : test.status === "unknown" ? "The test email may have been sent: the mail server didn't confirm it." : "The test email wasn't sent.")}
            </p>
          ) : null}
          {confirmDisconnect ? (
            <div className="reminder-email-confirm" role="group" aria-label="Disconnect email for reminders?">
              <p className="conn-note">Disconnect? Payment reminders can&rsquo;t be sent until email is connected again.</p>
              <div className="conn-sheet-actions">
                <Button variant="quiet" size="sm" destructive busy={busy === "disconnect"} busyLabel="Disconnecting…" onClick={disconnect}>
                  Disconnect
                </Button>
                <Button variant="quiet" size="sm" onClick={() => setConfirmDisconnect(false)}>
                  Cancel
                </Button>
              </div>
            </div>
          ) : null}
        </div>
      ) : null}

      <form className="reminder-email-fields" onSubmit={save} aria-label={connected ? "Change how reminders are sent" : "Connect email for reminders"}>
        <fieldset className="reminder-email-choices">
          <legend className="field-label">Send reminders from</legend>
          {choices.map((c) => (
            <label key={c.value} className="reminder-email-choice" data-disabled={c.disabled ? "" : undefined}>
              <input type="radio" name="reminder-backend" value={c.value} checked={backend === c.value} disabled={c.disabled} onChange={() => setBackend(c.value)} />
              <span className="reminder-email-choice-text">
                <span className="reminder-email-choice-label">{c.label}</span>
                <span className="conn-note">{c.disabled ? c.why : c.help}</span>
              </span>
            </label>
          ))}
        </fieldset>
        <Field
          label={backend === "smtp" ? "Gmail address" : "Your email address, for replies"}
          type="email"
          value={address}
          autoComplete="off"
          spellCheck={false}
          onChange={(e) => setAddress(e.target.value)}
        />
        {backend === "smtp" ? (
          <Field
            label="Gmail app password"
            hint="Vert checks it with Gmail before saving it, and never shows it again."
            type="password"
            value={appPassword}
            autoComplete="off"
            spellCheck={false}
            onChange={(e) => setAppPassword(e.target.value)}
          />
        ) : null}
        <div className="conn-sheet-actions">
          <Button type="submit" variant="commit" busy={busy === "save"} busyLabel={backend === "smtp" ? "Checking with Gmail…" : "Saving…"} disabledReason={whyNot || undefined}>
            {connected ? "Save" : "Connect email"}
          </Button>
        </div>
      </form>
      {saved ? (
        <p className="conn-note" role="status">
          {saved}
        </p>
      ) : null}
      {error ? (
        <p className="conn-note reminder-email-error" role="alert">
          {error}
        </p>
      ) : null}
    </div>
  );
}
