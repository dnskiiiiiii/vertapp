// components/setup/connections-link.js — WHAT A LINK INTO /connections ASKS TO OPEN
/**
 * The sheet a link asks to open on arrival (verify pass 2 D34): a card's "Import the
 * statement" lands on `/connections?import=statement&period=…`, and the importer opens
 * with it instead of waiting for a second press on Import. Nothing else opens by link.
 */
export function sheetAsked(query) {
  const value = query && typeof query === "object" ? query.import : null;
  return (Array.isArray(value) ? value[0] : value) === "statement" ? "bank-statement" : null;
}

/**
 * The account a statement link names (`&account=091`), so the importer opens on it
 * (production walk, 6 Nov 2026, D4): "091 · Business Savings Account — No statement
 * imported. Import" opened the form at "Choose the account…". Shape only (a number or
 * a chart id); the form picks it only if the chart lists it. Null otherwise.
 */
export function accountAsked(query) {
  if (sheetAsked(query) !== "bank-statement") return null;
  const value = query && typeof query === "object" ? query.account : null;
  const one = Array.isArray(value) ? value[0] : value;
  return typeof one === "string" && /^[A-Za-z0-9][A-Za-z0-9 _.:-]{0,63}$/.test(one.trim()) ? one.trim() : null;
}

/** The id of the statement account `asked` names (its number, else its id), or "". Pure. */
export function accountIdFor(accounts, asked) {
  if (!asked || !Array.isArray(accounts)) return "";
  const hit = accounts.find((a) => a && a.number === asked) || accounts.find((a) => a && a.id === asked);
  return hit ? hit.id : "";
}
