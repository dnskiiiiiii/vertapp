// components/setup/steps.js — THE THREE THINGS THAT HAVE TO BE TRUE, AND WHO SAYS SO
// ==============================================================================
// WHY THIS EXISTS. Everything a tenant needed before Vert could do any work at all was
// on one 1800px settings scroll, in no order, with nothing anywhere pointing a new
// customer at it: connections, six free-text account boxes, a two-step CSV upload and a
// duplicate section. The founder's words on 2026-08-17, after trying it as a customer
// would: "it is asking me to fill in everything. it is too much work for a real
// client", and "a non technical client wouldnt be doing all this would they".
//
// So the same three writes are drawn as three ordered steps, and this module is the
// only thing that decides which of them is done. The design (spec §6) is deliberately
// small: no new server behaviour, no new state anywhere. Whether a step is done is
// READ BACK FROM THE SERVICE that would have to answer for it either way —
// `GET /connections` for the two connections — so there is no "setup progress" record
// to fall out of step with the deployment. A tenant wired up from a terminal last month
// arrives here already finished.
//
// STEP 3 IS NOT ONE OF THEM, AND THIS PAGE USED TO PRETEND IT WAS.
// ------------------------------------------------------------------
// The account mapping was read from `GET /ledger/map` and written with `PUT
// /ledger/map`. NEITHER ROUTE EXISTS. They are in no version of the engine's OpenAPI
// and in none of its source; the mapping is loaded per tenant by an operator running
// `python -m vert_connect.ledger_map --tenant <tenant> --file <chart>.json`, and a
// per-tenant chart-mapping CRUD surface is a feature that needs designing (who may
// write a mapping, what a mid-close change does to entries already staged) rather than
// a route to invent from this side.
//
// So this page offered a control that 404s, under a heading that promised a list of the
// customer's own accounts, and read a progress line — "0 of 3 required" — off an answer
// nothing could ever give. The 404 was handled honestly; the promise above it was not.
//
// Step 3 is now what it has always actually been: an operator step. It states what has
// to happen and who does it, it claims nothing about whether it has been done, and it
// GATES NOTHING — a step whose state cannot be read must not be able to lock the step
// after it, or a tenant who has a mapping loaded is held behind a question this screen
// cannot ask.
//
// IT IS PURE, and it imports only lib/connections-shape.js, which is pure itself. That
// is what lets the same function decide two different questions in two different
// places without either of them re-deriving it: the screen (which step to open) and
// app/page.js (whether to send a tenant here at all).
//
// "DECIDED" IS THE FIELD THAT KEEPS THE REDIRECT HONEST.
// ------------------------------------------------------------------
// A read that FAILED is not a tenant that has connected nothing — the rule
// lib/connections.js is built around and the one that makes ConnectionsScreen say "this
// screen could not ask" instead of drawing three "Not connected" rows. The redirect
// inherits it: `needsSetup` is false whenever the answer is not known, so a socket
// timeout can never bounce a working tenant out of their register and into an
// onboarding flow they finished weeks ago. Undecided means stay where you are.
//
// The mapping read is only consulted once BOTH connections are up, because
// `GET /ledger/map` has nothing to answer about a tenant with no ledger attached —
// requiring it before then would make the most important case, a brand-new tenant with
// nothing connected, the one case that never redirects.
//
// A FOURTH READ, AND IT DECIDES NOTHING. `GET /sync/status` says how much is already
// in this tenant's register. Every gate above is unchanged by it and `needsSetup`
// returns the same answer with it or without it — it is here because deciding four
// steps correctly was not enough to stop the page being wrong. A tenant with no live
// connection and a register full of history read every gate correctly and still
// described somebody who had never used the product. "Nothing is connected" and
// "nothing has happened" are different claims, and only this read can separate them.

import { accountLine, connectedLedgers, ingestedLine, ledgerChoiceWords, ledgerRows, providerRows, stateLine } from "@/lib/connections-shape";

// Where a tenant that is not wired up yet is sent, and where /connections links back
// to. It lives HERE and not in components/shell/ia.js on purpose: ia.js is the list of
// rail AREAS, and setup is not one. It is an errand with an end, and a rail item that
// vanishes when it is finished reads as a broken rail while it is there.
// WHERE FIRST-RUN SETUP IS DONE: Connections. The ordered /setup errand is gone — it
// said the Stripe instructions a second time and disagreed with /connections about
// what came next (UI-061) — and /setup redirects here (next.config.mjs). Month-end's
// first run renders the same rows (components/setup/ConnectionsList.js).
export const SETUP_HREF = "/connections";

/**
 * The three steps, in order, each with everything the screen needs to draw it.
 *
 * `done` is what the service says. `open` is the one step a person may act on now, and
 * `locked` is a step whose inputs do not exist yet — step 3 offers a list of THEIR
 * accounts, and there is no list until step 2 has happened. Gating is derived by
 * walking the list once rather than stored, so a step cannot be open and unsatisfied
 * at the same time.
 *
 * STEP 3 IS IN THE LIST AND IN NO GATE. `operator: true` marks a step whose state no
 * route can report; it is drawn, it says who does it, and the loop below steps over it
 * so it can neither be "open" nor lock step 4. See the header for what it used to read.
 */
/**
 * `GET /bank-accounts`'s outcome, reduced to what step 4 needs.
 *
 * Three-state, like every read on this page: chosen, not chosen, or could-not-ask.
 * The third is why this exists rather than a bare truthiness test — a listing that
 * failed is not a tenant who has not picked yet, and telling them to pick from a list
 * that will not load is the dead end this step was added to stop.
 */
export function readBankAccount(result) {
  const answer = result && typeof result === "object" ? result : { ok: false };
  return {
    ok: answer.ok === true,
    chosen: typeof answer.chosen === "string" && answer.chosen ? answer.chosen : null,
    accounts: Array.isArray(answer.accounts) ? answer.accounts : [],
    message: answer.refused || answer.message || null,
  };
}

/**
 * `GET /sync/status`'s outcome, reduced to the one sentence the steps need.
 *
 * THE READ THAT WAS MISSING, AND THE BUG THAT PROVED IT. Everything above decides
 * whether a step is DONE from the service that would answer for it. Nothing decided
 * whether the tenant was NEW — that was inferred, silently, from an empty connections
 * list, and the two are not the same question. demo-retail has one revoked QuickBooks
 * row, no Stripe row, and 43 settlements with 43 draft entries and 43 exceptions
 * standing behind them; it opened this page and was told "Step 1 of 4 · Connect
 * Stripe · Do this now", which is the screen for somebody who has never used the
 * product.
 *
 * This is descriptive and NOT a gate. It moves no step, it is deliberately absent from
 * `decided` and from `complete`, and `needsSetup` reads the same state with or without
 * it — a register that could not be read must never change where a person lands, which
 * is the rule the whole header is about. All it does is let the screen say what is
 * already in the books beside the steps that are not done, so a true "Not connected"
 * cannot be read as a false "you have nothing here".
 */
export function readRegister(result) {
  const answer = result && typeof result === "object" ? result : { ok: false };
  return {
    ok: answer.ok === true,
    payouts: typeof answer.payouts === "number" ? answer.payouts : 0,
    bySource: answer.bySource && typeof answer.bySource === "object" ? answer.bySource : {},
    lastUpdatedAt: typeof answer.lastUpdatedAt === "string" ? answer.lastUpdatedAt : null,
  };
}

// THE FOURTH STEP, ADDED 2026-08-20, AND WHY THERE ARE NOW FOUR.
//
// This page told a bookkeeper "This tenant is set up. Stripe and QuickBooks are
// connected and every required account is mapped, so nothing on this page is waiting
// on you" — while every payout on that tenant sat blocked, on a step this page did not
// know existed. The bank tie is the fourth thing that has to be true before a payout
// can be reconciled and posted, and leaving it off did not make setup shorter; it made
// the completion notice false.
//
// It is read back from the service exactly like the other three, so there is still no
// progress record to fall out of step with the deployment.
export function setupState({ connections, bank, register }) {
  const answer = connections && typeof connections === "object" ? connections : { ok: false, connections: [] };
  // Rows are built from the API's list ONLY when the list is an answer. On a failed
  // read `providerRows([])` would say "not connected" about every provider, which is
  // the claim this whole module refuses to make.
  const rows = providerRows(answer.ok === true ? answer.connections : [], {
    measured: answer.ok === true,
  });
  // ══════════════════════════════════════════════════════════════════════════
  // WHETHER THERE IS ANYTHING ON THE OTHER END TO CONNECT TO.
  //
  // FOUND 2026-08-26, by sweeping for the shape round 19 found on /connections. The
  // very same defect was still live here, one screen earlier and worse. `StepControl`
  // rendered `<StripeConnectForm />` bare — the component defaults `canWrite` to true
  // — so on a build with no service behind it, step 1 badged itself "Do this now" and
  // put a required `rk_live_…` field and a live "Connect Stripe" button in front of
  // the reader. /connections at least printed "there is nothing to connect" above its
  // form; this page said nothing at all, and it is the page a brand-new tenant is sent
  // to first. Pasting a real restricted key into it spent the credential on a request
  // `lib/connections.js` refuses before the wire.
  //
  // DERIVED FROM THE READ, NOT FROM THE MODE, exactly as ConnectionsScreen derives it:
  // `kind === "unavailable"` is `readConnections`'s own word for "there is no Vert
  // service behind this build". Nothing here asks which data source is running, which
  // this module is forbidden to do (tests/no-arithmetic.test.js).
  //
  // A FAILED READ IS DELIBERATELY NOT THIS, for the reason ConnectionsScreen gives: a
  // timeout means the service is there and did not answer this time, and greying out
  // Connect would strand a real tenant behind a transient error.
  const noService = answer.ok !== true && answer.kind === "unavailable";

  const stripe = rows.find((row) => row.id === "stripe") || null;
  // THE LEDGER IS EITHER LEDGER (16 Oct 2026: Xero first). The connected one when there
  // is one; otherwise the first ledger row in catalogue order, so a revoked row still
  // reads as revoked. This read `row.id === "quickbooks"` and would have left a tenant
  // with Xero connected on "Connect QuickBooks" for ever.
  const ledger =
    connectedLedgers(rows)[0] ||
    ledgerRows(rows).find((row) => row.state === "revoked") ||
    ledgerRows(rows)[0] ||
    null;

  const stripeDone = Boolean(stripe && stripe.connected);
  const ledgerDone = Boolean(ledger && ledger.connected);
  // Done means an account is actually recorded, not that the list arrived. A listing
  // that answered with nothing chosen is the state most tenants are in on day one.
  const bankState = readBankAccount(bank);
  const bankDone = bankState.ok && Boolean(bankState.chosen);
  const bankPickable = bankState.ok && bankState.accounts.length > 0;

  // WHAT IS ALREADY IN THE BOOKS. Null unless the register read ANSWERED and answered
  // with something in it — see `readRegister`. Nothing below is gated on it; it is
  // carried so the screen can stop describing a tenant with history as a tenant with
  // nothing, and so the one sentence on this page that was flatly false on such a
  // tenant can be replaced with one that is not.
  const ingested = ingestedLine(readRegister(register));
  const hasHistory = Boolean(ingested);

  // A REVOKED ROW IS A THIRD STATE AND THIS MODULE USED TO DROP IT. `connected` was
  // the only field read, so "you disconnected this on the 16th" and "you have never
  // connected this" arrived here as one boolean and left as the badge "Not yet" —
  // which is the past tense being denied. `GET /connections` returns revoked rows on
  // purpose so a screen can tell the two apart, and lib/connections-shape.js already
  // words the difference for /connections; this is the same word, on the same fact.
  const revokedOf = (row) => Boolean(row && !row.connected && row.state === "revoked");

  const steps = [
    {
      id: "stripe",
      number: 1,
      title: "Connect Stripe",
      line:
        "The payouts, the charges and refunds inside them, and the fees taken out. " +
        "You paste one restricted key; Vert only ever reads.",
      done: stripeDone,
      detail: stripeDone ? accountLine(stripe) : revokedOf(stripe) ? stateLine(stripe) : null,
      revoked: revokedOf(stripe),
      // THIS STEP'S CONTROL SPENDS A CREDENTIAL AGAINST THE SERVICE. Steps 3 and 4 do
      // not — one is the operator's and the other is a link to a screen that draws
      // itself — so this is per-step rather than a fact the screen re-derives from an
      // id list it would then have to keep in step with this one.
      connects: true,
      needs: null,
    },
    {
      id: "ledger",
      number: 2,
      title: "Connect your ledger",
      line:
        `${ledgerChoiceWords(rows)}. You sign in to it to allow Vert and come straight ` +
        "back here. It is the ledger an approved entry is posted into, and the chart the " +
        "mapping in the next step is written against.",
      done: ledgerDone,
      detail: ledgerDone ? accountLine(ledger) : revokedOf(ledger) ? stateLine(ledger) : null,
      revoked: revokedOf(ledger),
      connects: true,
      // THE ONE SENTENCE ON THIS PAGE A TENANT COULD HOLD UP A COUNTER-EXAMPLE TO.
      // "There is nothing to reconcile against a ledger until the payouts are
      // arriving" is true of a tenant starting from nothing and false of one whose
      // register already holds forty-three of them — and it was printed to the second
      // kind, under a step count that said they had done nothing at all. The gate is
      // unchanged (a ledger still needs a payout feed behind it); what changes is that
      // the REASON is no longer stated as a fact about their books when the register
      // has answered otherwise.
      needs: hasHistory
        ? "What is already in the register stays there whatever happens on this page, " +
          "but nothing new arrives and nothing can be posted until there is a live " +
          "connection behind it."
        : "There is nothing to reconcile against a ledger until the payouts are arriving.",
    },
    {
      id: "mapping",
      number: 3,
      title: "Load your account mapping",
      line:
        "Which account in your own chart each line of an entry is posted to. There is " +
        "no screen for this: the mapping is loaded from your accountant's own file by " +
        "whoever runs this service, and nothing here can read it back.",
      // AN OPERATOR STEP. It is not this tenant's to do, its state cannot be read from
      // any route this build has, and it therefore gates nothing — see the loop below.
      // `done: false` is not a claim that it is unfinished; `verifiable: false` is what
      // the screen renders, and it renders it in words rather than as a badge.
      operator: true,
      verifiable: false,
      done: false,
      // NO PROGRESS LINE. This read "0 of 3 required", off a route that does not exist.
      // A count nobody can verify is worse than none — and one that was always going to
      // be zero is a screen telling a customer they have work to do that is not theirs.
      detail: null,
      needs: null,
      revoked: false,
    },
    {
      id: "bank",
      number: 4,
      title: "Choose the bank account",
      line:
        "Which account Vert reads to confirm a payout actually landed. Until one is " +
        "chosen, every payout stays blocked as a deposit nobody has seen; the " +
        "arithmetic ties, and no account has been read to confirm the money arrived.",
      done: bankDone,
      detail: bankDone ? bankState.chosen : bankPickable ? `${bankState.accounts.length} to choose from` : null,
      needs:
        "The account is one of yours, listed by the sync service out of your connected " +
        "ledger, and there is nothing to list until that ledger is connected.",
      // The one step that can be UNFINISHABLE rather than merely unfinished, which no
      // other step here can be: the other three are writes this tenant controls, and
      // this one depends on a list arriving. When it does not, the step says so and
      // names the route that does not need it — the bank statement import, which
      // answers the same question from a file. Without this the screen sent a person
      // to a picker that could not be drawn.
      unavailable: !bankState.ok ? bankState.message || "The bank accounts could not be listed." : null,
      revoked: false,
    },
  ];

  // ONE PASS, AND THE ORDER IS THE GATE. A step is open only when everything before it
  // is done; everything after the first unfinished step is locked. Derived rather than
  // held, so there is no arrangement of state in which two steps are open at once.
  //
  // THE SENTENCE ON A LOCKED STEP NAMES THE STEP THAT IS ACTUALLY BLOCKING IT, AND IT
  // USED TO NAME A CONSTANT.
  // ------------------------------------------------------------------
  // FOUND IN A BROWSER, SIGNED IN AS A LIVE TENANT, 2026-08-23. Steps 3 and 4 carried
  // the fixed words "Connect QuickBooks first." On a tenant with QuickBooks connected
  // and Stripe not, this page rendered "2. Connect QuickBooks — Done 4620816365" and
  // then, directly beneath it, twice, "Connect QuickBooks first." The instruction named
  // a prerequisite the reader had already satisfied, three inches under the badge
  // saying so — a dead end with nothing to press and no way to find out what was
  // really wanted, which was Stripe.
  //
  // It is an ordinary state and not an exotic one: /connections is explicitly the
  // reference surface where connections are made "in no particular order", so
  // connecting the ledger before the processor is a supported path into exactly this.
  // It is also where a revoked Stripe key lands a tenant who finished setup weeks ago.
  //
  // The gate was always sequential — a step is locked when ANY earlier step is
  // unfinished — while the sentence assumed the blocker was always the ledger. So the
  // blocking step is read off the same pass that does the locking, and the lead is
  // written from its title. One fact, one place, and the two cannot disagree.
  //
  // AN OPERATOR STEP IS NEITHER OPEN NOR LOCKED AND NEVER BLOCKS THE NEXT ONE.
  // ------------------------------------------------------------------
  // Step 3 is not a write this tenant makes and there is no route that can say whether
  // it has been done (see the header). Left in the sequence as an ordinary step it
  // would be permanently unfinished, so it would be the `blocker` for step 4 for ever —
  // "Load your account mapping first" printed under a bank picker that has nothing to
  // do with the mapping, with nothing on the page a person could press to satisfy it.
  // That is the dead end the whole `blocked` sentence exists to prevent, so the step
  // is skipped by the gate entirely: it is drawn, it is read, and it decides nothing.
  let reached = true;
  let blocker = null;
  for (const step of steps) {
    if (step.operator) {
      step.open = false;
      step.locked = false;
      step.blocked = null;
      continue;
    }
    step.open = reached && !step.done;
    step.locked = !reached && !step.done;
    // The lead names the first unfinished step, and `needs` says why THIS step wants
    // what that one produces. Null when nothing is blocking, which is every unlocked
    // step — a locked step always has a blocker, because that is what locked it.
    step.blocked = step.locked && blocker
      ? `${blocker.title} first.${step.needs ? ` ${step.needs}` : ""}`
      : null;
    if (!step.done) {
      if (!blocker) blocker = step;
      reached = false;
    }
  }

  return {
    steps,
    rows,
    // OVER THE STEPS THIS TENANT CAN FINISH. An operator step has no readable state, so
    // requiring it here would make `complete` false on every deployment for ever — and
    // asserting it would be this page claiming a mapping is loaded when it has no way
    // to know. The completion notice says which of the two it is speaking for.
    complete: steps.every((step) => step.operator || step.done),
    // Descriptive only — see `readRegister`. Never consulted by `decided`, `complete`
    // or `needsSetup`, so a register read that failed or answered zero cannot move a
    // step or change where anybody lands.
    ingested,
    current: steps.find((step) => step.open) || null,
    // See the header. The mapping read is only required to have landed once it is the
    // only question left.
    //
    // THE BANK READ GATES THE REDIRECT ONLY ONCE IT IS THE LAST QUESTION — the same
    // rule the mapping read follows one clause earlier, and for a sharper reason.
    //
    // `decided` is what lets `/` send a tenant here. A bank listing that could not
    // answer is the one case where doing so would be actively hostile: the step they
    // would be sent to finish is the step that cannot be finished, so they would land
    // on an onboarding page, read that it is broken, and have lost their register in
    // the process. Undecided means stay where you are — and the panel on /connections
    // still says what happened, with the import offered beside it.
    //
    // Once the listing DOES answer and simply has nothing chosen, that is an ordinary
    // unfinished step and the redirect is right: every payout is blocked until it is
    // answered, and this page is where it gets answered.
    // THE MAPPING CLAUSE IS GONE WITH THE ROUTE IT READ. `decided` used to require a
    // `GET /ledger/map` that answered; nothing answers it, so that clause was a
    // permanent `false` waiting for the two connections to be made, and it would have
    // stopped `/` ever sending a fully-connected tenant here.
    decided: answer.ok === true && (!ledgerDone || bankState.ok === true),
    // THE ANSWER THE WRITE CONTROLS ARE GATED ON. See `noService` above. It is a fact
    // about the build, not about this tenant, so it is its own field rather than a
    // flag on a step: it is the same answer for all four of them, and the screen
    // states it once above the steps rather than four times inside them.
    service: {
      available: !noService,
      // The service's own sentence, or nothing. Never invented here: on any other
      // failure this is null and `available` stays true, so no control is withheld
      // and no reason is claimed.
      message: noService ? answer.message || null : null,
    },
  };
}

/**
 * Whether `/` should send this tenant to `/setup` instead of to the register.
 *
 * FALSE WHENEVER THE ANSWER IS NOT KNOWN. The static showpiece has no tenant and no
 * service, every read comes back "unavailable", and it lands on the register exactly as
 * it always has. A live tenant whose API is slow or down lands there too, and finds out
 * why from the screen that was going to tell them anyway.
 */
export function needsSetup({ connections, bank, register }) {
  // `bank` threaded through since 2026-08-20. Dropping it here — which this function
  // did on the day the fourth step was added — makes the redirect read a DIFFERENT
  // setup state from the one the page renders: no bank answer means the bank step is
  // never done, so `complete` was false forever and every tenant was sent to a page
  // that then told them they were finished.
  // `register` is threaded through only so this reads the SAME state the page
  // renders, which is the invariant the note above is about. It is descriptive and
  // cannot change the answer — tests/setup.test.js sweeps that, because a fact added
  // for a sentence must never quietly become a gate.
  const state = setupState({ connections, bank, register });
  // A CONNECTED LEDGER IS SETUP DONE (production walk, 8 Nov 2026). First run used to
  // wait for Stripe and a payout bank too: the payout reconciler's rule, from before
  // the ledger came first (founder, 16 Oct 2026). A Xero-only client was held on
  // "Connect Stripe" with no way to start a month. Stripe and the payout bank stay on
  // Connections as optional sources.
  const ledger = state.steps.find((step) => step.id === "ledger");
  return state.decided && !(ledger && ledger.done);
}
