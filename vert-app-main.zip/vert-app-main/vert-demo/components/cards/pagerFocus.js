"use client";

// components/cards/pagerFocus.js — ONE PURPLE COMMIT ACROSS A RUN OF PAGED ENTRIES
// ==============================================================================
// Eval PR8 (2 Oct): a GL reconciliation that drafted three entries drew three journal
// cards at once ("1 of 3", "2 of 3", "3 of 3"), each with its own purple commit — three
// "this writes" signals in one view, where §4.0.9 allows one. The cards of one run
// (`je.pager.runId`) now agree which of them is CURRENT: the lowest-numbered one still
// open on screen. Only the current card draws its commit in the accent; the others
// draw the same control quiet (a secondary), still pressable — nothing is hidden or
// disabled, the colour just stops claiming three things are the next step.
//
// Before any card has said it is open (the server render, the first paint) the rule
// falls back to the payload alone: entry 1 of the run is current. When a card is
// decided it stops being open, and the next one takes the accent.

import { useEffect, useSyncExternalStore } from "react";

const open = new Map(); // runKey → Map(cardKey → index)
const listeners = new Set();

function emit() {
  for (const l of listeners) l();
}

function subscribe(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** The run a paged entry belongs to, or null for an entry that is not paged. */
export function runKeyOf(je) {
  const p = je && je.pager;
  if (!p || !Number.isInteger(p.of) || p.of <= 1 || !Number.isInteger(p.index)) return null;
  return `${typeof p.runId === "string" && p.runId ? p.runId : "run"}:${p.of}`;
}

/** Pure: the current index of a run, given the indices open on screen. */
export function currentIndex(indices) {
  const list = [...indices].filter(Number.isInteger);
  return list.length ? Math.min(...list) : 1;
}

function snapshotFor(run) {
  const cards = run ? open.get(run) : null;
  return cards && cards.size ? currentIndex(cards.values()) : 1;
}

/**
 * Whether this card is the run's current one. `stillOpen` is false once the card is
 * decided (approved, posted, rejected), so the accent moves on to the next entry.
 */
export function usePagerFocus(je, cardKey, stillOpen = true) {
  const run = runKeyOf(je);
  const index = run ? je.pager.index : null;
  useEffect(() => {
    if (!run || !stillOpen) return undefined;
    let cards = open.get(run);
    if (!cards) open.set(run, (cards = new Map()));
    cards.set(cardKey, index);
    emit();
    return () => {
      cards.delete(cardKey);
      if (!cards.size) open.delete(run);
      emit();
    };
  }, [run, cardKey, index, stillOpen]);
  const current = useSyncExternalStore(
    subscribe,
    () => snapshotFor(run),
    () => 1
  );
  if (!run) return true;
  return index === current;
}
