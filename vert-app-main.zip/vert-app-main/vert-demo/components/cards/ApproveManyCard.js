"use client";

// components/cards/ApproveManyCard.js — "APPROVE 24 · $412,380.10", THEN A PREVIEW
// ==============================================================================
// Spec §5.3 row 6; audit UI-010.
//
// THE DEFECT IT ENDS. The bulk bar read "Approve 24" with no total, crossed pages, and
// signed entries the reviewer had never seen. Here the button carries the count and
// the ENGINE'S total (approve_entries computes it; this card only formats it), and
// pressing it does not approve anything: it opens the list of what would be approved,
// one line per entry, in place. The one commit is under that list.
//
// ONE REQUEST, AND EVERY REFUSAL SURVIVES. `approveDraftEntries` sends the batch to
// `POST /approvals/approve`, which re-runs the tie-outs per payout and answers with one
// outcome each. "22 approved, 2 refused" is printed with both numbers, and each refusal
// is named by its transaction line (lib/actions.js bulkLine's rule: the part left out
// is the part somebody has to act on).
//
// THE CAP IS THE API'S (50). A batch over it is not sent, and the card says so with
// both numbers rather than spending a round trip to be told.
//
// IT COVERS EVERY ENTRY WAITING, OR SAYS WHICH IT DOESN'T (e2e r3 D4). The roll-up is the
// engine's, drawn from the entries ready when the task last ran; an entry whose own card
// is on the page but whose payout is not in the roll-up (a withdrawn approval coming
// back, a task not yet caught up) is named under it — "Not in this: …" — so "Approve
// all 2" never quietly means "all but one".
//
// NET AND GROSS, SAID ONCE (eval finding 13). Each line pairs the payout — what reached
// the bank, net of fees — with the entry it books, gross. When any pair differs the list
// carries one caption saying so, instead of "$11,000.00 … $11,330.00" with no word.
//
// UNDO (e2e r3 D5). An approve-many is approvals like any other, so its line keeps Undo
// while they stand: it withdraws each approval the batch made (lib/actions.js
// withdrawApprovals) and reopens the card, and the count moves back from the API's
// reading.

import DutyGate from "./DutyGate.js";
import { useState } from "react";
import { Button, Figure, FigureInText } from "@/components/ui";
import { approveDraftEntries, withdrawApprovals } from "@/lib/actions";
import { BULK_APPROVE_CAP, callSafely, useCardCommit } from "@/lib/decisions";
import { approveManyLabel, approveManyOffer } from "@/lib/bulkApprove";
import { useEngine } from "@/lib/engine-context";
import { useDuties, useRecordMonth } from "@/lib/store";
import { approveRefusal, dutyRefusalSentence } from "@/lib/roles";
import { monthReadingOf } from "@/components/month/model";
import Card from "./Card";
import DecisionLine from "./DecisionLine";
import Skip from "./Skip";
import { GROSS_NET_CAPTION, boundLabel, entryDiffersFromPayout, isRead, lineFor } from "./words";
import { formatMoney } from "@/lib/format";
import BoundText from "@/components/chat/BoundText";

/**
 * The lines the preview lists, one per payout in the request, in request order. Each
 * comes from the matching per-entry card when Month-end hands them over (`entries`),
 * else from the payload's payout record. A payout neither can describe is listed as
 * "An entry Vert couldn't describe" rather than dropped: the preview must show as many
 * lines as the button promises.
 *
 * Each line carries the figures behind its words — the payout's (`line`) and the
 * entry's (`entry`) — so both are drawn bound, and `differs` says whether they are two
 * different amounts (net and gross).
 */
export function previewLines(payoutIds, entries = [], engine = null) {
  return payoutIds.map((id) => {
    const card = entries.find((e) => e && e.target && e.target.id === id);
    if (card) {
      const line = lineFor(card);
      const entry = card.figures && card.figures.entry;
      return {
        id,
        text: line || "An entry Vert couldn't describe",
        amount: isRead(entry) ? formatMoney(entry.cents) : null,
        line: card.line || null,
        entry: isRead(entry) ? entry : null,
        differs: entryDiffersFromPayout(entry, card.line),
      };
    }
    const recon = engine && engine.reconciliations && engine.reconciliations[id];
    const p = recon && recon.payout;
    if (p) {
      // Through `lineFor`, the one place a card turns the register's source kind into
      // a processor's name: the raw kind "shopify_payments" printed "Shopify_payments
      // payout" here (found by G1's bulk-approve re-point, 2026-09-30).
      const line = { source: p.source, date: p.arrival_date, cents: p.amount };
      const text = lineFor({ line });
      if (text) return { id, text, amount: null, line, entry: null, differs: false };
    }
    return { id, text: "An entry Vert couldn't describe", amount: null, line: null, entry: null, differs: false };
  });
}

/**
 * The approve cards on the page that this roll-up does NOT carry: each an entry waiting
 * for approval that "Approve all" would leave out. Empty when it covers them all.
 */
export function uncoveredEntries(payoutIds, entries = []) {
  const ids = new Set(Array.isArray(payoutIds) ? payoutIds : []);
  return (Array.isArray(entries) ? entries : []).filter((e) => e && e.kind === "approve" && e.target && e.target.id && !ids.has(e.target.id));
}

export default function ApproveManyCard({ action, onSettled, onReopened = null, ledgerName = null, entries = [], initial = null }) {
  const engine = useEngine();
  // Every ready entry the engine put in the request, its count and its total
  // (lib/bulkApprove.js approveManyOffer: read, never derived).
  const offer = approveManyOffer(action);
  const ids = offer.ids;
  const [previewing, setPreviewing] = useState(false);
  const [undo, setUndo] = useState({ busy: false, failed: null });
  const card = useCardCommit(action, { onSettled, initial });
  const recordMonth = useRecordMonth();
  // A preparer's batch is a reviewer's to approve (§20.12 H3), said before the press.
  // Segregation is per entry, so the engine answers it per entry in the results.
  const dutyReason = approveRefusal(useDuties());
  const label = boundLabel(action.commitLabel, action.figures, ledgerName);
  const total = action.figures && action.figures.total;
  const totalText = isRead(total) ? formatMoney(total.cents) : null;
  const overCap = ids.length > BULK_APPROVE_CAP;
  const lines = previewLines(ids, entries, engine);
  const missing = uncoveredEntries(ids, entries);

  if (card.phase === "done") {
    const summary = (card.result && card.result.summary) || {};
    const results = card.result && Array.isArray(card.result.results) ? card.result.results : [];
    const refused = results.filter((r) => !r.ok);
    const approvedIds = results.filter((r) => r.ok && r.payoutId).map((r) => r.payoutId);
    const approved = Number(summary.approved) || 0;
    // A batch the API answered with nothing signed is not "Approved": the line would
    // head "Approved · Vansh · 10:42" over "0 approved, 2 refused" (found by G1,
    // 2026-09-30). It says what happened instead.
    const nothingSigned = card.settled.outcome !== "declined" && refused.length > 0 && approved === 0;
    const undoable = card.settled.outcome === "approved" && approvedIds.length > 0 && card.writesEnabled;

    async function withdraw() {
      setUndo({ busy: true, failed: null });
      const result = await callSafely(withdrawApprovals, approvedIds);
      if (!result.ok) {
        setUndo({ busy: false, failed: result });
        return;
      }
      setUndo({ busy: false, failed: null });
      const reading = monthReadingOf(result);
      if (reading) recordMonth(reading);
      setPreviewing(false);
      card.reopen();
      if (onReopened) onReopened();
    }

    return (
      <DecisionLine
        kind="approve_many"
        settled={card.settled}
        outcome={nothingSigned ? "refused" : card.settled.outcome}
        amount={refused.length === 0 ? totalText : null}
        note={
          undo.failed
            ? "Undo wasn't sent. The approvals stand."
            : card.settled.outcome === "declined"
              ? null
              : refused.length
                ? [
                    `${approved} approved, ${refused.length} refused: ${refused.map((r) => lines.find((l) => l.id === r.payoutId)?.text || "an entry").join("; ")}.`,
                    // Why, once, when the engine refused them for who pressed (§20.12 M4).
                    ...new Set(refused.map((r) => dutyRefusalSentence(r)).filter(Boolean)),
                  ].join(" ")
                : null
        }
      >
        {undoable && !nothingSigned ? (
          <Button variant="quiet" size="sm" onClick={withdraw} busy={undo.busy} busyLabel="Undoing…">
            Undo
          </Button>
        ) : null}
      </DecisionLine>
    );
  }

  const commit = dutyReason ? (
    <DutyGate reason={dutyReason} />
  ) : previewing ? (
    <Button
      variant="commit"
      busy={card.busy}
      busyLabel="Approving…"
      disabledReason={dutyReason || card.disabledReason}
      onClick={() => card.commit(approveDraftEntries, ids, { outcome: "approved" })}
    >
      {/* NAMES WHAT IT COVERS (answer shape, 17 Oct 2026): "all 3" over a batch that
          leaves a blocked entry out said it approved what it could not. */}
      {ids.length === 1 ? "Approve this entry" : `Approve these ${ids.length} entries`}
    </Button>
  ) : (
    <Button variant="commit" onClick={() => setPreviewing(true)} disabledReason={dutyReason || card.disabledReason}>
      {label ? <BoundText text={action.commitLabel} figures={action.figures} ledgerName={ledgerName} plain /> : approveManyLabel(offer)}
    </Button>
  );

  const anyDiffers = lines.some((l) => l.differs);
  const form = (
    <>
      {previewing ? (
        <>
          {anyDiffers ? <p className="dcard-caption t-footnote">{GROSS_NET_CAPTION}</p> : null}
          <ol className="dcard-preview" aria-label={`The ${ids.length} entries this approves`}>
            {lines.map((l) => (
              <li key={l.id} className="dcard-preview-row t-footnote" data-differs={l.differs ? "true" : undefined}>
                <span>
                  {l.line ? <FigureInText text={l.text} cents={l.line.cents} measured={l.line.measured} figure={`payouts/${l.id}/amount`} /> : l.text}
                </span>
                {l.entry ? (
                  <span className="num">
                    {"Entry "}
                    <Figure cents={l.entry.cents} figure={`journal_entry/${l.id}/sumDr`} />
                  </span>
                ) : null}
              </li>
            ))}
          </ol>
        </>
      ) : null}
      {missing.length ? (
        <p className="dcard-caption t-footnote" data-rollup-missing="">
          {`Not in this: ${missing.map((e) => lineFor(e) || "an entry").join("; ")}. Approve ${missing.length === 1 ? "it on its own card" : "them on their own cards"}.`}
        </p>
      ) : null}
    </>
  );

  return (
    <Card
      action={action}
      kind="approve_many"
      ledgerName={ledgerName}
      failure={card.phase === "failed" ? card.result : null}
      onRetry={card.phase === "failed" && card.writesEnabled ? card.retry : undefined}
      form={previewing || missing.length ? form : null}
      actions={
        overCap ? (
          <p className="dcard-reason t-footnote">
            {`${ids.length} entries is more than the ${BULK_APPROVE_CAP} one press can approve. Approve them from each entry's card.`}
          </p>
        ) : (
          <>
            {commit}
            {previewing ? (
              <Button variant="quiet" onClick={() => setPreviewing(false)}>
                Not now
              </Button>
            ) : (
              <Skip action={action} card={card} />
            )}
          </>
        )
      }
    />
  );
}
