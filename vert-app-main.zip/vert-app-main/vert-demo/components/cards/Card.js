"use client";

// components/cards/Card.js — THE ANATOMY EVERY DECISION CARD SHARES
// ==============================================================================
// Spec §5.1:
//
//   Stripe payout · 2 Jul · $7,000.00            ← the transaction, never an id
//   Use the 1 Jul deposit of $7,000.00?          ← the proposal, one sentence
//   Same amount, and the reference matches.      ← one reason, footnote size
//   Vert's best guess: check this               ← only when a model suggested it
//   [■ Use this deposit]  [ Pick another ]  [ Skip ]   Details ▾
//
// WHY ONE SHELL. Eleven kinds of card share one reading order, and the rules that make
// them honest are rules about that order: the head stays within 25 words (UI-021); the
// best-guess mark appears only when the event's `basis` is `suggested` (spec §9.1 — a
// card never marks itself); ids are drawn only inside Details (§1.6); exactly one
// filled button, the commit (§15); a failed press keeps the card open with its input
// and says what was recorded (UI-002). Written once, here, a card kind cannot get one
// of them wrong on its own.
//
// NO STATUS BADGE INSIDE A CARD (UI-007): on Month-end the group heading already says
// Needs you, and in the chat the conversation's header does.
//
// The head is `.dcard-head`, the form `.dcard-form`, the buttons `.dcard-actions`, and
// Details `.dcard-details` (`dcard`, because the old screens still own `.card` in app/globals.css). tests/cards.test.js counts the head's words and the
// commit-styled buttons by those names.

import { BestGuess, Disclosure, FigureInText, Notice, guessQualifies } from "@/components/ui";
import BoundText from "@/components/chat/BoundText";
import { failureDetails, failureSentence, lineFor } from "./words";

// The reference for a card's transaction line: the record the card is about (rubric C1).
function lineRef(a) {
  const t = a.target || {};
  return t.kind && t.id ? `${t.kind}s/${t.id}/amount` : `actions/${a.actionId || "unknown"}/line`;
}

export default function Card({
  action,
  kind,
  ledgerName = null,
  proposal,
  why,
  suggested,
  form = null,
  actions = null,
  failure = null,
  onRetry,
  details = null,
  className,
}) {
  const a = action && typeof action === "object" ? action : {};
  const line = lineFor(a);
  const proposalText = proposal !== undefined ? proposal : a.proposal;
  const whyText = why !== undefined ? why : a.why;
  const marked = suggested !== undefined ? suggested : a.basis === "suggested";

  // ESC LETS GO, AND FOCUS STAYS ON THE CARD (D10; critic r1 F8): Esc inside a card
  // never skips, and its focus rests on the card's question rather than falling to
  // <body>, so the next Tab carries on from the card.
  const onKeyDown = (event) => {
    if (event.key !== "Escape" || event.defaultPrevented) return;
    // Only a key pressed in the card itself: an Esc from a sheet the card opened (a
    // portal) is the sheet's own.
    if (!event.currentTarget.contains(event.target)) return;
    const head = event.currentTarget.querySelector(".dcard-proposal") || event.currentTarget.querySelector(".dcard-line");
    if (!head || head.contains(event.target)) return;
    event.preventDefault();
    head.focus();
  };
  return (
    <article
      className={["dcard", className].filter(Boolean).join(" ")}
      data-card={kind || a.kind || "unknown"}
      aria-label={line || undefined}
      onKeyDown={onKeyDown}
    >
      <div className="dcard-head">
        {line ? (
          <p className="dcard-line t-footnote" tabIndex={-1}>
            <FigureInText text={line} cents={a.line.cents} measured={a.line.measured} figure={lineRef(a)} />
          </p>
        ) : null}
        {proposalText ? (
          <p className="dcard-proposal t-callout" tabIndex={-1}>
            {typeof proposalText === "string" ? (
              <BoundText text={proposalText} figures={a.figures} ledgerName={ledgerName} />
            ) : (
              proposalText
            )}
          </p>
        ) : null}
        {whyText ? (
          <p className="dcard-why t-footnote">
            {typeof whyText === "string" ? <BoundText text={whyText} figures={a.figures} ledgerName={ledgerName} /> : whyText}
          </p>
        ) : null}
        {/* No mark on a card with nothing above it to check (bug bash 10 Oct 2026). */}
        {marked && guessQualifies(line, proposalText, whyText) ? <BestGuess /> : null}
      </div>
      {form ? <div className="dcard-form">{form}</div> : null}
      {/* Details before the foot (design-fix-2 DA2-016): what the card is about, then
          its ids one press down, then the divider and the actions the eye ends on. */}
      <CardDetails action={a}>{details}</CardDetails>
      {actions ? <div className="dcard-actions">{actions}</div> : null}
      {failure && failure.kind === "unconfirmed" ? (
        // P30: not a failure of the press, which landed; the decision is not counted
        // until the engine finds it. A warning, and its retry only looks again.
        <Notice kind="warning" onRetry={onRetry} retryLabel="Check again" className="dcard-failure dcard-unconfirmed">
          {failureSentence(failure)}
        </Notice>
      ) : failure ? (
        <Notice kind="error" recorded="nothing" onRetry={onRetry} details={failureDetails(failure)} className="dcard-failure">
          {failureSentence(failure, { source: a.line && a.line.source })}
        </Notice>
      ) : null}
    </article>
  );
}

// Details: the ids and the workings, one press down. The target's id and the card's
// own id are always here, so "which payout is this?" always has an answer — just not
// on the card's face.
function CardDetails({ action, children }) {
  const target = action.target && typeof action.target === "object" ? action.target : null;
  return (
    <div className="dcard-details" data-details="">
      <Disclosure summary="Details">
        {children}
        <dl className="dcard-ids">
          {target && target.id ? (
            <>
              <dt>{TARGET_WORDS[target.kind] || "Record"}</dt>
              <dd className="dcard-id">{String(target.id)}</dd>
            </>
          ) : null}
          {action.actionId ? (
            <>
              <dt>Decision</dt>
              <dd className="dcard-id">{String(action.actionId)}</dd>
            </>
          ) : null}
        </dl>
      </Disclosure>
    </div>
  );
}

const TARGET_WORDS = {
  payout: "Payout",
  period: "Month",
  exception: "Exception",
  journal_entry: "Journal entry",
  bank_line: "Bank line",
  prepaid_schedule: "Prepaid schedule",
};
