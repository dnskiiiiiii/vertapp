"use client";

// components/cards/GstCard.js — "IS THIS SALE TAXABLE, OR GST-FREE?"
// ==============================================================================
// Spec §5.3 row 2. Replaces GstResolvePanel.
//
// NEVER A GST-FREE GUESS. resolve_breaks sends no ground for this card on purpose: most
// GST grounds need order data the model is not shown (vert_agent.prefill), and a
// pre-filled GST-free ground is the one suggestion that can understate a liability. So
// the person chooses the treatment and writes the note an auditor will read. The
// direction (taxable or GST-free) is derived from the ground by lib/actions.js, never
// chosen separately, so the two can't disagree.
//
// THE QUESTION PATTERN, STARTING ON THE ACT'S DEFAULT (eval r2 §17.4). The card was a
// stacked form — a "Choose one" select and an empty note — where the chat and the
// reference (key/23) ask with numbered rows and the first answer highlighted. It now
// draws the rows (OptionRows, the chat's anatomy) with "Taxable supply" first and
// chosen. That is not Vert guessing a treatment: under the GST Act a sale IS taxable
// unless a provision makes it GST-free, so the default cites nothing and can only
// overstate the liability, never understate it. Each of the six GST-free grounds is a
// departure the person has to pick. Where the engine does name a ground in the prefill,
// that one leads instead. The note stays required. On the Act's default it starts on
// the default's own ground (GST_DEFAULT_NOTE below); on a GST-free ground it is empty
// until the person writes the evidence, and the commit says so beside it.
//
// The route recomputes the lines in scope and the digest of their figures and refuses
// with 409 if either moved since this card was drawn: nothing is recorded over figures
// nobody looked at.

import { useState } from "react";
import { Button, Field } from "@/components/ui";
import { recordGstAssertion } from "@/lib/actions";
import { GST_BASES, isKnownBasis } from "@/lib/assertions";
import { useCardCommit } from "@/lib/decisions";
import Card from "./Card";
import DecisionLine from "./DecisionLine";
import OptionRows from "./OptionRows";
import Skip from "./Skip";
import { clearOnChange, missing, required } from "./validate";

// The two things a GST answer needs, said the same way on blur and on the press.
export const GST_MESSAGES = Object.freeze({
  basis: "Choose the treatment.",
  note: "Say how you know, in a sentence.",
});

/** The Act's default treatment: a sale is taxable unless a ground makes it GST-free. */
export const GST_DEFAULT_BASIS = "taxable_standard_rate";

/**
 * The ground the Act's default rests on, said as the note when the card starts on it
 * (eval final-a §17.3 flow 2 / PR3). The commit was enabled with "Taxable supply"
 * chosen, then refused the press with "Say how you know, in a sentence." because the
 * note was empty: the one live commit in the flow did nothing. The default cites no
 * concession — that IS its evidence — so the note says exactly that, and one press
 * records it. Choosing a GST-free ground clears this sentence (it would be false
 * there), and the commit then stays disabled, with its reason, until the person writes
 * how they know.
 */
export const GST_DEFAULT_NOTE = "No GST-free ground applies, so the sale is a taxable supply at the standard rate.";

/** The note a card starts with: the engine's, else the default's ground, else empty. */
export function gstStartNote(prefill, startOn) {
  if (prefill && typeof prefill.note === "string" && prefill.note.trim()) return prefill.note;
  return startOn === GST_DEFAULT_BASIS ? GST_DEFAULT_NOTE : "";
}

/** Why "Save GST treatment" can't be pressed yet, or null when it can. */
export function gstDisabledReason({ basis, note }) {
  if (!isKnownBasis(basis)) return GST_MESSAGES.basis;
  if (typeof note !== "string" || !note.trim()) return GST_MESSAGES.note;
  return null;
}

/**
 * The rows in the order they are drawn: the ground the card starts on first (the
 * engine's own when it names one, else the Act's default), then the rest in the API's
 * order.
 */
export function gstRows(startOn, bases = null) {
  // ONLY THE GROUNDS THE ENGINE TAKES HERE, when it named them (a refused post's
  // `gstQuestion.bases`, w37): a sale Stripe says carries no GST can't be answered
  // "taxable", so that row is not offered at all.
  const pool = Array.isArray(bases) && bases.length ? GST_BASES.filter((g) => bases.includes(g.value)) : GST_BASES;
  const first = pool.find((g) => g.value === startOn) || (startOn ? pool.find((g) => g.value === GST_DEFAULT_BASIS) : null);
  return (first ? [first, ...pool.filter((g) => g !== first)] : pool).map((g) => ({ value: g.value, label: g.label }));
}

export default function GstCard({ action, onSettled, ledgerName = null, initial = null, bases = null }) {
  const prefill = (action && action.prefill) || {};
  const payoutId = prefill.payoutId || (action.target && action.target.id) || null;
  const allowed = (b) => isKnownBasis(b) && (!Array.isArray(bases) || !bases.length || bases.includes(b));
  // With the engine's grounds given and the Act's default not among them, NO ground is
  // chosen for the person: each one left is a GST-free departure they must pick.
  const startOn = allowed(prefill.basis) ? prefill.basis : allowed(GST_DEFAULT_BASIS) ? GST_DEFAULT_BASIS : null;
  const [basis, setBasis] = useState(startOn);
  const [note, setNote] = useState(() => gstStartNote(prefill, startOn));
  const [errors, setErrors] = useState({});
  const card = useCardCommit(action, { onSettled, initial });

  if (card.phase === "done") return <DecisionLine kind="gst" settled={card.settled} outcome={card.settled.outcome} />;

  function press() {
    const next = missing({
      basis: [basis, GST_MESSAGES.basis, allowed],
      note: [note, GST_MESSAGES.note],
    });
    setErrors(next);
    if (Object.keys(next).length) return;
    card.commit(
      recordGstAssertion,
      { payoutId, basis, note, txnIds: prefill.txnIds, scopeHash: prefill.scopeHash },
      { outcome: "applied" }
    );
  }

  return (
    <Card
      action={action}
      kind="gst"
      ledgerName={ledgerName}
      form={
        <>
          <OptionRows
            label="Treatment"
            name="basis"
            options={gstRows(startOn, bases)}
            value={basis}
            guess={startOn}
            guessWord={startOn === GST_DEFAULT_BASIS ? "Default" : "Suggested"}
            onChange={(v) => {
              setBasis(v);
              // The default's sentence is true only of the default.
              if (v !== GST_DEFAULT_BASIS && note === GST_DEFAULT_NOTE) setNote("");
              else if (v === GST_DEFAULT_BASIS && !note.trim()) setNote(GST_DEFAULT_NOTE);
              setErrors((e) => ({ ...e, basis: undefined }));
            }}
          />
          {errors.basis ? <p className="dcard-reason t-footnote" role="alert">{errors.basis}</p> : null}
          <Field
            label="How do you know?"
            placeholder="The evidence, in a sentence"
            value={note}
            error={errors.note}
            validate={required(GST_MESSAGES.note)}
            onChange={clearOnChange(setErrors, "note", setNote)}
          />
        </>
      }
      failure={card.phase === "failed" ? card.result : null}
      onRetry={card.phase === "failed" && card.writesEnabled ? card.retry : undefined}
      actions={
        <>
          <Button variant="commit" onClick={press} busy={card.busy} busyLabel="Saving…" disabledReason={card.disabledReason || gstDisabledReason({ basis, note })}>
            Save GST treatment
          </Button>
          <Skip action={action} card={card} />
        </>
      }
    />
  );
}
