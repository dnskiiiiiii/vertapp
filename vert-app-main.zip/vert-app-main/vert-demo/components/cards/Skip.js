"use client";

// components/cards/Skip.js — "SKIP", THE QUIET WAY OUT OF A DECISION
// ==============================================================================
// Spec §5.1: one commit, then quiet options. Skip writes nothing to the books: it
// declines the card (`POST /agent/actions/{id}/decline`), so the task stops asking
// and the decision is recorded as skipped by you, with the time. It is drawn only on
// a card that has an action id to decline — nothing is listed unless it works.
//
// It goes through lib/actions.js declineDecision rather than the bare contract call so
// the API's answer — the month as it now counts it — reaches the page, and the header,
// the task rows and the badge move from that one reading (e2e r3 D1).

//
// DESIGN-FIX-2 (D10, spec §7.2): a press of Skip is held for five seconds behind a
// "Skipped. Undo" toast; Undo in that time sends nothing. Esc never reaches here.

import { Button } from "@/components/ui";
import { declineDecision } from "@/lib/actions";
import { useDeferredSkip } from "./OptionRows";
import OpenInChat from "./OpenInChat";

export default function Skip({ action, card, label = "Skip" }) {
  const id = action && typeof action.actionId === "string" ? action.actionId : "";
  const held = useDeferredSkip(() => card.commit(declineDecision, action.actionId, { outcome: "declined", settle: false }));
  // "Open in chat" sits just before Skip on a Home card (spec §7.2): Skip is on every
  // decision card, so the foot reads hints · Open in chat · Skip · commit everywhere.
  if (!id) return <OpenInChat action={action} />;
  return (
    <>
      <OpenInChat action={action} />
      <Button variant="quiet" disabled={!card.writesEnabled || card.busy || held.pending} onClick={held.skip} data-skip="">
        {label}
      </Button>
      {held.toast}
    </>
  );
}
