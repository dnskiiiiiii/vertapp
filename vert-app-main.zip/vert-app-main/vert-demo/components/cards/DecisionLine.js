"use client";

// components/cards/DecisionLine.js — A DECIDED CARD, AS ONE LINE
// ==============================================================================
// Spec §5.2 "Success" and §4.4. When a decision lands, its card collapses to one
// past-tense line built from the ACCEPTED result, before any refresh (UI-012): what
// happened, who, when — "Approved $9,350.73 · you · 10:42 · Undo". Never the access
// key's label (eval S6 / C8): lib/format.js approverLabel turns a credential into "you".
// "Approved", "Posted" and "Rejected" are never statuses; they are this line's text.
//
// NEVER BLANK (UI-024). The who comes from lib/format.js approverLabel's chain, so a
// reply that named nobody still reads "… · you · 10:42" rather than "Approved by".
//
// It is announced politely (`role="status"`) on the frame it appears, which is the
// frame the press resolved on (apple-design §13: causality).

import { useSignedInActor } from "@/lib/store";
import { doneLine } from "./words";

export default function DecisionLine({ kind, settled, amount = null, outcome = null, what = null, children = null, note = null }) {
  const signedInActor = useSignedInActor();
  return (
    <div className="dcard-done" role="status" aria-live="polite" data-card-done="" data-card={kind}>
      <p className="dcard-done-text t-body">{doneLine(kind, settled, { amount, outcome, what, signedIn: signedInActor })}</p>
      {note ? <p className="dcard-done-note t-footnote">{note}</p> : null}
      {children ? <div className="dcard-done-actions">{children}</div> : null}
    </div>
  );
}
