"use client";

// components/cards/PostSheet.js — THE ONE MODAL: "POST TO <THE CONNECTED LEDGER>?"
// ==============================================================================
// Spec §3.7; audit UI-004.
//
// THE ONE IRREVERSIBLE ACT IN THE PRODUCT gets the one modal. Posting writes a journal
// into a client's ledger. On QuickBooks there is no draft state: the entry is in the
// trial balance the moment it lands. On Xero (the first ledger since 16 Oct 2026) it
// arrives as a DRAFT somebody in Xero approves — and the sheet says which, by reading
// the API's `createsDraft` (lib/ledger-shape.js `holdsAsDraft`), never the vendor's name. So the press is
// a second, deliberate one, behind a scrim, and the sheet RESTATES THE JOURNAL from the
// engine's own lines — account, debit, credit and the totals the engine computed — so
// the person sees exactly what will be written before writing it. The commit names the
// amount and the ledger: "Post $9,631.75 to QuickBooks", or, on a ledger that holds it as
// a draft, "Send $9,631.75 to Xero as draft" — worded by words.js `postActionLabel` from
// `createsDraft`, which since 17 Oct 2026 follows each client's post mode. The ledger's
// own `postingEffect` sentence sits beside it in the footer.
//
// THE LEDGER'S NAME IS READ, NEVER WRITTEN IN. It comes from `/approvals/ledger`
// (lib/ledger.js), passed in by the page. With no ledger connected this sheet is never
// opened — the card offers no Post at all and says "ready to post when your ledger is
// connected" instead — and if it somehow is, it says so and has no commit.
//
// NO FIGURE HERE IS COMPUTED. Every amount is an engine integer from the payload's
// journal (`je.lines[].dr/cr`, `je.sumDr`, `je.sumCr`), formatted by lib/format.js.

import { Button, Notice, Sheet } from "@/components/ui";
import { useState } from "react";
import { approveAndPostPayout, postApprovedEntry } from "@/lib/actions";
import { canPost, holdsAsDraft } from "@/lib/ledger-shape";
import { useCardCommit } from "@/lib/decisions";
import { useEngine } from "@/lib/engine-context";
import { formatMoney } from "@/lib/format";
import { RECORDING_ONLY, draftWords, failureDetails, failureSentence, recordedFor, legAccount, lineFor, postActionLabel, returnedNote, splitLedgerName, unmappedNote, REVERSE_WORDS } from "./words";
import { publishPosted } from "./journal-edits";
import GstCard from "./GstCard";
import { PAYOUT_ENTRY, postingEffectOf, taxCodesOf } from "./ledger-effect";

/** The drafted journal for a payout, from the payload, or null when it isn't there. */
export function journalFor(engine, payoutId) {
  const recon = engine && engine.reconciliations && engine.reconciliations[payoutId];
  const je = recon && recon.je;
  if (!je || !Array.isArray(je.lines) || !je.lines.length) return null;
  if (typeof je.sumDr !== "number" || typeof je.sumCr !== "number") return null;
  return je;
}

// APPROVING (§4.0.5, eval JE5). Opened from a draft's "Approve and post…", this sheet's
// one confirm appends the approval AND posts (lib/actions.js approveAndPostPayout):
// draft → posted in two presses, not three. A post that fails after the approval
// landed leaves the approval standing; the sheet says so, tells the card
// (`onApproved`), and its retry is then a plain post — never a second approval.
/**
 * THE SHEET'S HEAD NAMES WHICH AMOUNT IT IS (verify pass 6, D01). It read "Stripe payout
 * on 1 Jul · $11,000.00" over lines, a Total and a button of $11,330.00, with nothing
 * saying which was which. The payout's amount is what reached the bank; when the entry's
 * lines total something else, both are named. Pure; exported for the tests.
 */
export function sheetLine(action, je) {
  const head = lineFor(action);
  if (!head) return null;
  const paid = action && action.line && Number.isInteger(action.line.cents) && action.line.measured !== false ? action.line.cents : null;
  const total = je && Number.isInteger(je.sumDr) ? je.sumDr : null;
  if (paid === null || total === null || paid === total) return head;
  return `${head} paid into the bank. The entry's lines total ${formatMoney(total)}.`;
}

export default function PostSheet({ open, onClose, action, ledger = null, clientName = null, onPosted, onApproved = null, approving = false, initial = null, lines = null }) {
  const engine = useEngine();
  const payoutId = (action && action.prefill && action.prefill.payoutId) || (action && action.target && action.target.id) || null;
  // The card's own lines where the page's payload has none (a conversation, D01).
  const je = journalFor(engine, payoutId) || (lines && Array.isArray(lines.lines) && lines.lines.length ? lines : null);
  const fullName = ledger && typeof ledger.displayName === "string" && ledger.displayName ? ledger.displayName : null;
  // Worded by ledger mode (verify pass 1, U09): a recording ledger receives nothing.
  const { name: ledgerName, recording } = fullName ? splitLedgerName(fullName) : { name: null, recording: false };
  const postable = canPost(ledger) && Boolean(ledgerName) && Boolean(je);
  // A ledger that holds what arrives as a draft for a person there to approve (Xero).
  // Never for a recording ledger, which receives nothing at all.
  const draft = !recording && holdsAsDraft(ledger);
  const journal = draft ? "a draft journal" : "a journal";
  const after = draft ? ` ${draftWords(ledgerName)}` : "";
  // THE LEDGER'S OWN SENTENCE ABOUT WHAT THIS PRESS DOES (`postingEffect`, from
  // /approvals/ledger, which follows the client's post mode), beside the button. Only
  // the API's: with none sent, nothing is drawn in its place.
  // The payout's own sentence first (staging D1): never another kind's caveat.
  const effect = recording ? null : postingEffectOf(ledger, null, PAYOUT_ENTRY);
  // What happens to the entry's GST, from the target's `sendsTaxCodes` (engine w37).
  const taxCodes = recording ? null : taxCodesOf(ledger, ledgerName);
  const card = useCardCommit(action, {
    initial,
    onSettled: (done) => {
      // Held for the posted plate that replaces the card in the thread (eval r2 JE5).
      if (done && done.settled) publishPosted(action && action.actionId, { settled: done.settled, je: null });
      if (onPosted) onPosted(done);
    },
  });
  const line = sheetLine(action, je);
  // Once the approval has landed, the sheet only posts.
  const [approvedHere, setApprovedHere] = useState(false);
  const approveFirst = approving && !approvedHere;
  async function confirm() {
    const fn = approveFirst ? approveAndPostPayout : postApprovedEntry;
    const result = await card.commit(fn, payoutId, { outcome: "posted", settle: approveFirst || (action && action.kind === "post") });
    if (approveFirst && result && !result.ok && result.approved === true) {
      setApprovedHere(true);
      if (onApproved) onApproved(result);
    }
  }
  const stood = card.phase === "failed" && card.result && card.result.approved === true;
  // THE LEDGER REFUSED IT OUTRIGHT (engine w3/int, W3-1): said in its own words, with no
  // retry, because the same entry would be refused the same way.
  const refusedByLedger = card.phase === "failed" && Boolean(card.result && card.result.ledgerRefusal);
  // REFUSED FOR ITS GST QUESTION (engine w37): the question rides on the refusal and is
  // asked here, with resolve breaks' own GST card and only the grounds the engine named.
  // No figure moves when it is answered: the approval stands and Post again posts.
  const gstQuestion = card.phase === "failed" && card.result ? card.result.gstQuestion || null : null;

  return (
    <Sheet
      open={open}
      onClose={onClose}
      side="modal"
      title={recording ? "Record this entry as posted?" : ledgerName ? `${postActionLabel(ledgerName, { draft })}?` : "Post this entry?"}
      className="post-sheet"
      footer={
        <>
          {postable && effect ? (
            <p className="sheet-foot-status post-effect" data-ledger-effect="">
              {effect}
            </p>
          ) : null}
          {postable && taxCodes ? (
            <p className="sheet-foot-status post-effect" data-ledger-tax-codes="">
              {taxCodes}
            </p>
          ) : null}
          <div className="sheet-actions">
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            {postable ? (
              <Button
                variant="commit"
                busy={card.busy}
                busyLabel={draft ? "Sending…" : "Posting…"}
                disabledReason={card.disabledReason}
                onClick={confirm}
                data-post-confirm=""
              >
                {recording ? `Record ${formatMoney(je.sumDr)} as posted` : postActionLabel(ledgerName, { draft, amount: formatMoney(je.sumDr) })}
              </Button>
            ) : null}
          </div>
        </>
      }
    >
      {postable ? (
        <>
          <p className="t-body">
            {recording
              ? `${approveFirst ? "This approves the entry in your name and records" : "This records"} it as posted in Vert, for ${clientName ? `${clientName}'s` : "your"} ${ledgerName} file. ${RECORDING_ONLY} ${REVERSE_WORDS}`
              : approveFirst
                ? `This approves the entry in your name and creates ${journal} in ${clientName ? `${clientName}'s` : "your"} ${ledgerName} file.${after} ${REVERSE_WORDS}`
                : `This creates ${journal} in ${clientName ? `${clientName}'s` : "your"} ${ledgerName} file.${after} ${REVERSE_WORDS}`}
          </p>
          {line ? <p className="t-footnote post-line">{line}</p> : null}
          <table className="post-journal">
            <thead>
              <tr>
                <th scope="col">Account</th>
                <th scope="col" className="num">Debit</th>
                <th scope="col" className="num">Credit</th>
              </tr>
            </thead>
            <tbody>
              {je.lines.map((l, i) => (
                <tr key={`${l.account}-${i}`}>
                  <td translate="no">{legAccount(l)}</td>
                  <td className="num">{l.dr ? formatMoney(l.dr) : ""}</td>
                  <td className="num">{l.cr ? formatMoney(l.cr) : ""}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr>
                <th scope="row">Total</th>
                <td className="num">{formatMoney(je.sumDr)}</td>
                <td className="num">{formatMoney(je.sumCr)}</td>
              </tr>
            </tfoot>
          </table>
          {unmappedNote(je) ? <p className="t-body" data-unmapped-note="">{unmappedNote(je)}</p> : null}
          {returnedNote(je) ? <p className="t-body" data-returned-note="">{returnedNote(je)}</p> : null}
        </>
      ) : (
        <p className="t-body">
          {!canPost(ledger)
            ? "No ledger is connected, so nothing can be posted from here."
            : "Vert couldn't read this entry's lines, so it can't be posted from here."}
        </p>
      )}
      {card.phase === "failed" && card.result && card.result.kind === "unconfirmed" ? (
        <Notice kind="warning" onRetry={card.writesEnabled ? card.retry : undefined} retryLabel="Check again">
          {failureSentence(card.result)}
        </Notice>
      ) : card.phase === "failed" ? (
        <Notice kind="error" recorded={recordedFor(card.result, stood ? "partial" : "nothing")} onRetry={card.writesEnabled && !refusedByLedger ? confirm : undefined} details={failureDetails(card.result)}>
          {stood && !refusedByLedger ? "Approved, but not posted yet. Post again when you're ready." : failureSentence(card.result)}
        </Notice>
      ) : null}
      {gstQuestion && payoutId ? (
        <div className="post-gst-question" data-post-gst-question="">
          <GstCard
            action={{
              kind: "gst",
              target: { id: payoutId, kind: "payout" },
              prefill: { payoutId, txnIds: gstQuestion.txnIds, scopeHash: gstQuestion.scopeHash },
              proposal: gstQuestion.proposal || "Is this sale taxable, or GST-free?",
              why: gstQuestion.account ? `The sale is coded to ${gstQuestion.account}. Answer it here, then post again.` : "Answer it here, then post again.",
            }}
            bases={gstQuestion.bases}
            ledgerName={ledgerName}
          />
        </div>
      ) : null}
    </Sheet>
  );
}
