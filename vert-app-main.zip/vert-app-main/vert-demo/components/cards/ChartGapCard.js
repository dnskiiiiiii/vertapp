"use client";

// components/cards/ChartGapCard.js — "NO ACCOUNT FITS"
// ==============================================================================
// Spec §5.3 row 4. Replaces ChartGapPanel.
//
// THE OTHER ANSWER TO "WHICH ACCOUNT?". Until it existed, a bookkeeper holding a line the
// chart had no home for could only answer nothing, which left the payout blocked forever
// and told nobody the chart was short. With the account pre-filled from a model's
// reading, "answer nothing" competes with a plausible suggestion and loses — so this is
// what makes the pre-fill safe to show.
//
// IT DOES NOT RESOLVE THE PAYOUT, and the collapsed line does not say it did: the engine
// re-runs and the payout stays blocked on the very question the gap is about, until the
// chart owner acts. The ground routes the work (three grounds, three different
// remedies), and the note is the part the chart owner reads, so both are required.
//
// Reached from the classification card's "No account fits", in place, or on its own
// when the engine proposes it (`kind: "chart_gap"`).

import { useState } from "react";
import { Button, Field, SelectField } from "@/components/ui";
import { recordChartGap } from "@/lib/actions";
import { CHART_GAP_GROUNDS, isKnownChartGapGround } from "@/lib/assertions";
import { useCardCommit } from "@/lib/decisions";
import Card from "./Card";
import DecisionLine from "./DecisionLine";
import Skip from "./Skip";
import { clearOnChange, missing, onBlurRequired, required } from "./validate";

export const CHART_GAP_MESSAGES = Object.freeze({
  basis: "Choose what is missing.",
  note: "Say what the line is, for whoever keeps the chart.",
});

export default function ChartGapCard({ action, onSettled, ledgerName = null, initial = null, onBack = null }) {
  const prefill = (action && action.prefill) || {};
  const payoutId = prefill.payoutId || (action.target && action.target.id) || null;
  const [basis, setBasis] = useState("");
  const [note, setNote] = useState("");
  const [errors, setErrors] = useState({});
  const card = useCardCommit(action, { onSettled, initial });

  if (card.phase === "done") {
    return (
      <DecisionLine
        kind="chart_gap"
        settled={card.settled}
        outcome={card.settled.outcome}
        note={card.settled.outcome === "declined" ? null : "The payout stays with you until the chart has an account for it."}
      />
    );
  }

  function press() {
    const next = missing({
      basis: [basis, CHART_GAP_MESSAGES.basis, isKnownChartGapGround],
      note: [note, CHART_GAP_MESSAGES.note],
    });
    setErrors(next);
    if (Object.keys(next).length) return;
    card.commit(recordChartGap, { payoutId, basis, note, txnIds: prefill.txnIds, scopeHash: prefill.scopeHash }, { outcome: "applied" });
  }

  return (
    <Card
      action={action}
      kind="chart_gap"
      ledgerName={ledgerName}
      proposal={action.kind === "chart_gap" ? undefined : "No account in the chart fits {{fig:amount}}?"}
      why={action.kind === "chart_gap" ? undefined : "Vert will hold it and tell whoever keeps the chart."}
      suggested={false}
      form={
        <>
          <SelectField
            label="What's missing"
            value={basis}
            placeholder="Choose one"
            error={errors.basis}
            onBlur={onBlurRequired(setErrors, "basis", CHART_GAP_MESSAGES.basis)}
            onChange={clearOnChange(setErrors, "basis", setBasis)}
            options={CHART_GAP_GROUNDS.map((g) => ({ value: g.value, label: g.label }))}
          />
          <Field
            label="What is this line?"
            value={note}
            error={errors.note}
            validate={required(CHART_GAP_MESSAGES.note)}
            onChange={clearOnChange(setErrors, "note", setNote)}
          />
        </>
      }
      failure={card.phase === "failed" ? card.result : null}
      onRetry={card.phase === "failed" && card.writesEnabled ? card.retry : undefined}
      actions={
        <>
          <Button variant="commit" onClick={press} busy={card.busy} busyLabel="Reporting…" disabledReason={card.disabledReason}>
            Report that no account fits
          </Button>
          {onBack ? (
            <Button variant="quiet" onClick={onBack}>
              Choose an account instead
            </Button>
          ) : (
            <Skip action={action} card={card} />
          )}
        </>
      }
    />
  );
}
