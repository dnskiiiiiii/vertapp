"use client";

// components/cards/UseDepositCard.js — "USE THIS DEPOSIT", IN ONE PRESS
// ==============================================================================
// Spec §5.3 row 1; audit UI-018. Replaces BankPinPanel, CandidateList and the
// proposal's separate Accept/Dismiss.
//
// THE DEFECT IT ENDS. The agent could read the statement and name the deposit, and the
// prominent control beside that reading (Accept) did nothing to the close, while the
// control that did (Record pin) sat below it with both radios blank. The person had to
// re-type the model's answer by hand — about seven presses to apply one suggestion.
// Here the suggestion IS the card: the deposit, the ground and a note arrive pre-filled
// from the engine's `prefill` (resolve_breaks builds it with the same digest the route
// checks), and one press records it through the existing bank-pin route.
//
// WHAT STAYS FIRM.
//   · A model's reading carries the one mark, "Vert's best guess: check this", and only
//     while the deposit shown is the one it chose (`basis === "suggested"`). Pick another
//     and the mark goes, because the choice is now yours.
//   · The ground is evidence, not decoration. A suggestion arrives with the ground the
//     model named; a deposit you picked arrives with none, and the press asks for one on
//     the field (validate on the field, never a disabled button with no reason, UI-015).
//   · The note is pre-filled with the reason on the card and is yours to edit under
//     Details. It is what an auditor reads beside the pin.
//   · The route re-checks everything: the deposit must be one the engine offered, and the
//     digest must match the deposits the card was drawn from, or it answers 409 and
//     nothing is recorded.

import { useState } from "react";
import { Button, Field, FigureInText, SelectField } from "@/components/ui";
import { recordBankPin } from "@/lib/actions";
import { BANK_PIN_GROUNDS, isKnownPinGround } from "@/lib/assertions";
import { useCardCommit } from "@/lib/decisions";
import { useEngine } from "@/lib/engine-context";
import { bankLineLabel } from "@/lib/format";
import Card from "./Card";
import DecisionLine from "./DecisionLine";
import Skip from "./Skip";
import { actWords, depositChoiceLabel } from "./words";

export const PIN_GROUND_MESSAGE = "Choose how you know it's this deposit.";

/** The deposits the engine itself offered for this payout, from the payload. Empty
 *  when the payload carries no tie for it: "Pick another" is then not offered, because
 *  a control is not listed unless it works (spec §1.9). */
export function depositCandidates(engine, payoutId) {
  const recon = engine && engine.reconciliations && engine.reconciliations[payoutId];
  const ids = recon && recon.tie && Array.isArray(recon.tie.candidates) ? recon.tie.candidates : [];
  const lines = engine && Array.isArray(engine.bankLines) ? engine.bankLines : [];
  return ids.map((id) => lines.find((l) => l && l.id === id)).filter(Boolean);
}

export default function UseDepositCard({ action, onSettled, ledgerName = null, initial = null }) {
  const engine = useEngine();
  const prefill = (action && action.prefill) || {};
  const payoutId = prefill.payoutId || (action.target && action.target.id) || null;
  const candidates = depositCandidates(engine, payoutId);
  const suggestedLine = prefill.bankLineId || "";

  const [bankLineId, setBankLineId] = useState(suggestedLine);
  const [picking, setPicking] = useState(false);
  const [basis, setBasis] = useState(isKnownPinGround(prefill.basis) ? prefill.basis : "");
  const [note, setNote] = useState(
    typeof prefill.note === "string" && prefill.note.trim()
      ? prefill.note
      : typeof action.why === "string" && !/\{\{/.test(action.why)
        ? `Used this deposit. ${action.why}`
        : "Used this deposit."
  );
  const [basisError, setBasisError] = useState(null);
  const card = useCardCommit(action, { onSettled, initial });

  const chosenIsSuggestion = bankLineId === suggestedLine;
  const chosen = candidates.find((l) => l.id === bankLineId) || null;

  if (card.phase === "done") {
    // The deposit USED: the suggested one's own figure, and the generic words when the
    // person picked another (its amount is on the picker, not in the action's figures).
    const what = bankLineId === suggestedLine ? actWords("bank_pin", action) : null;
    return <DecisionLine kind="bank_pin" settled={card.settled} outcome={card.settled.outcome} what={what} />;
  }

  function press() {
    if (!isKnownPinGround(basis)) {
      setBasisError(PIN_GROUND_MESSAGE);
      return;
    }
    card.commit(
      recordBankPin,
      { payoutId, bankLineId, basis, note, scopeHash: prefill.scopeHash },
      { outcome: "applied" }
    );
  }

  function pick(id) {
    setBankLineId(id);
    // A ground the model named was about ITS deposit. A different deposit needs yours.
    if (id !== suggestedLine) setBasis("");
    else setBasis(isKnownPinGround(prefill.basis) ? prefill.basis : "");
  }

  // The ground is asked for unless the deposit shown is the suggestion AND the
  // suggestion arrived with a ground the route accepts.
  const needsGround = !(chosenIsSuggestion && isKnownPinGround(prefill.basis));
  const form =
    picking || needsGround ? (
      <>
        {picking && candidates.length > 1 ? (
          <SelectField
            label="Deposit"
            value={bankLineId}
            onChange={(e) => pick(e.target.value)}
            options={candidates.map((l) => ({ value: l.id, label: depositChoiceLabel(l) }))}
          />
        ) : null}
        {needsGround ? (
          <SelectField
            label="How do you know?"
            value={basis}
            placeholder="Choose one"
            error={basisError}
            onBlur={(e) => {
              // Validated on leaving the field, not only on the press (validate.js).
              if (!isKnownPinGround(e.target.value)) setBasisError(PIN_GROUND_MESSAGE);
            }}
            onChange={(e) => {
              setBasis(e.target.value);
              setBasisError(null);
            }}
            options={BANK_PIN_GROUNDS.map((g) => ({ value: g.value, label: g.label }))}
          />
        ) : null}
      </>
    ) : null;

  const proposal = chosenIsSuggestion || !chosen ? undefined : `Use the deposit of ${depositChoiceLabel(chosen)}?`;

  return (
    <Card
      action={action}
      kind="bank_pin"
      ledgerName={ledgerName}
      proposal={proposal}
      why={chosenIsSuggestion ? undefined : "You picked it."}
      suggested={action.basis === "suggested" && chosenIsSuggestion}
      form={form}
      failure={card.phase === "failed" ? card.result : null}
      onRetry={card.phase === "failed" && card.writesEnabled ? card.retry : undefined}
      actions={
        <>
          <Button variant="commit" onClick={press} busy={card.busy} busyLabel="Using…" disabledReason={card.disabledReason}>
            {(action.commitLabel && !/\{\{/.test(action.commitLabel) && action.commitLabel) || "Use this deposit"}
          </Button>
          {candidates.length > 1 && !picking ? (
            <Button variant="quiet" onClick={() => setPicking(true)}>
              Pick another
            </Button>
          ) : null}
          <Skip action={action} card={card} />
        </>
      }
      details={
        <>
          {chosen ? (
            <p className="dcard-detail t-footnote">
              <FigureInText text={bankLineLabel(chosen)} cents={chosen.amount} figure={`bank/${chosen.id}/amount`} />
            </p>
          ) : null}
          <Field label="Note for the record" value={note} onChange={(e) => setNote(e.target.value)} />
        </>
      }
    />
  );
}
