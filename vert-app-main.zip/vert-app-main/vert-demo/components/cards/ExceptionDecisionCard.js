"use client";

// components/cards/ExceptionDecisionCard.js — A DECISION ON ONE SETTLEMENT EXCEPTION
// ==============================================================================
// Spec §5.3 row 9. Replaces the decisions in ExceptionDetailRail.
//
// The commit is named by the outcome the engine proposed (`commitLabel`), never
// "Submit". A reason is required, because the exception queue records a decision as an
// append beside the engine's own verdict, and the reason is what makes a dismissal a
// decision rather than a delete. Nothing is posted by it.

import { useState } from "react";
import { Button, Field } from "@/components/ui";
import { recordExceptionDecision } from "@/lib/actions";
import { useCardCommit } from "@/lib/decisions";
import Card from "./Card";
import DecisionLine from "./DecisionLine";
import Skip from "./Skip";
import { required } from "./validate";
import { boundLabel } from "./words";

export const EXCEPTION_REASON_MESSAGE = "Say why, in a line. It goes on the record.";

export default function ExceptionDecisionCard({ action, onSettled, ledgerName = null, initial = null }) {
  const prefill = (action && action.prefill) || {};
  const exceptionId = prefill.exceptionId || (action.target && action.target.id) || null;
  const [note, setNote] = useState(typeof prefill.note === "string" ? prefill.note : "");
  const [error, setError] = useState(null);
  const card = useCardCommit(action, { onSettled, initial });
  const label = boundLabel(action.commitLabel, action.figures, ledgerName);

  if (card.phase === "done") return <DecisionLine kind="exception_decision" settled={card.settled} outcome={card.settled.outcome} />;

  function press() {
    if (!note.trim()) {
      setError(EXCEPTION_REASON_MESSAGE);
      return;
    }
    card.commit(recordExceptionDecision, { exceptionId, state: prefill.state, note }, { outcome: "applied" });
  }

  return (
    <Card
      action={action}
      kind="exception_decision"
      ledgerName={ledgerName}
      form={
        <Field
          label="Why?"
          value={note}
          error={error}
          validate={required(EXCEPTION_REASON_MESSAGE)}
          onChange={(e) => {
            setNote(e.target.value);
            setError(null);
          }}
        />
      }
      failure={card.phase === "failed" ? card.result : null}
      onRetry={card.phase === "failed" && card.writesEnabled ? card.retry : undefined}
      actions={
        <>
          {label && prefill.state ? (
            <Button variant="commit" onClick={press} busy={card.busy} busyLabel="Saving…" disabledReason={card.disabledReason}>
              {label}
            </Button>
          ) : (
            <p className="dcard-reason t-footnote">Vert didn't say what this decision would record, so it can't be made here.</p>
          )}
          <Skip action={action} card={card} />
        </>
      }
    />
  );
}
