// components/cards/words.js — WHAT A DECISION CARD SAYS, AS PURE FUNCTIONS
// ==============================================================================
// Spec §5 and §13. A card leads with the transaction, says one sentence, gives one
// reason and offers one commit whose label says what happens. Every sentence a card
// can say on its own authority is built here, from the event's own fields and the
// engine's own cents, so a test can read all of it without a browser.
//
// NOTHING HERE DOES ARITHMETIC ON MONEY. A figure is an engine integer in cents that
// is turned into a string by lib/format.js and nothing else. A figure the engine did
// not measure is said in words; a label that would need one is not drawn with a
// guess in it.
//
// NO ID REACHES A SENTENCE. Payout ids, bank-line ids and action ids live in `target`,
// `prefill` and `actionId`, and are drawn only under Details (spec §1.6, §13.6). The
// transaction line reads source, date and cents and nothing else (lib/format.js
// payoutLine).

import { bindFigures, withLedger } from "@/lib/agent/events";
import { MONTHS_LONG, approverLabel, formatDate, formatDay, formatMoney, metaLine, moneyOrWords, payoutLine, sourceName } from "@/lib/format";
import { dutyRefusalSentence } from "@/lib/roles";

/**
 * The sentence a card's disabled commit carries in a build with nothing behind it.
 * Shorter than lib/engine-context.js READ_ONLY_REASON and in a bookkeeper's words (spec
 * §9.5, §13): that sentence names an export, an engine and an API, which is operator
 * vocabulary the agent workspace keeps off the main path.
 */
export const SAMPLE_REASON = "This is a sample month, so nothing here can be recorded.";

/** Whether an event figure carries a measured engine amount. */
export function isRead(figure) {
  return Boolean(figure && typeof figure.cents === "number" && Number.isFinite(figure.cents) && figure.measured !== false);
}

/**
 * Event text with its `{{fig:ref}}` placeholders bound to the event's own figures and
 * `{{ledger}}` named, as ONE STRING — for a button label, which cannot hold a figure
 * button inside it. Returns null when any placeholder names a figure the event did not
 * carry or did not measure: a commit label with "not read yet" in it would promise a
 * write of an amount nobody has, so the caller draws the card without that commit.
 */
export function boundLabel(text, figures, ledgerName) {
  if (typeof text !== "string" || !text.trim()) return null;
  const parts = bindFigures(withLedger(text, ledgerName), figures);
  let out = "";
  for (const part of parts) {
    if (part.t === "text") out += part.v;
    else if (isRead(part.figure)) out += formatMoney(part.figure.cents);
    else return null;
  }
  return out.replace(/\s+/g, " ").trim();
}

/** "Stripe payout · 2 Jul · $7,000.00", or null for a card with no transaction line. */
export function lineFor(action) {
  const line = action && action.line;
  if (!line || typeof line !== "object") return null;
  const source = SOURCE_KIND[line.source] || line.source;
  try {
    return payoutLine({ ...line, source });
  } catch {
    // A date the formatter refuses is left out rather than invented.
    return payoutLine({ source, cents: line.cents, measured: line.measured });
  }
}

/**
 * A waiting plan's closed row: "Balance sheet roll-forwards plan · July 2026", the words
 * PlanCard's planCardLine gives the open card (kept here so this module imports no card).
 * Pure.
 */
export function planRowLine(action) {
  const a = action && typeof action === "object" ? action : {};
  const plan = a.plan && typeof a.plan === "object" ? a.plan : null;
  const named = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
  const name = named(a.taskTitle) || named(plan && plan.taskTitle);
  const period = (plan && plan.scope && plan.scope.period) || a.period || null;
  const m = /^(\d{4})-(\d{2})$/.exec(String(period || ""));
  const month = m && Number(m[2]) >= 1 && Number(m[2]) <= 12 ? `${MONTHS_LONG[Number(m[2]) - 1]} ${m[1]}` : null;
  return [name ? `${name} plan` : "A plan", month].filter(Boolean).join(" · ");
}

/**
 * The one line a decision reads as while it waits CLOSED: the conversation opens only
 * its first undecided card and draws the rest as this line, so a view never shows more
 * than one purple commit (PR8, eval S5, 2 Oct). "Stripe payout · 9 Jul · $6,000.00 —
 * Check the bank again?" for a payout card; "July rent · $4,000.00" for a drafted
 * entry, whose memo is its title and whose total is the engine's (never summed here).
 * Figures are bound from the event's own `figures`; a figure nobody read leaves the
 * proposal out rather than printing a zero. Never an id.
 */
export function closedLine(action, ledgerName = null) {
  const a = action && typeof action === "object" ? action : {};
  const je = a.je && typeof a.je === "object" ? a.je : null;
  if (je) {
    const memo = typeof je.memo === "string" && je.memo.trim() ? je.memo.trim() : "Draft entry";
    const t = je.totals;
    const total = t && Number.isInteger(t.debitCents) && t.debitCents === t.creditCents ? formatMoney(t.debitCents) : null;
    return [memo, total].filter(Boolean).join(" · ");
  }
  // A plan names itself, never the engine's bare "Start this plan?" (verify pass 10
  // F12): closed, that question had no way to answer it on the row (PlanCard's rule).
  if (a.kind === "plan") return planRowLine(a);
  const line = lineFor(a);
  const proposal = boundLabel(a.proposal, a.figures, ledgerName);
  return [line, proposal].filter(Boolean).join(": ") || "A decision";
}

// The engine's source kinds that are not the processor's plain name. "shopify_payments"
// is how the register stores a Shopify payout; a bookkeeper reads "Shopify payout".
const SOURCE_KIND = { shopify_payments: "shopify", stripe_connect: "stripe" };

/** A bank line as a person picks it: "$8,640.00 · 11 Jun". The bank's own text is left
 *  to Details, because a statement descriptor can quote a payout reference. */
export function depositChoiceLabel(line) {
  const parts = [moneyOrWords({ cents: line && line.amount, measured: true }, "amount not available yet")];
  if (line && typeof line.date === "string" && line.date) {
    try {
      parts.push(formatDay(line.date));
    } catch {
      /* no date is better than a wrong one */
    }
  }
  return metaLine(parts);
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * The collapsed line (spec §5.2 "Success"; UI-012, UI-024)
 * ══════════════════════════════════════════════════════════════════════════ */

const PAST = {
  bank_pin: "Used this deposit",
  gst: "Saved the GST treatment",
  txn_class: "Saved the account",
  chart_gap: "Reported that no account fits",
  approve: "Approved",
  approve_many: "Approved",
  reject: "Rejected",
  post: "Posted",
  withdraw: "Approval withdrawn",
  exception_decision: "Decided",
  sync: "Sync started",
  prepaid_agree: "Agreed the schedule",
  question: "Answered",
};

/**
 * The one line a card collapses to: what happened, who, when. NEVER BLANK (UI-024):
 * who comes from lib/format.js `approverLabel` — the actor the API recorded, then the
 * signed-in person, then "you" — and the time is added when there is one. It is never
 * the access key's label: "key: founder test approved it" was what the conversation
 * printed on every decision (eval S6 / C8, 30 Sep), because that line read `settled.by`
 * raw. Both surfaces now draw this one line (`settledDecisionLine` for the thread).
 *
 * `amount` is an already formatted engine figure ("$9,350.73") or null. When the API's
 * read-back did not confirm the write, the line says so rather than claiming it: a
 * card that trusted its own press would show "Approved" over a write that never
 * landed (plan §2.7).
 *
 * `signedIn` and `account` are the viewer's actor and the account's display name, for
 * the chain's second and third links. `what`, when given, replaces the kind's generic
 * past tense with the specific act ("Used the $7,000.00 deposit").
 */
export function doneLine(kind, settled, { amount = null, outcome = null, signedIn = null, account = null, what: specific = null } = {}) {
  const s = settled && typeof settled === "object" ? settled : {};
  let what = specific || PAST[kind] || "Decided";
  if (outcome === "declined" || s.outcome === "declined") what = "Skipped";
  // Every item of a batch refused: nothing was decided in the books, so the line must
  // not open with a past-tense "Approved" (ApproveManyCard; G1, 2026-09-30).
  if (outcome === "refused") what = "Nothing approved";
  // SUPERSEDED IS NOT A DECISION (eval r2 WB8 / C8, 3 Oct). When a later list or run
  // replaces an action, the API settles the old one with outcome "superseded" and
  // `by: "vert"`. Drawn through the approve past tense, that read "Approved $506,615.64
  // · vert" over half a million dollars nobody approved. The line names what happened
  // and nothing else: no amount (nothing was decided for it) and no actor (nobody acted).
  if (outcome === "superseded" || s.outcome === "superseded") return supersededLine(kind);
  const head = amount ? `${what} ${amount}` : what;
  let who;
  try {
    who = approverLabel({ recorded: s.by, signedIn, account, at: typeof s.at === "string" ? s.at : undefined });
  } catch {
    // An instant the formatter refuses is left out rather than invented; the who stays.
    who = approverLabel({ recorded: s.by, signedIn, account });
  }
  const parts = [head, who];
  if (s.verified === false && s.outcome !== "declined") parts.push("Vert couldn't confirm it was recorded yet");
  return metaLine(parts);
}

/** The words for an action a later one replaced: never "Approved", never an actor. */
export function supersededLine(kind) {
  return kind === "approve_many" ? "Replaced by a later list" : "Replaced by a later run";
}

// A settled outcome as the API records it, mapped to the kind whose past tense names it.
// The thread's `decision_settled` carries the outcome of the ACT (a withdrawn approval
// is settled on the approve card's action), so the kind comes from the outcome first.
const OUTCOME_KIND = { withdrawn: "withdraw", withdraw: "withdraw", rejected: "reject", reject: "reject", posted: "post", post: "post" };

/**
 * The line a decision in the CONVERSATION collapses to — the same line Month-end draws
 * for the same decision, from the card's own kind and figures, so a decision reads the
 * same in both places (spec §4.2 row 5) and never with a key label in it.
 */
export function settledDecisionLine(action, settled, { signedIn = null, account = null, ledgerName = null } = {}) {
  const a = action && typeof action === "object" ? action : {};
  const s = settled && typeof settled === "object" ? settled : {};
  const kind = OUTCOME_KIND[s.outcome] || a.kind || null;
  const figures = a.figures || {};
  const money = [figures.entry, figures.total, figures.amount].find(isRead);
  const amount = (kind === "approve" || kind === "approve_many" || kind === "post") && money ? formatMoney(money.cents) : null;
  // A post says what the ledger holds of it, when the settle recorded it (p1/fix5).
  const held = kind === "post" ? ledgerStatusOf(s.posted) : null;
  if (held) {
    const lead = ledgerStatusLead(held, ledgerName);
    return doneLine(kind, s, { signedIn, account, what: amount ? `${lead} · ${amount}` : lead });
  }
  return doneLine(kind, s, { amount, signedIn, account, what: actWords(kind, a) });
}

// "Used the $7,000.00 deposit" when the card carried the deposit's measured amount;
// the generic past tense otherwise. The deposit's own figure, not the bank's text,
// which can quote a payout reference (spec §13.6).
export function actWords(kind, action) {
  if (kind !== "bank_pin") return null;
  const deposit = action && action.figures && action.figures.deposit;
  return isRead(deposit) ? `Used the ${formatMoney(deposit.cents)} deposit` : null;
}

/**
 * Whether a settled decision can still be undone from its line: an approval that is
 * the latest decision and has not posted (plan §0.10, spec §5.2; W12). The API says so
 * with `undo` on the settlement when it knows; otherwise an approved approve card is.
 */
export function canUndo(action, settled) {
  const s = settled && typeof settled === "object" ? settled : {};
  if (s.undo && typeof s.undo === "object") return s.undo.kind === "withdraw";
  return Boolean(action && action.kind === "approve" && (s.outcome === "approved" || s.outcome === "approve"));
}

/**
 * What the books say NOW about an approval line, from the API's recorded state of its
 * payout (lib/feeds.js payoutStateFor): `null` when nothing is recorded (the sample
 * build; the line's own outcome stands), "stands" while the record is still approved,
 * "posted" once it posted, else "gone" (withdrawn, rejected, blocked, redrafted).
 *
 * WHY (eval r2 C11 / C8, 3 Oct): an approved line kept offering Undo and "Post to
 * QuickBooks…" after its approval was undone and the entry then posted — beside the
 * "Posted $41,855.00" line for the same entry. A settled line is re-derived from the
 * record, not from the moment it was settled.
 */
export function approvalNow(recorded) {
  if (!recorded || typeof recorded !== "object" || typeof recorded.status !== "string") return null;
  if (recorded.status === "approved") return "stands";
  if (recorded.status === "posted") return "posted";
  return "gone";
}

/** The note under a settled approval the record has since moved past, or null. */
export function approvalNowNote(now) {
  if (now === "posted") return "Posted since.";
  if (now === "gone") return "This approval no longer stands.";
  return null;
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * Gross and net (eval iter1 final N10 and finding 13)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * Whether an entry's total and its payout's amount are two different figures on the
 * card: "Stripe payout · 3 Jun · $13,322.12" over "Approve $13,720.00". Both are the
 * engine's — the payout is what reached the bank, NET of the processor's fees; the entry
 * is the sales it books, GROSS — and a card that prints both without saying so reads as
 * an error. Compared, never subtracted: the page states the two figures and what each
 * is, and the difference is left to the entry's lines under Details.
 */
export function entryDiffersFromPayout(entry, line) {
  if (!isRead(entry) || !line || typeof line !== "object") return false;
  if (line.measured === false || typeof line.cents !== "number" || !Number.isFinite(line.cents)) return false;
  return entry.cents !== line.cents;
}

/**
 * A journal leg's account as the chart names it: "4000 · Sales" when the engine
 * resolved the leg to a numbered chart account (`accountRef`), else the leg's own words.
 */
export function legAccount(line) {
  // The chart's own words first (F18, ENG-RECS-e2): `accountLabel` is "1020 · Business
  // Cheque", or the leg's own words when the leg is on no chart.
  if (line && typeof line.accountLabel === "string" && line.accountLabel.trim()) return line.accountLabel.trim();
  const ref = line && line.accountRef;
  // A chart number is paired only with the chart's own name, never with the engine's
  // leg ("1020 · Stripe Clearing" named an account the chart doesn't hold).
  if (ref && ref.number && ref.name) return `${ref.number} · ${ref.name}`;
  return line ? line.account : "";
}

/** The entry's unmapped legs, in the engine's words, or null when every leg is mapped. */
export function unmappedNote(je) {
  if (!je || !Array.isArray(je.unmapped) || je.unmapped.length === 0) return null;
  return je.unmappedNote || null;
}

/** Why Vert is asking again (verify pass 9, ENG-JE: the approval was taken back because
 *  the accounts moved), as the engine wrote it, or null. A plain sentence that never
 *  blocks the commit, unlike unmappedNote. */
export function returnedNote(je) {
  const note = je && typeof je.returnedNote === "string" ? je.returnedNote.trim() : "";
  return note || null;
}

/** The approve card's reason when the two differ: 15 words, inside the 25 (spec §5.1). */
export const GROSS_NET_WHY = "It matches the bank. The entry is {{fig:entry}} gross, before fees; the payout is net.";

/** The approve-many list's one caption when any line differs. */
export const GROSS_NET_CAPTION = "Payouts are net of fees; each entry is gross, before them.";

/* ══════════════════════════════════════════════════════════════════════════ *
 * A press that did not land (spec §5.2 "Failure"; UI-002)
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * The sentence under a card whose press failed. Always says whether anything reached
 * the books — every refusal here was refused BEFORE anything was written, so it is
 * "Nothing was recorded" (the Notice adds that clause). The API's own message and
 * code go under Details, where an engineer looks: a 409's sentence can quote a
 * payout reference, which the card's face never shows.
 *
 * KEYED ON THE CODE, NOT THE KIND. "unavailable" is two different facts: the static
 * build with no API behind it (a sample month — nothing CAN be sent), and a live
 * deployment with no sync worker (`no_worker_configured`). Mapping the kind told a
 * live tenant "This is a sample month" about their own books (eval C6, 30 Sep). The
 * sample-month sentence is now said only for the static build's own code.
 *
 * `source` names what a sync would have read ("stripe"), when the card knows.
 */
// The "what was recorded" sentences the engine ends a refusal with. The Notice says
// what was recorded itself (components/ui/Notice.js RECORDED_WORDS), so these are not
// said twice.
const RECORDED_TAIL = /\s*Nothing (?:was|has been) (?:recorded|changed|written)\.\s*/g;

/**
 * THE ENGINE'S OWN REASON FOR A REFUSAL, when it is written for the person (D02, D22,
 * D10e). The engine words its refusals for the bookkeeper ("Not on your chart: Stripe
 * Clearing … Redraft the entry to accounts on the client's chart"); the card used to
 * say only "Vert refused this." and hide that under Details, so the one sentence that
 * said what to do was never read. Null when there is no such sentence: an unreachable
 * service, a 401/422 (the request's own shape), a body that was not the engine's
 * (no envelope), or words meant for whoever runs the server. Pure.
 */
/**
 * What the post sheet says about undoing a post (P24/D10). The ledger has no draft
 * state, so a post is in the books at once; and the posted card offers Reverse, which
 * drafts a reversing entry through Vert. "You can reverse it there, not here" was said
 * beside a card that offered exactly that here.
 */
export const REVERSE_WORDS = "You can undo it later: Reverse drafts a reversing entry for approval.";

/**
 * WHAT A LEDGER THAT HOLDS DRAFTS DOES WITH THE POST (16 Oct 2026: Xero, the first
 * ledger). A journal sent there arrives as a DRAFT and somebody inside the ledger
 * approves it before it reaches the reports, so the press here is not the last gate.
 * Said only when the API's `createsDraft` is true (lib/ledger-shape.js `holdsAsDraft`),
 * with the ledger's own name, so no vendor is spelled here and QuickBooks — which has
 * no draft state — can never be promised one. Pure.
 */
export function draftWords(ledgerName) {
  const name = typeof ledgerName === "string" && ledgerName.trim() ? ledgerName.trim() : "your ledger";
  return `It arrives in ${name} as a draft, and someone in ${name} approves it before it reaches your reports.`;
}

/**
 * THE POST ACTION'S LABEL (17 Oct 2026), and the one place it is worded. Driven by the
 * ledger's `createsDraft` (lib/ledger-shape.js `holdsAsDraft`), never by its name:
 * "Post to <ledger>" when the ledger posts what it receives — QuickBooks, and Xero on its
 * default since the founder's decision — and "Send to <ledger> as draft" when it holds it
 * for someone there to approve. `amount` names the figure on a confirm that carries one
 * ("Post $4,000.00 to Xero"). No call site writes "Post to" itself. Pure.
 */
export function postActionLabel(ledgerName, { draft = false, amount = null } = {}) {
  // A RECORDING LEDGER IS NAMED BY ITS PLATFORM (verify pass 5, Q-SHAPE-4): "QuickBooks
  // Online (recording, nothing is sent)" is worded "Post to QuickBooks Online", the note
  // dropped from the button (the posting-effect line beside it says nothing is sent).
  // Every call site used to special-case recording into a bare "Approve and post", so the
  // card named no ledger; the rule now lives here once. A recording ledger holds no draft.
  const split = splitLedgerName(typeof ledgerName === "string" ? ledgerName : "");
  const name = split.name ? split.name : "your ledger";
  if (split.recording) draft = false;
  const what = typeof amount === "string" && amount.trim() ? amount.trim() : null;
  if (draft) return what ? `Send ${what} to ${name} as draft` : `Send to ${name} as draft`;
  return what ? `Post ${what} to ${name}` : `Post to ${name}`;
}

/**
 * THE DRAFT'S ONE COMMIT, NAMING THE LEDGER (answer shape, founder 17 Oct 2026): "Approve
 * and post to QuickBooks", "Approve and send to Xero as draft". The same wording rule as
 * `postActionLabel`, of which it is the approving form, so the two can never disagree.
 * Pure.
 */
export function approveActionLabel(ledgerName, { draft = false } = {}) {
  const post = postActionLabel(ledgerName, { draft });
  return `Approve and ${post.charAt(0).toLowerCase()}${post.slice(1)}`;
}

/** The posted plate's line for an entry that is a draft in its ledger. Pure. */
export function draftPostedWords(ledgerName) {
  const name = typeof ledgerName === "string" && ledgerName.trim() ? ledgerName.trim() : "your ledger";
  return `In ${name} as a draft: it reaches your reports once someone approves it there.`;
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * WHAT THE LEDGER HOLDS OF A POSTED ENTRY (p1/fix5, 27 Oct 2026)
 *
 * Vert's `posted` means "handed to the ledger". On a client posting to Xero in draft
 * mode the ledger holds a DRAFT, out of its trial balance until someone approves it
 * there; journals 41, 44 and 34 on staging were exactly that, and every screen said
 * "Posted". The engine now sends, beside Vert's state, `ledgerStatus` ("draft" |
 * "posted" | "recorded" | null) from what the ledger answered. Only its two words are
 * said here; anything else (a recording ledger, an older engine) keeps today's "Posted".
 * The ledger is named by the API's display name, never a vendor written in.
 * ══════════════════════════════════════════════════════════════════════════ */

const LEDGER_STATES = new Set(["draft", "posted"]);

/** The first `ledgerStatus` among `sources` that is "draft" or "posted", else null. Pure. */
export function ledgerStatusOf(...sources) {
  for (const s of sources) {
    const v = s && typeof s === "object" ? s.ledgerStatus : null;
    if (typeof v === "string" && LEDGER_STATES.has(v)) return v;
  }
  return null;
}

function ledgerNameOf(ledgerName) {
  return splitLedgerName(ledgerName).name || "your ledger";
}

/**
 * The words that open a posted entry's status: "Sent to Xero as a draft · approve it in
 * Xero to post", "Posted in Xero", or — with no ledger state said — "Posted". Pure.
 */
export function ledgerStatusLead(status, ledgerName = null, { numbered = true } = {}) {
  const name = ledgerNameOf(ledgerName);
  if (status === "draft") return `Sent to ${name} as a draft · approve it in ${name} to post`;
  if (status === "posted") return `Posted in ${name}`;
  // A POSTED CARD WITH NO NUMBER NAMES ITS LEDGER (engine w3/int, walk 1 D17): a Xero
  // manual journal has no number, so the engine's card carries `ledgerName` instead.
  if (!numbered && splitLedgerName(ledgerName).name) return `Posted in ${name}`;
  return "Posted";
}

/** The status tone the lead is drawn in: a draft waits on someone in the ledger. Pure. */
export function ledgerStatusTone(status) {
  return status === "draft" ? "attention" : "done";
}

/** A row's short term for the post act: "Sent to Xero as a draft", "Posted in Xero", "Posted". Pure. */
export function ledgerStatusTerm(status, ledgerName = null) {
  if (status === "draft") return `Sent to ${ledgerNameOf(ledgerName)} as a draft`;
  return ledgerStatusLead(status, ledgerName);
}

/** A settle the engine could not verify (P30): the card stays open and says so. */
export const UNCONFIRMED_SENTENCE = "Vert couldn't confirm this yet. Nothing was counted as decided.";

/**
 * A WRITE WHOSE ANSWER NEVER CAME (staging browser walk 2, N3): the engine may have done
 * it, so the card never says "nothing was recorded" over it. The same words as
 * lib/engine-source.js MAY_HAVE_GONE_THROUGH (a server module this file can't import).
 */
export const TIMEOUT_SENTENCE = "May have gone through.";

/**
 * What a failed press's Notice says was recorded: "unconfirmed" for a write whose answer
 * never came (or whose read-back failed), else the card's own `fallback`. Pure.
 */
export function recordedFor(failure, fallback = "nothing") {
  return failure && failure.kind === "unconfirmed" ? "unconfirmed" : fallback;
}

/**
 * AN ENGINE SENTENCE, SAID AS THE APP SAYS THINGS (UI walk 2, N1/N2, 30 Oct 2026). The
 * engine's refusals can carry an entry's stored id ("Journal entry 'je:c2969e66407c' was
 * not posted…") and ISO dates ("The date 2026-11-30 is not in October 2026"). On a
 * screen the entry is the one being looked at, so it is "this entry", and a date is the
 * house's "30 Nov 2026" (lib/format.js formatDate). Nothing else is changed. Pure.
 */
const ENTRY_REF = /(?:\b(?:[Jj]ournal entry|[Ee]ntry)\s+)?['"\u2018\u2019]?\b[a-z]{1,16}:[0-9a-f]{6,64}\b['"\u2019]?/g;
const ISO_DAY_IN_TEXT = /\b(\d{4}-\d{2}-\d{2})\b/g;

export function plainRefusalWords(text) {
  if (typeof text !== "string" || !text) return text;
  return text
    .replace(ENTRY_REF, (_, offset, whole) => (/^\s*$|[.!?]\s*$/.test(whole.slice(0, offset)) ? "This entry" : "this entry"))
    .replace(ISO_DAY_IN_TEXT, (day) => {
      try {
        return formatDate(day);
      } catch {
        return day;
      }
    });
}

export function engineReason(result) {
  const r = result && typeof result === "object" ? result : {};
  if (r.kind !== "refused" && r.kind !== "blocked") return null;
  const status = Number.isInteger(r.status) ? r.status : 0;
  // A 422 is a body the engine couldn't take, written for the client that sent it,
  // EXCEPT the draft it refused naming each problem (`detail.problems`, its DraftRefused:
  // "090 · Business Bank Account is a bank account, and Xero takes no manual journal
  // line…", engine w3/int W3-1): that sentence is the person's.
  const named = status === 422 && Array.isArray(r.problems) && r.problems.length > 0;
  if (status < 400 || status >= 500 || status === 401 || (status === 422 && !named)) return null;
  const message = typeof r.message === "string" ? r.message.trim() : "";
  if (!message || message.length > 600) return null;
  if (message === r.code) return null;
  // `detail.errors`: the engine's 400 for a body that didn't validate (vert_api/errors.py
  // validation_handler) is written for the client that sent it, not the person.
  if (OPERATOR_TEXT.test(message) || /\bHTTP\b|https?:\/\/|\b(?:POST|GET|PATCH) \/|[{}<>]|error envelope|\bdetail\.[a-z]/.test(message)) return null;
  if (!/[.!?]$/.test(message)) return null;
  const words = plainRefusalWords(message.replace(RECORDED_TAIL, " ").replace(/\s+/g, " ").trim());
  return words || null;
}

export function failureSentence(result, { source = null } = {}) {
  const r = result && typeof result === "object" ? result : {};
  // A refusal about who may do this (§20.12 H3, M4) says why, not "Vert refused this."
  const duty = dutyRefusalSentence(r);
  if (duty) return duty;
  // The ledger refused the post outright: its own reasons, never "Vert's checks".
  const ledger = ledgerRefusalSentence(r);
  if (ledger) return ledger;
  if (r.code === "no_worker_configured") {
    // The worker reads Stripe and Shopify (components/sync/actions.js startSync); a
    // card about the bank still starts that same run, so it names both.
    const key = String(source ?? "").trim().toLowerCase();
    const name = key === "stripe" || key === "shopify" ? sourceName(key) : "Stripe or Shopify";
    return `Vert can't reach ${name} from here yet, so nothing was sent.`;
  }
  switch (r.kind) {
    case "refused":
      // Read back after a write whose answer never came, and still pending (N3).
      if (r.code === "not_recorded") return "Not recorded yet.";
      return refusedSentence(r);
    case "unconfirmed": {
      // N3: the answer never came; the write may have landed.
      if (r.code === "timeout") return TIMEOUT_SENTENCE;
      if (r.code === "not_recorded") return "Not recorded yet.";
      // P30: the write landed, the engine's read-back did not find it yet.
      const why = typeof r.message === "string" && r.message.trim() && !OPERATOR_TEXT.test(r.message) ? ` ${r.message.trim()}` : "";
      return `${UNCONFIRMED_SENTENCE}${why}`;
    }
    case "network":
    case "unreachable":
      return "Not sent.";
    case "unavailable":
      // `no_api_configured` is set only where writes are off, and writes are off only in
      // the static build (lib/engine-context.js WRITES_ENABLED), so the code alone says
      // this build is the sample — no component asks which source is in use.
      return r.code === "no_api_configured"
        ? "This is a sample month, so it wasn't sent."
        : "Vert can't send this from here yet, so it wasn't sent.";
    case "blocked": {
      const reason = engineReason(r);
      return reason ? `Vert's checks refused this. ${reason}` : "Vert's checks refused this.";
    }
    default:
      return refusedSentence(r);
  }
}

function refusedSentence(r) {
  const reason = engineReason(r);
  return reason ? `Vert refused this. ${reason}` : "Vert refused this.";
}

const stopped = (t) => (/[.!?]$/.test(t) ? t : `${t}.`);

/**
 * A POST THE LEDGER DEFINITELY REFUSED, IN ITS OWN WORDS (engine w3/int 25bf84f9, staging
 * walk 3, W3-1). The approved Dr 090 / Cr 900 entry Xero refused ("Account code '090' is
 * not a valid code for this document") read "it is NOT known whether the entry reached
 * the books… Press post again", over an entry that can never post. The refusal is
 * `result.ledgerRefusal` (lib/ledger-shape.js ledgerRefusalOf): nothing reached the
 * ledger, and an approval made first stands. Said as:
 *
 *   "Xero refused this entry, so nothing reached Xero. Xero said: Account code '090' is
 *    not a valid code for this document. <the engine's next step>"
 *   "Approved, but Xero refused it, so nothing reached Xero. The approval stands. …"
 *
 * The ledger is named as the engine's message names it (its display name), else "your
 * ledger". The next step is the engine's (the sentence after the ledger's reasons in its message:
 * Spend Money, Receive Money or a transfer for a bank line), else "Change the entry and
 * approve it again." Never a code, and never "post again". Null when it isn't one. Pure.
 */
export function ledgerRefusalSentence(result) {
  const r = result && typeof result === "object" ? result : {};
  const refusal = r.ledgerRefusal && typeof r.ledgerRefusal === "object" ? r.ledgerRefusal : null;
  if (!refusal) return null;
  const message = typeof r.message === "string" ? r.message.trim() : "";
  // The ledger as the engine named it (its `display_name`, "<subject> was not posted:
  // Xero would not accept this entry."), never a vendor written in here.
  const named = / was not posted: ([^.:]{1,40}?) would not accept this entry\./.exec(message);
  const name = named ? named[1].trim() : null;
  const Who = name || "Your ledger";
  const who = name || "your ledger";
  const head = r.approved === true ? `Approved, but ${who} refused it, so nothing reached ${who}. The approval stands.` : `${Who} refused this entry, so nothing reached ${who}.`;
  const reasons = Array.isArray(refusal.reasons) ? refusal.reasons.filter((x) => typeof x === "string" && x.trim()).map((x) => stopped(x.trim())) : [];
  const personal = (t) => t && t.length <= 600 && !OPERATOR_TEXT.test(t) && !/\bHTTP\b|https?:\/\/|[{}<>]|\b[a-z]+_[a-z_]+\b/.test(t) && /[.!?]$/.test(t);
  if (!reasons.length) {
    // No reasons sent: the engine's own sentence, without the approval's prefix.
    // Its lead ("The entry was not posted: Xero would not accept this entry.") is what
    // the head already said.
    const said = message.replace(/^Approved, but not posted:\s*/, "").replace(/^[^.]*? was not posted: [^.]*? would not accept this entry\.\s*/, "");
    return personal(said) ? `${head} ${said}` : `${head} Change the entry and approve it again.`;
  }
  const last = refusal.reasons[refusal.reasons.length - 1].trim();
  const at = message.lastIndexOf(last);
  const tail = at >= 0 ? message.slice(at + last.length).replace(/^\.?\s*/, "").trim() : "";
  const next = personal(tail) ? tail : "Change the entry and approve it again.";
  return `${head} ${Who} said: ${reasons.join(" ")} ${next}`;
}

// What Details says for a code whose message was written for the person RUNNING the
// server, not the person using it. components/sync/worker-transport.js words its
// no-worker refusal as setup instructions (the variables to set, the process to
// start); a customer read those under Details (eval C7 / S6, 30 Sep). The code stays,
// because it is what support asks for; the instructions do not.
const DETAIL_WORDS = {
  no_worker_configured: "Syncing isn't set up for this workspace.",
  no_api_configured: "This build has no books behind it.",
  unreachable: "The service didn't answer.",
};

// Operator vocabulary that must never reach a customer's Details, whatever the code:
// an environment variable's name, a shell command, a module path.
const OPERATOR_TEXT = /\b[A-Z][A-Z0-9]*_[A-Z0-9_]+\b|python\s+-m|\brestart it\b|\bthis server\b/;

/** What goes under Details for a failed press: the code and the API's own words —
 *  or, for a code whose words are setup instructions, ours. Nothing when the headline
 *  already says the engine's own sentence (UI walk D4, 30 Oct 2026): Details then only
 *  repeated it behind an error code ("invalid_request: The entry wasn't saved…"). */
export function failureDetails(result) {
  const r = result && typeof result === "object" ? result : {};
  if (!dutyRefusalSentence(r) && (engineReason(r) || ledgerRefusalSentence(r))) return null;
  const bits = [];
  if (r.code) bits.push(String(r.code));
  const words = r.code && DETAIL_WORDS[r.code];
  if (words) bits.push(words);
  else if (r.message && r.kind !== "network" && !OPERATOR_TEXT.test(String(r.message))) bits.push(plainRefusalWords(String(r.message)));
  return bits.join(": ") || null;
}

/**
 * THE KINDS OF DECISION, SAID AS A BOOKKEEPER SAYS THEM (DA2-032; critic r1 F7). The
 * engine's skill text lists the decisions a task proposes by their action kinds with the
 * underscores dropped: "Proposes bank pin, gst, txn class and sync." Each is said in
 * words here; a kind not listed keeps the engine's word.
 */
export const DECISION_KIND_WORDS = Object.freeze({
  "bank pin": "bank matches",
  gst: "GST treatment",
  "txn class": "transaction classes",
  sync: "syncs to the ledger",
  "chart gap": "missing accounts",
  approve: "entries to approve",
  "approve many": "entries to approve together",
  "exception decision": "exception answers",
  "journal approve": "journal entries",
  "journal draft": "draft journal entries",
  "journal reject": "rejected entries",
  reverse: "reversals",
  "prepaid agree": "prepaid schedules",
  plan: "plans",
  "skill update": "skill updates",
});

function listWords(items) {
  if (items.length <= 1) return items.join("");
  return `${items.slice(0, -1).join(", ")} and ${items[items.length - 1]}`;
}

/**
 * A skill's text with its "Proposes …" sentence in words: "Proposes bank matches, GST
 * treatment, transaction classes and syncs to the ledger." Every other line is kept as it
 * is. Pure.
 */
export function decisionKindsInWords(text) {
  if (typeof text !== "string") return text;
  return text.replace(/\bProposes ([a-z ,]+?)\.(?=\s|$)/g, (whole, list) => {
    const items = list.split(/,\s*|\s+and\s+/).map((w) => w.trim()).filter(Boolean);
    if (!items.length) return whole;
    return `Proposes ${listWords(items.map((w) => DECISION_KIND_WORDS[w] || w))}.`;
  });
}

/** A ledger's name and its recording note: "QuickBooks Online (recording, nothing is
 *  sent)" is `{ name: "QuickBooks Online", recording: true }`. Pure. */
export function splitLedgerName(ledgerName) {
  const full = typeof ledgerName === "string" ? ledgerName.trim() : "";
  const m = full.match(/^(.*?)\s*\(([^)]*recording[^)]*)\)$/i);
  return m && m[1] ? { name: m[1], recording: true } : { name: full, recording: false };
}

export const RECORDING_ONLY = "Recording only: nothing is sent to the ledger. Vert keeps the entry as if it were posted.";
