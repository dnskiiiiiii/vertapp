"use client";

// components/cards/JournalCard.js — A JOURNAL ENTRY, COMPLETE, WITH ONE COMMIT
// ==============================================================================
// Build plan §4.5 FJ; §4.0.4–§4.0.5; teardown standards 10–12; audit 2, 3 and 12.
// The card for `journal_approve`, `journal_draft`, `journal_reject` and `reverse`:
//
//   Draft entry · 31 Jul 2026 · July 2026 (· No. 1042 once posted)         1 of 2
//   July rent                                                        ← the memo, the title
//   Account            Debit       Credit      Description   [Class] [Location]
//   6100 · Rent        $4,000.00               July rent
//   1000 · Everyday                $4,000.00   July rent
//   Total              $4,000.00   $4,000.00   Balanced                 ← green, never purple
//   [Lease 2026.pdf]                                                  ← evidence chips
//   Draft                       Approve only · Edit · Reject  [■ Approve and post…]
//   Details ▾                                    ← every id, and "Number: Assigned when it's posted"
//
// THE COMMIT (§4.0.5). With a ledger connected the one purple control is "Approve and
// post…": press 1 opens the human post sheet (entry, ledger, date, total), press 2,
// "Post to QuickBooks", appends the approval for the shown entry and then posts it.
// Draft → posted is two presses, and nothing posts without the sheet (§13: no
// unattended posting). "Approve only" is a quiet secondary. With no ledger the commit
// is Approve, and Undo follows it. A failed post leaves the entry Approved with a plain
// retry (§4.11a.9). The rules — which commit, what each press does — are pure
// functions in ./journal-model.js, so tests/posting.test.js walks them press by press.
//
// ONE STATE WORD, IN THE STATUS COLOURS: Draft (attention), Approved (working), Posted
// (done). Never the accent: purple means "this writes" (§4.0.9).
//
// EDIT opens the editor (./JournalEditor.js) inline, in place of the card's grid, in the
// thread and on Month-end alike (eval r1 #13). A Save
// is a new entry that supersedes this one, and the card then shows the new lines and
// approves the NEW id (./journal-edits.js), so the approval signs what was shown.
//
// AFTER POSTING: Posted, the number, the engine's narration line ("Posted as journal
// 1042 dated 31 Jul. …", bound to the card's figures), "View in QuickBooks ↗", Reverse.
//
// NO FIGURE HERE IS COMPUTED: lines and totals are the engine's integers, formatted.

import DutyGate from "./DutyGate.js";
import { markPressedHere } from "@/lib/pressed-here";
import { ledgerStatusLead, ledgerStatusOf, ledgerStatusTone, splitLedgerName, RECORDING_ONLY, returnedNote } from "./words";
import { useEffect, useReducer, useRef, useState } from "react";
import { BestGuess, Button, Disclosure, Field, IconButton, Meta, Notice, NoticeLine, Sheet, SourceLogo } from "@/components/ui";
import "./journal-editor.css";
import BoundText from "@/components/chat/BoundText";
import { decideAndSettle } from "@/lib/actions";
import { callSafely } from "@/lib/decisions";
import { readPostedEntry } from "@/lib/journal";
import { readPostedByGet } from "@/components/records/entry-read-client";
import { attachToEntry } from "@/lib/documents";
import { usePathname } from "next/navigation";
import { usePane } from "@/components/chat/results/paneContext";
import { DOCUMENT_ACCEPT, fileHref, sessionFromPath, uploadFile } from "@/components/chat/results/DocumentView";
import { useWritesEnabled } from "@/lib/engine-context";
import { formatDate, formatMoney } from "@/lib/format";
import { useDuties, useRecordMonth, useSignedInActor } from "@/lib/store";
import { approvalWaitWords, approveRefusal, drafterOf, gateSentence } from "@/lib/roles";
import { monthReadingOf } from "@/components/month/model";
import { closedMonthRefusal, closedPostReason, useMonthSignedOff } from "@/components/month/useMonthSignedOff";
import Card from "./Card";
import JournalEditor from "./JournalEditor";
import { publishPosted, useSavedEdit } from "./journal-edits";
import { useCardLedger } from "./useCardLedger";
import { usePagerFocus } from "./pagerFocus";
import { postingEffectOf, taxCodesOf } from "./ledger-effect";
import { commitLock, useCommitBlocked } from "@/lib/commit-lock";
import { REJECT_REASON_MESSAGE, REJECT_WARNING } from "./RejectSheet";
import { IconAttach, IconCheck, IconEdit, IconExternal, IconStatusDone } from "@/components/ui/icons";
import { ReadBackTable, besideBalanced, isValidation, readBackTone } from "./ReadBack";
import { usePhone } from "./usePhone";
import { required } from "./validate";
import {
  SECONDARY_LABELS,
  STATE_WORDS,
  accountText,
  alreadyPostedSentence,
  approveGate,
  cardControls,
  cardChips,
  cardEvidence,
  cardLabel,
  cardMeta,
  balanceWords,
  engineTotals,
  entryNumberText,
  shortLedger,
  isEntryId,
  journalFlow,
  mayBeMovedUnder,
  needsDrafterRead,
  unmappedGate,
  reversalHref,
  reversalOf,
  reversalWords,
  reversedConversation,
  ledgerDisplayName,
  pagerText,
  postedEntry,
  readBackLine,
  readBackRows,
  sideText,
  taxCell,
  taxColumn,
  taxNote,
  trackingColumns,
  visibleLines,
  journalLineWords,
  postedLedgerLink,
  statedByPerson,
  whyForControls,
  reverseCardControls,
  REFUSED_AGAIN,
  refusalHolds,
} from "./journal-model";
import { REVERSE_WORDS, SAMPLE_REASON, doneLine, draftWords, failureDetails, failureSentence, postActionLabel, recordedFor } from "./words";
import { holdsAsDraft } from "@/lib/ledger-shape";

import { IconCaretRight } from "@/components/ui/icons";
export const JOURNAL_KINDS = Object.freeze(["journal_approve", "journal_draft", "journal_reject", "reverse"]);

// What entryNumberText says of an entry the ledger has not numbered, and how Details
// says it once it has moved off the face.
const UNNUMBERED = "No. assigned on posting";
export const UNNUMBERED_WORDS = "Assigned when it's posted";

/** What a card says once its edit is saved: saved is not approved (eval final-a C6). */
export const SAVED_NOTE = "Your edit is saved. The entry still needs your approval.";

/** The same, worded for whose approval it waits on (D10: a preparer can't give hers). */
export function savedNote(whose = "your approval") {
  return `Your edit is saved. The entry still needs ${whose}.`;
}

// What each write is called on the one-press road (lib/actions.js decideAndSettle),
// and the outcome a settle records. Undo and Reverse settle nothing: the card's own
// decision is not what they change.
/** Said under a reversal its Save just stored. */
export const REVERSAL_SAVED_NOTE = "Saved as a draft reversal. Nothing posts until it is approved.";

const WRITES = {
  approve: { name: "approveEntry", outcome: "approved", settle: true, busy: "Approving…" },
  approve_and_post: { name: "approveAndPost", outcome: "posted", settle: true, busy: "Posting…" },
  post: { name: "postEntry", outcome: "posted", settle: true, busy: "Posting…" },
  undo: { name: "undoEntry", outcome: null, settle: false, busy: "Undoing…" },
  reject: { name: "rejectEntry", outcome: "rejected", settle: true, busy: "Rejecting…" },
  reverse: { name: "reverseEntry", outcome: null, settle: false, busy: "Drafting…" },
  // An unsaved reversal's Save (staging D4 retest): stores the draft, and settles this
  // card as applied (its read-back is the stored reversal).
  save_reversal: { name: "reverseEntry", outcome: null, settle: true, busy: "Saving…" },
};

function reducer(flow, event) {
  return journalFlow(flow, event, { ledger: event.ledger }).flow;
}

export default function JournalCard({ action, onSettled, onReopened = null, ledgerName = null, ledger = null, clientName = null, initial = null, refusal = null, signsAlone = null }) {
  const a = action && typeof action === "object" ? action : {};
  const saved = useSavedEdit(a.actionId, a.target && typeof a.target.id === "string" ? a.target.id : null);
  const [after, setAfter] = useState(initial && initial.after ? initial.after : null);
  const base = a.je && typeof a.je === "object" ? { entryId: a.target && a.target.id, je: a.je } : null;
  const current = after || (saved ? { ...saved, saved: true } : null) || base;
  // The card still shows the PROPOSAL (no Save, no write yet): its first write drafts
  // `prefill` first. Never after an edit or a write — the prefill is then stale, and
  // drafting it would approve lines the card no longer shows.
  const proposal =
    current === base && a.kind === "journal_draft" && a.prefill && typeof a.prefill === "object" && Array.isArray(a.prefill.lines) ? a.prefill : null;
  if (!current || !current.je || !Array.isArray(current.je.lines)) {
    // A journal kind with no entry to show is drawn as its proposal, with NO commit: a
    // button that approved an entry nobody could see would be a false affordance.
    return <Card action={a} kind={a.kind} ledgerName={ledgerName} />;
  }
  return (
    <JournalCardBody
      action={a}
      current={current}
      proposal={proposal}
      setAfter={setAfter}
      onSettled={onSettled}
      onReopened={onReopened}
      ledgerName={ledgerName}
      ledger={ledger}
      clientName={clientName}
      initial={initial}
      refusal={refusal}
      signsAlone={signsAlone}
    />
  );
}

function JournalCardBody({ action, current, proposal = null, setAfter, onSettled, onReopened, ledgerName, ledger: givenLedger, clientName, initial, refusal = null, signsAlone = null }) {
  const { je, entryId } = current;
  // The page's descriptor where it gave one; else the card asks (eval JE5: the thread
  // passed none, so the chat drew "Approve" with a ledger connected).
  const ledger = useCardLedger(givenLedger);
  const writesEnabled = useWritesEnabled();
  const recordMonth = useRecordMonth();
  const signedIn = useSignedInActor();
  const [flow, dispatch] = useReducer(reducer, null, () => ({
    state: (initial && initial.state) || je.state || "draft",
    sheet: Boolean(initial && initial.sheet),
    busy: false,
    failure: (initial && initial.failure) || null,
  }));
  const [expanded, setExpanded] = useState(Boolean(initial && initial.expanded));
  const [decided, setDecided] = useState((initial && initial.decided) || null);
  const [rejecting, setRejecting] = useState(Boolean(initial && initial.rejecting));
  const [editing, setEditing] = useState(Boolean(initial && initial.editing));
  // A saved edit is a new DRAFT, not a decision (eval final-a C6): the card stays open
  // and says so, until the edited entry is approved, posted or rejected.
  const [note, setNote] = useState(() => (current.saved ? SAVED_NOTE : null));
  const savedId = current.saved ? entryId : null;
  useEffect(() => {
    if (savedId) setNote(SAVED_NOTE);
  }, [savedId]);
  const [busyWrite, setBusyWrite] = useState(null);
  // A reversal this press drafted, until the engine's `je.reversal` says it (D11).
  const [reversed, setReversed] = useState(null);
  // The press that last failed, so Retry repeats exactly it — the same write with the
  // same request — and nothing the person typed (a reject reason, an edit) is lost.
  const lastWrite = useRef(null);

  const name = ledgerDisplayName(ledger, ledgerName);
  const state = flow.state;
  // An unsaved reversal (its entry id is still the ORIGINAL's) has one commit: Save.
  const unsavedReversal = action.kind === "reverse" && entryId === (action.target && action.target.id) && state === "draft";
  const controls = (unsavedReversal && reverseCardControls(action)) || cardControls(state, ledger, { ledgerName, editable: action.kind !== "journal_reject" });
  const ledgerWay = controls.link ? postedLedgerLink(je, controls.link) : null;
  const totals = engineTotals(je);
  // An unbalanced entry can't be approved; nor, in a live build, one whose legs are off
  // the client's chart (D02): the engine refuses it at Post, so it is refused here first.
  // The sample build already draws every commit dead with its own reason.
  const gate = approveGate(je) || (writesEnabled && state !== "posted" ? unmappedGate(je) : null);
  const tracking = trackingColumns(je.lines);
  // Each line's tax rate, on a ledger that takes tax codes (w45): the rate the post sends.
  const taxed = taxColumn(je.lines);
  const taxSaid = taxNote(je);
  // The lines in words: no payout entry's raw memo, no raw id (walk 6, W6-3).
  const { shown, more, fades } = visibleLines(journalLineWords(je), expanded);
  const pager = pagerText(je);
  const shownEntry = state === je.state ? je : { ...je, state };
  // THE NUMBER IS ON THE FACE ONLY ONCE THE LEDGER HAS GIVEN ONE (build plan §19.3 W0d).
  // "No. assigned on posting" on every draft was one more idea (posting) above the fold
  // on Month-end, and said nothing a person decides on; it is now under Details.
  const numbered = entryNumberText(shownEntry) !== UNNUMBERED;
  const word = STATE_WORDS[state] || STATE_WORDS.draft;
  // PAGED ENTRIES (eval PR8): only the run's current card draws its commit in the
  // accent; the others draw it quiet, so one view never shows three purple commits.
  const focused = usePagerFocus(je, String(entryId || action.actionId || ""), Boolean(controls.commit) && state !== "posted");
  // WHO MAY PRESS IT (§20.12 H3, M4): a preparer, or the person who drafted this entry
  // in a firm that splits the work, is told why before the press, beside a commit drawn
  // dead. Null when the engine reported no role: then the engine alone decides.
  const duties = useDuties();
  // The card's `je` names no drafter; the entry's record does (P12: Sam was offered a
  // live "Approve and post…" on his own payroll accrual, refused only after the press).
  const cardDrafter = drafterOf(je) || drafterOf(action);
  const [recordedDrafter, setRecordedDrafter] = useState((initial && initial.drafter) || null);
  // The documents filed against the entry (D08: the engine lists the linked invoice in
  // `entry.evidence.documents` before and after posting; no card showed it).
  const [documents, setDocuments] = useState((initial && initial.documents) || null);
  // The record a chipless card was drafted from (Q02 JE4), from the same read.
  const [sources, setSources] = useState((initial && initial.sources) || null);
  // What the ledger holds of the entry, from the same read (p1/fix5): a card the engine
  // drew carries none, so a Xero draft would otherwise read as posted.
  const [recordedLedger, setRecordedLedger] = useState((initial && initial.ledgerStatus) || null);
  // A posted card says what its LEDGER holds (p1/fix5): "Sent to Xero as a draft ·
  // approve it in Xero to post" in the attention tone, or "Posted in Xero"; with no
  // ledger state said (an older engine), "Posted" as before.
  const ledgerHeld = state === "posted" ? ledgerStatusOf(shownEntry, { ledgerStatus: recordedLedger }) : null;
  // The ledger named by the page's descriptor, else by the card's own payload (p1/fix8).
  const postedWord = ledgerStatusLead(ledgerHeld, name || shownEntry.ledgerName || null, { numbered: Boolean(shownEntry.number) });
  const postedTone = ledgerStatusTone(ledgerHeld);
  const evidence = cardEvidence(je.evidence, sources);
  // The chips drawn: each file once (Q02 N-10, journal-model cardChips).
  const chips = cardChips(evidence, documents);
  const readDrafter = needsDrafterRead({ duties, drafter: cardDrafter || recordedDrafter, entryId, state });
  // One read of the saved entry serves both: its drafter (when the gate needs one) and
  // its documents (whenever a live build shows a saved entry).
  // Never for an unsaved reversal: its id is the original's, not its own entry.
  const readEntry = !unsavedReversal && (readDrafter || (writesEnabled && isEntryId(entryId)));
  useEffect(() => {
    if (!readEntry) return undefined;
    let live = true;
    // A GET (staging D4 retest): this was the readPostedEntry Server Action, a POST
    // /chat/<id> on arriving at every conversation holding a saved entry's card.
    readPostedByGet(entryId).then((reading) => {
      if (!live || !reading) return;
      if (reading.drafter) setRecordedDrafter(reading.drafter);
      if (Array.isArray(reading.documents)) setDocuments(reading.documents);
      if (Array.isArray(reading.sources)) setSources(reading.sources);
      if (reading.ledgerStatus) setRecordedLedger(reading.ledgerStatus);
    });
    return () => {
      live = false;
    };
  }, [readEntry, entryId]);
  const [attaching, setAttaching] = useState({ busy: false, error: null });
  const fileRef = useRef(null);
  const pathname = usePathname();
  // A card in a conversation (its pane is provided there) always says its period (Q02);
  // on Month-end the page names the month (W0d).
  const inConversation = Boolean(usePane()) || (typeof pathname === "string" && pathname.startsWith("/chat/"));
  async function attachFile(file) {
    if (!file || !isEntryId(entryId)) return;
    setAttaching({ busy: true, error: null });
    const up = await uploadFile(file, { session: sessionFromPath(pathname) });
    if (!up.ok) return setAttaching({ busy: false, error: up.message });
    const linked = await callSafely(attachToEntry, up.chip.documentId, entryId);
    if (!linked.ok) return setAttaching({ busy: false, error: linked.message || "Not attached. Nothing was changed." });
    setDocuments((now) => [...(now || []), { documentId: up.chip.documentId, name: up.chip.name, detail: null }]);
    setAttaching({ busy: false, error: null });
  }
  // `refusal`: the read's own word for THIS viewer (the answer shape's `mayApprove: false`
  // with its `whyNot`), said before the press like the role book's. Only a draft is
  // approved, so it gates nothing once the entry is approved or posted.
  // Saving a reversal drafts it, which any role may: no approval gate on the Save.
  const dutyReason = state === "posted" || unsavedReversal ? null : (state === "draft" ? gateSentence(refusal) : null) || approveRefusal(duties, { drafter: cardDrafter || recordedDrafter, actor: signedIn });
  // WHOSE APPROVAL IT WAITS ON, said to the viewer (D10/D11): a preparer is never told an
  // entry "needs your approval". A reversal drafted here was drafted by the viewer.
  const whose = approvalWaitWords(duties, { drafter: cardDrafter || recordedDrafter, actor: signedIn });
  const whoseReversal = approvalWaitWords(duties, { drafter: reversed ? signedIn : null, actor: signedIn });
  // AN APPROVED ENTRY IN A SIGNED-OFF MONTH (UI walk 2, N2): the engine refuses its post,
  // so Post is held with the reason before the press (a GET of the month's lock; a lock
  // not read gates nothing).
  // A post refused because the month is closed reads the lock again (UI walk 3, W3-2), and
  // the reason names what this card offers beside Post: Undo (W3-3).
  const [lockReads, setLockReads] = useState(0);
  const closedMonth = useMonthSignedOff(state === "approved" && writesEnabled && isEntryId(entryId) && typeof je.period === "string" ? je.period : null, lockReads);
  const closedReason = closedMonth === true ? closedPostReason(je.period, { undo: "here" }) : null;
  // The entry's own reason first (it is about the entry), then the person's, then the build's.
  const commitReason = gate || dutyReason || closedReason || (!writesEnabled ? SAMPLE_REASON : null);
  // The engine's reason, less a "Post it" the card can't honour (D10, W3-3).
  const why = whyForControls(action.why, controls, { closed: closedReason });

  // ONE WRITE AT A TIME ACROSS THE PAGE (S-UI-8): while another card's write is in
  // flight, or has just landed, this card's presses do nothing (lib/commit-lock.js).
  const lockKey = String(action.actionId || entryId || "");
  const blockedByOther = useCommitBlocked(lockKey);

  async function perform(write, extra = {}) {
    const spec = WRITES[write];
    if (!spec || !writesEnabled) return;
    if (!commitLock.acquire(lockKey)) return;
    try {
      return await performWrite(write, spec, extra);
    } finally {
      commitLock.release(lockKey);
    }
  }

  async function performWrite(write, spec, extra) {
    lastWrite.current = [write, extra];
    markPressedHere(action.actionId);
    setBusyWrite(write);
    // A `journal_draft` card is not an entry until it is drafted (eval r1 f4: the GL
    // rec's Approve sent `glrec_…` and was refused). Its `prefill` travels with the
    // press and lib/journal.js drafts it first (idempotent on content), then acts on
    // the id the engine returned.
    const draft = proposal;
    // The card pressed rides with the write, so a post links its memo and Open back to
    // the conversation the card is in (eval iter3 r2, WP #14; DOCX-fix2's actionId).
    const cardActionId = typeof action.actionId === "string" && action.actionId ? action.actionId : null;
    const req = { entryId, entryDate: je.date, ...(draft ? { draft } : {}), ...(cardActionId ? { cardActionId } : {}), ...extra };
    const actionId = spec.settle && typeof action.actionId === "string" ? action.actionId : null;
    const result = await callSafely(decideAndSettle, spec.name, req, { actionId, outcome: spec.outcome || "applied" });
    setBusyWrite(null);
    dispatch({ type: "written", write, result, ledger });
    if (!result.ok && closedMonthRefusal(result)) setLockReads((n) => n + 1);
    const reading = monthReadingOf(result);
    if (reading) recordMonth(reading);
    if (!result.ok && (write === "approve" || write === "approve_and_post" || write === "post") && mayBeMovedUnder(result)) {
      // POSTED UNDER US (S-CF-12): a stale tab pressed after someone else posted. The
      // entry is read back; when it IS posted, the card turns into the posted entry in
      // place and says who posted it, instead of "Vert's checks refused this" beside a
      // "Record as posted" that could never work.
      const again = await callSafely(readPostedEntry, entryId);
      const sentence = alreadyPostedSentence(again, { signedIn });
      if (sentence) {
        dispatch({ type: "written", write: "post", result: { ok: true }, ledger });
        setAfter({ entryId, je: postedEntry(je, { body: { posted: { journalNumber: again.journalNumber, glExternalId: again.glExternalId, entryUrl: again.entryUrl } } }) });
        setNote(sentence);
        return result;
      }
    }
    if (!result.ok) return result;
    // From here the card is about the drafted entry: the next press (Post, Undo) names it.
    const actedOn = (typeof result.entryId === "string" && isEntryId(result.entryId) && result.entryId) || entryId;
    if (actedOn !== entryId) setAfter({ entryId: actedOn, je });
    let confirmed = Boolean(result.settle && result.settle.verified);
    if (write === "approve_and_post" || write === "post") {
      // RE-READ, THEN SAY IT (eval JE5). The settle can miss — the card was settled
      // first by the API's own re-verification — and the line then said "Vert couldn't
      // confirm it was recorded yet" while GET /journal held the ledger's id. The entry
      // is read back from the API; only a stored posted entry with the ledger's id
      // confirms it.
      const reread = confirmed ? null : await callSafely(readPostedEntry, actedOn);
      if (reread && reread.confirmed) confirmed = true;
      const withId =
        reread && reread.glExternalId && !(result.body && result.body.posted && result.body.posted.glExternalId)
          ? { ...result, body: { ...(result.body || {}), posted: { ...((result.body && result.body.posted) || {}), journalNumber: reread.journalNumber, glExternalId: reread.glExternalId, entryUrl: reread.entryUrl } } }
          : result;
      const postedJe = postedEntry(je, withId);
      setAfter({ entryId: actedOn, je: postedJe });
      // Held for the settled line that replaces this card in the thread (eval r2 JE5).
      publishPosted(action.actionId, {
        settled: { outcome: "posted", by: recordedBy(result) || signedIn || null, at: new Date().toISOString(), verified: confirmed, result: withId },
        je: postedJe,
      });
    }
    // The saved edit's "still needs your approval" is over once it is decided.
    if (spec.outcome) setNote(null);
    if (write === "reject") setRejecting(false);
    if (write === "reverse") setReversed({ entryId: null, state: "draft", sessionId: reversedConversation(result) });
    if (write === "save_reversal") {
      // The card is now the SAVED reversal: its own id, its stored card, a draft to approve.
      const savedJe = result.body && result.body.je && Array.isArray(result.body.je.lines) ? result.body.je : je;
      const savedId = result.body && result.body.entry && isEntryId(result.body.entry.externalId) ? result.body.entry.externalId : null;
      if (savedId) {
        setAfter({ entryId: savedId, je: { ...savedJe, state: "draft" } });
        setNote(REVERSAL_SAVED_NOTE);
      }
    }
    const by = recordedBy(result) || signedIn || null;
    const settled = { outcome: spec.outcome || write, by, at: new Date().toISOString(), verified: confirmed, result };
    if (write === "undo") {
      setDecided(null);
      if (onReopened) onReopened();
    } else if (spec.outcome) {
      setDecided({ kind: write, settled });
      if (onSettled) onSettled({ action, result, settled, reading });
    }
    return result;
  }

  // The write to repeat: the one this card last sent, else the one the failure names (a
  // card drawn in a remembered failure has sent nothing in this render).
  function retryPress(failure) {
    if (lastWrite.current) return lastWrite.current;
    const named = failure && failure.action;
    return named && named !== "reject" && WRITES[named] ? [named, {}] : null;
  }

  function pressCommit() {
    if (!controls.commit || commitReason || dutyReason) return;
    if (controls.commit.press === "save_reversal") {
      perform("save_reversal");
      return;
    }
    if (controls.commit.press === "approve") {
      dispatch({ type: "press_commit", ledger });
      perform("approve");
      return;
    }
    dispatch({ type: "press_commit", ledger });
  }

  function confirmPost() {
    const next = journalFlow(flow, { type: "confirm_post" }, { ledger });
    if (!next.write) return;
    dispatch({ type: "confirm_post", ledger });
    perform(next.write);
  }

  // EDIT IS INLINE, IN THE CARD (eval r1 #13). The editor used to open in the result
  // pane, where at 1440 px its Description column was clipped (scrollWidth 947 > 671)
  // and the card it edited scrolled away. It now takes the card's own grid and footer
  // in place, at the card's width, and the card comes back with the saved lines.
  function openEditor() {
    setEditing(true);
  }

  // A REVERSAL STANDING (D11): the engine's `je.reversal` (read again on every reload),
  // else this press's own. While it stands, no second Reverse is offered.
  const standing = state === "posted" ? reversalOf(je.reversal, reversed) : null;
  // "Approve only" is the same approval as the commit: withheld with it, never a side door.
  // DESIGN-FIX-2 (DA2-016): Edit is a pencil in the head, Reject… a quiet destructive at
  // the foot's far left, Approve only a secondary beside the one commit at the right.
  const keys = controls.secondary.filter((key) => !((dutyReason || gate) && key === "approve_only") && !(standing && key === "reverse"));
  const canEdit = keys.includes("edit");
  const secondaryButton = (key) => {
    const label = SECONDARY_LABELS[key];
    const busy = busyWrite === key || (key === "approve_only" && busyWrite === "approve");
    const onClick =
      key === "approve_only"
        ? () => perform("approve")
        : key === "edit"
          ? openEditor
          : key === "reject"
            ? () => setRejecting(true)
            : key === "undo"
              ? () => perform("undo")
              : key === "reverse"
                ? () => perform("reverse")
                : undefined;
    return (
      <Button
        key={key}
        // ONE PRIMARY (verify pass 5, Q-SHAPE-4 #15): "Approve only" is quiet, like Reject,
        // so an unfocused card (its commit drawn secondary) never shows two equal actions.
        variant="quiet"
        // Reject is a quiet press with a confirming sheet, not a red one (Q02): only
        // Reverse, which undoes something in the books, wears the problem ink.
        destructive={key === "reverse"}
        onClick={onClick}
        busy={busy}
        busyLabel={WRITES[key === "approve_only" ? "approve" : key] ? WRITES[key === "approve_only" ? "approve" : key].busy : undefined}
        disabled={(!writesEnabled || blockedByOther) && key !== "edit" ? true : undefined}
        data-je-action={key}
      >
        {label}
      </Button>
    );
  };
  const leading = keys.filter((k) => k === "reject" || k === "undo" || k === "reverse").map(secondaryButton);
  const trailing = keys.filter((k) => k === "approve_only").map(secondaryButton);
  const attachable = writesEnabled && isEntryId(entryId) && state !== "posted";

  const decidedLine = decided ? doneLine(decided.kind === "approve_and_post" ? "post" : decided.kind, decided.settled, { signedIn }) : null;

  return (
    <>
      <article className="dcard jcard" data-card={action.kind || "journal_approve"} data-je-state={state} aria-label={je.memo}>
        {/* THE HEAD (design pass, spec §6.17; audit §6 P1): the memo is the title, in
            title-3, with the one state word as its status chip beside it and the pager on
            the right; the meta line (entry, date, month) under it; then the engine's
            validation sentence as a done line with a tick, when that is what it is. */}
        <div className="dcard-head jcard-head">
          <div className="jcard-titlebar">
            <p className="jcard-memo">{je.memo}</p>
            {/* ONE STATUS IN THE HEAD (DA2-016, DA2-029): Draft and Approved are plain
                words (not a task's status); Posted is the done tick and its word. Beside
                it, "Balanced" as a tick and a word in the done ink, never a chip. */}
            {state === "posted" ? (
              <span className={postedTone === "done" ? "jcard-state jcard-posted" : "jcard-state jcard-ledger-draft"} data-tone={postedTone} data-ledger-status={ledgerHeld || undefined} data-je-state-word="">
                {postedTone === "done" ? <IconStatusDone size={12} aria-hidden="true" /> : null}
                {postedWord}
              </span>
            ) : (
              <Meta className="jcard-state" data-tone={word.tone} data-je-state-word="">
                {word.word}
              </Meta>
            )}
            {!editing ? (
              totals.balanced ? (
                <span className="jcard-balanced" data-je-balanced="">
                  <IconCheck size={12} aria-hidden="true" />
                  Balanced
                </span>
              ) : (
                <span className="jcard-unbalanced">Doesn&apos;t balance</span>
              )
            ) : null}
            <span className="jcard-tools">
              {pager ? (
                <span className="jcard-pager t-footnote num" data-je-pager="">
                  {pager}
                </span>
              ) : null}
              {attachable && !editing ? (
                <>
                  <IconButton label={attaching.busy ? "Attaching…" : "Add attachment"} className="jcard-tool" onClick={() => fileRef.current && fileRef.current.click()} data-je-action="attach" aria-busy={attaching.busy ? "true" : undefined}>
                    <IconAttach size={16} />
                  </IconButton>
                  <input
                    ref={fileRef}
                    type="file"
                    name="attachment"
                    className="sr-only"
                    tabIndex={-1}
                    aria-hidden="true"
                    accept={DOCUMENT_ACCEPT}
                    onChange={(e) => {
                      const f = e.target.files && e.target.files[0];
                      e.target.value = "";
                      if (f) attachFile(f);
                    }}
                  />
                </>
              ) : null}
              {canEdit && !editing ? (
                <IconButton label="Edit entry" className="jcard-tool" onClick={openEditor} data-je-action="edit">
                  <IconEdit size={16} />
                </IconButton>
              ) : null}
            </span>
          </div>
          <p className="jcard-label t-footnote">
            {cardMeta(shownEntry, { period: inConversation }).map((part) => (
              <span key={part} className="num">{part}</span>
            ))}
            {numbered ? <span className="jcard-number num">{entryNumberText(shownEntry)}</span> : null}
          </p>
          {/* THE ENGINE'S REASON IS ABOUT THE LINES IT SENT (D10e F7). While the lines are
              being edited, or after an edit was saved, it describes lines no longer on the
              card: "It balances, every account is on the chart…" stood over an unbalanced
              edit. It is drawn only over the engine's own lines. */}
          {why && !editing && je === action.je ? (
            isValidation(why) && !gate ? (
              <p className="dcard-why jcard-checked t-footnote" data-je-validated="">
                <IconCheck className="jcard-checked-glyph" size={14} aria-hidden="true" />
                <span>
                  <BoundText text={totals.balanced ? besideBalanced(why) : why} figures={action.figures} ledgerName={ledgerName} />
                </span>
              </p>
            ) : (
              <p className="dcard-why t-footnote">
                <BoundText text={why} figures={action.figures} ledgerName={ledgerName} />
              </p>
            )
          ) : null}
          {/* A saved edit's lines are the person's own, not Vert's guess (D10). */}
          {/* Nor an entry whose every field the person stated (verify pass 3, D10). */}
          {action.basis === "suggested" && !current.saved && !statedByPerson(current.je) ? <BestGuess /> : null}
          {/* WHO MAY PRESS IT, SAID AT THE TOP (verify pass 2, P12): at the card's foot the
              sentence sat under the composer's fade, below the fold, where Priya never
              read it. It is said in the head, in full ink, and the foot draws no commit. */}
          {controls.commit && dutyReason ? <DutyGate reason={dutyReason} /> : null}
        </div>

        {editing ? (
          <div className="jcard-inline-editor" data-je-editing="">
            <JournalEditor
              action={{ ...action, je, target: { ...(action.target || {}), id: entryId }, proposal: proposal || null }}
              onDone={() => setEditing(false)}
            />
          </div>
        ) : (
        <>
        {/* The grid is ONE idea, "entry", in the lexicon walk (build plan §19.3 W0d, §8.2):
            its account names are the entry's lines, not new things to hold. */}
        <div className="jcard-grid-wrap" data-lexicon="entry">
          <table className="jcard-grid">
            <thead>
              <tr>
                <th scope="col">Account</th>
                <th scope="col" className="num">Debit</th>
                <th scope="col" className="num">Credit</th>
                <th scope="col" className="jcard-desc-col">Description</th>
                {taxed ? <th scope="col" className="jcard-tax-col">Tax rate</th> : null}
                {tracking.classRef ? <th scope="col">Class</th> : null}
                {tracking.locationRef ? <th scope="col">Location</th> : null}
              </tr>
            </thead>
            <tbody>
              {shown.map((line, i) => (
                <tr key={i}>
                  {/* THE ANSWER SHAPE (founder, 17 Oct 2026): Account | Debit | Credit |
                      Description, the description its own column naming the line's
                      source, cut with its full text on hover. An empty side says "–"
                      (data-side-empty, so a phone's stacked line can drop it). */}
                  <td className="jcard-account" translate="no">
                    <span className="jcard-account-name">{accountText(line.account)}</span>
                  </td>
                  <SideCell className="jcard-debit" cents={line.debitCents} />
                  <SideCell className="jcard-credit" cents={line.creditCents} />
                  <td className="jcard-desc-col" translate="yes" data-je-desc="">
                    {line.description ? (
                      <span className="jcard-desc" title={line.description}>
                        {line.description}
                      </span>
                    ) : null}
                  </td>
                  {taxed ? <TaxCell line={line} /> : null}
                  {tracking.classRef ? <td>{line.classRef || ""}</td> : null}
                  {tracking.locationRef ? <td>{line.locationRef || ""}</td> : null}
                </tr>
              ))}
            </tbody>
            {/* Past eight lines, "Show N more" as a quiet row. Nothing fades: every figure
                shown is whole (DA2-016). */}
            {more ? (
              <tbody className="jcard-more-body">
                <tr>
                  <td colSpan={4 + (taxed ? 1 : 0) + (tracking.classRef ? 1 : 0) + (tracking.locationRef ? 1 : 0)}>
                    <button type="button" className="btn btn-quiet btn-sm jcard-more" onClick={() => setExpanded(true)}>
                      {more}
                    </button>
                  </td>
                </tr>
              </tbody>
            ) : null}
            <tfoot>
              <tr>
                <th scope="row">Total</th>
                <td className="num">{totals.debitCents === null ? "" : formatMoney(totals.debitCents)}</td>
                <td className="num">{totals.creditCents === null ? "" : formatMoney(totals.creditCents)}</td>
                <td className="jcard-desc-col" />
                {taxed ? <td className="jcard-tax-col" /> : null}
                {tracking.classRef ? <td /> : null}
                {tracking.locationRef ? <td /> : null}
              </tr>
            </tfoot>
          </table>
        </div>
        {/* What the rates are and why, under the lines (w45): an accrual's "every line is
            BAS Excluded", a rate not read, or the GST question Vert asks before it posts. */}
        {taxed && taxSaid ? (
          <p className={`jcard-tax-note t-footnote${taxSaid.asked ? " is-asked" : ""}`} data-tax-note="" data-tax-asked={taxSaid.asked ? "" : undefined}>
            {taxSaid.text}
          </p>
        ) : null}
        {state !== "posted" && returnedNote(je) ? <p className="t-body" data-returned-note="">{returnedNote(je)}</p> : null}

        {chips.evidence.length || chips.documents.length ? (
          <ul className="jcard-evidence" aria-label="Supporting records">
            {chips.evidence.map((ev, i) => (
              <li key={i} className="jcard-chip t-footnote">
                {ev.label}
              </li>
            ))}
            {chips.documents.map((d) => (
              <li key={d.documentId} className="jcard-chip jcard-doc t-footnote" data-entry-document={d.documentId}>
                <a className="jcard-doc-link" href={fileHref(d.documentId)} target="_blank" rel="noreferrer">
                  {d.name}
                  {d.detail ? <span className="jcard-doc-detail"> · {d.detail}</span> : null}
                </a>
              </li>
            ))}
          </ul>
        ) : null}
        {attaching.error ? (
          <p className="chat-inline-error t-footnote" role="alert">
            {attaching.error}
          </p>
        ) : null}

        {state === "posted" && je.postedNarration ? (
          <p className="jcard-narration t-body">
            <BoundText text={je.postedNarration} figures={action.figures} ledgerName={name} />
          </p>
        ) : null}
        {state === "posted" && typeof je.balanceNarration === "string" && je.balanceNarration.trim() ? (
          // Where the post left its account (Q04, ENG-JE-e2): "Accrued liabilities now
          // stands at {{fig:balance}}.", bound to the entry's own figures; unmeasured, the
          // engine's reason in words.
          <p className="jcard-narration jcard-balance t-footnote" data-je-after="">
            <BoundText text={balanceWords(je.balanceNarration)} figures={je.figures || {}} ledgerName={name} />
          </p>
        ) : null}

        {state === "posted" && readBackRows(shownEntry.readBack).length ? (
          <div className="jcard-readback" data-je-readback="" data-verified={readBackTone(shownEntry.readBack)}>
            <ReadBackTable readBack={shownEntry.readBack} rows={readBackRows(shownEntry.readBack)} />
          </div>
        ) : null}

        {flow.failure && !flow.sheet ? (
          <Notice
            kind="error"
            recorded={recordedFor(flow.failure, flow.failure.approved ? "partial" : "nothing")}
            className="dcard-failure"
            details={failureDetails(flow.failure)}
            onRetry={retryable(flow.failure, writesEnabled) && retryPress(flow.failure) ? () => perform(...retryPress(flow.failure)) : undefined}
          >
            {failureSentence(flow.failure)}
          </Notice>
        ) : null}

        {decidedLine || controls.note || note ? (
          <p className="jcard-note t-footnote" role="status" aria-live="polite">
            {[decidedLine, controls.note, note === SAVED_NOTE ? savedNote(whose) : note].filter(Boolean).join(" ")}
          </p>
        ) : null}
        {standing ? (
          <p className="jcard-note t-footnote" role="status" data-je-reversal={standing.state}>
            {reversalWords(standing, whoseReversal)}
            {reversalHref(standing) ? (
              <>
                {" "}
                <a className="jcard-reversal-link" href={reversalHref(standing)} data-je-action="open-reversal">
                  Open the reversal
                </a>
              </>
            ) : null}
          </p>
        ) : null}

        </>
        )}

        {/* DETAILS, THEN THE DIVIDER, THEN THE ACTIONS (DA2-016): what the entry is,
            its ids one press down, and the foot the eye ends on. */}
        <div className="dcard-details" data-details="" data-je-entry={entryId ? String(entryId) : undefined}>
          <Disclosure summary="Details">
            <dl className="dcard-ids">
              {!numbered ? (
                <>
                  <dt>Number</dt>
                  <dd>{UNNUMBERED_WORDS}</dd>
                </>
              ) : null}
              {/* NO INTERNAL ID IS SHOWN (verify pass 6, Q02): Details said "Entry je:…",
                  "Line 1 account 640" (the chart's id, not its number) and "Decision a-4".
                  It now says, in words, what the face leaves out: the accounts by number
                  and full name, what the entry replaces, and the records behind it. The
                  entry's id rides on this block as data-je-entry, for the tests, never as text. */}
              {je.supersedes ? (
                <>
                  <dt>Replaces</dt>
                  <dd>An earlier draft, changed by an edit</dd>
                </>
              ) : null}
              {detailAccounts(je.lines).length ? (
                <>
                  <dt>{detailAccounts(je.lines).length === 1 ? "Account" : "Accounts"}</dt>
                  <dd translate="no">{detailAccounts(je.lines).join(", ")}</dd>
                </>
              ) : null}
              {detailSources(evidence).length ? (
                <>
                  <dt>From</dt>
                  <dd>{detailSources(evidence).join(", ")}</dd>
                </>
              ) : null}
            </dl>
          </Disclosure>
        </div>

        {!editing ? (
          <div className="jcard-foot">
            <div className="jcard-quiet">
              {leading}
              {ledgerWay ? (
                ledgerWay.internal ? (
                  <a className="btn btn-secondary jcard-ledger-link" href={ledgerWay.href} data-ledger-link="vert">
                    <span>{ledgerWay.label}</span>
                  </a>
                ) : (
                  <a className="btn btn-secondary jcard-ledger-link" href={ledgerWay.href} target="_blank" rel="noreferrer" data-ledger-link="external">
                    <span>{ledgerWay.label}</span>
                    <IconExternal size={14} aria-hidden="true" />
                  </a>
                )
              ) : null}
              {state === "approved" && !controls.commit ? (
                <a className="btn btn-quiet" href="/connections">
                  Connect<IconCaretRight className="caret-trailing" />
                </a>
              ) : null}
            </div>
            <div className="dcard-actions jcard-actions">
              {trailing}
              {/* WHAT THE PRESS DOES IN THE LEDGER, BESIDE IT (answer shape, 17 Oct 2026):
                  the ledger's own posting_effect sentence, never a vendor guess. */}
              {controls.commit && !dutyReason && controls.commit.press === "open_post" && postingEffectOf(ledger, name, je) ? (
                <p className="jcard-effect t-footnote" data-ledger-effect="">
                  {postingEffectOf(ledger, name, je)}
                </p>
              ) : null}
              {/* The read's word that this viewer signs it alone (verify pass 7, Q-SHAPE-4),
                  said above the press, never after it. */}
              {controls.commit && !dutyReason && state === "draft" && typeof signsAlone === "string" && signsAlone ? (
                <p className="jcard-effect t-footnote" data-signs-alone="">
                  {signsAlone}
                </p>
              ) : null}
              {controls.commit && dutyReason ? null : controls.commit ? (
                <Button
                  variant={focused ? "commit" : "secondary"}
                  onClick={pressCommit}
                  busy={(busyWrite === "approve" && controls.commit.press === "approve") || (busyWrite === "save_reversal" && controls.commit.press === "save_reversal")}
                  busyLabel={controls.commit.press === "save_reversal" ? "Saving…" : "Approving…"}
                  disabledReason={commitReason || undefined}
                  disabled={blockedByOther || undefined}
                  data-je-commit=""
                >
                  {controls.commit.label}
                </Button>
              ) : null}
            </div>
          </div>
        ) : null}
      </article>

      {flow.sheet && controls.commit && !dutyReason && controls.commit.press === "open_post" ? (
        <JournalPostSheet
          open={flow.sheet}
          onClose={() => dispatch({ type: "close_sheet", ledger })}
          je={je}
          ledgerName={name}
          draft={holdsAsDraft(ledger)}
          effect={postingEffectOf(ledger, name, je)}
          taxCodes={taxCodesOf(ledger, name)}
          clientName={clientName}
          approving={state === "draft"}
          busy={Boolean(busyWrite)}
          failure={flow.failure}
          disabledReason={commitReason || undefined}
          onConfirm={confirmPost}
        />
      ) : null}

      {rejecting ? (
        <JournalRejectSheet
          open={rejecting}
          onClose={() => setRejecting(false)}
          busy={busyWrite === "reject"}
          failure={flow.failure}
          disabledReason={writesEnabled ? undefined : SAMPLE_REASON}
          onReject={(reason) => perform("reject", { reason })}
        />
      ) : null}

    </>
  );
}

/**
 * Whether a failed write is worth a plain Retry (eval C5b): anything that might land on
 * a second press — a dropped connection, an aborted request, an API that refused for a
 * reason that can pass. Not Vert's own checks (they would refuse again), and not the
 * sample build (nothing is behind it).
 */
export { postingEffectOf } from "./ledger-effect";

/** One side of a line: the engine's cents, or "–" for the empty side (the answer shape). */
export function SideCell({ className, cents }) {
  const text = sideText(cents);
  return text ? (
    <td className={`num ${className}`}>{text}</td>
  ) : (
    <td className={`num ${className}`} data-side-empty="">
      <span aria-label="none">&ndash;</span>
    </td>
  );
}

export function retryable(failure, writesEnabled = true) {
  if (!writesEnabled || !failure || failure.ok) return false;
  return failure.kind !== "blocked" && failure.kind !== "unavailable";
}

/** The entry's accounts for Details, by number and full name, once each, in order. Pure. */
/** One line's tax rate: the rate it goes out on, and under it, quieter, the account's
 *  own rate when the line isn't sent on it, or that the rate wasn't read (w45). */
function TaxCell({ line }) {
  const cell = taxCell(line);
  if (!cell) return <td className="jcard-tax-col" />;
  return (
    <td className="jcard-tax-col" data-je-tax="" data-tax-asked={cell.asked ? "" : undefined}>
      <span className="jcard-tax">{cell.text}</span>
      {cell.hint ? <span className="jcard-tax-hint">{cell.hint}</span> : null}
    </td>
  );
}

export function detailAccounts(lines) {
  const out = [];
  for (const l of Array.isArray(lines) ? lines : []) {
    const text = l && l.account && typeof l.account === "object" ? accountText(l.account) : "";
    if (text && !out.includes(text)) out.push(text);
  }
  return out;
}

/** The records an entry was drafted from, in words (never their ids), once each. Pure. */
export function detailSources(evidence) {
  const out = [];
  for (const ev of Array.isArray(evidence) ? evidence : []) {
    const label = ev && typeof ev.label === "string" ? ev.label.trim() : "";
    if (label && !out.includes(label)) out.push(label);
  }
  return out;
}

// The actor the API recorded on the decision, when its reply names one.
function recordedBy(result) {
  const body = (result && result.body) || {};
  const d = body.decision || (result && result.approval && result.approval.decision) || null;
  return d && typeof d.actor === "string" && d.actor.trim() ? d.actor.trim() : null;
}

export { splitLedgerName, RECORDING_ONLY } from "./words";

/**
 * Bring a refusal into view inside a sheet's scrolling body and give it focus (W3-1), so
 * a press whose answer is a refusal visibly answers. Returns whether it could. Exported
 * for tests.
 */
export function revealRefusal(el) {
  if (!el || typeof el.focus !== "function") return false;
  if (typeof el.scrollIntoView === "function") el.scrollIntoView({ block: "nearest" });
  el.focus({ preventScroll: true });
  return true;
}

/**
 * THE HUMAN POST SHEET (§4.0.5, spec §3.7). Restates what will be written — the entry,
 * the ledger, the date and the total, all the engine's — and its one commit posts it.
 * On a draft it also appends the approval for this entry first; a post that then fails
 * leaves the approval standing, and the sheet says so with a plain retry.
 *
 * DESIGN PASS (spec §6.16; audit §6 P0, P1). The title asks one short question, "Post
 * this entry?", and the commit says the act in two words, "Post entry", on one line at
 * every width: at 390 px the old 50-character label ("Post to QuickBooks Online
 * (recording, nothing is sent)") ran off the left edge. The ledger, and the recording
 * mode as a neutral chip, are said once, in the body. A centred modal on a desk; a
 * bottom sheet with a full-width commit on a phone.
 */
export function JournalPostSheet({ open, onClose, je, ledgerName, draft = false, effect = null, taxCodes = null, clientName = null, approving = true, busy = false, failure = null, disabledReason, onConfirm }) {
  const phone = usePhone();
  // A REFUSAL IS SAID WHERE IT IS SEEN (UI walk 3, W3-1). At 1440 x 900 it was drawn under
  // the lines, below the body's fold: the press seemed to do nothing, and "Record as
  // posted" stayed live for a press that would only be refused again. It now heads the
  // body, is scrolled to and focused when it arrives, and a refusal pressing again can't
  // change holds the confirm (journal-model.js refusalHolds), its reason pointing up.
  const refusalRef = useRef(null);
  useEffect(() => {
    if (failure) revealRefusal(refusalRef.current);
  }, [failure]);
  const held = refusalHolds(failure) ? REFUSED_AGAIN : disabledReason;
  const totals = engineTotals(je);
  const ledger = splitLedgerName(ledgerName);
  const where = `${clientName ? `${clientName}'s` : "your"} ${ledger.name} file`;
  let date = null;
  try {
    date = formatDate(je.date);
  } catch {
    date = null;
  }
  const total = totals.debitCents === null ? null : formatMoney(totals.debitCents);
  // NO JOURNAL NUMBER BEFORE THE POST (verify pass 1, P07). `entryTag` is the pager's
  // index, not the ledger's number: the sheet promised "as journal 1" and the entry
  // posted as 2. The ledger names the number when it posts, on the plate.
  // DESIGN-FIX-2 (DA2-052): ONE SENTENCE says the whole write, under the one hero figure;
  // the lines are one press down; recording-only is a full-width notice, not a pill; the
  // way back is said plainly; the commit names the ledger. No box of facts, no second
  // Total.
  // WORDED BY LEDGER MODE (verify pass 1, U09): a recording-only ledger receives
  // nothing, so the sheet never says "Post to QuickBooks" beside "nothing is sent". It
  // says what happens: Vert records the entry as posted.
  const recording = ledger.recording;
  // A LEDGER THAT HOLDS DRAFTS (createsDraft, 17 Oct 2026: per client on Xero) is SENT the
  // entry, not posted it, and every word of the press says so: the title, the sentence and
  // the button (words.js `postActionLabel`). Never on a recording ledger.
  const sends = draft && !recording;
  const button = shortLedger(ledger.name) || "the ledger";
  // The ledger's own sentence about this press, beside the button; only the API's.
  const said = !recording && typeof effect === "string" && effect.trim() ? effect.trim() : null;
  // What happens to its GST, from the target's `sendsTaxCodes` (engine w37); never on a
  // recording ledger, which receives nothing.
  const gst = !recording && typeof taxCodes === "string" && taxCodes.trim() ? taxCodes.trim() : null;
  const sentence = [
    recording
      ? `Record ${total || "this entry"} as posted, for ${ledger.name}`
      : sends
        ? `Send ${total || "this entry"} to ${ledger.name} as a draft`
        : `Post ${total || "this entry"} to ${ledger.name}`,
    date ? `, dated ${date}` : "",
    ".",
  ].join("");
  return (
    <Sheet
      open={open}
      onClose={onClose}
      side={phone ? "bottom" : "modal"}
      title={recording ? "Record this entry as posted?" : sends ? "Send this entry as a draft?" : "Post this entry?"}
      className="post-sheet jpost-sheet"
      footer={
        <>
          {said ? (
            <p className="sheet-foot-status post-effect" data-ledger-effect="">
              {said}
            </p>
          ) : null}
          {gst ? (
            <p className="sheet-foot-status post-effect" data-ledger-tax-codes="">
              {gst}
            </p>
          ) : null}
          <div className="sheet-actions jpost-actions">
            <Button variant="quiet" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="commit" onClick={onConfirm} busy={busy} busyLabel={sends ? "Sending…" : "Posting…"} disabledReason={held || undefined} data-je-confirm="">
              {recording ? "Record as posted" : postActionLabel(button, { draft: sends })}
            </Button>
          </div>
        </>
      }
    >
      {failure ? (
        <div className="jpost-refusal" ref={refusalRef} tabIndex={-1} data-jpost-refusal="">
          <Notice
            kind="error"
            recorded={recordedFor(failure, failure.approved ? "partial" : "nothing")}
            details={failureDetails(failure)}
            // A post that never reached Vert (P25) is safe to send again, from here.
            onRetry={!failure.approved && (failure.kind === "network" || failure.kind === "unreachable") && !disabledReason ? onConfirm : undefined}
          >
            {/* A post the ledger refused says so in its words: no "post again" over it. */}
            {failure.approved && !failure.ledgerRefusal ? "Approved, but not posted yet. Post again when you're ready." : failureSentence(failure)}
          </Notice>
        </div>
      ) : null}
      <div className="jpost-hero">
        <p className="jpost-hero-label t-footnote">{je.memo}</p>
        <p className="figure-hero jpost-total num" translate="no">
          {total || "Not available"}
        </p>
      </div>
      <p className="t-callout jpost-lede">
        {sentence}
        {approving ? " It approves the entry in your name first." : ""}
      </p>
      <p className="jpost-ledger t-footnote">
        <SourceLogo source={ledger.name} size={16} />
        <span className="jpost-where">
          {recording ? `Kept in Vert for ${where}` : `Into ${where}`}
        </span>
      </p>
      {ledger.recording ? (
        <NoticeLine tone="info" className="jpost-mode">
          <span data-je-recording="">{RECORDING_ONLY}</span>
        </NoticeLine>
      ) : null}
      {/* A LEDGER THAT HOLDS DRAFTS (Xero): the press here is not the last gate, and the
          sheet says so from the API's `createsDraft`, never from the vendor's name. */}
      {draft && !recording ? (
        <p className="jpost-ledger t-footnote" data-je-draft="">
          {draftWords(shortLedger(ledger.name) || ledger.name)}
        </p>
      ) : null}
      {/* THE LINES BEING POSTED (P24/D10), open on the sheet (verify pass 7, D06): a
          manual entry is never posted on its memo and total alone, and every post sheet
          is one design: Approve entries' sheet lists its lines, so this one does too,
          rather than folding them behind "The 2 lines". */}
      {Array.isArray(je.lines) && je.lines.length ? (
        <table className="post-journal jpost-lines" data-jpost-lines="">
          <thead>
            <tr>
              <th scope="col">Account</th>
              <th scope="col" className="num">Debit</th>
              <th scope="col" className="num">Credit</th>
              {taxColumn(je.lines) ? <th scope="col">Tax rate</th> : null}
            </tr>
          </thead>
          <tbody>
            {je.lines.map((l, i) => (
              <tr key={`${accountText(l.account)}-${i}`}>
                <td translate="no">{accountText(l.account)}</td>
                <td className="num">{sideText(l.debitCents)}</td>
                <td className="num">{sideText(l.creditCents)}</td>
                {taxColumn(je.lines) ? <td data-jpost-tax="">{taxCell(l) ? taxCell(l).text : ""}</td> : null}
              </tr>
            ))}
          </tbody>
        </table>
      ) : null}
      <p className="jpost-undo t-footnote">{REVERSE_WORDS}</p>
    </Sheet>
  );
}

/** Reject: it can't be reopened, and the reason goes on the record. */
function JournalRejectSheet({ open, onClose, busy, failure, disabledReason, onReject }) {
  const [reason, setReason] = useState("");
  const [error, setError] = useState(null);
  return (
    <Sheet
      open={open}
      onClose={onClose}
      side="modal"
      title="Reject this entry?"
      className="reject-sheet"
      footer={
        <div className="sheet-actions">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="commit"
            busy={busy}
            busyLabel="Rejecting…"
            disabledReason={disabledReason}
            onClick={() => {
              if (!reason.trim()) return setError(REJECT_REASON_MESSAGE);
              onReject(reason.trim());
            }}
          >
            Reject
          </Button>
        </div>
      }
    >
      <p className="t-body">{REJECT_WARNING}</p>
      <Field
        label="Why?"
        value={reason}
        error={error}
        validate={required(REJECT_REASON_MESSAGE)}
        onChange={(e) => {
          setReason(e.target.value);
          setError(null);
        }}
      />
      {failure ? (
        <Notice kind="error" recorded={recordedFor(failure)} details={failureDetails(failure)}>
          {failureSentence(failure)}
        </Notice>
      ) : null}
    </Sheet>
  );
}
