"use client";

// components/cards/AskedInChatCard.js — A DECISION ANSWERED IN ITS CONVERSATION, AS A CARD
// ==============================================================================
// Design-fix-2 DA2-037 (critic r1 F3). Some of Home's decisions are answered only in
// their conversation (a question with a form Home does not draw). Each was a one-line
// variant of its own: the question as a row, "1 of 9" floating alone above it, and an
// underlined "Answer in the conversation ›" link. It is now the one decision card's
// shape: the question in the card head, where the deck's pager sits (month.css
// `.decision-item[data-paged]`), and the one foot, with "Answer in chat" as a secondary
// button with its caret. It writes nothing, so nothing on it is the accent.

import Link from "next/link";
import { IconCaretRight } from "@/components/ui/icons";
import { DecisionFoot } from "./OptionRows";

export const ANSWER_IN_CHAT = "Answer in chat";

export default function AskedInChatCard({ text, sessionId = null, href = null }) {
  const to = href || (typeof sessionId === "string" && sessionId ? `/chat/${encodeURIComponent(sessionId)}` : null);
  return (
    <article className="dcard dcard-asked" data-card="asked-in-chat">
      <div className="dcard-head">
        <p className="dcard-proposal t-callout" tabIndex={-1}>
          {text}
        </p>
      </div>
      {to ? (
        <DecisionFoot hints={[]} commit={null}>
          <Link className="btn btn-secondary" href={to} data-answer-in-chat="">
            {ANSWER_IN_CHAT}
            <IconCaretRight className="caret-trailing" size={14} aria-hidden="true" />
          </Link>
        </DecisionFoot>
      ) : null}
    </article>
  );
}
