"use client";

// components/cards/chart-read.js — THE CHART OF ACCOUNTS, READ FROM THE BROWSER WITH A GET
// ==============================================================================
// Staging browser walk 1 (31 Oct 2026). The journal editor and the bank rec's coding
// editor read the chart by calling the `readChartAccounts` Server Action from an effect:
// a read on the engine's side, a POST on the wire, and the last two effects the
// quiet-load guard still excused (tests/p0-quiet-page-load.test.js). The bill review had
// no chart at all, so a line with no suggestion had to be coded from memory (D11).
//
// Now each asks `GET /api/journal?accounts` (app/api/journal/route.js), which calls the
// same lib/journal.js readChartAccounts on the server. One read per page while it is in
// flight; a failed read is said in the engine's words, never an empty chart standing in
// for "you have no accounts".

const UNREAD = "Vert couldn't read your chart of accounts just now. Your edits are kept.";

let pending = null;

function browserFetch() {
  return typeof window !== "undefined" && typeof window.fetch === "function" ? window.fetch.bind(window) : null;
}

/** `{ ok, accounts: [{ id, number, name, active, ... }], message? }`. Never throws. */
export async function readChart(fetchImpl = null) {
  const doFetch = fetchImpl || browserFetch();
  if (!doFetch) return { ok: false, accounts: [], message: UNREAD };
  try {
    const response = await doFetch("/api/journal?accounts", { method: "GET", headers: { accept: "application/json" }, cache: "no-store", credentials: "same-origin" });
    const body = response && typeof response.json === "function" ? await response.json().catch(() => null) : null;
    if (body && body.ok === true && Array.isArray(body.accounts)) return { ok: true, accounts: body.accounts };
    return { ok: false, accounts: [], message: (body && typeof body.message === "string" && body.message) || UNREAD };
  } catch {
    return { ok: false, accounts: [], message: UNREAD };
  }
}

/** The page's one read of the chart, shared by every editor that opens while it runs. */
export function readChartOnce(fetchImpl = null) {
  if (fetchImpl) return readChart(fetchImpl);
  if (!pending) pending = readChart().finally(() => { pending = null; });
  return pending;
}
