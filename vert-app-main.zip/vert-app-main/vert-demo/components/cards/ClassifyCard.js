"use client";

// components/cards/ClassifyCard.js — "WHAT IS THIS TRANSACTION?"
// ==============================================================================
// Spec §5.3 row 3. Replaces ClassifyPanel.
//
// THE COMMIT SAYS WHAT HAPPENS: "Save as Payment Processing Fees", named by the account
// chosen, never "Record" or "Submit" (spec §1.7, UI-042). With no account chosen yet the
// button reads "Choose an account" and pressing it marks the field — a disabled button
// with no field marked is the defect UI-015 found.
//
// THE PRE-FILL IS AN EXPERIMENT ARM, AND THE CARD RESPECTS IT. resolve_breaks fills the
// account only on the `assist` arm of the recorded pre-fill experiment; on the control
// arm the card opens empty, exactly as the panel it replaces did, so the anchoring
// measurement survives the move. Whatever arrives, the mark follows `basis` alone.
//
// Accounts are CHOSEN from the chart the engine supplies (CLASSIFIABLE_ACCOUNTS), never
// typed: lib/actions.js refuses free text before the wire, and the API refuses it again.
// "No account fits" turns the card, in place, into the chart-gap card.

import { useState } from "react";
import { Button, Field, SelectField } from "@/components/ui";
import { recordTxnClass } from "@/lib/actions";
import { CLASSIFIABLE_ACCOUNTS, CLASSIFY_GROUNDS, classifiableAccount, isClassifiableAccount, isKnownClassifyGround } from "@/lib/assertions";
import { useCardCommit } from "@/lib/decisions";
import Card from "./Card";
import ChartGapCard from "./ChartGapCard";
import DecisionLine from "./DecisionLine";
import Skip from "./Skip";
import { clearOnChange, missing, onBlurRequired, required } from "./validate";

export const CLASSIFY_MESSAGES = Object.freeze({
  account: "Choose the account this belongs to.",
  basis: "Choose how you know.",
  note: "Say what you looked at, in a sentence.",
});

export default function ClassifyCard({ action, onSettled, ledgerName = null, initial = null }) {
  const prefill = (action && action.prefill) || {};
  const payoutId = prefill.payoutId || (action.target && action.target.id) || null;
  const [account, setAccount] = useState(isClassifiableAccount(prefill.account) ? prefill.account : "");
  const [basis, setBasis] = useState(isKnownClassifyGround(prefill.basis) ? prefill.basis : "");
  const [note, setNote] = useState(typeof prefill.note === "string" ? prefill.note : "");
  const [errors, setErrors] = useState({});
  const [gap, setGap] = useState(false);
  const card = useCardCommit(action, { onSettled, initial });

  if (gap) return <ChartGapCard action={action} onSettled={onSettled} ledgerName={ledgerName} onBack={() => setGap(false)} />;
  if (card.phase === "done") return <DecisionLine kind="txn_class" settled={card.settled} outcome={card.settled.outcome} />;

  const chosen = isClassifiableAccount(account) ? classifiableAccount(account) : null;
  const suggested = action.basis === "suggested" && account === prefill.account;

  function press() {
    const next = missing({
      account: [account, CLASSIFY_MESSAGES.account, isClassifiableAccount],
      basis: [basis, CLASSIFY_MESSAGES.basis, isKnownClassifyGround],
      note: [note, CLASSIFY_MESSAGES.note],
    });
    setErrors(next);
    if (Object.keys(next).length) return;
    card.commit(
      recordTxnClass,
      { payoutId, account, basis, note, txnIds: prefill.txnIds, scopeHash: prefill.scopeHash },
      { outcome: "applied" }
    );
  }

  return (
    <Card
      action={action}
      kind="txn_class"
      ledgerName={ledgerName}
      suggested={suggested}
      form={
        <>
          <SelectField
            label="Account"
            value={account}
            placeholder="Choose an account"
            error={errors.account}
            onBlur={onBlurRequired(setErrors, "account", CLASSIFY_MESSAGES.account)}
            onChange={clearOnChange(setErrors, "account", setAccount)}
            options={CLASSIFIABLE_ACCOUNTS.map((a) => ({ value: a.code, label: a.name }))}
          />
          <SelectField
            label="How do you know?"
            value={basis}
            placeholder="Choose one"
            error={errors.basis}
            onBlur={onBlurRequired(setErrors, "basis", CLASSIFY_MESSAGES.basis)}
            onChange={clearOnChange(setErrors, "basis", setBasis)}
            options={CLASSIFY_GROUNDS.map((g) => ({ value: g.value, label: g.label }))}
          />
          <Field
            label="Note for the record"
            value={note}
            error={errors.note}
            validate={required(CLASSIFY_MESSAGES.note)}
            onChange={clearOnChange(setErrors, "note", setNote)}
          />
        </>
      }
      failure={card.phase === "failed" ? card.result : null}
      onRetry={card.phase === "failed" && card.writesEnabled ? card.retry : undefined}
      actions={
        <>
          <Button variant="commit" onClick={press} busy={card.busy} busyLabel="Saving…" disabledReason={card.disabledReason}>
            {chosen ? `Save as ${chosen.name}` : "Choose an account"}
          </Button>
          <Button variant="quiet" onClick={() => setGap(true)}>
            No account fits
          </Button>
          <Skip action={action} card={card} />
        </>
      }
    />
  );
}
