"use client";

// components/cards/PrepaidAgreeCard.js — "AGREE ATLASSIAN'S SCHEDULE: $1,200.00 OVER 12 MONTHS?"
// ==============================================================================
// The card for `prepaid_agree` (vert_engine/agent_events.py PENDING_ACTION_KINDS),
// emitted by vert_engine/workflows/templates/prepaid_schedule.py: a person agrees a
// prepaid schedule's figures before any of its releases is drawn.
//
// ONE COMMIT, THROUGH THE SHARED FOOTER. It was a placeholder with no commit (eval r1,
// §9.1.R / PR3: the card's only controls were its two figure links and Details, so the
// decision could not be made). Its commit is the engine's own label ("Agree the
// schedule"), and the press is lib/actions.js agreePrepaidSchedule — the three existing
// prepaid routes with the engine's prefill as their bodies, through the one card road
// (lib/decisions.js useCardCommit), which settles the card so the API reads the
// schedule back. Skip is the quiet secondary every card has.
//
// NOTHING POSTS. Agreeing draws each ended month's release as a DRAFT; each is its own
// journal card to approve. The card's reason already says so in the engine's words.

import { Button } from "@/components/ui";
import { agreePrepaidSchedule } from "@/lib/actions";
import { useCardCommit } from "@/lib/decisions";
import Card from "./Card";
import DecisionLine from "./DecisionLine";
import Skip from "./Skip";

// The engine names the commit (`commitLabel`); this is only the fallback for an event
// that carried none, in the same words.
export const AGREE_LABEL = "Agree the schedule";

export default function PrepaidAgreeCard({ action, onSettled, ledgerName = null, initial = null }) {
  const a = action && typeof action === "object" ? action : {};
  const prefill = a.prefill && typeof a.prefill === "object" ? a.prefill : {};
  const card = useCardCommit(action, { onSettled, initial });

  if (card.phase === "done") {
    return <DecisionLine kind="prepaid_agree" settled={card.settled} outcome={card.settled.outcome} />;
  }

  const label = typeof a.commitLabel === "string" && a.commitLabel.trim() ? a.commitLabel : AGREE_LABEL;
  // A card the engine drew without its routes' bodies cannot be agreed honestly: the
  // button says why instead of sending a request the action would refuse.
  const complete = Boolean(prefill.scheduleId && prefill.schedule && prefill.digest && prefill.through);
  const disabledReason = card.disabledReason || (complete ? null : "This schedule came without its figures. Ask Vert for it again.");

  function press() {
    card.commit(
      agreePrepaidSchedule,
      { scheduleId: prefill.scheduleId, schedule: prefill.schedule, digest: prefill.digest, through: prefill.through },
      { outcome: "applied" }
    );
  }

  return (
    <Card
      action={action}
      kind="prepaid_agree"
      ledgerName={ledgerName}
      failure={card.phase === "failed" ? card.result : null}
      onRetry={card.phase === "failed" && card.writesEnabled ? card.retry : undefined}
      actions={
        <>
          <Button variant="commit" onClick={press} busy={card.busy} busyLabel="Agreeing…" disabledReason={disabledReason}>
            {label}
          </Button>
          <Skip action={action} card={card} />
        </>
      }
    />
  );
}
