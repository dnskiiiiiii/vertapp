// components/cards/ledger-note.js — WHAT AN APPROVED, UNPOSTED CARD SAYS ABOUT ITS LEDGER
// ==============================================================================
// Verify pass 4, P24. With no ledger configured, the card said "Ready to post when
// your ledger is connected." beside an engine descriptor that says why none is, and
// what to do about it. The engine's own first sentence when the ledger is KNOWN to be
// absent; the old words only when it could not be read. Pure.

import { ledgerAbsence } from "@/lib/ledger-shape";

export const UNREAD_LEDGER_NOTE = "Ready to post when your ledger is connected.";

export function unpostedLedgerNote(ledger) {
  const absence = ledgerAbsence(ledger);
  return absence ? absence.short : UNREAD_LEDGER_NOTE;
}
