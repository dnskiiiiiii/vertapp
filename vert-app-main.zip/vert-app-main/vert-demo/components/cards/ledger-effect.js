// components/cards/ledger-effect.js — WHAT A POST DOES IN THE LEDGER, IN THE LEDGER'S OWN WORDS
// ==============================================================================
// The answer shape (founder, 17 Oct 2026): the primary action names the ledger and keeps
// the ledger target's `postingEffect` sentence beside it ("This creates a DRAFT manual
// journal in your Xero organisation."). The sentence is the target's (GET
// /approvals/ledger), never a vendor guess written here. A recording ledger keeps its
// sentence ("nothing is sent to QuickBooks"): it is what the press does there.
//
// THE ENTRY'S OWN SENTENCE FIRST (staging walkthrough D1, 26 Oct 2026). The ledger's one
// sentence for every entry told the person approving an ACCRUAL that Vert cannot
// reconcile their bank account, and never said which organisation the journal went to.
// The target now also sends `postingEffects`, one sentence per entry kind, naming the
// organisation; the card's `je.entryKind` picks it. The general sentence stands only
// where the ledger sent none for that kind.

const said = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

/**
 * The ledger's own sentence about what posting `je` does, or null (none sent). `je` is
 * the card's entry, or anything carrying its `entryKind` ({ entryKind: "payout" }). Pure.
 */
export function postingEffectOf(ledger, ledgerName = null, je = null) {
  if (!ledger || typeof ledger !== "object") return null;
  const kind = je && typeof je === "object" && typeof je.entryKind === "string" ? je.entryKind : null;
  const kinds = ledger.postingEffects && typeof ledger.postingEffects === "object" ? ledger.postingEffects : null;
  const own = kind && kinds && Object.hasOwn(kinds, kind) ? said(kinds[kind]) : null;
  // A recording ledger's sentence is kept too (verify pass 5, Q-SHAPE-4): it is the one
  // place the card says nothing is sent, beside a label that now names the platform.
  return own || said(ledger.postingEffect);
}

/** What a payout's post is, for the sentence: the payout cards carry no `je` of their own. */
export const PAYOUT_ENTRY = Object.freeze({ entryKind: "payout" });

/**
 * WHAT HAPPENS TO GST, from the ledger target's `sendsTaxCodes` (GET /approvals/ledger),
 * never from its name. Engine w37: a Xero journal now carries each line's GST tax code,
 * so the old "None sent — GST is a journal line here, not a ledger tax code" became
 * untrue there. True → GST goes as each line's tax code; false → GST is a journal line
 * of its own and no tax code goes; anything else (no ledger, unread, absent) → null,
 * because absent is not false. Pure.
 */
export function taxCodesOf(ledger, ledgerName = null) {
  if (!ledger || typeof ledger !== "object" || ledger.configured !== true) return null;
  const name = typeof ledgerName === "string" && ledgerName.trim() ? ledgerName.trim() : "your ledger";
  if (ledger.sendsTaxCodes === true) return `GST goes to ${name} as each line's tax code.`;
  if (ledger.sendsTaxCodes === false) return `GST is a journal line of its own; no tax code goes to ${name}.`;
  return null;
}
