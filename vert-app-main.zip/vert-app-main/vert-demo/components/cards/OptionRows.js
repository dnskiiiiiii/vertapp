"use client";

// components/cards/OptionRows.js — THE ROWS A DECISION ASKS WITH, AND THE FOOT IT COMMITS FROM
// ==============================================================================
// Eval r2 §17.4: Month-end drew the same kind of question three ways — numbered rows in
// the chat, a "Choose one" select on the GST card, and a select for the deposit's ground.
// Design-fix-2 (DA2-008, DA2-036, DA2-050, DA2-026; founder decision D10) makes the ONE
// decision card everywhere, so the row, the foot and the skip live here and the thread's
// question (components/chat/Clarification.js), the Month-end deposit question
// (ChooseDepositQuestion.js) and the GST card all draw them.
//
// A ROW PRESS SELECTS; IT NEVER SENDS (D10). Only the card's commit, "Use this one", or
// Enter records anything, so a stray click on a row is always undoable.
//
// THE ROW (spec §2.5, §7.2). A leading radio in ink (filled when chosen, a hollow circle in
// ink-3 when not), the label at body 14/400 (500 when chosen), Vert's guess as an inline
// "Suggested" tag right after the label (never the attention ink, never far right), and
// the number key as a key cap that shows on hover and keyboard focus. Selected is told
// from hover by SHAPE: the filled radio and an inset 1 px ring, not a lightness step.
// The row bleeds 0.75rem into the card's padding so the radio sits on the title's edge.
//
// THE KEYS: ↑/↓ move, a digit picks that row, Enter commits, Esc only lets go of the card
// (it never skips). Roving tabindex, so Tab enters the group once and leaves it once.

import { useCallback, useEffect, useId, useRef, useState } from "react";
import { Button, KbdHints, Portal } from "@/components/ui";
import { InsideControl } from "@/components/ui/Figure";
import { showsRegisterChrome } from "@/components/shared/registerChrome";
import { IconCaretRight, IconRadioOff, IconRadioOn, IconSearch } from "@/components/ui/icons";

/** The tag on Vert's guess (DA2-050): a quiet caption, said right after the label. */
export const SUGGESTED = "Suggested";

/** The key hints a decision card's foot shows while it has focus (spec §7.2). */
export const DECISION_HINTS = Object.freeze([
  { keys: ["↑", "↓"], label: "Move" },
  { keys: ["↵"], label: "Use" },
]);

/** One option row. `n` is its 1-based number (its key); `tag` marks Vert's guess. */
export function OptionRow({ n, label, detail = null, chosen = false, guess = false, tag = SUGGESTED, tabIndex, onSelect, onFocus, busy = false, busyLabel = "Sending…", disabled = false, describedBy, value }) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={chosen ? "true" : "false"}
      className="chat-option"
      data-option=""
      data-value={value}
      data-best-guess={guess ? "" : undefined}
      data-chosen={chosen ? "" : undefined}
      data-sending={busy ? "" : undefined}
      aria-busy={busy ? "true" : undefined}
      aria-disabled={disabled ? "true" : undefined}
      aria-describedby={describedBy}
      tabIndex={tabIndex}
      onFocus={onFocus}
      onClick={disabled ? undefined : onSelect}
    >
      <span className="chat-option-mark" aria-hidden="true">
        {chosen ? <IconRadioOn size={16} /> : <IconRadioOff size={16} />}
      </span>
      <InsideControl.Provider value>
        <span className="chat-option-label">
          <span className="chat-option-text">
            {label}
            {guess ? <span className="chat-option-tag">{tag}</span> : null}
          </span>
          {detail ? <span className="chat-option-detail">{detail}</span> : null}
        </span>
      </InsideControl.Provider>
      {busy ? (
        <span className="chat-option-sending" role="status">
          {busyLabel}
        </span>
      ) : n >= 1 && n <= 9 ? (
        <kbd className="kbd chat-option-key" aria-hidden="true">
          {n}
        </kbd>
      ) : null}
    </button>
  );
}

/** Up to this many options are all rows; past it, the first few, a search and "Other…" (DA2-026). */
export const ROWS_MAX = 5;
/** How many rows a long list shows before "Other…": Vert's guess (drawn first) and the next three. */
export const ROWS_SHORT = 4;

/** An option's words, for the search. */
function optionWords(o) {
  return [o && o.label, o && o.detail].filter((v) => typeof v === "string").join(" ").toLowerCase();
}

/**
 * Which rows a long list shows (DA2-026; critic r1 F8): every row when there are five or
 * fewer; otherwise the first ROWS_SHORT (the caller draws its guess first) plus the chosen
 * row, all of them once "Other…" is pressed, and, while there is a search, exactly the
 * rows whose words hold it. Returns a boolean per option. Pure.
 */
export function shownRows(options, { value = null, filter = "", showAll = false } = {}) {
  const list = Array.isArray(options) ? options : [];
  if (list.length <= ROWS_MAX) return list.map(() => true);
  const q = String(filter || "").trim().toLowerCase();
  if (q) return list.map((o) => optionWords(o).includes(q));
  return list.map((o, i) => showAll || i < ROWS_SHORT || (value != null && o.value === value));
}

/**
 * `options` are `{ value, label, detail? }`. `guess` is the value Vert starts on (drawn
 * first by the caller and tagged); null marks nothing.
 *
 * A LONG LIST (more than five, the GST card's seven grounds) shows the first four, a
 * "Search…" row and "Other… (3 more)". The rows it does not show are still drawn, hidden,
 * so the whole closed vocabulary stays on the card for a reader of the markup and the
 * keys move only through the rows that show.
 */
export default function OptionRows({ options, value, onChange, label, guess = null, guessWord = SUGGESTED, onEnter = null, name = undefined }) {
  const listRef = useRef(null);
  const filterId = useId();
  const [filter, setFilter] = useState("");
  const [showAll, setShowAll] = useState(false);
  const list = Array.isArray(options) ? options : [];
  // A list past five rows gets the search (DA2-026); a register's own threshold gives it
  // one too, whatever the five (components/shared/registerChrome.js).
  const long = list.length > ROWS_MAX || showsRegisterChrome(list.length);
  const shown = shownRows(list, { value, filter, showAll });
  const visible = list.filter((_, i) => shown[i]);
  const hiddenCount = list.length - visible.length;
  const searching = long && filter.trim() !== "";

  function focusRow(index) {
    const rows = listRef.current ? listRef.current.querySelectorAll("li:not([hidden]) > [data-option]") : [];
    if (rows[index]) rows[index].focus();
  }

  function onKeyDown(event) {
    if (!visible.length) return;
    if (event.target && event.target.id === filterId) {
      if (event.key === "ArrowDown") {
        event.preventDefault();
        focusRow(0);
      }
      return;
    }
    const at = Math.max(0, visible.findIndex((o) => o.value === value));
    let next = null;
    if (event.key === "ArrowDown") next = (at + 1) % visible.length;
    else if (event.key === "ArrowUp") next = (at + visible.length - 1) % visible.length;
    else if (/^[1-9]$/.test(event.key) && Number(event.key) <= visible.length) next = Number(event.key) - 1;
    else if (event.key === "Enter" && value && onEnter && event.target && event.target.hasAttribute && event.target.hasAttribute("data-option")) {
      event.preventDefault();
      onEnter();
      return;
    }
    if (next == null) return;
    event.preventDefault();
    onChange(visible[next].value);
    focusRow(next);
  }

  const tabTarget = visible.some((o) => o.value === value) ? value : visible.length ? visible[0].value : null;
  let n = 0;
  return (
    <div className="option-rows" data-long={long ? "" : undefined} onKeyDown={onKeyDown}>
      {long ? (
        <div className="chat-q-filter chat-q-search">
          <label className="chat-visually-hidden" htmlFor={filterId}>
            {`Search ${label ? String(label).toLowerCase() : "the choices"}`}
          </label>
          <IconSearch className="chat-q-search-glyph" size={14} aria-hidden="true" />
          <input
            id={filterId}
            name={name ? `${name}-search` : "search"}
            className="chat-field chat-q-search-field"
            type="search"
            autoComplete="off"
            placeholder="Search…"
            value={filter}
            onChange={(event) => setFilter(event.target.value)}
          />
        </div>
      ) : null}
      {searching && !visible.length ? <p className="chat-q-empty">Nothing matches “{filter.trim()}”.</p> : null}
      <ol className="chat-options dcard-choices" ref={listRef} role="radiogroup" aria-label={label} data-name={name}>
        {list.map((o, i) => {
          const show = shown[i];
          if (show) n += 1;
          return (
            <li key={o.value} role="none" hidden={show ? undefined : true}>
              <OptionRow
                n={show ? n : 0}
                value={o.value}
                label={o.label}
                detail={o.detail}
                chosen={value === o.value}
                guess={guess != null && o.value === guess && !searching}
                tag={guessWord}
                tabIndex={show && o.value === tabTarget ? 0 : -1}
                onSelect={() => onChange(o.value)}
              />
            </li>
          );
        })}
        {long && !showAll && !searching && hiddenCount > 0 ? (
          <li role="none">
            <button type="button" className="chat-option chat-option-other" data-option-other="" tabIndex={-1} onClick={() => setShowAll(true)}>
              <span className="chat-option-mark" aria-hidden="true">
                <IconCaretRight size={16} />
              </span>
              <span className="chat-option-label">Other… ({hiddenCount} more)</span>
            </button>
          </li>
        ) : null}
      </ol>
    </div>
  );
}

/**
 * THE ONE FOOT (spec §7.2): the key hints on the left (shown only while the card has
 * focus, hidden below a 520 px card), then the quiet ways out, then the one commit,
 * trailing, so the eye ends on it. `children` are the quiet buttons in order (Open in
 * chat, Skip); `commit` is the commit element.
 */
/** The hints on a card Esc can skip (the reference: "↑↓ to navigate · Enter to select · Esc to skip"). */
export const DECISION_HINTS_SKIP = Object.freeze([...DECISION_HINTS, { keys: ["Esc"], label: "Skip" }]);

export function DecisionFoot({ hints = DECISION_HINTS, children, commit, className }) {
  return (
    <div className={["dfoot", className].filter(Boolean).join(" ")} data-decision-foot="">
      {hints && hints.length ? <KbdHints className="dfoot-keys" hints={hints} /> : null}
      <div className="dfoot-actions">
        {children}
        {commit}
      </div>
    </div>
  );
}

/** How long "Skipped. Undo" stays before the skip is sent (spec §7.2: 5 s). */
export const SKIP_UNDO_MS = 5000;

/**
 * SKIP WITH UNDO (spec §7.2, D10). Skip happens only through the Skip button, and it is
 * held for five seconds behind a "Skipped. Undo" toast: Undo within that time sends
 * nothing at all; otherwise the skip is sent as before. A card that unmounts while a skip
 * is held sends it then, so leaving the page never loses a skip the person made.
 *
 * `send()` sends the skip and returns its result. Returns `{ pending, skip, undo, toast }`;
 * `toast` is the element to render (null when nothing is held).
 */
export function useDeferredSkip(send, { delay = SKIP_UNDO_MS } = {}) {
  const [pending, setPending] = useState(false);
  const timer = useRef(null);
  const sendRef = useRef(send);
  sendRef.current = send;
  const held = useRef(false);

  const flush = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    if (!held.current) return;
    held.current = false;
    setPending(false);
    Promise.resolve(sendRef.current()).catch(() => {});
  }, []);

  const skip = useCallback(() => {
    if (held.current) return;
    held.current = true;
    setPending(true);
    timer.current = setTimeout(flush, delay);
  }, [delay, flush]);

  const undo = useCallback(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = null;
    held.current = false;
    setPending(false);
  }, []);

  // Leaving with a skip held sends it: the person pressed Skip and did not undo it.
  useEffect(() => () => flush(), [flush]);

  const toast = pending ? <SkipToast onUndo={undo} /> : null;
  return { pending, skip, undo, toast };
}

/** "Skipped. Undo", bottom-centre over everything but tooltips (--z-toast). */
export function SkipToast({ onUndo, text = "Skipped." }) {
  return (
    <Portal>
      <div className="toast" role="status" aria-live="polite" data-skip-toast="">
        <span className="toast-text">{text}</span>
        <Button variant="quiet" size="sm" className="toast-action" onClick={onUndo}>
          Undo
        </Button>
      </div>
    </Portal>
  );
}
