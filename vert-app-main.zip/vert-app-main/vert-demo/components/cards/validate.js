// components/cards/validate.js — A CARD'S REQUIRED FIELDS SAY SO WHEN YOU LEAVE THEM
// ==============================================================================
// Spec §5.2 and §11.6; audit UI-015. The field kit (components/ui/fields.js) validates
// on blur, never on submit alone: a person who tabs out of an empty "How do you know?"
// is told, under that field, before they press anything. The cards used to check only
// inside their commit's press handler, so the eval blurred an emptied note and found
// `aria-invalid` unset and no message until Save was pressed — UI-015 still open.
//
// ONE RULE, TWO WIRINGS, BECAUSE THE KIT HAS TWO SHAPES.
//   · A text `Field` takes `validate(value) → message | null` and runs it on blur. Its
//     message sits under the input, joined by `aria-describedby`, and the input is
//     `aria-invalid`. Typing clears it.
//   · A `SelectField` takes no `validate` (its value can't be emptied once chosen, so
//     only "never chosen" can be wrong). The card holds the message in its own
//     `errors` and hands it back as the field's `error`; `onBlurRequired` sets it when
//     the select is left unchosen, and `clearOnChange` clears it on a choice.
// The press handler checks the same rules with the same sentences (`missing`), so the
// blur and the press can never disagree about what is wrong.
//
// NOTHING HERE RESETS A VALUE (UI-052). A message is about the value; the value stays.

/** A validator for a required text field: null when filled, else `message`. */
export function required(message) {
  return (value) => (String(value ?? "").trim() ? null : message);
}

/**
 * An `onBlur` for a required select: leaving it unchosen puts `message` on the field
 * (through the card's `errors[key]`). A chosen value leaves the errors alone.
 */
export function onBlurRequired(setErrors, key, message) {
  return (event) => {
    const value = event && event.target ? event.target.value : "";
    if (String(value ?? "").trim()) return;
    setErrors((prev) => (prev[key] === message ? prev : { ...prev, [key]: message }));
  };
}

/**
 * An `onChange` that sets the value and clears that field's message: the message was
 * about the old value (fields.js rule 3). Clearing it in the card as well as in the
 * field matters — the kit hides a caller's message the person has typed over by
 * comparing text, so a card that left the same sentence set would find its next
 * identical complaint hidden.
 */
export function clearOnChange(setErrors, key, set) {
  return (event) => {
    set(event.target.value);
    setErrors((prev) => (prev[key] ? { ...prev, [key]: undefined } : prev));
  };
}

/**
 * The press's check: `{ key: [value, message] }` → the messages for the fields that
 * are empty (the same sentences the blur shows). `ok(value)` overrides "non-empty"
 * for a field whose value must be one of a vocabulary.
 */
export function missing(rules) {
  const out = {};
  for (const [key, rule] of Object.entries(rules)) {
    const [value, message, ok] = rule;
    const fine = ok ? ok(value) : Boolean(String(value ?? "").trim());
    if (!fine) out[key] = message;
  }
  return out;
}
