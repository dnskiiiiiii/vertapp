"use client";

// components/cards/SkillUpdateCard.js — A PROPOSED CHANGE TO A TASK'S SKILL, AS A DIFF
// ==============================================================================
// Build plan §19.0.5, §19.7 F-PLAN. The engine proposes an update from one of four
// sources (an answer the steps don't cover, a plan changed before it started, an entry
// corrected before approval, a follow-up that changed the output: vert_engine/skills/
// proposer.py). The card is a line diff and two presses:
//
//   Update the Payroll skill                          ← the engine's proposal
//   Your follow-up changed what Vert produced.        ← why
//   Added to the steps
//     + Book the auto-reversal on the 1st of next month.   ← purple tint, never green
//   Capitalisation threshold
//     $2,500.00                                        ← muted, struck, never red
//     $5,000.00                                        ← purple tint
//                                       Not now   [■ Apply]
//
// After Apply, "What changed" lists what the engine wrote (the apply route's own
// `changes`, read back from the skill in force), not what the card proposed: a person
// may have edited the skill since, and the engine re-derives the change against that.
//
// The before/after words are the engine's (`prefill.changes`, money already phrased by
// the skill's one phrase writer). Nothing here formats or compares a value.

import "@/components/chat/plan/plan.css";
import { useState } from "react";
import { Button, Notice } from "@/components/ui";
import { declineDecision } from "@/lib/actions";
import { applySkillUpdate } from "@/lib/skills";
import { useWritesEnabled } from "@/lib/engine-context";
import Card from "./Card";
import { SAMPLE_REASON } from "./words";
import { useDuties } from "@/lib/store";
import { EDIT_SKILLS_REASON, may } from "@/lib/roles";

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);

/** The change rows a card draws: `{field, label, before, after}`, words only. */
function wordsOf(v) {
  return typeof v === "string" && v.trim() ? v : null;
}

export function skillChanges(action) {
  const p = isObj(action) && isObj(action.prefill) ? action.prefill : {};
  const list = Array.isArray(p.changes) ? p.changes : [];
  return list
    .filter((c) => isObj(c) && (typeof c.after === "string" || typeof c.before === "string"))
    .map((c, i) => ({
      field: typeof c.field === "string" && c.field ? c.field : `change-${i}`,
      label: typeof c.label === "string" && c.label ? c.label : "Change",
      // A choice is said by its label, never its id (verify pass 1, W11: "Now nsw"): the
      // engine's `beforeLabel` / `afterLabel` when it sends them.
      before: wordsOf(c.beforeLabel) || wordsOf(c.before),
      after: wordsOf(c.afterLabel) || wordsOf(c.after),
    }));
}

/** The task the update is for: the target's id (the engine's `target.id`), else the request's. */
export function skillTemplateOf(action) {
  const a = isObj(action) ? action : {};
  if (isObj(a.target) && typeof a.target.id === "string" && a.target.id) return a.target.id;
  return isObj(a.prefill) && typeof a.prefill.template === "string" ? a.prefill.template : null;
}

/**
 * The change rows, marked in WORDS and weight, never in red, green or the accent (U54;
 * W18/OU14: the inserted line was tinted the accent's green). "Was" over the struck old
 * words, "Now" over the new ones. `numbered` draws the applied outline as a numbered
 * list ("What changed", the checklist's numbered outline).
 */
export function DiffLines({ changes, numbered = false }) {
  const List = numbered ? "ol" : "ul";
  return (
    <List className={["skill-diff", numbered ? "skill-diff-numbered" : null].filter(Boolean).join(" ")} data-skill-diff="">
      {changes.map((c, i) => (
        <li key={c.field} className="skill-diff-row">
          {/* THE NUMBER IS DRAWN, not left to the list marker (verify pass 4, Q15): the
              rows are grid boxes, and a grid <li> has no ::marker, so the <ol> showed no
              numbers at all and "What changed" read as an un-numbered list. */}
          <span className="skill-diff-label t-footnote">
            {numbered ? <span className="skill-diff-n">{`${i + 1}. `}</span> : null}
            {c.label}
          </span>
          {c.before ? (
            <span className="skill-diff-pair">
              <span className="skill-diff-word t-footnote">Was</span>
              <del className="skill-diff-line diff-del" data-diff="removed">
                {c.before}
              </del>
            </span>
          ) : null}
          {c.after ? (
            <span className="skill-diff-pair">
              <span className="skill-diff-word t-footnote">{c.before ? "Now" : "Added"}</span>
              <ins className="skill-diff-line diff-ins" data-diff="added">
                {c.after}
              </ins>
            </span>
          ) : null}
        </li>
      ))}
    </List>
  );
}

/** "What changed in version 2", or "What changed" when the version isn't known. */
export function appliedHeading(version) {
  return Number.isInteger(version) && version > 0 ? `What changed in version ${version}` : "What changed";
}

/**
 * What a press leaves the card showing: `{applied: {changes}}` (the apply route's own
 * `changes`, or null when it named none), `{dismissed: true}`, or `{failure}` with the
 * route's words. Pure, so tests/skill-update.test.js walks it without a browser.
 */
export function afterPress(which, answer) {
  if (!answer || answer.ok !== true) return { failure: (answer && answer.message) || "Nothing was changed." };
  if (which !== "apply") return { dismissed: true };
  const result = answer.result || {};
  // The version the apply wrote (`skill.version`, the route's read-back), for the
  // outline's "now v4"; null when the route didn't say.
  const version = isObj(result.skill) && Number.isInteger(result.skill.version) ? result.skill.version : null;
  return { applied: { changes: Array.isArray(result.changes) ? skillChanges({ prefill: { changes: result.changes } }) : null, version } };
}

/**
 * What a card SETTLED ON THE STREAM shows (eval r1 #18 / SK2). In the conversation the
 * Apply comes back as a `decision_settled` event, and the thread used to draw the
 * generic "Decided · Sam Lee" plate in place of the card, so "What changed" was never
 * on screen. `applied` with a verified read-back means the skill in force now says what
 * the card proposed (vert_engine/skills/proposer.py read_back_update), so the proposed
 * rows ARE what changed; `already_applied` added nothing; anything unverified says so
 * rather than claiming the change. A decline is "Not now". Pure, for the tests.
 */
export function settledView(action, settled) {
  const s = isObj(settled) ? settled : null;
  if (!s) return null;
  const outcome = typeof s.outcome === "string" ? s.outcome : "";
  if (outcome === "already_applied") return { applied: { changes: [] } };
  if (outcome === "applied" || outcome === "approved") {
    const version = Number.isInteger(s.version) ? s.version : isObj(s.skill) && Number.isInteger(s.skill.version) ? s.skill.version : null;
    if (s.verified === true) return { applied: { changes: skillChanges(action), version } };
    return { applied: { changes: skillChanges(action), unconfirmed: true, version } };
  }
  return { dismissed: true };
}

/**
 * `apply` and `notNow` are the press roads (lib/skills.js applySkillUpdate, lib/actions.js
 * declineDecision), replaceable in tests.
 */
export default function SkillUpdateCard({ action, apply = applySkillUpdate, notNow = declineDecision, initial = null, settled = null }) {
  const writesEnabled = useWritesEnabled();
  const duties = useDuties();
  const fromStream = settledView(action, settled || (action && action.settled));
  const seed = initial && typeof initial === "object" ? initial : fromStream || {};
  const [busy, setBusy] = useState(null);
  const [failure, setFailure] = useState(seed.failure || null);
  const [applied, setApplied] = useState(seed.applied || null);
  const [dismissed, setDismissed] = useState(seed.dismissed === true);
  const changes = skillChanges(action);
  const template = skillTemplateOf(action);
  const actionId = action && action.actionId;
  if (!changes.length || !template) return <Card action={action} kind="skill_update" />;

  async function press(which) {
    if (busy) return;
    setBusy(which);
    setFailure(null);
    let answer = null;
    try {
      answer = which === "apply" ? await apply(template, actionId) : await notNow(actionId);
    } catch {
      answer = null;
    }
    setBusy(null);
    const next = afterPress(which, answer);
    if (next.failure) setFailure(next.failure);
    else if (next.applied) setApplied(next.applied);
    else setDismissed(true);
  }

  const shownApplied = applied || (fromStream && fromStream.applied) || null;
  if (shownApplied) {
    // The outline replaces the card, on the document type scale with no tint behind
    // it: a heading, then each change as removed / added lines (theme tokens only).
    return (
      <section className="skill-update skill-changed" data-card="skill_update" data-state="applied" aria-label="What changed">
        <h3 className="skill-changed-h t-title-3" data-skill-version={Number.isInteger(shownApplied.version) ? shownApplied.version : undefined}>
          {/* "What changed in version 2" (verify pass 4, Q15 line 4: "numbered outline
              (v n+1)"). The steps sheet already tags its versions ("V1, edited by Sam"),
              so the number is the person's too; the 10 Oct bug bash that dropped it was
              another session's call, not a founder decision. Unknown (a reload from
              the stream, which carries no version), it is not guessed. */}
          {appliedHeading(shownApplied.version)}
        </h3>
        {shownApplied.changes && shownApplied.changes.length ? (
          <DiffLines changes={shownApplied.changes} numbered />
        ) : (
          <p className="t-footnote skill-changed-note">Nothing new: the steps already said this, so nothing was changed.</p>
        )}
        {shownApplied.unconfirmed ? (
          <p className="t-footnote skill-changed-note">Vert couldn't read the steps back to confirm this change.</p>
        ) : shownApplied.changes && shownApplied.changes.length ? (
          <p className="t-footnote skill-changed-note">Saved. Vert follows this from next time.</p>
        ) : null}
      </section>
    );
  }

  if (dismissed) {
    return (
      <div className="dcard skill-update" data-card="skill_update" data-state="dismissed">
        <p className="t-footnote">Not now. Vert keeps the steps as they are.</p>
      </div>
    );
  }

  const reason = writesEnabled ? null : SAMPLE_REASON;
  // A PREPARER IS NOT OFFERED APPLY (verify pass 3, S-E2E-1): the press was refused only
  // after it was made. The engine lets a reviewer or an admin change a client's steps
  // (`edit_skills`); for anyone else the card says who can, in place of the button.
  const role = duties ? duties.role || duties.gatedAs || null : null;
  const cannotApply = may(role, "edit_skills") === false;
  return (
    <div className="dcard skill-update" data-card="skill_update">
      {action.proposal ? <p className="t-body card-proposal">{action.proposal}</p> : null}
      {action.why ? <p className="t-footnote card-why">{action.why}</p> : null}
      <DiffLines changes={changes} />
      {failure ? (
        <Notice kind="error" recorded="nothing">
          {failure}
        </Notice>
      ) : null}
      <div className="skill-update-foot">
        <Button variant="quiet" onClick={() => press("not_now")} busy={busy === "not_now"} disabledReason={reason} data-skill-press="not_now">
          Not now
        </Button>
        {/* Secondary, not the accent: a skill change writes no entry to the books, and the
            accent stays with the view's one ledger commit, so this card can stay open
            beside it and Apply is one press (W18/OU14: a closed row made it two). */}
        {cannotApply ? (
          <p className="t-footnote skill-update-who" data-skill-gate="">
            {EDIT_SKILLS_REASON}
          </p>
        ) : (
          <Button variant="secondary" onClick={() => press("apply")} busy={busy === "apply"} disabledReason={reason} data-skill-press="apply">
            Apply
          </Button>
        )}
      </div>
    </div>
  );
}
