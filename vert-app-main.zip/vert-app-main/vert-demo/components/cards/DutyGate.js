// components/cards/DutyGate.js — THE GATE SENTENCE IN PLACE OF A COMMIT (§20.12 H3, P07)
// =====================================================================================
// A person whose role can't approve or post (a preparer; the drafter of the entry in
// a firm that splits the work) is told why, in one sentence, where the commit would
// sit. No "Approve and post…" is drawn for them at all — not even dead beside the
// reason: verify pass 1 (P07) saw Priya offered an aria-disabled commit, and the
// checklist asks for "the gate sentence instead of an Approve-and-post commit".
//
// A gate about the ENTRY (unbalanced, legs off the chart) still draws the commit dead
// with its reason: that person could approve once the entry is fixed.

export default function DutyGate({ reason }) {
  if (!reason) return null;
  return (
    <p className="dcard-reason dcard-duty-gate t-footnote" data-duty-gate="" role="note">
      {reason}
    </p>
  );
}
