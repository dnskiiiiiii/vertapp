"use client";

// components/cards/PlanCard.js — "PLAN / FIXED ASSETS — SEPTEMBER CLOSE · REVIEW"
// ==============================================================================
// Build plan §19.0.6, §19.7 F-PLAN; the reference's plan line. A planning task puts its
// plan to you as one line in the thread, not a card full of buttons:
//
//   Plan                                     (or "Updated plan", once it is re-emitted)
//   Fixed assets, September close · Review
//
// The plan's name leads; the kicker says what it is. It used to lead with "Created
// plan", which named the event, not the plan (eval r2 §17.4).
//
// IN THE CONVERSATION Review opens the plan as a document
// (components/chat/plan/PlanDocument.js) in the result pane beside the chat (the pane's
// editor slot, `EditorFor("plan")`), under the pane header "Plan". The document's footer
// holds the presses (Save changes · Reject · Start now), so the one purple control is
// never on this line. A conversation opened at `?plan=<planId>` (or `?plan=open`) opens
// that plan in the pane on arrival: that is where Month-end's card sends you.
//
// ON MONTH-END (no pane) the card names its task — "Fixed assets plan · September
// 2026" — and its Review is a link to the task's conversation with the plan open, so
// Plan → Start now is two presses: Review, then Start now (eval r1 #10). The engine's
// Month-end request carries only `prefill.planId`, not the plan body, and the card used
// to fall back to the generic card with "Record plan:…:6039a968e6d3 Decision a-10" in
// its Details and no way to the plan at all. No session to link to and no body to show:
// it is drawn as its proposal with no press, because a Review that opened nothing would
// be a false affordance. The sheet stays for a body with no session (a test, a replay).
//
// A SCHEDULED PLAN SAYS SO ON MONTH-END (build plan §20.4 "Scheduled for 1 Nov, 9:00 ·
// Cancel on the task"; §20.6 F-POL4). Once the engine re-emits the plan with a live
// `triggers.schedule`, the card adds "Scheduled for 1 Nov, 9:00" under its line, in the
// client's time, so nobody reviews a plan by hand that is already set to start on its
// own. Cancel is NOT drawn here: it lives in the plan document the Review link opens,
// where the cancel's outcome is read back; a second Cancel on Month-end would be a second
// road with no read-back. A cancelled schedule, or none, draws nothing.

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Button, Sheet } from "@/components/ui";
import { useWritesEnabled } from "@/lib/engine-context";
import { decidePlan } from "@/lib/agent/plan-actions";
import { SAMPLE_REASON } from "@/components/cards/words";
import { usePane } from "@/components/chat/results/paneContext";
import PlanDocument from "@/components/chat/plan/PlanDocument";
import { ScheduledLine } from "@/components/chat/plan/TriggersSection";
import { PLAN_TITLE, monthWords, openedAtPlan, planHref, planIdOf, planLine, planOf, planTitle } from "@/lib/agent/plan";

import { IconCaretRight } from "@/components/ui/icons";
import ArtifactCard from "@/components/chat/ArtifactCard";
const named = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

export const PLAN_LOADING = "Loading the plan…";
export const PLAN_LATE = "The plan hasn't arrived yet. Reload the conversation to see it.";
const PLAN_LATE_MS = 30000;

/**
 * The Month-end card's line: "Fixed assets plan · September 2026", never an id. The
 * task is named from the Month-end row, else the action's or the plan's own task title
 * (W0c CO-23; eval r3 walkthrough #10: a plan card that did not say whose plan it was).
 * "A plan" only when nothing names one.
 */
export function planCardLine(task, plan, action) {
  const name = named(task && task.title) || named(action && action.taskTitle) || named(plan && plan.taskTitle);
  const title = name ? `${name} plan` : "A plan";
  const period = (plan && plan.scope && plan.scope.period) || (action && action.period) || (task && task.period) || null;
  return [title, monthWords(period)].filter(Boolean).join(" · ");
}

/** The plan's live scheduled start, or null (a cancelled one is not live). */
export function scheduleOf(plan) {
  const t = plan && typeof plan === "object" ? plan.triggers : null;
  const s = t && typeof t === "object" ? t.schedule : null;
  return s && typeof s === "object" && !s.cancelled && typeof s.fireAt === "string" ? s : null;
}

export default function PlanCard({ action, ledgerName = null, task = null }) {
  const pane = usePane();
  const [open, setOpen] = useState(false);
  const plan = planOf(action);
  const planId = planIdOf(action);
  const taskTitle = (action && action.taskTitle) || (task && task.title) || null;
  const arrived = useRef(false);
  const settled = Boolean(action && action.settled);
  const writes = useWritesEnabled();
  const [starting, setStarting] = useState(false);
  const [started, setStarted] = useState(false);
  const [startFailed, setStartFailed] = useState(null);
  // Start now, from the card: the plan document's own press (decidePlan "approve").
  async function start() {
    if (starting || !action || action.actionId == null) return;
    setStarting(true);
    setStartFailed(null);
    let answer = null;
    try {
      answer = await decidePlan(action.actionId, "approve", { planId: planIdOf(action), revalidate: true });
    } catch {
      answer = null;
    }
    setStarting(false);
    if (answer && answer.ok) setStarted(true);
    else setStartFailed((answer && answer.message) || "Nothing was started.");
  }

  function review(event) {
    const trigger = event && event.currentTarget;
    if (pane && typeof pane.editEntry === "function") pane.editEntry({ ...action, plan, taskTitle, title: PLAN_TITLE }, trigger);
    else setOpen(true);
  }

  // Arrived from Month-end at this plan: open it in the pane once.
  useEffect(() => {
    if (arrived.current || !pane || !plan || typeof window === "undefined") return;
    if (!openedAtPlan(window.location.search, planId, { decided: settled })) return;
    arrived.current = true;
    pane.editEntry({ ...action, plan, taskTitle, title: PLAN_TITLE }, null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pane, plan, planId, settled]);

  // A PLAN NAMED BUT NOT YET HERE (verify pass 9, S-E2E-1). The start request can reach
  // the thread before the plan it names: at 9 s a conversation showed a bare "Start this
  // plan?" with no button, and the plan card came by 20 s. Until it arrives the card is
  // drawn loading, under the plan's name; one that still hasn't come after a while says
  // so, rather than claiming to load for ever.
  const awaiting = !plan && !settled && Boolean(planId);
  const [late, setLate] = useState(false);
  useEffect(() => {
    if (!awaiting) return undefined;
    const timer = setTimeout(() => setLate(true), PLAN_LATE_MS);
    return () => clearTimeout(timer);
  }, [awaiting]);

  // Month-end: name the task and link to the conversation at the plan.
  const href = !pane && task ? planHref(task.sessionId, planId) : null;
  if (href) {
    return (
      <article className="plan-line-card" data-card="plan" data-plan={planId || ""} data-plan-where="month">
        <p className="plan-line t-body">
          <span className="plan-line-text">{planCardLine(task, plan, action)}</span>
        </p>
        {action && action.why ? <p className="plan-line-sub t-footnote">{action.why}</p> : null}
        {scheduleOf(plan) ? (
          <p className="plan-line-sub">
            <ScheduledLine schedule={scheduleOf(plan)} />
          </p>
        ) : null}
        <p className="plan-line t-body">
          <Link className="chat-quiet plan-review" data-plan-press="review" href={href}>
            Review the plan<IconCaretRight className="caret-trailing" />
          </Link>
        </p>
      </article>
    );
  }

  if (awaiting) {
    return (
      <article className="plan-line-card plan-artifact" data-card="plan" data-plan={planId} data-plan-where="loading" aria-busy={late ? undefined : "true"}>
        <ArtifactCard type="plan" title={planCardLine(task, null, action)} meta={late ? PLAN_LATE : PLAN_LOADING} />
      </article>
    );
  }

  if (!plan) {
    // Nothing to open: the plan named in words, no press, and no record ids (no Details).
    // Never the engine's bare "Start this plan?": a question with no way to answer it.
    return (
      <article className="plan-line-card" data-card="plan" data-plan={planId || ""} data-plan-where="none">
        <p className="plan-line t-body">
          <span className="plan-line-text">{planCardLine(task, null, action)}</span>
        </p>
        {action && action.why ? <p className="plan-line-sub t-footnote">{action.why}</p> : null}
      </article>
    );
  }
  const sub = planTitle(plan, taskTitle);

  // IN THE THREAD THE PLAN IS ONE ARTIFACT CARD (design-fix-2 DA2-024, §7.1): the plan
  // glyph, its title, what it is waiting on, and the whole card opens it in the pane.
  // The "Plan … · Review" row and the answer's separate "Review the plan" button were
  // two more ways to the same document (Thread.js drops that button for a plan card).
  const kicker = planLine(plan);
  // READY TO START, ON THE CARD (founder's walk, 8 Nov 2026): "Needs you" on Month-end
  // meant "start this plan", and Start now was inside the plan's document, behind View
  // plan. The card says so and carries the press; the document is still one press away.
  const waiting = settled || started ? null : "Ready to start";
  return (
    <article className="plan-line-card plan-artifact" data-card="plan" data-plan={plan.planId || ""}>
      <ArtifactCard
        type="plan"
        title={sub}
        meta={[kicker !== "Plan" ? kicker : null, waiting].filter(Boolean).join(", ") || null}
        onOpen={review}
        pressProps={{ "data-plan-press": "review", "aria-haspopup": "dialog" }}
        tools={
          <>
            {/* A NAMED "View plan" (verify pass 4, W09 F15): the reference's plan line has a
                View plan button, and a card that opens only by pressing its body has no word
                saying it opens. Same press as the card, said in words. */}
            <button type="button" className="btn btn-quiet btn-sm artifact-view" data-plan-press="view" aria-haspopup="dialog" onClick={review}>
              View plan
            </button>
            {!settled && !started && action && action.actionId != null ? (
              <Button variant="commit" size="sm" busy={starting} busyLabel="Starting…" disabledReason={writes ? undefined : SAMPLE_REASON} onClick={start} data-plan-press="start">
                Start now
              </Button>
            ) : null}
          </>
        }
      />
      {started ? (
        <p className="plan-line-sub t-footnote" role="status" data-plan-started="">
          Started. Vert is working through the plan; anything it drafts waits for your approval.
        </p>
      ) : null}
      {startFailed ? (
        <p className="plan-line-sub t-footnote" role="alert">
          {startFailed}
        </p>
      ) : null}
      {!pane ? (
        <Sheet open={open} onClose={() => setOpen(false)} side="right" title={PLAN_TITLE} className="plan-sheet">
          {open ? <PlanDocument action={{ ...action, plan, taskTitle }} ledgerName={ledgerName} revalidate onDone={() => setOpen(false)} /> : null}
        </Sheet>
      ) : null}
    </article>
  );
}
