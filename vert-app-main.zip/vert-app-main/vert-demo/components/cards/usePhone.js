"use client";

// components/cards/usePhone.js — WHETHER THIS IS A PHONE'S WIDTH, FOR A SHEET'S PLACEMENT
// ==============================================================================
// Design pass (spec §6.11, §6.16): a decision that writes is a centred modal on a desk
// and a bottom sheet on a phone, with its commit full width under the thumb. Only a
// sheet that opens on a press asks, so the first render never disagrees with the server.

import { useEffect, useState } from "react";

export const PHONE_QUERY = "(max-width: 639.98px)";

export function usePhone(query = PHONE_QUERY) {
  const [phone, setPhone] = useState(() => (typeof window !== "undefined" && typeof window.matchMedia === "function" ? window.matchMedia(query).matches : false));
  useEffect(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return undefined;
    const list = window.matchMedia(query);
    const on = () => setPhone(list.matches);
    on();
    list.addEventListener("change", on);
    return () => list.removeEventListener("change", on);
  }, [query]);
  return phone;
}
