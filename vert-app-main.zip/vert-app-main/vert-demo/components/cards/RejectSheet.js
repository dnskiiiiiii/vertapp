"use client";

// components/cards/RejectSheet.js — "REJECT THIS ENTRY? IT CAN'T BE REOPENED."
// ==============================================================================
// Spec §3.7 (last bullet); audit UI-003.
//
// WHY A SHEET AND A REASON. Reject used to be one press, the same weight as Approve,
// beside it — and a rejected entry is terminal in the engine (`rejected: []`). One
// misclick withdrew a draft for good. The audit's preferred fix (make rejection
// reopenable) is dropped by the build plan (§0.10), so its fallback is built: the card
// keeps Reject quiet and subordinate, and pressing it opens this smaller sheet that
// says, before anything is sent, that it can't be undone, and asks for the one-line
// reason the audit trail will carry.
//
// It is a modal (a scrim, focus held inside, Esc closes, focus returns to Reject),
// because rejecting is one of the two irreversible acts in the product (spec §1.8).

import { useState } from "react";
import { Button, Field, Notice, Sheet } from "@/components/ui";
import { declineDecision, rejectDraftEntry } from "@/lib/actions";
import { callSafely, useCardCommit } from "@/lib/decisions";
import { required } from "./validate";
import { failureDetails, failureSentence, recordedFor } from "./words";

// THE CARD WAS A PROPOSAL TO APPROVE, and the person said no. The rejection is written
// through the existing route (the approvals table records it, with the reason); the
// card itself is then DECLINED rather than settled, because settling an approve card
// asks the API to find an approval there, and it would rightly answer "not verified".
async function rejectThenDecline(req) {
  const result = await rejectDraftEntry(req.payoutId, req.note);
  if (result && result.ok && typeof req.actionId === "string" && req.actionId) {
    // Best effort: an undeclined card is re-verified and cleared by the next read. The
    // decline answers with the month, which the hook hands to the page (e2e r3 D1).
    const declined = await callSafely(declineDecision, req.actionId);
    if (declined.ok && declined.month) return { ...result, month: declined.month };
  }
  return result;
}

export const REJECT_WARNING = "It can't be reopened.";
export const REJECT_REASON_MESSAGE = "Say why, in a line. It goes on the record.";

export default function RejectSheet({ open, onClose, action, onRejected, initial = null }) {
  const payoutId = (action && action.prefill && action.prefill.payoutId) || (action && action.target && action.target.id) || null;
  const [reason, setReason] = useState("");
  const [error, setError] = useState(null);
  const card = useCardCommit(action, {
    initial,
    onSettled: (done) => {
      if (onRejected) onRejected(done);
    },
  });

  function press() {
    if (!reason.trim()) {
      setError(REJECT_REASON_MESSAGE);
      return;
    }
    card.commit(rejectThenDecline, { payoutId, note: reason.trim(), actionId: action && action.actionId }, { outcome: "rejected", settle: false });
  }

  return (
    <Sheet
      open={open}
      onClose={onClose}
      side="modal"
      title="Reject this entry?"
      className="reject-sheet"
      footer={
        <div className="sheet-actions">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="commit" onClick={press} busy={card.busy} busyLabel="Rejecting…" disabledReason={card.disabledReason}>
            Reject
          </Button>
        </div>
      }
    >
      <p className="t-body">{REJECT_WARNING}</p>
      <Field
        label="Why?"
        value={reason}
        error={error}
        validate={required(REJECT_REASON_MESSAGE)}
        onChange={(e) => {
          setReason(e.target.value);
          setError(null);
        }}
      />
      {card.phase === "failed" && card.result && card.result.kind === "unconfirmed" ? (
        <Notice kind="warning" onRetry={card.writesEnabled ? card.retry : undefined} retryLabel="Check again">
          {failureSentence(card.result)}
        </Notice>
      ) : card.phase === "failed" ? (
        <Notice kind="error" recorded={recordedFor(card.result)} onRetry={card.writesEnabled ? card.retry : undefined} details={failureDetails(card.result)}>
          {failureSentence(card.result)}
        </Notice>
      ) : null}
    </Sheet>
  );
}
