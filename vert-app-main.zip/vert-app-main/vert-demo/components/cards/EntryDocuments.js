"use client";

// components/cards/EntryDocuments.js — THE FILES FILED AGAINST AN ENTRY, WHEREVER IT IS SHOWN (D08)
// ==============================================================================
// Verification pass 2, D08: the engine lists the linked invoice in
// `entry.evidence.documents` before AND after posting, and the draft card showed its
// chip; once the entry posted, the posted plate and the Records entry sheet showed none.
// Evidence that disappears at the moment it matters most (a reviewer looking at what was
// posted) is not evidence. Every surface that shows an entry now draws the same chips
// from the same read (GET /api/journal → journal-model postedReadingOf → entryDocuments).

import { useEffect, useState } from "react";
import { readEntry } from "@/components/records/entry-read-client";
import { useWritesEnabled } from "@/lib/engine-context";
import { fileHref } from "@/components/chat/results/DocumentView";

const ENTRY_ID = /^[a-z]{1,16}:[0-9a-f]{6,64}$/;

/**
 * The documents for `entryId`: `given` when the caller already read them (an array),
 * else one read of the stored entry in a live build. Null until read; [] when none.
 */
export function useEntryDocuments(entryId, given = undefined) {
  const reading = useEntryReading(entryId, Array.isArray(given));
  return Array.isArray(given) ? given : reading && Array.isArray(reading.documents) ? reading.documents : null;
}

/**
 * One read of the stored entry (`GET /journal/{id}` through GET /api/journal), in a live
 * build, unless `skip`. Null until it answers. The posted plate reads its documents and
 * its balance-after sentence from it when the post's own answer carried neither.
 */
export function useEntryReading(entryId, skip = false) {
  const writesEnabled = useWritesEnabled();
  const [read, setRead] = useState(null);
  const id = typeof entryId === "string" && ENTRY_ID.test(entryId) ? entryId : null;
  const needs = Boolean(id && writesEnabled && !skip);
  useEffect(() => {
    if (!needs) return undefined;
    let live = true;
    // A GET through app/api/journal (staging walkthrough D4): this read was the
    // readPostedEntry Server Action, a POST on every mount of a sheet or a plate.
    readEntry(id).then((answer) => {
      const reading = answer && answer.posted;
      if (live && reading && reading.ok) setRead(reading);
    });
    return () => {
      live = false;
    };
  }, [needs, id]);
  return read;
}

/** The chips: one link per document, opening the file. Nothing when there are none. */
export default function EntryDocuments({ documents, className = "" }) {
  if (!Array.isArray(documents) || !documents.length) return null;
  return (
    <ul className={["jcard-evidence", className].filter(Boolean).join(" ")} aria-label="Supporting records" data-entry-documents="">
      {documents.map((d) => (
        <li key={d.documentId} className="jcard-chip jcard-doc t-footnote" data-entry-document={d.documentId}>
          <a className="jcard-doc-link" href={fileHref(d.documentId)} target="_blank" rel="noreferrer">
            {d.name}
            {d.detail ? <span className="jcard-doc-detail"> · {d.detail}</span> : null}
          </a>
        </li>
      ))}
    </ul>
  );
}
