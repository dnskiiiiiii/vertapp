"use client";

// components/cards/PostedPlate.js — A POSTED ENTRY, AS THE BOOKKEEPER NEEDS TO SEE IT
// ==============================================================================
// Eval JE5 (2 Oct). A payout's entry, once posted, collapsed to "Posted $41,855.00 ·
// you · 10:07 · Vert couldn't confirm it was recorded yet": no entry number, no
// narration, no way to go and look at it in the ledger, no check table and no Reverse
// — while the API held the ledger's id the whole time. This is the posted state the
// journal card draws (teardown standards 11–12), for the road a payout's entry takes:
//
//   Posted $41,855.00 · you · 10:07
//   No. 1 · Posted as journal 1 dated 15 Jun 2026.
//   Read back from the ledger: every check passes.
//   Check | Expected | Actual | Result                       ← the engine's, as sent
//   View in QuickBooks Online ↗                       Reverse
//
// NOTHING HERE IS WORKED OUT. The number is the ledger's id from the post's answer (or
// the API's re-read of it), the narration is the engine's sentence, the table is the
// engine's read-back. Reverse drafts a reversing entry through the journal road
// (lib/journal.js reverseEntry): it posts nothing, and the draft waits for a person.

import { useEffect, useId, useState } from "react";
import { Button, Notice } from "@/components/ui";
import BoundText from "@/components/chat/BoundText";
import { callSafely } from "@/lib/decisions";
import { decideAndSettle } from "@/lib/actions";
import { readPostedByGet } from "@/components/records/entry-read-client";
import { payoutStateFor } from "@/lib/feeds";
import { useEngine, useWritesEnabled } from "@/lib/engine-context";
import { useDuties, useSignedInActor } from "@/lib/store";
import { approvalWaitWords } from "@/lib/roles";
import { usePostedFor } from "./journal-edits";
import { balanceWords, engineTotals, entryDateOf, narrationFor, readBackLine, readBackRows, reversalHref, reversalOf, reversalWords, reversedConversation } from "./journal-model";
import { formatMoney, journalNumberOf, ledgerNumber } from "@/lib/format";
import { doneLine, draftPostedWords, failureDetails, failureSentence, recordedFor, ledgerStatusLead, ledgerStatusOf, ledgerStatusTone } from "./words";
import { ReadBackTable } from "./ReadBack";
import { IconExternal, IconStatusDone } from "@/components/ui/icons";
import EntryDocuments, { useEntryReading } from "./EntryDocuments";
import { usePathname } from "next/navigation";

/** What the post's answer says about where the entry went: the number, link, read-back. */
export function postedFacts(result, { date = null } = {}) {
  const r = result && typeof result === "object" ? result : {};
  const body = r.body || {};
  const posted = body.posted || {};
  const reread = r.reread || {};
  // The ledger's number, never its record id (walk 1 D17: lib/format.js journalNumberOf).
  const number = journalNumberOf(posted) || journalNumberOf(reread) || null;
  const card = body.je && typeof body.je === "object" ? body.je : {};
  // The ENTRY's date, never `posted.postedAt` (eval r2 JE5): the narration sits over a
  // read-back whose Date row is the entry's date, and one plate states one date.
  // The caller's date (a payout's arrival day) is only the last resort: the engine's
  // card and the read-back's Expected Date are the entry's own.
  const day = entryDateOf({ card, readBack: body.readBack }) || entryDateOf({ je: { date } });
  return {
    number,
    entryId: typeof posted.entryExternalId === "string" ? posted.entryExternalId : null,
    link: (typeof posted.entryUrl === "string" && posted.entryUrl) || reread.entryUrl || null,
    narration: narrationFor(typeof card.postedNarration === "string" ? card.postedNarration : null, number, day),
    readBack: body.readBack || null,
    ledgerName: (body.ledger && typeof body.ledger.displayName === "string" && body.ledger.displayName) || reread.ledgerName || null,
    ledgerPlatform: (body.ledger && typeof body.ledger.platform === "string" && body.ledger.platform) || null,
    // WHAT THE LEDGER HOLDS OF IT (p1/fix5): "draft" | "posted" as the API answered —
    // the post's own `posted`, else the re-read of the stored entry — or null when no
    // engine said (an older one): then the plate keeps today's wording.
    ledgerStatus: ledgerStatusOf(posted, reread),
    // The ledger holds the entry as a DRAFT somebody there approves (Xero): the API's
    // own flag on the post's answer, never inferred from the ledger's name. Only read
    // when the ledger's state was not said; the head says it when it was.
    draft: !ledgerStatusOf(posted, reread) && Boolean(body.ledger && body.ledger.createsDraft === true),
    links: linksOf(body.links) || linksOf(body.entry && body.entry.links) || linksOf(reread.links),
    // The entry's page on a recording ledger (verify pass 3, Q04 / S-CF-12): the card's
    // own `ledgerPath`, which the engine sets only for a record kept in Vert.
    ledgerPath: [card.ledgerPath, reread.je && reread.je.ledgerPath].find((u) => typeof u === "string" && /^\/records\?/.test(u)) || null,
    // Where the post left its account (Q04): the card's sentence and the figures it binds.
    balance: balanceOf(card) || balanceOf(reread.je),
    // A reversal standing against this entry (D11): the engine's, on its card or its
    // re-read. The settle line's own `reversal` is read by the plate beside these.
    reversal: reversalOf(card.reversal, body.entry && body.entry.reversal, reread.reversal),
    // The files filed against it (D08), when a re-read of the stored entry carried them.
    documents: Array.isArray(reread.documents) ? reread.documents : undefined,
  };
}

/** The engine card's "X now stands at {{fig:balance}}." with its figures, or null. Pure. */
export function balanceOf(card) {
  const c = card && typeof card === "object" ? card : {};
  return typeof c.balanceNarration === "string" && c.balanceNarration.trim()
    ? { text: c.balanceNarration, figures: c.figures && typeof c.figures === "object" ? c.figures : {} }
    : null;
}

function linksOf(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * OPEN · VIEW ON QB ↗ · REVERSE (build plan §19.10 F-POL; §19.17 question 10)
 *
 * The posted plate's three ways on, in this order:
 *
 *   Open           the Vert conversation the entry was approved in — `/chat/<id>`,
 *                  the app's own route (app/chat/[id]), from the engine's
 *                  `links.sessionId`. The in-app path is preferred to `sessionUrl`
 *                  (the deployment's absolute address) because it resolves in every
 *                  deployment and never leaves the tab; `sessionUrl` is the fallback
 *                  only when no id was sent.
 *   View on QB ↗   the ledger's own page for the entry: `links.qboUrl` when the
 *                  ledger is QuickBooks — the engine's own statement that the link
 *                  is a QuickBooks page. Any other link (another ledger's
 *                  `ledgerUrl`, or a post's own answer `posted.entryUrl` that came
 *                  without `links`) reads "View in [the ledger's name] ↗", as it did.
 *   Reverse        drafts a reversing entry for a person to approve.
 *
 * "Remove from QuickBooks" is deliberately NOT here: deleting a posted entry erases
 * its trail, and a reversal keeps both sides on the record (§19.17 question 10).
 *
 * Every link is one the engine sent, never a guessed address: no id, no Open; no
 * ledger link, no View. Absent is drawn as absent, not as a dead button.
 * ══════════════════════════════════════════════════════════════════════════ */

const CHAT_ID = /^[A-Za-z0-9_-]{1,128}$/;

/** The held ledger link's reason, short: the engine's full sentence is in its payload. */
export const LEDGER_LINK_HELD = "No ledger link was sent for this entry. Search the ledger for the Vert id in its memo.";
const HTTPS = /^https:\/\/[^\s]+$/;
/** The plate's line when the post's answer said nothing about a ledger link. */
export const LEDGER_LINK_NOT_SENT = "No link to the entry came back with this post. Search the ledger for the Vert id in its memo.";

function quickbooks(platform, name) {
  return platform === "quickbooks" || (typeof name === "string" && /quickbooks/i.test(name));
}

/** The plate's links: `{ open: {href, external} | null, ledger: {href, label} | null }`. Pure. */
export function plateLinks(facts, { ledgerName = null } = {}) {
  const f = facts && typeof facts === "object" ? facts : {};
  const l = f.links || {};
  const sid = typeof l.sessionId === "string" && CHAT_ID.test(l.sessionId) ? l.sessionId : null;
  const sessionUrl = typeof l.sessionUrl === "string" && HTTPS.test(l.sessionUrl) ? l.sessionUrl : null;
  const open = sid ? { href: `/chat/${encodeURIComponent(sid)}`, external: false } : sessionUrl ? { href: sessionUrl, external: true } : null;
  const name = f.ledgerName || ledgerName || null;
  const platform = (typeof l.platform === "string" && l.platform) || f.ledgerPlatform || null;
  const qbo = typeof l.qboUrl === "string" && HTTPS.test(l.qboUrl) ? l.qboUrl : null;
  const other = [l.ledgerUrl, f.link].find((u) => typeof u === "string" && HTTPS.test(u)) || null;
  const ledgerLabel = `View in ${quickbooks(platform, name) ? "QuickBooks" : name || "your ledger"}`;
  // THE RECORDING LEDGER'S OWN PAGE (W14, ENG-JE p2). When the books are kept in Vert,
  // the engine sends the entry's in-app path (`ledgerPath`, kind "vert_record"), which
  // needs no host and never an https rule; it opens in this tab, named as Vert's page.
  // The card's own `ledgerPath` is that page too, with or without the evidence view's
  // `links` (Q04: a plate whose post answer carried no links drew no way to the entry).
  const vertPath =
    (l.ledgerUrlKind === "vert_record" ? [l.ledgerPath, f.ledgerPath, f.entryPath].find((u) => typeof u === "string" && /^\/records\?/.test(u)) : null) ||
    (typeof f.ledgerPath === "string" && /^\/records\?/.test(f.ledgerPath) ? f.ledgerPath : null);
  const ledger = qbo
    ? { href: qbo, label: "View in QuickBooks" }
    : vertPath
      ? { href: vertPath, label: "View the entry in Vert", internal: true }
      : other
        ? { href: other, label: ledgerLabel }
        : null;
  // ABSENT WITH ITS REASON (DA2-056; critic r1 F20). When the engine says why there is
  // no page in the ledger for this entry, the way there keeps its place, held, with a
  // short reason under it, so the plate always reads the same three ways on. With no
  // word from the engine at all, nothing is drawn: never a guessed address.
  // AND WITH NO WORD AT ALL, THE ABSENCE IS STILL SAID (verify pass 3, Q04): a posted
  // plate with no way to the entry and no sentence about it read as if the ledger had
  // nothing. The reason is the one thing known: no link came back with the post.
  // A `links` the engine did send, with nothing usable in it, is not "nothing came back":
  // that stays undrawn, as an address that is not https always has been.
  const held = ledger
    ? null
    : typeof l.ledgerUrlUnavailableReason === "string" && l.ledgerUrlUnavailableReason.trim()
      ? { label: ledgerLabel, reason: LEDGER_LINK_HELD }
      : !f.links && !f.link
        ? { label: ledgerLabel, reason: LEDGER_LINK_NOT_SENT }
        : null;
  return { open, ledger, ledgerHeld: held };
}

/** An entry's engine total, formatted, when the engine sent a balanced one. Pure. */
export function entryAmount(je) {
  const t = engineTotals(je);
  return t.balanced ? formatMoney(t.debitCents) : null;
}

/**
 * The plate's first line, before who and when: "Posted · Journal entry 2 · $200.00"
 * (eval final-a JE5). The number is the ledger's; with none the line says only what
 * is known, never a number nobody read.
 */
export function postedHead(number, amount, { status = null, ledgerName = null } = {}) {
  // What the ledger holds opens the line (p1/fix5): "Sent to Xero as a draft · approve
  // it in Xero to post · Journal entry 41", "Posted in Xero · …"; unsaid, "Posted · …".
  // A GUID is the ledger's internal id, not a number (staging browser walk 1, D17).
  const n = ledgerNumber(number);
  return [ledgerStatusLead(status, ledgerName), n ? `Journal entry ${n}` : null, amount || null].filter(Boolean).join(" · ");
}

/**
 * The plate's head, drawn the way the journal card's head is (spec §6.17 "the same head
 * with a Posted chip"): the Posted word as a done chip, the entry and its total as the
 * title, who and when as the meta line under it. The words are doneLine's, unchanged and
 * in the same order — the separators the layout replaces stay in the text for a screen
 * reader — so the line still reads "Posted · Journal entry 2 · $200.00 · Priya Nair".
 * A line that does not begin with the head (it never should) is drawn as it is.
 */
export function PostedHead({ line, head, status = null, ledgerName = null }) {
  const text = typeof line === "string" ? line : "";
  // The chip is the ledger's state in words (p1/fix5): a Xero draft in the attention
  // tone with no done tick, so it never reads as posted; the word is always there.
  const lead = ledgerStatusLead(status, ledgerName);
  const tone = ledgerStatusTone(status);
  if (!head || !text.startsWith(head) || !head.startsWith(lead)) {
    return <p className="dcard-done-text t-body" data-je-posted-head="">{text}</p>;
  }
  const title = head.slice(lead.length).replace(/^ · /, "");
  const rest = text.slice(head.length).replace(/^ · /, "");
  return (
    <p className="dcard-done-text jposted-line" data-je-posted-head="">
      <span className={tone === "done" ? "jcard-state jcard-posted" : "jcard-state jcard-ledger-draft"} data-tone={tone} data-ledger-status={status || undefined}>
        {tone === "done" ? <IconStatusDone size={12} aria-hidden="true" /> : null}
        {lead}
      </span>
      {title ? (
        <>
          <span className="sr-only"> · </span>
          <span className="jposted-title">{title}</span>
        </>
      ) : null}
      {rest ? (
        <>
          <span className="sr-only"> · </span>
          <span className="jposted-who t-footnote">{rest}</span>
        </>
      ) : null}
    </p>
  );
}

/** What "Reverse…" asks before it drafts anything (DA2-056). */
export const REVERSE_CONFIRM = "Draft a reversing entry? It waits for a person's approval; nothing posts now.";

export default function PostedPlate({ settled, amount = null, ledgerName = null, entryDate = null }) {
  const signedIn = useSignedInActor();
  const writesEnabled = useWritesEnabled();
  const facts = postedFacts(settled && settled.result, { date: entryDate });
  // The ledger's name as the API reported it (the post's `ledger`, else the page's).
  const ledgerShown = facts.ledgerName || ledgerName;
  const head = postedHead(facts.number, amount, { status: facts.ledgerStatus, ledgerName: ledgerShown });
  const heldId = useId();
  const [reverse, setReverse] = useState({ busy: false, failure: null, done: false, sessionId: null });
  // "Reverse…" asks first (DA2-056; critic r1 F20): the press opens a one-line
  // confirmation in place, and only its own button drafts the reversal.
  const [confirming, setConfirming] = useState(false);
  const rows = readBackRows(facts.readBack);
  // THE EVIDENCE AND THE BALANCE STAY ON THE POSTED ENTRY (D08, Q04). The post's own
  // answer (a plate drawn the moment it posted) carries neither the documents nor the
  // engine's balance-after sentence, so the stored entry is read once for them.
  const stored = useEntryReading(facts.entryId, Array.isArray(facts.documents) && Boolean(facts.balance));
  const documents = Array.isArray(facts.documents) ? facts.documents : stored && Array.isArray(stored.documents) ? stored.documents : null;
  const balance = facts.balance || balanceOf(stored && stored.je);
  // The stored entry's way to the ledger too, when the post's answer carried none (Q04).
  const storedJe = stored && stored.je && typeof stored.je === "object" ? stored.je : {};
  const links = plateLinks(
    {
      ...facts,
      ledgerPath: facts.ledgerPath || (typeof storedJe.ledgerPath === "string" && /^\/records\?/.test(storedJe.ledgerPath) ? storedJe.ledgerPath : null),
      link: facts.link || (typeof storedJe.ledgerLink === "string" ? storedJe.ledgerLink : null),
      links: facts.links || linksOf(stored && stored.links),
    },
    { ledgerName },
  );
  // ONE LABELLED WAY TO THE REVERSAL (S-E2E-7): "Open" beside "Open" read as two dead
  // ends. The conversation link is not drawn when it is the page you are on, nor while a
  // reversal stands (its own link, named, is the way on).
  const pathname = usePathname();
  // Whose approval a reversal waits on (D11): one drafted here was drafted by the viewer.
  const duties = useDuties();
  const whoseReversal = approvalWaitWords(duties, { drafter: reverse.done ? signedIn : null, actor: signedIn });
  // THE REVERSAL STANDING (D11). The engine's word for it first — the settle line's
  // `reversal`, laid on at read time, or the entry's — so a reload neither offers
  // Reverse again nor forgets where the reversing entry went; the press's own answer
  // stands in until the engine has said it.
  const standing =
    reversalOf(settled && settled.reversal, facts.reversal) ||
    (reverse.done ? { entryId: null, state: "draft", sessionId: reverse.sessionId } : null);

  async function pressReverse() {
    if (!facts.entryId || !writesEnabled) return;
    setReverse({ busy: true, failure: null, done: false, sessionId: null });
    const result = await callSafely(decideAndSettle, "reverseEntry", { entryId: facts.entryId }, { actionId: null });
    setReverse(result.ok ? { busy: false, failure: null, done: true, sessionId: reversedConversation(result) } : { busy: false, failure: result, done: false, sessionId: null });
    setConfirming(false);
  }

  // DESIGN PASS (spec §6.17 "posted card"; audit §6a P1). The plate is the journal
  // card's own paper, not a green wash: a Posted chip and the line that says what was
  // posted, by whom and when; the engine's narration under it; the read-back's verdict
  // as a done line with the check table one press down; and the three ways on as quiet
  // buttons. There is no commit here, so there is no accent in this view.
  return (
    <div className="dcard-done jposted" role="status" aria-live="polite" data-card-done="" data-card="post" data-je-state="posted">
      <div className="jposted-head">
        <PostedHead line={doneLine("post", settled, { what: head, signedIn })} head={head} status={facts.ledgerStatus} ledgerName={ledgerShown} />
      </div>
      {facts.narration ? (
        <p className="jcard-narration t-footnote" data-je-narration="">
          {facts.narration}
        </p>
      ) : null}
      {facts.draft ? (
        <p className="jcard-narration t-footnote" data-je-draft="">
          {draftPostedWords(facts.ledgerName || ledgerName)}
        </p>
      ) : null}
      {balance ? (
        <p className="jcard-narration jcard-balance t-footnote" data-je-after="">
          <BoundText text={balanceWords(balance.text)} figures={balance.figures} ledgerName={ledgerName} />
        </p>
      ) : null}
      <EntryDocuments documents={documents} />
      {rows.length ? (
        <div className="jcard-readback" data-je-readback="">
          <ReadBackTable readBack={facts.readBack} rows={rows} />
        </div>
      ) : null}
      {reverse.failure ? (
        <Notice kind="error" recorded={recordedFor(reverse.failure)} details={failureDetails(reverse.failure)} onRetry={writesEnabled ? pressReverse : undefined}>
          {failureSentence(reverse.failure)}
        </Notice>
      ) : null}
      {standing ? (
        <p className="dcard-done-note t-footnote" data-je-reversal={standing.state}>
          {reversalWords(standing, whoseReversal)}
          {reversalHref(standing) ? (
            <>
              {" "}
              <a className="jcard-reversal-link" href={reversalHref(standing)} data-je-action="open-reversal">
                Open the reversal
              </a>
            </>
          ) : null}
        </p>
      ) : null}
      {/* THE WAYS ON (DA2-056): "Reverse…" a quiet destructive at the left, asking first;
          Open quiet; the ledger's own page a secondary with its external glyph, last. */}
      {confirming && facts.entryId && !standing ? (
        <div className="dcard-done-actions jposted-confirm" role="group" aria-label="Reverse this entry" data-je-reverse-confirm="">
          <p className="jposted-confirm-text t-footnote">{REVERSE_CONFIRM}</p>
          <Button variant="quiet" size="sm" onClick={() => setConfirming(false)} disabled={reverse.busy || undefined} data-je-action="reverse-cancel">
            Cancel
          </Button>
          <Button variant="commit" size="sm" onClick={pressReverse} busy={reverse.busy} busyLabel="Drafting…" disabled={!writesEnabled || undefined} data-je-action="reverse-confirm">
            Draft the reversal
          </Button>
        </div>
      ) : (
        <div className="dcard-done-actions" data-je-posted-actions="">
          {facts.entryId && !standing ? (
            <Button variant="quiet" size="sm" destructive onClick={() => setConfirming(true)} disabled={!writesEnabled || undefined} data-je-action="reverse">
              Reverse…
            </Button>
          ) : null}
          {links.open && !standing && !(pathname && !links.open.external && links.open.href === pathname) ? (
            <a className="btn btn-quiet btn-sm jcard-open-link" href={links.open.href} data-je-action="open" {...(links.open.external ? { target: "_blank", rel: "noreferrer" } : {})}>
              Open
            </a>
          ) : null}
          {links.ledger ? (
            <a className="btn btn-secondary btn-sm jcard-ledger-link" href={links.ledger.href} {...(links.ledger.internal ? {} : { target: "_blank", rel: "noreferrer" })} data-je-action="view">
              <span>{links.ledger.label}</span>
              {links.ledger.internal ? null : <IconExternal size={14} aria-hidden="true" />}
            </a>
          ) : links.ledgerHeld ? (
            <Button variant="secondary" size="sm" className="jcard-ledger-link" disabled aria-describedby={heldId} trailingIcon={<IconExternal size={14} aria-hidden="true" />} data-je-action="view-held">
              {links.ledgerHeld.label}
            </Button>
          ) : null}
        </div>
      )}
      {/* The held link's reason, one quiet line under the row it explains (not beside the
          button, where it pushed the row onto two lines). */}
      {links.ledgerHeld && !links.ledger && !confirming ? (
        <p className="jposted-held-reason t-footnote" id={heldId}>
          {links.ledgerHeld.reason}
        </p>
      ) : null}
    </div>
  );
}


/* ══════════════════════════════════════════════════════════════════════════ *
 * A POSTED ENTRY, LATER (eval r2 JE5 / §9.3.F, 3 Oct)
 *
 * The plate above was drawn only in the moment after a post, from the post's own
 * answer. Anywhere else — a posted decision in the chat thread, the same decision
 * folded under "Earlier", the thread after a reload — the entry was one line,
 * "Posted $X · you · hh:mm", with no number and no Reverse: Reverse was unreachable.
 * This draws the same plate from what the API HOLDS about the entry: the entry id
 * from the card (a journal card's own `je:` id) or from the payout's recorded entries,
 * then `GET /journal/{id}` for the ledger's number and link. The read-back table is
 * the post's answer and is not stored with the entry, so a later plate draws none
 * rather than a table nobody re-read.
 * ══════════════════════════════════════════════════════════════════════════ */

const ENTRY_ID = /^[a-z]{1,16}:[0-9a-f]{6,64}$/;

/** The posted entry a settled decision is about: `{ entryId, number }`, or null. Pure. */
export function postedEntryOf(action, engine) {
  const a = action && typeof action === "object" ? action : {};
  const own = a.target && typeof a.target.id === "string" && ENTRY_ID.test(a.target.id) ? a.target.id : null;
  const payoutId = (a.prefill && a.prefill.payoutId) || (a.target && a.target.kind === "payout" ? a.target.id : null);
  const recorded = payoutId ? payoutStateFor(engine, payoutId) : null;
  const entries = recorded && Array.isArray(recorded.entries) ? recorded.entries : [];
  const posted = entries.filter((e) => e && typeof e.externalId === "string" && (e.status === "posted" || e.glExternalId));
  const match = (own && posted.find((e) => e.externalId === own)) || posted[posted.length - 1] || null;
  const entryId = own || (match && match.externalId) || null;
  if (!entryId) return null;
  const raw = match ? match.glExternalId : null;
  return { entryId, number: typeof raw === "string" && raw ? raw : Number.isInteger(raw) ? String(raw) : null };
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * THE CHECK TABLE SURVIVES A RELOAD (iteration 3 W0c; carry-over items 1 and 3)
 *
 * The read-back table used to live only in the post's own answer, so a reload drew
 * the plate without it and "every check passes" was something you had to have been
 * there to see. The engine now persists the read-back WITH the settle (build plan
 * §19.3 W0a): the `decision_settled` line carries `readBack` (the post's own shape:
 * `{verified, checks:[{check, expected, actual, result}]}`) and `posted`
 * (`{glExternalId, entryExternalId, entryUrl}`). This reads them, in this order:
 *
 *   1. the settle's persisted read-back — what was read back AT the post;
 *   2. the stored entry's card read-back, from `GET /journal/{id}`;
 *   3. none — and then no table, never one nobody read.
 *
 * The persisted one wins over a later re-read's card because it is the record of the
 * check that was made when the person pressed Post; the number and link prefer the
 * live re-read (a ledger can renumber), then the persisted ones.
 * ══════════════════════════════════════════════════════════════════════════ */

function isCheckTable(readBack) {
  return Boolean(readBack && typeof readBack === "object" && Array.isArray(readBack.checks) && readBack.checks.length);
}

/** What a settle persisted about its post: `{ posted, readBack }`, each or null. Pure. */
export function persistedPost(settled) {
  const s = settled && typeof settled === "object" ? settled : {};
  const posted = s.posted && typeof s.posted === "object" ? s.posted : null;
  return { posted, readBack: isCheckTable(s.readBack) ? s.readBack : null };
}

/** `settled` as PostedPlate reads it, built from what the API holds. Pure. */
export function laterSettled(settled, found, reread) {
  const r = reread && reread.ok ? reread : {};
  const kept = persistedPost(settled);
  const p = kept.posted || {};
  const cardReadBack = r.je && isCheckTable(r.je.readBack) ? r.je.readBack : null;
  const readBack = kept.readBack || cardReadBack;
  return {
    ...(settled || {}),
    result: {
      ok: true,
      body: {
        posted: {
          glExternalId: r.glExternalId || found.number || p.glExternalId || null,
          entryUrl: r.entryUrl || (typeof p.entryUrl === "string" && p.entryUrl) || null,
          entryExternalId: found.entryId,
          // What the ledger holds (p1/fix5): the live re-read, then the settle's record.
          ledgerStatus: ledgerStatusOf(r, p),
        },
        // The engine's card for the stored entry (its posted narration), from the
        // same re-read; the check table as above.
        ...(r.je ? { je: r.je } : {}),
        ...(readBack ? { readBack } : {}),
        ...(r.links ? { links: r.links } : {}),
      },
      reread: r.ok ? r : null,
    },
  };
}

// `entryId` (and `number`, `entryDate`), for a surface with no action to hand — the
// Records › Journal entries row detail mounts the plate from the row it lists.
export function PostedEntryPlate({ action = null, settled = null, amount = null, ledgerName = null, fallback = null, entryId: givenId = null, number = null, entryDate = null }) {
  const engine = useEngine();
  const writesEnabled = useWritesEnabled();
  // What the post itself answered, when it was made in this tab: the full plate,
  // read-back table included, not the thinner one rebuilt from the record.
  const held = usePostedFor(action && action.actionId);
  // The entry the settle persisted is as good as one handed in: after a reload it is
  // the only place a GL-rec or manual post's entry id survives on the thread.
  const kept = persistedPost(settled).posted;
  const keptId = kept && typeof kept.entryExternalId === "string" && ENTRY_ID.test(kept.entryExternalId) ? kept.entryExternalId : null;
  const keptNumber = kept ? kept.glExternalId : null;
  const givenEntry = typeof givenId === "string" && ENTRY_ID.test(givenId) ? givenId : null;
  const given = givenEntry
    ? { entryId: givenEntry, number: number == null ? null : String(number) }
    : keptId && !postedEntryOf(action, engine)
      ? { entryId: keptId, number: keptNumber == null ? null : String(keptNumber) }
      : null;
  const found = held ? null : given || postedEntryOf(action, engine);
  const [reread, setReread] = useState(null);
  const entryId = found ? found.entryId : null;
  useEffect(() => {
    if (!entryId || !writesEnabled) return undefined;
    let live = true;
    // A GET (staging D4 retest), never the readPostedEntry Server Action on mount.
    readPostedByGet(entryId).then((answer) => {
      if (live) setReread(answer && answer.ok ? answer : null);
    });
    return () => {
      live = false;
    };
  }, [entryId, writesEnabled]);
  const je = (held && held.je) || (action && action.je && typeof action.je === "object" ? action.je : null) || (entryDate ? { date: entryDate } : null);
  // The entry's own engine total when the card carried no figure (eval final-a JE5: a
  // hand-written draft's plate read "Posted · you", with no amount); else the API's
  // re-read of the stored entry. Read, never summed here.
  const shownAmount = amount || entryAmount(je) || (reread && Number.isInteger(reread.sumDr) && reread.sumDr > 0 ? formatMoney(reread.sumDr) : null);
  if (held) return <PostedPlate settled={{ ...(settled || {}), ...held.settled }} amount={shownAmount} ledgerName={ledgerName} entryDate={je && je.date} />;
  if (!found) return fallback;
  return <PostedPlate settled={laterSettled(settled, found, reread)} amount={shownAmount} ledgerName={ledgerName} entryDate={je && je.date} />;
}
