"use client";

// components/cards/journal-edits.js — A SAVED EDIT, HANDED FROM THE PANE TO ITS CARD
// ==============================================================================
// The journal card lives in the thread (or on Month-end); its editor opens in the result
// pane (FP's slot, `EditorFor`), a different branch of the tree. When Save lands, the
// engine has a NEW entry (an edit supersedes, §4.0.4) and the card must show the new
// lines and approve the NEW id — otherwise the approval would sign the hash of an entry
// that has just been discarded as "edited", and the engine would refuse it.
//
// So the editor publishes `{ entryId, je }` under the card's actionId here, and the card
// reads it. Kept in memory for the page's life only: the durable record is the engine's
// (the superseding entry and its `supersedes` link), and a reload re-reads it from there.

import { useSyncExternalStore } from "react";

const edits = new Map();
// The same saves by the entry they replaced (and by the entry they made), so a card the
// engine proposes AGAIN for an entry this tab has already edited shows the saved
// revision and approves its id (eval r1 #13: "card after save targets
// je:fca149400d9f" — the new card named the superseded entry, and its Approve would
// have signed the lines the person had just changed).
const byEntry = new Map();
const listeners = new Set();
let version = 0;

function emit() {
  version += 1;
  for (const fn of listeners) fn();
}

/** Record the entry a Save produced for the card `actionId`. */
export function publishEdit(actionId, saved, replaced = null) {
  if (!saved) return;
  if (typeof actionId === "string" && actionId) edits.set(actionId, saved);
  const from = typeof replaced === "string" && replaced ? replaced : saved.je && typeof saved.je.supersedes === "string" ? saved.je.supersedes : null;
  if (from) byEntry.set(from, saved);
  // A save of a save: whatever pointed at the entry just replaced now points here.
  for (const [k, v] of byEntry) if (v && v.entryId === from) byEntry.set(k, saved);
  if (typeof saved.entryId === "string" && saved.entryId) byEntry.set(saved.entryId, saved);
  emit();
}

/** The latest saved revision of entry `entryId` in this tab, or null. */
export function editForEntry(entryId) {
  return (typeof entryId === "string" && byEntry.get(entryId)) || null;
}

/** Forget an edit (tests; a card that was settled). */
export function clearEdit(actionId) {
  const had = edits.get(actionId);
  if (!edits.delete(actionId)) return;
  if (had) for (const [k, v] of byEntry) if (v === had) byEntry.delete(k);
  emit();
}

function subscribe(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

/** The latest saved edit for `actionId`, or null. */
export function editFor(actionId) {
  return (typeof actionId === "string" && edits.get(actionId)) || null;
}

export function useSavedEdit(actionId, entryId = null) {
  const read = () => editFor(actionId) || editForEntry(entryId);
  return useSyncExternalStore(subscribe, read, read);
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * A POST, HELD FOR THE LINE THAT REPLACES THE CARD (eval r2 JE5, 3 Oct)
 *
 * In the thread a card is replaced by its settled line the moment the API's
 * `decision_settled` arrives — within 400 ms of the post — and the post's answer (the
 * ledger's number, its link, the engine's read-back table) went with the card: the
 * line said "Posted $200.00 · you" and nothing else. The card publishes the post's
 * settlement here, keyed on its action, and the posted plate that replaces it reads it
 * back, so the plate shown after the swap is the plate the post produced.
 * ══════════════════════════════════════════════════════════════════════════ */

const posts = new Map();

/** Record what a post answered for the card `actionId`: `{ settled, je? }`. */
export function publishPosted(actionId, posted) {
  if (typeof actionId !== "string" || !actionId || !posted || !posted.settled) return;
  posts.set(actionId, posted);
  emit();
}

/** The post recorded for `actionId` in this tab, or null. */
export function postedFor(actionId) {
  return (typeof actionId === "string" && posts.get(actionId)) || null;
}

export function usePostedFor(actionId) {
  return useSyncExternalStore(
    subscribe,
    () => postedFor(actionId),
    () => postedFor(actionId)
  );
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * A SAVED EDIT KEEPS ITS CARD OPEN (eval final-a C6, 6 Oct)
 *
 * Save drafts the card's entry, then supersedes it with the edited one. The API,
 * reading the card's target back, finds the entry drafted and settles the card
 * "applied"; the thread then folded it into "Decided · you" behind "Earlier", over an
 * edited entry still waiting for approval. A journal decision whose edit was saved in
 * this tab, and whose settlement is not an approval, post or rejection, is drawn OPEN.
 * ══════════════════════════════════════════════════════════════════════════ */

const JOURNAL = new Set(["journal_approve", "journal_draft", "journal_reject"]);
const DECIDED = new Set(["approved", "approve", "posted", "post", "rejected", "reject", "declined", "withdrawn"]);

/** Whether a settled journal decision was settled only by a saved edit. Pure. */
export function settledBySave(action, settled, saved) {
  if (!saved || !settled || typeof settled !== "object") return false;
  const kind = action && action.kind;
  return JOURNAL.has(kind) && !DECIDED.has(settled.outcome);
}

/** Thread items with every decision settled only by a saved edit drawn open again. */
export function reopenSaved(items, lookup = editFor) {
  if (!Array.isArray(items)) return items;
  let changed = false;
  const out = items.map((item, n) => {
    if (!item || item.kind !== "decision" || !item.settled) return item;
    const id = item.action && item.action.actionId;
    const saved = lookup(id);
    if (!settledBySave(item.action, item.settled, saved)) return item;
    // The engine has since proposed the edited entry on a card of its own: that card is
    // the one to approve, and reopening this one too would draw the entry twice.
    if (proposedLater(items, n, item, saved)) return item;
    changed = true;
    return { ...item, settled: null, settledBySave: item.settled };
  });
  return changed ? out : items;
}

/** Re-render on any saved edit (the thread folds on them). */
export function useEditsVersion() {
  return useSyncExternalStore(
    subscribe,
    () => version,
    () => version
  );
}

// Whether a decision after `items[n]` names the entry it was about, or the entry its
// save produced.
function proposedLater(items, n, item, saved) {
  const ids = new Set([item.action && item.action.target && item.action.target.id, saved && saved.entryId].filter(Boolean));
  for (let i = n + 1; i < items.length; i += 1) {
    const later = items[i];
    if (!later || later.kind !== "decision" || !later.action || later.settled) continue;
    const t = later.action.target && later.action.target.id;
    if (t && ids.has(t) && JOURNAL.has(later.action.kind)) return true;
  }
  return false;
}
