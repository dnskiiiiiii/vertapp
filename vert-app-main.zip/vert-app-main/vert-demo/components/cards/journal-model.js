// components/cards/journal-model.js — THE JOURNAL CARD AND ITS EDITOR, AS PURE FUNCTIONS
// ==============================================================================
// Build plan §4.5 FJ, §4.0.4 and §4.0.5; teardown standards 10–11.
//
// WHY THE RULES LIVE HERE AND NOT IN THE COMPONENTS. The test harness renders markup
// with no browser (tests/_harness/render.js): nothing can be pressed and no state can
// change. So every rule a press depends on — which commit a card offers, what the
// second press does, whether an edited entry balances, what Save sends — is a pure
// function in this file, and the components hold nothing but the state these functions
// are handed. A test can then walk a card from Draft to Posted press by press, and
// count the presses, without a DOM.
//
// THE MONEY RULE, AND ITS ONE EXCEPTION. Every figure on the card is an engine
// integer in cents (`je.lines[].debitCents`, `je.totals`), formatted by lib/format.js;
// the card never adds a column. The EDITOR is the exception, because what it totals
// does not exist anywhere else yet: the person's own unsaved lines, typed a moment ago.
// No engine has authored a total for an entry nobody has saved, and "Save" is refused
// by the engine (422) if the lines do not balance, so the editor's totals are a
// preview of the engine's check, never a figure recorded anywhere. `editorTotals` is
// that one site, and it adds integers only (cents parsed from what was typed, through
// components/ui/fields.js parseDollars).
//
// NO ID REACHES THE CARD'S FACE. The entry's content id, an account's ledger id and an
// evidence record's id are drawn only under Details (spec §1.6); the face reads the
// account's number and name, the memo, the date and the period.

import { actorWords, formatDate, formatMoney, formatTime, journalNumberOf, ledgerNumber, metaLine } from "@/lib/format";
import { periodLabel } from "@/lib/period";
import { hasRawId, payoutLineWords, payoutOfTitle, withoutRawIds } from "@/lib/raw-ids";
import { canPost, holdsAsDraft } from "@/lib/ledger-shape";
import { unpostedLedgerNote } from "./ledger-note";
import { approveActionLabel, ledgerStatusOf, ledgerStatusTerm, postActionLabel, splitLedgerName } from "./words";
import { drafterOf } from "@/lib/roles";

/** The three states an entry is in, and the status colour each is drawn in (never
 *  the accent: purple means "this writes", §4.0.9). */
export const STATE_WORDS = Object.freeze({
  draft: { word: "Draft", tone: "attention" },
  approved: { word: "Approved", tone: "working" },
  posted: { word: "Posted", tone: "done" },
});

/** How many lines a card shows before "Show N more" (design-fix-2 DA2-016: an approver
 *  reads every line of a short entry; nothing financial ever fades). */
export const VISIBLE_LINES = 8;

export function stateWord(state) {
  return (STATE_WORDS[state] || STATE_WORDS.draft).word;
}

/**
 * "31 Jul 2026 · July 2026" — the card's meta line (design pass, spec §6.17: one dot).
 * The state word (Draft, Posted) is the status chip beside the title, so the line no
 * longer repeats it; a reversing entry still says so, because no chip carries that.
 */
export function cardLabel(je) {
  return cardMeta(je).join("  ");
}

/**
 * The meta line's parts, laid out with a gap and no middle dots (design-fix-2 DA2-033):
 * ["30 Sep 2026", "September 2026 period", "JE 1"].
 */

export function cardMeta(je, { period: alwaysPeriod = false } = {}) {
  const parts = je && je.reverses ? [reversesText(je) || "Reversing entry"] : [];
  const date = safe(() => formatDate(je.date));
  if (date) parts.push(date);
  // THE PERIOD IS ON THE FACE TOO (verify pass 1, Q02; the rubric's JE1: date, period,
  // entry number): the month the entry closes into, which a dated entry did not say.
  // Said when the date doesn't already say it ("1 Aug 2026" in July's close), so the face
  // carries no second idea for the same month.
  // Verify pass 2 (Q02): in a conversation the period is ALWAYS said — date, period,
  // entry number, as the rubric's JE1 reads them; "31 Jul 2026" alone left the reviewer
  // to infer the close. On Month-end (`period: false`) the page already names the month,
  // and the W0d five-idea limit holds: there it is said only when the date's month is not
  // the period's.
  const period = safe(() => periodLabel(je.period));
  const inside = typeof je.date === "string" && typeof je.period === "string" && je.date.slice(0, 7) === je.period.slice(0, 7);
  if (period && (alwaysPeriod || !date || !inside)) parts.push(date ? `${period} period` : period);
  const tag = entryTag(je);
  if (tag) parts.push(tag);
  // THE ENTRY NUMBER, AS THE REFERENCE WRITES A DRAFT'S (verify pass 8, Q02 F-11):
  // "No. automatic", on every card, where "JE n" stood; a numbered entry's "No. 1042" is
  // the card's own jcard-number.
  if (isUnnumbered(je)) parts.push(UNNUMBERED_FACE);
  return parts;
}

/**
 * A DRAFT'S ENTRY NUMBER ON THE FACE (verify pass 8, Q02 F-11; iter2 §b "No. Automatic").
 * No ledger has numbered a draft; the field is still drawn, and says the ledger numbers
 * it. Details says the same in a sentence ("Assigned when it's posted").
 */
export const UNNUMBERED_FACE = "No. automatic";

function isUnnumbered(je) {
  return Boolean(je) && je.state !== "posted" && !(typeof je.number === "string" && je.number.trim());
}

/**
 * EVERY COMPACT CARD'S HEAD (verify pass 8, Q02 F-12): "Draft · 3 Jul 2026, July 2026
 * period, No. automatic" — the status, the date, the period and the entry number, the
 * rubric's JE1 fields, so the approve-entries cards, its pane and the payout card say what
 * the full card says. The period is the entry's own, else the month its date falls in.
 * `date` overrides the entry's (a payout card's arrival). Pure.
 */
export function entryHeadLine(status, je, { date = null } = {}) {
  const day = date || (je && je.date) || null;
  // ONE MIDDLE DOT (DA2-033): the status, then the entry's facts as one comma list.
  const dayText = statusDateLine(status, day).split(" · ").slice(1).join("");
  const parts = dayText ? [dayText] : [];
  const own = je && typeof je.period === "string" && /^\d{4}-\d{2}$/.test(je.period) ? je.period : null;
  const month = own || (typeof day === "string" && /^\d{4}-\d{2}/.test(day) ? day.slice(0, 7) : null);
  const period = month ? safe(() => periodLabel(month)) : null;
  if (period) parts.push(`${period} period`);
  // A ledger number that is the ledger's own id ("No. 5525b44e-…", walk 5) is no number.
  const number = je && typeof je.number === "string" && je.number.trim() && !hasRawId(je.number) ? je.number.trim() : null;
  if (number) parts.push(`No. ${number}`);
  else if (status !== "posted") parts.push(UNNUMBERED_FACE);
  return metaLine([statusWordFor(status, je), parts.join(", ")]);
}

const STATUS_WORDS = Object.freeze({ draft: "Draft", approved: "Approved", posted: "Posted" });

/**
 * A card's status word: "Draft", "Approved", and for a posted entry what its LEDGER
 * holds, from the card's own payload ("Sent to Xero as a draft", "Posted in Xero"), as
 * Records and the posted plate say it (p1/fix8, staging D4 retest: entry 41 read
 * "Posted" in the conversation though Xero holds only a draft). With no ledger state
 * sent (an older engine), "Posted" as before. Pure.
 */
export function statusWordFor(status, je = null) {
  if (status === "posted") {
    const held = ledgerStatusOf(je);
    if (held) return ledgerStatusTerm(held, je && je.ledgerName);
  }
  return STATUS_WORDS[status] || "Draft";
}

/**
 * "Draft · 31 Jul 2026": an entry's status and its date, the reference's first line on
 * every entry card (verify pass 5, Q-SHAPE-4: the payout cards drew none). Shared by the
 * answer shape's cards and the payout card, so the two can never word it apart. Pure.
 */
export function statusDateLine(status, date, je = null) {
  const word = statusWordFor(status, je);
  let day = null;
  try {
    day = typeof date === "string" && /^\d{4}-\d{2}-\d{2}/.test(date) ? formatDate(date.slice(0, 10)) : null;
  } catch {
    day = null;
  }
  return day ? `${word} · ${day}` : word;
}

/**
 * THE ENTRY'S NUMBER BEFORE THE LEDGER GIVES ONE (Q02, the rubric's JE1; the reference's
 * "Draft · 04/30/2026 · No. Automatic"): "JE 1", the entry's place among the entries
 * this run drafted (the pager's index), which the workbook's "JE n" tab names too. A
 * posted entry carries the ledger's number instead (`entryNumberText`), so none here.
 * It says nothing about posting, which W0d kept off the face. Pure.
 */
export function entryTag(je) {
  if (!je || je.state === "posted" || (typeof je.number === "string" && je.number.trim())) return null;
  // AN ENTRY NAMED FOR ITS KIND (the founder's 19 Oct 2026 decision, fixed assets): its
  // workbook tab is "Reclassification JE", never "JE 1", so the tag names that tab.
  const name = pagerName(je);
  if (name) return `${name} JE`;
  // A REVERSAL IS ITS WORKBOOK'S "Reversal" TAB (verify pass 6, Q-SHAPE-4 F17). Its
  // workbook holds "JE 2" (the posted entry it reverses) and "Reversal" (its own lines),
  // so "JE 1" on its card named no tab and read as the wrong entry.
  if (je.reverses) return "Reversal";
  // NO BARE "JE n" (verify pass 8, Q02 F-11): the pager's index read as an entry number
  // and is not one ("JE 1" on every card, with Details saying the number comes on
  // posting). The card's place among its run's entries is the pager ("1 of 2"); its
  // number is "No. automatic" (cardMeta).
  return null;
}

/** The entry's kind as the engine named it ("Reclassification"), or null. Pure. */
export function pagerName(je) {
  const name = je && je.pager && typeof je.pager.name === "string" ? je.pager.name.trim() : "";
  return name || null;
}

/* ── A REVERSAL STANDING AGAINST A POSTED ENTRY (D11; ENG-JE-e1, e2) ─────────────
 * The engine lays `reversal: {entryId, state, sessionId}` on a posted entry's card
 * (`je.reversal`), on `GET /journal/{id}` (`entry.reversal`) and on the settle line
 * read back (`decision_settled.reversal`). While it stands the plate offers no second
 * Reverse; it says where the reversal is, and Open goes to its conversation. Read from
 * the engine, so a reload says the same thing the press did. */

const REVERSAL_STATES = new Set(["draft", "approved", "posted"]);
const CHAT_SESSION = /^[A-Za-z0-9_-]{1,128}$/;

/** The first well-formed reversal among `candidates`, normalised, or null. Pure. */
export function reversalOf(...candidates) {
  for (const c of candidates) {
    if (!c || typeof c !== "object") continue;
    const state = REVERSAL_STATES.has(c.state) ? c.state : null;
    const entryId = typeof c.entryId === "string" && c.entryId ? c.entryId : null;
    if (!state && !entryId) continue;
    const sessionId = typeof c.sessionId === "string" && CHAT_SESSION.test(c.sessionId) ? c.sessionId : null;
    return { entryId, state: state || "draft", sessionId };
  }
  return null;
}

export const REVERSAL_WORDS = Object.freeze({
  draft: "A reversing entry was drafted. It's waiting for your approval.",
  approved: "A reversing entry was approved. It isn't posted yet.",
  posted: "This entry was reversed. The reversing entry is posted.",
});

/** What the plate says of a standing reversal, worded for whose approval it waits on (D11). Pure. */
export function reversalWords(reversal, whose = "your approval") {
  if (!reversal) return null;
  const words = REVERSAL_WORDS[reversal.state] || REVERSAL_WORDS.draft;
  return reversal.state === "draft" || !REVERSAL_WORDS[reversal.state] ? words.replace("your approval", whose) : words;
}

/** Where Open goes for a reversal: its conversation, or null. Pure. */
export function reversalHref(reversal) {
  return reversal && reversal.sessionId ? `/chat/${encodeURIComponent(reversal.sessionId)}` : null;
}

/** The conversation a Reverse press opened (`POST /journal/{id}/reverse`), or null. Pure. */
export function reversedConversation(result) {
  const b = result && result.body && typeof result.body === "object" ? result.body : {};
  if (typeof b.conversationId === "string" && CHAT_SESSION.test(b.conversationId)) return b.conversationId;
  const url = typeof b.conversationUrl === "string" ? b.conversationUrl : "";
  const m = /\/chat\/([A-Za-z0-9_-]{1,128})(?:[?#]|$)/.exec(url);
  return m ? m[1] : null;
}

const LEDGER_GUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * "Reverses journal 1042", or "Reverses Vert entry 41" (the engine's `reversesWords`)
 * when the ledger gave the original only a GUID: never "Reverses journal 7b78c37e-…"
 * (staging D4 retest, c-23). Pure.
 */
export function reversesText(je) {
  const words = je && typeof je.reversesWords === "string" ? je.reversesWords.trim() : "";
  // The original only a draft in its ledger is said so (p1/fix8): it isn't in the books.
  const held = je && je.reversesLedgerStatus === "draft" ? ` (a draft in ${splitLedgerName(je.reversesLedgerName).name || "the ledger"}, not posted there)` : "";
  if (words) return `Reverses ${words}${held}`;
  const n = je && (typeof je.reversesNumber === "string" ? je.reversesNumber.trim() : Number.isInteger(je.reversesNumber) ? String(je.reversesNumber) : "");
  return n && !LEDGER_GUID.test(n) ? `Reverses journal ${n}` : null;
}

/**
 * THE UNSAVED REVERSAL'S CONTROLS (staging D4 retest, c-23), or null for any other card.
 * A `reverse` card is the mirror of a posted entry that is NOT SAVED yet: its target is
 * the original, so the draft controls offered approving the original, and the read laid
 * the original's "already in the books" on it. Its one commit is Save reversal — the
 * journal road's reverse, which stores the draft linked to the original in the entry's
 * conversation — and nothing else until it is saved. Pure.
 */
export function reverseCardControls(action) {
  if (!action || action.kind !== "reverse") return null;
  const label = typeof action.commitLabel === "string" && action.commitLabel.trim() ? action.commitLabel.trim() : "Save reversal";
  return { commit: { label, press: "save_reversal", then: null }, secondary: [], link: null, note: null };
}

/** "No. 1042", or "No. assigned on posting" while the ledger has not numbered it. */
export function entryNumberText(je) {
  const n = je && typeof je.number === "string" && je.number.trim() ? je.number.trim() : null;
  return n ? `No. ${n}` : "No. assigned on posting";
}

/** "6100 Rent" (design-fix-2 §3.4: the code, a space, the name), or the name alone. */
export function accountText(account) {
  if (!account || typeof account !== "object") return "An account Vert couldn't name";
  const name = typeof account.name === "string" && account.name.trim() ? account.name.trim() : null;
  const number = typeof account.number === "string" && account.number.trim() ? account.number.trim() : null;
  if (number && name) return `${number} ${name}`;
  return name || number || "An account Vert couldn't name";
}

/** A Debit or Credit cell: the engine's cents, or blank for the side a line doesn't use. */
export function sideText(cents) {
  return typeof cents === "number" && Number.isInteger(cents) && cents > 0 ? formatMoney(cents) : "";
}

/** Whether the Class and Location columns are drawn: only when some line carries one
 *  (§4.11a.5: tracking columns appear only when the company uses them). */
export function trackingColumns(lines) {
  const list = Array.isArray(lines) ? lines : [];
  return {
    classRef: list.some((l) => l && typeof l.classRef === "string" && l.classRef.trim()),
    locationRef: list.some((l) => l && typeof l.locationRef === "string" && l.locationRef.trim()),
  };
}

/* ══════════════════════════════════════════════════════════════════════════════ *
 * THE TAX RATE COLUMN (w45, audit row 15). On a ledger that takes tax codes (Xero) the
 * engine puts each line's rate on `line.tax` (vert_engine/journals/tax_plan.py): the
 * rate the post sends, so what is approved is what is sent. No line carries one on any
 * other ledger, nor on a payout's entry, and then no column is drawn.
 * ══════════════════════════════════════════════════════════════════════════════ */

/** Whether any line carries a tax rate: the column is drawn only then. Pure. */
export function taxColumn(lines) {
  return (Array.isArray(lines) ? lines : []).some((l) => Boolean(taxCell(l)));
}

/**
 * One line's tax cell: the rate it goes out on (`text`), and a quieter word under it
 * (`hint`) when that isn't the account's own rate — "Normally GST on Expenses" — or the
 * account's rate wasn't read from the ledger, which is said, never assumed. `null` for
 * a line with no rate. Pure.
 */
export function taxCell(line) {
  const tax = line && typeof line === "object" ? line.tax : null;
  if (!tax || typeof tax !== "object" || typeof tax.words !== "string" || !tax.words.trim()) return null;
  const text = tax.words.trim();
  const own = typeof tax.ownRate === "string" ? tax.ownRate.trim() : "";
  let hint = null;
  if (tax.ownRateRead === false) hint = "Rate not read";
  else if (own && own !== text && tax.code) hint = `Normally ${own}`;
  return { text, hint, asked: !tax.code && text === TAX_ASKED };
}

/** The engine's words for a line whose rate Vert asks about (tax_plan.ASKED_WORDS). */
export const TAX_ASKED = "Vert asks";

/** The sentence under the lines about their rates, and whether it is a question Vert
 *  asks (nothing posts until it is answered). `null` when the engine said none. Pure. */
export function taxNote(je) {
  const tax = je && typeof je === "object" ? je.tax : null;
  if (!tax || typeof tax !== "object" || typeof tax.note !== "string" || !tax.note.trim()) return null;
  return { text: tax.note.trim(), asked: tax.asked === true };
}

/**
 * The entry's lines as the card words them (staging browser walk 6, W6-3): a line the
 * engine described by a payout entry's raw memo ("Payout po_… — decomposed journal
 * entry") says its own words (`name`), else the payout the card's memo names ("Entry for
 * Stripe payout · 27 Oct"), and no description carries a raw id. Amounts and accounts
 * are untouched. Pure.
 */
export function journalLineWords(je) {
  const lines = je && Array.isArray(je.lines) ? je.lines : [];
  const label = payoutOfTitle(je && je.memo);
  return lines.map((l) => (l && typeof l === "object" && typeof l.description === "string" ? { ...l, description: withoutRawIds(payoutLineWords(l.description, { name: l.name, label })) } : l));
}

/**
 * The lines the card shows, and the "Show all 7 lines" control's words. A card with
 * more than VISIBLE_LINES lines shows the first three, fading, until opened.
 */
export function visibleLines(lines, expanded = false) {
  const list = Array.isArray(lines) ? lines : [];
  if (expanded || list.length <= VISIBLE_LINES) return { shown: list, more: null, fades: false };
  return { shown: list.slice(0, VISIBLE_LINES), more: `Show ${list.length - VISIBLE_LINES} more`, fades: false };
}

/** The engine's totals, and whether they balance — read, never summed (the engine's
 *  JournalEntry model refuses totals that are not the sum of the lines). */
export function engineTotals(je) {
  const t = je && je.totals;
  const debit = t && Number.isInteger(t.debitCents) ? t.debitCents : null;
  const credit = t && Number.isInteger(t.creditCents) ? t.creditCents : null;
  return { debitCents: debit, creditCents: credit, balanced: debit !== null && debit === credit && debit > 0 };
}

/** "6 Jul" pager words: "1 of 2", or null for a run that drafted one entry. */
export function pagerText(je) {
  const p = je && je.pager;
  const name = pagerName(je);
  // "1 of 2 · Reclassification": the place in the run and, when the engine names the
  // entry by its kind, that name, as the answer's delivered list says it.
  if (!p || !Number.isInteger(p.of) || p.of <= 1 || !Number.isInteger(p.index)) return name;
  return `${p.index}\u00a0of\u00a0${p.of}` + (name ? ` \u00b7 ${name}` : "");
}

/* ══════════════════════════════════════════════════════════════════════════════ *
 * THE COMMIT (§4.0.5): one purple control per card, and what each press does.
 * ══════════════════════════════════════════════════════════════════════════════ */

export const UNBALANCED_REASON = "Debits and credits don't balance yet, so this can't be approved.";
/** The editor's form of it: Save is what stands between the edit and an approval. */
export const EDITOR_UNBALANCED_REASON = "Debits and credits don't balance yet, so this can't be saved or approved.";

/**
 * Why this entry can't be approved, or null when it can. The engine never puts an
 * unbalanced entry in front of a person, so on a card this is the defensive half; in
 * the editor it is the live one (`editorGate`).
 */
export function approveGate(je) {
  const t = engineTotals(je);
  if (!t.balanced) return UNBALANCED_REASON;
  return null;
}

/**
 * Legs on accounts the client's chart doesn't hold (D02; recs-jes finding 7): the
 * engine's own note, for a commit drawn dead before any press, or null. Pure.
 */
export function unmappedGate(je) {
  if (!je || !Array.isArray(je.unmapped) || !je.unmapped.length) return null;
  return typeof je.unmappedNote === "string" && je.unmappedNote.trim() ? je.unmappedNote.trim() : UNMAPPED_REASON;
}

export const UNMAPPED_REASON = "Some lines use accounts that aren't on the client's chart, so this can't be approved yet.";

/**
 * The card's controls for an entry in `state`, given the ledger descriptor:
 *
 *   draft, ledger      commit "Approve and post to {ledger}…", or "Approve and send to
 *                      {ledger} as draft…" (opens the post sheet); quiet
 *                      "Approve only", "Edit", "Reject"
 *   draft, no ledger   commit "Approve"; quiet "Edit", "Reject"
 *   approved, ledger   commit "Post to {ledger}…", or "Send to {ledger} as draft…" when
 *                      the ledger holds a draft (opens the post sheet); quiet "Undo"
 *   approved, none     no commit; quiet "Undo"; "Ready to post when your ledger is connected."
 *   posted             no commit; "View in {ledger} ↗" (a link) and quiet "Reverse"
 *
 * `press` names what the commit does, so the walk in tests/posting.test.js can follow
 * it: "open_post" opens the sheet, "approve" writes at once.
 */
export function cardControls(state, ledger, { ledgerName = null, editable = true } = {}) {
  const name = ledgerDisplayName(ledger, ledgerName);
  const postable = canPost(ledger) && Boolean(name);
  // SENT, NOT POSTED, on a ledger that holds a draft (createsDraft; per client on Xero
  // since 17 Oct 2026): "Send to Xero as draft…", "Approve and send…". Worded by
  // words.js `postActionLabel`; never on a recording ledger, which receives nothing.
  const sends = holdsAsDraft(ledger) && !splitLedgerName(name).recording;
  if (state === "posted") {
    return { commit: null, secondary: ["reverse"], link: name ? `View in ${shortLedger(name)}` : "View in your ledger", note: null };
  }
  if (state === "approved") {
    return postable
      ? { commit: { label: `${postActionLabel(name, { draft: sends })}…`, press: "open_post", then: "post" }, secondary: ["undo"], link: null, note: null }
      : { commit: null, secondary: ["undo"], link: null, note: unpostedLedgerNote(ledger) };
  }
  const secondary = postable ? ["approve_only"] : [];
  if (editable) secondary.push("edit");
  secondary.push("reject");
  return postable
    ? { commit: { label: `${approveActionLabel(name, { draft: sends })}…`, press: "open_post", then: "approve_and_post" }, secondary, link: null, note: null }
    : { commit: { label: "Approve", press: "approve", then: null }, secondary, link: null, note: null };
}

/**
 * A posted card's way to the entry in its ledger, or null (verify pass 3, S-CF-12). On a
 * recording ledger the engine sends the entry's in-app page (`ledgerPath`, `/records?…`)
 * beside an absolute `ledgerLink`; the pager card took the absolute link and called it
 * "View in QuickBooks ↗" while the posted plate, from the same entry, said "View the
 * entry in Vert". Every posted card now reads the same rule: the in-app path first, as
 * Vert's page, in this tab; otherwise the ledger's own https link, named by the ledger.
 * Pure.
 */
export function postedLedgerLink(je, label) {
  const e = je && typeof je === "object" ? je : {};
  const path = typeof e.ledgerPath === "string" && /^\/records\?/.test(e.ledgerPath) ? e.ledgerPath : null;
  if (path) return { href: path, label: "View the entry in Vert", internal: true };
  const link = typeof e.ledgerLink === "string" && /^https:\/\/\S+$/.test(e.ledgerLink) ? e.ledgerLink : null;
  return link && label ? { href: link, label, internal: false } : null;
}

/**
 * EVERY FIELD WAS THE PERSON'S (verify pass 3, D10). A manual entry whose account,
 * amount, date and memo were each answered in the conversation carried "Vert's best
 * guess. Check it." as if Vert had guessed it. Its record's evidence says otherwise:
 * every chip is the person's own answer (`kind: "answer"`). True only then. Pure.
 */
export function statedByPerson(je) {
  const ev = je && Array.isArray(je.evidence) ? je.evidence.filter((e) => e && typeof e === "object") : [];
  return ev.length > 0 && ev.every((e) => e.kind === "answer");
}

/**
 * The engine's reason, or null when it names a control this card does not draw (verify
 * pass 3, D10): an approved entry with no ledger to post to read "Post it, or Undo the
 * approval." over a card whose only control is Undo; the card's own note ("Ready to post
 * when your ledger is connected.") says what is true instead. Pure.
 */
export function whyForControls(why, controls, { closed = null } = {}) {
  if (typeof why !== "string" || !why.trim()) return null;
  if (controls && !controls.commit && /\bPost it\b/i.test(why)) return null;
  // POST HELD FOR A SIGNED-OFF MONTH (UI walk 3, W3-3): "Post it, or Undo the approval."
  // sat over a disabled Post. The sentence that says to post is dropped; the held
  // press's own reason says what can be done (reopen the month, or undo the approval).
  if (closed) {
    const kept = (why.match(/[^.!?]+[.!?]*/g) || []).filter((s) => !/\bPost it\b/i.test(s)).join("").trim();
    return kept || null;
  }
  return why;
}

/**
 * A REFUSAL PRESSING AGAIN CAN'T CHANGE (UI walk 3, W3-1). After Vert's checks refused the
 * post (a 409: the month is closed, the entry changed) or the ledger refused it outright,
 * "Record as posted" stayed live and each press was another refusal. Such a refusal holds
 * the confirm, with this reason; a dropped connection, an unknown outcome, or an approval
 * that stood with the post still to make may land on a second press, so they don't. Pure.
 */
export const REFUSED_AGAIN = "Pressing again would be refused too: why is above.";

export function refusalHolds(failure) {
  if (!failure || typeof failure !== "object" || failure.ok) return false;
  if (failure.ledgerRefusal) return true;
  return !failure.approved && (failure.kind === "blocked" || failure.kind === "unavailable");
}

/** "QuickBooks Online (recording, nothing is sent)" → "QuickBooks": the name a button says. */
export function shortLedger(name) {
  const full = typeof name === "string" ? name.replace(/\s*\([^)]*\)\s*$/, "").trim() : "";
  return full.replace(/\s+Online$/i, "") || full;
}

export const SECONDARY_LABELS = Object.freeze({
  approve_only: "Approve only",
  edit: "Edit",
  reject: "Reject…",
  undo: "Undo",
  reverse: "Reverse",
});

/** The ledger's name as the API reported it, else the name the page was given. */
export function ledgerDisplayName(ledger, ledgerName = null) {
  if (ledger && typeof ledger.displayName === "string" && ledger.displayName.trim()) return ledger.displayName.trim();
  return typeof ledgerName === "string" && ledgerName.trim() ? ledgerName.trim() : null;
}

/**
 * THE CARD'S STATE MACHINE. `flow` is `{ state, sheet, busy, failure }`; an event
 * returns the next flow and, when a press writes, the write it asks for (`write`). The
 * component dispatches the events and performs the writes; the test walks them.
 *
 *   press_commit   the purple control
 *   confirm_post   the sheet's "Post to {ledger}"
 *   close_sheet    Cancel / Esc
 *   written        a write answered: { write, result }
 */
export function journalFlow(flow, event, { ledger = null } = {}) {
  const f = { sheet: false, busy: false, failure: null, approvedOnly: false, ...flow };
  const controls = cardControls(f.state, ledger);
  switch (event.type) {
    case "press_commit": {
      if (!controls.commit || f.busy) return { flow: f, write: null };
      if (controls.commit.press === "open_post") return { flow: { ...f, sheet: true, failure: null }, write: null };
      return { flow: { ...f, busy: true, failure: null }, write: "approve" };
    }
    case "confirm_post": {
      if (!f.sheet || f.busy || !controls.commit || controls.commit.press !== "open_post") return { flow: f, write: null };
      return { flow: { ...f, busy: true, failure: null }, write: controls.commit.then };
    }
    case "close_sheet":
      return { flow: { ...f, sheet: false }, write: null };
    case "written":
      return { flow: afterWrite(f, event.write, event.result), write: null };
    default:
      return { flow: f, write: null };
  }
}

// What a write's answer does to the card. An approve-and-post whose approval landed and
// whose post did not leaves the entry APPROVED with the failure shown (§4.11a.9: a
// failed post is not rolled back), so the next press is a plain post, not a second
// approval.
function afterWrite(f, write, result) {
  const r = result && typeof result === "object" ? result : { ok: false };
  if (r.ok) {
    const next = write === "approve" ? "approved" : write === "undo" ? "draft" : write === "post" || write === "approve_and_post" ? "posted" : f.state;
    return { ...f, state: next, sheet: false, busy: false, failure: null };
  }
  if (write === "approve_and_post" && r.approved === true) {
    return { ...f, state: "approved", sheet: true, busy: false, failure: r };
  }
  return { ...f, busy: false, failure: r };
}

/** The entry as the card should now show it after a post the ledger answered. The
 *  post's read-back (the engine's check table) comes with the answer and is carried
 *  as sent; with none, the card's own `je.readBack` stands. */
export function postedEntry(je, result) {
  const body = (result && result.body) || {};
  const posted = body.posted || {};
  // The engine's own card for the posted entry, when the route sends it (EX); it is the
  // source of the number and the narration as the ledger holds them.
  const card = body.je && typeof body.je === "object" ? body.je : {};
  const number =
    idText(card.number) || idText(posted.docNumber) || journalNumberOf(posted) || idText(je.number) || null;
  const readBack = isReadBack(body.readBack) ? body.readBack : isReadBack(card.readBack) ? card.readBack : je.readBack || null;
  // What the ledger holds of it, as the post answered (p1/fix5); unsaid, nothing is set.
  const held = ledgerStatusOf(posted);
  return {
    ...je,
    ...(held ? { ledgerStatus: held } : {}),
    state: "posted",
    number,
    ledgerLink: (typeof posted.entryUrl === "string" && posted.entryUrl) || card.ledgerLink || je.ledgerLink || null,
    postedNarration: narrationFor(
      (typeof card.postedNarration === "string" && card.postedNarration) || je.postedNarration,
      number,
      entryDateOf({ card, je, readBack }),
    ),
    readBack,
  };
}

/**
 * `GET /journal/{id}`'s body → the post re-read (lib/journal.js readPostedEntry):
 * `confirmed` only when the stored entry is posted AND carries the ledger's id. Pure.
 */
export function postedReadingOf(body) {
  // `GET /journal/{id}` answers `{ entry: {...}, je: {...} }` (eval final-a JE5: read
  // at the top level, the ledger's number was never found, and every plate rebuilt from
  // the record said "Posted" with no Journal entry number). A bare entry still reads.
  const outer = body && typeof body === "object" ? body : {};
  const b = outer.entry && typeof outer.entry === "object" ? outer.entry : outer;
  const gl = idText(b.glExternalId);
  const status = typeof b.status === "string" ? b.status : typeof b.state === "string" ? b.state : null;
  return {
    ok: Boolean(body && typeof body === "object"),
    confirmed: Boolean(gl) && (status === null || status === "posted"),
    glExternalId: gl,
    entryUrl: [b.ledgerUrl, b.entryUrl, b.ledgerLink].find((u) => typeof u === "string" && u) || null,
    status,
    sumDr: Number.isInteger(b.sumDr) ? b.sumDr : null,
    je: outer.je && typeof outer.je === "object" ? outer.je : null,
    // "Open" and "View on QB ↗" (build plan §19.8 DOCX): the engine's `links`, read
    // back with the posted entry, beside the read-back and never inside it.
    links: b.links && typeof b.links === "object" ? b.links : null,
    // The documents filed against it (D08), each a chip; null when not read.
    documents: entryDocuments(b),
    // The record it was drafted from (Q02 JE4), a chip for a card the engine sent none.
    sources: entrySources(b),
    // The reversal standing against it (D11), from the entry or its card.
    reversal: reversalOf(b.reversal, outer.je && outer.je.reversal),
    // WHO DRAFTED IT (P12): the entry's own record names its drafter
    // (`entry.manual.createdBy`), which the card's `je` does not carry, so a drafter's
    // own "Approve and post…" can be refused before the press, as the engine will.
    drafter: drafterOf(b),
    // WHO POSTED IT AND WHEN (S-CF-12): a stale tab told of a post someone else made
    // names them. The engine's statusReason ends "… by Sam Stress."; else the latest
    // approval's actor, who is the one the post was signed by.
    postedBy: postedByOf(b),
    postedAt: typeof b.postedAt === "string" && b.postedAt ? b.postedAt : null,
    journalNumber: journalNumberOf(b),
    // WHAT THE LEDGER HOLDS OF IT (p1/fix5): "draft" | "posted", or null when the engine
    // did not say; and the ledger's display name from the same answer.
    ledgerStatus: ledgerStatusOf(b),
    ledgerName: outer.ledger && typeof outer.ledger.displayName === "string" && outer.ledger.displayName.trim() ? outer.ledger.displayName.trim() : null,
  };
}

function postedByOf(entry) {
  const reason = typeof entry.statusReason === "string" ? / by ([^.]+)\.\s*$/.exec(entry.statusReason) : null;
  if (reason && reason[1].trim()) return reason[1].trim();
  const decisions = Array.isArray(entry.decisions) ? entry.decisions : [];
  const approval = [...decisions].reverse().find((d) => d && d.decision === "approve" && typeof d.actor === "string" && d.actor.trim());
  return approval ? approval.actor.trim() : null;
}

// The refusals a write gets when the entry moved under it: another tab or person
// decided or posted it first.
const MOVED_CODES = new Set(["illegal_transition", "state_conflict", "not_approved", "concurrent_modification", "already_posted"]);

/** Whether a failed write may mean someone else already decided the entry (S-CF-12). Pure. */
export function mayBeMovedUnder(result) {
  if (!result || result.ok) return false;
  // The ledger definitely refused the post (engine w3/int, W3-1): nobody moved it, and
  // reading it back would only find it unposted.
  if (result.ledgerRefusal) return false;
  // A write whose answer never came (walk 2, N3) may have posted: it is read back too.
  if (result.kind === "unconfirmed") return true;
  return result.status === 409 || MOVED_CODES.has(result.code);
}

/**
 * The sentence for a write refused because the entry was already posted by someone
 * (S-CF-12): "Already posted by Sam Stress at 11:52 pm on 14 Oct 2026 as journal entry 6.
 * Nothing was recorded twice." Null when the read-back does not show it posted. Pure.
 */
export function alreadyPostedSentence(reading, { signedIn = null } = {}) {
  if (!reading || !reading.confirmed) return null;
  const parts = ["Already posted"];
  // The poster as recorded ("key: founder" for a shared key) is worded against the
  // viewer (engine w3/int: actors come raw): "you", "another access code", or the name.
  const by = actorWords(reading.postedBy, { signedIn });
  if (by) parts.push(`by ${by}`);
  if (reading.postedAt) {
    try {
      parts.push(`at ${formatTime(reading.postedAt)} on ${formatDate(reading.postedAt)}`);
    } catch {
      // An instant the formatter refuses is left out rather than invented.
    }
  }
  if (ledgerNumber(reading.journalNumber)) parts.push(`as journal entry ${ledgerNumber(reading.journalNumber)}`);
  return `${parts.join(" ")}. Nothing was recorded twice.`;
}

/**
 * The documents `GET /journal/{id}` lists under `entry.evidence.documents` (D08), as
 * file chips `{documentId, name, detail}`; null when the engine didn't read them. Pure.
 */
export function entryDocuments(entry) {
  const ev = entry && entry.evidence && typeof entry.evidence === "object" ? entry.evidence : null;
  if (!ev || ev.read !== true || !Array.isArray(ev.documents)) return null;
  return ev.documents
    .filter((d) => d && typeof d.documentId === "string" && d.documentId)
    .map((d) => ({
      documentId: d.documentId,
      name: typeof d.filename === "string" && d.filename.trim() ? d.filename.trim() : "Attached file",
      detail: Array.isArray(d.pages) && d.pages.length ? `p. ${d.pages.join(", ")}` : null,
    }));
}

/**
 * THE RECORD AN ENTRY WAS DRAFTED FROM, AS A CHIP (verify pass 7, Q02 JE4; stuck four
 * passes). A schedule's release (a prepaid release, a recognition) has no manual journal
 * behind it, so the engine's card sends `evidence: []`, and the release card drew no
 * chip although `GET /journal/{id}` names its source: `entry.source.record`
 * (`{kind: "prepaid_schedule", id}`) and, in words, `backReference.draftedOn` ("a
 * schedule agreed by Sam Lee"). `[{kind, id, label}]` in words, never an id; null for
 * a hand entry (its own chip, "Drafted in this conversation", comes on the card) or an
 * entry that names no record. Pure.
 */
export function entrySources(entry) {
  const src = entry && entry.source && typeof entry.source === "object" ? entry.source : null;
  const rec = src && src.record && typeof src.record === "object" ? src.record : null;
  if (!rec || typeof rec.kind !== "string" || !rec.kind || rec.kind === "manual_journal") return null;
  const back = entry.backReference && typeof entry.backReference === "object" ? entry.backReference : {};
  const on = typeof back.draftedOn === "string" ? back.draftedOn.trim() : "";
  const kind = typeof src.label === "string" ? src.label.trim() : "";
  const label = on ? `From ${on}` : kind ? `From the ${kind.charAt(0).toLowerCase()}${kind.slice(1)} record` : null;
  return label ? [{ kind: rec.kind, id: typeof rec.id === "string" ? rec.id : null, label }] : null;
}

/**
 * The chips a card draws (Q02 JE4): the engine's own evidence, else the record its saved
 * entry was drafted from (`entrySources`), so a card with a source is never chipless.
 * Pure.
 */
export function cardEvidence(evidence, sources) {
  const own = Array.isArray(evidence) ? evidence.filter((e) => e && typeof e === "object") : [];
  if (own.length) return own;
  return Array.isArray(sources) ? sources.filter((e) => e && typeof e.label === "string" && e.label) : [];
}

/**
 * ONE CHIP PER RECORD (verify pass 10, Q02 N-10). A card's chips come from two reads:
 * the engine's card evidence (`je.evidence`, which names the file an entry was drafted
 * from as a `document` chip by its label) and the documents filed against the stored
 * entry (`GET /journal/{id}`, by document id). The two name the same file under
 * different ids, so the payroll card drew "payroll-july.xlsx" twice. A document is kept
 * once per id; an evidence chip whose label is a filed document's name gives way to that
 * document (the chip that opens the file); evidence labels are kept once each. Pure.
 */
export function cardChips(evidence, documents) {
  const docs = [];
  const docIds = new Set();
  for (const d of Array.isArray(documents) ? documents : []) {
    if (!d || typeof d.documentId !== "string" || docIds.has(d.documentId)) continue;
    docIds.add(d.documentId);
    docs.push(d);
  }
  const key = (v) => (typeof v === "string" ? v.trim().toLowerCase() : "");
  const filed = new Set(docs.map((d) => key(d.name)).filter(Boolean));
  const seen = new Set();
  const own = [];
  for (const ev of Array.isArray(evidence) ? evidence : []) {
    const label = key(ev && ev.label);
    if (!label || filed.has(label) || seen.has(label)) continue;
    seen.add(label);
    own.push(ev);
  }
  return { evidence: own, documents: docs };
}

/**
 * Whether the card must read its entry back to learn who drafted it (P12): the firm
 * splits the work, the entry is saved (it has an id the API holds), it is not posted,
 * and nothing the card already holds names its drafter. Pure.
 */
export function needsDrafterRead({ duties = null, drafter = null, entryId = null, state = null } = {}) {
  if (!duties || duties.segregation !== true) return false;
  if (drafter) return false;
  if (state === "posted") return false;
  return isEntryId(entryId);
}

function idText(value) {
  if (typeof value === "string" && value.trim()) return value.trim();
  if (Number.isInteger(value)) return String(value);
  return null;
}

/**
 * "Posted as journal 1042 dated 31 Jul 2026." — the engine's sentence
 * (vert_engine/journals posted_narration), word for word, for a post whose answer did
 * not carry the engine's card. Built only from the ledger's number and the entry's own
 * date; no number, no sentence (an unnumbered post says nothing rather than a guess).
 */
export function postedNarrationFor(number, date) {
  // A GUID is the ledger's internal id, not a journal number (staging browser walk 1, D17).
  const n = ledgerNumber(idText(number));
  if (!n) return null;
  const day = safe(() => formatDate(date));
  return `Posted as journal ${n}${day ? ` dated ${day}` : ""}.`;
}

/**
 * The ENTRY's own date, for the narration — never the post's timestamp (eval r2 JE5 /
 * §9.3 C1, 3 Oct). A June payout's plate read "Posted as journal 2 dated 3 Oct 2026"
 * over its own read-back row "Date 2 Jun 2026 · 2 Jun 2026 · Pass": the fallback was
 * handed `posted.postedAt`. One card states one date, so the candidates are the entry's
 * date as the engine's card holds it, then as this card holds it, then the date the
 * read-back says was SENT (its Expected) — all the same fact when present. Null when
 * none is an ISO day: the narration then carries no date rather than a wrong one.
 */
export function entryDateOf({ card = null, je = null, readBack = null } = {}) {
  const iso = (v) => (typeof v === "string" && /^\d{4}-\d{2}-\d{2}/.test(v) ? v.slice(0, 10) : null);
  const row = isReadBack(readBack) ? readBack.checks.find((c) => c && c.check === "Date") : null;
  return iso(card && card.date) || iso(je && je.date) || iso(row && row.expected) || null;
}

/**
 * The narration to draw: the engine's sentence when it agrees with the entry's date,
 * rebuilt from the number and that date when it names another day (or is missing).
 * A narration that contradicts the check table beside it is the defect, so the table's
 * own fact wins; a sentence with no date in it is left as the engine wrote it.
 */
export function narrationFor(engineNarration, number, date) {
  const given = typeof engineNarration === "string" && engineNarration ? engineNarration : null;
  const day = date ? safe(() => formatDate(date)) : null;
  if (given && (!day || !/ dated /.test(given) || given.includes(` dated ${day}`))) return given;
  return postedNarrationFor(number, date) || given;
}

/* ══════════════════════════════════════════════════════════════════════════════ *
 * THE READ-BACK (teardown standard 12): after a post, the engine reads the entry back
 * from the ledger and checks it against what was sent. The card draws the engine's
 * table — Check | Expected | Actual | Result — and works nothing out: every value is
 * the engine's. Results arrive lower case ("pass", "fail", "not_read"); the screen
 * words them, never in capitals (an all-caps verdict is banned prose). An overall
 * `verified` of null is "Not read back" — unread is never a pass.
 * ══════════════════════════════════════════════════════════════════════════════ */

export const READ_BACK_RESULTS = Object.freeze({ pass: "Pass", fail: "Fail", not_read: "Not checked" });

// A CHECK THE LEDGER CAN'T ANSWER (staging browser walk 6, W6-1; w20 contract). Xero gives
// a manual journal no number, so the engine passes that row with expected "None: Xero
// gives manual journals no number" and actual "None". The card says it is not
// applicable, with the engine's reason in Expected; a "None: …" row that failed stays a
// fail. Not a result the engine sends: the screen's word for that one shape.
const NOT_APPLICABLE = "Not applicable";
const NONE_BECAUSE = /^None:\s*(\S[\s\S]*)$/;

/** Whether `value` is the engine's read-back shape: `{checks: [...], verified}`. */
export function isReadBack(value) {
  return Boolean(value && typeof value === "object" && Array.isArray(value.checks) && value.checks.length);
}

/** The table's one-line verdict, from `verified` alone. */
export function readBackLine(readBack) {
  if (!isReadBack(readBack)) return null;
  if (readBack.verified === true) return "Read back from the ledger: every check passes.";
  if (readBack.verified === false) return "Read back from the ledger: it holds this entry differently from what was sent.";
  return "Not read back: the ledger couldn't be read, so nothing here is confirmed.";
}

const MONEY_CHECKS = new Set(["Debits", "Credits"]);
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

function readBackValue(check, value, side, result = null) {
  // A row that was checked and failed with nothing in the ledger says None, never "Not
  // checked" beside "Fail" (W6-1: the w20 engine sends "None"; an older one sent null).
  if (value === null || value === undefined || value === "") return side === "actual" ? (result === "fail" ? "None" : "Not checked") : "";
  // The ledger's own id is an id, and ids are drawn only under Details (spec §1.6).
  if (check === "Found in the ledger") return side === "actual" ? "Found" : "This entry";
  if (MONEY_CHECKS.has(check) && Number.isInteger(value)) return formatMoney(value);
  if (typeof value === "string" && ISO_DATE.test(value)) return formatDate(value);
  // "Created in Vert by Dana · conversation c_12": the conversation's id stays off the face.
  if (typeof value === "string") return value.split(" · ")[0];
  return String(value);
}

/** The read-back's rows as the card draws them, or [] when there is none. */
export function readBackRows(readBack) {
  if (!isReadBack(readBack)) return [];
  return readBack.checks.map((c) => {
    const result = Object.prototype.hasOwnProperty.call(READ_BACK_RESULTS, c.result) ? c.result : "not_read";
    const because = result === "pass" && typeof c.expected === "string" ? NONE_BECAUSE.exec(c.expected.trim()) : null;
    if (because) {
      return { check: String(c.check || ""), expected: because[1], actual: "None", result: "not_applicable", resultText: NOT_APPLICABLE };
    }
    return {
      check: String(c.check || ""),
      expected: readBackValue(c.check, c.expected, "expected"),
      actual: result === "not_read" ? "Not checked" : readBackValue(c.check, c.actual, "actual", result),
      result,
      resultText: READ_BACK_RESULTS[result],
    };
  });
}

/* ══════════════════════════════════════════════════════════════════════════════ *
 * THE EDITOR (§4.0.4): an edit is a new entry that supersedes the old one.
 * ══════════════════════════════════════════════════════════════════════════════ */

/** Cents as the text a person edits: "1,234.56", or "" for an unused side. */
export function centsText(cents) {
  if (!(typeof cents === "number" && Number.isInteger(cents) && cents > 0)) return "";
  return formatMoney(cents).replace(/^\$/, "");
}

let blankSeq = 0;

/** A blank line, as the editor's "Add a line" adds it. */
export function blankLine() {
  blankSeq += 1;
  return { key: `new-${blankSeq}`, accountId: "", account: null, debit: "", credit: "", description: "", name: "", classRef: "", locationRef: "" };
}

/** The editor's starting state, from the card's entry. */
export function editorState(je) {
  const lines = (je && Array.isArray(je.lines) ? je.lines : []).map((l, i) => ({
    key: `l${i}`,
    accountId: (l.account && l.account.id) || "",
    account: l.account || null,
    debit: centsText(l.debitCents),
    credit: centsText(l.creditCents),
    description: l.description || "",
    // Who the line is with (Q03: the reference editor's Name/Vendor column).
    name: l.name || "",
    classRef: l.classRef || "",
    locationRef: l.locationRef || "",
  }));
  return {
    memo: (je && je.memo) || "",
    date: (je && je.date) || "",
    lines,
    failure: null,
    busy: false,
  };
}

/** One edit to the editor's state. Never resets what the person typed (UI-052). */
export function editLines(state, edit) {
  const s = { ...state };
  if (edit.type === "field") return { ...s, [edit.name]: edit.value };
  if (edit.type === "add") return { ...s, lines: [...s.lines, blankLine()] };
  if (edit.type === "remove") return s.lines.length <= 2 ? s : { ...s, lines: s.lines.filter((l) => l.key !== edit.key) };
  if (edit.type === "line") {
    const before = s.lines.find((l) => l.key === edit.key);
    const lines = s.lines.map((l) => (l.key === edit.key ? { ...l, ...edit.patch } : l));
    return renamedAccount({ ...s, lines }, before, lines.find((l) => l.key === edit.key));
  }
  if (edit.type === "saving") return { ...s, busy: true, failure: null };
  // A failed save keeps every line exactly as it was and says what happened.
  if (edit.type === "failed") return { ...s, busy: false, failure: edit.result || { ok: false } };
  if (edit.type === "saved") return { ...s, busy: false, failure: null };
  return s;
}

/**
 * THE WORDS FOLLOW THE ACCOUNT (verify pass 6, D10). Vert words an entry by its accounts
 * ("Reclass from Office expenses to Software subscriptions"): its memo, which is the
 * card's title, and its lines' descriptions. An edit that moved the entry off Software
 * subscriptions onto Utilities saved, posted and titled it "...to Software
 * subscriptions" still, naming an account the entry no longer touches. So when a line's
 * account changes and no line uses the old account any more, the old account's name in
 * the memo and descriptions becomes the new one's. Words that never named it are left
 * exactly as typed (UI-052). Pure.
 */
function renamedAccount(state, before, after) {
  const was = before && before.account && typeof before.account.name === "string" ? before.account.name.trim() : "";
  const now = after && after.account && typeof after.account.name === "string" ? after.account.name.trim() : "";
  if (!was || !now || was === now || !after || before.accountId === after.accountId) return state;
  if (state.lines.some((l) => l.account && typeof l.account.name === "string" && l.account.name.trim() === was)) return state;
  const escaped = was.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const named = new RegExp(`(^|[^\\p{L}\\p{N}])${escaped}(?=$|[^\\p{L}\\p{N}])`, "giu");
  const swap = (text) => (typeof text === "string" ? text.replace(named, (_, lead) => `${lead}${now}`) : text);
  return { ...state, memo: swap(state.memo), lines: state.lines.map((l) => ({ ...l, description: swap(l.description) })) };
}

/** Typed dollars → integer cents, or null when the text isn't an amount. Mirrors
 *  components/ui/fields.js parseDollars (imported there would pull a client module into
 *  a test of pure logic); refuses negatives, which a Debit or Credit cell never holds. */
export function dollarsToCents(text) {
  const raw = String(text ?? "").trim().replace(/^\$/, "");
  if (!raw) return 0;
  if (!/^(\d{1,3}(,\d{3})+|\d+)(\.\d{1,2})?$/.test(raw)) return null;
  const [whole, fraction = ""] = raw.replace(/,/g, "").split(".");
  const cents = Number.parseInt(`${whole}${fraction.padEnd(2, "0")}`, 10);
  return Number.isSafeInteger(cents) ? cents : null;
}

/**
 * The editor's live totals: the ONE place the view layer adds money (see the head of
 * this file). Integers only; a cell that isn't an amount makes the totals unknown
 * rather than zero, because an unread cell is not a zero.
 */
export function editorTotals(lines) {
  let debitCents = 0;
  let creditCents = 0;
  const unreadable = [];
  for (const line of Array.isArray(lines) ? lines : []) {
    const d = dollarsToCents(line.debit);
    const c = dollarsToCents(line.credit);
    if (d === null || c === null) {
      unreadable.push(line.key);
      continue;
    }
    debitCents += d;
    creditCents += c;
  }
  if (unreadable.length) return { debitCents: null, creditCents: null, balanced: false, unreadable };
  return { debitCents, creditCents, balanced: debitCents === creditCents && debitCents > 0, unreadable };
}

/**
 * WHAT THE TOTALS ROW SAYS ABOUT BALANCE (UI walk D12, 30 Oct 2026): "unreadable" while an
 * amount isn't dollars, "empty" until a line has an amount, then "balanced" or "off". A
 * new, empty entry said "Doesn't balance" in red over $0.00 and $0.00: nothing had been
 * typed for it to be wrong about. Pure.
 */
export function balanceOf(lines) {
  const totals = editorTotals(lines);
  if (totals.debitCents === null) return "unreadable";
  const amounts = (Array.isArray(lines) ? lines : []).some((l) => dollarsToCents(l.debit) || dollarsToCents(l.credit));
  if (!amounts) return "empty";
  return totals.balanced ? "balanced" : "off";
}

/**
 * Why the edited entry can't be saved (and so can't be approved), or null when it can.
 * The same rules the engine applies on Save (`POST /journal/{id}/redraft`, 422), said
 * before the press so it is never spent learning them.
 */
export function editorGate(state) {
  const lines = state && Array.isArray(state.lines) ? state.lines : [];
  if (lines.length < 2) return "An entry needs at least two lines.";
  for (const [i, l] of lines.entries()) {
    const n = `Line ${i + 1}`;
    if (!l.accountId) return `${n} needs an account.`;
    const d = dollarsToCents(l.debit);
    const c = dollarsToCents(l.credit);
    if (d === null || c === null) return `${n}'s amount isn't a dollar amount, like 1,234.56.`;
    if ((d > 0) === (c > 0)) return `${n} needs a debit or a credit, not both.`;
    if (!String(l.description || "").trim()) return `${n} needs a description.`;
  }
  if (!String(state.memo || "").trim()) return "The entry needs a memo.";
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(state.date || ""))) return "The entry needs a date.";
  const t = editorTotals(lines);
  if (!t.balanced) return EDITOR_UNBALANCED_REASON;
  return null;
}

/**
 * What Save sends: `POST /journal/{id}/redraft` with the edited memo, date and lines,
 * money in cents. Account ids are the ledger's own (from /ledger/accounts); class and
 * location only when set.
 */
export function redraftBody(state) {
  return {
    memo: String(state.memo || "").trim(),
    date: state.date,
    lines: state.lines.map((l) => {
      const out = {
        accountId: l.accountId,
        debitCents: dollarsToCents(l.debit) || 0,
        creditCents: dollarsToCents(l.credit) || 0,
        description: String(l.description || "").trim(),
      };
      if (String(l.name || "").trim()) out.name = l.name.trim();
      if (String(l.classRef || "").trim()) out.classRef = l.classRef.trim();
      if (String(l.locationRef || "").trim()) out.locationRef = l.locationRef.trim();
      return out;
    }),
  };
}

/**
 * What Save sends for a NEW entry written by hand: `POST /journal/drafts`
 * (vert_api/routers/journal.py DraftBody, which refuses an unknown field). Its names
 * are the route's own: `account` (the chart id the picker chose), `entryDate`. The
 * period and the conversation it was written in travel with it when known.
 */
export function draftBody(state, { period = null, sessionId = null } = {}) {
  const body = {
    memo: String(state.memo || "").trim(),
    entryDate: state.date,
    lines: state.lines.map((l) => ({
      account: l.accountId,
      debitCents: dollarsToCents(l.debit) || 0,
      creditCents: dollarsToCents(l.credit) || 0,
      description: String(l.description || "").trim(),
      ...(String(l.name || "").trim() ? { name: l.name.trim() } : {}),
    })),
  };
  // THE MONTH OF THE DATE CHOSEN (UI walk 2, N1, 30 Oct 2026). The editor opens dated in
  // a month (`period`, the page's first open one), but the person may pick any day: an
  // entry dated 30 Nov 2026 was sent as October's and refused ("The date … is not in
  // October 2026"). The chosen date names the month; the editor's month only stands in
  // while no date is chosen.
  const dated = typeof state.date === "string" ? /^(\d{4}-(0[1-9]|1[0-2]))-\d{2}$/.exec(state.date) : null;
  const month = dated ? dated[1] : period;
  if (typeof month === "string" && /^\d{4}-(0[1-9]|1[0-2])$/.test(month)) body.period = month;
  if (typeof sessionId === "string" && sessionId) body.sessionId = sessionId;
  // W3: the type the person chose (DraftBody `entryKind`) and the day it reverses on
  // (`autoReverseOn`), each only when set: an entry with neither is drafted as before.
  if (typeof state.entryKind === "string" && /^[a-z_]{1,40}$/.test(state.entryKind)) body.entryKind = state.entryKind;
  if (typeof state.autoReverseOn === "string" && /^\d{4}-\d{2}-\d{2}$/.test(state.autoReverseOn)) body.autoReverseOn = state.autoReverseOn;
  return body;
}

/** The blank editor's starting state: no memo, the month's last day, two empty lines. */
export function blankEditorState(period = null) {
  const m = typeof period === "string" ? /^(\d{4})-(0[1-9]|1[0-2])$/.exec(period) : null;
  // The month's last day, by the calendar, not the browser's clock.
  const date = m ? `${m[1]}-${m[2]}-${String(new Date(Date.UTC(Number(m[1]), Number(m[2]), 0)).getUTCDate()).padStart(2, "0")}` : "";
  return { memo: "", date, lines: [blankLine(), blankLine()], failure: null, busy: false };
}

/**
 * The entry the card shows after a Save the engine accepted: the edited lines (with
 * each account's number and name from the chart the picker read) under the NEW entry's
 * id, so the next approval signs the new hash (§4.0.4).
 */
export function savedEntry(je, state, result, accounts = []) {
  const body = (result && result.body) || {};
  const entry = body.entry || {};
  const id = (typeof entry.externalId === "string" && entry.externalId) || null;
  if (body.je && typeof body.je === "object") return { entryId: id, je: { ...body.je } };
  const req = redraftBody(state);
  const byId = new Map((Array.isArray(accounts) ? accounts : []).map((a) => [a.id, a]));
  const lines = req.lines.map((l, i) => {
    const known = byId.get(l.accountId) || state.lines[i].account || { id: l.accountId, name: l.accountId };
    return { ...l, account: { id: known.id || l.accountId, number: known.number || null, name: known.name || l.accountId } };
  });
  const totals = engineTotalsFrom(entry, state);
  return {
    entryId: id,
    je: { ...je, state: "draft", number: null, memo: req.memo, date: req.date, lines, totals, supersedes: (je && je.supersedes) || null },
  };
}

// The new entry's totals as the ENGINE stored them (`sumDr`/`sumCr` on the redraft's
// answer), else the editor's own check of the lines it just sent.
function engineTotalsFrom(entry, state) {
  if (Number.isInteger(entry.sumDr) && Number.isInteger(entry.sumCr)) return { debitCents: entry.sumDr, creditCents: entry.sumCr };
  const t = editorTotals(state.lines);
  return { debitCents: t.debitCents, creditCents: t.creditCents };
}

/**
 * Why the chart can't be offered yet, in a bookkeeper's words (live check, 29 Oct 2026:
 * the editor printed "gl_accounts: gl_accounts has never been synced for this client").
 * An engine reason that names a table, or says the chart was never synced, is said as
 * one plain sentence; any other reason the engine wrote for a person is kept. Pure.
 */
export const CHART_UNREAD = "Vert hasn't read your chart of accounts yet: sync your ledger first.";

export function chartUnreadMessage(body) {
  const said = body && typeof (body.notMeasuredReason || body.inWords) === "string" ? String(body.notMeasuredReason || body.inWords).trim() : "";
  if (!said || /\bgl_\w+|never been synced|not been synced|_accounts\b/i.test(said)) return CHART_UNREAD;
  return said;
}

/** `/ledger/accounts` rows → the picker's options, active accounts only, by number. */
export function accountOptions(accounts) {
  const list = (Array.isArray(accounts) ? accounts : []).filter((a) => a && a.id && a.active !== false);
  return list
    .slice()
    .sort((a, b) => String(a.number || "~").localeCompare(String(b.number || "~")) || String(a.name).localeCompare(String(b.name)))
    .map((a) => ({ value: a.id, label: accountText(a) }));
}

function safe(fn) {
  try {
    return fn();
  } catch {
    return null;
  }
}

/**
 * Whether `id` is an entry the journal routes know (`je:` + a hash; vert_api
 * routers/journal.py `_ENTRY_ID`), as opposed to a proposal's id (`glrec_…`) that has
 * not been drafted yet. Mirrors lib/journal.js's check, which a "use server" module
 * cannot export as a plain function.
 */
export function isEntryId(id) {
  return typeof id === "string" && /^[a-z]{1,16}:[0-9a-f]{6,64}$/.test(id);
}

/**
 * The engine's "Utilities: its balance after the post isn't measured: Vert hasn't been
 * told when these books began." said in one clause (DA2-056): "Utilities balance after
 * posting: not measured (no opening balance set)." Anything else is said as the engine
 * wrote it. Pure.
 */
export function balanceWords(text) {
  const t = typeof text === "string" ? text.trim() : "";
  const m = /^(.+?): its balance after the post isn't measured(?::|,)? .*began\.?$/i.exec(t);
  return m ? `${m[1]} balance after posting: not measured (no opening balance set).` : t;
}
