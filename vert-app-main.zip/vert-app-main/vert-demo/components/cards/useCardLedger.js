"use client";

// components/cards/useCardLedger.js — THE LEDGER, FOR A CARD NOBODY HANDED IT TO
// ==============================================================================
// Eval JE5 (2 Oct): with the recording ledger configured, the journal card in a task's
// conversation offered "Approve", not "Approve and post…", and an approval made in the
// chat offered no Post at all. Month-end reads `/approvals/ledger` on the server and
// passes it down; the thread draws cards through `CardFor` with only a ledger NAME, so
// every card there believed no ledger was connected — and draft → posted in two
// presses (§4.0.5) was impossible from the place most decisions are made.
//
// A card now asks for itself when its parent gave it no descriptor: the same
// `/approvals/ledger` answer (lib/journal.js readCardLedger → lib/ledger.js), once per
// page load, shared by every card. The given prop always wins. Until the answer comes
// back the card behaves as with no ledger (Approve, no Post) — the safe direction: a
// Post button drawn on a guess would be a false affordance into somebody's books. In
// the sample build nothing is asked (there is no API behind it).

import { useEffect, useState } from "react";
import { useWritesEnabled } from "@/lib/engine-context";

let known = null;
let pending = null;

function ask() {
  if (!pending) {
    // A GET (staging D4 retest): this was the readCardLedger Server Action, a POST on
    // arriving at any conversation with a card its parent gave no ledger.
    pending = readLedgerByGet().then((ledger) => {
      // Only a real answer is kept; a failed ask is asked again by the next card.
      if (ledger && typeof ledger === "object" && ledger.ok !== false) known = ledger;
      else pending = null;
      return known;
    });
  }
  return pending;
}

/** `GET /api/journal?ledger` → the ledger descriptor, or null. Never throws. */
export async function readLedgerByGet(fetchImpl = null) {
  const doFetch = fetchImpl || (typeof window !== "undefined" && typeof window.fetch === "function" ? window.fetch.bind(window) : null);
  if (!doFetch) return null;
  try {
    const response = await doFetch("/api/journal?ledger", { method: "GET", headers: { accept: "application/json" }, cache: "no-store", credentials: "same-origin" });
    const body = response && typeof response.json === "function" ? await response.json().catch(() => null) : null;
    return response && response.ok && body && body.ok === true && body.ledger && typeof body.ledger === "object" ? body.ledger : null;
  } catch {
    return null;
  }
}

/** `given` when the parent passed a ledger descriptor, else the one asked for. */
export function useCardLedger(given = null) {
  const writesEnabled = useWritesEnabled();
  const [fetched, setFetched] = useState(known);
  const need = !given && writesEnabled;
  useEffect(() => {
    if (!need) return undefined;
    if (known) {
      setFetched(known);
      return undefined;
    }
    let alive = true;
    ask().then((ledger) => {
      if (alive && ledger) setFetched(ledger);
    });
    return () => {
      alive = false;
    };
  }, [need]);
  return given || (need ? fetched : null) || null;
}

/** For tests: forget the page's answer. */
export function forgetCardLedger() {
  known = null;
  pending = null;
}
