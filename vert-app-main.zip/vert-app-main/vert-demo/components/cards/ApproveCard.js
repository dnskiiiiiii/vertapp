"use client";

// components/cards/ApproveCard.js — "APPROVE $9,350.73", WITH UNDO
// ==============================================================================
// Spec §5.3 rows 5, 7, 8 and 11; §3.7. Replaces ApprovalDetail and JournalEntry.
//
// THE THREE GATES STILL HOLD, AND THIS CARD IS THE SECOND. A blocked payout must never
// be approvable (tests/gates.test.js; V1-STATUS.md §2.8), and independence is the point:
//
//   1. The engine: approve_entries never proposes a blocked payout, and the route
//      re-runs the tie-outs at the moment of approval and answers 409.
//   2. This card: before drawing the commit it reads the payload for the payout's own
//      verdict (lib/payoutStatus.js — the recorded state wins, and the local verifier
//      may still add a block) and the session store's record. A blocked payout gets NO
//      approve control, and the reason is printed where it would have been (UI-014).
//   3. lib/store.js RECORD_APPROVAL stays a no-op once a payout is marked blocked.
//
// A payout in a state approval is not legal from (ingested, reconciled) is withheld the
// same way, with lib/feeds.js notYetApprovableReason's sentence — the regression
// tests/approve-affordance.test.js names.
//
// AFTER THE PRESS (spec §5.2, UI-009, UI-012, UI-024). The card collapses to
// "Approved $9,350.73 · you · 10:42" from the accepted result, and Undo sits in that
// line FOR AS LONG AS THE APPROVAL STANDS AND NOTHING HAS POSTED (W12): it withdraws the
// approval through `POST /approvals/{id}/withdraw` and reopens the card. It used to
// close after ten seconds, and the eval found Undo gone six seconds after the last
// approval in a group (the group unmounted; NeedsYouList now keeps it) — a timer is one
// more way for the one safe exit to disappear while the entry is still undoable.
//
// APPROVE AND POST (§4.0.5, eval JE5 2 Oct). With a ledger connected the draft's one
// commit is "Approve and post…": it opens the §3.7 sheet, whose confirm approves AND
// posts — two presses from draft to posted, where it was three. "Approve only" is a
// quiet secondary; after it the line offers Post, which opens the same sheet to post
// alone. With no ledger the commit is "Approve $X" and the line says the entry is
// ready to post once one is connected. Posted draws PostedPlate: the ledger's number,
// the narration, View in {ledger}, the read-back table and Reverse.
//
// THE LINES ARE ON THE FACE (eval r1, §17.3 flow 3). The entry this approves is drawn
// inline, in the same inset table the GL-rec journal card uses (`jcard-grid`), not one
// press down behind Details: a bookkeeper approves what they can see, and the reference
// shows the table on the card. Every figure is the engine's integer (`je.lines[].dr/cr`,
// `je.sumDr/sumCr`), drawn through Figure with its ref; nothing on it is computed here.
//
// WHERE: on a page that reads the engine payload — Month-end, which hands the card its
// ledger descriptor (`ledger`, possibly null) — not in a conversation. A conversation
// is a record of its events and renders only money they carried (tests/chat-replay,
// tests/no-general-ledger); the payload's journal is not in the approve event, so the
// chat keeps the lines in the post sheet until the engine carries them as a money
// table on that event. `lines` overrides the default either way.
//
// A PRESS WHOSE ANSWER NEVER CAME IS READ BACK FIRST (W0c, CO-17; eval r3 C5b / F5).
// "Approve only" timed out behind a 13-second catch-up and the card said "Nothing was
// recorded" — while the approval stood, and Undo turned up 6.5 s later under the false
// line. Now a press that failed in transit (the API never answered, or the browser never
// reached this server) says nothing until the payout is read back
// (lib/actions.js readBackApproval / the server's own read-back): RECORDED collapses
// the card to its Approved line, with Undo, from the record; NOT RECORDED is the old
// "Not sent. Nothing was recorded.", now read rather than assumed; and a read that also
// failed says "couldn't confirm yet", with Check again, never "nothing".
//
// REJECT IS QUIET (UI-003): a text button beside the commit, opening a sheet that says
// it can't be reopened and asks why.

import DutyGate from "./DutyGate.js";
import { useEffect, useState } from "react";
import { Button, Figure, FigureInText, Notice } from "@/components/ui";
import BoundText from "@/components/chat/BoundText";
import { approveDraftEntry, readBackApproval, withdrawApproval } from "@/lib/actions";
import { readPostedByGet } from "@/components/records/entry-read-client";
import { callSafely, useCardCommit } from "@/lib/decisions";
import { useEngine, useWritesEnabled } from "@/lib/engine-context";
import { notYetApprovableReason } from "@/lib/feeds";
import { canPost, holdsAsDraft } from "@/lib/ledger-shape";
import { unpostedLedgerNote } from "./ledger-note";
import { formatMoney } from "@/lib/format";
import { payoutStatus } from "@/lib/payoutStatus";
import { useApproval, useDuties, useRecordMonth, useSignedInActor } from "@/lib/store";
import { approveRefusal, drafterOf, gateSentence } from "@/lib/roles";
import { monthReadingOf } from "@/components/month/model";
import Card from "./Card";
import DecisionLine from "./DecisionLine";
import PostSheet, { journalFor } from "./PostSheet";
import { PAYOUT_ENTRY, postingEffectOf } from "./ledger-effect";
import PostedPlate from "./PostedPlate";
import { useCardLedger } from "./useCardLedger";
import RejectSheet from "./RejectSheet";
import { entryHeadLine, ledgerDisplayName, visibleLines } from "./journal-model";
import { GROSS_NET_WHY, approveActionLabel, boundLabel, canUndo, entryDiffersFromPayout, isRead, legAccount, postActionLabel, returnedNote, splitLedgerName, unmappedNote } from "./words";

import { IconCaretRight } from "@/components/ui/icons";
/**
 * The first check the verifier refused, in words ("2 deposits match this payout.").
 * Staging browser walk 5 (W5-1): the card said only "Vert's checks don't clear this
 * payout yet", and the bookkeeper couldn't tell which check, so couldn't act. A check
 * not named here is said by its own label. Pure.
 */
export function failedCheckWords(verdict) {
  const failed = verdict && Array.isArray(verdict.checks) ? verdict.checks.find((c) => c && !c.ok) : null;
  if (!failed) return "a check on this payout failed.";
  switch (failed.id) {
    case "deposit_ties_to_declared":
      if (failed.expected === 0) return "a deposit is in the bank for a payout still in transit.";
      if (!failed.actual) return "no bank deposit matches this payout.";
      return `${failed.actual} deposits match this payout.`;
    case "entry_balances":
      return "the entry doesn't balance.";
    case "txn_sum_ties_to_declared":
    case "agent_claim_matches_replay":
    case "clearing_line_supported_by_detail":
      return "the payout's detail doesn't add up to it.";
    case "revenue_recognised_ties_to_source":
      return "sales less fees don't come to the deposit.";
    default:
      return `${String(failed.label || "a check failed").replace(/\.$/, "").toLowerCase()}.`;
  }
}

/**
 * Why this payout can't be approved from here, or null when it can. Reads the payload
 * and the session store only; never computes a figure — the shortfall is the
 * verifier's own `shortfallCents`, formatted.
 */
export function approveBlockedReason(engine, payoutId, sessionApproval = null) {
  if (sessionApproval && sessionApproval.status === "blocked") {
    return "Can't approve: Vert's checks stopped this payout.";
  }
  const ps = payoutId ? payoutStatus(engine, payoutId) : null;
  if (!ps) return null;
  if (ps.verdict && ps.verdict.blocked) {
    const gap = ps.verdict.shortfallCents;
    return typeof gap === "number" && gap > 0
      ? `Can't approve until the ${formatMoney(gap)} gap is explained.`
      : `Can't approve: ${failedCheckWords(ps.verdict)}`;
  }
  if (ps.key === "blocked") return "Can't approve: Vert's checks stopped this payout.";
  // PAST APPROVAL ALREADY. The register's panel keyed on "approved" once offered to
  // approve an entry that was already POSTED — in somebody's trial balance — and
  // tests/claims.test.js guarded that on the panel. When G1 re-pointed the guard here
  // (2026-09-30) this card offered Approve on a posted payout too: notYetApprovableReason
  // leaves these three states to "their own branch", and the card had none. Each is
  // withheld with what is true of it.
  const recordedStatus = ps.recorded && ps.recorded.status;
  if (recordedStatus === "posted") return "Already posted to your ledger.";
  if (recordedStatus === "approved") return "Already approved.";
  if (recordedStatus === "rejected") return "Rejected, so it can't be approved.";
  return notYetApprovableReason(ps.recorded);
}

/**
 * The engine's drafted journal for this payout as the card's inline table, or null.
 *
 * THREE ROWS, THEN A FADE (build plan §19.3 W0d; eval iter2 polish, visual finding 5).
 * A four-leg Stripe entry plus its unmapped-account note filled a 1440×900 window and
 * pushed "Approve and post…" below the fold. The grid now draws what the GL-rec card
 * draws (journal-model.js visibleLines): the first three rows, the last of them faded,
 * and "Show all N lines" in place; the Total row is always drawn, so the figure being
 * approved is never one press down. The table and its note are ONE idea, "entry", in
 * the lexicon walk (`data-lexicon`): the account names are the entry's own lines.
 */
export function JournalLines({ je, payoutId }) {
  const [expanded, setExpanded] = useState(false);
  const ref = (k) => `reconciliations/${payoutId}/je/${k}`;
  if (!je) return null;
  const all = Array.isArray(je.lines) ? je.lines : [];
  const { shown, more, fades } = visibleLines(all, expanded);
  // The rows past the third stay in the card, `hidden` until "Show all N lines": the
  // engine's whole entry is on the card it approves, one press down, never in a sheet.
  const folded = shown.length < all.length;
  // THE DESCRIPTION COLUMN (answer shape, 17 Oct 2026): each line's source, when the
  // engine's lines carry one; an entry whose lines carry none keeps three columns.
  const described = all.some((l) => typeof l.description === "string" && l.description);
  return (
    <div className="jcard-grid-wrap" data-approve-lines="" data-fades={fades ? "true" : undefined} data-lexicon="entry">
      <table className="jcard-grid">
        <thead>
          <tr>
            <th scope="col">Account</th>
            <th scope="col" className="num">Debit</th>
            <th scope="col" className="num">Credit</th>
            {described ? <th scope="col" className="jcard-desc-col">Description</th> : null}
          </tr>
        </thead>
        <tbody>
          {all.map((l, i) => (
            <tr
              key={`${l.account}-${i}`}
              hidden={folded && i >= shown.length ? true : undefined}
              data-fade={fades && i === shown.length - 1 ? "" : undefined}
            >
              {/* The journal card's account cell: one line, cut with its whole name on hover,
                  never broken mid-word beside a Description column. */}
              <td className="jcard-account" translate="no">
                <span className="jcard-account-name" title={legAccount(l)}>{legAccount(l)}</span>
              </td>
              {/* An empty side is a quiet "–" (the answer shape), marked so a phone's stacked line drops it. */}
              {l.dr ? <td className="num jcard-debit"><Figure cents={l.dr} figure={ref(`lines/${i}/dr`)} /></td> : <td className="num jcard-debit" data-side-empty=""><span aria-label="none">&ndash;</span></td>}
              {l.cr ? <td className="num jcard-credit"><Figure cents={l.cr} figure={ref(`lines/${i}/cr`)} /></td> : <td className="num jcard-credit" data-side-empty=""><span aria-label="none">&ndash;</span></td>}
              {described ? (
                <td className="jcard-desc-col" data-je-desc="">
                  {l.description ? <span className="jcard-desc" title={l.description}>{l.description}</span> : null}
                </td>
              ) : null}
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr>
            <th scope="row">Total</th>
            <td className="num"><Figure cents={je.sumDr} figure={ref("sumDr")} /></td>
            <td className="num"><Figure cents={je.sumCr} figure={ref("sumCr")} /></td>
            {described ? <td className="jcard-desc-col" /> : null}
          </tr>
        </tfoot>
      </table>
      {more ? (
        <button type="button" className="link jcard-more t-footnote" onClick={() => setExpanded(true)}>
          {more}
        </button>
      ) : null}
      {unmappedNote(je) ? <p className="t-body" data-unmapped-note="">{unmappedNote(je)}</p> : null}
      {returnedNote(je) ? <p className="t-body" data-returned-note="">{returnedNote(je)}</p> : null}
    </div>
  );
}

/* ── the read-back after a press that failed in transit (CO-17) ─────────────────── */

/**
 * The journal an approve card's own event carries (`action.je`, the engine's
 * JournalEntry: lines in cents with `{account: {number, name}}`), in the shape the
 * card's table draws (`{account, dr, cr}`, `sumDr`, `sumCr`), or null. Read, never
 * summed: the totals are the event's. Pure.
 */
export function eventJournal(action) {
  const je = action && action.je && typeof action.je === "object" ? action.je : null;
  if (!je || !Array.isArray(je.lines) || !je.lines.length || !je.totals) return null;
  const { debitCents, creditCents } = je.totals;
  if (!Number.isInteger(debitCents) || !Number.isInteger(creditCents)) return null;
  const lines = je.lines.map((l) => {
    const a = l && l.account && typeof l.account === "object" ? l.account : {};
    const account = [a.number, a.name].filter((x) => typeof x === "string" && x.trim()).join(" · ") || (typeof l.account === "string" ? l.account : "An account Vert couldn't name");
    const description = typeof l.description === "string" && l.description.trim() ? l.description.trim() : null;
    return { account, dr: Number.isInteger(l.debitCents) ? l.debitCents : 0, cr: Number.isInteger(l.creditCents) ? l.creditCents : 0, ...(description ? { description } : {}) };
  });
  const date = typeof je.date === "string" && je.date ? je.date : null;
  return { lines, sumDr: debitCents, sumCr: creditCents, ...(date ? { date } : {}), ...(Array.isArray(je.unmapped) ? { unmapped: je.unmapped, unmappedNote: je.unmappedNote || null } : {}), ...(returnedNote(je) ? { returnedNote: returnedNote(je) } : {}) };
}

/**
 * The journal entry a payout `approve` action names, from its bound figure
 * (`figures.entry.source = {kind: "entry", id: "je:…"}`), or null. Pure.
 */
export function entryIdOf(action) {
  const src = action && action.figures && action.figures.entry && action.figures.entry.source;
  if (src && src.kind === "entry" && typeof src.id === "string" && /^je:[0-9a-f]+$/i.test(src.id)) return src.id;
  const t = action && action.prefill && action.prefill.entryId;
  return typeof t === "string" && /^je:[0-9a-f]+$/i.test(t) ? t : null;
}

/** The entry's lines read back from the API, in eventJournal's shape, or null until read. */
function useEntryLines(entryId) {
  const [read, setRead] = useState(null);
  useEffect(() => {
    if (!entryId) return undefined;
    let live = true;
    // A GET (staging D4 retest), never the readPostedEntry Server Action on mount.
    readPostedByGet(entryId).then((reading) => {
      if (live && reading && reading.je) setRead(eventJournal({ je: reading.je }));
    });
    return () => {
      live = false;
    };
  }, [entryId]);
  return entryId ? read : null;
}

/** The payout commit's reason when a leg is off the chart: the note under the lines
 *  names the account, so the commit only says what to do (D02). */
export const UNMAPPED_COMMIT_REASON = "Map the account above to the client's chart first.";

export const READ_BACK_READING = "No answer yet. Checking whether the approval was recorded…";
export const READ_BACK_RECORDED = "Recorded. The answer was slow, so Vert read the approval back.";
export const READ_BACK_UNCONFIRMED = "No answer, and Vert couldn't read the approval back.";

const IN_TRANSIT = new Set(["network", "unreachable"]);

function readBackOf(settled) {
  const s = settled && typeof settled === "object" ? settled : {};
  return Boolean(s.readBack || (s.result && s.result.readBack && s.result.readBack.recorded === "recorded"));
}

/**
 * What a card whose press failed shows, from the press's result and any read-back:
 *
 *   { state: "idle" }            no failed press
 *   { state: "failed" }          refused by the API (a 409, a 403): its own words, as before
 *   { state: "reading" }         failed in transit, not read back yet: say nothing yet
 *   { state: "recorded", approved }  the record holds the approval: the Approved line, with Undo
 *   { state: "not_recorded" }    the record does not: "Not sent. Nothing was recorded."
 *   { state: "unconfirmed" }     the read failed too: "couldn't confirm yet", Check again
 *
 * Pure. `local` is the read-back this card made itself (a press that never reached the
 * server); the server's own rides on the result.
 */
export function pressReadBack(phase, result, local = null) {
  if (phase !== "failed" || !result) return { state: "idle" };
  if (!IN_TRANSIT.has(result.kind)) return { state: "failed" };
  const rb = (result.readBack && typeof result.readBack === "object" && result.readBack) || (local && typeof local === "object" && local) || null;
  if (!rb) return { state: "reading" };
  if (rb.recorded === "recorded") {
    return {
      state: "recorded",
      approved: { outcome: "approved", by: rb.by || null, at: rb.at || new Date().toISOString(), verified: true, result, readBack: true },
    };
  }
  if (rb.recorded === "not_recorded") return { state: "not_recorded" };
  return { state: "unconfirmed" };
}

export default function ApproveCard({ action, onSettled, onReopened = null, ledgerName = null, ledger: givenLedger, clientName = null, initial = null, lines = undefined, quiet = false, refusal = null }) {
  // `quiet`: one of several entry cards on screen at once (the answer shape's numbered
  // cards) that is not the current one draws its commit as a secondary, still pressable:
  // a view holds one accent (PR8), the way a run of paged journal cards does.
  const commitVariant = quiet ? "secondary" : "commit";
  const engine = useEngine();
  // The page's descriptor where it gave one; in the conversation the card asks itself
  // (eval JE5: an approval made in the chat offered no Post at all).
  const ledger = useCardLedger(givenLedger || null);
  const prefill = (action && action.prefill) || {};
  const payoutId = prefill.payoutId || (action.target && action.target.id) || null;
  const sessionApproval = useApproval(payoutId);
  const blocked = approveBlockedReason(engine, payoutId, sessionApproval);
  // WHO MAY PRESS IT (§20.12 H3, M4): said beside the commit, before the press. Null
  // when the engine reported no role, and then the engine alone decides.
  // `refusal`: the read's own word for this viewer (the answer shape's `mayApprove: false`).
  const roleRefusal = approveRefusal(useDuties(), { drafter: drafterOf(action) || drafterOf(prefill), actor: useSignedInActor() });
  const dutyReason = gateSentence(refusal) || roleRefusal;
  const entry = action.figures && action.figures.entry;
  const amount = isRead(entry) ? formatMoney(entry.cents) : null;
  const label = boundLabel(action.commitLabel, action.figures, ledgerName) || (amount ? `Approve ${amount}` : null);
  // The label's amount is bound (rubric C1): the engine's own label with its figure, as
  // text inside the button (`plain`: no sheet inside a control), else the fallback with
  // the entry's cents found in it.
  const labelNode = !label
    ? null
    : boundLabel(action.commitLabel, action.figures, ledgerName)
      ? <BoundText text={action.commitLabel} figures={action.figures} ledgerName={ledgerName} plain />
      : <FigureInText text={label} cents={entry && entry.cents} figure={`journal_entry/${payoutId}/sumDr`} />;
  const status = payoutId ? payoutStatus(engine, payoutId) : null;
  // The entry's lines: on a page, the payload's journal; in a conversation, which renders
  // only money its events carried, the lines the card's own event carries (`action.je`,
  // D01/D02 F19: without them the card was a sentence and ids, and the lines appeared
  // only in the post sheet).
  const onPage = lines !== undefined ? lines : givenLedger !== undefined;
  // D01 (verify pass 1): the engine's payout `approve` event carries no `je`, so in a
  // conversation the card was a sentence and two ids. The entry it approves is named
  // (`figures.entry.source`, kind "entry"); its lines are read from GET /journal/{id}.
  const readJe = useEntryLines(onPage || eventJournal(action) ? null : entryIdOf(action));
  const je = onPage ? journalFor(engine, payoutId) : eventJournal(action) || readJe;
  const gap = status && status.verdict ? status.verdict.shortfallCents : null;
  const liveWrites = useWritesEnabled();
  // LEGS OFF THE CHART (D02/D01; recs-jes finding 7). An entry whose accounts the
  // client's chart doesn't hold can't be posted, and approving it only to be refused at
  // Post said nothing until then. The commit is drawn dead with the engine's note.
  // The note itself is drawn under the lines; the commit says where to look. The sample
  // build already draws its commit dead with its own reason.
  const unmappedReason = liveWrites && (unmappedNote(je) || unmappedNote(action.je)) ? UNMAPPED_COMMIT_REASON : null;
  const commitBlock = dutyReason || unmappedReason;

  // Net and gross, said once (N10): the payout line above is what reached the bank; the
  // entry this approves is the sales before fees. Only when the two figures differ.
  const why = entryDiffersFromPayout(entry, action.line) ? GROSS_NET_WHY : undefined;

  const card = useCardCommit(action, { onSettled, initial });
  const recordMonth = useRecordMonth();
  const [rejecting, setRejecting] = useState(false);
  // The sheets are mounted on first open and kept after (for their exit), never before:
  // a closed sheet per card put a hidden "Reject" button beside every entry on the page,
  // and a person — or a check — reaching for Reject could land on one (e2e r3 D3).
  const [rejectMounted, setRejectMounted] = useState(false);
  const [postMounted, setPostMounted] = useState(false);
  const openReject = () => {
    setRejectMounted(true);
    setRejecting(true);
  };
  const [rejected, setRejected] = useState(null);
  const [posting, setPosting] = useState(false);
  const [posted, setPosted] = useState(null);
  // The sheet was opened by "Approve and post…" on the draft (its confirm approves too).
  const [approvingSheet, setApprovingSheet] = useState(false);
  // An approve-and-post whose approval landed and whose post did not: the card reads
  // Approved, with Post (a plain post) and Undo, exactly as after "Approve only".
  const [approvedOnly, setApprovedOnly] = useState(null);
  const [undo, setUndo] = useState({ busy: false, failed: null });
  // The read-back after a press that failed in transit (see header). The server's own
  // read-back rides on the result; a press that never reached the server is read here.
  const [check, setCheck] = useState({ phase: "idle", readBack: null });
  const view = pressReadBack(card.phase, card.result, check.readBack);
  // While the record is being read, or couldn't be, a second press could sign twice
  // over an approval that may stand: Check again is the one press.
  const held = view.state === "reading" || view.state === "unconfirmed";

  async function checkAgain() {
    setCheck({ phase: "reading", readBack: null });
    const answer = await callSafely(readBackApproval, payoutId);
    setCheck({ phase: "done", readBack: answer.ok && answer.readBack ? answer.readBack : { recorded: "unconfirmed" } });
  }
  useEffect(() => {
    if (view.state === "reading" && check.phase === "idle") checkAgain();
    else if (card.phase !== "failed" && check.phase !== "idle") setCheck({ phase: "idle", readBack: null });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [view.state, card.phase]);

  async function withdraw() {
    setUndo({ busy: true, failed: null });
    const result = await callSafely(withdrawApproval, payoutId);
    if (!result.ok) {
      setUndo({ busy: false, failed: result });
      return;
    }
    setUndo({ busy: false, failed: null });
    // The withdraw answers with the month as the API now counts it (vert_api approvals
    // withdraw → month_counts): the count goes back up from that one reading, with the
    // header, the rows and the badge together (e2e r3 D1). No router.refresh(): the
    // action revalidated on the server.
    const reading = monthReadingOf(result);
    if (reading) recordMonth(reading);
    setApprovedOnly(null);
    setCheck({ phase: "idle", readBack: null });
    card.reopen();
    if (onReopened) onReopened();
  }

  // §4.0.5: with a ledger connected the draft's one commit is "Approve and post…".
  const postableNow = canPost(ledger) && Boolean(ledgerName || (ledger && ledger.displayName));
  if (rejected) return <DecisionLine kind="reject" settled={rejected.settled} outcome="rejected" />;
  if (posted) return <PostedPlate settled={posted.settled} amount={amount} ledgerName={ledgerName || (ledger && ledger.displayName) || null} />;
  const approvedState = card.phase === "done" ? card.settled : approvedOnly || view.approved;
  if (approvedState) {
    const approved = approvedState.outcome === "approved";
    const postable = approved && canPost(ledger);
    return (
      <>
        <DecisionLine
          kind="approve"
          settled={approvedState}
          amount={approved ? amount : null}
          outcome={approvedState.outcome}
          note={
            undo.failed
              ? "Undo wasn't sent. The approval stands."
              : approved && readBackOf(approvedState)
                ? READ_BACK_RECORDED
                : approved && !canPost(ledger)
                  ? unpostedLedgerNote(ledger)
                  : null
          }
        >
          {approved && canUndo(action, approvedState) ? (
            <Button variant="quiet" size="sm" onClick={withdraw} busy={undo.busy} busyLabel="Undoing…">
              Undo
            </Button>
          ) : null}
          {postable && dutyReason ? (
            <DutyGate reason={dutyReason} />
          ) : postable ? (
            <Button
              variant="secondary"
              size="sm"
              disabledReason={commitBlock || undefined}
              onClick={() => {
                setApprovingSheet(false);
                setPostMounted(true);
                setPosting(true);
              }}
            >
              {/* Worded by createsDraft, never by the vendor (17 Oct 2026). */}
              {`${postActionLabel(ledgerDisplayName(ledger, ledgerName), { draft: holdsAsDraft(ledger) && !splitLedgerName(ledgerDisplayName(ledger, ledgerName)).recording })}…`}
            </Button>
          ) : approved ? (
            <a className="link t-footnote" href="/connections">
              Connect<IconCaretRight className="caret-trailing" />
            </a>
          ) : null}
        </DecisionLine>
        {postable && postMounted ? (
          <PostSheet
            open={posting}
            onClose={() => setPosting(false)}
            action={action}
            ledger={ledger}
            clientName={clientName}
            lines={je}
            initial={approvedOnly && card.phase !== "done" ? { phase: "failed", result: approvedOnly.result, settled: null } : null}
            onPosted={(done) => {
              setPosting(false);
              setPosted(done);
            }}
          />
        ) : null}
      </>
    );
  }

  return (
    <>
      <Card
        action={action}
        kind="approve"
        ledgerName={ledgerName}
        failure={view.state === "not_recorded" || view.state === "failed" ? card.result : null}
        onRetry={(view.state === "not_recorded" || view.state === "failed") && card.writesEnabled ? card.retry : undefined}
        form={
          je ? (
            <>
              {/* "Draft · 31 Jul 2026, July 2026 period, No. automatic" (verify pass 5,
                  Q-SHAPE-4; pass 8, Q02 F-12): the first line of every entry card, the
                  payout's too; the date is the payout's arrival. */}
              <p className="jcard-status t-footnote" data-entry-status="">
                {entryHeadLine("draft", { period: action.je && action.je.period, ...je }, { date: je.date || (action.je && action.je.date) || prefill.date || null })}
              </p>
              <JournalLines je={je} payoutId={payoutId} />
            </>
          ) : null
        }
        why={blocked ? <FigureInText text={blocked} cents={gap} figure={`payouts/${payoutId}/shortfall`} /> : why}
        actions={
          blocked ? null : held ? null : (
            <>
              {label && dutyReason ? (
                <DutyGate reason={dutyReason} />
              ) : label && postableNow ? (
                <>
                  {/* The same approval as the commit: withheld with it, never a side door. */}
                  {commitBlock ? null : (
                    <Button
                      variant="quiet"
                      onClick={() => card.commit(approveDraftEntry, payoutId, { outcome: "approved" })}
                      busy={card.busy}
                      busyLabel="Approving…"
                      disabled={!card.writesEnabled || card.blocked || undefined}
                      data-approve-only=""
                    >
                      Approve only
                    </Button>
                  )}
                  {/* WHAT THE PRESS DOES IN THE LEDGER, BESIDE IT (answer shape, 17 Oct 2026). */}
                  {!commitBlock && postingEffectOf(ledger, ledgerName, PAYOUT_ENTRY) ? (
                    <p className="jcard-effect t-footnote" data-ledger-effect="">
                      {postingEffectOf(ledger, ledgerName, PAYOUT_ENTRY)}
                    </p>
                  ) : null}
                  <Button
                    variant={commitVariant}
                    onClick={() => {
                      setApprovingSheet(true);
                      setPostMounted(true);
                      setPosting(true);
                    }}
                    disabled={card.blocked || undefined}
                    disabledReason={commitBlock || card.disabledReason}
                    data-approve-and-post=""
                  >
                    {/* Names the ledger, worded by createsDraft (answer shape, 17 Oct 2026). */}
                    {/* The ledger's own name first (ledgerDisplayName, the journal card's one
                        rule): the page's name beside a Xero descriptor read "send to
                        QuickBooks as draft" over Xero's own posting effect. */}
                    {`${approveActionLabel(ledgerDisplayName(ledger, ledgerName), { draft: holdsAsDraft(ledger) })}…`}
                  </Button>
                </>
              ) : label ? (
                <Button
                  variant={commitVariant}
                  onClick={() => card.commit(approveDraftEntry, payoutId, { outcome: "approved" })}
                  busy={card.busy}
                  busyLabel="Approving…"
                  disabledReason={commitBlock || card.disabledReason}
                  disabled={card.blocked || undefined}
                >
                  {labelNode}
                </Button>
              ) : (
                <p className="dcard-reason t-footnote">The entry's amount hasn't been read yet, so it can't be approved.</p>
              )}
              <Button variant="quiet" onClick={openReject} disabled={!card.writesEnabled}>
                Reject
              </Button>
            </>
          )
        }
      />
      {view.state === "reading" ? <Notice kind="status">{READ_BACK_READING}</Notice> : null}
      {view.state === "unconfirmed" ? (
        <Notice
          kind="error"
          recorded="unconfirmed"
          action={
            <Button variant="secondary" size="sm" onClick={checkAgain}>
              Check again
            </Button>
          }
        >
          {READ_BACK_UNCONFIRMED}
        </Notice>
      ) : null}
      {!blocked && postableNow && postMounted && approvingSheet ? (
        <PostSheet
          open={posting}
          onClose={() => setPosting(false)}
          action={action}
          ledger={ledger}
          clientName={clientName}
          lines={je}
          approving
          onApproved={(result) => {
            // The approval stands though the post failed; the sheet stays open with
            // its retry (a plain post), and the card behind it now reads Approved.
            setApprovedOnly({ outcome: "approved", by: null, at: new Date().toISOString(), verified: false, result });
          }}
          onPosted={(done) => {
            setPosting(false);
            setPosted(done);
            if (onSettled) onSettled(done);
          }}
        />
      ) : null}
      {blocked || !rejectMounted ? null : (
        <RejectSheet
          open={rejecting}
          onClose={() => setRejecting(false)}
          action={action}
          onRejected={(done) => {
            setRejecting(false);
            setRejected(done);
          }}
        />
      )}
    </>
  );
}
