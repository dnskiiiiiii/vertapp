"use client";

// components/cards/ChooseDepositQuestion.js — "TWO DEPOSITS OF $7,000.00. WHICH ONE?"
// ==============================================================================
// Spec §5.3 and copy principle §13.5: "If Vert suggests something, give one reason. If
// it can't choose, ask, and suggest nothing."
//
// WHEN TWO DEPOSITS GENUINELY TIE and no stored proposal separates them, resolve_breaks
// does not decide: it asks, with every candidate the engine offered as an option. This
// renders that question. Where the engine offers a guess (option 1, marked `bestGuess`)
// the card says so and starts on it; where it offers none, nothing is marked or chosen —
// a card that said "these match equally well" and then picked one would contradict
// itself.
//
// ANSWERING TOUCHES NO BOOKS, BUT IT IS STILL THE CARD'S ONE DECISION. The answer goes to
// the conversation (`answerQuestion`) and is recorded there in your voice; the task
// resumes, and it comes back as a Use-this-deposit card pre-filled with YOUR choice and
// unmarked. It was drawn as a secondary button on the reading that the accent means
// "this changes the books" — and the eval (30 Sep, S5) found July's Month-end with a
// decision open and no commit anywhere on the page, the one screen where the person
// most needed to see what to press. So "Use this one" is the card's single commit
// (spec §5.1: one commit per card, §15: one filled button per view): it records the
// answer, which is a write to the month's record if not to the ledger.
//
// ONE PRESS RECORDS THE CHOICE AND USES THE DEPOSIT (e2e r3 D2). Answering alone left the
// month where it was: the task resumed and put up a SECOND card for the same deposit
// ("Use the 2 Jul deposit?") that asked how you knew, and the count sat at 4 while the
// person believed they had decided. A deposit question now asks "How do you know?" with
// the choice — the same grounds a pin needs (lib/assertions.js BANK_PIN_GROUNDS) — and
// "Use this one" answers the question AND records the pin through the existing route
// (lib/actions.js answerAndUseDeposit), settling the card the task put up, so the count
// moves from the API's own reading. A question that is not about a deposit (a bank rec
// choice) still just answers.
//
// ONE PRESS FOR THE BEST GUESS, IN THE CHAT'S ANATOMY (eval r1 §17.3 flow 2, S5). The
// card drew radios with nothing chosen, then a required "How do you know?" select, then
// "Use this one": three or four presses, and Month-end showed no enabled commit above the
// fold. The same question in the chat drew numbered rows with option 1 marked "Best
// guess": two styles for one decision. It now draws the chat's rows (the same
// `chat-option` anatomy, numbered, "Best guess" on option 1), with option 1 preselected
// WHEN the engine marked it as its guess (iteration 2's resolve_breaks does, nearest the
// payout's date, with the deposits as evidence). The commit is then enabled and purple,
// and one press uses the guess. Preselecting is not deciding: nothing is pinned until the
// person presses, which is the engine's own rule for the guess (§4.0.10).
//
// THE GROUND DEFAULTS TO THE EVIDENCE VERT CITED, AND IT STAYS EDITABLE. A pin still needs
// one of the three grounds (lib/assertions.js BANK_PIN_GROUNDS), but asking for it on the
// face was the extra press. The question's evidence is the statement lines' date and
// amount, so the default is "Amount and date confirmed" (or the question's own `ground`
// when the engine names one); it is said in one line and changed under Details. A
// question with no guess and no evidence (an iteration-1 tie) preselects nothing and
// still asks how you know on the face: a default there would be a ground nobody cited.
//
// NOTHING CHOSEN, NOTHING SENT, AND IT SAYS WHY. Until a deposit is chosen the commit is
// `aria-disabled` with its reason printed beside it ("Choose a deposit first."), never a
// press that silently does nothing (UI-014).

import { useId, useRef, useState } from "react";
import { Button, Disclosure, NoticeLine } from "@/components/ui";
import OptionRows, { DecisionFoot, OptionRow, useDeferredSkip } from "./OptionRows";
import OpenInChat from "./OpenInChat";
import { NOT_SENT_AGAIN, SKIP_REFUSED } from "@/components/chat/Clarification";
import Evidence from "@/components/chat/questions/Evidence";
import { evidenceOf } from "@/components/chat/questions/model";
import BoundText from "@/components/chat/BoundText";
import { answerQuestion } from "@/lib/agent/actions";
import { answerAndUseDeposit } from "@/lib/actions";
import { BANK_PIN_GROUNDS, isKnownPinGround } from "@/lib/assertions";
import { callSafely } from "@/lib/decisions";
import { SAMPLE_REASON } from "./words";
import { useWritesEnabled } from "@/lib/engine-context";
import { useRecordMonth, useSignedInActor } from "@/lib/store";
import { monthReadingOf } from "@/components/month/model";
import { useRouter } from "next/navigation";
import { PIN_GROUND_MESSAGE } from "./UseDepositCard";
import { withoutRawIds } from "@/lib/raw-ids";

export const CHOOSE_FIRST = "Choose a deposit first.";
export const GROUND_FIRST = "Say how you know under Details.";
/** The reason beside the commit while the ground, asked on the face, is still empty. */
export const GROUND_ON_FACE = "Say how you know first.";

/**
 * Why "Use this one" can't be pressed yet, or null when it can. `groundMissing` is set
 * only where the ground sits under Details: a reason printed beside the commit is the
 * only way a person learns the folded field was cleared.
 */
export function answerDisabledReason({ writesEnabled, choice, groundMissing = false }) {
  if (!writesEnabled) return SAMPLE_REASON;
  if (choice == null || choice === "") return CHOOSE_FIRST;
  // `groundMissing: "face"` — a ground asked on the face and not yet given (eval r2
  // §17.3 flow 2): the commit is disabled with the reason beside it, never live and
  // then refused after the press. Any other truthy value: cleared under Details.
  if (groundMissing === "face") return GROUND_ON_FACE;
  if (groundMissing) return GROUND_FIRST;
  return null;
}

/** A deposit question (resolve_breaks asks it as `deposit:{payout}`): its answer is a pin. */
export function isDepositQuestion(question) {
  return Boolean(question && typeof question.questionId === "string" && question.questionId.startsWith("deposit:"));
}

/** Option 1 when the engine marked it as its guess; otherwise nothing is chosen. */
export function initialChoice(question) {
  const options = Array.isArray(question && question.options) ? question.options : [];
  return options.length && options[0] && options[0].bestGuess === true ? options[0].id : null;
}

/**
 * The ground a deposit question starts on: the question's own `ground` when it names one
 * of the three, else "Amount and date confirmed" when Vert's guess rests on evidence that
 * shows the deposits' date and amount. Empty otherwise, so the person is asked.
 */
export function defaultGround(question) {
  const q = question || {};
  if (isKnownPinGround(q.ground)) return q.ground;
  if (!initialChoice(q)) return "";
  const evidence = evidenceOf(q);
  const keys = new Set(evidence && evidence.table ? evidence.table.columns.map((c) => c.kind || c.key) : []);
  return keys.has("date") && keys.has("money") ? "amount_and_date_confirmed" : "";
}

/** The ground's own words, for the one line that says what the pin will rest on. */
export function groundLabel(value) {
  const g = BANK_PIN_GROUNDS.find((x) => x.value === value);
  return g ? g.label : null;
}

/** The engine's words for an answer it refused because the question moved on (a 409,
 *  `state_conflict`), or null for any other failure. Pure. */
export function conflictWords(failure) {
  const f = failure && typeof failure === "object" ? failure : null;
  if (!f || !(f.status === 409 || f.code === "state_conflict")) return null;
  return typeof f.message === "string" && f.message.trim() ? f.message.trim() : null;
}

export default function ChooseDepositQuestion({ question, sessionId, ledgerName = null, onSettled = null }) {
  const q = question || {};
  const router = useRouter();
  const writesEnabled = useWritesEnabled();
  const recordMonth = useRecordMonth();
  const signedIn = useSignedInActor();
  const deposit = isDepositQuestion(q);
  // The engine's words without its raw ids (walk 4, W4-9: "bank line xero:984f…:…").
  const unraw = (text) => withoutRawIds(text, { ledgerName });
  const options = Array.isArray(q.options) ? q.options : [];
  const [choice, setChoice] = useState(() => initialChoice(q));
  const [basis, setBasis] = useState(() => (deposit ? defaultGround(q) : ""));
  // Whether the ground was defaulted at the start: then it is said in a line and edited
  // under Details; otherwise it is asked on the face, as before.
  const [groundDefaulted] = useState(() => deposit && isKnownPinGround(defaultGround(q)));
  const listRef = useRef(null);
  const cardRef = useRef(null);
  const titleRef = useRef(null);
  // "Open in chat" is drawn on Home only (spec §7.2; OpenInChat.js): in the thread it
  // would point at the page it is on.
  const [failures, setFailures] = useState(0);
  const evidenceId = useId();
  const [basisError, setBasisError] = useState(null);
  const [state, setState] = useState({ phase: "idle", answer: null, pinned: false, failure: null });

  async function send(answer) {
    setState({ phase: "busy", answer, pinned: false, failure: null });
    const useIt = deposit && !answer.skip;
    const picked = options.find((o) => o.id === answer.optionId);
    const result = useIt
      ? await callSafely(answerAndUseDeposit, {
          sessionId,
          questionId: q.questionId,
          optionId: answer.optionId,
          basis: answer.basis,
          note: `Chose ${picked ? picked.label.replace(/^The /, "the ") : "this deposit"}.`,
        })
      : await callSafely(answerQuestion, sessionId, { questionId: q.questionId, ...answer });
    if (!result.ok) setFailures((n) => n + 1);
    if (!result.ok) {
      // A pin refused AFTER the answer landed: the choice is on the record, the pin card
      // the task put up stays to press, and the sentence says which half happened.
      setState({ phase: result.answered ? "answered" : "failed", answer, pinned: false, failure: result });
      if (result.answered) router.refresh();
      return;
    }
    const reading = monthReadingOf(result);
    if (reading) recordMonth(reading);
    setState({ phase: "done", answer, pinned: Boolean(result.pinned), failure: null });
    if (onSettled) {
      onSettled({
        action: null,
        result,
        settled: { outcome: result.pinned ? "applied" : "answered", by: signedIn || null, at: new Date().toISOString(), verified: Boolean(result.settle && result.settle.verified) },
        reading,
      });
    }
    // With a reading the page was revalidated in the same response; without one (the
    // answer went to a task that resumes later) ask for the re-read.
    if (!reading) router.refresh();
  }

  // Skip is held five seconds behind "Skipped. Undo", then sent (spec §7.2, D10).
  const deferred = useDeferredSkip(() => send({ skip: true }));

  function press() {
    if (!choice) return;
    if (deposit && !isKnownPinGround(basis)) {
      setBasisError(PIN_GROUND_MESSAGE);
      return;
    }
    send(deposit ? { optionId: choice, basis } : { optionId: choice });
  }

  if (deferred.pending) {
    return (
      <div className="dcard-done" role="status" aria-live="polite" data-card-done="" data-card="question" data-outcome="skipped" data-skip-pending="">
        <p className="dcard-done-text t-body">Skipped for now</p>
        {deferred.toast}
      </div>
    );
  }

  if (state.phase === "done" || state.phase === "answered") {
    const picked = options.find((o) => o.id === state.answer.optionId);
    const name = picked ? picked.label : "your choice";
    const text = state.answer.skip
      ? "Skipped for now"
      : state.pinned
        ? `Used ${name.replace(/^The /, "the ")} · you`
        : `Answered: ${name}`;
    return (
      <div className="dcard-done" role="status" aria-live="polite" data-card-done="" data-card="question">
        <p className="dcard-done-text t-body">{text}</p>
        {state.phase === "answered" ? (
          <p className="dcard-done-note t-footnote">The deposit wasn't used yet. Its card is below to finish.</p>
        ) : null}
      </div>
    );
  }

  // Arrow keys move the choice, a digit picks that row, Enter uses the chosen one: the
  // keys the chat's question answers to, so the one decision behaves the same in both.
  const groundMissing = !deposit || isKnownPinGround(basis) ? false : groundDefaulted ? true : choice ? "face" : false;
  const reason = answerDisabledReason({ writesEnabled, choice, groundMissing });
  function onKeyDown(event) {
    if (!options.length) return;
    const at = Math.max(0, options.findIndex((o) => o.id === choice));
    let next = null;
    if (event.key === "ArrowDown") next = (at + 1) % options.length;
    else if (event.key === "ArrowUp") next = (at + options.length - 1) % options.length;
    else if (/^[1-9]$/.test(event.key) && Number(event.key) <= options.length) next = Number(event.key) - 1;
    else if (event.key === "Escape") {
      // Esc lets go of the options; it never skips (founder decision D10). Focus rests on
      // the card's title, never on <body> (critic r1 F8).
      event.preventDefault();
      if (titleRef.current) titleRef.current.focus();
      return;
    } else if (event.key === "Enter" && choice) {
      event.preventDefault();
      if (!answerDisabledReason({ writesEnabled, choice, groundMissing }) && state.phase !== "busy") press();
      return;
    }
    if (next == null) return;
    event.preventDefault();
    setChoice(options[next].id);
    const rows = listRef.current ? listRef.current.querySelectorAll("[data-option]") : [];
    if (rows[next]) rows[next].focus();
  }

  // The ground is asked in the same numbered rows as the deposit (eval r2 §17.4 found a
  // required select here that the chat never draws). A press on a row chooses; only "Use
  // this one" sends. No row starts chosen unless the ground was defaulted above.
  const groundSelect = (
    <div className="dcard-ground-rows" data-ground-rows="">
      <p className="dcard-choices-label t-footnote" id={`${evidenceId}-ground`}>How do you know?</p>
      <OptionRows
        label="How do you know?"
        name="ground"
        options={BANK_PIN_GROUNDS.map((g) => ({ value: g.value, label: g.label }))}
        value={basis || null}
        onChange={(v) => {
          setBasis(v);
          setBasisError(null);
        }}
      />
      {basisError ? <p className="dcard-reason t-footnote" role="alert">{basisError}</p> : null}
    </div>
  );
  const said = groundLabel(basis);

  return (
    <article className="dcard dcard-question" data-card="question" ref={cardRef} onKeyDown={(event) => { if (event.key === "Escape" && titleRef.current && cardRef.current && cardRef.current.contains(document.activeElement)) { event.preventDefault(); titleRef.current.focus(); } }}>
      <div className="dcard-head">
        <p className="dcard-proposal t-callout" ref={titleRef} tabIndex={-1}>
          <BoundText text={unraw(q.title)} figures={q.figures} ledgerName={ledgerName} />
        </p>
        {!q.allowSkip ? <p className="dcard-needs" data-needs-answer="">{SKIP_REFUSED}</p> : null}
        {q.why ? <p className="dcard-why t-footnote">{unraw(q.why)}</p> : null}
      </div>
      <Evidence item={q} id={evidenceId} ledgerName={ledgerName} />
      <div className="dcard-form">
        <ol
          className="chat-options dcard-choices"
          ref={listRef}
          role="radiogroup"
          aria-label="Choose one"
          onKeyDown={onKeyDown}
        >
          {options.map((o, i) => (
            <li key={o.id} role="none">
              <OptionRow
                n={i + 1}
                value={o.id}
                label={<BoundText text={unraw(o.label)} figures={q.figures} ledgerName={ledgerName} plain />}
                detail={o.detail ? <BoundText text={unraw(o.detail)} figures={q.figures} ledgerName={ledgerName} plain /> : null}
                guess={o.bestGuess === true && i === 0}
                chosen={choice === o.id}
                tabIndex={choice === o.id || (!choice && i === 0) ? 0 : -1}
                onSelect={() => setChoice(o.id)}
              />
            </li>
          ))}
        </ol>
        {deposit && choice && !groundDefaulted ? groundSelect : null}
        {deposit && groundDefaulted ? (
          <>
            {/* Cleared under Details, the line goes and the commit says why beside it. */}
            {said ? (
              <p className="dcard-ground t-footnote" data-ground={basis}>
                How you know: {said}.
              </p>
            ) : null}
            <Disclosure summary="Details" className="dcard-details">
              {groundSelect}
            </Disclosure>
          </>
        ) : null}
      </div>
      {/* THE ONE FOOT (spec §7.2): hints while focused, then Open in chat (Home only),
          Skip, and the one commit, trailing. */}
      <DecisionFoot
        hints={options.length ? undefined : []}
        commit={
          <Button
            variant="commit"
            busy={state.phase === "busy"}
            busyLabel="Sending…"
            disabledReason={reason || undefined}
            onClick={press}
            data-commit=""
          >
            Use this one
          </Button>
        }
      >
        <OpenInChat sessionId={sessionId} questionId={q.questionId} />
        {q.allowSkip ? (
          <Button variant="quiet" data-skip="" disabled={!writesEnabled || state.phase === "busy"} onClick={deferred.skip}>
            Skip
          </Button>
        ) : null}
      </DecisionFoot>
      {state.phase === "failed" && conflictWords(state.failure) ? (
        // A 409 from the engine (verify pass 2, S-ST-6): the question was settled or
        // changed since it was asked. Its own words, and no Try again: sending the same
        // answer again would be refused the same way.
        <NoticeLine tone="problem">
          <span data-answer-refused="">{conflictWords(state.failure)}</span>
        </NoticeLine>
      ) : state.phase === "failed" ? (
        <NoticeLine tone="problem" actionLabel="Try again" onAction={() => send(state.answer)}>
          {`Couldn't send: Vert's server didn't answer. Your choice is still here.${failures > 1 ? ` ${NOT_SENT_AGAIN}` : ""}`}
        </NoticeLine>
      ) : null}
    </article>
  );
}
