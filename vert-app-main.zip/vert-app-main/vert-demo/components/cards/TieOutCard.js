"use client";

// components/cards/TieOutCard.js — DOES THE RESULT AGREE WITH WHAT IT WAS CHECKED AGAINST?
// ==============================================================================
// Build plan §19.0.13 and §19.10 F-POL (eval TO1); iteration 4 W0c (CO-18, CO-19).
// Every schedule, fixed-asset, roll-forward and payroll result carries
// `artifact.tieOut`: the result's own figure beside the figure it should agree with.
// The reference draws it as two lines with a source mark on each:
//
//   ▤ Schedule                               $41,150.00
//   ▥ GL 2300 · Deferred revenue             $41,150.00
//   ✓ Agrees with the books   (the glossary: never "ties", §13.2)
//
// and, when it does not, the difference in the ENGINE's words in place of the ✓.
//
// THE SECOND SIDE IS NOT ALWAYS THE BOOKS (eval r3 output-visual F2). TieOutLine's
// second figure is named `gl`, but payroll checks its entry against the payroll FILE's
// Total row, and the card used to print "GL payroll-july.xlsx ✓ Agrees with the books"
// for it — a claim about the general ledger that nobody checked. So the second side is
// labelled by the kind of record its figure came from (`sideOf`): "GL 1500 · …" and
// "Agrees with the books" ONLY when that side is a ledger balance; a file side is named
// as the file, and agreeing with it says so ("Agrees with payroll-july.xlsx").
//
// WORDS ARE BOUND. A line's `words` carry money only as `{{fig:…}}` over the artifact's
// own figures, and they are drawn through BoundText like every other sentence in the
// thread; the card printed them raw once (eval r3, July fixed assets).
//
// A REASON IS SAID ONCE. An unread side is words, not $0.00 — and when the line's own
// words already give that reason, or both sides share it, the figure cell says only
// "not compared" and the reason is said once, in the verdict. When every line carries
// the same verdict (fixed assets' two accounts, both "no asset in the register yet"),
// it is said once under the lines, not once per line (eval r3: the same reason 4–6
// times on one screen).
//
// NOTHING HERE IS WORKED OUT. The figures are the artifact's (`ours` and `gl` name
// keys in `artifact.figures`, which the engine's validator holds to exist); `tied` is
// the engine's; the difference is the engine's sentence. The card never subtracts one
// side from the other, and never prints a ✓ the engine did not send.
//
// UNREAD IS NOT ZERO. A side the engine could not read is an unmeasured figure, drawn
// in words by the same Figure every other screen uses, never $0.00, and such a line is
// never `tied` (the engine refuses it), so it never carries a ✓.
//
// A LINE THAT NAMES A FIGURE THE ARTIFACT DOES NOT CARRY is drawn with that side
// "not sent" rather than dropped, so a half-sent tie-out is visible as half-sent.
//
// THE FOLD (CO-19). Under a delivered file chip the card is one line — "2 of 2 agree
// with the books", or the one shared reason — that opens the lines on press
// (`TieOutFold`). Stacked open under every chip, the card made eight result screens
// too long to read (eval r3 §9.1 S2).

import EventFigure from "@/components/chat/EventFigure";
import BoundText from "@/components/chat/BoundText";

import { IconCheck, IconFile, IconLedger } from "@/components/ui/icons";
const NOT_SENT = { measured: false, reason: "Not sent with this result" };

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);

/** The record kinds a ledger balance carries (vert_engine/agent_events.py TASK_SOURCE_KINDS). */
const LEDGER_KINDS = new Set(["ledger", "gl_account", "gl", "general_ledger"]);
/** The record kinds a file's own figure carries. */
const FILE_KINDS = new Set(["document", "upload", "file", "workbook", "statement", "bank"]);
/** A name that is a file's name. */
const FILE_NAME = /\.(xlsx|xlsm|xls|csv|pdf|png|jpe?g)$/i;

function kindsOf(figure) {
  const src = isObj(figure) && isObj(figure.source) ? figure.source : null;
  if (!src) return [];
  const own = typeof src.kind === "string" ? [src.kind] : [];
  // A derived figure (a total, a difference) is as much a file's or the books' as the
  // records it was worked out from.
  const inputs = Array.isArray(src.inputs) ? src.inputs.map((i) => (isObj(i) && typeof i.kind === "string" ? i.kind : null)).filter(Boolean) : [];
  return src.derived === true || inputs.length ? inputs.concat(own) : own;
}

/**
 * Which record the second side is: "gl" (a ledger balance) or "file". Read from the
 * figure's own source first; a side with no source (an unread one) is a file when the
 * line names a file there, and the books otherwise — `gl` is what TieOutLine's second
 * figure is named for, so the books are the default only when nothing says otherwise.
 */
export function sideOf(line, figure) {
  const kinds = kindsOf(figure);
  if (kinds.some((k) => FILE_KINDS.has(k))) return "file";
  if (kinds.some((k) => LEDGER_KINDS.has(k))) return "gl";
  const account = text(line && line.account);
  if (account && FILE_NAME.test(account)) return "file";
  return "gl";
}

function isRead(figure) {
  return Boolean(figure && figure.measured !== false && Number.isInteger(figure.cents));
}

function reasonOf(figure) {
  return figure && !isRead(figure) ? text(figure.reason) : null;
}

/** Does `words` already say `reason`? Case and a closing full stop don't matter. */
function says(words, reason) {
  if (!words || !reason) return false;
  const norm = (s) => s.toLowerCase().replace(/[.\s]+$/, "").trim();
  return norm(words).includes(norm(reason));
}

/** An unread side whose reason is said elsewhere on the line: words, once, never a figure. */
const quiet = (figure) => ({ ...figure, measured: false, reason: "not compared" });

/** The tie-out lines of an artifact, each with its two figures resolved. Pure. */
export function tieOutLines(artifact) {
  const a = isObj(artifact) ? artifact : {};
  const figures = isObj(a.figures) ? a.figures : {};
  const lines = Array.isArray(a.tieOut) ? a.tieOut : [];
  return lines
    .filter((l) => isObj(l) && text(l.label))
    .map((l, i) => {
      const ours = typeof l.ours === "string" && figures[l.ours] ? figures[l.ours] : null;
      const gl = typeof l.gl === "string" && figures[l.gl] ? figures[l.gl] : null;
      const glMeasured = isRead(gl);
      const oursMeasured = isRead(ours);
      // The ✓ is the engine's `tied`, and only over two read figures: a line that says
      // tied beside an unread side is drawn as not tied (the engine refuses to send one).
      const tied = l.tied === true && glMeasured && oursMeasured;
      const account = text(l.account);
      const side = sideOf(l, gl);
      const sideName = side === "gl" ? (account ? `GL ${account}` : "GL") : account || "the file";
      const words = text(l.words);
      // The reasons, each said once: an unread side whose reason the words (or the other
      // side) already give is drawn as "not compared", and the reason stays in one place.
      const oursReason = reasonOf(ours);
      const glReason = reasonOf(gl);
      const shared = oursReason && glReason && oursReason === glReason ? oursReason : null;
      let verdict;
      if (tied) verdict = side === "gl" ? "Agrees with the books" : `Agrees with ${sideName}`;
      else if (words) verdict = words;
      else if (shared) verdict = `Not compared: ${shared}`;
      else if (glMeasured) verdict = side === "gl" ? "Doesn't agree with the books" : `Doesn't agree with ${sideName}`;
      else verdict = side === "gl" ? "Not checked: the ledger side wasn't read" : `Not checked: ${sideName} wasn't read`;
      const oursShown = ours ? (oursReason && (says(verdict, oursReason) || shared) ? quiet(ours) : ours) : NOT_SENT;
      const glShown = gl ? (glReason && (says(verdict, glReason) || shared) ? quiet(gl) : gl) : NOT_SENT;
      return {
        key: `${l.ours || "ours"}~${l.gl || "gl"}~${i}`,
        label: text(l.label),
        account,
        source: text(l.source),
        side,
        sideName,
        ours: oursShown,
        oursRef: l.ours || null,
        gl: glShown,
        glRef: l.gl || null,
        tied,
        verdict,
      };
    });
}

/**
 * The card's verdicts, said once each: `shared` is the one verdict every line carries
 * when they all carry the same one and none is a ✓ (said once under the lines), else
 * null and each line says its own.
 */
export function sharedVerdict(lines) {
  const list = Array.isArray(lines) ? lines : [];
  if (list.length < 2 || list.some((l) => l.tied)) return null;
  const first = list[0].verdict;
  return list.every((l) => l.verdict === first) ? first : null;
}

/** The one unread-side reason every line shares, or null. Read from the artifact's own figures. */
function commonReason(artifact) {
  const a = isObj(artifact) ? artifact : {};
  const figures = isObj(a.figures) ? a.figures : {};
  const lines = (Array.isArray(a.tieOut) ? a.tieOut : []).filter((l) => isObj(l) && text(l.label));
  if (!lines.length) return null;
  const per = lines.map((l) => [reasonOf(figures[l.ours]), reasonOf(figures[l.gl])].filter(Boolean));
  const first = per[0];
  const found = first.find((r) => per.every((rs) => rs.includes(r)));
  return found ? found.replace(/\.\s*$/, "") : null;
}

/**
 * The fold's one line (CO-19): `{ text, tied, total, agrees }`, or null with no lines.
 * "2 of 2 agree with the books" — the books only when every second side is the GL; a
 * file side is named; a mix says "agree". When nothing agreed and the lines share one
 * reason, the line IS that reason (it already says what was not compared). A line that
 * does not agree adds the engine's own words for it (its difference); nothing is subtracted.
 */
export function tieOutSummary(artifact) {
  const lines = tieOutLines(artifact);
  if (!lines.length) return null;
  const tied = lines.filter((l) => l.tied).length;
  const total = lines.length;
  const sides = [...new Set(lines.map((l) => l.sideName))];
  const allGl = lines.every((l) => l.side === "gl");
  const against = allGl ? " with the books" : sides.length === 1 ? ` with ${sides[0]}` : "";
  const shared = sharedVerdict(lines);
  if (!tied && shared) return { text: shared, tied, total, agrees: false };
  if (total === 1 && !tied) return { text: lines[0].verdict, tied, total, agrees: false };
  // Nothing agreed and every line left one side unread for the same reason (fixed
  // assets with an empty register): that reason is the line, said once.
  const common = !tied ? commonReason(artifact) : null;
  if (common) return { text: `Not compared: ${common}`, tied, total, agrees: false };
  const verb = total === 1 ? "agrees" : "agree";
  const count = `${tied} of ${total} ${verb}${against}`;
  // THE DIFFERENCE IN DOLLARS (verify pass 2, Q14): "1 of 2 agree" said nothing of how
  // far the other is out. A line that does not agree and carries the engine's own words
  // (which hold the difference as a figure) is said after the count, named by its label;
  // nothing is subtracted here.
  const differ = lines.filter((l) => !l.tied && l.verdict && !/^(Doesn't agree|Not checked)/.test(l.verdict));
  const said = differ.map((l) => `${l.label}: ${l.verdict.replace(/\.\s*$/, "")}.`).join(" ");
  return { text: said ? `${count}. ${said}` : count, tied, total, agrees: tied === total };
}

function Mark({ kind, label }) {
  // A source mark: the side's origin as an icon, named for a screen reader and on hover.
  return (
    <span className="tieout-mark" data-source-mark={kind} role="img" aria-label={label} title={label}>
      {kind === "gl" ? <IconLedger size={14} /> : <IconFile size={14} />}
    </span>
  );
}

function Verdict({ tied, words, figures, ledgerName }) {
  return (
    <p className="tieout-verdict t-footnote" data-tieout-verdict={tied ? "tied" : "differs"}>
      {tied ? <span aria-hidden="true"><IconCheck size={12} className="caret-leading" /></span> : null}
      <BoundText text={words} figures={figures} ledgerName={ledgerName} />
    </p>
  );
}

export default function TieOutCard({ artifact, ledgerName = null }) {
  const lines = tieOutLines(artifact);
  if (!lines.length) return null;
  const figures = isObj(artifact) && isObj(artifact.figures) ? artifact.figures : {};
  const shared = sharedVerdict(lines);
  const allGl = lines.every((l) => l.side === "gl");
  return (
    <section className="tieout" data-card="tie-out" aria-label={allGl ? "Checked against the general ledger" : "Checked against its source"}>
      {lines.map((l) => (
        <div className="tieout-line" key={l.key} data-tied={l.tied ? "true" : "false"} data-side={l.side}>
          <div className="tieout-row">
            <Mark kind="ours" label={l.source ? `From ${l.source}` : "From this result"} />
            <span className="tieout-label t-footnote">{l.label}</span>
            <span className="tieout-figure t-footnote">
              <EventFigure figure={l.ours} figureRef={l.oursRef} />
            </span>
          </div>
          <div className="tieout-row">
            <Mark kind={l.side === "gl" ? "gl" : "file"} label={l.side === "gl" ? "From the general ledger" : `From ${l.sideName}`} />
            <span className="tieout-label t-footnote">{l.sideName}</span>
            <span className="tieout-figure t-footnote">
              <EventFigure figure={l.gl} figureRef={l.glRef} />
            </span>
          </div>
          {shared ? null : <Verdict tied={l.tied} words={l.verdict} figures={figures} ledgerName={ledgerName} />}
        </div>
      ))}
      {shared ? <Verdict tied={false} words={shared} figures={figures} ledgerName={ledgerName} /> : null}
    </section>
  );
}

/**
 * The tie-out folded to one line under a delivered chip (CO-19): the summary is the
 * summary element of a native disclosure, so the lines open on one press, with no
 * script, from the keyboard as from the pointer, and a closed one is not read out as
 * page text. Draws nothing when the engine sent no tie-out.
 */
export function TieOutFold({ artifact, ledgerName = null }) {
  const summary = tieOutSummary(artifact);
  if (!summary) return null;
  const figures = isObj(artifact) && isObj(artifact.figures) ? artifact.figures : {};
  return (
    <details className="tieout-fold" data-tieout-fold="" data-agrees={summary.agrees ? "true" : "false"}>
      <summary className="tieout-fold-line t-footnote" data-tieout-summary="">
        {summary.agrees ? <span aria-hidden="true"><IconCheck size={12} className="caret-leading" /></span> : null}
        <BoundText text={summary.text} figures={figures} ledgerName={ledgerName} />
      </summary>
      <TieOutCard artifact={artifact} ledgerName={ledgerName} />
    </details>
  );
}
