"use client";

// components/cards/SettledDecision.js — A DECISION IN THE THREAD, ONCE MADE
// ==============================================================================
// Spec §4.2 row 5: "After deciding it collapses to one line: 'You used the 1 Jul deposit
// · 10:42 · Undo'." This is that line for the conversation, drawn from the same words
// Month-end's cards collapse to (words.js settledDecisionLine → doneLine), so one
// decision reads the same in both places.
//
// WHY IT EXISTS (eval 30 Sep, S6 / C8 / UI-024 and W12). The thread printed its own
// line from `settled.by` raw — "key: founder test approved it · 15:32" on every decision
// — and had no Undo, so an approval made from the conversation, or the last approval in
// a Month-end group, could not be withdrawn from anywhere on screen. The approver now
// goes through lib/format.js approverLabel (never a key label), and Undo sits in the
// line while the latest decision is an approval and nothing has posted (words.js
// canUndo; the API's `undo` on the settlement wins when it sends one).
//
// UNDO REOPENS THE CARD IN PLACE. It calls the same Server Action as the Month-end card
// (lib/actions.js withdrawApproval → `POST /approvals/{id}/withdraw`), awaited through
// callSafely so a dropped connection is "Undo wasn't sent", never a thrown digest; on
// success the card is drawn again, armed, and the route is re-read. Nothing here writes
// on its own: the press is the person's.

import { createContext, useContext, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui";
import { withdrawApproval } from "@/lib/actions";
import { callSafely } from "@/lib/decisions";
import { useEngine, useWritesEnabled } from "@/lib/engine-context";
import { payoutStateFor } from "@/lib/feeds";
import { useRecordMonth, useSignedInActor } from "@/lib/store";
import { monthReadingOf } from "@/components/month/model";
import { canPost, holdsAsDraft } from "@/lib/ledger-shape";
import { formatMoney } from "@/lib/format";
import PostSheet from "./PostSheet";
import PostedPlate, { PostedEntryPlate } from "./PostedPlate";
import { useCardLedger } from "./useCardLedger";
import { readPostedByGet } from "@/components/records/entry-read-client";
import { settledBySave, usePostedFor, useSavedEdit } from "./journal-edits";
import { approvalNow, approvalNowNote, canUndo, isRead, postActionLabel, settledDecisionLine, splitLedgerName } from "./words";

/* ══════════════════════════════════════════════════════════════════════════ *
 * A POST IS A POST WHATEVER WORD ITS SETTLE RECORDED (eval final-b JE5, 6 Oct)
 *
 * The API re-reads a journal card's target on every conversation read, and a
 * `journal_draft` is verified the moment its entry is DRAFTED — the first half of the
 * card's draft-then-post press. So the card was settled "applied" while the post was
 * still in flight; the card's own settle as "posted" then found it already decided, and
 * the thread drew "Decided · you" over a posted entry, with no number, narration,
 * check table or Reverse (the GL rec's July card; the Draft-an-entry thread).
 *
 * So for a decision about one journal entry whose recorded word is not already a post
 * or a "no", the plate is drawn from what the ENTRY is: the post this tab made (held
 * by the card, journal-edits.js publishPosted), else `GET /journal/{id}` reading it
 * posted. Unread is not posted: until the read answers, the line stands.
 * ══════════════════════════════════════════════════════════════════════════ */

const JOURNAL_KINDS = new Set(["journal_draft", "journal_approve"]);
/** What a journal card says while its entry is read back (verify pass 10 F12). */
export const ENTRY_READING = "Checking this entry in the books…";
const NOT_A_POST = new Set(["posted", "post", "rejected", "reject", "declined", "withdrawn", "superseded"]);
const ENTRY_ID = /^[a-z]{1,16}:[0-9a-f]{6,64}$/;

/**
 * Whether a settled decision is a journal entry that may have posted under another
 * word: `{ entryId, posted }`, or null when it is not asked about. `posted` is true
 * only on a post held in this tab or a read of the entry saying posted. Pure.
 */
export function journalPostedView(action, settled, held = null, reread = null) {
  const a = action && typeof action === "object" ? action : {};
  if (!JOURNAL_KINDS.has(a.kind) || !settled || typeof settled !== "object") return null;
  if (NOT_A_POST.has(settled.outcome)) return null;
  const id = a.target && typeof a.target.id === "string" && ENTRY_ID.test(a.target.id) ? a.target.id : null;
  if (!id && !held) return null;
  const read = reread && reread.ok ? reread : null;
  const posted = Boolean(held && held.settled) || Boolean(read && (read.status === "posted" || (read.status === null && read.confirmed)));
  return { entryId: id, posted };
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * AN APPROVED ENTRY KEEPS ITS POST (verify pass 4, P25 / recs-jes F-5)
 *
 * After "Approve only" on a recording ledger the thread folded the journal card into
 * "Decided · Rina Patel" and the answer said "approved, waiting to post": nothing on
 * screen could post it. The line's own Post (below) is the payout road's (`approve`
 * cards only), so a `journal_draft` / `journal_approve` approval had none. The entry is
 * read back already (journalPostedView); when the read says it stands APPROVED and
 * unposted, the card is drawn again in its approved state, whose commit is "Post to
 * {ledger}…" through the same post sheet, with Undo beside it (journal-model.js
 * cardControls). It is re-drawn on the ENTRY's id with no `prefill`, so the press posts
 * the approved entry and never drafts the proposal a second time.
 * ══════════════════════════════════════════════════════════════════════════ */

const APPROVED_WORDS = new Set(["approved", "approve", "applied"]);

/**
 * The card to draw again for an approved, unposted journal entry: `{ action, initial }`,
 * or null. Only a read of the entry saying `approved` reopens it; an unread entry, a
 * draft, a post, a rejection or any other decision keeps the line. Pure.
 */
export function approvedEntryReopen(action, settled, reread) {
  const a = action && typeof action === "object" ? action : {};
  if (!JOURNAL_KINDS.has(a.kind) || !settled || typeof settled !== "object") return null;
  if (!APPROVED_WORDS.has(settled.outcome)) return null;
  if (!reread || !reread.ok || reread.status !== "approved") return null;
  const id = a.target && typeof a.target.id === "string" && ENTRY_ID.test(a.target.id) ? a.target.id : null;
  if (!id) return null;
  if (!a.je || typeof a.je !== "object" || !Array.isArray(a.je.lines) || !a.je.lines.length) return null;
  const { prefill, ...rest } = a;
  return { action: { ...rest, target: { ...(a.target || {}), id }, je: { ...a.je, state: "approved" } }, initial: { state: "approved" } };
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * A SKIP IS NOT A DEAD END (iteration 3 W0c; eval polish visual finding 2)
 *
 * After Skip on "No deposit found. Check the bank again?" the resolve-breaks thread
 * read "Needs you" over a green "Skipped · you · 22:26" line, and nothing on the page
 * let the person take the decision up again. A skip writes nothing, so taking it up
 * again writes nothing either: it runs the conversation's task again, and the task
 * asks every decision still open on the books — the skipped one included, as a new
 * card (vert_engine/workflows/player.py `_open_actions` leaves a declined card out of
 * the ones it re-uses).
 *
 * The conversation provides what "again" means (components/chat/Thread.js, through
 * this context): its own task, run in the same conversation. Where nothing provides
 * it — Month-end, a conversation that is not a task, a replay — the line offers
 * nothing, because nothing is listed unless it works.
 * ══════════════════════════════════════════════════════════════════════════ */

export const TakeUpAgain = createContext(null);
export const TAKE_UP_LABEL = "Take this up again";

const SKIPPED = new Set(["declined", "decline", "skipped"]);

/** Whether a settled line is a skip a person could take up again. Pure. */
export function isSkipped(settled) {
  return Boolean(settled && typeof settled === "object" && SKIPPED.has(settled.outcome));
}

// POST, FROM THE CONVERSATION TOO (eval JE5, 2 Oct): an approval made in the chat
// offered no Post anywhere on screen. While the approval stands and a ledger is
// connected, the line offers "Post to {ledger}…", which opens the same human post sheet
// Month-end uses; once posted it draws the same posted plate.
export default function SettledDecision({ action, settled, account = null, reopen = null, ledger: givenLedger = null, clientName = null }) {
  const router = useRouter();
  const signedIn = useSignedInActor();
  const writesEnabled = useWritesEnabled();
  const engine = useEngine();
  const recordMonth = useRecordMonth();
  const [undo, setUndo] = useState({ busy: false, failed: null, withdrawn: false });
  const ledger = useCardLedger(givenLedger);
  const [posting, setPosting] = useState(false);
  const [postMounted, setPostMounted] = useState(false);
  const [posted, setPosted] = useState(null);
  const takeUp = useContext(TakeUpAgain);
  const [takingUp, setTakingUp] = useState(false);
  const a = action && typeof action === "object" ? action : {};
  const payoutId = (a.prefill && a.prefill.payoutId) || (a.target && a.target.id) || null;

  // A SAVED EDIT IS NOT A DECISION (eval final-a C6). Save drafts the card's entry and
  // then supersedes it with the edited one; the API, reading its target back, finds the
  // entry drafted and settles the card "applied" — and the thread folded the card into
  // "Decided · you" over an edited entry still waiting for approval. While this tab
  // holds that saved edit, the card stays open on the edited entry (JournalCard says
  // "Your edit is saved. The entry still needs your approval."), until the edited entry
  // is approved, posted or rejected.
  const savedEdit = useSavedEdit(a.actionId);
  const held = usePostedFor(a.actionId);
  const journalAsk = journalPostedView(a, settled, held);
  const askId = journalAsk && !journalAsk.posted ? journalAsk.entryId : null;
  const [entryRead, setEntryRead] = useState(null);
  // Which entry's read has answered (ok or not). Until it has, the card says it is
  // checking (verify pass 10 F12; pass 9 F17): the bare "Decided" line under it read as
  // a dead card for 9–22 s while reads queued, and then grew a plate and Reverse….
  const [answeredFor, setAnsweredFor] = useState(null);
  const reading = Boolean(askId && writesEnabled && answeredFor !== askId);
  useEffect(() => {
    if (!askId || !writesEnabled) return undefined;
    let live = true;
    // A GET (staging D4 retest), never the readPostedEntry Server Action on mount.
    readPostedByGet(askId).then((answer) => {
      if (!live) return;
      setEntryRead(answer && answer.ok ? answer : null);
      setAnsweredFor(askId);
    });
    return () => {
      live = false;
    };
  }, [askId, writesEnabled]);
  const journalPosted = journalPostedView(a, settled, held, entryRead);
  if (journalPosted && journalPosted.posted) {
    const figure = a.figures && [a.figures.entry, a.figures.total, a.figures.amount, a.figures.debits].find(isRead);
    return (
      <PostedEntryPlate
        action={a}
        settled={{ ...settled, outcome: "posted" }}
        amount={figure ? formatMoney(figure.cents) : null}
        ledgerName={ledger && ledger.displayName}
        entryId={held ? null : journalPosted.entryId}
        fallback={null}
      />
    );
  }
  if (settledBySave(a, settled, savedEdit) && typeof reopen === "function") return reopen();
  const approvedAgain = typeof reopen === "function" ? approvedEntryReopen(a, settled, entryRead) : null;
  if (approvedAgain) return reopen(approvedAgain);

  // Withdrawn: the decision is open again. The caller draws the card (it owns the
  // props a card needs); without one, the line says what happened.
  if (undo.withdrawn && typeof reopen === "function") return reopen();

  async function withdraw() {
    setUndo({ busy: true, failed: null, withdrawn: false });
    const result = await callSafely(withdrawApproval, payoutId);
    if (!result.ok) {
      setUndo({ busy: false, failed: result, withdrawn: false });
      return;
    }
    setUndo({ busy: false, failed: null, withdrawn: true });
    // The withdraw's own reading of the month moves the sidebar badge at once (e2e r3
    // D1); the refresh then redraws the thread from what the API recorded.
    const reading = monthReadingOf(result);
    if (reading) recordMonth(reading);
    router.refresh();
  }

  const entry = a.figures && a.figures.entry;
  if (posted) return <PostedPlate settled={posted.settled} amount={isRead(entry) ? formatMoney(entry.cents) : null} ledgerName={ledger && ledger.displayName} />;

  const shown = undo.withdrawn ? { ...(settled || {}), outcome: "withdrawn" } : settled;
  // Re-derived from the record, not from the moment it settled (eval r2 C11): an
  // approval since withdrawn, rejected or posted offers neither Undo nor Post.
  const isApproval = a.kind === "approve" && (!shown || shown.outcome === "approved" || shown.outcome === "approve");
  const now = isApproval && !undo.withdrawn && payoutId ? approvalNow(payoutStateFor(engine, payoutId)) : null;
  const stale = now === "posted" || now === "gone";
  const undoable = !stale && !undo.withdrawn && writesEnabled && Boolean(payoutId) && canUndo(a, settled);
  // Post sits beside Undo exactly while Undo does: the approval stands, nothing posted.
  const postable = undoable && a.kind === "approve" && canPost(ledger) && Boolean(ledger && ledger.displayName);
  const line = (
    <div className="dcard-done" role="status" aria-live="polite" aria-busy={reading ? "true" : undefined} data-card-done="" data-card={a.kind || "unknown"} data-outcome={(shown && shown.outcome) || undefined}>
      <p className="dcard-done-text t-body">{settledDecisionLine(a, shown, { signedIn, account, ledgerName: ledger && ledger.displayName })}</p>
      {reading ? (
        <p className="dcard-done-note t-footnote" data-entry-reading="">
          {ENTRY_READING}
        </p>
      ) : null}
      {stale ? <p className="dcard-done-note t-footnote" data-stale="">{approvalNowNote(now)}</p> : null}
      {undo.failed ? <p className="dcard-done-note t-footnote">Undo wasn't sent. The approval stands.</p> : null}
      {isSkipped(shown) && writesEnabled && takeUp && typeof takeUp.run === "function" ? (
        <div className="dcard-done-actions">
          <Button
            variant="secondary"
            size="sm"
            busy={takingUp}
            busyLabel="Asking again…"
            disabledReason={takeUp.disabledReason || null}
            data-take-up=""
            onClick={async () => {
              setTakingUp(true);
              try {
                await takeUp.run();
              } finally {
                setTakingUp(false);
              }
            }}
          >
            {TAKE_UP_LABEL}
          </Button>
        </div>
      ) : null}
      {undoable ? (
        <div className="dcard-done-actions">
          <Button variant="quiet" size="sm" onClick={withdraw} busy={undo.busy} busyLabel="Undoing…">
            Undo
          </Button>
          {postable ? (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => {
                setPostMounted(true);
                setPosting(true);
              }}
              data-post-open=""
            >
              {/* Worded by createsDraft, never by the vendor (17 Oct 2026). */}
              {`${postActionLabel(ledger.displayName, { draft: holdsAsDraft(ledger) && !splitLedgerName(ledger.displayName).recording })}…`}
            </Button>
          ) : null}
        </div>
      ) : null}
      {postable && postMounted ? (
        <PostSheet
          open={posting}
          onClose={() => setPosting(false)}
          action={a}
          ledger={ledger}
          clientName={clientName}
          onPosted={(done) => {
            setPosting(false);
            setPosted(done);
          }}
        />
      ) : null}
    </div>
  );
  // A POSTED decision is drawn as the posted plate — number, narration, the ledger's
  // link and Reverse — wherever it sits: in the thread, folded under "Earlier", after a
  // reload (eval r2 JE5 / §9.3.F: Reverse was reachable only in the moment after a
  // Month-end post). With no entry to point at, the one line stands.
  if (shown && (shown.outcome === "posted" || shown.outcome === "post")) {
    const money = [entry, a.figures && a.figures.total, a.figures && a.figures.amount].find(isRead);
    return (
      <PostedEntryPlate
        action={a}
        settled={shown}
        amount={money ? formatMoney(money.cents) : null}
        ledgerName={ledger && ledger.displayName}
        fallback={line}
      />
    );
  }
  return line;
}
