"use client";

// components/cards/ReadBack.js — THE LEDGER'S READ-BACK, AND THE ENGINE'S "IT CHECKED OUT"
// ==============================================================================
// Shared by the journal card and the posted plate (design pass, 9 Oct 2026). Nothing
// here is worked out: the verdict and the rows are the engine's, as journal-model.js
// words them.

import { Disclosure } from "@/components/ui";
import { IconCheck } from "@/components/ui/icons";
import { readBackLine } from "./journal-model";

/** Whether a card's reason is the engine's own "it checked out" sentence (vert_engine
 *  draft_entry CHECKED_ALL), drawn as a done line with a tick (spec §6.17). Pure. */
export function isValidation(why) {
  return typeof why === "string" && /^It balances, every account is on the chart\b/.test(why.trim());
}

/** The engine's "it checked out" sentence without the "It balances," the card's head
 *  already says as "Balanced" (DA2-016 residue): "Every account is on the chart and the
 *  month is open." Anything else comes back as it was. Pure. */
export function besideBalanced(why) {
  if (!isValidation(why)) return why;
  const rest = why.trim().replace(/^It balances,\s*/, "");
  return rest ? rest.charAt(0).toUpperCase() + rest.slice(1) : why;
}

/** The read-back's tone: "done" when every check passed, "problem" when one failed,
 *  "neutral" when it was not read back. Never a pass by default. Pure. */
export function readBackTone(readBack) {
  const v = readBack && typeof readBack === "object" ? readBack.verified : null;
  return v === true ? "done" : v === false ? "problem" : "neutral";
}

/**
 * THE READ-BACK, ONE PRESS DOWN (design pass, spec §6.17; audit §6a P1). The engine's
 * verdict is the line on the face, with its tick (or triangle); the check table is the
 * evidence behind it, in a quiet disclosure, as an inset table whose Result column never
 * breaks mid-word. Shared by the card and the posted plate.
 */
export function ReadBackTable({ readBack, rows }) {
  const list = Array.isArray(rows) ? rows : [];
  if (!list.length) return null;
  const tone = readBackTone(readBack);
  return (
    <Disclosure
      className="jcard-readback-disclosure"
      summary={
        <span className="jcard-readback-line" data-tone={tone}>
          {tone === "done" ? <IconCheck className="jcard-readback-glyph" size={14} aria-hidden="true" /> : <span className="jcard-readback-mark" aria-hidden="true" />}
          {readBackLine(readBack)}
        </span>
      }
    >
      <div className="jcard-readback-scroll">
        <table className="jcard-grid jcard-readback-grid">
          <thead>
            <tr>
              <th scope="col">Check</th>
              <th scope="col">Expected</th>
              <th scope="col">Actual</th>
              <th scope="col">Result</th>
            </tr>
          </thead>
          <tbody>
            {list.map((row) => (
              <tr key={row.check} data-result={row.result}>
                <th scope="row">{row.check}</th>
                <td data-label="Expected">{row.expected}</td>
                <td data-label="Actual">{row.actual}</td>
                <td className="jcard-readback-result" data-result={row.result}>
                  {row.resultText}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Disclosure>
  );
}

