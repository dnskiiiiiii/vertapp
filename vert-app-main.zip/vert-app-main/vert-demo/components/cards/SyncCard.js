"use client";

// components/cards/SyncCard.js — "SYNC STRIPE", WHEN MORE EVIDENCE IS THE ANSWER
// ==============================================================================
// Spec §5.3 row 10; §6.4.
//
// Some breaks are not a person's to decide. When a payout's transactions don't add up,
// or no deposit on the statement matches it, the engine has proved something is
// missing, and the remedy is to read the source again — never a person choosing a
// number. So the card offers exactly that, through the existing sync action, and the
// button names only what is connected and relevant ("Sync Stripe", "Sync the bank"),
// from the engine's `commitLabel`.
//
// WHAT "DONE" MEANS HERE, said honestly: a sync STARTED. Whether it found what was
// missing is the next run's answer, and the task will say so; the collapsed line does
// not claim the break is fixed.

import { useRouter } from "next/navigation";
import { Button } from "@/components/ui";
import { startSync } from "@/components/sync/actions";
import { useCardCommit } from "@/lib/decisions";
import Card from "./Card";
import DecisionLine from "./DecisionLine";
import Skip from "./Skip";
import { boundLabel } from "./words";

import { IconCaretRight } from "@/components/ui/icons";
// The sync action reads who is signed in and takes nothing from the card: which books
// it syncs is the session's answer, never a request field.
function syncNow() {
  return startSync();
}

/** The sources a sync card names (`prefill.sources`), lower-cased. Pure. */
export function syncSources(action) {
  const list = action && action.prefill && Array.isArray(action.prefill.sources) ? action.prefill.sources : [];
  return list.filter((x) => typeof x === "string").map((x) => x.toLowerCase());
}

/**
 * Whether the card's remedy is the BANK alone (D02 F17: "Sync the bank" on a payout with
 * no deposit found). Vert's bank lines arrive with an imported statement; the sync
 * worker reads Stripe and Shopify, so the press started nothing for the bank and said
 * "Vert can't reach Stripe from here yet". The way on is the statement import. Pure.
 */
export function bankOnly(action) {
  const s = syncSources(action);
  return s.length > 0 && s.every((x) => x === "bank");
}

/** Where the statement import is: the engine's `prefill.importStatement.href` (ENG-RECS-e2,
 *  "/connections?import=statement&period=…") when it is one of this app's paths, else
 *  Connections. Pure. */
export function importHref(action) {
  const imp = action && action.prefill && action.prefill.importStatement;
  const href = imp && typeof imp.href === "string" ? imp.href : "";
  return /^\/connections(?:[?#][^\s]*)?$/.test(href) ? href : "/connections";
}

export const BANK_REMEDY = "Bank lines arrive with an imported statement. Import the latest one, and Vert looks for the deposit again.";

export default function SyncCard({ action, onSettled, ledgerName = null, initial = null }) {
  const card = useCardCommit(action, { onSettled, initial });
  const router = useRouter();
  const label = boundLabel(action.commitLabel, action.figures, ledgerName) || "Sync now";

  if (bankOnly(action) && card.phase !== "done") {
    return (
      <Card
        action={action}
        kind="sync"
        ledgerName={ledgerName}
        form={<p className="t-footnote dcard-why" data-bank-remedy="">{BANK_REMEDY}</p>}
        actions={
          <>
            <Button variant="commit" onClick={() => router.push(importHref(action))} data-sync-bank="">
              Import the statement<IconCaretRight className="caret-trailing" />
            </Button>
            <Skip action={action} card={card} />
          </>
        }
      />
    );
  }

  if (card.phase === "done") {
    return (
      <DecisionLine
        kind="sync"
        settled={card.settled}
        outcome={card.settled.outcome}
        note={card.settled.outcome === "declined" ? null : "Vert will look at this payout again when the sync finishes."}
      />
    );
  }

  return (
    <Card
      action={action}
      kind="sync"
      ledgerName={ledgerName}
      failure={card.phase === "failed" ? card.result : null}
      onRetry={card.phase === "failed" && card.writesEnabled ? card.retry : undefined}
      actions={
        <>
          <Button variant="commit" onClick={() => card.commit(syncNow, null, { outcome: "started" })} busy={card.busy} busyLabel="Starting…" disabledReason={card.disabledReason}>
            {label}
          </Button>
          <Skip action={action} card={card} />
        </>
      }
    />
  );
}
