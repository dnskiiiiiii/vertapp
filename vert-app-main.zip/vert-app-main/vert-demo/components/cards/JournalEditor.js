"use client";

// components/cards/JournalEditor.js — EDIT AN ENTRY, IN ITS CARD
// ==============================================================================
// Build plan §4.5 FJ item 3, §4.0.4; teardown standard 11. A journal card's Edit opens
// this inline, in place of the card's grid (eval r1 #13), at the card's width: every
// column fits (./journal-editor.css): in a card narrower than 760 px each line takes
// two rows (description beneath), and below 560 px each line stacks:
//
//   Memo [July rent            ]   Date [2026-07-31]
//   Account ⌄       Description      Name        Debit       Credit      ✕
//   6100 · Rent          4,000.00                July rent           ✕
//   1000 · Everyday                  4,000.00    July rent           ✕
//   + Add a line
//   Total debits $4,000.00 · Total credits $4,000.00 · Balanced     ← green when equal
//   [■ Save]   Cancel
//
// SAVE IS A NEW ENTRY (§4.0.4). It calls `saveEntry` (`POST /journal/{id}/redraft`):
// the engine records a new entry that supersedes this one, and the card then shows the
// new lines and approves the new id (./journal-edits.js), so an approval signs exactly
// what was shown. "Redraft" is the route's name and never appears here.
//
// WHILE THE LINES DON'T BALANCE, SAVE (AND SO APPROVE) IS DISABLED, WITH THE REASON
// PRINTED (UI-014): the same rules the engine applies on Save, said before the press
// (journal-model.js `editorGate`). The live totals are the one place the view layer
// adds money — the person's own unsaved lines, which no engine has totalled yet.
//
// A FAILED SAVE KEEPS EVERY EDIT (UI-002, UI-052). The lines stay exactly as typed, the
// failure says nothing was recorded, and Save can be pressed again.
//
// The account picker reads the chart from `/ledger/accounts` (lib/journal.js
// readChartAccounts): an account is chosen from the chart, never typed (§4.2). Until
// the chart has been read, each line offers the account it already had.

import { useEffect, useReducer, useState } from "react";
import { Button, DateField, Notice } from "@/components/ui";
import { decideAndSettle } from "@/lib/actions";
import { callSafely } from "@/lib/decisions";
import { useWritesEnabled } from "@/lib/engine-context";
import { draftEntry } from "@/lib/journal";
import { readChartOnce } from "./chart-read";
import { createRecurring } from "@/lib/journal";
import { ENTRY_TYPES, REPEAT_OPTIONS, recurringBody, repeatGate, reversalRuleWords } from "@/components/journals/model";
import { Segmented } from "@/components/ui";
import { formatMoney } from "@/lib/format";
import { publishEdit } from "./journal-edits";
import {
  accountOptions,
  accountText,
  blankEditorState,
  draftBody,
  editLines,
  editorGate,
  editorState,
  editorTotals,
  balanceOf,
  isEntryId,
  redraftBody,
  savedEntry,
  trackingColumns,
} from "./journal-model";
import { SAMPLE_REASON, failureDetails, failureSentence, recordedFor } from "./words";
import { IconAdd, IconCheck, IconClose } from "@/components/ui/icons";
import useUnsavedWarning from "@/components/chat/results/useUnsavedWarning";
// ITS OWN SHEET, WHEREVER IT IS OPENED (live check, 29 Oct 2026): only JournalCard
// imported it, so the Journals page's New entry, which opens the editor with no card on
// the page, drew it unstyled and pushed Credit off the sheet.
import "./journal-editor.css";

// What the person can change, as one comparable string: the memo, the date and every
// line's fields. Busy and failure are not edits, so they never make the editor dirty.
function editedContent(state) {
  const lines = (state.lines || []).map(({ key, ...line }) => line);
  return JSON.stringify({ memo: state.memo, date: state.date, lines, kind: state.entryKind || "", reverse: state.autoReverseOn || "", repeat: state.repeat || "off" });
}

// THE NEW-ENTRY FIELDS (W3 feature 2), drawn only when the editor writes a NEW entry
// (`create`): the entry's type (the engine stores it and prefers it over its guess), the
// day it reverses on, and Repeat. An edit of an existing entry keeps its own.
const CREATE_DEFAULTS = Object.freeze({ entryKind: "", autoReverseOn: "", repeat: "off", repeatEnd: "never", repeatUntil: "", repeatCount: "12" });

/** Why the new-entry fields can't be saved yet, or null. Pure. */
export function createGate(state) {
  const s = state || {};
  if (s.autoReverseOn && s.date && s.autoReverseOn <= s.date) return "It reverses after its own date, not on or before it.";
  return repeatGate(s);
}

// `create` ({ period, sessionId }): a NEW entry from a blank editor, written by hand
// (eval S10′): Save is `POST /journal/drafts` (lib/journal.js draftEntry), a draft that
// waits for a person's approval like any other, and `onSaved(result)` hears it.
//
// `schedule` ({ date, onCreate, label }): the Scheduled section's "+ New" Journal
// (research/2026-10-27-w3-build/scheduled-spec.md). The same lines, inside that sheet:
// no date row (the first date is the schedule's, `date`), no type, reversal or repeat
// (the When row above it is the repeat), and its one press calls `onCreate(config)` with
// the recurring-journal create's body (components/journals/model.js recurringBody), which
// the sheet sends as `POST /scheduled`'s `config`. Its words are the section's: short.
export default function JournalEditor({ action, onDone = null, onSaved = null, initial = null, accounts: givenAccounts = null, create = null, schedule = null }) {
  const a = action && typeof action === "object" ? action : {};
  const je = a.je && typeof a.je === "object" ? a.je : null;
  const entryId = (a.target && a.target.id) || null;
  const writesEnabled = useWritesEnabled();
  const [state, dispatch] = useReducer(editLines, null, () => ({ ...(create || schedule ? { ...blankEditorState(create ? create.period : null), ...CREATE_DEFAULTS } : editorState(je)), ...(initial || {}) }));
  // UNSAVED EDITS WARN BEFORE LEAVING (design-pass spec §8; WIG forms; critique r1
  // #14). The baseline is the entry as opened; a save moves it, so a saved editor is
  // clean again.
  const [baseline, setBaseline] = useState(() => editedContent(state));
  const dirty = editedContent(state) !== baseline;
  useUnsavedWarning(dirty);
  const [chart, setChart] = useState(() => ({ accounts: Array.isArray(givenAccounts) ? givenAccounts : [], reason: null }));

  useEffect(() => {
    if (Array.isArray(givenAccounts) || !writesEnabled) return undefined;
    let live = true;
    readChartOnce().then((answer) => {
      if (!live) return;
      setChart(answer && answer.ok ? { accounts: answer.accounts, reason: null } : { accounts: [], reason: (answer && answer.message) || null });
    });
    return () => {
      live = false;
    };
  }, [givenAccounts, writesEnabled]);

  if (!create && !schedule && (!je || !entryId)) {
    return <p className="t-body jeditor-empty">Vert couldn't read this entry, so it can't be edited here.</p>;
  }

  const totals = editorTotals(state.lines);
  const balance = balanceOf(state.lines);
  // A scheduled journal's date is the schedule's first one, not a field of its own.
  const dated = schedule ? { ...state, date: schedule.date || "" } : state;
  const gate = editorGate(dated) || (create ? createGate(state) : null);
  const reason = schedule ? (gate ? shortGate(gate) : null) : gate || (!writesEnabled ? SAMPLE_REASON : null);
  const options = optionsFor(chart.accounts, state.lines);
  // CLASS AND LOCATION, WHERE THE COMPANY USES THEM (§4.11a.5; §19.7 F-PLAN: "class/
  // location/tracking where used" on every new template's drafts). The columns are
  // read from the entry as drafted, so clearing a value never makes its column vanish
  // mid-edit; a company that uses neither sees neither. The entry contract carries class
  // and location only (vert_engine JournalLine), so there is no third tracking column.
  const track = trackingColumns([...(je && Array.isArray(je.lines) ? je.lines : []), ...state.lines]);

  async function save() {
    if (reason || state.busy) return;
    dispatch({ type: "saving" });
    if (schedule) {
      const made = await schedule.onCreate(scheduleConfig(state, schedule.date));
      if (!made || !made.ok) {
        dispatch({ type: "failed", result: made || { ok: false, message: "Not saved" } });
        return;
      }
      dispatch({ type: "saved" });
      setBaseline(editedContent(state));
      return;
    }
    if (create) {
      const repeating = state.repeat && state.repeat !== "off";
      // SAVE WITH REPEAT sets up the recurring entry and drafts its first period
      // (POST /recurring-journals); without, it is the one draft it always was.
      const made = repeating ? await callSafely(createRecurring, recurringBody(state, draftBody(state, create).lines)) : await callSafely(draftEntry, draftBody(state, create));
      if (!made.ok) {
        dispatch({ type: "failed", result: made });
        return;
      }
      dispatch({ type: "saved" });
      setBaseline(editedContent(state));
      if (onSaved) onSaved(made);
      return;
    }
    const body = redraftBody(state);
    // A card still showing its undrafted proposal sends it as `draft`: Save drafts it
    // first and then saves the edit onto that entry (lib/journal.js saveEntry; eval r2
    // JE3 — a bare redraft of the proposal's future id was refused `not_found`).
    const proposal = a.proposal && typeof a.proposal === "object" && Array.isArray(a.proposal.lines) ? a.proposal : null;
    const result = await callSafely(decideAndSettle, "saveEntry", { entryId, body, ...(proposal ? { draft: proposal } : {}) }, { actionId: null });
    if (!result.ok) {
      dispatch({ type: "failed", result });
      return;
    }
    dispatch({ type: "saved" });
    setBaseline(editedContent(state));
    const saved = savedEntry(je, state, result, chart.accounts);
    // A proposal saved for the first time is DRAFTED, not superseded (eval r1 f4): it
    // replaces no entry, so it names none.
    // Published under the card AND the entry it replaced, so a card the engine proposes
    // again for that entry shows (and approves) this revision (journal-edits.js).
    publishEdit(a.actionId, { entryId: saved.entryId || entryId, je: { ...saved.je, supersedes: isEntryId(entryId) ? entryId : null } }, entryId);
    if (onDone) onDone();
  }

  return (
    <form
      className="jeditor"
      data-editor="journal"
      onSubmit={(e) => {
        e.preventDefault();
        save();
      }}
    >
      {/* DESIGN-FIX-2 (DA2-017): the memo and the date on one row (the date an in-repo
          DateField, "30 Sep 2026", not the browser's dd/mm/yyyy), then ONE 36 px row per
          line: Account · Description · Debit · Credit · remove, borderless cells that
          take the evergreen edge and halo only on focus, and the totals under their own
          columns. */}
      <div className="jeditor-fields">
        <label className="field jeditor-memo">
          <span className="field-label">Memo</span>
          <input className="field-input" name="memo" autoComplete="off" placeholder={schedule ? "Monthly rent accrual" : "What this entry is for…"} value={state.memo} onChange={(e) => dispatch({ type: "field", name: "memo", value: e.target.value })} />
        </label>
        {schedule ? null : <DateField label="Date" name="date" className="jeditor-date" value={state.date} onChange={(value) => dispatch({ type: "field", name: "date", value })} />}
      </div>

      {create ? (
        <div className="jeditor-extra" data-editor-extra="">
          <label className="field jeditor-type">
            <span className="field-label">Type</span>
            <select className="field-input" name="entry-type" autoComplete="off" value={state.entryKind || ""} onChange={(e) => dispatch({ type: "field", name: "entryKind", value: e.target.value })}>
              <option value="">Let Vert tell from the lines</option>
              {ENTRY_TYPES.map((t) => (
                <option key={t.value} value={t.value}>
                  {t.label}
                </option>
              ))}
            </select>
          </label>
          <div className="jeditor-reverse">
            <DateField label="Reverses on (optional)" name="auto-reverse" value={state.autoReverseOn || ""} min={state.date || undefined} onChange={(value) => dispatch({ type: "field", name: "autoReverseOn", value })} />
            {state.autoReverseOn ? (
              <Button variant="quiet" size="sm" onClick={() => dispatch({ type: "field", name: "autoReverseOn", value: "" })}>
                Doesn&apos;t reverse
              </Button>
            ) : null}
          </div>
          <div className="field jeditor-repeat">
            <span className="field-label" id="jeditor-repeat-label">
              Repeat
            </span>
            <Segmented size="sm" label="Repeat" options={REPEAT_OPTIONS} value={state.repeat || "off"} onChange={(value) => dispatch({ type: "field", name: "repeat", value })} />
          </div>
          {state.repeat && state.repeat !== "off" ? (
            <div className="jeditor-repeat-end">
              <label className="field">
                <span className="field-label">Ends</span>
                <select className="field-input" name="repeat-end" autoComplete="off" value={state.repeatEnd || "never"} onChange={(e) => dispatch({ type: "field", name: "repeatEnd", value: e.target.value })}>
                  <option value="never">Never, until ended</option>
                  <option value="after">After a number of times</option>
                  <option value="on">On a date</option>
                </select>
              </label>
              {state.repeatEnd === "after" ? (
                <label className="field jeditor-count">
                  <span className="field-label">Times, this one included</span>
                  <input className="field-input num" inputMode="numeric" name="repeat-count" autoComplete="off" value={state.repeatCount || ""} onChange={(e) => dispatch({ type: "field", name: "repeatCount", value: e.target.value })} />
                </label>
              ) : null}
              {state.repeatEnd === "on" ? <DateField label="Last date" name="repeat-until" value={state.repeatUntil || ""} min={state.date || undefined} onChange={(value) => dispatch({ type: "field", name: "repeatUntil", value })} /> : null}
              <p className="t-footnote jeditor-repeat-note" data-repeat-note="">
                {/* Short, and the same rule as Scheduled (walk 2 copy list: five sentences
                    that also contradicted Scheduled's cadence). */}
                Save drafts the first one now. {reversalRuleWords(state) || "No reversal."} Never posts itself.
              </p>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="jeditor-grid-wrap">
        <table className="jeditor-grid">
          <thead>
            <tr>
              <th scope="col" className="jeditor-col-account jeditor-td-account">Account</th>
              <th scope="col" className="jeditor-col-desc jeditor-td-desc">Description</th>
              <th scope="col" className="jeditor-col-name jeditor-td-name">Name</th>
              {track.classRef ? <th scope="col" className="jeditor-td-track">Class</th> : null}
              {track.locationRef ? <th scope="col" className="jeditor-td-track">Location</th> : null}
              <th scope="col" className="num jeditor-col-amt jeditor-td-debit">Debit</th>
              <th scope="col" className="num jeditor-col-amt jeditor-td-credit">Credit</th>
              <th scope="col" className="jeditor-col-x jeditor-td-remove">
                <span className="sr-only">Remove</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {state.lines.map((line, i) => (
              <tr key={line.key} data-line={line.key}>
                <td className="jeditor-td-account">
                  <select
                    className="jeditor-cell"
                    translate="no"
                    aria-label={`Line ${i + 1} account`}
                    name={`line-${i + 1}-account`}
                    autoComplete="off"
                    value={line.accountId}
                    onChange={(e) => {
                      const picked = chart.accounts.find((x) => x.id === e.target.value) || null;
                      dispatch({ type: "line", key: line.key, patch: { accountId: e.target.value, account: picked || line.account } });
                    }}
                  >
                    <option value="" disabled>
                      Choose an account
                    </option>
                    {options.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </td>
                <td className="jeditor-td-desc">
                  <input
                    className="jeditor-cell"
                    placeholder={schedule ? "Office rent" : "What this line is for…"}
                    aria-label={`Line ${i + 1} description`}
                    name={`line-${i + 1}-description`}
                    autoComplete="off"
                    value={line.description}
                    onChange={(e) => dispatch({ type: "line", key: line.key, patch: { description: e.target.value } })}
                  />
                </td>
                <td className="jeditor-td-name">
                  {/* WHO THE LINE IS WITH (Q03 line 2; the reference editor's
                      Name/Vendor): a vendor or customer, kept on the saved line. */}
                  <input
                    className="jeditor-cell"
                    placeholder="Vendor or customer…"
                    aria-label={`Line ${i + 1} name`}
                    name={`line-${i + 1}-name`}
                    autoComplete="off"
                    value={line.name || ""}
                    onChange={(e) => dispatch({ type: "line", key: line.key, patch: { name: e.target.value } })}
                  />
                </td>
                {track.classRef ? (
                  <td className="jeditor-td-track">
                    <input
                      className="jeditor-cell"
                      placeholder="Class…"
                      aria-label={`Line ${i + 1} class`}
                      name={`line-${i + 1}-class`}
                      autoComplete="off"
                      value={line.classRef || ""}
                      onChange={(e) => dispatch({ type: "line", key: line.key, patch: { classRef: e.target.value } })}
                    />
                  </td>
                ) : null}
                {track.locationRef ? (
                  <td className="jeditor-td-track">
                    <input
                      className="jeditor-cell"
                      placeholder="Location…"
                      aria-label={`Line ${i + 1} location`}
                      name={`line-${i + 1}-location`}
                      autoComplete="off"
                      value={line.locationRef || ""}
                      onChange={(e) => dispatch({ type: "line", key: line.key, patch: { locationRef: e.target.value } })}
                    />
                  </td>
                ) : null}
                <td className="num jeditor-td-debit">
                  <input
                    className="jeditor-cell num"
                    inputMode="decimal"
                    placeholder="0.00"
                    aria-label={`Line ${i + 1} debit`}
                    name={`line-${i + 1}-debit`}
                    autoComplete="off"
                    value={line.debit}
                    onChange={(e) => dispatch({ type: "line", key: line.key, patch: { debit: e.target.value } })}
                  />
                </td>
                <td className="num jeditor-td-credit">
                  <input
                    className="jeditor-cell num"
                    inputMode="decimal"
                    placeholder="0.00"
                    aria-label={`Line ${i + 1} credit`}
                    name={`line-${i + 1}-credit`}
                    autoComplete="off"
                    value={line.credit}
                    onChange={(e) => dispatch({ type: "line", key: line.key, patch: { credit: e.target.value } })}
                  />
                </td>
                <td className="jeditor-col-x jeditor-td-remove">
                  <button
                    type="button"
                    className="icon-btn icon-btn-sm jeditor-remove"
                    aria-label={`Remove line ${i + 1}`}
                    aria-disabled={state.lines.length <= 2 ? "true" : undefined}
                    onClick={() => dispatch({ type: "remove", key: line.key })}
                  >
                    <IconClose size={14} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="jeditor-totals" data-balanced={totals.balanced ? "true" : "false"} aria-live="polite">
              <th scope="row" className="jeditor-td-total" colSpan={3 + (track.classRef ? 1 : 0) + (track.locationRef ? 1 : 0)}>
                {balance === "unreadable" ? (
                  <span className="jeditor-totals-note">{schedule ? "Check amounts" : "Totals appear once every amount is in dollars, like 1,234.56."}</span>
                ) : balance === "empty" ? null : balance === "balanced" ? (
                  // "Total, balanced" in the green ink with its tick (Q03 line 3: "balanced
                  // shown in green WITH the word"). The card's static "Balanced" stays the
                  // done ink; this is live feedback while the person types, the one place
                  // the editor says "this can be saved" (verify pass 8, F-7).
                  <span className="jcard-balanced jeditor-balanced" data-je-balanced="">
                    <IconCheck size={12} aria-hidden="true" />
                    Total, balanced
                  </span>
                ) : (
                  // Nothing is said until a line has an amount (D12), and the totals are
                  // on this row, not "below".
                  <span className="jeditor-off">{schedule ? "Doesn't balance" : "Doesn't balance: the debits and credits differ"}</span>
                )}
              </th>
              <td className="num jeditor-td-debit">{totals.debitCents === null ? "" : formatMoney(totals.debitCents)}</td>
              <td className="num jeditor-td-credit">{totals.creditCents === null ? "" : formatMoney(totals.creditCents)}</td>
              <td className="jeditor-td-remove" />
            </tr>
          </tfoot>
        </table>
      </div>
      {/* "Add line": a quiet small button with its Plus, never the accent. */}
      <Button variant="quiet" size="sm" className="jeditor-add" icon={<IconAdd size={14} />} onClick={() => dispatch({ type: "add" })}>
        Add line
      </Button>

      {chart.reason ? <p className="t-footnote jeditor-chart-note">{chart.reason}</p> : null}

      {state.failure && schedule ? (
        <p className="t-footnote jeditor-failed" role="alert" data-je-failed="">
          {state.failure.message || "Not saved"}
        </p>
      ) : state.failure ? (
        <Notice kind="error" recorded={recordedFor(state.failure)} details={failureDetails(state.failure)}>
          {failureSentence(state.failure)}
        </Notice>
      ) : null}

      {/* Cancel, then Save: the editor's one write (design-fix-2 §2.2 "Save on an editor
          that writes"), so it is the view's one commit while the card's own commit is
          folded away under the editor. */}
      <div className="jeditor-actions">
        {onDone ? (
          <Button variant="quiet" onClick={onDone}>
            Cancel
          </Button>
        ) : null}
        <Button variant="commit" type="submit" busy={state.busy} busyLabel={schedule ? "Creating…" : "Saving…"} disabledReason={reason || undefined} data-je-save="">
          {schedule ? schedule.label || "Create" : "Save"}
        </Button>
      </div>
    </form>
  );
}

/**
 * A scheduled journal's `config` (POST /scheduled): the recurring-journal create's body
 * (components/journals/model.js recurringBody) for these lines and memo, from `date`,
 * never reversing, with no end — WITHOUT the fields the cadence already states. The
 * engine takes the frequency and the day from `cadence` and refuses either in config
 * (vert_api/routers/scheduled.py _create_journal: "frequency comes from cadence, not
 * config."); sending `frequency` made every Create a 422 (staging browser walk 2, N1).
 * Pure, for tests/scheduled-wire.test.js.
 */
export const CADENCE_STATES = Object.freeze(["frequency", "dayOfMonth", "day_of_month"]);

export function scheduleConfig(state, date) {
  const dated = { ...(state || {}), date: date || "" };
  const lines = draftBody(dated, {}).lines;
  const body = recurringBody({ ...dated, repeat: "monthly", repeatEnd: "never", autoReverseOn: "", entryKind: "" }, lines);
  for (const taken of CADENCE_STATES) delete body[taken];
  return body;
}

// THE SCHEDULED SHEET'S REASONS ARE SHORT (the section's copy rule: four words at most).
// The same gate as Save's (journal-model.js editorGate), said as a label.
export function shortGate(gate) {
  const g = String(gate || "");
  if (!g) return null;
  if (/two lines/.test(g)) return "Add two lines";
  if (/needs an account/.test(g)) return "Choose accounts";
  if (/dollar amount|debit or a credit/.test(g)) return "Check amounts";
  if (/description/.test(g)) return "Add descriptions";
  if (/memo/.test(g)) return "Add a memo";
  if (/date/.test(g)) return "Choose a day";
  return "Doesn't balance";
}

// The picker's options: the chart when it has been read; otherwise each line's own
// account, so an untouched line still shows what it was.
function optionsFor(accounts, lines) {
  const fromChart = accountOptions(accounts);
  if (fromChart.length) return fromChart;
  const seen = new Map();
  for (const l of lines) {
    if (l.accountId && !seen.has(l.accountId)) seen.set(l.accountId, { value: l.accountId, label: accountText(l.account) });
  }
  return [...seen.values()];
}
