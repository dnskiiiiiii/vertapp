"use client";

// components/cards/OpenInChat.js — "OPEN IN CHAT", ON EVERY HOME CARD
// ==============================================================================
// Spec §7.2 (D10; critic r1 F8): a decision card's foot reads the same everywhere —
// hints · Open in chat · Skip · the one commit — and "Open in chat" is drawn on Home
// only: in the thread it would point at the page it is on. The conversation a card
// belongs to is its task's, which Home knows and the card does not, so the caller says
// it once (CardFor's `sessionId`, or the action's own) and every card's foot reads it
// from here. With no conversation known, nothing is drawn: a link to nowhere is not
// offered.

import { createContext, useContext } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { questionAnchor } from "@/app/api/budgets/shared";

const CardSession = createContext(null);

/** The conversation the cards inside belong to. */
export function CardSessionProvider({ sessionId = null, children }) {
  return <CardSession.Provider value={typeof sessionId === "string" && sessionId ? sessionId : null}>{children}</CardSession.Provider>;
}

/** The conversation id a card's "Open in chat" goes to: the given one, else its provider's, else the action's. */
export function useCardSession(action = null, sessionId = null) {
  const provided = useContext(CardSession);
  if (typeof sessionId === "string" && sessionId) return sessionId;
  if (provided) return provided;
  const own = action && typeof action === "object" ? action.sessionId : null;
  return typeof own === "string" && own ? own : null;
}

/**
 * WHERE "OPEN IN CHAT" LANDS (verify pass 5, W10): the conversation AT the card, by its
 * anchor (`#card-<actionId>`, the id the thread gives it; components/chat/NextAction.js
 * cardAnchor). Without it the press landed at the top of the conversation with the card
 * under the fold. Pure.
 */
export function openInChatHref(sessionId, action = null, questionId = null) {
  const base = `/chat/${encodeURIComponent(sessionId)}`;
  // A QUESTION'S card lands on the question (verify pass 5, W10 regression): Month-end's
  // "Two deposits … which one?" passed no action, so its link carried no anchor at all and
  // the conversation opened at the top with the question under the fold. The thread gives
  // an open question the id `question-<id>` (Thread.js) and lands on it.
  if (typeof questionId === "string" && questionId) return `${base}#${questionAnchor(questionId)}`;
  const actionId = action && typeof action === "object" ? action.actionId : null;
  return actionId != null && String(actionId) ? `${base}#card-${String(actionId).replace(/[^A-Za-z0-9_-]/g, "_")}` : base;
}

export default function OpenInChat({ action = null, sessionId = null, questionId = null }) {
  const pathname = usePathname();
  const id = useCardSession(action, sessionId);
  if (pathname !== "/" || !id) return null;
  return (
    <Link className="btn btn-quiet" href={openInChatHref(id, action, questionId)} data-open-in-chat="">
      Open in chat
    </Link>
  );
}
