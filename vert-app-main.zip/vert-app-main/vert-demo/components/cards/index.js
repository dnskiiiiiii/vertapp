// components/cards/index.js — ONE CARD PER KIND OF DECISION
// ==============================================================================
// Build plan §2.9 and spec §5. `CardFor({ action, onSettled })` is the one door both
// Month-end and the conversation use to draw a decision, keyed by `action.kind` — the
// engine's ACTION_KINDS (vert_engine/agent_events.py): bank_pin, gst, txn_class,
// chart_gap, approve, approve_many, reject, post, withdraw, exception_decision, sync —
// and iteration 2's PENDING_ACTION_KINDS (journal_approve, journal_reject,
// journal_draft, reverse, prepaid_agree), keyed now to placeholder cards that draw no
// commit until FJ and EC3b build them (build plan §4.1 step 0).
//
// `EditorFor(kind)` is the second door: the editor a card's Edit opens in the result
// pane (FP's slot), or null for a kind nothing edits. The pane asks for an editor by
// kind and never imports one, so a new editable kind is one line here.
//
// A card receives the action and callbacks, never the event list (plan §2.9). What it
// writes goes through lib/actions.js — the existing routes with their gates — and it
// then settles the action so the API reads the target back (lib/decisions.js
// useCardCommit).
//
// A KIND WITHOUT A CARD IS DRAWN WITHOUT A COMMIT. `reject`, `post` and `withdraw` are
// reached from the approve card (the reject sheet, the post sheet, Undo) rather than
// proposed on their own in iteration 1; if the engine ever does propose one, it is
// drawn as its proposal with no button, because a button that decided something while
// no card was wired would be a false affordance.

import ApproveCard from "./ApproveCard";
import ApproveManyCard from "./ApproveManyCard";
import Card from "./Card";
import ChartGapCard from "./ChartGapCard";
import ClassifyCard from "./ClassifyCard";
import ExceptionDecisionCard from "./ExceptionDecisionCard";
import GstCard from "./GstCard";
import JournalCard from "./JournalCard";
import JournalEditor from "./JournalEditor";
import PlanCard from "./PlanCard";
import PlanDocument from "@/components/chat/plan/PlanDocument";
import PrepaidAgreeCard from "./PrepaidAgreeCard";
import SkillUpdateCard from "./SkillUpdateCard";
import SyncCard from "./SyncCard";
import UseDepositCard from "./UseDepositCard";
import { CardSessionProvider } from "./OpenInChat";

export const CARDS = Object.freeze({
  bank_pin: UseDepositCard,
  gst: GstCard,
  txn_class: ClassifyCard,
  chart_gap: ChartGapCard,
  approve: ApproveCard,
  approve_many: ApproveManyCard,
  exception_decision: ExceptionDecisionCard,
  sync: SyncCard,
  journal_approve: JournalCard,
  journal_reject: JournalCard,
  journal_draft: JournalCard,
  reverse: JournalCard,
  prepaid_agree: PrepaidAgreeCard,
  // Iteration 3 (§19.7 F-PLAN). Their presses (plan_approve, plan_reject, plan_edit,
  // skill_apply) are footer buttons on these cards and the plan document, never cards of
  // their own; note_save is the inline Save under a turn (components/chat/TurnSave.js).
  plan: PlanCard,
  skill_update: SkillUpdateCard,
});

// The kinds whose card has an inline editor (§4.0.4: Edit → Save supersedes the entry).
export const EDITORS = Object.freeze({
  journal_approve: JournalEditor,
  journal_draft: JournalEditor,
});

// The kinds whose card opens a DOCUMENT in the same pane slot (§19.7 F-PLAN: a plan's
// Review opens the plan beside the chat, where Save changes · Reject · Start now live).
// Kept apart from EDITORS on purpose: nothing here edits an entry, and the entry-editor
// set stays exactly the kinds an entry is edited from (tests/iter2-contracts.test.js).
export const PANE_DOCUMENTS = Object.freeze({
  plan: PlanDocument,
});

// The kinds whose card draws its own settled state in the thread, in place of the shared
// settled line: the skill update, whose settled state is its "What changed" outline
// (eval r1 #18, SK2). Every other kind settles to components/cards/SettledDecision.js.
export const SELF_SETTLING = Object.freeze(new Set(["skill_update"]));

/** Whether a settled card of this kind is drawn by its own card, not the settled line. */
export function drawsOwnSettlement(kind) {
  return typeof kind === "string" && SELF_SETTLING.has(kind);
}

/** The body the pane draws for a card kind (an entry's editor or a plan), or null. */
export function EditorFor(kind) {
  if (typeof kind !== "string") return null;
  if (Object.hasOwn(EDITORS, kind)) return EDITORS[kind];
  if (Object.hasOwn(PANE_DOCUMENTS, kind)) return PANE_DOCUMENTS[kind];
  return null;
}

export function CardFor({ action, sessionId = null, ...props }) {
  const Component = action && CARDS[action.kind];
  // The card's conversation, for its "Open in chat" on Home (spec §7.2): the caller's,
  // else the task's it was given (a plan), else the action's own (OpenInChat.js).
  const session = sessionId || (props.task && props.task.sessionId) || null;
  if (!Component) return <Card action={action} kind={action && action.kind} />;
  return (
    <CardSessionProvider sessionId={session}>
      <Component action={action} {...props} />
    </CardSessionProvider>
  );
}

export { default as ChooseDepositQuestion } from "./ChooseDepositQuestion";
export { default as AskedInChatCard } from "./AskedInChatCard";
export { default as OpenInChat, CardSessionProvider } from "./OpenInChat";
export { default as DecisionLine } from "./DecisionLine";
export { default as PostSheet } from "./PostSheet";
export { default as RejectSheet } from "./RejectSheet";
export { default as SettledDecision } from "./SettledDecision";
export { PostedEntryPlate } from "./PostedPlate";
