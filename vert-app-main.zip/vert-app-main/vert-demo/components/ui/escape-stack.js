"use client";

// components/ui/escape-stack.js — ONE ESC CLOSES ONE LAYER: THE TOPMOST (verify pass 2, U36)
// ==============================================================================
// At 390 px the Schedule sheet sat over the plan pane, and one Esc closed both: each
// listened on `document`, and `stopPropagation` does not stop another listener on the
// same node. Every layer that closes on Esc (the kit Sheet, the conversation's panes)
// now registers here; one document listener hands Esc to the layer opened last, and to
// no other. Pure bookkeeping plus that one listener, so the rule is held without a
// browser (tests/vf-demo-chat-p2-escape.test.js).

const stack = [];
let listening = false;

function onKeyDown(event) {
  if (event.key !== "Escape" || !stack.length) return;
  // An inner control that already used this Esc (a cell editor cancelling, a menu
  // closing, an IME composition) keeps it: the layer under it stays open.
  if (event.defaultPrevented || event.isComposing) return;
  const top = stack[stack.length - 1];
  event.stopPropagation();
  top(event);
}

/** Register `handler` as the newest Esc layer; returns the function that removes it. */
export function pushEscape(handler) {
  if (typeof handler !== "function") return () => {};
  const entry = (event) => handler(event);
  stack.push(entry);
  if (!listening && typeof document !== "undefined") {
    document.addEventListener("keydown", onKeyDown);
    listening = true;
  }
  return () => {
    const at = stack.lastIndexOf(entry);
    if (at >= 0) stack.splice(at, 1);
    if (!stack.length && listening && typeof document !== "undefined") {
      document.removeEventListener("keydown", onKeyDown);
      listening = false;
    }
  };
}

/** The Esc handler a key event goes to (exported for the tests). */
export function dispatchEscape(event) {
  onKeyDown(event);
}
