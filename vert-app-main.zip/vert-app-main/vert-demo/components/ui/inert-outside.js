// components/ui/inert-outside.js — A MODAL SHEET MAKES THE PAGE BEHIND IT INERT
// ==============================================================================
// ui-pass-1 #32 (U52, U59; 10 Oct 2026). The new-task sheet said `aria-modal="true"` and
// put a scrim over the page, but nothing behind the scrim was taken out of reach: the
// open decision card's "Use this one" stayed focusable and in the accessibility tree,
// so the view held two commits and two accent fills, and Tab left the dialog the moment
// the focus trap missed a beat (a press on the page, a screen reader's virtual cursor).
// `aria-modal` is a promise to assistive tech, not a mechanism; `inert` is the mechanism.
//
// The sheet is drawn inside the page (no portal), so its ancestors cannot be made inert
// without taking the sheet with them. What is made inert is every SIBLING along the path
// from the sheet's layer up to <body>: everything on the page that is not the sheet or
// one of its containers. An element that was already inert is left alone and is not
// restored, so a closed disclosure stays closed. The returned function undoes exactly
// what this did. `[data-leaving]` copies (Sheet.js leaveFromLive) are skipped: they are
// inert already.

const SKIP = new Set(["SCRIPT", "STYLE", "TEMPLATE", "LINK", "META", "NOSCRIPT"]);

/**
 * Make everything outside `layer` inert, up to `<body>`. Returns the undo. Works on any
 * element-like tree (parentElement, children, tagName, has/set/removeAttribute), so it
 * is tested without a browser.
 */
export function inertOutside(layer, root = typeof document === "undefined" ? null : document.body) {
  const changed = [];
  if (!layer) return () => {};
  let node = layer;
  while (node && node !== root && node.parentElement) {
    const parent = node.parentElement;
    for (const sibling of Array.from(parent.children || [])) {
      if (sibling === node || SKIP.has(String(sibling.tagName || "").toUpperCase())) continue;
      if (sibling.hasAttribute("inert") || sibling.hasAttribute("data-leaving")) continue;
      sibling.setAttribute("inert", "");
      changed.push(sibling);
    }
    node = parent;
  }
  return () => {
    for (const el of changed) el.removeAttribute("inert");
    changed.length = 0;
  };
}
