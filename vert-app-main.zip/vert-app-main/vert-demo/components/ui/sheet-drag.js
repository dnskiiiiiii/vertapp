// components/ui/sheet-drag.js — A PHONE SHEET YOU CAN PULL DOWN
// ==============================================================================
// Design-pass spec §5.2 (the bottom-sheet row of the motion table); apple-design §2,
// §5, §6, §9, §10. The grabber on a phone bottom sheet is a promise of a gesture, so
// the gesture exists:
//
//   · 1:1 tracking on the grabber and the sheet's head, with the grab offset kept, and
//     pointer capture once the drag is committed, so it keeps tracking off the handle
//     (AD §2). Capture waits for the commit so a tap on the close button is still a
//     click on the close button.
//   · A 10 px hysteresis before the drag commits (AD §10).
//   · Past the open position (dragged up), resistance: the rubber band, c = 0.55 (AD §9).
//   · On release, the resting place is PROJECTED from the velocity with d = 0.998
//     (AD §6), and the sheet goes to whichever of open or closed is nearer that point.
//   · Closed, the release velocity seeds the exit spring (sheet-spring.js, AD §5);
//     kept open, it settles on `--spring-momentum`, the one bounce this product has,
//     because only here did a gesture carry momentum (AD §4).
//
// Pure functions, so the physics is tested without a browser (tests/ui-kit.test.js).
// Under reduced motion there is no drag (spec §5.6): the grabber is hidden (base.css)
// and the sheet closes by its close control, the scrim or Esc.

/** The drag commits once the pointer has moved this far (px). */
export const HYSTERESIS_PX = 10;
/** UIScrollView's normal deceleration rate. */
export const DECELERATION = 0.998;
/** The rubber band's stiffness (UIScrollView's). */
export const RUBBER_BAND = 0.55;
/** Only the last stretch of the drag counts toward the release velocity (ms). */
export const VELOCITY_WINDOW_MS = 80;

/**
 * How far a flick carries on after release, in px, for a velocity in px/ms:
 * Apple's `(v/1000)·d/(1−d)` with v in px/s, which is `v·d/(1−d)` in px/ms.
 */
export function project(velocityPxPerMs, d = DECELERATION) {
  if (!Number.isFinite(velocityPxPerMs)) return 0;
  return (velocityPxPerMs * d) / (1 - d);
}

/** Resistance past a bound: the further, the harder, never more than `dimension`. */
export function rubberband(overshoot, dimension, c = RUBBER_BAND) {
  if (!(overshoot > 0) || !(dimension > 0)) return 0;
  return (1 - 1 / ((overshoot * c) / dimension + 1)) * dimension;
}

/**
 * Where the panel is drawn for a raw drag distance (px, positive = down). Down tracks
 * 1:1; up, past the open position, rubber-bands.
 */
export function dragOffset(raw, height) {
  if (!Number.isFinite(raw)) return 0;
  return raw >= 0 ? raw : -rubberband(-raw, height);
}

/** Whether a pointer that moved (dx, dy) has committed to a vertical drag. */
export function committed(dx, dy, threshold = HYSTERESIS_PX) {
  return Math.abs(dy) >= threshold && Math.abs(dy) >= Math.abs(dx);
}

/**
 * The release velocity in px/ms from timed samples [{ t, y }], over the last
 * VELOCITY_WINDOW_MS. A pointer that stopped before letting go has no velocity.
 */
export function velocityOf(samples, now) {
  if (!Array.isArray(samples) || samples.length < 2) return 0;
  const last = samples[samples.length - 1];
  const at = Number.isFinite(now) ? now : last.t;
  if (at - last.t > VELOCITY_WINDOW_MS) return 0;
  let first = last;
  for (let i = samples.length - 1; i >= 0; i -= 1) {
    if (last.t - samples[i].t > VELOCITY_WINDOW_MS) break;
    first = samples[i];
  }
  const dt = last.t - first.t;
  return dt > 0 ? (last.y - first.y) / dt : 0;
}

/**
 * Open or closed, from where the release is GOING, not where it is: the projected end
 * point against half the sheet's height.
 */
export function releaseTarget({ offset, velocity, height }) {
  if (!(height > 0)) return "open";
  const end = offset + project(velocity);
  return end > height / 2 ? "close" : "open";
}
