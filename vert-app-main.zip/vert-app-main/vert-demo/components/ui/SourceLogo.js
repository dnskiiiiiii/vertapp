// components/ui/SourceLogo.js — WHERE A FIGURE CAME FROM, DRAWN AS ITS SOURCE'S MARK
// ==============================================================================
// Design-fix-2 spec §2.5, §4, §5.6; audit DA2-027. (The spec's fourth ledger mark, Xero, was
// left out while the product did not connect to it; it is back since Xero became the first
// ledger, 16 Oct 2026.) A Connections row, a finding line, a
// budget row and the post sheet's ledger line each lead with the mark of the system the
// figure came from, not a generic card or book glyph.
//
// MONOCHROME, ALWAYS. The brand marks are static files (public/sources/*.svg, paths from
// the CC0 simple-icons set: no dependency; the sources Vert reads today, and no others —
// tests/claims.test.js holds the app to naming no ledger it does not connect to) drawn as a CSS MASK filled with the current
// text colour, so a Stripe or QuickBooks mark is the same ink as the words beside it and never
// its brand colour: the palette stays calm. Sources with no brand mark take a Phosphor
// glyph: the bank, a CSV statement, an Excel workbook.
//
// Sizes: 16 px inline (a finding line), 20 px in a row, and `tile` — a 32 px
// --surface-inset tile, radius 8, with the mark at 20 px (a Connections row).
// Decorative: the source's NAME is always printed beside it, so the mark is aria-hidden.

import { IconBank, IconCsv, IconEmail, IconWorkbook, IconFile } from "@/components/ui/icons";

const MARKS = {
  stripe: "/sources/stripe.svg",
  xero: "/sources/xero.svg",
  quickbooks: "/sources/quickbooks.svg",
  shopify: "/sources/shopify.svg",
};

const GLYPHS = {
  bank: IconBank,
  email: IconEmail,
  csv: IconCsv,
  statement: IconCsv,
  excel: IconWorkbook,
  workbook: IconWorkbook,
};

/** The key for a source named in words ("QuickBooks Online", "Stripe payouts", "bank"). */
export function sourceKey(name) {
  const s = String(name || "").toLowerCase();
  if (s.includes("stripe")) return "stripe";
  if (s.includes("xero")) return "xero";
  if (s.includes("quickbooks") || s === "qbo") return "quickbooks";
  if (s.includes("shopify")) return "shopify";
  if (s.includes("excel") || s.includes("xlsx") || s.includes("workbook")) return "excel";
  if (s.includes("csv") || s.includes("statement")) return "csv";
  if (s.includes("bank")) return "bank";
  return null;
}

export function SourceLogo({ source, size = 16, tile = false, className }) {
  const key = MARKS[source] || GLYPHS[source] ? source : sourceKey(source);
  const px = tile ? 20 : size;
  let mark;
  if (key && MARKS[key]) {
    mark = <span className="source-logo-mark" style={{ "--logo": `url(${MARKS[key]})`, "--logo-size": `${px / 16}rem` }} />;
  } else {
    const Glyph = (key && GLYPHS[key]) || IconFile;
    mark = <Glyph size={px} />;
  }
  return (
    <span className={["source-logo", tile ? "source-logo-tile" : null, className].filter(Boolean).join(" ")} aria-hidden="true" data-ui="SourceLogo" data-source={key || "other"}>
      {mark}
    </span>
  );
}
