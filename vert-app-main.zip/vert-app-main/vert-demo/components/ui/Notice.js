"use client";

// components/ui/Notice.js — FEEDBACK, IN ITS FOUR KINDS
// ==============================================================================
// Spec §11.5 (apple-design §16, "feedback comes in four kinds"); audit UI-002, UI-051.
//
//   status      what is happening now                  "Checking 31 payouts…"
//   completion  what just happened, who and when        "You approved $9,350.73 · 10:42"
//   warning     before a problem, beside what it is about
//   error       a plain sentence, what was and wasn't recorded, Retry, Details ▾
//
// AN ERROR IS WRITTEN FOR THE PERSON READING IT (UI-051). The sentence is theirs:
// what happened and what was recorded — "Not sent. Nothing was recorded." The code,
// the URL and anything else an engineer needs go under Details, closed. A Retry is
// offered whenever the caller can retry, because an error with no next step is a
// dead end with a message on it.
//
// `recorded` is required for an error, not optional prose: a person who pressed
// Approve and saw a failure must know whether anything reached the books before they
// press it again (UI-002). Three values match the §2.2 `error` event (nothing,
// partial, all); `unknown` is for a failure no write of this page caused; `unconfirmed`
// is a write whose answer never came and whose read-back failed too.
//
// Status and completion are announced politely; an error is an alert. `anchored` is
// the background notice's form — a small float pinned to the conversation list.

import { Button, IconButton } from "./Button";
import { Disclosure } from "./Disclosure";
import { IconClose, IconInfo, IconProblem, IconWarning } from "@/components/ui/icons";

const KINDS = new Set(["status", "completion", "warning", "error"]);

export const RECORDED_WORDS = Object.freeze({
  nothing: "Nothing was recorded.",
  partial: "Some of it was recorded.",
  all: "It was recorded.",
  // For a failure that did not come from a write this page made — a page that stopped
  // rendering — nobody here knows what reached the books, and saying "nothing" would be
  // a guess. It points at the one place that does know.
  unknown: "Reload to see what was saved.",
  // For a write whose answer never came and whose read-back failed too (W0c, CO-17):
  // whether it landed is not known yet, and saying "nothing" would be a guess that
  // invites a second press over a decision that may stand.
  unconfirmed: "Vert couldn't confirm yet whether it was recorded.",
  // For a read that failed (staging browser walk 3, W3-4): nothing was asked to be
  // recorded, so nothing is said about recording. "Nothing was recorded" is a write's.
  read: "",
});

export function Notice({
  kind = "status",
  children,
  recorded,
  onRetry,
  retryLabel = "Try again",
  details,
  action,
  onDismiss,
  anchored = false,
  className,
}) {
  if (!KINDS.has(kind)) throw new TypeError(`Notice: unknown kind ${JSON.stringify(kind)}`);
  if (kind === "error" && !Object.hasOwn(RECORDED_WORDS, recorded)) {
    throw new TypeError("Notice: an error must say what was recorded (nothing | partial | all | unknown | unconfirmed | read)");
  }
  const role = kind === "error" ? "alert" : "status";
  return (
    <div
      className={["notice", `notice-${kind}`, anchored ? "notice-anchored" : null, className].filter(Boolean).join(" ")}
      role={role}
      aria-live={kind === "error" ? undefined : "polite"}
      data-ui="Notice"
    >
      <div className="notice-body">
        <p className="notice-text">
          {children}
          {kind === "error" && RECORDED_WORDS[recorded] ? <> {RECORDED_WORDS[recorded]}</> : null}
        </p>
        {action || onRetry ? (
          <div className="notice-actions">
            {action || null}
            {onRetry ? (
              <Button variant="secondary" size="sm" onClick={onRetry}>
                {retryLabel}
              </Button>
            ) : null}
          </div>
        ) : null}
        {details ? (
          <Disclosure summary="Details" className="notice-details">
            <p className="notice-code">{details}</p>
          </Disclosure>
        ) : null}
      </div>
      {onDismiss ? (
        <IconButton label="Dismiss" onClick={onDismiss} className="notice-dismiss">
          <IconClose />
        </IconButton>
      ) : null}
    </div>
  );
}

const LINE_TONES = {
  problem: IconProblem,
  attention: IconWarning,
  info: IconInfo,
};

/**
 * THE ONE-LINE NOTICE (design-fix-2 §5.6; DA2-031, DA2-040, DA2-074). One line, 36 px at
 * least: an icon, the cause and the next step in words, and one quiet action at the end.
 * No pink slab: the tone is its ink. "Couldn't send: Vert's server didn't answer. Your
 * message is still here." + "Try again".
 *
 * The CALLER reserves its space (a slot of the same min-height that is empty until the
 * notice arrives), so nothing on the page shifts when it appears. A problem is an alert;
 * attention and info are announced politely.
 */
export function NoticeLine({ tone = "problem", children, actionLabel, onAction, actionBusy = false, actionBusyLabel, className }) {
  const Glyph = LINE_TONES[tone];
  if (!Glyph) throw new TypeError(`NoticeLine: unknown tone ${JSON.stringify(tone)}`);
  return (
    <div
      className={["notice-line", className].filter(Boolean).join(" ")}
      data-tone={tone}
      role={tone === "problem" ? "alert" : "status"}
      aria-live={tone === "problem" ? undefined : "polite"}
      data-ui="NoticeLine"
    >
      <Glyph />
      <p className="notice-line-text">{children}</p>
      {actionLabel && onAction ? (
        <Button variant="quiet" size="sm" onClick={onAction} busy={actionBusy} busyLabel={actionBusyLabel}>
          {actionLabel}
        </Button>
      ) : null}
    </div>
  );
}
