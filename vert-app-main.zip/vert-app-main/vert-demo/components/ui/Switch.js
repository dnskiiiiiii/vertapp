"use client";

// components/ui/Switch.js — ON OR OFF, IN PLACE
// ==============================================================================
// The Scheduled list's on/off (research/2026-10-27-w3-build/scheduled-spec.md: "●" on,
// "○" off). A <button role="switch"> with `aria-checked`, named by `label`: the track
// carries no words of its own. On is drawn in ink, never the accent: turning a routine
// on is a setting, not a write to the books (tokens.css, "the accent means this writes").
// `busy` keeps it pressable-looking and ignores presses while the change is in flight.

export function Switch({ checked = false, onChange, label, busy = false, className, id }) {
  if (typeof label !== "string" || !label.trim()) throw new TypeError("Switch: label needed");
  return (
    <button
      type="button"
      role="switch"
      id={id}
      className={["switch", className].filter(Boolean).join(" ")}
      aria-checked={checked ? "true" : "false"}
      aria-label={label}
      aria-busy={busy ? "true" : undefined}
      data-ui="Switch"
      onClick={(event) => {
        event.stopPropagation();
        if (busy || !onChange) return;
        onChange(!checked);
      }}
    >
      <span className="switch-thumb" aria-hidden="true" />
    </button>
  );
}
