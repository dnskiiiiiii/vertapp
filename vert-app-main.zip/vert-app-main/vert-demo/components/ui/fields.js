"use client";

// components/ui/fields.js — THE VALIDATION KIT
// ==============================================================================
// Spec §5.2 and §11.6; audit UI-015, UI-034, UI-052.
//
// Four rules, the same in every form — a card's closing balance, the bank rec's
// questions in the chat, the sign-in code:
//
//   1. VALIDATE ON BLUR, NOT ON SUBMIT, AND NEVER DISABLE SUBMIT TO SAY SO. A disabled
//      submit with no field marked is the defect UI-015 found on four panels: the person
//      cannot see what is wrong. The field says what is wrong, under itself, as soon as
//      they leave it.
//   2. THE MESSAGE BELONGS TO THE FIELD. It sits under the input, is joined to it with
//      `aria-describedby`, and marks it `aria-invalid`. A server refusal is mapped onto
//      the field it names (`fieldErrorsFromDetail`), not dropped in a banner above.
//   3. TYPING CLEARS IT. The message was about the old value.
//   4. INPUT IS NEVER DISCARDED ON ERROR (UI-052). Nothing here resets a value.
//   5. A REFUSAL TAKES FOCUS AND IS ANNOUNCED (design-fix-2 DA2-047). The message is
//      `role="alert"`, and when the caller hands a field an error (a failed submit), the
//      field's input takes focus, so a keyboard or screen-reader user lands on what to
//      fix. With `reserveError`, one footnote line is held under the field even with no
//      message, so nothing below it moves when one appears (DA2-079).
//
// PEOPLE TYPE DOLLARS, PICK MONTHS AND CHOOSE ACCOUNTS (UI-034). The bank rec form
// used to ask for cents, `YYYY-MM` and `csv:` names. MoneyField reads "$12,345.67" and
// hands its caller cents; MonthField offers the months the engine has, by name.

import { useEffect, useId, useRef, useState } from "react";

import { periodLabel } from "@/lib/period";

/**
 * The shared frame: label, the control, a hint, the message. `children` receives the
 * ids it must wire, so a custom control is as accessible as the stock ones.
 */
function FieldFrame({ id, label, hint, error, children, className, trailing, reserveError = false }) {
  const hintId = hint ? `${id}-hint` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const describedBy = [errorId, hintId].filter(Boolean).join(" ") || undefined;
  return (
    <div className={["form-field", error ? "field-invalid" : null, className].filter(Boolean).join(" ")} data-ui="Field">
      <label className="field-label" htmlFor={id}>
        {label}
      </label>
      <div className="field-box">
        {children({ describedBy, invalid: Boolean(error) })}
        {trailing}
      </div>
      {error ? (
        <p className={["field-error", reserveError ? "field-error-slot" : null].filter(Boolean).join(" ")} id={errorId} role="alert">
          {error}
        </p>
      ) : reserveError ? (
        <p className="field-error-slot" aria-hidden="true" />
      ) : null}
      {hint ? (
        <p className="field-hint" id={hintId}>
          {hint}
        </p>
      ) : null}
    </div>
  );
}

/**
 * The blur-validation state every field shares. `error` from the caller (a server
 * refusal mapped with `fieldErrorsFromDetail`) wins until the person types; a local
 * `validate(value)` result shows on blur. Both clear on input.
 */
function useFieldState({ error, validate, onBlur, onChange }) {
  const [local, setLocal] = useState(null);
  // The server message the person has since typed over. Held by value, and released
  // when the caller clears `error` (as it does while a resubmission is in flight), so
  // the same refusal arriving again is shown again.
  const [dismissed, setDismissed] = useState(null);
  if (!error && dismissed !== null) setDismissed(null);
  const shown = (error && error !== dismissed ? error : null) || local || null;

  return {
    shown,
    handlers: {
      onBlur(event) {
        if (validate) setLocal(validate(event.target.value) || null);
        if (onBlur) onBlur(event);
      },
      onChange(event) {
        setLocal(null);
        if (error) setDismissed(error);
        if (onChange) onChange(event);
      },
    },
  };
}

/** Focus `ref`'s element whenever the caller hands the field a new error (DA2-047). */
function useFocusOnError(error) {
  const ref = useRef(null);
  useEffect(() => {
    if (error && ref.current && typeof ref.current.focus === "function") ref.current.focus();
  }, [error]);
  return ref;
}

/** A labelled text input. Any input attribute passes through (`name`, `value`, …). */
export function Field({ label, hint, error, validate, id, className, trailing, onBlur, onChange, reserveError, ...input }) {
  const auto = useId();
  const fieldId = id || auto;
  const state = useFieldState({ error, validate, onBlur, onChange });
  const inputRef = useFocusOnError(error);
  return (
    <FieldFrame id={fieldId} label={label} hint={hint} error={state.shown} className={className} trailing={trailing} reserveError={reserveError}>
      {({ describedBy, invalid }) => (
        <input
          ref={inputRef}
          id={fieldId}
          // WIG G8 (ui-pass-1 output-ui #37): every field has a name and says whether the
          // browser may fill it. Off unless the caller says otherwise (sign-in passes
          // current-password); both are defaults the caller's own props replace.
          name={fieldId}
          autoComplete="off"
          className="field-input"
          aria-invalid={invalid ? "true" : undefined}
          aria-describedby={describedBy}
          {...input}
          onBlur={state.handlers.onBlur}
          onChange={state.handlers.onChange}
        />
      )}
    </FieldFrame>
  );
}

// "12,345.67", "$12,345.67", "12345", "-150", "(150.00)". Whole dollars and cents, as a
// person writes them; never scientific notation, never more than two decimals.
const DOLLARS = /^\(?-?\$?\s*(\d{1,3}(,\d{3})+|\d+)(\.\d{1,2})?\)?$/;

/**
 * Typed dollars → integer cents, or null when the text is not an amount.
 *
 * Exact, by construction: the sign and digits are joined as a string and parsed once as an
 * integer, so no binary fraction ever stands between what was typed and what is sent
 * ("0.29" is 29 cents, not 28.999…). A leading minus or accounting parentheses make it
 * negative. This is a data-entry boundary; nothing rendered is computed from it.
 */
export function parseDollars(text) {
  const raw = String(text ?? "").trim();
  if (!raw || !DOLLARS.test(raw)) return null;
  const negative = raw.startsWith("-") || raw.includes("(-") || (raw.startsWith("(") && raw.endsWith(")"));
  const unsigned = raw.replace(/[()$\s,-]/g, "");
  const [whole, fraction = ""] = unsigned.split(".");
  // The sign is part of the string that is parsed, so no operator ever touches the
  // amount on its way in (the no-arithmetic guard holds the view layer to that).
  const cents = Number.parseInt(`${negative ? "-" : ""}${whole}${fraction.padEnd(2, "0")}`, 10);
  return Number.isSafeInteger(cents) ? cents : null;
}

export const DOLLARS_INVALID = "Enter an amount in dollars, like 12,345.67.";
export const DOLLARS_TOO_LARGE = "That amount is too large for Vert to record. Check the digits.";

/**
 * Why typed dollars can't be sent, in words, or null when they can (empty is the
 * caller's to judge). Verify pass 9, D22: an amount written correctly but past what
 * whole cents can hold exactly ("99999999999999") was told "Enter an amount in dollars",
 * which it already was; parseDollars answers null for both, so the shape is read here.
 */
export function dollarsError(text) {
  const raw = String(text ?? "").trim();
  if (!raw) return null;
  if (parseDollars(raw) !== null) return null;
  return DOLLARS.test(raw) ? DOLLARS_TOO_LARGE : DOLLARS_INVALID;
}

/**
 * Dollars in, cents out. The visible text is the person's own and is never rewritten;
 * `onValueChange({ text, cents })` hands the caller cents (null while the text is not
 * an amount). With `name`, a hidden `<name>Cents` input carries the cents in a plain
 * form post, so a server action receives an integer and never parses a string.
 */
export function MoneyField({ label, hint, error, name, onValueChange, required, id, defaultValue, value, ...input }) {
  const auto = useId();
  const fieldId = id || auto;
  const [text, setText] = useState(value ?? defaultValue ?? "");
  const shownText = value ?? text;
  const cents = parseDollars(shownText);
  const inputRef = useFocusOnError(error);
  const state = useFieldState({
    error,
    validate(v) {
      if (!String(v).trim()) return required ? "Enter an amount in dollars." : null;
      return dollarsError(v);
    },
    onChange(event) {
      setText(event.target.value);
      if (onValueChange) onValueChange({ text: event.target.value, cents: parseDollars(event.target.value) });
    },
  });
  return (
    <FieldFrame id={fieldId} label={label} hint={hint} error={state.shown} className="field-money">
      {({ describedBy, invalid }) => (
        <>
          <span className="field-prefix" aria-hidden="true">$</span>
          <input
            ref={inputRef}
            id={fieldId}
            className="field-input"
            inputMode="decimal"
            autoComplete="off"
            aria-invalid={invalid ? "true" : undefined}
            aria-describedby={describedBy}
            value={shownText}
            required={required}
            {...input}
            onBlur={state.handlers.onBlur}
            onChange={state.handlers.onChange}
          />
          {name ? <input type="hidden" name={`${name}Cents`} value={cents === null ? "" : String(cents)} /> : null}
          {name ? <input type="hidden" name={name} value={shownText} /> : null}
        </>
      )}
    </FieldFrame>
  );
}

/** A native select, labelled and validated like the rest. `options: [{value, label}]`. */
export function SelectField({ label, hint, error, options = [], placeholder, id, onBlur, onChange, ...select }) {
  const auto = useId();
  const fieldId = id || auto;
  const state = useFieldState({ error, onBlur, onChange });
  const selectRef = useFocusOnError(error);
  return (
    <FieldFrame id={fieldId} label={label} hint={hint} error={state.shown} className="field-select">
      {({ describedBy, invalid }) => (
        <select
          ref={selectRef}
          id={fieldId}
          name={fieldId}
          autoComplete="off"
          className="field-input"
          aria-invalid={invalid ? "true" : undefined}
          aria-describedby={describedBy}
          {...select}
          onBlur={state.handlers.onBlur}
          onChange={state.handlers.onChange}
        >
          {placeholder ? (
            <option value="" disabled>
              {placeholder}
            </option>
          ) : null}
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      )}
    </FieldFrame>
  );
}

/**
 * A month, picked by name from the months the engine has (`/close/periods`). The value
 * is the ISO month the API wants; the person only ever sees "September 2026".
 * `months: [{period, label?}]`.
 */
export function MonthField({ months = [], ...rest }) {
  const options = months.map((m) => ({ value: m.period, label: m.label || periodLabel(m.period) }));
  return <SelectField options={options} {...rest} />;
}

/**
 * The API's validation refusal → `{ fieldName: message }`.
 *
 * vert_api answers a bad request with `detail.errors: [{loc: [..., "field"], msg}]`
 * (FastAPI's shape). The last string in `loc` names the field. An entry that names no
 * field is returned under `_form`, so a caller can still show it once rather than drop
 * it. Messages are passed through unchanged: rewording them here would be a second
 * place that decides what a refusal says.
 */
export function fieldErrorsFromDetail(detail) {
  const errors = detail && Array.isArray(detail.errors) ? detail.errors : [];
  const out = {};
  for (const entry of errors) {
    const loc = Array.isArray(entry && entry.loc) ? entry.loc : [];
    const field = [...loc].reverse().find((part) => typeof part === "string" && part !== "body");
    const key = field || "_form";
    const message = String((entry && (entry.msg || entry.message)) || "").trim();
    if (message && !out[key]) out[key] = message;
  }
  return out;
}
