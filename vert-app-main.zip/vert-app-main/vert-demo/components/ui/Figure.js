"use client";

// components/ui/Figure.js — EVERY FIGURE OPENS ITS SOURCE
// ==============================================================================
// Spec §9.3 and §9.4.
//
// A <Figure> renders ENGINE CENTS through the one formatter (lib/format.js), with
// tabular numerals. It never adds, rounds or converts: the number on screen is the
// number the engine emitted, which the no-arithmetic guard holds everywhere.
//
// UNMEASURED IS NEVER ZERO. When the engine did not read a value (`measured: false`, or
// no cents at all) the figure is WORDS — "No September bank statement yet", "Not read
// yet" — and never "$0.00" and never a green state. The words are the caller's to
// choose, because only the caller knows what is missing; there is a plain default so
// an absence can never render as an empty span.
//
// With a `source`, the figure is a button that opens the SOURCE SHEET: the rows behind
// the number, where they came from, the ids under Details, and a "See all" link to
// Records. The affordance is quiet — an underline on hover and on focus only — because
// every figure has it, and a page of underlined numbers is a page of noise.
//
// THE MARKUP CARRIES THE BINDING (rubric C1). `figure` is the engine's reference for the
// number ("payout/po_2Bd/amount"), written as `data-figure`, and a read figure carries
// its integer as `data-cents`. A check can then hold the text on screen to the cents the
// engine emitted without parsing a formatted string, on Month-end, Records and the
// cards exactly as in the chat (components/chat/EventFigure.js). tests/figure-binding
// fails on any dollar amount rendered outside such an element.

import Link from "next/link";
import { createContext, useContext, useRef, useState } from "react";

import { formatMoney, moneyOrWords } from "@/lib/format";

import { Disclosure } from "./Disclosure";
import { Sheet } from "./Sheet";

/**
 * TRUE INSIDE ANOTHER CONTROL (verify pass 1: React hydration error 418 on every conversation page).
 * A delivered file's card is one <button>; the key figure on its meta line was a
 * <button> of its own, a button inside a button. The browser's parser closes the outer
 * button at the inner one, so the server's HTML and the client's tree differ and React
 * throws hydration error 418, then redraws the whole conversation. A control that
 * holds figures provides `true`; every figure under it is text with its binding, never
 * a second control.
 */
export const InsideControl = createContext(false);

// An unknown figure is said in words, never $0.00 or blank; the words are a bookkeeper's,
// "Not available yet", not the engine's "Not read yet" (bug bash 10 Oct 2026).
export function Figure({ cents, measured = true, unread = "Not available yet", style = "prose", source, className, figure = "" }) {
  const [open, setOpen] = useState(false);
  // The sheet is mounted on first open and kept after, so a page of figures does not
  // carry a closed sheet per number, and a sheet closed mid-opening still reverses.
  const [used, setUsed] = useState(false);
  const trigger = useRef(null);
  const inside = useContext(InsideControl);
  const known = measured !== false && typeof cents === "number" && Number.isFinite(cents);
  const text = moneyOrWords({ cents, measured }, unread, { style });
  const classes = ["figure", known ? "num" : "figure-unread", className].filter(Boolean).join(" ");
  // Quoted keys: a hyphenated attribute beside a money name reads as a subtraction to
  // tests/no-arithmetic.test.js.
  const binding = { "data-figure": figure, "data-cents": known ? String(cents) : undefined, "data-measured": known ? "true" : "false" };
  // A figure is never machine-translated (design-fix-2 §3.5, DA2-083: WIG G20).
  if (known) binding.translate = "no";

  if (!known || !source || inside) {
    return (
      <span className={classes} data-ui="Figure" {...binding}>
        {text}
      </span>
    );
  }

  return (
    <>
      <button
        type="button"
        ref={trigger}
        className={`${classes} figure-source`}
        aria-haspopup="dialog"
        aria-expanded={open ? "true" : "false"}
        // A number alone is not a name for a control (U68): it says what pressing does.
        aria-label={`${text}, where it comes from`}
        onClick={() => {
          setUsed(true);
          setOpen(true);
        }}
        data-ui="Figure"
        {...binding}
      >
        {text}
      </button>
      {used ? <SourceSheet open={open} onClose={() => setOpen(false)} {...source} /> : null}
    </>
  );
}

/**
 * A line of words with ONE engine amount in it — "Stripe payout · 2 Jul · $7,000.00",
 * "Can't approve until the $12.34 gap is explained" — with that amount bound. The line
 * is built by the one formatter (lib/format.js `payoutLine`, `bankLineLabel`), so the
 * amount is found in it by formatting the same cents the same way, and only that span
 * becomes a <Figure>; the words either side stay text. A line whose amount was not
 * read carries words there instead, and has nothing to bind, so it is returned as is.
 */
export function FigureInText({ text, cents, measured = true, figure = "", style = "prose" }) {
  const line = String(text ?? "");
  const known = measured !== false && typeof cents === "number" && Number.isFinite(cents);
  const shown = known ? formatMoney(cents, { style }) : null;
  const at = shown ? line.indexOf(shown) : -1;
  if (at === -1) return line;
  return (
    <>
      {line.slice(0, at)}
      <Figure cents={cents} style={style} figure={figure} />
      {line.slice(at + shown.length)}
    </>
  );
}

/**
 * The rows behind a number (spec §9.3). `rows: [{label, detail?, cents?, measured?, minus?}]`,
 * each a line from a source the engine read; `from` names that source in words;
 * `ids` are the engineering references, shown only under Details; `seeAll` is the
 * way on to Records ("See all payouts ›").
 */
export function SourceSheet({ open, onClose, title = "Where this comes from", from, rows = [], ids = [], seeAll }) {
  return (
    <Sheet open={open} onClose={onClose} side="right" title={title}>
      {from ? <p className="source-from t-footnote">{from}</p> : null}
      {rows.length ? (
        <ul className="source-rows">
          {rows.map((row, i) => (
            <li key={row.key || i} className="source-row">
              <span className="source-row-label">
                {row.label}
                {row.detail ? <span className="source-row-detail">{row.detail}</span> : null}
              </span>
              {"cents" in row || "measured" in row ? (
                <span className="source-row-amount">
                  {/* A figure below zero in its own right is drawn as the tie-out drew it:
                      its minus, then its amount (W7-1). */}
                  {row.minus ? "−" : null}
                  <Figure
                    cents={row.cents}
                    measured={row.measured}
                    unread={row.unread || "Not available yet"}
                    // ONE SCREEN CONVENTION (Q06/Q07, S-UI-11): the sheet sits beside a
                    // sentence that says "−$4,112.00"; it said "($4,112.00)". Minus on
                    // screen; the workbook keeps its accounting parentheses.
                    style="prose"
                    figure={row.figure || `source/${row.key || i}`}
                  />
                </span>
              ) : null}
            </li>
          ))}
        </ul>
      ) : (
        <p className="t-body">Vert found no rows behind this figure.</p>
      )}
      {ids.length ? (
        <Disclosure summary="Details">
          <ul className="source-ids">
            {ids.map((id) => (
              <li key={id}>
                <code>{id}</code>
              </li>
            ))}
          </ul>
        </Disclosure>
      ) : null}
      {seeAll && seeAll.href ? (
        <p className="source-more">
          <Link href={seeAll.href} className="link">
            {seeAll.label || "See all"} ›
          </Link>
        </p>
      ) : null}
    </Sheet>
  );
}

// Re-exported so a caller formatting a figure outside a <Figure> reaches the same
// formatter rather than a second one.
export { formatMoney };
