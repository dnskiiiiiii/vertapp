// components/ui/icons.js — THE ONE ICON SET
// ==============================================================================
// Founder decision D7 (10 Oct 2026); design-fix-2 spec §4; audit DA2-010. Every glyph in
// the app is Phosphor (`@phosphor-icons/react`, weight "regular"), imported HERE and
// nowhere else, under Vert's own names. The hand-drawn families that came before it
// (components/shell, components/je and components/reconcile each kept one, at eight
// different stroke widths) are now re-exports of this file, so their call sites keep
// working until each owner moves them here.
//
// SIZES (spec §4): 16 px by default; 14 px inside buttons and rows (the kit's CSS sizes a
// button's glyph); 12 px for a trailing chevron and an inline status; 20 px in the
// sidebar nav; 32 px in a 40 px file tile. Pass `size` where a call site needs another.
//
// WHY THE `ssr` BUILD. Phosphor's default build reads a React context for its defaults,
// which makes every icon a client component. The `ssr` build takes the same props with
// no context, so an icon renders in a server component (the 404, the loading screens)
// and in a client one alike. The defaults that context would carry (16 px, regular) are
// set by the wrapper below instead, once, for every icon: so there is no IconContext
// provider to mount, and nothing a missing provider could silently change.
//
// ACCESSIBILITY (spec §4): every icon is `aria-hidden` and unfocusable. When an icon is
// the only content of a button, the BUTTON carries the name (`IconButton` requires a
// `label`); a glyph on its own is a guess.
//
// Allowed hand-drawn SVG elsewhere (tests/tokens.test.js holds the list): the bridge
// chart and the progress and mini bars (data drawings), and the source logos
// (components/ui/SourceLogo.js, drawn from static files in public/sources/). The mark is
// an image. Everything else is here.

import { ArrowClockwise } from "@phosphor-icons/react/dist/ssr/ArrowClockwise";
import { ArrowLineDown } from "@phosphor-icons/react/dist/ssr/ArrowLineDown";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr/ArrowRight";
import { ArrowSquareOut } from "@phosphor-icons/react/dist/ssr/ArrowSquareOut";
import { ArrowUp } from "@phosphor-icons/react/dist/ssr/ArrowUp";
import { ArrowsOutSimple } from "@phosphor-icons/react/dist/ssr/ArrowsOutSimple";
import { Article } from "@phosphor-icons/react/dist/ssr/Article";
import { Bank } from "@phosphor-icons/react/dist/ssr/Bank";
import { Envelope } from "@phosphor-icons/react/dist/ssr/Envelope";
import { BookOpen } from "@phosphor-icons/react/dist/ssr/BookOpen";
import { Buildings } from "@phosphor-icons/react/dist/ssr/Buildings";
import { Calculator } from "@phosphor-icons/react/dist/ssr/Calculator";
import { CalendarBlank } from "@phosphor-icons/react/dist/ssr/CalendarBlank";
import { CalendarCheck } from "@phosphor-icons/react/dist/ssr/CalendarCheck";
import { CaretDown } from "@phosphor-icons/react/dist/ssr/CaretDown";
import { CaretLeft } from "@phosphor-icons/react/dist/ssr/CaretLeft";
import { CaretRight } from "@phosphor-icons/react/dist/ssr/CaretRight";
import { CaretUpDown } from "@phosphor-icons/react/dist/ssr/CaretUpDown";
import { ChartBar } from "@phosphor-icons/react/dist/ssr/ChartBar";
import { ChatCircle } from "@phosphor-icons/react/dist/ssr/ChatCircle";
import { Check } from "@phosphor-icons/react/dist/ssr/Check";
import { CheckCircle } from "@phosphor-icons/react/dist/ssr/CheckCircle";
import { Circle } from "@phosphor-icons/react/dist/ssr/Circle";
import { CircleDashed } from "@phosphor-icons/react/dist/ssr/CircleDashed";
import { CircleNotch } from "@phosphor-icons/react/dist/ssr/CircleNotch";
import { Clock } from "@phosphor-icons/react/dist/ssr/Clock";
import { CreditCard } from "@phosphor-icons/react/dist/ssr/CreditCard";
import { CurrencyCircleDollar } from "@phosphor-icons/react/dist/ssr/CurrencyCircleDollar";
import { CurrencyDollar } from "@phosphor-icons/react/dist/ssr/CurrencyDollar";
import { DotsThree } from "@phosphor-icons/react/dist/ssr/DotsThree";
import { DotsThreeVertical } from "@phosphor-icons/react/dist/ssr/DotsThreeVertical";
import { DownloadSimple } from "@phosphor-icons/react/dist/ssr/DownloadSimple";
import { Eye } from "@phosphor-icons/react/dist/ssr/Eye";
import { EyeSlash } from "@phosphor-icons/react/dist/ssr/EyeSlash";
import { FileCsv } from "@phosphor-icons/react/dist/ssr/FileCsv";
import { FileText } from "@phosphor-icons/react/dist/ssr/FileText";
import { FileXls } from "@phosphor-icons/react/dist/ssr/FileXls";
import { FileZip } from "@phosphor-icons/react/dist/ssr/FileZip";
import { Funnel } from "@phosphor-icons/react/dist/ssr/Funnel";
import { Hash } from "@phosphor-icons/react/dist/ssr/Hash";
import { Info } from "@phosphor-icons/react/dist/ssr/Info";
import { List } from "@phosphor-icons/react/dist/ssr/List";
import { ListChecks } from "@phosphor-icons/react/dist/ssr/ListChecks";
import { ListDashes } from "@phosphor-icons/react/dist/ssr/ListDashes";
import { MagnifyingGlass } from "@phosphor-icons/react/dist/ssr/MagnifyingGlass";
import { Notebook } from "@phosphor-icons/react/dist/ssr/Notebook";
import { NotePencil } from "@phosphor-icons/react/dist/ssr/NotePencil";
import { Paperclip } from "@phosphor-icons/react/dist/ssr/Paperclip";
import { Pause } from "@phosphor-icons/react/dist/ssr/Pause";
import { PencilSimple } from "@phosphor-icons/react/dist/ssr/PencilSimple";
import { Plug } from "@phosphor-icons/react/dist/ssr/Plug";
import { Plus } from "@phosphor-icons/react/dist/ssr/Plus";
import { Prohibit } from "@phosphor-icons/react/dist/ssr/Prohibit";
import { Question } from "@phosphor-icons/react/dist/ssr/Question";
import { Receipt } from "@phosphor-icons/react/dist/ssr/Receipt";
import { RadioButton } from "@phosphor-icons/react/dist/ssr/RadioButton";
import { Repeat } from "@phosphor-icons/react/dist/ssr/Repeat";
import { Rows } from "@phosphor-icons/react/dist/ssr/Rows";
import { ShareNetwork } from "@phosphor-icons/react/dist/ssr/ShareNetwork";
import { ShoppingBag } from "@phosphor-icons/react/dist/ssr/ShoppingBag";
import { SignOut } from "@phosphor-icons/react/dist/ssr/SignOut";
import { Star } from "@phosphor-icons/react/dist/ssr/Star";
import { User } from "@phosphor-icons/react/dist/ssr/User";
import { UserCheck } from "@phosphor-icons/react/dist/ssr/UserCheck";
import { UploadSimple } from "@phosphor-icons/react/dist/ssr/UploadSimple";
import { Users } from "@phosphor-icons/react/dist/ssr/Users";
import { Warning } from "@phosphor-icons/react/dist/ssr/Warning";
import { WarningCircle } from "@phosphor-icons/react/dist/ssr/WarningCircle";
import { X } from "@phosphor-icons/react/dist/ssr/X";

/** Wrap a Phosphor glyph with Vert's defaults: 16 px, regular, hidden from assistive tech. */
function vert(Glyph, name, defaults = {}) {
  function Icon({ size = defaults.size ?? 16, weight = defaults.weight ?? "regular", ...props }) {
    return <Glyph size={size} weight={weight} aria-hidden="true" focusable="false" data-icon={name} {...props} />;
  }
  Icon.displayName = name;
  return Icon;
}

/* ── navigation and controls ─────────────────────────────────────────────────────── */
export const IconBack = vert(CaretLeft, "IconBack");
export const IconCaretLeft = vert(CaretLeft, "IconCaretLeft");
/** A trailing chevron: 12 px, after its words with a 4 px gap. */
export const IconCaretRight = vert(CaretRight, "IconCaretRight", { size: 12 });
/** A disclosure's caret: turns 180° on the snappy spring when open. */
export const IconCaretDown = vert(CaretDown, "IconCaretDown", { size: 12 });
export const IconCaretUpDown = vert(CaretUpDown, "IconCaretUpDown");
export const IconMenu = vert(List, "IconMenu");
export const IconClose = vert(X, "IconClose");
export const IconMore = vert(DotsThree, "IconMore");
export const IconMoreVertical = vert(DotsThreeVertical, "IconMoreVertical");
export const IconSearch = vert(MagnifyingGlass, "IconSearch");
export const IconNewChat = vert(NotePencil, "IconNewChat");
export const IconSend = vert(ArrowUp, "IconSend");
export const IconArrowRight = vert(ArrowRight, "IconArrowRight");
export const IconAdd = vert(Plus, "IconAdd");
export const IconAttach = vert(Paperclip, "IconAttach");
export const IconEdit = vert(PencilSimple, "IconEdit");
export const IconDownload = vert(DownloadSimple, "IconDownload");
export const IconUpload = vert(UploadSimple, "IconUpload");
export const IconExternal = vert(ArrowSquareOut, "IconExternal");
export const IconRunAgain = vert(ArrowClockwise, "IconRunAgain");
export const IconExpand = vert(ArrowsOutSimple, "IconExpand");
export const IconFilter = vert(Funnel, "IconFilter");
export const IconCheck = vert(Check, "IconCheck");
export const IconEye = vert(Eye, "IconEye");
export const IconEyeOff = vert(EyeSlash, "IconEyeOff");
export const IconPause = vert(Pause, "IconPause");
export const IconSignOut = vert(SignOut, "IconSignOut");
export const IconCalendar = vert(CalendarBlank, "IconCalendar");
export const IconRepeat = vert(Repeat, "IconRepeat");
export const IconPerson = vert(User, "IconPerson");
export const IconPersonCheck = vert(UserCheck, "IconPersonCheck");
export const IconStar = vert(Star, "IconStar");
export const IconShare = vert(ShareNetwork, "IconShare");
export const IconRows = vert(Rows, "IconRows");
export const IconRowsCompact = vert(ListDashes, "IconRowsCompact");
export const IconList = vert(List, "IconList");
export const IconHash = vert(Hash, "IconHash");
export const IconDollar = vert(CurrencyDollar, "IconDollar");
export const IconCurrency = vert(CurrencyCircleDollar, "IconCurrency");
export const IconClock = vert(Clock, "IconClock");
export const IconInTransit = vert(ArrowLineDown, "IconInTransit");
export const IconChat = vert(ChatCircle, "IconChat");
export const IconInfo = vert(Info, "IconInfo");
export const IconQuestion = vert(Question, "IconQuestion");
/** A pending navigation on the clicked row (DA2-030): turns while the route loads. */
export const IconSpinner = vert(CircleNotch, "IconSpinner");

/* ── destinations (spec §4: month-end / clients / connections / people) ─────────── */
export const IconMonthEnd = vert(CalendarCheck, "IconMonthEnd", { size: 20 });
export const IconClients = vert(Buildings, "IconClients", { size: 20 });
export const IconConnections = vert(Plug, "IconConnections", { size: 20 });
export const IconPeople = vert(Users, "IconPeople", { size: 20 });
export const IconBills = vert(Receipt, "IconBills", { size: 20 });

/* ── status (design-fix-2 §2.3): always beside the word ─────────────────────────── */
export const IconStatusAttention = vert(Circle, "IconStatusAttention", { size: 8, weight: "fill" });
export const IconStatusWorking = vert(CircleDashed, "IconStatusWorking", { size: 12 });
export const IconStatusWaiting = vert(Circle, "IconStatusWaiting", { size: 12 });
export const IconStatusDone = vert(CheckCircle, "IconStatusDone", { size: 12, weight: "fill" });
export const IconWarning = vert(Warning, "IconWarning");
export const IconProblem = vert(WarningCircle, "IconProblem", { size: 14 });
export const IconBlocked = vert(Prohibit, "IconBlocked");
/** An option row's radio: filled when chosen, a plain ring when not (§2.5). */
export const IconRadioOn = vert(RadioButton, "IconRadioOn", { weight: "fill" });
export const IconRadioOff = vert(Circle, "IconRadioOff");

/* ── file types (spec §4) ──────────────────────────────────────────────────────────── */
export const IconWorkbook = vert(FileXls, "IconWorkbook");
export const IconPlan = vert(ListChecks, "IconPlan");
export const IconBridge = vert(ChartBar, "IconBridge");
export const IconCommentary = vert(Article, "IconCommentary");
export const IconSkill = vert(BookOpen, "IconSkill");
export const IconJournal = vert(Notebook, "IconJournal");
export const IconBudget = vert(Calculator, "IconBudget");
export const IconFile = vert(FileText, "IconFile");
export const IconCsv = vert(FileCsv, "IconCsv");
export const IconArchive = vert(FileZip, "IconArchive");

/* ── sources (a generic source; brand marks are SourceLogo) ────────────────────────── */
export const IconEmail = vert(Envelope, "IconEmail");
export const IconBank = vert(Bank, "IconBank");
export const IconPayments = vert(CreditCard, "IconPayments");
export const IconLedger = vert(Notebook, "IconLedger");
export const IconShop = vert(ShoppingBag, "IconShop");
export const IconStatement = vert(FileCsv, "IconStatement");

/** Every name above, for the guard that holds the app to this one set. */
export const ICON_NAMES = Object.freeze([
  "IconBack", "IconCaretLeft", "IconCaretRight", "IconCaretDown", "IconCaretUpDown", "IconMenu", "IconClose",
  "IconMore", "IconMoreVertical", "IconSearch", "IconNewChat", "IconSend", "IconArrowRight", "IconAdd",
  "IconAttach", "IconEdit", "IconDownload", "IconExternal", "IconRunAgain", "IconExpand", "IconFilter",
  "IconCheck", "IconEye", "IconEyeOff", "IconPause", "IconSignOut", "IconCalendar", "IconRepeat",
  "IconPerson", "IconPersonCheck", "IconStar", "IconShare", "IconRows", "IconRowsCompact", "IconList",
  "IconHash", "IconDollar", "IconCurrency", "IconClock", "IconInTransit", "IconChat", "IconInfo",
  "IconQuestion", "IconSpinner", "IconMonthEnd", "IconClients", "IconConnections", "IconPeople",
  "IconStatusAttention", "IconStatusWorking", "IconStatusWaiting", "IconStatusDone", "IconWarning",
  "IconProblem", "IconBlocked", "IconRadioOn", "IconRadioOff", "IconWorkbook", "IconPlan", "IconBridge",
  "IconCommentary", "IconSkill", "IconJournal", "IconBudget", "IconFile", "IconCsv", "IconBank",
  "IconPayments", "IconLedger", "IconShop", "IconStatement", "IconArchive", "IconEmail", "IconUpload",
  "IconBills",
]);
