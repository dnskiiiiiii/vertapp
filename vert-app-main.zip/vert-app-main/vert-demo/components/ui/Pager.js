"use client";

// components/ui/Pager.js — "1 of 13", AND THE TWO WAYS THROUGH
// ==============================================================================
// Design-fix-2 spec §5.6, §7.1; audits DA2-008, DA2-037. There were three pager variants
// for the one decision deck. This is the one: both chevrons always present (the earlier
// one disabled at the first item, the later one at the last — disabled, still focusable,
// never hidden, so the control never shifts), and the position as "1 of 13" with
// non-breaking spaces, tabular. It sits in the card head; below a 520 px container
// width it takes its own row above the title (kit.css, a container query).

import { IconCaretLeft, IconCaretRight } from "@/components/ui/icons";
import { formatPosition } from "@/lib/format";

export function Pager({ index, count, onPrev, onNext, label = "Decision", className }) {
  if (!Number.isInteger(count) || count < 1) return null;
  const at = Math.min(Math.max(1, index), count);
  const first = at <= 1;
  const last = at >= count;
  return (
    <nav className={["pager", className].filter(Boolean).join(" ")} aria-label={`${label}s`} data-ui="Pager">
      <button
        type="button"
        className="pager-btn"
        aria-label={`Previous ${label.toLowerCase()}`}
        aria-disabled={first ? "true" : undefined}
        onClick={first ? undefined : onPrev}
      >
        <IconCaretLeft size={14} />
      </button>
      <span className="pager-pos num" aria-live="polite">
        {formatPosition(at, count)}
      </span>
      <button
        type="button"
        className="pager-btn"
        aria-label={`Next ${label.toLowerCase()}`}
        aria-disabled={last ? "true" : undefined}
        onClick={last ? undefined : onNext}
      >
        <IconCaretRight size={14} />
      </button>
    </nav>
  );
}
