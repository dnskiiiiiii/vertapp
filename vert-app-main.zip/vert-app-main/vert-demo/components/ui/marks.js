// components/ui/marks.js — THE SMALL MARKS: STATUS, META, BEST GUESS, KEY CAP, SKELETON, PROGRESS
// ==============================================================================
// Server-safe: no hooks, no handlers. Each of these draws something the spec keeps to
// exactly one form, so there is exactly one component for it.

import { STATUS_WORDS, statusStyle } from "@/lib/status";
import {
  IconStatusAttention,
  IconStatusDone,
  IconStatusWaiting,
  IconStatusWorking,
} from "@/components/ui/icons";

/** The glyph for each status style (design-fix-2 §2.3). */
const GLYPHS = {
  "status-attention": IconStatusAttention, // Circle, filled, 8 px
  "status-working": IconStatusWorking, // CircleDashed, 12 px, turns once per 1.2 s
  "status-neutral": IconStatusWaiting, // Circle, regular, 12 px
  "status-done": IconStatusDone, // CheckCircle, filled, 12 px
};

/**
 * One of the four status words with its mark (design-fix-2 §2.3): a Phosphor glyph and the
 * word, caption 500, in the status's own ink, with NO FILL AND NO BORDER. Done is a filled
 * tick in a quiet neutral ink, never green and never a chip: the evergreen means "this
 * writes" and nothing else (founder decisions D1/D3).
 *
 * The WORD IS ALWAYS PRESENT. Colour never carries a status alone (UI-040): the glyph
 * shapes differ, and the word is printed — or, with `compact`, kept for assistive tech
 * where a list shows the glyph only. `reason` follows the word ("Waiting · on its way to
 * the bank").
 *
 * A word outside the four throws, through `statusStyle`, rather than drawing a fifth
 * status in a neutral grey (lib/status.js says why). A thing that is not a task's status
 * ("Not checked", "Draft", "Recording only") is a `Meta`, never a StatusMark (DA2-029).
 *
 * `chip` is accepted for the callers that still pass it and draws the same mark: the
 * soft-tint pill is gone (DA2-004).
 */
export function StatusMark({ word, reason, compact = false, chip = false, className }) {
  const style = statusStyle(word);
  const Glyph = GLYPHS[style];
  const cls = ["status-mark", style, compact ? "status-compact" : null, chip ? "status-chip" : null, className];
  return (
    <span className={cls.filter(Boolean).join(" ")} data-ui="StatusMark">
      <span className="status-glyph" aria-hidden="true">
        <Glyph size="100%" />
      </span>
      <span className={compact ? "sr-only" : "status-word"}>{word}</span>
      {reason ? <span className="status-reason"> · {reason}</span> : null}
    </span>
  );
}
StatusMark.WORDS = STATUS_WORDS;

/**
 * A state that is NOT one of the four task statuses (design-fix-2 §2.3, DA2-029): "Not
 * checked", "Not started", "Draft", "Inactive", "Not imported yet". The secondary ink,
 * caption 500, with an optional 12 px neutral glyph (pass an icon element as `icon`).
 */
export function Meta({ children, icon = null, className, ...rest }) {
  return (
    <span className={["meta", className].filter(Boolean).join(" ")} data-ui="Meta" {...rest}>
      {icon}
      <span>{children}</span>
    </span>
  );
}

// The only mark a model's reading ever carries (spec §9.1, §13.1). Exact results are
// unmarked, because exact is the default. Render it only when the event's
// `basis === "suggested"`; the component takes no props so nobody can re-word it. It is
// drawn as a quiet inline tag (kit.css .best-guess), never in a warning colour (DA2-050).
//
// COMPLETE WORDS ABOUT WHAT IS ABOVE IT, AND NEVER ON ITS OWN (bug bash 10 Oct 2026).
// "Vert's best guess: check this" read as a label introducing something, and on an
// answer with no verdict and no facts the screen showed it followed by nothing. Now it
// is two short sentences about the content it sits under (five words, as before, so a
// card stays within its word budget), and a caller draws it only when `guessQualifies`
// finds that content.
export const BEST_GUESS_TEXT = "Vert's best guess. Check it.";

/**
 * True when there is something on screen for the best-guess mark to qualify: any part
 * that is a non-blank string, a non-empty list, or another drawn element. A mark over
 * nothing is a dangling claim, so with no part it is not drawn.
 */
export function guessQualifies(...parts) {
  return parts.some((p) => (typeof p === "string" ? p.trim().length > 0 : Array.isArray(p) ? p.length > 0 : p != null && p !== false));
}

export function BestGuess() {
  return (
    <span className="best-guess" data-ui="BestGuess">
      {BEST_GUESS_TEXT}
    </span>
  );
}

/** A key cap: a 20 px chip in the UI face. */
export function Kbd({ children }) {
  return (
    <kbd className="kbd" data-ui="Kbd">
      {children}
    </kbd>
  );
}

/**
 * A key hint: one or more key caps and what they do ("↑↓ Move", "↵ Open", "Esc Close"),
 * laid out with a gap, never joined by middle dots (design-fix-2 §3.5, DA2-033).
 * `hints` is [{ keys: ["↑", "↓"], label: "Move" }, …].
 */
export function KbdHints({ hints, className }) {
  return (
    <span className={["kbd-hints", className].filter(Boolean).join(" ")} data-ui="KbdHints">
      {hints.map((hint) => (
        <span className="kbd-hint" key={hint.label}>
          {hint.keys.map((k) => (
            <Kbd key={k}>{k}</Kbd>
          ))}
          <span>{hint.label}</span>
        </span>
      ))}
    </span>
  );
}

/**
 * The shape of what is coming, while it comes (UI-016; design-fix-2 DA2-030). Blocks that
 * pulse in opacity once every 1.2 s, still under reduced motion; no shimmer and no
 * spinner. `label` is announced once.
 */
export function Skeleton({ lines = 3, label = "Loading", title = true }) {
  const rows = Array.from({ length: Math.max(1, lines) }, (_, i) => i);
  return (
    <div className="skeleton" role="status" aria-live="polite" data-ui="Skeleton">
      <span className="sr-only">{label}</span>
      {title ? <span className="skeleton-line skeleton-title" aria-hidden="true" /> : null}
      {rows.map((i) => (
        <span key={i} className="skeleton-line" aria-hidden="true" />
      ))}
    </div>
  );
}

/**
 * One block of a destination-shaped skeleton (a title, a bar, the ask box, a card). Size it
 * in rem: `width`, `height` and `radius` are CSS lengths (a token is fine). Decorative:
 * the surrounding `Skeleton`-role container announces the wait.
 */
export function SkeletonBlock({ width = "100%", height = "1rem", radius, className }) {
  const style = { "--sk-w": width, "--sk-h": height };
  if (radius) style["--sk-r"] = radius;
  return <span className={["skeleton-block", className].filter(Boolean).join(" ")} style={style} aria-hidden="true" data-ui="SkeletonBlock" />;
}

/**
 * How far the month has got (design-fix-2 §2.4). `done` and `total` come from the API's
 * counts and are drawn, never derived here — each segment's share is the count handed to
 * CSS as a flex weight; the words beside the bar are the caller's. 6 px, 2 px gaps, no
 * track: Done in its quiet bar ink, the rest as one waiting segment. With no total —
 * nothing measured yet — there is no bar at all rather than an empty one.
 *
 * `parts` draws a full segmented bar instead: { done, working, attention, waiting }, each a
 * count; a zero count draws no segment.
 */
/** The words for a segmented bar's parts, in its own order: "Done 3, Needs you 6, Waiting 2". Pure. */
export function progressPartsWords(parts) {
  if (!parts || typeof parts !== "object") return null;
  const order = [["done", "Done"], ["working", "Vert's working"], ["attention", "Needs you"], ["waiting", "Waiting"]];
  const said = order.map(([key, word]) => [word, Number(parts[key]) || 0]).filter(([, n]) => n > 0).map(([word, n]) => `${word} ${n}`);
  return said.length ? said.join(", ") : null;
}

export function ProgressBar({ done, total, label, className, parts }) {
  if (typeof total !== "number" || !Number.isFinite(total) || total <= 0) return null;
  if (typeof done !== "number" || !Number.isFinite(done) || done < 0) return null;
  const shown = Math.min(done, total);
  // NEVER COLOUR ALONE (verify pass 2 U53): a segmented bar says each segment's word and
  // count — as its value text for assistive tech and as its tooltip on a pointer — so
  // the colours are never the only way to tell Needs you from Waiting.
  const partsWords = parts ? progressPartsWords(parts) : null;
  return (
    <div
      className={["progress-segments", parts ? null : "progress-simple", className].filter(Boolean).join(" ")}
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={total}
      aria-valuenow={shown}
      aria-valuetext={partsWords || undefined}
      title={partsWords || undefined}
      aria-label={label}
      data-ui="ProgressBar"
      style={{ "--progress-done": shown, "--progress-of": total }}
    >
      {parts ? (
        ["done", "working", "attention", "waiting"]
          .map((part) => [part, Number(parts[part]) || 0])
          .filter(([, n]) => n > 0)
          .map(([part, n]) => <span key={part} className="progress-segment" data-part={part} style={{ "--seg": n }} aria-hidden="true" />)
      ) : (
        // Done's share is worked out by CSS from the two counts (kit.css .progress-simple);
        // the rest of the bar is the Waiting segment. The view layer subtracts nothing.
        <>
          {shown > 0 ? <span className="progress-segment" data-part="done" aria-hidden="true" /> : null}
          <span className="progress-segment" data-part="waiting" aria-hidden="true" />
        </>
      )}
    </div>
  );
}

/** The four status words in the strip's reading order, with the count key each reads. */
export const STRIP_WORDS = Object.freeze([
  { key: "done", word: "Done" },
  { key: "working", word: "Vert's working" },
  { key: "needsYou", word: "Needs you" },
  { key: "waiting", word: "Waiting" },
]);

/**
 * THE COUNTS LINE UNDER A PROGRESS STRIP (design-pass spec §6.8; checklist U53; verify
 * pass 1 F-8). Each word with work in it, as its StatusMark (glyph AND word) and its count:
 * "✓ Done 3 · ● Needs you 6 · ○ Waiting 4". The strip's segments are colour; this line is
 * what tells them apart in grayscale, in forced colours and to a screen reader, in the
 * segments' own order. Every count is the payload's; nothing here sums. Null when any of
 * the four is unmeasured (an unread count is never drawn as none).
 */
//
// `unit` names WHAT is counted, when a screen counts two kinds of thing (verify pass 5,
// W20): the Clients band counts TASKS by status ("Needs you 4") while its rows count
// DECISIONS ("5 decisions need you"), and two figures under one name read as one
// disagreeing with itself. With a unit the line leads with it ("Tasks ✓ Done 2 …").
export function StatusCounts({ counts, className, unit = null }) {
  if (!counts || !STRIP_WORDS.every((s) => Number.isInteger(counts[s.key]) && counts[s.key] >= 0)) return null;
  const shown = STRIP_WORDS.filter((s) => counts[s.key] > 0);
  if (!shown.length) return null;
  const named = typeof unit === "string" && unit.trim() ? unit.trim() : null;
  return (
    <ul className={["status-counts", className].filter(Boolean).join(" ")} data-ui="StatusCounts" aria-label={named ? `${named} by status` : undefined}>
      {named ? (
        <li className="status-counts-unit" aria-hidden="true" data-status-unit="">
          {named}
        </li>
      ) : null}
      {shown.map((s) => (
        <li key={s.key} className="status-counts-item" data-status-count={s.key}>
          <StatusMark word={s.word} />
          <span className="status-counts-n num">{counts[s.key]}</span>
        </li>
      ))}
    </ul>
  );
}
