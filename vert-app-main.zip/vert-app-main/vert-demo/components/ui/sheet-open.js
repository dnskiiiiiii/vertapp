"use client";

// components/ui/sheet-open.js — IS THE SHEET AROUND THIS STILL OPEN?
// ==============================================================================
// A Sheet keeps drawing what it last showed while it leaves (components/ui/Sheet.js), so
// a form inside it stays mounted after ✕. Staging browser walk 3, N10: a New journal
// typed into and discarded kept its "Leave site?" guard. The sheet says whether it is
// open; an unsaved-edit guard inside a closed one is off. Outside any sheet: true.

import { createContext } from "react";

export const SheetOpen = createContext(true);
