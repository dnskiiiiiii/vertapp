// components/ui/index.js — THE KIT
// ==============================================================================
// Spec §11.6; build plan §2.9. The seventeen names every screen of the agent workspace
// is built from. F2, F3 and F4 import them from here, so the names are the contract and
// were fixed at step 0 before any of this existed; what each one looks like, and the
// rule it enforces, lives in its own file:
//
//   Button, IconButton                   Button.js   commit / secondary / quiet / ink;
//                                                    a disabled control prints its reason
//   Segmented                            Segmented.js a radio group with a sliding thumb
//   Field, MoneyField, MonthField,       fields.js   blur validation, the message on
//   SelectField                                      the field, input never discarded
//   Sheet                                Sheet.js    right / bottom / left / modal
//   Disclosure                           Disclosure.js
//   StatusMark, Meta, BestGuess, Kbd,    marks.js    the four words, a glyph and a word
//   KbdHints, Skeleton, SkeletonBlock,               with no fill; Meta for a non-status
//   ProgressBar
//   Notice, NoticeLine                   Notice.js   feedback; the one-line notice
//   Pager                                Pager.js    "1 of 13" with both chevrons
//   SourceLogo                           SourceLogo.js a source's monochrome mark
//   DateField, TimeSlotSelect            DateField.js a month grid; 30-minute slots
//   Portal                               Portal.js   a layer lifted into <body>
//   Icon*                                icons.js    the one icon set (Phosphor)
//   Figure, SourceSheet                  Figure.js   engine cents, and their source
//   Notice                               Notice.js   the four kinds of feedback
//   Table                                Table.js    roving rows, stacked on a phone
//   RememberTick, RuleSaved              RememberTick.js the one Remember tick (opt-in rules)
//
// Styles are in app/styles/kit.css, drawn only from app/styles/tokens.css.

export { Button, IconButton } from "./Button";
export { DOLLARS_INVALID, DOLLARS_TOO_LARGE, Field, MoneyField, MonthField, SelectField, dollarsError, fieldErrorsFromDetail, parseDollars } from "./fields";
export { Sheet } from "./Sheet";
export { Disclosure } from "./Disclosure";
export { StatusMark, Meta, BestGuess, BEST_GUESS_TEXT, guessQualifies, Kbd, KbdHints, Skeleton, SkeletonBlock, ProgressBar, StatusCounts } from "./marks";
export { Figure, FigureInText, SourceSheet } from "./Figure";
export { Notice, NoticeLine, RECORDED_WORDS } from "./Notice";
export { Pager } from "./Pager";
export { SourceLogo, sourceKey } from "./SourceLogo";
export { DateField, TimeSlotSelect, TIME_SLOTS } from "./DateField";
export { Portal } from "./Portal";
export { Table } from "./Table";
export { Segmented } from "./Segmented";
export { Switch } from "./Switch";
export { RememberTick, RuleSaved } from "./RememberTick";
