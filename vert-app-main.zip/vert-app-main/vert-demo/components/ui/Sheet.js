"use client";

// components/ui/Sheet.js — THE ONE WAY ANYTHING SLIDES OVER THE PAGE
// ==============================================================================
// Spec §11.4 and §3.3; audit UI-005, UI-017, UI-049, UI-057. Four placements:
//
//   right   a parallel panel beside the work (the result pane at 700–1279 px, a
//           figure's source). No scrim: it separates to keep the flow, it does not
//           dim to demand focus (apple-design §12).
//   bottom  the phone's result sheet, with a grabber. Scrim.
//   left    the phone's sidebar. Scrim.
//   modal   the one confirmation this product has (posting to a ledger) and the
//           reject sheet. Scrim, centred, `aria-modal`, focus held inside.
//
// WHAT MAKES IT FEEL RIGHT, and what each rule is for:
//
//   · It ENTERS FROM OFF-SCREEN, EVERY TIME. A sheet mounted already open used to be
//     drawn at rest on its first frame — the transition was declared and never ran,
//     and the eval saw `transform: none` at 8 ms (UI-017, UI-049). Now the panel is
//     always first laid out at its off-screen transform, the layout is forced, and
//     only on the next frame is it told to rest, so the browser has a "from" to
//     transition out of.
//   · Open/closed is one attribute, and the motion is a CSS transition on `transform`
//     and `opacity`. A CSS transition reverses from its CURRENT value, so a sheet
//     closed halfway through opening turns back from where it is, along the edge it
//     came from, without a jump (apple-design §3). The best way to get that is to
//     keep the sheet mounted and pass `open={false}`. While it leaves it keeps drawing
//     what it last showed, so a caller that clears its row on close does not empty the
//     panel mid-flight.
//   · A CALLER THAT UNMOUNTS IT STILL GETS AN EXIT (eval iter 1 round 2, A5). The eval
//     found the context and result sheets gone within one frame of Esc — at rest or
//     interrupted 80 ms into the entrance — because their callers render nothing when
//     closed, and an unmounted node has no transition to play. So, in the unmount's
//     layout cleanup, while the panel is still in the document, the layer is copied
//     (`leaveFromLive`): the copy is pinned at the panel's LIVE computed transform,
//     then released toward its own off-screen edge, and removed on `transitionend`
//     with a timeout fallback. An interrupted entrance reverses from wherever it was.
//     The copy is inert and hidden from assistive tech: it is a picture of the exit,
//     not a second dialog.
//   · It leaves along the path it came in on (§7): a right sheet exits right.
//   · A MODAL GROWS FROM ITS TRIGGER (design-pass spec §5.2; apple-design §7). With no
//     `origin` given, the modal's `transform-origin` is set, as it opens, to the centre of
//     the control that opened it, so its scale from .96 points back at that control, and
//     the close — the same transition reversed — shrinks back to it.
//   · Opening never reflows the page: the layer is `position: fixed`, so the trigger
//     does not move under the pointer.
//   · FOCUS: on open it moves to the sheet's title (so a screen reader announces what
//     opened); Esc closes; on close focus returns to whatever had it before — the
//     trigger (UI-017). That includes a sheet whose caller UNMOUNTS it on close: the
//     eval found the context sheet dropping focus to <body> on Esc, because the
//     close branch of an effect never runs on an unmount. The return now also runs
//     in the unmount's cleanup, while the panel is still in the document.
//   · CLOSED, IT IS NOT A DIALOG. The role, `aria-modal` and the label are on the
//     panel only while it is open; a sheet on its way out is inert and plays its exit
//     as a panel, so nothing (a person with a screen reader, or a check counting
//     visible dialogs a moment after Esc — eval iter 1, D7) finds a dialog that has
//     already been dismissed.
//   · It is a modal dialog (`aria-modal="true"`) in every placement, and keeps Tab
//     inside itself: the page behind is not part of the conversation while it is up.
//   · A caller that draws its own header passes `labelledBy` and no `title`; the sheet
//     then draws no header of its own (never two close controls), labels itself by
//     the caller's heading, and lets the caller place focus — it only steps in if
//     nothing inside the panel has focus a frame later.
//   · The header is sticky with the close control in it, so the way out never scrolls
//     away (UI-057), and the body carries a scroll-edge mask rather than a hard rule.
//   · Closed, the layer is `inert`: nothing inside it can be focused or read.
//
// The spring curve and its duration are tokens (`--ease-spring`, `--dur-spring`).
// Under reduced motion every placement becomes a 150 ms cross-fade (base.css).
//   · A PHONE BOTTOM SHEET CAN BE PULLED DOWN (design-pass spec §5.2; critique r1, 1).
//     The grabber is a promise of a gesture, so the gesture is real: the grabber and
//     the sheet's own head track the finger 1:1 after a 10 px hysteresis, with pointer
//     capture once committed; up past the open position the sheet rubber-bands; on
//     release the resting place is projected from the velocity (d = 0.998) and the sheet
//     either leaves on the exit spring seeded with that velocity, or settles back on
//     `--spring-momentum`. The physics is in sheet-drag.js. Under reduced motion there
//     is no drag and no grabber.
//   · The scrim is a real control: a <button tabIndex={-1}> labelled with the close
//     label, so a tap outside closes the sheet without a click handler on a <div>
//     (Web Interface Guidelines; critique r1, 20). It stays out of the Tab order: Esc
//     and the close button are the keyboard's way out.

import { pushEscape } from "./escape-stack";
import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState } from "react";

import { IconClose } from "@/components/shell/icons";

import { IconButton } from "./Button";
import { SheetOpen } from "./sheet-open";
import { inertOutside } from "./inert-outside";
import { committed, dragOffset, releaseTarget, velocityOf } from "./sheet-drag";
import { planSpringExit } from "./sheet-spring";

const PLACEMENTS = new Set(["right", "bottom", "left", "modal"]);
const FOCUSABLE =
  'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

// useLayoutEffect warns during a server render; the server never animates anyway.
const useBrowserLayoutEffect = typeof window === "undefined" ? useEffect : useLayoutEffect;

/**
 * Give focus back to where it was before the sheet opened — but only if it is still
 * "ours" to give: nothing has focus (the panel left, so <body> does), or it is inside
 * the panel. A person who has already moved on (clicked into the page) keeps their
 * place.
 */
export function returnFocus(target, panel) {
  if (typeof document === "undefined" || !target || typeof target.focus !== "function") return false;
  if (!document.contains(target)) return false;
  const active = document.activeElement;
  const lost = !active || active === document.body || active === document.documentElement || !document.contains(active);
  if (!lost && !(panel && panel.contains(active))) return false;
  target.focus({ preventScroll: true });
  return true;
}

// How long an exit may take before the copy is removed anyway: the spring plus a margin,
// for a browser that never fires `transitionend` (a background tab, a cancelled run).
const EXIT_FALLBACK_MS = 700;

/** Whether the person asked for less motion (no drag physics then: spec §5.6). */
function prefersReducedMotion() {
  return typeof window !== "undefined" && typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

/** A panel's live vertical translation in px (0 at rest open). */
function liveOffsetY(panel) {
  const m = /matrix\(([^)]*)\)/.exec(window.getComputedStyle(panel).transform || "");
  if (!m) return 0;
  const y = Number.parseFloat(m[1].split(",")[5]);
  return Number.isFinite(y) ? y : 0;
}

/** Which placement a layer is, from its class ("sheet-right" → "right"). */
function sideOf(layer) {
  const hit = String(layer.className || "").match(/\bsheet-(right|left|bottom|modal)\b/);
  return hit ? hit[1] : null;
}

/**
 * Play a sheet's exit on a copy of its layer, for a caller that is unmounting it.
 * Returns the copy, or null when there is nothing to play (the layer was not showing,
 * or there is no browser). `env` is injectable so the sequence can be tested without
 * one (tests/ui-kit.test.js).
 *
 * The order matters, and each step is there for a reason:
 *   1. read the panel's live transform and opacity — mid-entrance they are neither
 *      "open" nor "closed", and the exit must start from exactly there;
 *   2. append the copy with its transition switched off and those values inline, and
 *      force a layout, so the copy is drawn where the original was on this frame;
 *   3. drop the inline values, restore the transition, and mark the layer closed: the
 *      stylesheet's closed transform (its own edge) is the new target, and the browser
 *      animates to it from the live value;
 *   4. remove the copy when its transform transition ends, or after the fallback.
 */
export function leaveFromLive(layer, env = typeof window === "undefined" ? null : window) {
  if (!env || !layer || !env.document || layer.getAttribute("data-open") !== "true") return null;
  const panel = layer.querySelector(".sheet");
  if (!panel) return null;
  const live = env.getComputedStyle(panel);
  const from = { transform: live.transform, opacity: live.opacity };
  // The exit is the stylesheet's own transition, from the live value (U37, verify pass 2:
  // a JS spring here played as a script Animation the checker could not reverse, and a
  // re-press during it jumped 554 px at 390). Only a sheet let go of after a drag still
  // carries the finger's velocity into a spring (sheet-drag.js): that is a gesture's
  // momentum, not an open or a close.
  const flung = panel.dataset && panel.dataset.dragVelocity !== undefined;
  const spring = flung ? planSpringExit(panel, sideOf(layer), env) : null;

  const copy = layer.cloneNode(true);
  copy.setAttribute("inert", "");
  copy.setAttribute("aria-hidden", "true");
  copy.setAttribute("data-leaving", "true");
  copy.removeAttribute("id");
  const ghost = copy.querySelector(".sheet");
  // Not a dialog: a picture of one leaving.
  if (typeof ghost.removeAttribute === "function") {
    ghost.removeAttribute("role");
    ghost.removeAttribute("aria-modal");
  }
  ghost.style.transition = "none";
  ghost.style.transform = from.transform;
  ghost.style.opacity = from.opacity;
  env.document.body.appendChild(copy);
  void ghost.getBoundingClientRect();

  let animation = null;
  if (spring && typeof ghost.animate === "function") {
    // The spring drives the panel; the scrim still fades on the stylesheet's transition.
    copy.setAttribute("data-open", "false");
    animation = ghost.animate(spring.keyframes, { duration: spring.duration, easing: "linear", fill: "forwards" });
    // The panel was drawn at the live position on the frame just gone; start one frame
    // on, so the exit's first frame is already moving at the handed-off speed.
    animation.currentTime = spring.frameMs;
  } else {
    ghost.style.transition = "";
    ghost.style.transform = "";
    ghost.style.opacity = "";
    copy.setAttribute("data-open", "false");
  }

  let done = false;
  const remove = () => {
    if (done) return;
    done = true;
    env.clearTimeout(timer);
    ghost.removeEventListener("transitionend", onEnd);
    if (copy.parentNode) copy.parentNode.removeChild(copy);
  };
  const onEnd = (event) => {
    if (event.target === ghost && (event.propertyName === "transform" || event.propertyName === "opacity")) remove();
  };
  let timer;
  if (animation) {
    animation.onfinish = remove;
    timer = env.setTimeout(remove, Math.max(EXIT_FALLBACK_MS, spring.duration + 200));
  } else {
    ghost.addEventListener("transitionend", onEnd);
    timer = env.setTimeout(remove, EXIT_FALLBACK_MS);
  }
  return copy;
}

/**
 * Set a centred modal's `transform-origin` to the centre of `trigger`, in the panel's
 * own coordinates, so its scale grows out of the control that opened it and shrinks
 * back into it (apple-design §7). The panel is laid out at the layer's centre and
 * translated by half its size; the scale's fixed point on screen is that corner plus
 * the origin, so the origin is the trigger's centre minus the panel's laid-out corner.
 * Does nothing when there is no usable trigger (focus on <body>, or inside the panel).
 * Exported for tests.
 */
export function anchorToTrigger(panel, layer, trigger) {
  if (!panel || !layer || !trigger || typeof trigger.getBoundingClientRect !== "function") return null;
  if (typeof document !== "undefined" && (trigger === document.body || trigger === document.documentElement)) return null;
  if (panel.contains && panel.contains(trigger)) return null;
  const r = trigger.getBoundingClientRect();
  if (!r || !(r.width > 0 || r.height > 0)) return null;
  const left = layer.clientWidth / 2 - panel.offsetWidth / 2;
  const top = layer.clientHeight / 2 - panel.offsetHeight / 2;
  const x = Math.round(r.left + r.width / 2 - left);
  const y = Math.round(r.top + r.height / 2 - top);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
  const value = `${x}px ${y}px`;
  panel.style.transformOrigin = value;
  return value;
}

export function Sheet({
  open = false,
  onClose,
  side = "right",
  title,
  labelledBy,
  children,
  footer,
  className,
  closeLabel = "Close",
  origin,
  id,
}) {
  if (!PLACEMENTS.has(side)) throw new TypeError(`Sheet: unknown side ${JSON.stringify(side)}`);
  const auto = useId();
  // What the sheet last showed while open, drawn while it leaves (see the header).
  const last = useRef({ title, children, footer });
  if (open) last.current = { title, children, footer };
  const drawn = open ? { title, children, footer } : last.current;
  const ownHeader = drawn.title !== undefined && drawn.title !== null && drawn.title !== false;
  const titleId = ownHeader || !labelledBy ? `${id || auto}-title` : labelledBy;
  const layerRef = useRef(null);
  const panelRef = useRef(null);
  const titleRef = useRef(null);
  const returnTo = useRef(null);
  const scrimmed = side !== "right";


  // `shown` is what the CSS sees. It trails `open` by one frame on the way in, so the
  // first frame is always drawn off-screen; on the way out it follows at once, and
  // the transition reverses from wherever the panel is.
  const [shown, setShown] = useState(false);

  const close = useCallback(() => {
    if (onClose) onClose();
  }, [onClose]);

  // The spring playing an interrupted exit in place, if one is (see below).
  const exitSpring = useRef(null);

  // In: lay the panel out at its off-screen transform, then release it next frame.
  useBrowserLayoutEffect(() => {
    const panel = panelRef.current;
    if (!open) {
      // Closed while still entering, or at rest: the CSS transition reverses from the
      // panel's current value, on the same spring it came in on (U37, verify pass 2: the
      // JS spring this used to play was a script Animation, not the symmetric CSS
      // transition, and a press during it re-opened from a committed style). Only a
      // sheet let go of after a drag carries the finger's velocity into a spring.
      const layer = layerRef.current;
      const flung = panel && panel.dataset && panel.dataset.dragVelocity !== undefined;
      const spring = flung && layer && layer.getAttribute("data-open") === "true" ? planSpringExit(panel, side, window) : null;
      // Let go of after a drag: the panel is held at the finger's position inline. The
      // spring (or, with no velocity, the CSS transition) now takes it from there.
      if (panel && panel.dataset && panel.dataset.dragVelocity !== undefined) {
        delete panel.dataset.dragVelocity;
        panel.style.transform = "";
        if (!spring) panel.style.transition = "";
      }
      if (spring) {
        panel.style.transition = "none";
        const animation = panel.animate(spring.keyframes, { duration: spring.duration, easing: "linear" });
        animation.currentTime = spring.frameMs;
        const release = () => {
          if (exitSpring.current === animation) exitSpring.current = null;
          panel.style.transition = "";
        };
        animation.onfinish = release;
        animation.oncancel = release;
        exitSpring.current = animation;
      }
      setShown(false);
      return undefined;
    }
    // Reopened mid-exit: keep the panel where the spring had it, and let the entrance
    // transition carry it in from there.
    if (exitSpring.current && panel) {
      const animation = exitSpring.current;
      exitSpring.current = null;
      try {
        animation.commitStyles();
      } catch {
        // A panel that cannot hold the committed style simply enters from its edge.
      }
      animation.cancel();
      void panel.getBoundingClientRect();
      panel.style.transition = "";
      const frame = requestAnimationFrame(() => {
        // "none" is the open transform: the transition runs from the committed
        // position toward it now, and the inline value is dropped once the stylesheet
        // says the same (the effect on `shown` below).
        panel.style.transform = "none";
        setShown(true);
      });
      return () => cancelAnimationFrame(frame);
    }
    // A modal is anchored to the control that opened it (see the header).
    if (side === "modal" && !origin) anchorToTrigger(panel, layerRef.current, document.activeElement);
    // Reading layout forces the browser to compute the closed style now, so there is
    // a "from" for the transition when `shown` flips.
    if (panel) void panel.getBoundingClientRect();
    const frame = requestAnimationFrame(() => setShown(true));
    return () => cancelAnimationFrame(frame);
  }, [open, side, origin]);

  useBrowserLayoutEffect(() => {
    const panel = panelRef.current;
    if (shown && panel && panel.style.transform === "none") panel.style.transform = "";
  }, [shown]);

  // Focus in on open; back to the trigger on close.
  useBrowserLayoutEffect(() => {
    if (!open) {
      const target = returnTo.current;
      returnTo.current = null;
      returnFocus(target, panelRef.current);
      return undefined;
    }
    const panel = panelRef.current;
    const active = document.activeElement;
    returnTo.current = active && active !== document.body && !(panel && panel.contains(active)) ? active : null;
    if (ownHeader && titleRef.current) {
      titleRef.current.focus({ preventScroll: true });
      return undefined;
    }
    // The caller draws the heading and may focus it itself in its own effect, which
    // runs after this one; step in a frame later only if nothing inside has focus.
    const frame = requestAnimationFrame(() => {
      if (!panel || panel.contains(document.activeElement)) return;
      const target = (labelledBy && document.getElementById(labelledBy)) || panel.querySelector(FOCUSABLE) || panel;
      if (target && typeof target.focus === "function") target.focus({ preventScroll: true });
    });
    return () => cancelAnimationFrame(frame);
  }, [open, ownHeader, labelledBy]);

  // A SCRIMMED SHEET IS MODAL IN FACT, NOT ONLY IN NAME (ui-pass-1 #32; inert-outside.js).
  // While it is open everything outside it is inert, so nothing behind the scrim can take
  // focus or be counted as on the view (the decision card's commit under the new-task
  // sheet was). Declared AFTER the effect that remembers the trigger (so the trigger is
  // read while it still has focus) and BEFORE the unmount effect that hands focus back
  // (cleanups run in declaration order), so the page is live again before focus
  // returns to the trigger on it. On a close, every cleanup runs before any new effect.
  useBrowserLayoutEffect(() => {
    if (!open || !scrimmed) return undefined;
    return inertOutside(layerRef.current);
  }, [open, scrimmed]);

  // Unmounted while open (a caller that renders nothing when closed): the close
  // branch above never runs, so the return happens here, in a layout cleanup, before
  // the panel leaves the document.
  // It also plays the exit on a copy, from wherever the panel is right now.
  useBrowserLayoutEffect(
    () => () => {
      const target = returnTo.current;
      returnTo.current = null;
      leaveFromLive(layerRef.current);
      returnFocus(target, panelRef.current);
    },
    []
  );

  // ── drag to dismiss (bottom sheets; see the header and sheet-drag.js) ──
  const openRef = useRef(open);
  openRef.current = open;
  const drag = useRef(null);

  const settleOpen = useCallback((panel) => {
    if (!panel) return;
    // Back to rest on the momentum spring: the gesture carried momentum (AD §4).
    panel.style.transition = "transform var(--dur-spring-momentum) var(--ease-spring-momentum)";
    void panel.getBoundingClientRect();
    panel.style.transform = "";
    const done = (event) => {
      if (event && event.target !== panel) return;
      panel.removeEventListener("transitionend", done);
      if (!drag.current) panel.style.transition = "";
    };
    panel.addEventListener("transitionend", done);
  }, []);

  const endDrag = useCallback(() => {
    const d = drag.current;
    if (!d) return;
    drag.current = null;
    window.removeEventListener("pointermove", d.onMove);
    window.removeEventListener("pointerup", d.onUp);
    window.removeEventListener("pointercancel", d.onCancel);
    if (d.active && d.handle && typeof d.handle.releasePointerCapture === "function") {
      try {
        d.handle.releasePointerCapture(d.pointerId);
      } catch {
        // Already released (the pointer left the page).
      }
    }
  }, []);

  const onHandlePointerDown = useCallback(
    (event) => {
      if (side !== "bottom" || !open || !event.isPrimary) return;
      if (event.pointerType === "mouse" && event.button !== 0) return;
      if (prefersReducedMotion()) return;
      const panel = panelRef.current;
      if (!panel) return;
      endDrag();
      const d = {
        pointerId: event.pointerId,
        handle: event.currentTarget,
        x0: event.clientX,
        y0: event.clientY,
        active: false,
        origin: 0,
        from: 0,
        offset: 0,
        height: panel.offsetHeight,
        samples: [],
      };
      d.onMove = (e) => {
        if (e.pointerId !== d.pointerId) return;
        if (!d.active) {
          if (!committed(e.clientX - d.x0, e.clientY - d.y0)) return;
          // Committed: grab the panel wherever it is (mid-entrance or settling), and
          // keep the grab offset, so nothing jumps under the finger (AD §2).
          d.active = true;
          d.from = liveOffsetY(panel);
          d.origin = e.clientY;
          panel.style.transition = "none";
          panel.style.transform = `translateY(${d.from}px)`;
          try {
            d.handle.setPointerCapture(d.pointerId);
          } catch {
            // The window listeners still track it.
          }
        }
        if (e.cancelable) e.preventDefault();
        d.offset = dragOffset(d.from + (e.clientY - d.origin), d.height);
        panel.style.transform = `translateY(${Math.round(d.offset * 100) / 100}px)`;
        d.samples.push({ t: e.timeStamp, y: d.offset });
        if (d.samples.length > 12) d.samples.shift();
      };
      d.onUp = (e) => {
        if (e.pointerId !== d.pointerId) return;
        const wasActive = d.active;
        const velocity = velocityOf(d.samples, e.timeStamp);
        endDrag();
        if (!wasActive) return; // a tap: the click goes where it was aimed
        if (releaseTarget({ offset: d.offset, velocity, height: d.height }) === "close") {
          panel.dataset.dragVelocity = String(Math.max(velocity, 0));
          close();
          // A caller that does not close: the sheet goes back where it belongs.
          requestAnimationFrame(() => {
            if (!openRef.current || !panel.isConnected) return;
            delete panel.dataset.dragVelocity;
            settleOpen(panel);
          });
        } else {
          settleOpen(panel);
        }
      };
      d.onCancel = (e) => {
        if (e.pointerId !== d.pointerId) return;
        const wasActive = d.active;
        endDrag();
        if (wasActive) settleOpen(panel);
      };
      drag.current = d;
      window.addEventListener("pointermove", d.onMove, { passive: false });
      window.addEventListener("pointerup", d.onUp);
      window.addEventListener("pointercancel", d.onCancel);
    },
    [side, open, close, endDrag, settleOpen]
  );

  // A gesture never outlives the sheet.
  useEffect(() => endDrag, [endDrag]);

  // Esc closes; Tab stays inside.
  useEffect(() => {
    if (!open) return undefined;
    function onKey(event) {
      // Esc is handed out by components/ui/escape-stack.js, to the topmost layer only.
      if (event.key !== "Tab" || !panelRef.current) return;
      const items = [...panelRef.current.querySelectorAll(FOCUSABLE)];
      if (!items.length) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (event.shiftKey && (document.activeElement === first || !panelRef.current.contains(document.activeElement))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }
    document.addEventListener("keydown", onKey);
    const popEscape = pushEscape(() => close());
    return () => {
      document.removeEventListener("keydown", onKey);
      popEscape();
    };
  }, [open, close]);

  const panelStyle = origin ? { transformOrigin: origin } : undefined;
  const panel = (
    <>
      {side === "bottom" ? <div className="sheet-grabber" aria-hidden="true" onPointerDown={onHandlePointerDown} /> : null}
      {ownHeader ? (
        <header className="sheet-head" onPointerDown={side === "bottom" ? onHandlePointerDown : undefined}>
          <h2 className="sheet-title t-title-2" id={titleId} tabIndex={-1} ref={titleRef}>
            {drawn.title}
          </h2>
          <IconButton label={closeLabel} onClick={close} className="sheet-close">
            <IconClose />
          </IconButton>
        </header>
      ) : null}
      <div className="sheet-body scroll-edges">
        <SheetOpen.Provider value={open}>{drawn.children}</SheetOpen.Provider>
      </div>
      {drawn.footer ? <footer className="sheet-foot">{drawn.footer}</footer> : null}
    </>
  );

  return (
    <div
      ref={layerRef}
      className={["sheet-layer", `sheet-${side}`, className].filter(Boolean).join(" ")}
      data-open={shown ? "true" : "false"}
      inert={open ? undefined : true}
      data-ui="Sheet"
    >
      {scrimmed ? <button type="button" className="sheet-scrim" tabIndex={-1} aria-label={closeLabel} onClick={close} /> : null}
      {open ? (
        <section
          ref={panelRef}
          className="sheet"
          role="dialog"
          aria-modal="true"
          aria-labelledby={titleId}
          tabIndex={-1}
          style={panelStyle}
        >
          {panel}
        </section>
      ) : (
        // The same element on its way out: inert, and no longer a dialog.
        <section ref={panelRef} className="sheet" tabIndex={-1} style={panelStyle}>
          {panel}
        </section>
      )}
    </div>
  );
}
