"use client";

// components/ui/Disclosure.js — "Details", AND EVERYTHING ELSE THAT OPENS IN PLACE
// ==============================================================================
// Spec §1.5 and §11.4; audit UI-050. The verdict is on the surface; ids, the workings
// and the codes sit one press down. A button with `aria-expanded` controls a region;
// the region animates its HEIGHT with `grid-template-rows: 0fr → 1fr` (no measured
// pixel heights, so it is right at any text size) and, once open, is scrolled into
// view if it opened below the fold — the part UI-050 found missing, where the content
// opened off-screen and the press looked like it had done nothing.
//
// THE ONE DISCLOSURE (design-fix-2 §4): a 28 px toggle with a hover fill and Phosphor's
// CaretDown, which turns 180° on the snappy spring. Every <details> in the app is meant to
// become this; the UA's triangle is hidden everywhere (base.css `summary`).
//
// The closed region stays in the document but is `inert`, so nothing inside it can be
// tabbed to while it is shut, and a static render still carries its text for a reader
// who lands with the page already rendered.

import { useEffect, useId, useRef, useState } from "react";

import { IconCaretDown } from "@/components/ui/icons";

export function Disclosure({ summary, children, defaultOpen = false, className, onToggle }) {
  const [open, setOpen] = useState(defaultOpen);
  const regionId = useId();
  const regionRef = useRef(null);
  const opened = useRef(false);

  useEffect(() => {
    if (!open || !opened.current || !regionRef.current) return;
    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    regionRef.current.scrollIntoView({ block: "nearest", behavior: reduce ? "auto" : "smooth" });
  }, [open]);

  // `onToggle` is called beside the state change, not inside its updater: an updater
  // may run while React renders this component, and a caller's own setState from there
  // is an update to another component during render (the checklist's roving tabindex
  // keeps each band's open state this way).
  function toggle() {
    opened.current = true;
    const next = !open;
    setOpen(next);
    if (onToggle) onToggle(next);
  }

  return (
    <div className={["disclosure", className].filter(Boolean).join(" ")} data-open={open ? "true" : "false"} data-ui="Disclosure">
      <button type="button" className="disclosure-toggle" aria-expanded={open ? "true" : "false"} aria-controls={regionId} onClick={toggle}>
        <span>{summary}</span>
        <IconCaretDown className="disclosure-chevron" size={12} />
      </button>
      <div className="disclosure-region" id={regionId} ref={regionRef} inert={open ? undefined : true}>
        <div className="disclosure-inner">{children}</div>
      </div>
    </div>
  );
}
