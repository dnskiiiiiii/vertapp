"use client";

// components/ui/Portal.js — LIFT A LAYER OUT OF THE SHELL'S STACKING CONTEXT
// ==============================================================================
// Design-fix-2 spec §8.2; audit DA2-001 (a blocker). On a phone the result pane and
// every sheet opened UNDER the top bar: the scroller they were drawn in is a stacking
// context (a scroll-edge mask makes one), so no z-index inside it can rise above the
// fixed bar outside it. Rendered into <body>, a layer sits on the one z scale
// (app/styles/tokens.css: --z-sheet above --z-topbar) and nothing can trap it.
//
// The server render and HYDRATION draw `children` IN PLACE, so hydration matches; then,
// with `when` true, they move to <body>. `when` lets a caller portal only below the
// 1024 px breakpoint (lib/breakpoints.js) and stay in the grid on a desk.
//
// A LAYER OPENED AFTER THE PAGE HYDRATED GOES STRAIGHT TO <body> (staging walkthrough D1,
// 26 Oct 2026). It used to be drawn in place for one render and then moved, and React
// mounts a moved tree afresh: every dialog's body mounted twice, and each mount's effects
// ran twice — the plan document read its skill twice per open. `useSyncExternalStore`
// answers the server snapshot (false) only while hydrating, so only a layer that was in
// the server's HTML takes the in-place first render.

import { useSyncExternalStore } from "react";
import { createPortal } from "react-dom";

const never = () => () => {};

export function Portal({ children, when = true }) {
  const client = useSyncExternalStore(never, () => true, () => false);
  if (!when || !client || typeof document === "undefined") return children;
  return createPortal(children, document.body);
}
