"use client";

// components/ui/Button.js — THE ONE BUTTON, AND ITS QUIETER COUSINS
// ==============================================================================
// Design-pass spec §6.1 (9 Oct 2026); audit UI-012, UI-013, UI-014.
//
// THREE STYLES, AND ONLY ONE OF THEM CARRIES THE ACCENT (design-fix-2 §5.3; DA2-009).
//   commit     — Vert green. Only for the one control per view that writes to the books,
//                starts a plan, creates a task or signs in: Post entry, Approve and post,
//                Start now, Create task, Use this one, Sign in. Its label fits on one
//                line in three words at most; context goes in the body.
//   secondary  — the desk's grey fill, no outline, no shadow: Open bridge, Schedule…,
//                Import, Try again, Download.
//   quiet      — text in the secondary ink, a soft fill on hover: Skip, Reject…, Cancel,
//                Edit, Open in chat. `destructive` turns its label the problem ink.
//   ink        — (not a style a view chooses) the near-black fill of the composer's send.
//                Sending a message is not a write, so it is never the accent.
// The accent means "this writes" and nothing else (spec §3.2), so a green button that
// does not write is a colour telling a lie. Destructive actions are quiet buttons in the
// problem ink with a confirmation, never a red fill.
//
// DISABLED IS `aria-disabled` PLUS A PRINTED REASON, NEVER `disabled` ALONE (UI-014).
// A native `disabled` button cannot be focused, cannot be hovered and swallows the
// press, so the reason for it — which used to live in a `title` — could never be read
// by keyboard, touch or screen reader. Here the button stays focusable and pressable,
// the press does nothing, and the reason is printed beside it and tied to it with
// `aria-describedby`.
//
// BUSY KEEPS THE BUTTON AT FULL STRENGTH (UI-012). While a write is in flight the
// label says what is happening ("Approving…"), `aria-busy` says so to assistive tech,
// and further presses are ignored. It does not fade: a faded button reads as "this
// did not work", which is the opposite of what is happening.
//
// `icon` leads the label and `trailingIcon` follows it (a CaretRight on "Open bridge"):
// each a Phosphor element from components/ui/icons.js, drawn 14 px with a 6 px gap.
//
// The press itself is CSS (`.btn:active`, app/styles/kit.css): every variant names its
// own pressed fill and scales to .97 on pointer-down, within 100 ms (apple-design §1).
// Nothing here waits for a click to acknowledge a press.

import Link from "next/link";
import { useId } from "react";
import { InsideControl } from "./Figure";

const VARIANTS = new Set(["commit", "secondary", "quiet", "ink"]);

export function Button({
  children,
  variant = "secondary",
  size,
  type = "button",
  onClick,
  href,
  busy = false,
  busyLabel,
  disabledReason,
  disabled,
  className,
  wide = false,
  icon = null,
  trailingIcon = null,
  destructive = false,
  ...rest
}) {
  const reasonId = useId();
  if (!VARIANTS.has(variant)) {
    throw new TypeError(`Button: unknown variant ${JSON.stringify(variant)}`);
  }

  // `disabled` without a reason is accepted for the step-0 contract (the stub took a
  // bare boolean), and still renders as aria-disabled rather than native disabled.
  // A caller should pass `disabledReason`; the reason is what makes it usable.
  const inert = Boolean(busy || disabledReason || disabled);
  const classes = [
    "btn",
    `btn-${variant}`,
    size === "sm" ? "btn-sm" : null,
    wide ? "btn-wide" : null,
    destructive ? "btn-destructive" : null,
    className,
  ]
    .filter(Boolean)
    .join(" ");

  const text = busy && busyLabel ? busyLabel : children;
  const label =
    icon || trailingIcon ? (
      <>
        {icon}
        <span>{text}</span>
        {trailingIcon}
      </>
    ) : (
      text
    );
  const describedBy = disabledReason ? reasonId : undefined;
  // Figures in a button's label are text, never a second control (InsideControl).
  const inner = <InsideControl.Provider value>{label}</InsideControl.Provider>;

  function handleClick(event) {
    if (inert) {
      event.preventDefault();
      return;
    }
    if (onClick) onClick(event);
  }

  const control = href && !inert ? (
    <Link href={href} className={classes} onClick={onClick} {...rest}>
      {inner}
    </Link>
  ) : (
    <button
      type={type}
      className={classes}
      onClick={handleClick}
      aria-disabled={inert ? "true" : undefined}
      aria-busy={busy ? "true" : undefined}
      aria-describedby={describedBy}
      data-ui="Button"
      {...rest}
    >
      {inner}
    </button>
  );

  if (!disabledReason) return control;
  return (
    <span className="btn-with-reason">
      {control}
      <span className="btn-reason" id={reasonId}>
        {disabledReason}
      </span>
    </span>
  );
}

/**
 * A control that is only a glyph. `label` is required: the glyph is decoration and
 * the label is the control's name. The hit area is 44 × 44 at every width even when
 * the glyph is 20, because a small target on a phone is a missed press (hit-targets).
 */
export function IconButton({ children, label, type = "button", onClick, className, pressed, ...rest }) {
  if (typeof label !== "string" || !label.trim()) {
    throw new TypeError("IconButton: a glyph-only control needs a label");
  }
  return (
    <button
      type={type}
      className={["icon-btn", className].filter(Boolean).join(" ")}
      aria-label={label}
      aria-pressed={pressed === undefined ? undefined : pressed ? "true" : "false"}
      onClick={onClick}
      data-ui="IconButton"
      {...rest}
    >
      {children}
    </button>
  );
}
