"use client";

// components/ui/DateField.js — A DATE, PICKED FROM A MONTH; A TIME, PICKED FROM SLOTS
// ==============================================================================
// Design-fix-2 spec §5.6; audit DA2-066. The schedule popover and the journal editor used
// the browser's native date and time inputs: a different control on every platform,
// "dd/mm/yyyy" placeholders, and a picker that ignores the app's type and colour. These
// two are in-repo (no date-picker dependency was approved):
//
//   DateField       a text-field-shaped button showing "Sun 11 Oct 2026" that opens a
//                   month grid in a popover. Keyboard: the arrows move a day or a week,
//                   PageUp / PageDown a month, Home / End the week's ends, Enter picks,
//                   Esc closes and returns focus to the field.
//   TimeSlotSelect  30-minute slots in a labelled select, with the zone in words
//                   ("Sydney time"), never a free-typed clock.
//
// Values are ISO strings ("2026-10-11", "09:30"), the shape the API takes. Dates are
// built from their parts at noon UTC, so no time zone moves a day.

import { useEffect, useId, useLayoutEffect, useRef, useState } from "react";

import { IconCalendar, IconCaretLeft, IconCaretRight } from "@/components/ui/icons";
import { MONTHS, MONTHS_LONG, formatDate, formatTime } from "@/lib/format";

const WEEKDAYS = ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"];
const WEEKDAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

function parseIso(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(iso || ""));
  if (!m) return null;
  return { y: Number(m[1]), m: Number(m[2]) - 1, d: Number(m[3]) };
}

function toIso({ y, m, d }) {
  return `${String(y).padStart(4, "0")}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

function utc(parts) {
  return new Date(Date.UTC(parts.y, parts.m, parts.d, 12));
}

function fromDate(date) {
  return { y: date.getUTCFullYear(), m: date.getUTCMonth(), d: date.getUTCDate() };
}

/** `parts` moved by `days` (negative goes back). */
function shiftDays(parts, days) {
  const date = utc(parts);
  date.setUTCDate(date.getUTCDate() + days);
  return fromDate(date);
}

/** `parts` moved by `months`, the day clamped to the new month's length. */
function shiftMonths(parts, months) {
  const first = new Date(Date.UTC(parts.y, parts.m + months, 1, 12));
  const length = new Date(Date.UTC(first.getUTCFullYear(), first.getUTCMonth() + 1, 0, 12)).getUTCDate();
  return { y: first.getUTCFullYear(), m: first.getUTCMonth(), d: Math.min(parts.d, length) };
}

/** Monday-first weekday index, 0–6. */
function weekdayIndex(parts) {
  return (utc(parts).getUTCDay() + 6) % 7;
}

/** The 6 x 7 grid of the month `view` ({y, m}), Monday first, padded with its neighbours. */
function monthGrid(view) {
  const first = { y: view.y, m: view.m, d: 1 };
  const start = shiftDays(first, -weekdayIndex(first));
  return Array.from({ length: 42 }, (_, i) => shiftDays(start, i));
}

function todayParts() {
  const now = new Date();
  return { y: now.getFullYear(), m: now.getMonth(), d: now.getDate() };
}

const sameDay = (a, b) => Boolean(a && b && a.y === b.y && a.m === b.m && a.d === b.d);

// The gap kept between the grid and the window's edge, in px (the phone's side gutter).
const EDGE = 16;
// Before the first paint there is nothing to measure: run the placement in a layout
// effect in the browser, and not at all on the server.
const useBrowserLayoutEffect = typeof window === "undefined" ? useEffect : useLayoutEffect;

/**
 * WHICH EDGE OF THE FIELD THE GRID HANGS FROM (UI walk 2, N3, 30 Oct 2026). Under the
 * field's left edge, as it always opened, unless that would run past the window's right
 * edge: the journal editor's Date sits at the sheet's right, and at 1440 px its grid
 * opened at 1240–1520, with "Next month" and Friday to Sunday off-screen. Then it hangs
 * from the field's right edge instead, when that fits. `left`/`right`: the field's
 * edges, `width`: the grid's, `viewport`: the window's, all in px. Pure: "start" | "end".
 */
export function datePopAlign({ left, right, width, viewport } = {}) {
  if (![left, right, width, viewport].every((n) => typeof n === "number" && Number.isFinite(n))) return "start";
  if (left + width <= viewport - EDGE) return "start";
  return right - width >= EDGE ? "end" : "start";
}

export function DateField({ label, value, onChange, hint, error, id, min, max, className, name, aside = null }) {
  const auto = useId();
  const fieldId = id || auto;
  const gridId = `${fieldId}-grid`;
  const chosen = parseIso(value);
  const [open, setOpen] = useState(false);
  const [cursor, setCursor] = useState(chosen || todayParts());
  const [align, setAlign] = useState("start");
  const triggerRef = useRef(null);
  const gridRef = useRef(null);
  const popRef = useRef(null);
  const lo = parseIso(min);
  const hi = parseIso(max);

  const outOfRange = (p) => (lo && toIso(p) < toIso(lo)) || (hi && toIso(p) > toIso(hi));

  // Placed before the grid paints, from the field's and the grid's measured edges.
  useBrowserLayoutEffect(() => {
    if (!open || !triggerRef.current || !popRef.current) return;
    const field = triggerRef.current.getBoundingClientRect();
    const viewport = document.documentElement.clientWidth || window.innerWidth;
    setAlign(datePopAlign({ left: field.left, right: field.right, width: popRef.current.offsetWidth, viewport }));
  }, [open]);

  useEffect(() => {
    if (!open || !gridRef.current) return;
    const cell = gridRef.current.querySelector('[data-cursor="true"]');
    if (cell) cell.focus();
  }, [open, cursor]);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (event) => {
      const root = triggerRef.current && triggerRef.current.closest(".date-field");
      if (root && !root.contains(event.target)) setOpen(false);
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [open]);

  function openGrid() {
    setCursor(chosen || todayParts());
    setOpen(true);
  }

  function close(returnFocus = true) {
    setOpen(false);
    if (returnFocus && triggerRef.current) triggerRef.current.focus();
  }

  function pick(parts) {
    if (outOfRange(parts)) return;
    if (onChange) onChange(toIso(parts));
    close();
  }

  function onGridKey(event) {
    const moves = {
      ArrowLeft: () => shiftDays(cursor, -1),
      ArrowRight: () => shiftDays(cursor, 1),
      ArrowUp: () => shiftDays(cursor, -7),
      ArrowDown: () => shiftDays(cursor, 7),
      PageUp: () => shiftMonths(cursor, -1),
      PageDown: () => shiftMonths(cursor, 1),
      Home: () => shiftDays(cursor, -weekdayIndex(cursor)),
      End: () => shiftDays(cursor, 6 - weekdayIndex(cursor)),
    };
    if (moves[event.key]) {
      event.preventDefault();
      setCursor(moves[event.key]());
    } else if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      pick(cursor);
    } else if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      close();
    }
  }

  const cells = monthGrid(cursor);
  const today = todayParts();
  const hintId = hint ? `${fieldId}-hint` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;

  return (
    <div className={["form-field", "date-field", error ? "field-invalid" : null, className].filter(Boolean).join(" ")} data-ui="DateField">
      {/* `aside`: drawn at the label's end (a bill's "Medium confidence"), as BillField does. */}
      {aside ? (
        <div className="date-field-label-row">
          <span className="field-label" id={`${fieldId}-label`}>
            {label}
          </span>
          {aside}
        </div>
      ) : (
        <span className="field-label" id={`${fieldId}-label`}>
          {label}
        </span>
      )}
      <div className="field-box">
        <button
          ref={triggerRef}
          type="button"
          id={fieldId}
          className="field-input date-field-trigger"
          aria-haspopup="dialog"
          aria-expanded={open ? "true" : "false"}
          aria-labelledby={`${fieldId}-label ${fieldId}`}
          aria-describedby={[errorId, hintId].filter(Boolean).join(" ") || undefined}
          onClick={() => (open ? close(false) : openGrid())}
        >
          <span className={chosen ? "num" : "date-field-empty"}>{chosen ? formatDate(toIso(chosen), { weekday: true }) : "Choose a date…"}</span>
          <IconCalendar size={16} className="date-field-icon" />
        </button>
        {name ? <input type="hidden" name={name} value={value || ""} /> : null}
      </div>
      {open ? (
        <div ref={popRef} className="popover date-pop" role="dialog" aria-label={`Choose ${String(label).toLowerCase()}`} data-open="true" data-align={align}>
          <div className="date-pop-head">
            <button type="button" className="icon-btn icon-btn-sm" aria-label="Previous month" onClick={() => setCursor(shiftMonths(cursor, -1))}>
              <IconCaretLeft size={14} />
            </button>
            <span className="date-pop-title" aria-live="polite">
              {MONTHS_LONG[cursor.m]} {cursor.y}
            </span>
            <button type="button" className="icon-btn icon-btn-sm" aria-label="Next month" onClick={() => setCursor(shiftMonths(cursor, 1))}>
              <IconCaretRight size={14} />
            </button>
          </div>
          <div className="date-grid" role="grid" id={gridId} ref={gridRef} onKeyDown={onGridKey}>
            <div className="date-row" role="row">
              {WEEKDAYS.map((w, i) => (
                <span key={w} className="date-dow" role="columnheader" aria-label={WEEKDAY_NAMES[i]}>
                  {w}
                </span>
              ))}
            </div>
            {[0, 1, 2, 3, 4, 5].map((row) => (
              <div className="date-row" role="row" key={row}>
                {cells.slice(row * 7, row * 7 + 7).map((p) => {
                  const iso = toIso(p);
                  const isCursor = sameDay(p, cursor);
                  const disabled = Boolean(outOfRange(p));
                  return (
                    <button
                      key={iso}
                      type="button"
                      role="gridcell"
                      className="date-cell num"
                      tabIndex={isCursor ? 0 : -1}
                      data-cursor={isCursor ? "true" : undefined}
                      data-outside={p.m !== cursor.m ? "true" : undefined}
                      data-today={sameDay(p, today) ? "true" : undefined}
                      aria-selected={sameDay(p, chosen) ? "true" : "false"}
                      aria-disabled={disabled ? "true" : undefined}
                      aria-label={`${WEEKDAY_NAMES[weekdayIndex(p)]} ${p.d} ${MONTHS_LONG[p.m]} ${p.y}`}
                      onClick={() => pick(p)}
                    >
                      {p.d}
                    </button>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      ) : null}
      {error ? (
        <p className="field-error" id={errorId} role="alert">
          {error}
        </p>
      ) : null}
      {hint ? (
        <p className="field-hint" id={hintId}>
          {hint}
        </p>
      ) : null}
    </div>
  );
}

/** Every 30-minute slot of a day, "00:00" to "23:30". */
export const TIME_SLOTS = Object.freeze(
  Array.from({ length: 48 }, (_, i) => `${String(Math.floor(i / 2)).padStart(2, "0")}:${i % 2 ? "30" : "00"}`)
);

/**
 * A time, chosen from 30-minute slots and shown as "9:30 am", with the zone in words
 * beside it ("Sydney time"). `value` is "HH:MM". `isUnavailable(slot)`, when given, marks
 * a slot that can't be chosen (verify pass 9, P24: a time already past today) as
 * disabled, so the list never offers what the send would refuse.
 */
export function TimeSlotSelect({ label, value, onChange, zone = "Sydney time", id, className, from = "06:00", to = "21:00", name, isUnavailable = null }) {
  const auto = useId();
  const fieldId = id || auto;
  const slots = TIME_SLOTS.filter((t) => t >= from && t <= to);
  return (
    <div className={["form-field", "time-slot-field", className].filter(Boolean).join(" ")} data-ui="TimeSlotSelect">
      <label className="field-label" htmlFor={fieldId}>
        {label}
      </label>
      <div className="field-box">
        <select id={fieldId} name={name || fieldId} autoComplete="off" className="field-input num" value={value || ""} onChange={(event) => onChange && onChange(event.target.value)}>
          {value ? null : (
            <option value="" disabled>
              Choose a time…
            </option>
          )}
          {slots.map((t) => (
            <option key={t} value={t} disabled={typeof isUnavailable === "function" && isUnavailable(t) && t !== value ? true : undefined}>
              {formatTime(t)}
            </option>
          ))}
        </select>
        <span className="field-suffix">{zone}</span>
      </div>
    </div>
  );
}

// Exported for tests.
export const _dateMath = { parseIso, toIso, shiftDays, shiftMonths, monthGrid, weekdayIndex, MONTHS };
