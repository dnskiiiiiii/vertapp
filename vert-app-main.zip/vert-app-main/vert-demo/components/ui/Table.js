"use client";

// components/ui/Table.js — A LIST OF RECORDS THAT A KEYBOARD CAN WALK
// ==============================================================================
// Spec §3.5 and §11.6; audit UI-031, UI-056, UI-058.
//
//   · ONE TAB STOP FOR THE WHOLE TABLE (UI-056: every row used to take two). Rows use a
//     roving tabindex: Tab enters on the current row, ↑ ↓ Home End move, Enter opens.
//   · BELOW 700 PX EACH ROW STACKS into label/value pairs (CSS, kit.css), so a phone
//     never scrolls sideways to reach Status (UI-031, the mobile-overflow guard).
//   · Between 700 px and the table's natural width it scrolls inside itself, and a
//     fade on the right edge says there is more (shown only while there is).
//   · Rules between rows only when there are five rows or more (§11.3, UI-058): a
//     short list is grouped by space, not by hairlines.
//
// `columns: [{key, label, numeric?}]`, `rows: [{id, cells: {key: node}, href?, onOpen?,
// selected?}]`. Cells are rendered as given: formatting is the caller's, through
// lib/format.js, so a figure here is the same string it is everywhere else.

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

// `foot`: an optional total row, `{ cells: { [columnKey]: node } }`, drawn in a <tfoot>
// so it is never one of the arrow-key rows and never opens a record. Its figures are
// the caller's to source (Records reads the engine's total; it never sums the rows).
export function Table({ columns = [], rows = [], caption, className, empty = "Nothing here.", foot = null }) {
  const router = useRouter();
  const [active, setActive] = useState(0);
  const [overflow, setOverflow] = useState(false);
  const scroller = useRef(null);
  const body = useRef(null);

  useEffect(() => {
    const el = scroller.current;
    if (!el) return undefined;
    const measure = () => setOverflow(el.scrollWidth - el.clientWidth - el.scrollLeft > 1);
    measure();
    el.addEventListener("scroll", measure, { passive: true });
    window.addEventListener("resize", measure);
    return () => {
      el.removeEventListener("scroll", measure);
      window.removeEventListener("resize", measure);
    };
  }, [rows.length]);

  function open(row) {
    if (row.onOpen) row.onOpen();
    else if (row.href) router.push(row.href);
  }

  function focusRow(index) {
    const next = Math.max(0, Math.min(rows.length - 1, index));
    setActive(next);
    const el = body.current && body.current.querySelectorAll("tr")[next];
    if (el) el.focus();
  }

  function onKeyDown(event, index, row) {
    if (event.key === "ArrowDown") { event.preventDefault(); focusRow(index + 1); }
    else if (event.key === "ArrowUp") { event.preventDefault(); focusRow(index - 1); }
    else if (event.key === "Home") { event.preventDefault(); focusRow(0); }
    else if (event.key === "End") { event.preventDefault(); focusRow(rows.length - 1); }
    else if (event.key === "Enter" || event.key === " ") { event.preventDefault(); open(row); }
  }

  if (!rows.length) return <p className="table-empty">{empty}</p>;

  const ruled = rows.length >= 5;
  return (
    <div
      ref={scroller}
      className={["table-scroll", overflow ? "table-overflow" : null, className].filter(Boolean).join(" ")}
      data-ui="Table"
    >
      <table className={["table", ruled ? "table-ruled" : null].filter(Boolean).join(" ")}>
        {caption ? <caption className="sr-only">{caption}</caption> : null}
        <thead>
          <tr>
            {columns.map((col) => (
              <th key={col.key} scope="col" className={col.numeric ? "num-col" : undefined}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody ref={body}>
          {rows.map((row, index) => {
            const pressable = Boolean(row.href || row.onOpen);
            return (
              <tr
                key={row.id}
                className={["row", pressable ? "row-pressable" : null, row.selected ? "row-selected" : null].filter(Boolean).join(" ")}
                tabIndex={pressable ? (index === active ? 0 : -1) : undefined}
                aria-selected={row.selected ? "true" : undefined}
                onClick={pressable ? () => { setActive(index); open(row); } : undefined}
                onKeyDown={pressable ? (event) => onKeyDown(event, index, row) : undefined}
              >
                {columns.map((col) => (
                  <td key={col.key} data-label={col.label} className={col.numeric ? "num-col num" : undefined}>
                    {row.cells ? row.cells[col.key] : null}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
        {foot ? (
          <tfoot>
            <tr className="table-total">
              {columns.map((col, i) => (
                <td key={col.key} data-label={col.label} className={col.numeric ? "num-col num" : undefined}>
                  {foot.cells && foot.cells[col.key] !== undefined ? foot.cells[col.key] : i === 0 ? "Total" : null}
                </td>
              ))}
            </tr>
          </tfoot>
        ) : null}
      </table>
    </div>
  );
}
