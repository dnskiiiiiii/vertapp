"use client";

// components/ui/RememberTick.js — THE ONE "REMEMBER" TICK, AND "RULE SAVED"
// ==============================================================================
// Founder decision, 3 Nov 2026 (engine w36): a coding becomes a saved rule ONLY when a
// person ticks Remember. Unset and unticked save none, on every road. The Cash coding
// grid drew the first tick (components/cash-coding/CashCodingScreen.js); the bill review,
// the bank rec's coding rows and the chat's coding cards draw this one, so all four look
// and read the same: the grid's classes (app/styles/cash-coding.css .cc-remember,
// globals.css .cbx-hit / .cbx), its one word, the label wrapping the box as its hit
// target (tests/hit-targets.test.js), and unticked unless the person ticks it.
//
// `label` is the box's accessible name. It must begin with the word it shows (WCAG
// 2.5.3, label in name), so a person using voice control can say "click Remember".
//
// RuleSaved is the grid's "Rule saved", the engine's own sentence (`remembered`) on
// hover; it says nothing unless the engine said a rule was saved.

const DEFAULT_LABEL = "Remember this coding as a rule";

export function RememberTick({ checked = false, onChange, label = DEFAULT_LABEL, name, disabled = false }) {
  if (typeof label !== "string" || !/^Remember\b/.test(label)) throw new TypeError("RememberTick: the label must begin with Remember");
  return (
    <span className="cc-remember t-footnote remember-tick" data-remember-tick="">
      <label className="cbx-hit">
        <input type="checkbox" className="cbx" name={name} checked={checked === true} disabled={disabled} aria-label={label} onChange={(e) => onChange && onChange(e.target.checked === true)} />
        <span>Remember</span>
      </label>
    </span>
  );
}

export function RuleSaved({ remembered }) {
  const said = typeof remembered === "string" ? remembered.trim() : "";
  if (!said) return null;
  return (
    <span className="cc-remembered" title={said} data-rule-saved="">
      Rule saved
    </span>
  );
}
