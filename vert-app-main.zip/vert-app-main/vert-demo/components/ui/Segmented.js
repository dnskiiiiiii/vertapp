"use client";

// components/ui/Segmented.js — ONE CHOICE OUT OF TWO OR THREE, IN PLACE
// ==============================================================================
// Design-pass spec §6.4: All tasks / Assigned to you; Status / Group. A sunken track
// with a raised white thumb that slides to the chosen option on the snappy spring
// (app/styles/kit.css `.segmented`). It is a radio group: one tab stop, the arrow keys
// move the choice (and focus) and wrap, Home and End jump to the ends — the keyboard
// model a person expects from a segmented control (WAI-ARIA radio group).
//
// The thumb's position is two numbers handed to CSS (`--seg-index`, `--seg-count`), so
// a change is a transform transition that re-targets from wherever the thumb is when the
// choice changes again mid-slide (apple-design §3). Under reduced motion it cross-fades.

import { useRef } from "react";

/**
 * `options` is [{ value, label }]; `value` is the chosen one; `onChange(value)` is called
 * with the new choice. `label` names the group for assistive tech.
 */
export function Segmented({ options = [], value, onChange, label, className, size }) {
  const refs = useRef([]);
  const index = Math.max(0, options.findIndex((o) => o.value === value));

  function choose(i, focus) {
    const next = options[(i + options.length) % options.length];
    if (!next) return;
    if (next.value !== value && onChange) onChange(next.value);
    if (focus) {
      const el = refs.current[(i + options.length) % options.length];
      if (el && typeof el.focus === "function") el.focus();
    }
  }

  function onKeyDown(event) {
    const keys = { ArrowRight: index + 1, ArrowDown: index + 1, ArrowLeft: index - 1, ArrowUp: index - 1, Home: 0, End: options.length - 1 };
    if (!(event.key in keys)) return;
    event.preventDefault();
    choose(keys[event.key], true);
  }

  return (
    <div
      className={["segmented", size === "sm" ? "segmented-sm" : null, className].filter(Boolean).join(" ")}
      role="radiogroup"
      aria-label={label}
      style={{ "--seg-count": Math.max(1, options.length), "--seg-index": index }}
      onKeyDown={onKeyDown}
      data-ui="Segmented"
    >
      <span className="segmented-thumb" aria-hidden="true" />
      {options.map((o, i) => (
        <button
          key={o.value}
          ref={(el) => {
            refs.current[i] = el;
          }}
          type="button"
          role="radio"
          className="segmented-option"
          aria-checked={i === index ? "true" : "false"}
          tabIndex={i === index ? 0 : -1}
          onClick={() => choose(i, false)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}
