// components/ui/sheet-spring.js — AN INTERRUPTED SHEET KEEPS ITS MOMENTUM
// ==============================================================================
// apple-design §5: when a moving thing is sent somewhere else, it carries the velocity
// it had into the new motion. A CSS transition cannot: reversed mid-flight it starts
// its new curve from rest, so a sheet closed 80 ms into its entrance jumped from
// moving left at 19 px a frame to moving right at 26 (eval iter 1, A5). Here the exit
// of an interrupted sheet is a critically damped spring seeded with the live
// velocity: it carries on inward for a moment, turns, and leaves along its own edge.
//
// Pure functions, so the physics is tested without a browser (tests/ui-kit.test.js).
// The entrance curve is read from the `--ease-spring` token and its duration from
// `--dur-spring`, so there is one definition of how a sheet moves. A sheet at rest
// (velocity 0) and reduced motion keep the plain CSS exit.

/** Parse `linear(0, 0.115, …, 1)` into its stops (evenly spaced), or null. */
export function parseLinearEasing(value) {
  const m = /^\s*linear\(([^)]*)\)\s*$/.exec(String(value || ""));
  if (!m) return null;
  const stops = m[1].split(",").map((s) => Number.parseFloat(s.trim()));
  if (stops.length < 2 || stops.some((n) => !Number.isFinite(n))) return null;
  return stops;
}

/** `515ms` or `0.515s` → milliseconds, or null. */
export function parseDuration(value) {
  const m = /^\s*([\d.]+)\s*(ms|s)\s*$/.exec(String(value || ""));
  if (!m) return null;
  const n = Number.parseFloat(m[1]);
  return m[2] === "s" ? n * 1000 : n;
}

/**
 * The entrance's velocity at a given progress (0 = closed, 1 = open), in progress per
 * millisecond. The curve is monotonic, so the progress names one point on it; the
 * slope there, over the duration, is how fast the panel was moving.
 */
export function slopeAt(stops, durationMs, progress) {
  const n = stops.length - 1;
  if (!(durationMs > 0) || progress <= stops[0] || progress >= stops[n]) return 0;
  for (let i = 0; i < n; i += 1) {
    if (progress >= stops[i] && progress <= stops[i + 1]) {
      return ((stops[i + 1] - stops[i]) * n) / durationMs;
    }
  }
  return 0;
}

/**
 * The rate of a critically damped spring that settles like the entrance curve does:
 * the time the curve takes to cover 95 % of the way, matched to 1 − (1 + ωt)e^(−ωt).
 */
export function omegaFor(stops, durationMs) {
  const n = stops.length - 1;
  let t95 = durationMs;
  for (let i = 0; i < n; i += 1) {
    if (stops[i + 1] >= 0.95) {
      const f = (0.95 - stops[i]) / (stops[i + 1] - stops[i] || 1);
      t95 = ((i + f) / n) * durationMs;
      break;
    }
  }
  return 4.744 / Math.max(t95, 1);
}

/**
 * The exit as positions, one per frame, from `from` px moving at `velocity` px/ms to
 * `to` px, on a critically damped spring of rate `omega`. Ends exactly at `to`.
 *
 *   x(t) = to + (c1 + c2·t)·e^(−ω·t),  c1 = from − to,  c2 = velocity + ω·c1
 */
export function exitFrames({ from, velocity, to, omega, frameMs = 1000 / 60, maxMs = 1000 }) {
  const c1 = from - to;
  const c2 = velocity + omega * c1;
  const frames = [];
  let t = 0;
  for (; t <= maxMs; t += frameMs) {
    const e = Math.exp(-omega * t);
    const x = to + (c1 + c2 * t) * e;
    const v = (c2 - omega * (c1 + c2 * t)) * e;
    frames.push(x);
    if (t > 0 && Math.abs(x - to) < 0.5 && Math.abs(v) < 0.05) break;
  }
  frames.push(to);
  return { frames, duration: Math.min(t, maxMs) + frameMs };
}

// The axis each placement slides on, and the sign of its off-screen edge.
const AXES = { right: { axis: "x", sign: 1 }, left: { axis: "x", sign: -1 }, bottom: { axis: "y", sign: 1 } };

/**
 * Everything the exit needs from a live panel, or null when a plain CSS exit is right:
 * a modal (it scales, it does not slide), reduced motion, no WAAPI, or a panel at rest.
 * `env` is the window (injectable for tests).
 */
export function planSpringExit(panel, side, env) {
  const place = AXES[side];
  if (!place || !env || !panel || typeof panel.animate !== "function") return null;
  if (env.matchMedia && env.matchMedia("(prefers-reduced-motion: reduce)").matches) return null;
  const root = env.getComputedStyle(env.document.documentElement);
  const stops = parseLinearEasing(root.getPropertyValue("--ease-spring"));
  const duration = parseDuration(root.getPropertyValue("--dur-spring"));
  if (!stops || !duration) return null;

  const live = env.getComputedStyle(panel).transform;
  const m = /matrix\(([^)]*)\)/.exec(live || "");
  const parts = m ? m[1].split(",").map((s) => Number.parseFloat(s)) : [1, 0, 0, 1, 0, 0];
  const offset = place.axis === "x" ? parts[4] : parts[5];
  const extent = place.axis === "x" ? panel.offsetWidth : panel.offsetHeight;
  if (!(extent > 0) || !Number.isFinite(offset)) return null;

  const to = place.sign * extent;
  const progress = 1 - offset / to; // 0 closed, 1 open
  // A sheet let go of after a drag (sheet-drag.js) carries the finger's velocity, which
  // Sheet.js leaves on the panel; otherwise it is moving toward open while entering:
  // toward 0 from the edge, so against the sign.
  const handed = panel.dataset ? Number.parseFloat(panel.dataset.dragVelocity) : Number.NaN;
  const velocity = Number.isFinite(handed) ? handed : -place.sign * extent * slopeAt(stops, duration, progress);
  if (Math.abs(velocity) < 0.01) return null;

  const frameMs = 1000 / 60;
  const { frames, duration: ms } = exitFrames({ from: offset, velocity, to, omega: omegaFor(stops, duration), frameMs });
  const fn = place.axis === "x" ? "translateX" : "translateY";
  return { keyframes: frames.map((x) => ({ transform: `${fn}(${Math.round(x * 100) / 100}px)` })), duration: ms, velocity, frameMs };
}
