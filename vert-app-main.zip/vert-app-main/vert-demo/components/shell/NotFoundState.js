"use client";

// components/shell/NotFoundState.js — AN ADDRESS THAT ISN'T HERE, AND THE WAY ON
// ==============================================================================
// Design-fix-2 DA2-076. The 404 was a bare heading 88 px left of the page column and a
// 17 px underlined link, and an unknown conversation got the same generic sentence. Now,
// in the page column at about 30% of its height:
//
//        [muted navy mark]
//     This conversation doesn't exist      ← title-2, Archivo
//     It may have been removed, or the link is incomplete.
//     [ Go to Month-end ]                  ← secondary
//     Recent conversations
//     Bank reconciliation             4m
//     …                                    ← up to three, from the sidebar's own list
//
// The recent rows are the shell's conversations (the command menu's provider holds the
// same list the sidebar draws), so nothing is read again and nothing here can disagree
// with the sidebar. With none, the list is not drawn.

import { useEffect, useState } from "react";

import { Button } from "@/components/ui/Button";
import { IconChat } from "@/components/ui/icons";

import { ageLabel } from "./age";
import { useCommandMenu } from "./command";
import { MONTH_END_HREF } from "./ia";
import { MARK_SRC, MARK_SRCSET } from "./icons";
import ShellLink from "./ShellLink";
import "./not-found.css";

export const NOT_FOUND_WORDS = Object.freeze({
  page: { title: "There’s nothing at this address", line: "The link may be mistyped, or the page has moved." },
  conversation: { title: "This conversation doesn’t exist", line: "It may have been removed, or the link is incomplete." },
});

function Recent() {
  const { shell } = useCommandMenu();
  const [now, setNow] = useState(null);
  useEffect(() => setNow(Date.now()), []);
  const list = (shell && Array.isArray(shell.conversations) ? shell.conversations : [])
    .filter((c) => c && typeof c.href === "string" && typeof c.title === "string")
    .slice()
    .sort((a, b) => (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0))
    .slice(0, 3);
  if (!list.length) return null;
  return (
    <section className="not-found-recent" aria-labelledby="not-found-recent-heading">
      <p className="not-found-recent-head" id="not-found-recent-heading">
        Recent conversations
      </p>
      <ul>
        {list.map((c) => {
          const age = now === null ? null : ageLabel(c.updatedAt, now);
          return (
            <li key={c.id}>
              <ShellLink href={c.href} pending className="row not-found-row">
                <IconChat className="not-found-row-icon" />
                <span className="not-found-row-title">{c.title}</span>
                {age && age !== "now" ? <span className="not-found-row-age num">{age}</span> : null}
              </ShellLink>
            </li>
          );
        })}
      </ul>
    </section>
  );
}

export default function NotFoundState({ kind = "page" }) {
  const words = NOT_FOUND_WORDS[kind] || NOT_FOUND_WORDS.page;
  return (
    <section className="page not-found" aria-labelledby="not-found-title" data-kind={kind}>
      <div className="not-found-inner">
        {/* eslint-disable-next-line @next/next/no-img-element -- pre-sized static files (components/shell/icons.js) */}
        <img className="not-found-mark" src={MARK_SRC} srcSet={MARK_SRCSET} width="32" height="32" alt="" decoding="async" draggable="false" />
        <h1 className="t-title-2" id="not-found-title">
          {words.title}
        </h1>
        <p className="not-found-line">{words.line}</p>
        <div className="not-found-actions">
          <Button variant="secondary" href={MONTH_END_HREF}>
            Go to Month-end
          </Button>
        </div>
        <Recent />
      </div>
    </section>
  );
}
