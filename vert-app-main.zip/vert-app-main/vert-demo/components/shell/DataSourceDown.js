// components/shell/DataSourceDown.js — WHAT RENDERS WHEN THE BOOKS CANNOT BE READ
// ==============================================================================
// app/layout.js renders this INSTEAD of the page when the close could not be read. No
// page component runs, so nothing downstream can quietly draw an empty month: an empty
// month and an unreachable service look identical on screen, and one of them is a
// false claim that the books are clean.
//
// WRITTEN FOR THE BOOKKEEPER, WITH THE ENGINEERING UNDER DETAILS (UI-051). The old card
// led with the URL that failed, the name of the export file and a paragraph about why
// nothing had fallen back to it. None of that is actionable by the person reading. The
// sentence now says what happened and what did not — nothing is shown, nothing changed
// — and offers the one thing they can do. The failure message, which an operator needs,
// is still here, under Details, and in the server log.
//
// A READ, NOT A WRITE (staging browser walk 3, W3-4). Nothing was asked to be recorded,
// so the card doesn't say "Nothing was recorded" (that is a write's sentence), and its
// Details never show an environment variable, a file path or a shell command outside
// development (lib/public-details.js). The read itself was already asked twice when it
// timed out (lib/engine-source.js READ_TIMEOUT_TRIES).
//
// TRY AGAIN IS A BUTTON THAT ASKS AGAIN BEFORE IT RELOADS (verify pass 4, F17): see
// ./books-retry.js. `data-books-down` is what its no-store probe looks for.

import { IconBlocked } from "@/components/je/icons";
import { Notice } from "@/components/ui/Notice";
import { publicDetails } from "@/lib/public-details";
import BooksRetry from "./BooksRetry";

export default function DataSourceDown({ failure, dev }) {
  const details = publicDetails(
    [failure && failure.apiUrl ? `${failure.apiUrl} could not be read.` : null, failure && failure.message].filter(Boolean).join(" "),
    dev === undefined ? undefined : { dev }
  );
  return (
    <main className="standalone" id="main" data-books-down="">
      <div className="standalone-inner">
        <IconBlocked aria-hidden="true" className="standalone-icon" />
        <h1 className="t-title-1">Vert can’t reach your books right now</h1>
        <p className="t-body standalone-lede">No figures are shown until they can be read.</p>
        <Notice kind="error" recorded="read" details={details || undefined} action={<BooksRetry />}>
          This month couldn’t be loaded.
        </Notice>
      </div>
    </main>
  );
}
