"use client";

// components/shell/AppShell.js — THE FRAME EVERY SIGNED-IN PAGE SITS IN
// ==============================================================================
// Spec §2.1 and §3.8. In document order, which is the Tab order:
//
//   1. the skip link — the first Tab stop on every page (UI-055)
//   2. the phone's top bar (hidden from 1024 px)
//   3. the sidebar — a column from 1024 px, a left sheet below
//   4. <main id="main">, which the skip link lands on
//
// The phone sidebar's open state lives here because two things drive it: the top bar
// opens it, and a navigation, Esc or the scrim closes it. It is a CSS transition on
// `transform`, entering from the left edge and leaving the same way (apple-design §7),
// so closing it halfway through opening turns it back without a jump. Closed, it is
// `visibility: hidden` on a phone (kit.css), which also takes it out of the Tab order
// without waiting for any script.
//
// `.content` keeps the page gutter the screens built before this shell were laid out
// against; a screen that needs to run edge to edge (the conversation) opts out with
// `.bleed`.

import { usePathname } from "next/navigation";
import { Suspense, useCallback, useEffect, useRef, useState } from "react";

import { isPhoneWidth } from "@/lib/breakpoints";
import { inertOutside } from "@/components/ui/inert-outside";

import { NewTaskProvider } from "@/components/month/NewTaskProvider";
import { OPEN_SWITCHER_EVENT, canSwitch, isFirmMode } from "./ClientSwitcher";
import { CommandMenuProvider } from "./command";
import CommandMenu from "./CommandMenu";
import NavProgress from "./NavProgress";
import { ShellReading, useLiveShell } from "./live-shell";
import { LeftChatNotice, RememberShownMonth } from "./MonthControl";
import Sidebar from "./Sidebar";
import { SwitchingNotice } from "./switching";
import SkipLink, { MAIN_ID } from "./SkipLink";
import TopBar from "./TopBar";

export default function AppShell({ shell: rendered, signedInAs = null, children }) {
  // The rendered figures, with the sidebar's own re-read laid over them while Vert is
  // working (live-shell.js). Nothing here re-renders the route on a timer.
  const shell = useLiveShell(rendered || null);
  const pathname = usePathname();
  const [navOpen, setNavOpen] = useState(false);
  // Where focus goes when the sheet opens: its close control from ≡, or the client and
  // month from the top bar's title (spec §6.10: the phone's context lives in that title).
  const openedFor = useRef("menu");
  const lastPath = useRef(pathname);

  // THE TOP BAR'S EDGE APPEARS ONLY WHEN CONTENT IS UNDER IT (design-pass spec §4.3;
  // apple-design §12: scroll edges, not hard dividers). A one-pixel sentinel at the top
  // of the page leaves the space below the bar the moment the page scrolls; an
  // IntersectionObserver says so, never a scroll listener (taste §5.D).
  const sentinel = useRef(null);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const el = sentinel.current;
    if (!el || typeof IntersectionObserver === "undefined") return undefined;
    // The bar's height is a rem token, so it follows the reader's text size; the
    // observer wants pixels.
    const root = getComputedStyle(document.documentElement);
    const bar = Math.round(parseFloat(root.getPropertyValue("--topbar-h")) * parseFloat(root.fontSize)) || 44;
    const io = new IntersectionObserver(([entry]) => setScrolled(!entry.isIntersecting), { rootMargin: `-${bar}px 0px 0px 0px` });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  const closeNav = useCallback(() => setNavOpen(false), []);

  // A navigation closes the phone sidebar: the sheet was a way to get somewhere.
  useEffect(() => {
    if (lastPath.current !== pathname) {
      lastPath.current = pathname;
      setNavOpen(false);
    }
  }, [pathname]);

  useEffect(() => {
    if (!navOpen) return undefined;
    function onKey(event) {
      if (event.key === "Escape") setNavOpen(false);
    }
    document.addEventListener("keydown", onKey);
    // Focus goes into the sheet: to the client switcher, opened, when the title was
    // pressed (or the month, for a key with one client); else to its first control.
    const context = openedFor.current === "context";
    const toggle = context ? document.querySelector("#sidebar button.switcher-toggle") : null;
    const first = toggle || document.querySelector("#sidebar .sidebar-close");
    if (first) first.focus();
    if (toggle) window.dispatchEvent(new Event(OPEN_SWITCHER_EVENT));
    // THE DRAWER IS MODAL (design-fix-2 DA2-014): while it is open everything outside
    // #sidebar is inert, so Tab cannot walk into the ask box and the decision options
    // under the scrim. Only on a phone, where the sidebar is a drawer at all.
    const sidebar = document.getElementById("sidebar");
    const undoInert = isPhoneWidth(window) && sidebar ? inertOutside(sidebar) : () => {};
    // The scrim stays live: a tap on it is how the drawer closes.
    const scrim = document.querySelector(".shell > .sidebar-scrim");
    if (scrim) scrim.removeAttribute("inert");
    return () => {
      document.removeEventListener("keydown", onKey);
      undoInert();
    };
  }, [navOpen]);

  // Focus returns to ≡ when the phone sidebar closes.
  const wasOpen = useRef(false);
  useEffect(() => {
    if (wasOpen.current && !navOpen) {
      const menu = document.querySelector(".topbar-menu");
      if (menu && isPhoneWidth(window)) menu.focus();
    }
    wasOpen.current = navOpen;
  }, [navOpen]);

  return (
    // The command menu (founder decision D6; design-fix-2 §6): one provider for the whole
    // shell, so ⌘K / Ctrl+K works from every page. Its UI is CommandMenu.js (DS-SHELL).
    <CommandMenuProvider shell={shell}>
    {/* The one new-task form (founders, 22 Oct 2026): the sidebar, Month-end and the home
        page open it with useNewTask().openNewTask() (NewTaskProvider.js). */}
    <NewTaskProvider shell={shell} signedInAs={signedInAs} firmMode={canSwitch(signedInAs) && isFirmMode(pathname)}>
    <div className="shell" data-nav-open={navOpen ? "true" : "false"}>
      <SkipLink />
      <RememberShownMonth period={shell && shell.period} />
      <Suspense fallback={null}>
        <NavProgress />
      </Suspense>
      <TopBar
        client={shell && shell.client}
        period={shell && shell.period}
        navOpen={navOpen}
        onOpenNav={() => {
          openedFor.current = "menu";
          setNavOpen(true);
        }}
        onOpenContext={() => {
          openedFor.current = "context";
          setNavOpen(true);
        }}
        pathname={pathname}
        scrolled={scrolled}
      />
      <Sidebar shell={shell || undefined} signedInAs={signedInAs} pathname={pathname} onClose={closeNav} />
      <button type="button" className="sidebar-scrim" tabIndex={-1} aria-label="Close sidebar" onClick={closeNav} />
      <main id={MAIN_ID} className="shell-main" tabIndex={-1}>
        <span className="scroll-sentinel" ref={sentinel} aria-hidden="true" />
        <SwitchingNotice clientId={(shell && shell.clientId) || null} />
        <div className="content">
          <LeftChatNotice />
          {/* The live reading, for a page that lists the same conversations (the
              homepage board, components/home/live.js): one poll, not two. */}
          <ShellReading.Provider value={shell}>{children}</ShellReading.Provider>
        </div>
      </main>
      <CommandMenu />
    </div>
    </NewTaskProvider>
    </CommandMenuProvider>
  );
}
