"use client";

// components/shell/AccountMenu.js — WHO IS SIGNED IN, THE SETTINGS, THE WAY OUT
// ==============================================================================
// Spec §2.1; audit UI-055. The foot of the sidebar: the person, and a menu holding
// Connections and Sign out. Sign out used to be the seventh Tab stop on every page,
// ahead of the content; it now sits one press inside this menu.
//
// THE NAME SHOWN IS THE ACCOUNT'S, NEVER THE KEY'S. With a session, the line is the
// business the books belong to (else the tenant), through lib/format.js
// `accountName`. It used to be `actingAsFor(signedInAs)` — "key: founder test" — the
// credential label lib/session.js writes into the audit trail. That string is still
// what the books record (lib/acting-as.js is untouched, and the actor rule still has
// one home); it is not a name to greet somebody with (UI-024; eval S6). The authored
// demo preparer appears only in the static build, where nobody is signed in and
// nothing is written.
//
// PAUSE VERT sits here too (build plan §19.0.6): the kill switch belongs with the
// account, one press from anywhere, and says what it does beside the press.
//
// A PERSON KEY NAMES A PERSON (build plan §19.0.9, §19.9 F-FIRM). When the session
// carries one, the toggle shows that person and the menu opens on "Signed in as Sam
// Lee" — the same string lib/acting-as.js sends as the actor and the engine records
// on every approval, so the plate and the audit trail can never name two people. The
// name comes from the session, never from this file: no name is written here.
//
// PEOPLE AND ROLES (build plan §20.12 H3, F-SEC). A person key in a firm gets one more
// row: the people sheet, where everyone reads who is an admin, reviewer or preparer and
// an admin changes it. The plate says the signed-in person's own role beside their
// name, from the engine's read on this page (lib/duties.js), and nothing when the
// engine reported none.
//
// ONE LINE PER ITEM, IN THREE GROUPS (design-fix-2 DA2-064). The person (body 500) over
// their role (caption), then [Connections, People and roles] | [Pause Vert…] | [Sign out],
// each group ruled off by a hairline, 32 px rows (44 on touch). Pause Vert's consequence
// lives in its confirm (PauseVertItem.js), not as a paragraph in the menu. Tab out of the
// menu closes it (DA2-014), and People and roles also opens from the command menu and the
// firm sidebar, through OPEN_PEOPLE_EVENT.
//
// A disclosure, not an ARIA menu: two links do not need a menu's key model, and a
// widget that announces itself as a menu but does not behave like one is worse than a
// plain list. The list is always in the document and `hidden` while closed.

import ShellLink from "./ShellLink";
import { useEffect, useId, useRef, useState } from "react";

import SignOutButton from "@/components/auth/SignOutButton";
import PeopleSheet from "@/components/firm/PeopleSheet";
import { ROLE_WORDS, dutiesOf } from "@/lib/roles";
import { USER } from "@/lib/data";
import { personOf } from "@/lib/acting-as";
import { accountName } from "@/lib/format";

import { OPEN_PEOPLE_EVENT } from "./command";
import { ACCOUNT_LINKS } from "./ia";
import { closeOnFocusOut, focusIntoMenu } from "./menu-focus";
import { IconConnections, IconMore, IconPeople } from "./icons";
import PauseVertItem from "./PauseVertItem";

function initialsOf(text) {
  const parts = String(text || "").split(/[^A-Za-z0-9]+/).filter(Boolean);
  if (!parts.length) return "·";
  return parts.slice(0, 2).map((p) => p[0].toUpperCase()).join("");
}

export default function AccountMenu({ signedInAs = null, business = null }) {
  const [open, setOpen] = useState(false);
  // Mounted on first open and kept for its exit, like the cards' sheets.
  const [people, setPeople] = useState({ mounted: false, open: false });
  const menuId = useId();
  const root = useRef(null);
  const toggle = useRef(null);
  const menu = useRef(null);

  const account = signedInAs ? accountName({ business, tenant: signedInAs.tenant }) || "Your account" : USER.name;
  const person = personOf(signedInAs);
  const who = person || account;
  const initials = signedInAs ? initialsOf(who) : USER.initials;
  const duties = dutiesOf(signedInAs);
  const inFirm = Boolean(person && signedInAs && signedInAs.firm);

  useEffect(() => {
    if (!open) return undefined;
    // Focus moves inside on open (ui-pass-1 output-ui #24); Esc brings it back.
    focusIntoMenu(menu.current);
    function onKey(event) {
      if (event.key === "Escape") {
        setOpen(false);
        if (toggle.current) toggle.current.focus();
      }
    }
    function onPointer(event) {
      if (root.current && !root.current.contains(event.target)) setOpen(false);
    }
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onPointer);
    const undoFocus = closeOnFocusOut(root.current, () => setOpen(false), toggle.current);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onPointer);
      undoFocus();
    };
  }, [open]);

  // People and roles opens from elsewhere too: the command menu and the firm sidebar.
  useEffect(() => {
    if (!inFirm) return undefined;
    function onPeople() {
      setOpen(false);
      setPeople({ mounted: true, open: true });
    }
    window.addEventListener(OPEN_PEOPLE_EVENT, onPeople);
    return () => window.removeEventListener(OPEN_PEOPLE_EVENT, onPeople);
  }, [inFirm]);

  const role = duties && duties.role ? ROLE_WORDS[duties.role] : null;

  return (
    <div className="account" ref={root}>
      <div className="account-menu" id={menuId} ref={menu} hidden={!open}>
        {person ? (
          <div className="account-head">
            <p className="account-tenant">
              <span className="sr-only">Signed in as </span>
              <span className="account-person">{person}</span>
            </p>
            {role ? (
              <p className="account-role" data-role={duties.role}>
                {role}
              </p>
            ) : null}
          </div>
        ) : signedInAs ? (
          <div className="account-head">
            <p className="account-tenant">Signed in to {account}</p>
          </div>
        ) : null}
        <ul className="account-links" aria-label="Settings">
          {ACCOUNT_LINKS.map((link) => (
            <li key={link.href}>
              <ShellLink href={link.href} className="row menu-item" onClick={() => setOpen(false)}>
                <IconConnections />
                <span>{link.label}</span>
              </ShellLink>
            </li>
          ))}
          {inFirm ? (
            <li>
              <button
                type="button"
                className="row menu-item"
                data-people-roles=""
                onClick={() => {
                  setOpen(false);
                  setPeople({ mounted: true, open: true });
                }}
              >
                <IconPeople />
                <span>People and roles</span>
              </button>
            </li>
          ) : null}
        </ul>
        {signedInAs ? (
          // Pause Vert (build plan §19.0.6, §19.6 F-BRAIN): only with a session, the
          // only build with an engine to pause; its state is read when the menu opens.
          <ul className="account-links account-group">
            <li>
              <PauseVertItem open={open} onPicked={() => setOpen(false)} />
            </li>
          </ul>
        ) : null}
        {signedInAs ? (
          <ul className="account-links account-group">
            <li>
              <SignOutButton />
            </li>
          </ul>
        ) : null}
      </div>
      <button
        type="button"
        ref={toggle}
        className="row account-toggle"
        aria-expanded={open ? "true" : "false"}
        aria-controls={menuId}
        onClick={() => setOpen((was) => !was)}
      >
        <span className="avatar" aria-hidden="true">
          {initials}
        </span>
        <span className="account-who" translate="no">{who}</span>
        <IconMore className="account-more" />
        <span className="sr-only">, account and sign out</span>
      </button>
      {people.mounted ? (
        <PeopleSheet
          open={people.open}
          onClose={() => setPeople((p) => ({ ...p, open: false }))}
          you={person}
          role={duties ? duties.role : null}
        />
      ) : null}
    </div>
  );
}
