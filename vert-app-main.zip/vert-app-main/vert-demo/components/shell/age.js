// components/shell/age.js — HOW LONG AGO A CONVERSATION LAST MOVED
// ==============================================================================
// Visual parity (build plan §17; visual spec §1): the reference's Recent list carries a
// short, right-aligned age on every row ("1m", "4m", "29m"), so you can tell the work
// that is moving from the work that has stalled without opening either.
//
// The age is read from the engine's own `updatedAt`. A row with no readable time gets
// no age at all, never "0m": an unread time is not a measured "just now". A time in the
// future by more than a minute (a skewed clock) is equally unreadable, so it too is left
// blank rather than drawn as "now".

const MIN = 60 * 1000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

/** The instant `value` names, in ms, or null when it cannot be read as one. */
export function instantOf(value) {
  if (typeof value !== "string" || !value.trim()) return null;
  const ms = Date.parse(value);
  return Number.isFinite(ms) ? ms : null;
}

/**
 * The short age label for an instant, measured against `nowMs`: "now", "4m", "2h",
 * "3d", "5w". Null when either time is unreadable or the instant is in the future.
 */
export function ageLabel(atMs, nowMs) {
  if (!Number.isFinite(atMs) || !Number.isFinite(nowMs)) return null;
  const d = nowMs - atMs;
  if (d < -MIN) return null;
  if (d < MIN) return "now";
  if (d < HOUR) return `${Math.floor(d / MIN)}m`;
  if (d < DAY) return `${Math.floor(d / HOUR)}h`;
  if (d < 7 * DAY) return `${Math.floor(d / DAY)}d`;
  return `${Math.floor(d / (7 * DAY))}w`;
}

/** The same age spelled out for assistive tech: "updated 4 minutes ago". */
export function ageWords(label) {
  if (!label) return null;
  if (label === "now") return "updated just now";
  const n = Number(label.slice(0, -1));
  const unit = { m: "minute", h: "hour", d: "day", w: "week" }[label.slice(-1)];
  return `updated ${n} ${unit}${n === 1 ? "" : "s"} ago`;
}
