// components/shell/conversation-groups.js — WHICH CONVERSATIONS THE SIDEBAR SHOWS
// ==============================================================================
// Spec §2.1 and §4.5; eval iter 1 round 2, finding 2 (S2, S4). The sidebar listed every
// conversation of the month above the fold — eleven rows, three of them the same
// question asked three times — and those titles alone took Month-end from 101 words
// and 4 concepts in the page to 164 words and 10 concepts on the screen. The list is
// for the work UNDER WAY; the month's history already lives on Month-end.
//
// So the list is split in two, and nothing is computed about a conversation beyond
// reading its status word:
//
//   now      every conversation that is Needs you or Vert's working — never folded,
//            whatever their number, because each one is waiting on the reader or about
//            to be — then the most recent of the rest, until the list holds
//            RECENT_SLOTS rows. The one being read is always here.
//   earlier  everything else, behind "Earlier · N", closed. Its words are not on the
//            screen until someone asks for them.
//
// WHY A THREE-ROW BUDGET AND NOT "ACTIVE PLUS THREE". With two conversations needing
// you, "plus three" is five rows and the screen goes back over its word budget; the
// budget is the screen's, so the recent rows fill what the active ones leave.
//
// A REPEATED QUESTION IS ONE ROW. Asking "Which July payouts still need me?" three
// times made three conversations with one title. Past the first, a conversation whose
// title reads the same (case, spacing and closing punctuation aside) as one already
// listed goes to Earlier — unless it needs you or is running, which is never hidden.
// Merging the repeats into one conversation is the service's job (build plan §3 E3);
// this only stops the list from saying the same thing three times.
//
// The order within each group is the order the reader gave: needs-you first, then the
// most recently updated (the service sorts on `updated_at`).

export const RECENT_SLOTS = 3;

const ACTIVE = new Set(["Needs you", "Vert's working"]);

/** A title as a person would compare two: case, runs of spaces and end punctuation aside. */
export function sameTitleKey(title) {
  return String(title || "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .replace(/[\s.?!…:;,]+$/u, "")
    .trim();
}

/**
 * `{ now, earlier }` for the list. `current` is the href being shown, if any; that
 * conversation is always in `now` so the reader never loses the row they are on.
 */
export function groupConversations(list = [], { current = "", slots = RECENT_SLOTS } = {}) {
  // ONLY WHAT YOU ASKED (founder, 8 Nov 2026). One "reconcile the bank" put four rows in
  // the list: the question and the three tasks it ran ("Reconcile the bank account"
  // twice, "Credit card reconciliation"), each with its own count, and a "3 conversations
  // need you" toast. A task's conversation (its row names a `template`) belongs to the
  // month's checklist on Month-end, and its answer and questions come back into the
  // conversation that asked; the list keeps the conversations a person started, and the
  // one being read.
  const rows = (Array.isArray(list) ? list : []).filter((c) => c && (!c.template || (current && c.href === current)));
  const seen = new Set();
  const now = [];
  const rest = [];

  for (const c of rows) {
    const key = sameTitleKey(c.title);
    if (ACTIVE.has(c.status) || (current && c.href === current)) {
      now.push(c);
      seen.add(key);
    } else {
      rest.push(c);
    }
  }

  const earlier = [];
  let room = Math.max(0, slots - now.length);
  for (const c of rest) {
    const key = sameTitleKey(c.title);
    if (room > 0 && !seen.has(key)) {
      now.push(c);
      seen.add(key);
      room -= 1;
    } else {
      earlier.push(c);
    }
  }

  // `now` keeps the reader's order: the rows pulled forward above are re-sorted into the
  // positions they held in the list the reader gave.
  const at = new Map(rows.map((c, i) => [c, i]));
  now.sort((a, b) => at.get(a) - at.get(b));
  return { now, earlier };
}

/**
 * The decisions count a sidebar row draws, or null for none (verify pass 5, S-E2E-1 F16).
 *
 * A DONE CONVERSATION DRAWS NO COUNT. The row's word comes from `GET /agent/sessions` and
 * its count from `GET /close/{period}` (components/shell/shell-data.js), two reads that
 * can land either side of the moment a task finishes: "Balance sheet roll-forwards, Done"
 * was drawn with "1 decision" beside it, a row contradicting itself. Done means nothing
 * waits on anyone in it, so the count is not drawn there; the read that disagreed is
 * re-read (components/shell/live-shell.js `unsettled`), and the Month-end badge stays the
 * engine's own figure. Pure.
 */
export function decisionCount(row) {
  if (!row || row.status === "Done") return null;
  return typeof row.decisions === "number" && Number.isInteger(row.decisions) && row.decisions > 0 ? row.decisions : null;
}
