// components/shell/ia.js — THE INFORMATION ARCHITECTURE
// =====================================================
// Spec §2.1, amended by scheduled-spec.md (31 Oct 2026). Two destinations and a setting:
//
//     Month-end   /            ← its badge is the decisions that need you
//     Scheduled   /scheduled   ← its badge is the drafts waiting for a person
//     ──────────
//     Connections /connections
//
// and, below them, this month's conversations, which are a list and not navigation. The
// nine-item rail this replaces had four areas that did nothing and five that were
// organised by engine object (UI-066, UI-063); the work happens in conversations and in
// the routines, and everything else is evidence you reach from a figure.
//
// The nav item is named for its contents, not "Home" (apple-design §16, "direct,
// specific labels"). Records is deliberately NOT here: it is evidence, reached from a
// figure's source or a task row.
//
// Everything that draws the sidebar reads this file, and tests/sidebar.test.js checks
// every href here resolves to a route on disk.

import { IconClients, IconConnections, IconMonthEnd, IconPeople, IconRepeat } from "@/components/ui/icons";

export const MONTH_END_HREF = "/";

// ITS COUNT IS THE MONTH'S DECISIONS (design-pass spec §6.7 "Month-end 13"; checklist
// U61, verify pass 1 F-9). Design-fix-2 (DA2-006) took the badge off and the bx merge kept
// it off, so of the five places the decisions are counted only three were left to agree.
// The badge is `counts.decisions` as the shell read it (shell-data.js), drawn only when
// it is a measured count above zero: an unread count is no badge, never a 0.
// SCHEDULED (scheduled-spec.md, founder approved 31 Oct 2026). Bills & invoices and
// Journals stopped being modules: one section holds the daily, weekly and monthly
// routines (the sync, the bill inbox, reminders, recurring journals, depreciation, the
// month's start). Its count is the engine's `waitingTotal` from `GET /scheduled`, the
// items a run drafted that wait for a person, drawn only when it is a measured count
// above zero (shell-data.js), as Month-end's is. One-off journals are Records' "New
// entry"; /bills and /journals are redirected (next.config.mjs).
//
// CONNECTIONS, BELOW A RULE (the spec's sidebar): the setting a person comes back to most
// (Xero, the bank feeds), under the two places, apart from them. It stays in the account
// menu too.
export const SCHEDULED_HREF = "/scheduled";
export const CONNECTIONS_HREF = "/connections";
export const NAV = [
  { label: "Month-end", href: MONTH_END_HREF, icon: IconMonthEnd, counter: "decisions" },
  { label: "Scheduled", href: SCHEDULED_HREF, icon: IconRepeat, counter: "waiting" },
];
export const NAV_AFTER_RULE = [{ label: "Connections", href: CONNECTIONS_HREF, icon: IconConnections, counter: null }];

// THE MONTH'S EVIDENCE IS UNDER MONTH-END (verify pass 1 F-33, U10). Records and the
// reconciliation papers are reached from Month-end's figures and are not nav items of
// their own (above), so on them the Month-end row is the current section, not nothing.
// The month's financial statements (W4 Step 5, 29 Oct 2026) are reached from Month-end's
// "Close the month" panel the same way, and are Month-end's section too.
export const MONTH_END_SECTION = ["/records", "/reconciliation", "/statements", "/reports"];

// THE FIRM VIEW IS A PLACE, NOT A MODE OF THE SWITCHER (design-pass spec §6.10; audit
// §12 P2). For a person in a firm the primary nav gains "All clients", under Month-end,
// and the client switcher above it only ever names a client. It used to read
// "Firm · All clients" on the Clients view, which looked like a breadcrumb and put two
// facts in one control. Drawn only for a person in a firm (ClientSwitcher.js canSwitch):
// a tenant key has one client and no Clients view to go to.
export const CLIENTS_HREF = "/clients";
// "Clients", the page's own title (design-fix-2 DA2-081: the nav said "All clients" over a
// page titled "Clients").
export const FIRM_NAV = [{ label: "Clients", href: CLIENTS_HREF, icon: IconClients, counter: null }];

// FIRM MODE'S OWN PLACES (design-fix-2 DA2-043). On the Clients view the sidebar draws
// these instead of a client's switcher, nav and conversations, under a "Firm" heading.
// People and roles is a sheet, not a route: its row sends the event the account menu
// listens for (command/sources.js OPEN_PEOPLE_EVENT), so there is one sheet and one way in.
export const FIRM_PLACES = [
  { label: "Clients", href: CLIENTS_HREF, icon: IconClients },
  { label: "People and roles", event: "people", icon: IconPeople },
];

// The account menu (spec §2.1): the settings this product has, and the way out.
// Sign out is a form, not a link, and is drawn by components/auth/SignOutButton.js.
export const ACCOUNT_LINKS = [{ label: "Connections", href: "/connections" }];

// ──────────────────────────────────────────────────────────────────────────────
// TRANSITIONAL NAMES, each with the workstream that retires it.
// ──────────────────────────────────────────────────────────────────────────────
//
// HOME_HREF is where app/page.js sends `/` until Month-end is built there. It cannot be
// "/" yet: app/page.js is still the old redirect, and pointing it at itself would loop.
// When app/page.js becomes Month-end, nothing needs this, and it goes with the old
// landing screen's tests.
export const HOME_HREF = "/payouts";

// AREAS is the old placeholder copy. The sidebar renders none of it. It stays only
// because components/shell/PlaceholderArea.js still serves app/chat/page.js until that
// route becomes a redirect, and tests/claims.test.js reads the Connections sentence;
// both are replaced in this iteration, and this export goes with them.
export const AREAS = {
  "/chat": {
    title: "Chat",
    line: "Ask a question about the books and get the answer drawn from the reconciliations already open here, with the workings shown, never a model doing arithmetic in its head.",
  },
  "/connections": {
    title: "Connections",
    line: "Which processors are connected and which clearing account each one pays into, how close a deposit has to be before it counts as a match, and which model the agent may consult on the exceptions nothing could settle.",
  },
};
