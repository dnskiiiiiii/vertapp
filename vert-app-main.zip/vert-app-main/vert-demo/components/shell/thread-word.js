"use client";

// components/shell/thread-word.js — THE OPEN CONVERSATION'S WORD, SHARED WITH THE SIDEBAR
// ==============================================================================
// Iteration 3 W0c (eval polish visual finding 4, carry-over item 3). The sidebar drew
// a green ✓ Done beside "Resolve payout breaks" while that conversation's own header
// said Needs you and Month-end counted a decision in it. Two readers, two readings:
// the header reads the conversation's last `run_state` (lib/agent/events.js
// threadModel), the sidebar the session row the layout read when the page was drawn
// (`agent_sessions.state`), and between a settle and the next page render the two can
// say different things about the same conversation on the same screen.
//
// THE HEADER'S READING WINS, FOR THE ONE CONVERSATION BEING READ. It is the newer of
// the two (the event stream follows the conversation live; the layout's list is a
// render old) and it is the engine's own word from the engine's own event — nothing is
// worked out here. The conversation view publishes its word under its href; the list
// lays it over that one row. Every other row keeps the layout's word, and a word
// outside the four is refused rather than drawn.
//
// It is a module-level store (one tab, one open conversation), read through
// useSyncExternalStore so the sidebar re-renders exactly when the word moves.

import { useEffect, useSyncExternalStore } from "react";
import { isStatusWord } from "@/lib/status";

let current = Object.freeze({});
const listeners = new Set();

function emit() {
  for (const l of listeners) l();
}

/** Lay `word` over the row at `href`. A non-word clears it. */
export function publishThreadWord(href, word) {
  if (typeof href !== "string" || !href) return;
  const next = { ...current };
  if (isStatusWord(word)) next[href] = word;
  else delete next[href];
  if (next[href] === current[href] && Object.keys(next).length === Object.keys(current).length) return;
  current = Object.freeze(next);
  emit();
}

/** Stop laying a word over `href` (the conversation was left). */
export function clearThreadWord(href) {
  if (!(href in current)) return;
  const next = { ...current };
  delete next[href];
  current = Object.freeze(next);
  emit();
}

export function threadWords() {
  return current;
}

function subscribe(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

const EMPTY = Object.freeze({});

export function useThreadWords() {
  // The server snapshot is the same store: it is only ever written in an effect (the
  // browser), so on a server it is empty, and a test can render what a tab would.
  return useSyncExternalStore(subscribe, threadWords, threadWords);
}

/** The conversation view's side: publish this conversation's word while it is shown. */
export function usePublishThreadWord(href, word) {
  useEffect(() => {
    publishThreadWord(href, word);
  }, [href, word]);
  useEffect(() => () => clearThreadWord(href), [href]);
}

/**
 * The conversations with each published word laid over its row. Pure. A row whose
 * href has no published word is returned as it was; the list's order is not touched
 * (the reader's order, needs-you first, is the reader's).
 */
export function withThreadWords(conversations, words) {
  const list = Array.isArray(conversations) ? conversations : [];
  const w = words && typeof words === "object" ? words : EMPTY;
  if (!Object.keys(w).length) return list;
  return list.map((c) => (c && typeof c.href === "string" && isStatusWord(w[c.href]) && w[c.href] !== c.status ? { ...c, status: w[c.href] } : c));
}
