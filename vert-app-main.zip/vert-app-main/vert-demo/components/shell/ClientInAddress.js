"use client";

// components/shell/ClientInAddress.js — THE ADDRESS BAR NAMES THE CLIENT ON SCREEN
// ==============================================================================
// Verify pass 2 S-E2E-3: a task conversation's id is the same on every client, so
// `/chat/2026-07-approve_entries` copied from Fresh Start opened Stresslab's thread for
// whoever was on Stresslab. Every in-app link opens the conversation under the client
// on screen; once it is open, the address is rewritten in place to carry
// `?client=<tenant>`, so the link anyone copies from the bar names its books and the
// conversation page switches to (or refuses) that client before reading anything.
// Nothing navigates: history.replaceState keeps the page, the scroll and the stream.

import { usePathname, useSearchParams } from "next/navigation";
import { useEffect } from "react";

/** The address with `client` set, or null when it already names that client. Pure. */
export function withClient(href, client) {
  if (typeof href !== "string" || typeof client !== "string" || !client) return null;
  let url;
  try {
    url = new URL(href);
  } catch {
    return null;
  }
  if (url.searchParams.get("client") === client) return null;
  url.searchParams.set("client", client);
  // `looked` was a one-trip marker of the client search; it means nothing once open.
  url.searchParams.delete("looked");
  return `${url.pathname}${url.search}${url.hash}`;
}

/**
 * The arguments for `history.replaceState` that put `next` in the bar AND in the router.
 *
 * THE STATE IS NULL ON PURPOSE (verify pass 5, S-CF-9 F3). Next's app router patches
 * replaceState: a call whose state carries its own marker (`__NA`) is taken as the
 * router's own and passed straight through, so the router's canonical URL keeps the old
 * address. This passed `window.history.state` (which carries `__NA`), so the bar named
 * the client and the router did not: a Server Action posts to the router's URL, and when
 * the session expired mid-press the way back to sign in (`/login?next=`) named a
 * conversation with no client, and the reviewer came back on another client's July.
 * With a null state Next copies its own tree into the entry and moves its canonical URL
 * to `next` (next/dist/client/components/app-router.js), with no request and no render.
 */
export function replaceArgs(next) {
  return [null, "", next];
}

export default function ClientInAddress({ client }) {
  // Re-stamped on every address change inside the conversation (another id, `?view=`):
  // an in-app push names no client, and the bar must still name it after one.
  const pathname = usePathname();
  const search = useSearchParams();
  const query = search ? search.toString() : "";
  useEffect(() => {
    const next = withClient(window.location.href, client);
    if (next) window.history.replaceState(...replaceArgs(next));
  }, [client, pathname, query]);
  return null;
}
