"use client";

// components/shell/BackgroundNotice.js — "Bank rec needs you · Open ›"
// ==============================================================================
// Spec §4.5. Several conversations run at once and nothing is modal across them. When
// one you are NOT looking at starts needing you, one quiet notice appears, anchored to
// the conversation list:
//
//   · announced with `aria-live="polite"` — the live region is always in the document,
//     empty when there is nothing to say, because a region that appears together with
//     its text is not reliably announced;
//   · one at a time: a second one replaces the text ("2 chats are waiting on you");
//   · it stays until opened or dismissed; no sound, no modal, no timer.
//
// WHAT COUNTS AS "STARTED NEEDING YOU". A conversation that already needed you when
// this page loaded is in the list, first, with its amber mark — announcing it too would
// be noise on every page load. So the ones seen at mount are remembered, and only a
// conversation that turns to Needs you afterwards (after a refresh brings new data)
// raises the notice. The one you are reading never does.
//
// THE RE-READ. While any conversation is Vert's working, the shell re-reads this
// month's list every 15 seconds while the tab is visible (components/shell/live-shell.js),
// so a background task that reaches a decision surfaces here. It reads data and never
// re-renders the route: a timed router.refresh() used to, and a cut-off one became a
// full browser navigation back to the page being left (eval iter 1, D6). Nothing polls
// while nothing is running.

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";

import { IconButton } from "@/components/ui/Button";

import { IconClose } from "./icons";

import { IconCaretRight } from "@/components/ui/icons";
/** The notice's sentence for the conversations that turned to Needs you, or null. */
export function backgroundNoticeText(fresh) {
  if (!fresh.length) return null;
  if (fresh.length === 1) return `${fresh[0].title} needs you`;
  // Chats, not tasks (9 Nov 2026): "8 conversations need you" read as a second count
  // beside Month-end's "Needs you 9" badge, which counts tasks.
  return `${fresh.length} chats are waiting on you`;
}

export default function BackgroundNotice({ conversations = [], pathname = "" }) {
  const seen = useRef(null);
  const [dismissed, setDismissed] = useState(() => new Set());

  // Everything that needed you when this page first rendered.
  if (seen.current === null) {
    seen.current = new Set(conversations.filter((c) => c.status === "Needs you").map((c) => c.id));
  }

  const fresh = useMemo(
    () =>
      conversations.filter(
        // A task's conversation isn't announced (founder, 8 Nov 2026): its question is
        // asked in the conversation that ran it, and Month-end's badge counts it.
        (c) => c.status === "Needs you" && !c.template && !seen.current.has(c.id) && !dismissed.has(c.id) && c.href !== pathname
      ),
    [conversations, dismissed, pathname]
  );

  // Opening one counts as having seen it.
  useEffect(() => {
    const open = conversations.find((c) => c.href === pathname);
    if (open) seen.current.add(open.id);
  }, [conversations, pathname]);

  const text = backgroundNoticeText(fresh);

  function dismiss() {
    setDismissed((was) => new Set([...was, ...fresh.map((c) => c.id)]));
  }

  return (
    <div className="background-notice-region" aria-live="polite">
      {text ? (
        <div className="background-notice" data-ui="BackgroundNotice">
          <p className="background-notice-text">{text}</p>
          <Link href={fresh[0].href} className="link">
            Open<IconCaretRight className="caret-trailing" />
          </Link>
          <IconButton label="Dismiss" onClick={dismiss} className="background-notice-dismiss">
            <IconClose width="16" height="16" />
          </IconButton>
        </div>
      ) : null}
    </div>
  );
}
