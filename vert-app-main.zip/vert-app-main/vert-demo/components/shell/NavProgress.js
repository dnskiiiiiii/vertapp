"use client";

// components/shell/NavProgress.js — THE PAGE SAYS IT HEARD THE PRESS
// ==============================================================================
// Design-fix-2 DA2-030 (spec §8.4 "Loading"). With the service slow, a press on a link
// left the old page standing unchanged for seconds: the audit held a navigation for 8 s
// and only the clicked row turned grey. Every press now answers twice:
//
//   · on the row itself, a 12 px turning ring (ShellLink.js, next/link useLinkStatus);
//   · across the top of the window, a 2 px bar in the ink, once the wait has passed
//     150 ms (a fast navigation never shows it, so it never flickers).
//
// The bar is the ink, not the accent: a navigation is not a write (§2.2). It creeps
// toward the right on a long ease and never reaches it until the new route has drawn;
// then it fills and fades. Under reduced motion it is a still bar that appears and goes.
//
// How it knows a navigation started: a press (capture phase) on a same-origin link to a
// different address, with no modifier key and no target, is the start; the pathname or
// the query changing is the end. Nothing here patches the router.

import { usePathname, useSearchParams } from "next/navigation";
import { useEffect, useRef, useState } from "react";

const DELAY_MS = 150;

/** Is this click the start of an in-app navigation? Pure, for the tests. */
export function startsNavigation(event, anchor, here) {
  if (!anchor || event.defaultPrevented) return false;
  if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return false;
  if (anchor.target && anchor.target !== "_self") return false;
  if (anchor.hasAttribute("download")) return false;
  let url;
  try {
    url = new URL(anchor.href, here.href);
  } catch {
    return false;
  }
  if (url.origin !== here.origin) return false;
  return url.pathname !== here.pathname || url.search !== here.search;
}

export default function NavProgress() {
  const pathname = usePathname();
  const search = useSearchParams();
  const [state, setState] = useState("idle"); // idle | waiting | shown | done
  const timer = useRef(null);
  const key = `${pathname}?${search ? search.toString() : ""}`;
  const last = useRef(key);

  useEffect(() => {
    function onClick(event) {
      const anchor = event.target && event.target.closest ? event.target.closest("a[href]") : null;
      if (!startsNavigation(event, anchor, window.location)) return;
      clearTimeout(timer.current);
      setState("waiting");
      timer.current = setTimeout(() => setState((s) => (s === "waiting" ? "shown" : s)), DELAY_MS);
    }
    document.addEventListener("click", onClick, true);
    return () => {
      document.removeEventListener("click", onClick, true);
      clearTimeout(timer.current);
    };
  }, []);

  // The route changed: the wait is over.
  useEffect(() => {
    if (last.current === key) return;
    last.current = key;
    clearTimeout(timer.current);
    setState((s) => (s === "shown" ? "done" : "idle"));
  }, [key]);

  // The finished bar fades, then goes.
  useEffect(() => {
    if (state !== "done") return undefined;
    const t = setTimeout(() => setState("idle"), 320);
    return () => clearTimeout(t);
  }, [state]);

  return <div className="nav-progress" data-state={state} aria-hidden="true" />;
}
