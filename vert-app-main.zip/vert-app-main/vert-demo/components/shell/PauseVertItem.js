"use client";

// components/shell/PauseVertItem.js — PAUSE VERT, AS ONE MENU ROW AND A CONFIRM
// ==============================================================================
// Build plan §19.0.6 (the kill switch belongs with the account); design-fix-2 DA2-064.
//
// The account menu used to hold Pause Vert as a toggle with its four-line consequence
// printed under it, so a menu of four actions was 300 px of prose and Sign out sat flush
// against a paragraph. A menu is for scanning. The row now says only what it does
// ("Pause Vert…", with the ellipsis because it opens a dialog), and the consequence moves
// into the confirm, where it is read at the moment it matters: before the press, beside
// the button that does it.
//
// The rules of components/skills/PauseVert.js still hold, because this uses its reader
// and its words: the state shown is the ENGINE'S, read when the menu opens; while it is
// unknown there is no button to press into it, only one line saying it couldn't be read;
// the line changes only when the read-back agrees.

import { useEffect, useId, useState } from "react";

import { Button } from "@/components/ui/Button";
import { Sheet } from "@/components/ui/Sheet";
import { Portal } from "@/components/ui/Portal";
import { IconPause } from "@/components/ui/icons";
import { fetchPaused } from "@/components/skills/PauseVert";
import { pauseWords } from "@/components/skills/model";
import { pauseVert } from "@/lib/skills";

export default function PauseVertItem({ open = true, onPicked, initial = undefined }) {
  const [paused, setPaused] = useState(initial === undefined ? null : initial);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState(null);
  const titleId = useId();

  useEffect(() => {
    if (!open || initial !== undefined) return undefined;
    let live = true;
    fetchPaused().then((p) => {
      if (live) setPaused(p);
    });
    return () => {
      live = false;
    };
  }, [open, initial]);

  const words = pauseWords(paused);

  async function press() {
    setBusy(true);
    setMessage(null);
    let result = null;
    try {
      result = await pauseVert(!paused);
    } catch {
      result = null;
    }
    setBusy(false);
    if (result && result.ok) {
      setPaused(result.paused);
      setConfirm(false);
    } else setMessage((result && result.message) || "Nothing was changed. Try again.");
  }

  return (
    <div className="pause-vert" data-paused={paused === null ? "unknown" : String(paused)}>
      {words.label ? (
        <button
          type="button"
          className="row menu-item pause-vert-item"
          onClick={() => {
            setMessage(null);
            setConfirm(true);
            if (onPicked) onPicked();
          }}
        >
          <IconPause />
          <span>{words.label}…</span>
        </button>
      ) : (
        <p className="menu-note">{words.state}</p>
      )}
      <Portal>
        <Sheet
          open={confirm}
          onClose={() => setConfirm(false)}
          side="modal"
          title={paused ? "Resume Vert?" : "Pause Vert?"}
          id={titleId}
          className="pause-confirm"
          footer={
            <div className="pause-confirm-foot">
              <Button variant="quiet" onClick={() => setConfirm(false)}>
                Cancel
              </Button>
              <Button variant="commit" onClick={press} busy={busy} busyLabel={paused ? "Resuming…" : "Pausing…"}>
                {words.label}
              </Button>
            </div>
          }
        >
          <p className="t-body pause-confirm-text">{words.state}</p>
          {message ? (
            <p className="field-error" role="alert">
              {message}
            </p>
          ) : null}
        </Sheet>
      </Portal>
    </div>
  );
}
