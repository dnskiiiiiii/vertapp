"use client";

// components/shell/ClientSwitcher.js — WHOSE BOOKS, WHICH MONTH: ONE ROW AT THE TOP
// ==============================================================================
// Build plan §19.9 F-FIRM, §19.0.9; design-fix-2 DA2-057, DA2-078.
//
//   [N]  Northwind        ⇕     ← a 20 px initial tile, the client (body 500) over its
//        July 2026                month (caption, tertiary ink), one CaretUpDown; 44 px
//
// ONE ROW, NOT TWO CONTROLS. The client used to be a plain line with ⇕ and the month a
// separate row with its own ⌄ and its own height, so the nav below sat 10 px lower for a
// client with one month than for one with several (DA2-057). The row now says both facts
// once and opens one popover holding both choices: the client's months (when it has more
// than one) and, for a person in a firm, the firm's clients.
//
// THE POPOVER SITS BESIDE THE SIDEBAR, NOT OVER IT (DA2-078): 17.5rem of glass anchored to
// the row's top and the sidebar's right edge, so the nav and the conversations stay in
// view while choosing. While the firm's list is read it shows three skeleton rows in the
// shape of the rows to come, never "Reading your clients…"; the client being shown is
// first, with a tick. "Clients" (the firm view) is offered once, at the foot. On a phone,
// where the sidebar is a drawer, the popover opens under the row instead.
//
// FIRM MODE IS A PLACE IN THE NAV, NOT THESE WORDS (design-pass spec §6.10). The row always
// names a client; on the Clients view the sidebar does not draw it at all (Sidebar.js:
// firm mode shows the firm's nav instead, DA2-043).
//
// ONLY A ROW THAT HAS SOMETHING TO OFFER IS A BUTTON. A tenant key with one month has
// nothing to choose: the row is drawn as the same two lines with no caret, because a
// control that opened a list of one would be a false affordance.
//
// The list is read when the popover opens, from /api/firm (the switch itself is the
// Server Action lib/firm.js switchClient, proven with the engine before it is
// remembered). A list that could not be read says so; it is never shown empty.

import { usePathname, useRouter } from "next/navigation";
import { useEffect, useId, useLayoutEffect, useRef, useState } from "react";

import { personOf } from "@/lib/acting-as";
import { monthListWord } from "@/lib/period";
import { switchClient } from "@/lib/firm";
import { clientName } from "@/app/clients/model";
import { SkeletonBlock } from "@/components/ui/marks";

import ShellLink from "./ShellLink";
import { CLIENTS_HREF } from "./ia";
import { IconCheck, IconChevronUpDown } from "./icons";
import { closeOnFocusOut, focusIntoMenu } from "./menu-focus";
import { chooseMonth } from "./MonthControl";
import { useOpenSwitchedClient } from "./switching";
import "./switcher.css";

/** The Clients view's address: firm mode (ia.js FIRM_NAV). */
export { CLIENTS_HREF };

/** The event the phone's top bar sends to open this popover (TopBar.js, AppShell.js). */
export const OPEN_SWITCHER_EVENT = "vert:open-switcher";

/** Is this page firm mode? */
export function isFirmMode(pathname) {
  return pathname === CLIENTS_HREF || String(pathname || "").startsWith(`${CLIENTS_HREF}/`);
}

/** May this session switch client? A person, in a firm. */
export function canSwitch(signedInAs) {
  return Boolean(personOf(signedInAs) && signedInAs && signedInAs.firm);
}

/**
 * The row's words: always the client's name (spec §6.10). `firm` says the Clients view
 * is showing; the row itself does not change its words for it.
 */
export function switcherLabel({ pathname, client }) {
  return { firm: isFirmMode(pathname), name: client || "This client" };
}

/** The tile's letter: the name's first letter or digit, upper case. */
export function initialOf(name) {
  const m = String(name || "").match(/[A-Za-z0-9]/);
  return m ? m[0].toUpperCase() : "·";
}

/** The firm's clients with the one being shown first; the rest keep the order read. */
export function currentFirst(clients, current) {
  const list = Array.isArray(clients) ? clients : [];
  const here = list.filter((c) => current != null && String(c.tenantId) === String(current));
  return [...here, ...list.filter((c) => !here.includes(c))];
}

const DESK = "(min-width: 1024px)";

/** The two lines and the tile, shared by the button and the static row. */
function Face({ name, monthLabel }) {
  return (
    <>
      <span className="switcher-tile" aria-hidden="true">
        {initialOf(name)}
      </span>
      <span className="switcher-words">
        {/* The full name on hover: a long name is cut with an ellipsis (verify pass 1 S-UI-3). */}
        <span className="switcher-head" data-switcher-head="" translate="no" title={typeof name === "string" ? name : undefined}>
          {name}
        </span>
        {monthLabel ? <span className="switcher-month">{monthLabel}</span> : null}
      </span>
    </>
  );
}

export default function ClientSwitcher({ client = null, period = null, periodLabel = null, months = [], pathname: forcedPath, current = null, firm: inFirm = true }) {
  const router = useRouter();
  const openSwitched = useOpenSwitchedClient();
  const livePath = usePathname();
  const pathname = forcedPath ?? livePath ?? "";
  const [open, setOpen] = useState(false);
  const [list, setList] = useState({ state: "idle", clients: [] });
  const [problem, setProblem] = useState(null);
  const [busy, setBusy] = useState(null);
  const [anchor, setAnchor] = useState(null);
  const sheetId = useId();
  const root = useRef(null);
  const toggle = useRef(null);
  const sheet = useRef(null);
  const label = switcherLabel({ pathname, client });
  const firm = isFirmMode(pathname);
  const monthList = Array.isArray(months) ? months : [];
  const hasMonths = monthList.length > 1;
  const interactive = inFirm || hasMonths;

  // The phone's top bar names the client and month; pressing it opens the drawer and
  // this popover in it (spec §6.10, audit §0 P2).
  useEffect(() => {
    if (!interactive) return undefined;
    function onOpen() {
      setOpen(true);
    }
    window.addEventListener(OPEN_SWITCHER_EVENT, onOpen);
    return () => window.removeEventListener(OPEN_SWITCHER_EVENT, onOpen);
  }, [interactive]);

  // Where the popover stands on a desk: the row's top, a gap right of the sidebar. Measured
  // when it opens, before paint, so it never flashes in the old place.
  useLayoutEffect(() => {
    if (!open || !toggle.current) return;
    if (!window.matchMedia || !window.matchMedia(DESK).matches) {
      setAnchor(null);
      return;
    }
    const row = toggle.current.getBoundingClientRect();
    const side = toggle.current.closest(".sidebar");
    const right = side ? side.getBoundingClientRect().right : row.right;
    setAnchor({ top: Math.max(8, row.top), left: right + 8 });
  }, [open]);

  // Focus moves inside on open, onto the row marked current when there is one (ui-pass-1
  // output-ui #24). Its own effect, keyed on `open` alone: the list's read re-runs the
  // effect below, and a second move would pull focus off a row the person arrowed to.
  useEffect(() => {
    if (open) focusIntoMenu(sheet.current, "[aria-current]");
  }, [open]);

  useEffect(() => {
    if (!open) return undefined;
    let live = true;
    if (inFirm) {
      setList((was) => ({ ...was, state: "reading" }));
      fetch(`/api/firm?view=switcher&period=${encodeURIComponent(period || "")}`, { cache: "no-store" })
        .then((r) => (r.ok ? r.json() : null))
        .then((body) => {
          if (!live) return;
          setList(body && Array.isArray(body.clients) ? { state: "read", clients: body.clients } : { state: "failed", clients: [] });
        })
        .catch(() => live && setList({ state: "failed", clients: [] }));
    }
    function onKey(event) {
      if (event.key === "Escape") {
        setOpen(false);
        if (toggle.current) toggle.current.focus();
      } else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        // The rows are a list: the arrows walk it, as in every other menu.
        const items = sheet.current ? Array.from(sheet.current.querySelectorAll(".switcher-item")) : [];
        if (!items.length) return;
        event.preventDefault();
        const at = items.indexOf(document.activeElement);
        const next = event.key === "ArrowDown" ? (at + 1) % items.length : (at - 1 + items.length) % items.length;
        items[next].focus();
      }
    }
    function onPointer(event) {
      if (root.current && !root.current.contains(event.target)) setOpen(false);
    }
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onPointer);
    // Tab out of the popover closes it and gives focus back to the row (DA2-014).
    const undoFocus = closeOnFocusOut(root.current, () => setOpen(false), toggle.current);
    return () => {
      live = false;
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onPointer);
      undoFocus();
    };
  }, [open, period, inFirm]);

  async function choose(tenantId) {
    setProblem(null);
    setBusy(tenantId);
    // The popover listed this month's counts, so the client opens on this month.
    const switched = await switchClient(tenantId, { period: period || null });
    setBusy(null);
    if (!switched || !switched.ok) {
      setProblem((switched && switched.message) || "Vert couldn't open that client. You're still on the one you had.");
      return;
    }
    setOpen(false);
    // Said at once, until the new client's page draws (verify pass 1 S-E2E-3).
    const row = Array.isArray(list.clients) ? list.clients.find((c) => c && c.tenantId === tenantId) : null;
    openSwitched(row ? clientName(row) : null);
  }

  function pickMonth(next) {
    setOpen(false);
    chooseMonth({ next, period, pathname, router });
  }

  if (!interactive) {
    return (
      <div className="switcher switcher-static">
        <div className="switcher-toggle">
          <Face name={label.name} monthLabel={periodLabel} />
        </div>
      </div>
    );
  }

  const clients = currentFirst(list.clients, current);
  const reading = list.state === "reading" && !list.clients.length;
  const placed = anchor ? { "--switcher-top": `${anchor.top}px`, "--switcher-left": `${anchor.left}px` } : undefined;

  return (
    <div className="switcher" ref={root} data-firm-mode={firm ? "true" : undefined}>
      <button
        type="button"
        ref={toggle}
        className="row switcher-toggle"
        aria-expanded={open ? "true" : "false"}
        aria-controls={sheetId}
        onClick={() => setOpen((was) => !was)}
      >
        <Face name={label.name} monthLabel={periodLabel} />
        <IconChevronUpDown className="switcher-chevron" />
        <span className="sr-only">{inFirm ? ", switch client or month" : ", switch month"}</span>
      </button>

      <div
        className="switcher-sheet"
        id={sheetId}
        ref={sheet}
        role="dialog"
        aria-label={inFirm ? "Switch client or month" : "Switch month"}
        hidden={!open}
        data-anchored={anchor ? "beside" : undefined}
        style={placed}
      >
        {hasMonths ? (
          <section className="switcher-section" aria-label="Month">
            <p className="switcher-label">Month</p>
            <ul className="switcher-list">
              {[...monthList].reverse().map((m) => {
                const here = m.period === period;
                return (
                  <li key={m.period}>
                    <button type="button" className="row switcher-item" data-month={m.period} aria-current={here ? "true" : undefined} onClick={() => pickMonth(m.period)}>
                      <span className="switcher-item-name">{m.label}</span>
                      {monthListWord(m) ? <span className="switcher-item-word">{monthListWord(m)}</span> : null}
                      {here ? <IconCheck className="switcher-check" /> : null}
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>
        ) : null}

        {inFirm ? (
          <section className="switcher-section" aria-label="Client">
            <p className="switcher-label">Client</p>
            {reading ? (
              <div className="switcher-skeleton" role="status" aria-live="polite">
                <span className="sr-only">Reading your clients</span>
                {[0, 1, 2].map((i) => (
                  <span key={i} className="switcher-skeleton-row" aria-hidden="true">
                    <SkeletonBlock width="1.25rem" height="1.25rem" radius="var(--r-xs)" />
                    <SkeletonBlock width={i === 1 ? "6rem" : "8rem"} height="0.75rem" />
                  </span>
                ))}
              </div>
            ) : null}
            {list.state === "failed" ? <p className="switcher-note">Vert couldn&apos;t read your clients just now.</p> : null}
            {clients.length ? (
              <ul className="switcher-list">
                {clients.map((c) => {
                  const here = !firm && String(c.tenantId) === String(current);
                  const name = clientName(c);
                  return (
                    <li key={c.tenantId}>
                      <button
                        type="button"
                        className="row switcher-item"
                        data-client={c.tenantId}
                        aria-current={here ? "true" : undefined}
                        aria-busy={busy === c.tenantId ? "true" : undefined}
                        disabled={busy != null}
                        onClick={() => (here ? setOpen(false) : choose(c.tenantId))}
                      >
                        <span className="switcher-tile switcher-tile-sm" aria-hidden="true">
                          {initialOf(name)}
                        </span>
                        <span className="switcher-item-name" translate="no" title={name}>{name}</span>
                        {here ? <IconCheck className="switcher-check" /> : <span className="switcher-item-word">{c.status}</span>}
                      </button>
                    </li>
                  );
                })}
              </ul>
            ) : null}
            {problem ? (
              <p className="switcher-note" role="alert">
                {problem}
              </p>
            ) : null}
            <div className="switcher-foot">
              <ShellLink href={CLIENTS_HREF} className="row switcher-item" aria-current={firm ? "page" : undefined} onClick={() => setOpen(false)}>
                <span className="switcher-item-name">Clients</span>
              </ShellLink>
            </div>
          </section>
        ) : null}
      </div>
    </div>
  );
}
