"use client";

// components/shell/BooksRetry.js — THE "TRY AGAIN" ON DataSourceDown (verify pass 4, F17)
// The rule is in ./books-retry.js. A button, because it is an action; busy while it
// asks; its progress in a polite live region beside it.

import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { retryUntilReadable } from "./books-retry";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export default function BooksRetry() {
  const [busy, setBusy] = useState(false);
  const [words, setWords] = useState("");

  async function tryAgain() {
    if (busy) return;
    setBusy(true);
    setWords("");
    const href = window.location.href;
    const outcome = await retryUntilReadable({
      href,
      fetchPage: (url, init) => fetch(url, init),
      wait: sleep,
      onWaiting: (_attempt, ms) => setWords(`Not yet. Trying again in ${Math.round(ms / 1000)} s…`),
    });
    if (outcome === "up") {
      window.location.reload();
      return;
    }
    setBusy(false);
    setWords("Still can’t reach your books. Try again in a minute.");
  }

  return (
    <>
      <Button variant="secondary" size="sm" busy={busy} busyLabel="Trying again…" onClick={tryAgain} data-books-retry="">
        Try again
      </Button>
      <span className="books-retry-status t-footnote" role="status" aria-live="polite">
        {words}
      </span>
    </>
  );
}
