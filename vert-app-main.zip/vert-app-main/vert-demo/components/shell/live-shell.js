"use client";

// components/shell/live-shell.js — THE SIDEBAR'S FIGURES, KEPT CURRENT WITHOUT MOVING THE PAGE
// ==============================================================================
// Spec §4.5: a conversation you are not looking at can start needing you, and the
// sidebar has to say so. The figures come from the layout's render; while anything is
// Vert's working, this re-reads them every 15 seconds from app/api/shell (the same
// reader) and lays the answer over the rendered ones.
//
// WHY NOT router.refresh(). A refresh on a timer re-renders the route under the
// reader, and when its read failed or was cut off Next fell back to a full browser
// navigation to the same URL, which cancelled whatever navigation the person (or a
// test) had just started (eval iter 1, D6). Nothing here navigates or re-renders the
// page: a poll that fails is ignored, and the next render from the server wins.

import { createContext, useContext, useEffect, useRef, useState } from "react";

/**
 * The shell's figures as drawn now (the layout's render with this file's re-read laid
 * over it), for a page that lists the same conversations: the homepage board reads each
 * row's newer word and time from here rather than polling the list a second time. Null
 * outside the shell (a test render, sign-in).
 */
export const ShellReading = createContext(null);

/** The shell's current reading, or null outside the shell. */
export function useShellReading() {
  return useContext(ShellReading);
}

export const LIVE_SHELL_MS = 15000;

// A POLL THAT ENDS (Vercel CPU, 4 Nov 2026). The staging API was paused for CPU: each
// re-read here asks `GET /close`, the heaviest read Vert has (5-8 s of CPU on staging
// northwind), and a row that stayed "Vert's working" kept one visible tab asking every
// 15 s for as long as it stayed open. Now the working poll backs off — LIVE_SHELL_MS for
// LIVE_SHELL_STEP_READS reads, then twice that, then four times — and stops after
// LIVE_SHELL_MAX_READS (about half an hour of following). A new render, a surface saying
// the figures moved, or the tab coming back starts it again.
export const LIVE_SHELL_STEP_READS = 8;
export const LIVE_SHELL_MAX_READS = 40;

// A ROW THAT HAS SAID NOTHING FOR STALLED_MS IS NOT FOLLOWED. Every event a run writes
// moves its conversation's `updatedAt`, and no request runs past Vercel's 300 s, so a
// "working" row quiet for ten minutes is a run that stopped without saying so: polling
// it would read the month every few seconds for nothing.
export const STALLED_MS = 10 * 60 * 1000;

// THE READS AFTER THE WORK STOPS (verify pass 5, S-E2E-1 F16). The poll used to stop on
// the first reading in which nothing was Vert's working, and that reading is the one
// taken at the moment a task changes state: `GET /agent/sessions` and `GET /close` were
// read either side of it, so the bank rec said "Needs you" in the list while the badge
// still read 4 without its 2 decisions (`/close` said 6 seconds later), and nothing read
// again until the person navigated. Now the work stopping (or a reading that contradicts
// itself, `unsettled`) buys SETTLE_READS more readings, SETTLE_MS apart, and the figures
// on screen are the ones the engine settled on.
export const SETTLE_READS = 3;
export const SETTLE_MS = 4000;

/** The event a surface sends when it changed the month's figures (an import, an answer). */
export const SHELL_STALE_EVENT = "vert:shell-stale";

/**
 * Say the sidebar's figures may have moved (F16: "refresh the badge from /close after an
 * import"): the shell takes SETTLE_READS fresh readings. Safe anywhere; no window, no-op.
 */
export function markShellStale() {
  try {
    window.dispatchEvent(new Event(SHELL_STALE_EVENT));
  } catch {
    // No window (a server or test render): nothing to tell.
  }
}

/** The event the close panel sends when a press left a month signed off or open again. */
export const MONTH_CLOSE_EVENT = "vert:month-close";

/**
 * Say where a sign-off, reopen or check left the month (staging browser walk 5, W5-5:
 * right after a reopen the switcher still listed "October 2026 · Closed", and only a
 * reload said Open). `status` is close-step.js lockStatusOf's. Safe anywhere; no window,
 * no-op.
 */
export function announceMonthClose(status) {
  if (!status || typeof status !== "object" || typeof status.period !== "string") return;
  try {
    window.dispatchEvent(new CustomEvent(MONTH_CLOSE_EVENT, { detail: { period: status.period, closed: status.signedOff === true } }));
  } catch {
    // No window (a server or test render): nothing to tell.
  }
}

/**
 * The shell with the month a press just signed off (`closed: true`) or reopened listed
 * so, for the client it was pressed on. Anything else comes back as it was. Pure.
 */
export function withMonthClose(shell, said) {
  if (!shell || !said || !Array.isArray(shell.months) || (shell.clientId || null) !== (said.clientId || null)) return shell;
  if (!shell.months.some((m) => m && m.period === said.period)) return shell;
  const months = shell.months.map((m) => {
    if (!m || m.period !== said.period) return m;
    const { closed, reopened, ...rest } = m;
    return said.closed ? { ...rest, started: true, closed: true } : { ...rest, started: true, reopened: true };
  });
  return { ...shell, months };
}

/**
 * Does this reading contradict itself? A Done conversation with decisions waiting in it
 * is two reads taken either side of the task finishing (F16). Pure.
 */
export function unsettled(shell) {
  return Boolean(
    shell && Array.isArray(shell.conversations) && shell.conversations.some((c) => c && c.status === "Done" && typeof c.decisions === "number" && c.decisions > 0)
  );
}

/**
 * The poll's plan from what is on screen: `{ active, ms }`. While anything is Vert's
 * working, every LIVE_SHELL_MS, backing off as `reads` (the working reads taken since the
 * poll last started) grows, and not at all after LIVE_SHELL_MAX_READS; every SETTLE_MS
 * while settle reads are left; and not at all otherwise. Pure.
 */
export function pollPlan({ working, settle, reads = 0 }) {
  if (working) {
    const n = Number.isInteger(reads) && reads > 0 ? reads : 0;
    if (n >= LIVE_SHELL_MAX_READS) return { active: false, ms: null };
    const step = Math.min(2, Math.floor(n / LIVE_SHELL_STEP_READS));
    return { active: true, ms: LIVE_SHELL_MS * 2 ** step };
  }
  if (Number.isInteger(settle) && settle > 0) return { active: true, ms: SETTLE_MS };
  return { active: false, ms: null };
}

/**
 * The settle reads left after one: the work stopping starts SETTLE_READS of them; while
 * working none are counted (the working poll reads anyway); a quiet reading spends one.
 * Pure.
 */
export function nextSettle({ wasWorking, working, settle, contradicts = false, same = false }) {
  if (working) return 0;
  if (wasWorking || contradicts) return Math.max(settle || 0, SETTLE_READS);
  // A settle read that says what the screen already says: the engine has settled.
  if (same) return 0;
  return Math.max(0, (settle || 0) - 1);
}

/**
 * THE SETTLE READS A RENDER BUYS (staging browser walk 2, N11). A render that contradicts
 * itself — a Done row still counting a decision — bought SETTLE_READS reads on every
 * load, at ~5 s each, and the board went quiet only after 13–28 s. The render was just
 * read from the engine; a contradiction in it is the engine's own reading (walk 2, D4:
 * "Credit card reconciliation · 1 decision" under Done), not a race, so it buys one read
 * to check, and a reading that says the same stops there. Pure.
 */
export function initialSettle(shell) {
  return unsettled(shell) ? 1 : 0;
}

/** Whether two readings say the same: the badge, and each row's status and count. Pure. */
export function sameReading(a, b) {
  if (!a || !b) return false;
  if (a.decisions !== b.decisions) return false;
  const rows = (x) => (Array.isArray(x.conversations) ? x.conversations.map((c) => [c && c.id, c && c.status, c && c.decisions].join("|")).join("~") : "");
  return rows(a) === rows(b);
}

// ONE READ AT A TIME PER MONTH (N11). A tick while the last read is still out, a second
// hook, or React's double effect asked again: each read of a month shares the one out.
const inFlight = new Map();

/**
 * `GET /api/shell?period=` as JSON, or null; concurrent asks for a month share one
 * request. `close: false` reads the list alone (`&close=0`): the poll while something is
 * Vert's working, when the list is what moves and `GET /close` would be recomputed on
 * every read (Vercel CPU, 4 Nov 2026).
 */
export function readShellOnce(period, { fetchImpl = globalThis.fetch, signal, close = true } = {}) {
  const key = close ? period : `${period}|list`;
  const held = inFlight.get(key);
  if (held) return held;
  const read = (async () => {
    try {
      const res = await fetchImpl(`/api/shell?period=${encodeURIComponent(period)}${close ? "" : "&close=0"}`, { signal, cache: "no-store", headers: { accept: "application/json" } });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    } finally {
      inFlight.delete(key);
    }
  })();
  inFlight.set(key, read);
  return read;
}

/**
 * The shell as drawn, with a newer reading of the same month laid over it. Pure.
 *
 * A reading of another month, or one that did not read the list, never replaces the
 * rendered list, and an absent badge in the reading (a failed read) keeps the
 * rendered badge rather than printing nothing over a figure that was measured.
 */
export function mergeLive(shell, live) {
  if (!shell || !live || live.period !== shell.period) return shell;
  const next = { ...shell };
  if (typeof live.decisions === "number") next.decisions = live.decisions;
  if (live.conversationsRead && Array.isArray(live.conversations)) {
    next.conversations = live.closeAsked === false ? withCountsDrawn(shell.conversations, live.conversations) : live.conversations;
    next.replayed = false;
  }
  return next;
}

/**
 * A list read without the month (`closeAsked: false`), each row keeping the decisions
 * count the shell drew for it: the count is `GET /close`'s, and that was not asked.
 * Pure.
 */
function withCountsDrawn(drawn, listed) {
  const counts = new Map((Array.isArray(drawn) ? drawn : []).filter((c) => c && typeof c.decisions === "number").map((c) => [String(c.id), c.decisions]));
  return listed.map((c) => (c && !("decisions" in c) && counts.has(String(c.id)) ? { ...c, decisions: counts.get(String(c.id)) } : c));
}

/**
 * This conversation's title as the sessions list holds it now, or null when the list
 * (the shell's reading) does not list it. Staging browser walk 6, W6-4: the engine
 * renames a rec request after each run (w19 contract, "re-read the title from the
 * sessions list after a run"); the list is the reading the sidebar draws, so the open
 * conversation's header and its sidebar row say one title. Pure.
 */
export function listedTitle(shell, sessionId) {
  if (!shell || !Array.isArray(shell.conversations) || sessionId == null) return null;
  const row = shell.conversations.find((c) => c && String(c.id) === String(sessionId));
  return row && typeof row.title === "string" && row.title.trim() ? row.title.trim() : null;
}

/** Is anything running that could change the figures without anyone pressing? */
export function anyWorking(shell) {
  return Boolean(shell && Array.isArray(shell.conversations) && shell.conversations.some((c) => c.status === "Vert's working"));
}

/**
 * Is anything working that is worth following at `nowMs`: a "Vert's working" row that
 * has moved within STALLED_MS (a row with no time is followed, as before). The row still
 * draws its word; only the poll leaves it. Pure.
 */
export function followedWorking(shell, nowMs) {
  return Boolean(
    shell && Array.isArray(shell.conversations) && shell.conversations.some((c) =>
      c && c.status === "Vert's working" && !(typeof c.updatedAt === "number" && Number.isFinite(nowMs) && nowMs - c.updatedAt > STALLED_MS))
  );
}

export function useLiveShell(shell) {
  // The reading is kept with the render it was taken over. A new render from the
  // server is newer than any poll, so a reading taken over an older one is ignored.
  const [live, setLive] = useState(null);
  const base = useRef(shell);
  useEffect(() => {
    base.current = shell;
  }, [shell]);
  // WHERE A PRESS LEFT A MONTH (W5-5), kept over every render until a reload: the
  // refresh after a reopen can land before the engine's listing says it.
  const [said, setSaid] = useState(null);
  const clientId = (shell && shell.clientId) || null;
  useEffect(() => {
    const heard = (event) => {
      const d = event && event.detail;
      if (d && typeof d.period === "string") setSaid({ clientId, period: d.period, closed: d.closed === true });
    };
    window.addEventListener(MONTH_CLOSE_EVENT, heard);
    return () => window.removeEventListener(MONTH_CLOSE_EVENT, heard);
  }, [clientId]);
  const merged = withMonthClose(live && live.base === shell ? mergeLive(shell, live.body) : shell, said);
  const working = followedWorking(merged, Date.now());
  const period = shell && shell.period;

  // The working reads taken since the poll last started (pollPlan backs off on them).
  // A new render, a surface saying the figures moved, or the tab coming back into view
  // starts the count again.
  const [reads, setReads] = useState(0);
  useEffect(() => {
    setReads(0);
  }, [shell]);
  useEffect(() => {
    const again = () => {
      if (document.visibilityState === "visible") setReads(0);
    };
    document.addEventListener("visibilitychange", again);
    return () => document.removeEventListener("visibilitychange", again);
  }, []);

  // Settle reads left (F16): started when the work stops, or when a render or reading
  // contradicts itself; each quiet reading spends one, so this always ends.
  const [settle, setSettle] = useState(() => initialSettle(shell));
  const wasWorking = useRef(working);
  useEffect(() => {
    if (wasWorking.current && !working) setSettle(SETTLE_READS);
    wasWorking.current = working;
  }, [working]);
  useEffect(() => {
    if (unsettled(shell)) setSettle((n) => Math.max(n, initialSettle(shell)));
  }, [shell]);
  useEffect(() => {
    const stale = () => {
      setSettle((n) => Math.max(n, SETTLE_READS));
      setReads(0);
    };
    window.addEventListener(SHELL_STALE_EVENT, stale);
    return () => window.removeEventListener(SHELL_STALE_EVENT, stale);
  }, []);
  const plan = pollPlan({ working, settle, reads });

  useEffect(() => {
    if (!plan.active || !period) return undefined;
    let controller = null;
    let stopped = false;
    let out = false;
    let last = base.current;
    async function poll() {
      if (document.visibilityState !== "visible") return;
      // A tick while the last read is still out waits for it (N11: reads overlapped).
      if (out) return;
      out = true;
      controller = new AbortController();
      try {
        // While something is working the list is what moves: read it alone. The settle
        // reads after the work stops ask the month too (F16).
        const body = await readShellOnce(period, { signal: controller.signal, close: !working });
        if (!stopped && body && body.ok) {
          setLive({ base: base.current, body });
          const read = mergeLive(base.current, body);
          // Only a contradiction that reads the same again ends the settling early: after
          // the work stops, a quiet read is still worth repeating (F16, /close lags).
          const same = unsettled(read) && sameReading(last, read);
          last = read;
          if (working) setReads((n) => n + 1);
          if (!working) setSettle((n) => nextSettle({ wasWorking: false, working: followedWorking(read, Date.now()), settle: n, same }));
        }
      } catch {
        // Cut off or unreachable: the figures on screen stay as they were drawn.
      } finally {
        out = false;
      }
    }
    const timer = setInterval(poll, plan.ms);
    // Leaving the page cancels an in-flight read instead of letting it land later.
    const leave = () => controller && controller.abort();
    window.addEventListener("pagehide", leave);
    return () => {
      stopped = true;
      clearInterval(timer);
      window.removeEventListener("pagehide", leave);
      if (controller) controller.abort();
    };
  }, [plan.active, plan.ms, working, period]);

  return merged;
}
