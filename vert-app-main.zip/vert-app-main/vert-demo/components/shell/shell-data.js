import "server-only";

// components/shell/shell-data.js — WHAT THE SIDEBAR SHOWS, READ ONCE PER REQUEST
// ==============================================================================
// Spec §2.1–§2.2; build plan §2.3 and §3 F1. The sidebar carries four facts, and each
// one is READ, never computed here:
//
//   client        whose books these are — the payload's business name
//   months        `GET /close/periods` → [{period, label}]; the month control is
//                 hidden when there is only one
//   decisions     `GET /close/{period}` → `counts.decisions`, the badge on Month-end.
//                 Never summed, never derived: the same number the Month-end header
//                 and every task row are held to (UI-001, F3's month.test)
//   conversations `GET /agent/sessions?period=` → this month's conversations,
//                 needs-you first; with no service, the export's replays
//
// A FIGURE THAT COULD NOT BE READ IS ABSENT, NOT ZERO. Each read that fails leaves its
// value null, and the sidebar then draws no badge at all rather than a "0" that would
// say nothing needs you (spec §9.4). The failure is logged server-side by
// lib/session.js; the page is never taken down by a secondary read.
//
// THIS FILE DOES NOT KNOW WHICH MODE THE APP IS IN. It asks the service through
// `sessionGet` (which answers "no service" in the static build without touching a
// cookie) and falls back to what the payload itself carries — the export's `close`,
// `periods` and `replays` once the engine emits them. The no-arithmetic guard holds
// every component to that: none of them may branch on the data source.
//
// IT IS ALSO THE ONE READER OF SOURCE FRESHNESS (`readSources`, below). One source used
// to carry three statuses at once: the context sheet said Stripe was "up to date, read
// 30 Sep", Month-end said it "hasn't synced since 1 Jul", and Connections said "Not
// checked" (eval C6). Each surface asked a different question of a different read.
// Now the state is decided here, once per request, and every surface prints it with
// lib/format.js `freshnessWords`.

import { conversationTitle } from "@/lib/agent/title";
import { cache } from "react";

import { readConnections } from "@/lib/connections";
import { providerRows } from "@/lib/connections-shape";
import { chosenClient, readCloseOf, readPeriods, readScheduledBody, readSession, readSessionsOf, visibleMonth } from "@/lib/session";
import { closeMonthOf, isPeriod, offeredMonths, periodLabel, shownMonth } from "@/lib/period";
import { wordForState } from "@/lib/status";

import { instantOf } from "./age";
import { accountName } from "@/lib/format";

// One read of a month per request, shared by the badge and the sources: two surfaces
// drawn from two reads of the same route could disagree about the same second.
// Exported (verify pass 3, S-BK-8): Month-end's own read of its month is this one, so
// a page load asks `GET /close/{period}` — the slowest read it makes — once, not twice.
export const readClose = readCloseOf;

/**
 * Closed, reopened (open again), or neither, from one listing row (staging browser walk 3,
 * W3-2: a reopened October read "October 2026 · Closed"). The engine's `status` when it
 * sends one; else a reopen later than the close is open. Pure.
 */
export function closeStatusOf(m) {
  if (!m || typeof m !== "object") return null;
  if (m.status === "closed" || m.status === "reopened" || m.status === "open") return m.status;
  const closedAt = typeof m.closedAt === "string" && m.closedAt ? Date.parse(m.closedAt) : NaN;
  const reopenedAt = typeof m.reopenedAt === "string" && m.reopenedAt ? Date.parse(m.reopenedAt) : NaN;
  if (Number.isFinite(reopenedAt) && !(reopenedAt < closedAt)) return "reopened";
  return Number.isFinite(closedAt) ? "closed" : null;
}

export function monthsFrom(body) {
  const list = Array.isArray(body) ? body : body && Array.isArray(body.periods) ? body.periods : [];
  return list
    .filter((m) => m && isPeriod(m.period))
    .map((m) => {
      const out = { period: m.period, label: typeof m.label === "string" && m.label ? m.label : periodLabel(m.period) };
      // A month closed in Vert (its close photograph's day), when the listing says so.
      // Never inferred: a listing without it claims nothing (verify pass 7, S-BK-6). A
      // month reopened since is open (walk 3, W3-2).
      const status = closeStatusOf(m);
      if (status === "closed") out.closed = true;
      if (status === "reopened") out.reopened = true;
      // Whether the month was OPENED, when the listing says (verify pass 7 F8): being
      // listed is not being started, since a month with payouts is listed too.
      if (typeof m.opened === "boolean") out.opened = m.opened;
      return out;
    });
}

/**
 * What is known about which months were opened: the listing's own flags, then the
 * shown month's `GET /close/{period}` `opened` (the read this request makes anyway,
 * shared through `readClose`). A month neither answers stays unknown (lib/period.js
 * offeredMonths), never assumed started because it is listed.
 */
export function openedMonths(listed, shown, shownRead) {
  const out = new Map();
  for (const m of listed || []) if (typeof m.opened === "boolean") out.set(m.period, m.opened);
  if (shown && shownRead && shownRead.ok && shownRead.body && typeof shownRead.body.opened === "boolean"
      && (!shownRead.body.period || shownRead.body.period === shown)) {
    out.set(shown, shownRead.body.opened);
  }
  return out;
}

/**
 * The months known to be closed in Vert: the listing's own `closedAt` (carried as
 * `closed`), and the shown month's `GET /close/{period}` `changedAfterClose.closedAt`,
 * its close photograph, the same field Month-end prints "closed on" from (verify
 * pass 8, S-BK-6). The engine's listing sends no `closedAt`, so before this a month
 * closed by its snapshot read "Not started" in the switcher beside a Month-end that
 * said it was closed. Never inferred: no photograph, an unread month, or a read of
 * another month claims nothing.
 */
export function closedMonths(listed, shown, shownRead) {
  const out = new Set((listed || []).filter((m) => m && m.closed === true).map((m) => m.period));
  const body = shownRead && shownRead.ok ? shownRead.body : null;
  const c = body && body.changedAfterClose;
  // A month the listing says was reopened is open, whatever photograph it has (W3-2).
  const reopened = (listed || []).some((m) => m && m.period === shown && m.reopened === true);
  if (shown && !reopened && c && typeof c.closedAt === "string" && c.closedAt && (!body.period || body.period === shown)) {
    out.add(shown);
  }
  return out;
}

function decisionsFrom(close, period) {
  // The export records every month as `{periods, months}` (lib/engine-source.js close);
  // the API answers one month. Either way the count is that month's own.
  if (close && close.months && typeof close.months === "object") close = close.months[period] || null;
  if (!close || (close.period && close.period !== period)) return null;
  // ONE COUNT FOR "WHAT NEEDS ME" (9 Nov 2026, overnight walk): the badge said 6
  // decisions, the Tasks band "Needs you 9", the header "6 for you to decide", over nine
  // rows holding eleven questions. The badge is the TASKS that need you, the same figure
  // as the band, the pager ("1 of 9") and the Close list's "Needs you" rows.
  const n = close.counts && close.counts.needsYou;
  return typeof n === "number" && Number.isInteger(n) && n >= 0 ? n : null;
}

/**
 * One conversation as the sidebar lists it, or null when the row cannot be read as
 * one. The status is the API's word, or the stored state renamed one-to-one
 * (lib/status.js wordForState); a row with neither is dropped rather than drawn in a
 * guessed state.
 */
function conversationFrom(row) {
  if (!row || typeof row !== "object") return null;
  const id = row.sessionId ?? row.id;
  const title = typeof row.title === "string" ? conversationTitle(row.title) : "";
  if ((typeof id !== "string" && typeof id !== "number") || !title) return null;
  let status;
  try {
    status = wordForState(row.status ?? row.state);
  } catch {
    return null;
  }
  const out = { id: String(id), title, status, href: `/chat/${encodeURIComponent(String(id))}` };
  // When it last moved, for the row's age (visual spec §1). Carried only when readable,
  // so a row with no time draws no age rather than a made-up "now".
  const updatedAt = instantOf(row.updatedAt);
  if (updatedAt !== null) out.updatedAt = updatedAt;
  // A task's conversation names its template: the homepage board lists a task started
  // from chat as a row of its own (components/home/board.js). A chat carries none.
  if (typeof row.template === "string" && row.template) out.template = row.template;
  return out;
}

// Needs-you first, then in the order the source gave (spec §2.1). A partition on the
// word, not a status computed here.
function needsYouFirst(list) {
  return [...list.filter((c) => c.status === "Needs you"), ...list.filter((c) => c.status !== "Needs you")];
}

/**
 * Each conversation's open decisions, as the month read them (design-fix-2 DA2-057). The
 * sidebar's row used to carry a status dot; it carries the count of decisions waiting in
 * that conversation instead, and only when there are some. The count is the task row's
 * own `decisions` from `GET /close/{period}` — the figure the Month-end checklist prints
 * beside the same task — joined on `sessionId`, never computed here. A month that could
 * not be read gives no map, and then no row carries a count (absent, never zero).
 */
export function decisionsBySession(close, period) {
  let body = close;
  if (body && body.months && typeof body.months === "object") body = body.months[period] || null;
  if (!body || !Array.isArray(body.tasks)) return null;
  const out = new Map();
  for (const t of body.tasks) {
    if (!t || (typeof t.sessionId !== "string" && typeof t.sessionId !== "number")) continue;
    if (typeof t.decisions === "number" && Number.isInteger(t.decisions) && t.decisions >= 0) out.set(String(t.sessionId), t.decisions);
  }
  return out;
}

function withDecisions(list, map) {
  if (!map) return list;
  return list.map((c) => (map.has(c.id) ? { ...c, decisions: map.get(c.id) } : c));
}

function conversationsFrom(body) {
  const list = Array.isArray(body) ? body : body && Array.isArray(body.sessions) ? body.sessions : [];
  return needsYouFirst(list.map(conversationFrom).filter(Boolean));
}

/**
 * Everything the shell draws, for this request.
 *
 * `engine` is the payload app/layout.js reads (never re-read here) — the payload, or the
 * promise of it: the sidebar's own reads go out first and only the business name and
 * the fallbacks wait for it (staging smoke, 23 Oct 2026). `signedInAs` is the public
 * half of the session, used only as the client label when the payload names no
 * business.
 */
export async function readShellData({ engine, signedInAs = null }) {
  const payloadRead = Promise.resolve(engine).then((e) => e || {});
  // Scheduled's badge, asked beside the months (it depends on none of them).
  const waitingRead = readScheduledBody().then(waitingFrom, () => null);
  // Months: the service's list, else what the payload says it covers. Read with this
  // browser's month choice, side by side; the listing is the request's one read of it.
  const [periodsRead, chosen] = await Promise.all([readPeriods(), visibleMonth()]);
  const listed = periodsRead.ok ? monthsFrom(periodsRead.body) : null;
  let months;
  let period;
  let monthRead = null;
  if (listed) {
    // ONE RULE FOR THE VISIBLE MONTH AND THE MONTHS OFFERED (lib/period.js shownMonth,
    // offeredMonths; verify pass 1 F02/F22). The same rule Month-end and the Clients view
    // use, so the sidebar, the page and the Clients row name one month. A month offered
    // and not started is listed as such, and choosing it lands on its Start screen; the
    // month after the latest started one is always offered, so it can be started.
    const listedPeriods = listed.map((m) => m.period);
    const close = closeMonthOf(new Date());
    period = shownMonth(listedPeriods, chosen, close);
    // The month's badge and conversations are asked now, beside the month itself.
    monthRead = period ? readShellMonth(period, payloadRead) : null;
    const labels = new Map(listed.map((m) => [m.period, m.label]));
    const shownRead = period ? await readClose(period) : null;
    const closed = closedMonths(listed, period, shownRead);
    const reopened = new Set(listed.filter((m) => m.reopened === true).map((m) => m.period));
    const opened = openedMonths(listed, period, shownRead);
    months = offeredMonths(listedPeriods, { close, shown: period, opened }).map((m) => ({
      period: m.period,
      label: labels.get(m.period) || periodLabel(m.period),
      started: m.started,
      ...(closed.has(m.period) ? { closed: true } : {}),
      ...(reopened.has(m.period) ? { reopened: true } : {}),
    }));
  }

  const payload = await payloadRead;
  // WHICH CLIENT THESE BOOKS ARE (§19.0.9): a person who switched reads the chosen
  // client, not the key's home one, so the fallback name and the switcher's tick are
  // the chosen client's. Asked only with a session (`signedInAs`), so the static build
  // reads no cookie and stays prerendered.
  const switched = signedInAs && signedInAs.person ? await chosenClient(await readSession()) : null;
  const clientId = switched || (signedInAs && signedInAs.tenant) || null;
  // The display name, never the raw tenant id (lib/format.js accountName; eval S6).
  const client = accountName({ business: payload.business, tenant: clientId });

  if (!listed) {
    months = monthsFrom(payload.periods);
    if (!months.length && isPeriod(payload.period)) months = [{ period: payload.period, label: periodLabel(payload.period) }];
    // The visible month: the one this browser chose, if the payload has it; else the
    // latest month there is. ISO months sort as strings.
    const latest = months.map((m) => m.period).sort().at(-1) || null;
    period = chosen && months.some((m) => m.period === chosen) ? chosen : latest;
  }

  const month = period
    ? await (monthRead || readShellMonth(period, payload))
    : { decisions: null, conversations: [], replayed: false, conversationsRead: false };

  return {
    client,
    clientId,
    period,
    periodLabel: period ? periodLabel(period) : null,
    months,
    waiting: await waitingRead,
    ...month,
  };
}

/**
 * Scheduled's badge: `GET /scheduled`'s `waitingTotal`, the engine's count of drafts
 * waiting for a person (scheduled-spec.md). Never summed from the tasks here; a read
 * that failed, or a body without it, is no badge (null), never a 0.
 */
export function waitingFrom(read) {
  if (!read || !read.ok || !read.body || typeof read.body !== "object") return null;
  const n = read.body.waitingTotal;
  return typeof n === "number" && Number.isInteger(n) && n >= 0 ? n : null;
}

/**
 * The two figures of one month the shell keeps live: the decisions badge and the
 * conversation list. One reader for the layout's render AND for the sidebar's own
 * re-read (app/api/shell/route.js), so a count read on a poll is never worked out
 * differently from the count the page was drawn with (eval D1: one source for counts).
 *
 * `payload` is the engine payload the layout already holds. The re-read passes none,
 * and then a failed read leaves its figure absent (null, not replayed) rather than
 * falling back to a recording. `conversationsRead` says whether the list was READ, so
 * a poll that failed never replaces a real list with an empty one.
 */
export async function readShellMonth(period, payload = null, { close = true } = {}) {
  // `close: false` is the sidebar's poll while a conversation is Vert's working
  // (live-shell.js): the list is what moves then, and `GET /close` is the heaviest
  // read Vert has (Vercel CPU, 4 Nov 2026). The badge and each row's count are then
  // not read at all (`closeAsked: false`), and the shell keeps the ones it drew.
  const [closeRead, sessionsRead] = await Promise.all([
    close ? readClose(period) : Promise.resolve({ ok: false }),
    readSessionsOf(period),
  ]);
  // The payload (or the promise of it, from the layout) is wanted only for a fallback.
  const p = (await payload) || {};
  const decisions = closeRead.ok ? decisionsFrom(closeRead.body, period) : decisionsFrom(p.close, period);
  let conversations = [];
  let replayed = false;
  if (sessionsRead.ok) {
    conversations = withDecisions(conversationsFrom(sessionsRead.body), closeRead.ok ? decisionsBySession(closeRead.body, period) : null);
  } else if (Array.isArray(p.replays)) {
    // The static build's conversations are recordings, and the list says so once
    // (spec §9.5) rather than presenting them as this client's work.
    conversations = conversationsFrom(p.replays.filter((r) => !r.period || r.period === period));
    replayed = conversations.length > 0;
  }
  return { decisions, conversations, replayed, conversationsRead: Boolean(sessionsRead.ok), ...(close ? {} : { closeAsked: false }) };
}

/* ══════════════════════════════════════════════════════════════════════════ *
 * Source freshness — one reader for every surface (eval C6)
 * ══════════════════════════════════════════════════════════════════════════ */

// The payout sources a register can hold, mapped to the connection that feeds them.
// The ledger is not here: it is where entries go, not a source whose freshness the
// engine measures, and saying "up to date" about it would be a claim nobody checked.
const PROVIDER_OF_KIND = { stripe: "stripe", shopify_payments: "shopify", shopify: "shopify" };
const PAYOUT_PROVIDERS = new Set(Object.values(PROVIDER_OF_KIND));
// `not_connected` is the engine's own word too (p0/refresh-tenant 986b57f): a processor
// with no active connection, and a ledger the client has none of.
const READ_STATES = new Set(["fresh", "stale", "failed", "not_read", "not_connected"]);

const UNKNOWN = Object.freeze({ state: "unknown", at: null });

function freshnessOf(raw) {
  const f = raw && typeof raw === "object" ? raw : {};
  const at = typeof f.at === "string" && f.at ? f.at : null;
  // A bank row's reach (the last day its lines cover) is kept for the words.
  const through = typeof f.through === "string" && f.through ? { through: f.through } : {};
  return READ_STATES.has(f.state) ? { state: f.state, at, ...through } : { state: "unknown", at };
}

function closeSourcesOf(close) {
  if (!close || typeof close !== "object" || !Array.isArray(close.sources)) return null;
  return close.sources
    .filter((s) => s && typeof s === "object" && typeof s.label === "string" && s.label.trim())
    .map((s) => ({ kind: typeof s.kind === "string" ? s.kind : s.label, label: s.label.trim(), freshness: s.freshness, ...postingOf(s) }));
}

/**
 * Every source's freshness, decided once. Pure, so the rules below are tested without
 * a service (tests/sidebar.test.js).
 *
 * `closeSources` is the month's `sources` as the API or the export gave them, or null
 * when that read failed. `connections` is `readConnections()`'s answer, or null when
 * there is no service to ask (the static build, whose recordings are shown as they
 * were recorded).
 *
 * Returns `{ measured, sources }`: `sources` is `[{kind, label, freshness: {state,
 * at}}]`, or null when nothing at all could be read — which a surface says in a
 * sentence, never as an empty list ("Vert can see nothing, and that is fine").
 *
 * THE RULES, and the defect each one stops:
 *   · The connections read failed → every source is "unknown", whatever the register
 *     says. Nobody may print "up to date" about a source whose connection could not
 *     even be asked about (eval C6).
 *   · A payout source whose connection is not connected is "not_connected", with the
 *     last read kept for the words: the register's age says nothing about whether Vert
 *     can read it next time.
 *   · A connected payout source the register holds nothing from is "not_read".
 *   · The month's read failed → every connected source is "unknown".
 *   · A freshness state this build does not know is "unknown", never "fresh".
 */
// The ledger row's as-at (engine w3/int, walk 1 D5), carried as sent when there is one,
// and what posting to it still needs, in the engine's words (a connected ledger with no
// account mapping, production 3 Nov 2026).
const postingOf = (s) => (s && s.posting && typeof s.posting === "object" && typeof s.posting.words === "string" && s.posting.words.trim() ? { posting: s.posting } : {});
const asAtOf = (s) => ({ ...(s && s.asAt && typeof s.asAt === "object" ? { asAt: s.asAt } : {}), ...postingOf(s) });

export function sourcesFrom({ closeSources = null, connections = null } = {}) {
  const listed = Array.isArray(closeSources) ? closeSources : null;

  if (!connections) {
    if (!listed) return { measured: false, sources: null };
    return { measured: true, sources: listed.map((s) => ({ kind: s.kind, label: s.label, freshness: freshnessOf(s.freshness), ...asAtOf(s) })) };
  }

  if (!connections.ok) {
    if (!listed || !listed.length) return { measured: false, sources: null };
    return { measured: false, sources: listed.map((s) => ({ kind: s.kind, label: s.label, freshness: { ...UNKNOWN } })) };
  }

  const rows = providerRows(connections.connections);
  const byProvider = new Map(rows.map((r) => [r.id, r]));
  const out = [];
  const seen = new Set();
  for (const s of listed || []) {
    const provider = PROVIDER_OF_KIND[s.kind] || null;
    if (provider) seen.add(provider);
    const row = provider ? byProvider.get(provider) : null;
    const freshness = freshnessOf(s.freshness);
    out.push({
      kind: s.kind,
      label: s.label,
      freshness: row && !row.connected ? { state: "not_connected", at: freshness.at } : freshness,
      ...asAtOf(s),
    });
  }
  for (const row of rows) {
    if (!PAYOUT_PROVIDERS.has(row.id) || !row.connected || seen.has(row.id)) continue;
    out.push({ kind: row.id, label: row.name, freshness: listed ? { state: "not_read", at: null } : { ...UNKNOWN } });
  }
  return { measured: Boolean(listed), sources: out };
}

/**
 * The sources for a month, for this request — the reader the context sheet, Month-end
 * (its footer and its "hasn't synced" rows) and Connections all consume, so one source
 * has one status on every screen. `engine` is the payload app/layout.js read, used
 * only when there is no service (the static build).
 */
export async function readSources({ period, engine = null } = {}) {
  if (!isPeriod(period)) return { measured: false, sources: null };
  const closeRead = await readClose(period);
  if (!closeRead.ok && closeRead.reason === "no-service") {
    let close = engine && engine.close;
    if (close && close.months && typeof close.months === "object") close = close.months[period] || null;
    return sourcesFrom({ closeSources: closeSourcesOf(close), connections: null });
  }
  const connections = await readConnections();
  return sourcesFrom({ closeSources: closeRead.ok ? closeSourcesOf(closeRead.body) : null, connections });
}
