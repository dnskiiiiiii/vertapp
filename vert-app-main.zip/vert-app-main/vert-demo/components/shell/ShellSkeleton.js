// components/shell/ShellSkeleton.js — THE FRAME, WHILE THE SHELL'S READS LAND (verify pass 1 S-UI-8)
// ==============================================================================
// The root layout streams this first (app/layout.js), so a slow link or a slow close read
// shows the shell's own shape at once instead of a blank page for seconds. The desk-grey
// sidebar with a few placeholder rows, and Month-end's shape in the page column (the same
// blocks as app/loading.js). It names no client, month or count: none has been read yet.
// Server-safe: no hooks, no handlers.

import { SkeletonBlock } from "@/components/ui/marks";

export default function ShellSkeleton() {
  return (
    <div className="shell shell-skeleton" data-shell-skeleton="">
      <aside className="sidebar" aria-hidden="true">
        <div className="sk-stack shell-skeleton-rail">
          <SkeletonBlock width="4.5rem" height="1.5rem" radius="var(--r-sm)" />
          <SkeletonBlock width="100%" height="2rem" radius="var(--r-sm)" />
          <SkeletonBlock width="100%" height="2.75rem" radius="var(--r-sm)" />
          <SkeletonBlock width="70%" height="1rem" />
          <SkeletonBlock width="85%" height="1rem" />
          <SkeletonBlock width="60%" height="1rem" />
        </div>
      </aside>
      <main className="shell-main">
        <div className="content">
          <section className="page route-loading route-loading-home" role="status" aria-live="polite" aria-busy="true">
            <span className="sr-only">Loading Vert</span>
            <div className="sk-stack sk-head">
              <SkeletonBlock width="10rem" height="1.75rem" radius="var(--r-sm)" />
              <SkeletonBlock width="14rem" height="0.875rem" />
            </div>
            <SkeletonBlock width="100%" height="0.375rem" radius="var(--r-bar)" />
            <SkeletonBlock className="sk-ask" width="100%" height="4rem" radius="var(--r-card)" />
          </section>
        </div>
      </main>
    </div>
  );
}
