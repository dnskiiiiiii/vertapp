// components/shell/command/keys.js — WHICH KEY OPENS THE COMMAND MENU, AND WHERE FOCUS GOES
// ==============================================================================
// Founder decision D6 (10 Oct 2026); design-fix-2 spec §6.1. Pure functions, so the rules
// are tested without a browser (tests/command-menu.test.js):
//
//   · ⌘K on a Mac, Ctrl+K everywhere else, toggles the menu FROM ANYWHERE — including
//     inside the composer and every other field — because it is the one way to jump.
//     On a Mac, Ctrl+K is left alone: in a text field it is the platform's "delete to
//     the end of the line".
//   · Ignored while an input method is composing (event.isComposing): a Japanese or
//     Chinese typist's K is a character, not a command.
//   · No ⌘N binding: the browser owns it. New chat is a command and a sidebar row.
//   · Esc closes it; on close, focus returns to whatever had it when the menu opened.

/** True on Apple platforms, where the command key is ⌘. */
export function isApplePlatform(nav = typeof navigator === "undefined" ? null : navigator) {
  if (!nav) return false;
  const hint = (nav.userAgentData && nav.userAgentData.platform) || nav.platform || nav.userAgent || "";
  return /mac|iphone|ipad|ipod/i.test(String(hint));
}

/** Does this keydown toggle the command menu? */
export function isCommandKey(event, { apple = isApplePlatform() } = {}) {
  if (!event || event.isComposing || event.keyCode === 229) return false;
  if (String(event.key || "").toLowerCase() !== "k") return false;
  if (event.altKey || event.shiftKey) return false;
  return apple ? Boolean(event.metaKey) && !event.ctrlKey : Boolean(event.ctrlKey) && !event.metaKey;
}

/** The shortcut as it is printed in a <kbd> chip. */
export function shortcutLabel({ apple = isApplePlatform() } = {}) {
  return apple ? "⌘K" : "Ctrl K";
}

/**
 * The open/close bookkeeping, independent of React: remembers the element that had focus
 * when the menu opened and gives focus back to it on close (if it is still in the
 * document). `doc` is the document (a fake one in tests).
 */
export function createFocusReturn(doc = typeof document === "undefined" ? null : document) {
  let opener = null;
  return {
    remember() {
      opener = doc && doc.activeElement && doc.activeElement !== doc.body ? doc.activeElement : null;
      return opener;
    },
    restore() {
      const target = opener;
      opener = null;
      if (!target || typeof target.focus !== "function") return false;
      if (doc && doc.contains && !doc.contains(target)) return false;
      target.focus();
      return true;
    },
    get opener() {
      return opener;
    },
  };
}
