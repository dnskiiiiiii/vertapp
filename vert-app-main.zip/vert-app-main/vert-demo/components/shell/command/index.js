// components/shell/command — the command menu's behaviour (DS-FOUND) and data. The UI,
// components/shell/CommandMenu.js, is DS-SHELL's (design-fix-2 spec §6.2).
export { CommandMenuProvider, useCommandMenu, useCommandSources, useRegisterCommandTasks } from "./CommandMenuProvider";
export { isCommandKey, isApplePlatform, shortcutLabel, createFocusReturn } from "./keys";
export { GROUPS, NEW_CHAT_HREF, OPEN_PEOPLE_EVENT, CONNECTIONS_HREF, commandGroups, actionItems, clientItems, monthItems, conversationItems, taskItems } from "./sources";
