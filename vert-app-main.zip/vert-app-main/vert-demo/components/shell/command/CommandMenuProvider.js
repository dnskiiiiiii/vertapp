"use client";

// components/shell/command/CommandMenuProvider.js — THE COMMAND MENU'S STATE AND ITS KEY
// ==============================================================================
// Founder decision D6 (10 Oct 2026); design-fix-2 spec §6.1. Mounted ONCE, in AppShell.
// This file owns the behaviour; the menu's look (cmdk's Command.Dialog, the input row,
// the groups, the footer) is components/shell/CommandMenu.js, built by DS-SHELL on top of
// `useCommandMenu()` and `useCommandSources()`.
//
//   useCommandMenu()    → { open, setOpen, toggle, query, setQuery, perform, registerTasks }
//   useCommandSources() → the groups to show ({ group, count, items }), built from the
//                         shell's data, the firm's clients (read once, on first open) and
//                         the tasks a page registered; plus `loading` while clients load.
//
// THE KEY: ⌘K on a Mac, Ctrl+K elsewhere, from anywhere, even inside a field; never while
// an input method is composing (keys.js). Esc closes. Focus returns to the opener.
//
// WHAT AN ITEM DOES (`perform(item)`): an `href` navigates; a `run` is one of
//   ask           start a conversation with the typed text (as the Home ask box does,
//                 lib/agent/actions.js startConversation) and open it;
//   switch-client prove and switch the client (lib/firm.js switchClient), then Home;
//   month         show that month (the month cookie the sidebar's control writes);
//   event         dispatch a window event another component listens for.

import { useRouter } from "next/navigation";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";

import { startConversation } from "@/lib/agent/actions";
import { sendFailureWords } from "@/components/chat/Composer";
import { switchClient } from "@/lib/firm";
import { MONTH_COOKIE } from "@/lib/period";

import { createFocusReturn, isCommandKey } from "./keys";
import { useOpenSwitchedClient } from "../switching";
import { NEW_CHAT_HREF, clientsPending, commandGroups } from "./sources";

const CommandMenuContext = createContext(null);

export function CommandMenuProvider({ shell = null, children }) {
  const router = useRouter();
  const openSwitched = useOpenSwitchedClient();
  const [open, setOpenState] = useState(false);
  const [query, setQuery] = useState("");
  const [tasks, setTasks] = useState([]);
  const [clients, setClients] = useState({ state: "idle", list: [] });
  const [problem, setProblem] = useState(null);
  const focus = useRef(null);
  if (focus.current === null && typeof document !== "undefined") focus.current = createFocusReturn(document);

  const openRef = useRef(false);
  const setOpen = useCallback((next) => {
    const was = openRef.current;
    const value = typeof next === "function" ? Boolean(next(was)) : Boolean(next);
    if (value === was) return;
    openRef.current = value;
    if (value && focus.current) focus.current.remember();
    if (!value) {
      setQuery("");
      setProblem(null);
      // After the dialog has gone, so focus is not trapped inside it any more.
      if (focus.current) setTimeout(() => focus.current.restore(), 0);
    }
    setOpenState(value);
  }, []);
  const toggle = useCallback(() => setOpen((was) => !was), [setOpen]);

  // The key, from anywhere. Capture phase, so a field's own key handler cannot swallow it.
  useEffect(() => {
    function onKey(event) {
      if (isCommandKey(event)) {
        event.preventDefault();
        toggle();
      } else if (event.key === "Escape" && open) {
        event.preventDefault();
        setOpen(false);
      }
    }
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [open, setOpen, toggle]);

  // The firm's clients, read once, on the first open (the switcher's own read).
  const period = shell && shell.period;
  useEffect(() => {
    if (!open || clients.state !== "idle") return;
    setClients({ state: "loading", list: [] });
    fetch(`/api/firm?view=switcher&period=${encodeURIComponent(period || "")}`, { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : null))
      .then((body) => setClients({ state: "read", list: body && Array.isArray(body.clients) ? body.clients : [] }))
      .catch(() => setClients({ state: "failed", list: [] }));
  }, [open, clients.state, period]);

  const perform = useCallback(
    async (item) => {
      if (!item) return;
      setProblem(null);
      if (item.href) {
        setOpen(false);
        router.push(item.href);
        return;
      }
      const run = item.run || {};
      if (run.type === "ask") {
        const text = String(run.text || "").trim();
        if (!text) {
          setOpen(false);
          router.push(NEW_CHAT_HREF);
          return;
        }
        const result = await startConversation({ period: period || undefined, text });
        if (!result || !result.ok || !result.sessionId) {
          // A refusal of the ask itself (a 400 over 4,000 characters) is named, not
          // called a server that didn't answer (harsh wave 1, W1-45).
          const status = result && Number.isInteger(result.status) ? result.status : 0;
          setProblem(status === 400 || status === 422 ? sendFailureWords(result).replace("Your message is", "Your question is") : "Couldn't start the conversation: Vert's server didn't answer. Your question is still here.");
          return;
        }
        setOpen(false);
        router.push(`/chat/${encodeURIComponent(result.sessionId)}`);
      } else if (run.type === "switch-client") {
        const switched = await switchClient(run.tenant, { period: period || null });
        if (!switched || !switched.ok) {
          setProblem((switched && switched.message) || "Vert couldn't open that client. You're still on the one you had.");
          return;
        }
        setOpen(false);
        // Said at once, until the new client's page draws (verify pass 1 S-E2E-3).
        openSwitched(item.label);
      } else if (run.type === "month") {
        document.cookie = `${MONTH_COOKIE}=${encodeURIComponent(run.period)}; path=/; max-age=31536000; samesite=lax`;
        setOpen(false);
        router.push("/");
        router.refresh();
      } else if (run.type === "event") {
        setOpen(false);
        window.dispatchEvent(new Event(run.name));
      }
    },
    [period, router, setOpen, openSwitched]
  );

  const registerTasks = useCallback((list) => setTasks(Array.isArray(list) ? list : []), []);

  const value = useMemo(
    () => ({ open, setOpen, toggle, query, setQuery, perform, registerTasks, problem, shell, tasks, clients }),
    [open, setOpen, toggle, query, perform, registerTasks, problem, shell, tasks, clients]
  );
  return <CommandMenuContext.Provider value={value}>{children}</CommandMenuContext.Provider>;
}

const OUTSIDE = Object.freeze({
  open: false,
  setOpen() {},
  toggle() {},
  query: "",
  setQuery() {},
  perform() {},
  registerTasks() {},
  problem: null,
  shell: null,
  tasks: [],
  clients: { state: "idle", list: [] },
});

/** The menu's state. Outside the provider (a test render, sign-in) it is a closed no-op. */
export function useCommandMenu() {
  return useContext(CommandMenuContext) || OUTSIDE;
}

/** The groups to show for the current query. */
const NONE = Object.freeze([]);

export function useCommandSources({ full = NONE } = {}) {
  const { query, shell, tasks, clients } = useCommandMenu();
  const groups = useMemo(() => commandGroups({ query, shell, clients: clients.list, tasks, full }), [query, shell, clients.list, tasks, full]);
  return { groups, loading: clientsPending(clients.state) };
}

/**
 * A page hands the menu the tasks it already holds (Month-end's checklist), while it is
 * mounted. `tasks` is [{ id, title, status, href | run }].
 */
export function useRegisterCommandTasks(tasks) {
  const { registerTasks } = useCommandMenu();
  useEffect(() => {
    registerTasks(tasks);
    return () => registerTasks([]);
  }, [registerTasks, tasks]);
}
