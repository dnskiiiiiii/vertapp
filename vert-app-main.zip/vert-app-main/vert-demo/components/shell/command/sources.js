// components/shell/command/sources.js — WHAT THE COMMAND MENU CAN JUMP TO
// ==============================================================================
// Founder decision D6; design-fix-2 spec §6.1. Pure: the groups are built from data the
// shell ALREADY reads (components/shell/shell-data.js: the client, the months, this
// month's conversations), the firm's client list (`GET /api/firm`, the switcher's read,
// fetched lazily on first open), and the tasks a page registers (Month-end registers the
// checklist it already holds). Nothing here reads the engine itself.
//
// Every item is `{ id, group, label, keywords, meta, icon, href | run }`: exactly one of
// `href` (a route) or `run` (a named action the provider performs), so every item does
// something (tests/command-menu.test.js holds every source to that).

import { CLIENTS_HREF, MONTH_END_HREF } from "@/components/shell/ia";
import { ageLabel } from "@/components/shell/age";
import { accountName } from "@/lib/format";
import { monthListWord } from "@/lib/period";

export const GROUPS = Object.freeze(["Actions", "Clients", "Months", "Conversations", "Tasks"]);

// The routes the menu offers by name.
export const CONNECTIONS_HREF = "/connections";
/** Home with its ask box focused: where "New chat" goes with nothing typed (§6.1). */
export const NEW_CHAT_HREF = "/?ask=1";
/** The account menu opens its People sheet on this window event (SHELL wires the listener). */
export const OPEN_PEOPLE_EVENT = "vert:open-people";

/** The actions, with the query folded into "Ask Vert" when something is typed. */
export function actionItems(query = "") {
  const q = String(query || "").trim();
  const items = [];
  if (q) {
    items.push({ id: "ask", group: "Actions", label: `Ask Vert “${q}”`, keywords: ["ask", "chat", "question", q], icon: "chat", run: { type: "ask", text: q } });
  }
  items.push(
    { id: "new-chat", group: "Actions", label: "New chat", keywords: ["new", "chat", "conversation", "ask"], icon: "new-chat", run: q ? { type: "ask", text: q } : null, href: q ? undefined : NEW_CHAT_HREF },
    { id: "go-month-end", group: "Actions", label: "Go to Month-end", keywords: ["home", "month", "close", "checklist"], icon: "month-end", href: MONTH_END_HREF },
    { id: "go-clients", group: "Actions", label: "Clients", keywords: ["firm", "clients", "all"], icon: "clients", href: CLIENTS_HREF },
    { id: "go-connections", group: "Actions", label: "Connections", keywords: ["sources", "stripe", "bank", "ledger", "connect"], icon: "connections", href: CONNECTIONS_HREF },
    { id: "people", group: "Actions", label: "People and roles", keywords: ["people", "roles", "team", "reviewer", "preparer"], icon: "people", run: { type: "event", name: OPEN_PEOPLE_EVENT } }
  );
  // An item with a `run` keeps no stray `href` key, and vice versa.
  return items.map((item) => (item.run ? { ...item, href: undefined } : { ...item, run: undefined }));
}

/**
 * Are the firm's clients still to arrive? "idle" counts: the first render after opening
 * comes before the read starts (verify pass 10 S-E2E-3). A failed read is not pending.
 */
export function clientsPending(state) {
  return state === "idle" || state === "loading";
}

/** The firm's clients, from the switcher's `GET /api/firm` body. */
export function clientItems(clients = [], { current = null } = {}) {
  if (!Array.isArray(clients)) return [];
  return clients
    .filter((c) => c && (typeof c.tenantId === "string" || typeof c.tenantId === "number"))
    .map((c) => {
      // The client's display name by the one rule every other list uses (lib/format.js
      // accountName, as the Clients view and the switcher draw it): a name that is only
      // the tenant's slug ("northwind") is drawn "Northwind", never the slug.
      const raw = String(c.name || c.business || c.label || "").trim();
      const name = accountName({ business: raw, tenant: String(c.tenantId) }) || String(c.tenantId);
      return {
        id: `client:${c.tenantId}`,
        group: "Clients",
        label: name,
        keywords: ["client", "switch", name],
        meta: String(c.tenantId) === String(current) ? "Current" : c.monthLabel || null,
        icon: "client",
        run: { type: "switch-client", tenant: String(c.tenantId) },
      };
    });
}

/** The current client's months, newest first. */
export function monthItems(months = [], { current = null } = {}) {
  if (!Array.isArray(months)) return [];
  return [...months]
    .filter((m) => m && typeof m.period === "string")
    .sort((a, b) => (a.period < b.period ? 1 : a.period > b.period ? -1 : 0))
    .map((m) => ({
      id: `month:${m.period}`,
      group: "Months",
      label: m.label || m.period,
      keywords: ["month", m.period, m.label || "", ...(m.started === false && m.closed !== true ? ["start"] : [])],
      // A month offered and not started yet (lib/period.js offeredMonths) says so: choosing
      // it lands on its Start screen (verify pass 1 F02).
      meta: m.period === current ? "Showing" : monthListWord(m),
      icon: "month",
      run: { type: "month", period: m.period },
    }));
}

/** This month's conversations, most recent first, each with its age. */
export function conversationItems(conversations = [], { now = Date.now() } = {}) {
  if (!Array.isArray(conversations)) return [];
  const timed = conversations.filter((c) => c && typeof c.href === "string" && typeof c.title === "string");
  const order = [...timed].sort((a, b) => (Number(b.updatedAt) || 0) - (Number(a.updatedAt) || 0));
  return order.map((c) => ({
    id: `conversation:${c.id}`,
    group: "Conversations",
    label: c.title,
    keywords: ["conversation", "chat", c.status || ""],
    meta: typeof c.updatedAt === "number" ? ageLabel(c.updatedAt, now) : c.status || null,
    icon: "conversation",
    href: c.href,
  }));
}

/** The month's checklist, as a page registered it: title and its status word. */
export function taskItems(tasks = []) {
  if (!Array.isArray(tasks)) return [];
  return tasks
    .filter((t) => t && typeof t.title === "string" && (typeof t.href === "string" || t.run))
    .map((t) => ({
      id: `task:${t.id ?? t.title}`,
      group: "Tasks",
      label: t.title,
      keywords: ["task", t.group || "", t.status || ""],
      meta: t.status || null,
      icon: "task",
      ...(t.href ? { href: t.href } : { run: t.run }),
    }));
}

/**
 * Every group the menu shows, in order, empty groups dropped. With nothing typed, `limit`
 * caps each group (spec §6.2: six, then "Show all N"; `full` lifts the cap for the groups
 * named in it). While a query is typed nothing is capped, because the menu filters what
 * it is given and a match beyond the sixth must still be found.
 */
export function commandGroups({ query = "", shell = null, clients = [], tasks = [], now = Date.now(), limit = 6, full = [] } = {}) {
  const s = shell || {};
  const all = [
    ["Actions", actionItems(query)],
    ["Clients", clientItems(clients, { current: s.clientId })],
    ["Months", monthItems(s.months, { current: s.period })],
    ["Conversations", conversationItems(s.conversations, { now })],
    ["Tasks", taskItems(tasks)],
  ];
  return all
    .filter(([, items]) => items.length)
    .map(([group, items]) => ({
      group,
      count: items.length,
      items: String(query || "").trim() || full.includes(group) || group === "Actions" ? items : items.slice(0, limit),
    }));
}
