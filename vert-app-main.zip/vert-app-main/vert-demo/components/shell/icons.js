// components/shell/icons.js — THE SHELL'S GLYPHS, NOW PHOSPHOR
// ==============================================================================
// Founder decision D7 (10 Oct 2026); design-fix-2 spec §4. The shell's hand-drawn glyphs
// are gone: every one is re-exported from components/ui/icons.js, the one icon set, under
// the name its call sites already use. Each owner moves its imports to
// "@/components/ui/icons" when it next touches the file; this list then empties and the
// file keeps only the mark.

export {
  IconMonthEnd,
  IconMenu,
  IconClose,
  IconCaretDown as IconChevronDown,
  IconCaretLeft as IconChevronLeft,
  IconMore,
  IconEye,
  IconEyeOff,
  IconConnections,
  IconSignOut,
  IconCheck,
  IconPeople,
  IconClients,
  IconCaretUpDown as IconChevronUpDown,
  IconPayments,
  IconLedger,
  IconShop,
  IconBank,
  IconStatement,
} from "@/components/ui/icons";
import { IconCaretRight } from "@/components/ui/icons";

/** A chevron pointing right, at the shell's 16 px. */
export function IconChevronRight(props) {
  return <IconCaretRight size={16} {...props} />;
}

// THE MARK IS THE WEBSITE'S (founder, 10 Oct 2026). Vert's mark is the navy circle of
// radiating stripes that frame a triangle, as drawn in the website's header
// (Website/app/components/site/Header.jsx: /v3/mark-navy.webp at 32 px beside "Vert",
// medium weight, -0.02em tracking, ink). The violet disc with a white crescent that
// stood here was never Vert's logo, and it is gone with its `--brand-mark` token. The
// files are public/brand/vert-mark-navy.webp (the 320 px source) and
// vert-mark-white.webp (the white cut, for a dark ground), copied from the website.
//
// The lockup is the mark's image and the word, named ONCE: the wrapper is `role="img"`
// with aria-label "Vert", the image's alt is empty and the word is aria-hidden, so a
// screen reader says "Vert" a single time rather than "image, Vert" and then the word.
// The word is set in Archivo 500, the brand face (founder decision D2; kit.css
// `.wordmark-word`), with the UI face standing in until it loads.
//
// CRISP AT 1x AND 2x. The source is 320 px and its stripes are about 3 px wide; left to
// the browser's downscale they shimmer. So the image is drawn from copies sized once
// with Lanczos (32, 64 and 96 px, lossless), and `srcSet` hands each screen its own.
// `translate="no"`: a brand name is never machine-translated (WIG G20).
export const MARK_SRC = "/brand/vert-mark-navy-32.webp";
export const MARK_SRCSET = "/brand/vert-mark-navy-32.webp 1x, /brand/vert-mark-navy-64.webp 2x, /brand/vert-mark-navy-96.webp 3x";

const MARK_FILES = [32, 64, 96];

/**
 * The srcSet for the mark drawn at `size` CSS px: for 1x, 2x and 3x screens, the smallest
 * pre-sized file at least that many device pixels wide (the largest when none is), so a
 * 40 px lockup is drawn down from the 64 px file and never blown up from the 32. Pure.
 */
export function markSrcSet(size = 32) {
  const pick = (px) => MARK_FILES.find((f) => f >= px) || MARK_FILES[MARK_FILES.length - 1];
  return [1, 2, 3].map((x) => `/brand/vert-mark-navy-${pick(size * x)}.webp ${x}x`).join(", ");
}

export function Wordmark({ className, size = 32, ...props }) {
  const srcSet = size === 32 ? MARK_SRCSET : markSrcSet(size);
  return (
    <span role="img" aria-label="Vert" translate="no" className={className} {...props}>
      {/* eslint-disable-next-line @next/next/no-img-element -- pre-sized static files; next/image would only re-derive them */}
      <img
        className="wordmark-mark"
        src={srcSet.split(" ")[0]}
        srcSet={srcSet}
        width={size}
        height={size}
        alt=""
        decoding="async"
        draggable="false"
      />
      <span className="wordmark-word" aria-hidden="true">
        Vert
      </span>
    </span>
  );
}
