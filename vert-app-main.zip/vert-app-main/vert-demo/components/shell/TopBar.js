"use client";

// components/shell/TopBar.js — THE PHONE'S ONE BAR
// ==============================================================================
// Spec §3.8; audit UI-038; design-pass spec §6.10 and audit §0 P2. Below 900 px the
// sidebar leaves the page and this bar takes its place: 44 px, fixed, glass, so content
// scrolls under it and it never scrolls away. ≡ opens the sidebar as a left sheet.
//
// THE CONTEXT LIVES HERE ON A PHONE. The title says whose books and which month —
// "Northwind · July" — the two facts that must be true before anything on the page is
// read, and it is a quiet button: pressing it opens the sidebar with the client switcher
// open in it (or, for a key with one client, on its month). The same words used to sit
// here AND as a chip three lines below, and the conversation head spent 165 px of an
// 844 px screen restating them.
//
// FIRM MODE: on the Clients view no one client's books are shown, so the bar says the
// view's own name, "All clients" (the sidebar's nav item), rather than the client the
// browser last opened.
//
// Hidden from 1024 px by CSS (kit.css), where the sidebar is always visible. Its right
// edge holds Search, which opens the command menu (design-fix-2 DA2-041).

import { monthName } from "@/lib/period";
import { IconButton } from "@/components/ui/Button";

import { IconSearch } from "@/components/ui/icons";

import { IconChevronUpDown, IconMenu } from "./icons";
import { isFirmMode } from "./ClientSwitcher";
import { useCommandMenu } from "./command";
import "./shell.css";

/** The bar's words: the view's name in firm mode, else "Client · Month". Pure. */
export function topBarTitle({ client, period, pathname }) {
  if (isFirmMode(pathname)) return "Clients";
  return [client, period ? monthName(period) : null].filter(Boolean).join(" · ");
}

export default function TopBar({ client, period, navOpen = false, onOpenNav, onOpenContext, sidebarId = "sidebar", pathname = "", scrolled = false }) {
  const title = topBarTitle({ client, period, pathname });
  const firm = isFirmMode(pathname);
  const command = useCommandMenu();
  return (
    <header className="topbar" data-scrolled={scrolled ? "true" : undefined}>
      <IconButton
        label="Open the sidebar"
        onClick={onOpenNav}
        aria-expanded={navOpen ? "true" : "false"}
        aria-controls={sidebarId}
        className="topbar-menu"
      >
        <IconMenu />
      </IconButton>
      {title && !firm && onOpenContext ? (
        <button type="button" className="row topbar-context" onClick={onOpenContext} aria-controls={sidebarId} aria-expanded={navOpen ? "true" : "false"}>
          <span className="topbar-title" title={title}>{title}</span>
          <IconChevronUpDown className="topbar-context-chevron" />
          <span className="sr-only">, change client or month</span>
        </button>
      ) : title ? (
        <p className="topbar-title" title={title}>{title}</p>
      ) : null}
      {/* Search on a phone (DA2-041): the command menu, as a full-width sheet from the top. */}
      <IconButton label="Search" onClick={() => command.setOpen(true)} className="topbar-search">
        <IconSearch />
      </IconButton>
    </header>
  );
}
