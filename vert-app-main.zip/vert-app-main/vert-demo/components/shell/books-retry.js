// components/shell/books-retry.js — TRY AGAIN, WHEN THE BOOKS COULD NOT BE READ
// ==============================================================================
// Verify pass 4, F17 (S-UI-9). DataSourceDown's "Try again" was `<a href="">`: a link,
// not a control (G3: an action is a <button>), so a checker asking for the Try again
// BUTTON found none and the page stayed on "Vert can't reach your books". And a press
// was a blind reload: pressed while the service was still coming back, it drew the
// same card again with nothing to say that it had tried, and the person had to guess
// how long to wait before pressing again (pass 4 saw it load at 10 s, not at 3 s).
//
// THE RULE NOW: a press asks the page again with `cache: "no-store"` (no browser or
// proxy copy of the failure can answer) and swaps to the page only once the page no
// longer carries the card. While it still does, it waits briefly and asks again (1 s,
// 2 s, 4 s, 8 s: pass 4 saw the page come back about 10 s after the API did), saying
// so in words, and only after the last try says it still can't reach the books, with
// Try again offered again. Nothing here posts or changes a
// figure: it is a read, repeated.

/** The attribute DataSourceDown puts on its <main>; the probe looks for it. */
export const BOOKS_DOWN_MARK = "data-books-down";

/** Waits between tries, in ms. Four tries after the first, about 15 s in all. */
export const RETRY_DELAYS_MS = Object.freeze([1000, 2000, 4000, 8000]);

/** Does this page's HTML still carry the "can't reach your books" card? */
export function stillDown(html) {
  return typeof html !== "string" || html.includes(BOOKS_DOWN_MARK);
}

/**
 * Ask the page again until it comes back without the card, or the delays run out.
 * Returns "up" (the caller reloads) or "down" (the caller says so and offers the
 * button again). `fetchPage` must not throw past here: a refused request is "down".
 *
 *   fetchPage(href, init) -> Promise<{ ok, text() }>
 *   wait(ms)              -> Promise<void>
 *   onWaiting(attempt, ms) called before each wait, for the words on screen
 */
export async function retryUntilReadable({ href, fetchPage, wait, onWaiting = () => {}, delays = RETRY_DELAYS_MS }) {
  for (let attempt = 0; attempt <= delays.length; attempt++) {
    if (attempt > 0) {
      const ms = delays[attempt - 1];
      onWaiting(attempt, ms);
      await wait(ms);
    }
    let html = null;
    try {
      const response = await fetchPage(href, { cache: "no-store", credentials: "same-origin", headers: { "cache-control": "no-store" } });
      html = response && response.ok ? await response.text() : null;
    } catch {
      html = null;
    }
    if (!stillDown(html)) return "up";
  }
  return "down";
}
