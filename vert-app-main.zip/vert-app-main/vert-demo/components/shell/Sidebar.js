"use client";

// components/shell/Sidebar.js — ONE PLACE TO GO, AND THE WORK UNDER WAY
// ==============================================================================
// Spec §2.1; audit UI-059, UI-066, UI-069; design-fix-2 DA2-041, DA2-043, DA2-057.
//
//   ◉ Vert
//   🔍 Search            ⌘K      ← opens the command menu (CommandMenu.js, founder D6)
//   ✎  New chat                  ← Home with its ask box focused (/?ask=1)
//   +  New task                  ← the new-task form (founders, 22 Oct 2026), where a
//                                  task can be made: a live service and a client's month
//   [N] Northwind        ⇕      ← one switcher row: the client over its month
//       July 2026
//   ▣ Month-end              13  ← the client's month; the decisions that need you
//   ↻ Scheduled               3  ← the routines; the drafts waiting (scheduled-spec.md)
//   ──────────
//   ⌁ Connections
//   ▦ Clients                    ← a person in a firm only: the firm view
//   Conversations
//   Bank reconciliation      4   ← a conversation; the decisions waiting in it, if any
//   Earlier · 5
//   (SL) Sam Lee          •••    ← the account menu
//
// FIRM MODE (DA2-043; founder D4: the sidebar stays light, only its contents change). On
// the Clients view no one client's books are on screen, so the sidebar stops drawing a
// client's switcher, nav and conversations, and shows the firm's own places under a
// "Firm" heading: Clients and, for a person who may see it, People and roles. The brand,
// Search, New chat and the account row stay, so the way back to a client is one press
// (a Clients row, or ⌘K).
//
// EVERY ROW ON ONE INSET (DA2-057). The brand, the actions, the switcher's tile, the nav
// glyphs, the "Conversations" label, each title and "Earlier · N" all start 20 px from the
// sidebar's edge (the sidebar's 12 px gutter plus each row's 8 px), so the column reads as
// one edge. No row draws a status dot (the dots pushed titles 4 px off that edge).
//
// THE DESK (design-pass spec §4.3, §6.10). The sidebar is the structural layer: solid soft
// grey, near-black ink. The active item is a white pill with the smallest shadow: selected
// is LIFTED, never the accent (apple-design §12), so the one green on a screen stays the
// commit.
//
// ON A PHONE (below 1024 px) the same element becomes a left sheet, opened from the top
// bar's ≡ and closed by its own close control, Esc, the scrim or a navigation (AppShell
// owns that state, and makes the page behind it inert while it is open).

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";

import { IconButton } from "@/components/ui/Button";
import { Kbd } from "@/components/ui/marks";
import { IconAdd, IconNewChat, IconSearch } from "@/components/ui/icons";
import { useNewTask } from "@/components/month/NewTaskProvider";

import AccountMenu from "./AccountMenu";
import BackgroundNotice from "./BackgroundNotice";
import ClientSwitcher, { canSwitch, isFirmMode } from "./ClientSwitcher";
import ConversationList from "./ConversationList";
import ShellLink from "./ShellLink";
import { NEW_CHAT_HREF, OPEN_PEOPLE_EVENT, shortcutLabel, useCommandMenu } from "./command";
import { FIRM_NAV, FIRM_PLACES, MONTH_END_HREF, MONTH_END_SECTION, NAV, NAV_AFTER_RULE } from "./ia";
import { IconClose, Wordmark } from "./icons";
import { useThreadWords, withThreadWords } from "./thread-word";

/** Is this nav item the page being shown? Month-end is "/" exactly. */
export function isCurrent(pathname, href) {
  if (href === "/") return pathname === "/";
  return pathname === href || pathname.startsWith(`${href}/`);
}

/**
 * The aria-current a nav row carries: "page" on its own page, and nothing elsewhere.
 *
 * NOT ON A PAGE OF ITS SECTION (verify pass 2, U10/U63). On /records the Month-end row
 * used to carry aria-current="true", so a screen reader announced the link to "/" as the
 * current item while the page was Records. A link is current only where it goes. The
 * section is still drawn (pass 1 F-33 asked for a row to be lit on /records): that is
 * `sectionOf`, a data attribute the stylesheet reads, which no assistive technology
 * mistakes for "you are here".
 */
export function currentOf(pathname, href) {
  return isCurrent(pathname, href) ? "page" : undefined;
}

/** True when this row is the SECTION of the page shown (Records and the papers are Month-end's evidence; ia.js MONTH_END_SECTION), not its page. */
export function sectionOf(pathname, href) {
  return href === MONTH_END_HREF && !isCurrent(pathname, href) && MONTH_END_SECTION.some((p) => isCurrent(pathname, p));
}

// What each counter reads off the shell, and how its accessible name says it.
const COUNTERS = Object.freeze({
  // The field keeps its name; it holds the TASKS that need you (shell-data.js decisionsFrom).
  decisions: { field: "decisions", words: (n) => (n === 1 ? "task needs you" : "tasks need you") },
  // Scheduled's: the engine's `waitingTotal` (scheduled-spec.md), read by shell-data.js.
  waiting: { field: "waiting", words: () => "waiting" },
});

/** The count a nav row carries, or null: a measured count above zero only. */
export function navCount(item, shell) {
  const counter = item && COUNTERS[item.counter];
  if (!counter || !shell) return null;
  const n = shell[counter.field];
  return Number.isInteger(n) && n > 0 ? n : null;
}

const EMPTY_SHELL = { client: null, period: null, periodLabel: null, months: [], decisions: null, waiting: null, conversations: [], replayed: false };

/**
 * Search and New chat (DA2-041): the two ways to start, at the top of every sidebar. The
 * shortcut is printed for this platform once mounted (⌘K on a Mac, Ctrl K elsewhere); the
 * server and the first paint print ⌘K so the two renders agree.
 */
function SidebarActions({ firmMode = false }) {
  const { setOpen } = useCommandMenu();
  const { openNewTask, available } = useNewTask();
  const canTask = available && !firmMode;
  const [keys, setKeys] = useState("⌘K");
  useEffect(() => setKeys(shortcutLabel()), []);
  return (
    <div className="sidebar-actions">
      <button type="button" className="row nav-link sidebar-search" onClick={() => setOpen(true)} aria-keyshortcuts="Meta+K Control+K">
        <IconSearch className="nav-icon" />
        <span className="nav-label">Search</span>
        <Kbd>{keys}</Kbd>
      </button>
      <ShellLink href={NEW_CHAT_HREF} pending className="row nav-link sidebar-new-chat">
        <IconNewChat className="nav-icon" />
        <span className="nav-label">New chat</span>
      </ShellLink>
      {canTask ? (
        // A TASK IS MADE FROM ANY PAGE (founders, 22 Oct 2026): the one form, grown from
        // this row. Drawn only where a task can be made (NewTaskProvider canMakeTasks).
        <button type="button" className="row nav-link sidebar-new-task" aria-haspopup="dialog" onClick={(event) => openNewTask({ origin: event.currentTarget })}>
          <IconAdd className="nav-icon" />
          <span className="nav-label">New task</span>
        </button>
      ) : null}
    </div>
  );
}

function NavRow({ item, pathname, count = null }) {
  const Icon = item.icon;
  const current = item.href ? currentOf(pathname, item.href) : undefined;
  const section = item.href ? sectionOf(pathname, item.href) : false;
  if (item.event) {
    return (
      <li>
        <button type="button" className="row nav-link" onClick={() => window.dispatchEvent(new Event(item.event))}>
          <Icon className="nav-icon" />
          <span className="nav-label">{item.label}</span>
        </button>
      </li>
    );
  }
  return (
    <li>
      <ShellLink href={item.href} pending className="row nav-link" aria-current={current} data-nav-section={section ? "current" : undefined}>
        <Icon className="nav-icon" />
        <span className="nav-label">{item.label}</span>
        {count != null ? (
          // The badge's accessible name says what it counts (checklist U53).
          <span className="nav-count num" data-nav-count={count}>
            <span aria-hidden="true">{count}</span>
            <span className="sr-only">, {count} {COUNTERS[item.counter].words(count)}</span>
          </span>
        ) : null}
      </ShellLink>
    </li>
  );
}

export default function Sidebar({ shell = EMPTY_SHELL, signedInAs = null, pathname: forcedPath, id = "sidebar", onClose }) {
  const livePath = usePathname();
  const pathname = forcedPath ?? livePath ?? "";
  // The open conversation's row says what its header says (thread-word.js).
  const words = useThreadWords();
  const conversations = withThreadWords(shell.conversations, words);
  const inFirm = canSwitch(signedInAs);
  const firmMode = inFirm && isFirmMode(pathname);
  const nav = inFirm ? [...NAV, ...FIRM_NAV] : NAV;

  return (
    <aside className="sidebar" id={id} aria-label="Sidebar" data-mode={firmMode ? "firm" : "client"}>
      <div className="sidebar-head">
        <ShellLink href={MONTH_END_HREF} className="sidebar-brand">
          <Wordmark className="wordmark" />
        </ShellLink>
        <IconButton label="Close the sidebar" onClick={onClose} className="sidebar-close">
          <IconClose />
        </IconButton>
      </div>

      <SidebarActions firmMode={firmMode} />

      {firmMode ? (
        // The firm's own places (DA2-043). No client, no month, no conversations: none of
        // them is what this view is about.
        <nav className="sidebar-nav sidebar-firm" aria-labelledby="sidebar-firm-heading">
          <p className="sidebar-label sidebar-firm-label" id="sidebar-firm-heading">
            Firm
          </p>
          <ul>
            {FIRM_PLACES.map((item) => (
              <NavRow key={item.label} item={{ ...item, event: item.event === "people" ? OPEN_PEOPLE_EVENT : undefined }} pathname={pathname} />
            ))}
          </ul>
        </nav>
      ) : (
        <>
          {shell.client || shell.period ? (
            <div className="sidebar-client">
              <ClientSwitcher
                client={shell.client}
                period={shell.period}
                periodLabel={shell.periodLabel}
                months={shell.months}
                pathname={pathname}
                current={shell.clientId || null}
                firm={inFirm}
              />
            </div>
          ) : null}

          <nav className="sidebar-nav" aria-label="Primary">
            <ul>
              {nav.map((item) => (
                <NavRow key={item.href} item={item} pathname={pathname} count={navCount(item, shell)} />
              ))}
              {/* The rule, then Connections (scheduled-spec.md's sidebar). */}
              <li className="nav-rule" aria-hidden="true" />
              {NAV_AFTER_RULE.map((item) => (
                <NavRow key={item.href} item={item} pathname={pathname} count={navCount(item, shell)} />
              ))}
            </ul>
          </nav>

          <div className="sidebar-scroll scroll-edges">
            <ConversationList conversations={conversations} replayed={shell.replayed} pathname={pathname} />
          </div>
          <BackgroundNotice conversations={conversations} pathname={pathname} />
        </>
      )}

      {firmMode ? <div className="sidebar-spacer" aria-hidden="true" /> : null}
      <AccountMenu signedInAs={signedInAs} business={shell.client} />
    </aside>
  );
}
