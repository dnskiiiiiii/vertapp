"use client";

// components/shell/CommandMenu.js — ⌘K: JUMP ANYWHERE, START ANYTHING
// ==============================================================================
// Founder decision D6 (10 Oct 2026); design-fix-2 spec §6.2; audit DA2-041. The behaviour
// (the key, the sources, what an item does, focus return) is CommandMenuProvider.js; this
// file is how it looks and how the keyboard moves through it.
//
//   ┌──────────────────────────────────────────────┐
//   │ 🔍 Search clients, tasks and conversations…   │  48 px, callout 16/400
//   ├──────────────────────────────────────────────┤
//   │ Actions                                       │  footnote 500, tertiary ink
//   │ ✎ New chat                                    │  40 px rows, radius --r-inner
//   │ ▣ Go to Month-end                             │
//   │ Conversations                                 │
//   │ ◯ Bank reconciliation                    4m   │  meta: caption, tertiary ink
//   ├──────────────────────────────────────────────┤
//   │ ↑↓ Move   ↵ Open   Esc Close                  │  36 px footer, <kbd> chips
//   └──────────────────────────────────────────────┘
//
// THE SELECTED ROW IS THE HOVER FILL, NEVER THE ACCENT (spec §2.2): green means "this
// writes", and moving through a list writes nothing.
//
// cmdk draws the dialog (a Radix dialog: focus is trapped inside while open, the page
// behind is hidden from assistive tech, Esc closes, focus returns to the opener) and the
// list's keyboard model (↑↓, Home/End, ↵). The FILTERING is ours (`shouldFilter={false}`),
// for three reasons: every query word must match (cmdk's fuzzy score lets "bank rec" match
// "Balance sheet roll-forward"); the matched characters are drawn 600, which needs to
// know where the match is; and "No matches" must be decided on the real list, not on
// the always-present "Ask Vert" row.
//
// Desk: 35rem of glass, 16vh from the top, centred over the main panel. Phone (< 1024 px):
// a full-width sheet from the top. Opens with opacity and a .98 → 1 scale from its top
// centre on the snappy spring (a transition with @starting-style, never a keyframe);
// reduced motion cross-fades.

import { Command } from "cmdk";
import { useMemo, useState } from "react";

import { KbdHints, SkeletonBlock } from "@/components/ui/marks";
import {
  IconCalendar,
  IconChat,
  IconClients,
  IconConnections,
  IconMonthEnd,
  IconNewChat,
  IconPeople,
  IconPlan,
  IconSearch,
} from "@/components/ui/icons";

import { useCommandMenu, useCommandSources } from "./command";
import "./command.css";

const ICONS = {
  chat: IconChat,
  "new-chat": IconNewChat,
  "month-end": IconMonthEnd,
  clients: IconClients,
  connections: IconConnections,
  people: IconPeople,
  client: IconClients,
  month: IconCalendar,
  conversation: IconChat,
  task: IconPlan,
};

export const PLACEHOLDER = "Search clients, tasks and conversations…";
const HINTS = [
  { keys: ["↑", "↓"], label: "Move" },
  { keys: ["↵"], label: "Open" },
  { keys: ["Esc"], label: "Close" },
];

/** The words of the query, lower case. */
function wordsOf(query) {
  return String(query || "").toLowerCase().split(/\s+/).filter(Boolean);
}

/** Does an item match every word of the query? Its label, keywords and meta are searched. */
export function matches(item, words) {
  if (!words.length) return true;
  const hay = [item.label, ...(item.keywords || []), item.meta || ""].join(" ").toLowerCase();
  return words.every((w) => hay.includes(w));
}

/**
 * The label with the query's words drawn 600 where they occur (spec §6.2: "matched
 * characters 600"). Returns an array of strings and <mark>s; overlapping words merge.
 */
export function highlight(label, words) {
  const text = String(label || "");
  if (!words.length) return [text];
  const lower = text.toLowerCase();
  const hits = new Array(text.length).fill(false);
  for (const w of words) {
    let at = lower.indexOf(w);
    while (at !== -1) {
      for (let i = at; i < at + w.length; i++) hits[i] = true;
      at = lower.indexOf(w, at + w.length);
    }
  }
  const out = [];
  let run = "";
  let marked = hits[0];
  for (let i = 0; i <= text.length; i++) {
    if (i === text.length || hits[i] !== marked) {
      if (run) out.push(marked ? <mark key={i}>{run}</mark> : run);
      run = "";
      marked = hits[i];
    }
    if (i < text.length) run += text[i];
  }
  return out;
}

/**
 * How well an item answers the query: 3 when its label starts with the whole query, 2
 * when the label holds it, 1 when every word is in the label, 0 when only its keywords
 * or meta match. A comparison of positions, never a figure shown to anyone.
 */
export function matchScore(item, query) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return 0;
  const label = String(item.label || "").toLowerCase();
  if (label.startsWith(q)) return 3;
  if (label.includes(q)) return 2;
  return wordsOf(q).every((w) => label.includes(w)) ? 1 : 0;
}

/** The heading of the trailing group that holds "Ask Vert" while something else matches. */
export const ASK_GROUP = "Ask";

/**
 * The groups as shown: filtered by the query, "New chat" folded into "Ask Vert" while typing.
 *
 * THE BEST MATCH IS FIRST, SO ↵ GOES THERE (critic r1: typing "Fixed" and ↵ opened a new
 * chat, because "Ask Vert “Fixed”" led the list over the conversation of that name). With
 * anything matched, the groups are ordered by their best match (ties keep the source
 * order: Actions, Clients, Months, Conversations, Tasks), each group's rows likewise, and
 * "Ask Vert" moves to a last group of its own. Only when nothing matches is "Ask Vert"
 * the first, and only, row.
 */
export function visibleGroups(groups, query, { loading = false } = {}) {
  const words = wordsOf(query);
  let ask = null;
  const matched = groups
    .map((g, order) => ({
      ...g,
      order,
      items: g.items.filter((item) => {
        if (item.id === "ask") {
          // WHILE THE CLIENTS READ, ASK VERT CANNOT BE CHOSEN (verify pass 10 S-E2E-3):
          // it was the only row, so cmdk selected it, and ↵ on "Stresslab" posted a live
          // question instead of opening that client. Drawn, but disabled until the read.
          ask = loading ? { ...item, disabled: true } : item;
          return false;
        }
        if (item.id === "new-chat" && words.length) return false;
        return matches(item, words);
      }),
    }))
    .filter((g) => g.items.length);
  if (!words.length) return matched.map(({ order, ...g }) => g);
  const ranked = matched
    .map((g) => {
      const items = g.items
        .map((item, i) => ({ item, i, score: matchScore(item, query) }))
        .sort((a, b) => b.score - a.score || a.i - b.i);
      return { ...g, items: items.map((x) => x.item), best: items.length ? items[0].score : 0 };
    })
    .sort((a, b) => b.best - a.best || a.order - b.order)
    .map(({ order, best, ...g }) => g);
  if (!ask) return ranked;
  if (!ranked.length) return [{ group: "Actions", items: [ask] }];
  return [...ranked, { group: ASK_GROUP, items: [ask] }];
}

function Row({ item, words, onSelect }) {
  const Icon = ICONS[item.icon] || IconChat;
  return (
    <Command.Item value={item.id} disabled={Boolean(item.disabled)} onSelect={() => onSelect(item)} className="cmdk-row" data-group={item.group}>
      <Icon size={16} className="cmdk-row-icon" />
      {/* The whole label on hover, since a long one is cut (verify pass 1 S-UI-3). */}
      <span className="cmdk-row-label" translate={item.group === "Clients" ? "no" : undefined} title={typeof item.label === "string" ? item.label : undefined}>
        {item.id === "ask" ? item.label : highlight(item.label, words)}
      </span>
      {item.meta ? <span className="cmdk-row-meta">{item.meta}</span> : null}
    </Command.Item>
  );
}

export default function CommandMenu() {
  const { open, setOpen, query, setQuery, perform, problem } = useCommandMenu();
  const [full, setFull] = useState([]);
  const fullList = useMemo(() => full, [full]);
  const { groups, loading } = useCommandSources({ full: fullList });
  const shown = visibleGroups(groups, query, { loading });
  const words = wordsOf(query);
  const q = query.trim();
  // "No matches" is decided on the read list: while the sources are still reading, the
  // skeleton rows say so and the sentence would be a guess (round 2: it showed over a
  // conversation that had not arrived yet).
  const onlyAsk = q && !loading && shown.every((g) => g.items.every((i) => i.id === "ask"));

  return (
    <Command.Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) setFull([]);
      }}
      label="Command menu"
      shouldFilter={false}
      loop
      overlayClassName="cmdk-scrim"
      contentClassName="cmdk-dialog"
    >
      <div className="cmdk-input-row">
        <IconSearch className="cmdk-input-icon" />
        <Command.Input
          value={query}
          onValueChange={setQuery}
          placeholder={PLACEHOLDER}
          className="cmdk-input"
          name="command"
          autoComplete="off"
          spellCheck={false}
        />
      </div>
      <Command.List className="cmdk-list">
        {onlyAsk ? (
          <p className="cmdk-empty" role="status">
            No matches for “{q}”.
          </p>
        ) : null}
        {shown.map((g) => {
          const capped = !q && g.count > g.items.length;
          return (
            <Command.Group key={g.group} heading={g.group} className="cmdk-group">
              {g.items.map((item) => (
                // cmdk picks a first row only when a row mounts: the Ask row that becomes
                // choosable remounts, so with nothing else matched it is selected again.
                <Row key={item.disabled ? `${item.id}:wait` : item.id} item={item} words={words} onSelect={perform} />
              ))}
              {capped ? (
                <Command.Item value={`show-all:${g.group}`} onSelect={() => setFull((f) => [...f, g.group])} className="cmdk-row cmdk-show-all">
                  <span className="cmdk-row-label">Show all {g.count}</span>
                </Command.Item>
              ) : null}
            </Command.Group>
          );
        })}
        {/* Still reading: the shape of the rows to come (DA2-078's rule), never a
            sentence. The words are for assistive tech. */}
        {loading ? (
          <div className="cmdk-loading" role="status">
            <span className="sr-only">Reading your clients</span>
            {[0, 1].map((i) => (
              <span key={i} className="cmdk-skeleton-row" aria-hidden="true">
                <SkeletonBlock width="1rem" height="1rem" radius="var(--r-xs)" />
                <SkeletonBlock width={i ? "7rem" : "10rem"} height="0.75rem" />
              </span>
            ))}
          </div>
        ) : null}
      </Command.List>
      {problem ? (
        <p className="cmdk-problem" role="alert">
          {problem}
        </p>
      ) : null}
      <div className="cmdk-foot">
        <KbdHints hints={HINTS} />
      </div>
    </Command.Dialog>
  );
}
