"use client";

import { Button } from "@/components/ui/Button";

// components/shell/ServiceUnavailable.js — A STATED OUTCOME AND A WAY ON
// ==============================================================================
// What a panel renders in place of itself when the service behind it did not answer.
// It exists because the alternative was on the deployed settings page on 2026-08-17,
// in a paragraph a customer was expected to act on: "The sync worker answered HTTP 500
// with no error envelope, so something other than the worker is on that address."
// Every word of that is true and none of it is addressed to the person reading it. It
// names an internal component, quotes a status code, describes a deployment topology,
// and does not say what happened to their books or what to do next.
//
// So this states three things and offers one control:
//
//   1. WHAT WAS BEING ASKED, in the caller's words — "the accounts in your ledger
//      could not be listed", not the route that failed.
//   2. WHAT IT MEANS FOR THEIR DATA. Almost always "nothing has changed", and saying
//      so is the fact that stops a person re-pressing a destructive control.
//   3. A RETRY. A transport failure is the one class of error where trying again is a
//      reasonable first move, and a screen that refuses without offering it makes a
//      person reload the page to find out.
//
// IT IS NOT components/shell/DataSourceDown.js, AND THAT IS THE ONLY REASON THERE ARE
// TWO. DataSourceDown is the same idea one level up and is deliberately the WHOLE page
// — no rail, no register, nothing that would still be making a claim about the close —
// which is right when the engine payload cannot be read and wrong for one panel on a
// working page. This is that component's card, sized for a section, with the retry it
// has no use for. The wording rules above are its rules.
//
// The service's own sentence still has a home: a REFUSAL the service worded — "no
// QuickBooks connection yet" — is not this component's business and is rendered as
// ordinary text by the caller. This is for the case where nothing answered at all.

// `alternative` is the fourth thing, added 2026-08-20, and it is the one that turns a
// stated outage into a way forward. A retry is only a reasonable first move while the
// failure might be transient; when it is not — and the bank-account listing on a live
// tenant was not, three presses running — a card offering nothing but Retry is a dead
// end wearing a control. Where another route to the same goal exists, it is named
// here. Optional, because most outages genuinely have no second route and inventing
// one would be worse than admitting the wait.
export default function ServiceUnavailable({ title, body, alternative = null, onRetry, retrying = false }) {
  // Spacing comes from `.service-unavailable` (kit.css), not inline styles (UI-044), and
  // the retry is the kit's button: busy while it runs, never a native `disabled` that
  // swallows the press silently (UI-012, UI-014).
  return (
    <div className="verify blocked service-unavailable" role="alert">
      <div>
        <div className="v-title">{title}</div>
        <div className="v-body">{body}</div>
        {alternative && <div className="v-body">{alternative}</div>}
        {onRetry && (
          <Button variant="secondary" size="sm" onClick={onRetry} busy={retrying} busyLabel="Trying again…">
            Try again
          </Button>
        )}
      </div>
    </div>
  );
}
