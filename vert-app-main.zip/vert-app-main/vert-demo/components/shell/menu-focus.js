// components/shell/menu-focus.js — A MENU THAT OPENS TAKES THE FOCUS
// ==============================================================================
// ui-pass-1 output-ui #24 (U36, a blocker): the account menu and the client switcher
// opened with focus left on their toggle. A keyboard person pressed Enter, saw the menu
// appear, and their next Tab walked on past it into the page — the menu was on screen
// and out of reach. Esc already closed both and returned focus to the toggle; this is
// the other half: on open, focus moves to the first thing in the menu a person can use
// (or the one marked current, so the switcher lands on the client you are on).
//
// Plain DOM and no React, so the same function is what the components call and what
// tests/shell-u1.test.js runs in Chrome.

/** What can take focus inside a menu. */
export const MENU_FOCUSABLE =
  'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

/**
 * Move focus into `container`: the element matching `prefer` when there is one, else the
 * first focusable that is laid out (a `hidden` subtree has no boxes). Returns the element
 * focused, or null when there was nothing to focus (focus is then left where it was).
 */
export function focusIntoMenu(container, prefer = null) {
  if (!container || typeof container.querySelectorAll !== "function") return null;
  const shown = (el) => typeof el.getClientRects !== "function" || el.getClientRects().length > 0;
  const preferred = prefer ? Array.from(container.querySelectorAll(prefer)).find((el) => el.matches(MENU_FOCUSABLE) && shown(el)) : null;
  const target = preferred || Array.from(container.querySelectorAll(MENU_FOCUSABLE)).find(shown) || null;
  if (target) target.focus();
  return target;
}

/**
 * A MENU CLOSES WHEN FOCUS LEAVES IT (design-fix-2 DA2-014). The account menu and the
 * client switcher stayed drawn while Tab walked on into the page behind them, so the
 * keyboard was in one place and the eye in another. `focusout` from inside `root` to an
 * element outside it closes the menu and gives focus to its trigger, which is where a
 * person who pressed Tab past the last item expects to be standing. A focusout with no
 * `relatedTarget` (a press on the page, the window losing focus) only closes: the
 * pointer handler owns that case and focus is already wherever the press put it.
 *
 * Returns the listener's undo. Plain DOM, like `focusIntoMenu`.
 */
export function closeOnFocusOut(root, close, trigger = null) {
  if (!root || typeof root.addEventListener !== "function") return () => {};
  function onFocusOut(event) {
    const next = event.relatedTarget;
    if (!next || root.contains(next)) return;
    close();
    // Tabbing on from the trigger itself just closes: focus is going where it was sent.
    if (event.target === trigger) return;
    if (trigger && typeof trigger.focus === "function") trigger.focus();
  }
  root.addEventListener("focusout", onFocusOut);
  return () => root.removeEventListener("focusout", onFocusOut);
}
