"use client";

// components/shell/ConversationList.js — THIS MONTH'S CONVERSATIONS
// ==============================================================================
// Spec §2.1 and §4.5. Not navigation: a list of the work under way, needs-you first,
// that scrolls on its own inside the sidebar. There is no "New chat" (the ask box
// starts one), no "Show all" and no index page.
//
// Each row is the conversation's title and, when decisions wait in it, their count, right
// -aligned and tabular in the tertiary ink (design-fix-2 DA2-057). There are no status
// dots: seven amber dots down the list said "needs you" seven times and pushed every title
// four pixels off the edge the rest of the sidebar sits on. The status word is still on
// the row for assistive tech, and a row that waits on nobody steps back to the secondary
// ink. The order comes from the reader (components/shell/shell-data.js) and is not
// re-sorted here.
//
// The AGE ("4m") shows only when it says something: a row with no count shows it unless
// it is "now", and every row shows it on hover or focus, in the count's place.
//
// A replayed list (the static build's recordings) says so once, in the heading's
// caption, so nobody reads a sample as their own client's work (spec §9.5).
//
// WHAT SHOWS AND WHAT FOLDS (eval iter 1 round 2, S2/S4). Only the work under way and
// the few most recent sit on the surface; the rest of the month is one press down,
// behind "Earlier · N" (components/shell/conversation-groups.js has the rule and why).
// The folded rows are in a Disclosure, hidden once closed, so their words are not on
// the screen until they are asked for.
//
// The label is a label, not a heading: a 12 px heading over 14 px rows inverted the
// scale (A3). The section is still named by it for assistive tech.

import { useEffect, useState } from "react";

import ShellLink from "./ShellLink";

import { Disclosure } from "@/components/ui/Disclosure";

import { ageLabel, ageWords } from "./age";
import { decisionCount, groupConversations } from "./conversation-groups";

// The clock the ages are read against. It starts unset, so the server's render and the
// first client render agree (no ages), then ticks each minute once mounted; an age drawn
// from the server's clock would be stale by the time it is read.
function useNow() {
  const [now, setNow] = useState(null);
  useEffect(() => {
    setNow(Date.now());
    const t = setInterval(() => setNow(Date.now()), 60 * 1000);
    return () => clearInterval(t);
  }, []);
  return now;
}

function Rows({ list, pathname, now }) {
  return (
    <ul className="conv-list">
      {list.map((c) => {
        const current = pathname === c.href;
        const age = now === null ? null : ageLabel(c.updatedAt, now);
        const count = decisionCount(c);
        return (
          <li key={c.id}>
            <ShellLink
              href={c.href}
              pending
              className="row conv-row"
              aria-current={current ? "page" : undefined}
              data-status={c.status === "Needs you" ? "needs-you" : c.status === "Vert's working" ? "working" : "quiet"}
              data-age-now={age === "now" ? "true" : undefined}
            >
              <span className="conv-title" title={c.title}>{c.title}</span>
              <span className="sr-only">, {c.status}</span>
              {count ? (
                <span className="conv-count num">
                  <span aria-hidden="true">{count}</span>
                  <span className="sr-only">{count === 1 ? ", 1 decision" : `, ${count} decisions`}</span>
                </span>
              ) : null}
              {age ? (
                <span className="conv-age num" data-with-count={count ? "true" : undefined}>
                  <span aria-hidden="true">{age}</span>
                  <span className="sr-only">, {ageWords(age)}</span>
                </span>
              ) : null}
            </ShellLink>
          </li>
        );
      })}
    </ul>
  );
}

export default function ConversationList({ conversations = [], replayed = false, pathname = "" }) {
  const { now: recent, earlier } = groupConversations(conversations, { current: pathname });
  const now = useNow();
  return (
    <section className="conversations" aria-labelledby="conversations-heading">
      <p className="sidebar-label" id="conversations-heading">
        Conversations
      </p>
      {replayed ? <p className="sidebar-caption">Samples, replayed. Not your books.</p> : null}
      {conversations.length ? (
        <>
          {recent.length ? <Rows list={recent} pathname={pathname} now={now} /> : null}
          {earlier.length ? (
            <Disclosure summary={`Earlier · ${earlier.length}`} className="conv-earlier">
              <Rows list={earlier} pathname={pathname} now={now} />
            </Disclosure>
          ) : null}
        </>
      ) : (
        <p className="sidebar-caption">None yet this month.</p>
      )}
    </section>
  );
}
