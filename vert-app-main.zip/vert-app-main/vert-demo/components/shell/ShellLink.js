"use client";

// components/shell/ShellLink.js — A SIDEBAR LINK THAT PREFETCHES ON INTENT, NOT ON SIGHT
// ==============================================================================
// Every page draws the sidebar, and next/link prefetches every link it can see. Each
// page load fired about eight RSC reads of conversations nobody was opening, twice
// (eval iter 1 round 3, performance: 'load 9082 ms at /records'), against a service
// that renders each one live. Those reads competed with the page itself and kept the
// network busy for seconds after the page had drawn.
//
// So the sidebar prefetches a link when a pointer rests on it or focus reaches it:
// the moment someone shows intent, a few hundred milliseconds before the press, which
// is when a prefetch pays for itself.
//
// THE PRESS IS ANSWERED ON THE ROW (design-fix-2 DA2-030). With the service slow, a
// press on a conversation left the old page unchanged for seconds and only the row's
// grey said anything had happened. `pending` puts a 12 px turning ring at the row's
// trailing edge while the route loads (next/link's `useLinkStatus`), in the tertiary
// ink: it is a wait, not a status. The top bar (NavProgress.js) says the same thing for
// the whole page after 150 ms.

import Link, * as nextLink from "next/link";
import { useRouter } from "next/navigation";

import { IconSpinner } from "@/components/ui/icons";

// `useLinkStatus` is next/link's (Next 15.3+). Read off the module so a build or a test
// stand-in without it draws no ring rather than failing to load.
const NO_STATUS = { pending: false };
const useLinkStatus = typeof nextLink.useLinkStatus === "function" ? nextLink.useLinkStatus : () => NO_STATUS;

/** The row's pending ring: rendered inside the Link, so it reads that link's status. */
function PendingMark() {
  const { pending } = useLinkStatus();
  if (!pending) return null;
  return (
    <span className="link-pending" aria-hidden="true">
      <IconSpinner size={12} />
    </span>
  );
}

export default function ShellLink({ href, onMouseEnter, onFocus, pending = false, children, ...rest }) {
  const router = useRouter();
  function warm() {
    try {
      router.prefetch(href);
    } catch {
      // A prefetch is an optimisation; the press still navigates without one.
    }
  }
  return (
    <Link
      href={href}
      prefetch={false}
      onMouseEnter={(event) => {
        warm();
        if (onMouseEnter) onMouseEnter(event);
      }}
      onFocus={(event) => {
        warm();
        if (onFocus) onFocus(event);
      }}
      {...rest}
    >
      {children}
      {pending ? <PendingMark /> : null}
    </Link>
  );
}
