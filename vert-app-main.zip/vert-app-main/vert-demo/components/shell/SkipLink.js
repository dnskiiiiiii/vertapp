// components/shell/SkipLink.js — THE FIRST TAB STOP ON EVERY PAGE
// ==============================================================================
// Spec §2.1; audit UI-055: every route's first seven Tab stops used to be the logo,
// five nav items and Sign out, before any content. This is first in the document, so
// it is the first thing Tab reaches; it is off-screen until focused, then appears at
// the top-left in the float material. The target is <main id="main" tabIndex={-1}>.

export const MAIN_ID = "main";

export default function SkipLink() {
  return (
    <a className="skip-link" href={`#${MAIN_ID}`}>
      Skip to main content
    </a>
  );
}
