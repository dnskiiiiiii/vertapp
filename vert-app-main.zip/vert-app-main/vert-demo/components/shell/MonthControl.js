"use client";

// components/shell/MonthControl.js — THE VISIBLE MONTH, AND THE TWO RULES AROUND IT
// ==============================================================================
// Spec §2.2. One month is visible at a time; it scopes Month-end, Records and the
// conversation list. Three things live here:
//
//   chooseMonth       what choosing a month does; the choice itself is a section of the
//                     sidebar's switcher popover (ClientSwitcher.js), offered only when
//                     the engine has more than one month.
//   SetVisibleMonth   rendered by a conversation page: opening a conversation SETS the
//                     visible month to that conversation's month, so the sidebar never
//                     says October over September's figures.
//   LeftChatNotice    switching month INSIDE a conversation leaves it: Vert goes to
//                     that month's Month-end and says "This chat is about September.
//                     Open it ›", so the switch is never silent and never strands the
//                     conversation.
//
// The choice is one cookie (lib/period.js MONTH_COOKIE), read by the layout on the
// server so the next render fetches the right month's badge and list.

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

import { MONTH_COOKIE, monthName } from "@/lib/period";
import { Notice } from "@/components/ui/Notice";
import { useCommandMenu } from "./command/CommandMenuProvider";

import { IconCaretRight } from "@/components/ui/icons";
const LEFT_CHAT_KEY = "vert:left-chat";

function readMonthCookie() {
  const hit = document.cookie.split("; ").find((c) => c.startsWith(`${MONTH_COOKIE}=`));
  return hit ? decodeURIComponent(hit.slice(MONTH_COOKIE.length + 1)) : null;
}

function writeMonthCookie(period) {
  // A year: the month you were last looking at is still the one you want next week.
  document.cookie = `${MONTH_COOKIE}=${encodeURIComponent(period)}; path=/; max-age=31536000; samesite=lax`;
}

function inConversation(pathname) {
  return typeof pathname === "string" && pathname.startsWith("/chat/");
}

/**
 * Show another month (design-fix-2 DA2-057: the choice now lives in the sidebar's one
 * switcher row, ClientSwitcher.js, beside the client). Writes the cookie; inside a
 * conversation it leaves for that month's Month-end and remembers the way back, so the
 * switch is never silent and never strands the conversation.
 */
export function chooseMonth({ next, period, pathname, router }) {
  if (!next || next === period) return;
  writeMonthCookie(next);
  if (inConversation(pathname)) {
    try {
      sessionStorage.setItem(LEFT_CHAT_KEY, JSON.stringify({ href: pathname, period }));
    } catch {
      // Private browsing can refuse storage. The switch still happens; only the
      // "Open it" way back is lost, and nothing is claimed that is not true.
    }
    router.push("/");
  }
  router.refresh();
}

/**
 * What opening a conversation of `period` does, given the cookie and the month the shell
 * is DRAWN with (verify pass 5, F-14). Pure.
 *
 *   write     the cookie names another month: write `period`
 *   refresh   the shell on screen names another month: re-render it once
 *
 * THE SHELL ON SCREEN DECIDES THE REFRESH, NOT THE COOKIE. The proxy now writes a task
 * conversation's month before the page is drawn (proxy.js), so the cookie already says
 * July while a layout kept from an in-app navigation still says September: deciding by
 * the cookie alone would never refresh and the bar would keep the wrong month. Deciding
 * by the cookie was also the old defect's other half: a cookie that already named the
 * month, over a shell drawn before it did, skipped the refresh the bar needed.
 */
export function visibleMonthSteps({ period, cookie, shown }) {
  if (typeof period !== "string" || !/^\d{4}-(0[1-9]|1[0-2])$/.test(period)) return { write: false, refresh: false };
  return { write: cookie !== period, refresh: shown !== period };
}

/**
 * Render inside a conversation with that conversation's month. Makes it the visible
 * month if it is not already, then refreshes so the sidebar follows. Renders nothing.
 * One refresh per month at most: a month the shell cannot show (not offered) must not
 * loop the page through refreshes.
 */
export function SetVisibleMonth({ period }) {
  const router = useRouter();
  const { shell } = useCommandMenu();
  const shown = shell ? shell.period || null : undefined;
  const refreshed = useRef(null);
  useEffect(() => {
    const steps = visibleMonthSteps({ period, cookie: readMonthCookie(), shown: shown === undefined ? period : shown });
    if (steps.write) writeMonthCookie(period);
    // Outside the shell (no provider) the cookie write is the whole of it, as before.
    if ((steps.refresh || (steps.write && shown === undefined)) && refreshed.current !== period) {
      refreshed.current = period;
      router.refresh();
    }
  }, [period, shown, router]);
  return null;
}

/** "This chat is about September. Open it ›" on Month-end, after a switch left a chat. */
export function LeftChatNotice() {
  const pathname = usePathname();
  const [left, setLeft] = useState(null);

  useEffect(() => {
    if (pathname !== "/") {
      setLeft(null);
      return;
    }
    try {
      const raw = sessionStorage.getItem(LEFT_CHAT_KEY);
      setLeft(raw ? JSON.parse(raw) : null);
    } catch {
      setLeft(null);
    }
  }, [pathname]);

  if (!left || !left.href || !left.period) return null;

  function forget() {
    try {
      sessionStorage.removeItem(LEFT_CHAT_KEY);
    } catch {
      // Nothing to forget if storage was refused.
    }
    setLeft(null);
  }

  function reopen() {
    // Going back to the chat makes its month visible again (SetVisibleMonth).
    forget();
  }

  return (
    <Notice
      kind="status"
      className="left-chat-notice"
      onDismiss={forget}
      action={
        <Link href={left.href} className="link" onClick={reopen}>
          Open it<IconCaretRight className="caret-trailing" />
        </Link>
      }
    >
      This chat is about {monthName(left.period)}.
    </Notice>
  );
}

/**
 * The month the server worked out for a browser that had chosen none (lib/session.js
 * visibleMonth → lib/period.js workedMonth; verify pass 3 S-E2E-4 F17), kept as this
 * browser's choice once it is on screen. Working it out costs a month read or two, so
 * it is done once per browser, not on every page. Writes only when no choice is
 * stored, never over one, and refreshes nothing: the page already shows this month.
 */
export function RememberShownMonth({ period }) {
  useEffect(() => {
    if (typeof period !== "string" || !/^\d{4}-(0[1-9]|1[0-2])$/.test(period)) return;
    try {
      if (readMonthCookie()) return;
      writeMonthCookie(period);
    } catch {
      // A refused cookie only means the month is worked out again next time.
    }
  }, [period]);
  return null;
}
