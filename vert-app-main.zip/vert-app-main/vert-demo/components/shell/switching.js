"use client";

// components/shell/switching.js — A CLIENT SWITCH SAYS IT IS HAPPENING (verify pass 1 S-E2E-3)
// ==============================================================================
// cmd-K and the switcher proved the switch, closed, and asked for Month-end: on a slow
// close the old client's figures then stood on screen for about 14 s with nothing to say a
// different client was on its way, and they could still be pressed. Now the switch is
// announced the moment it is proven: the page column is marked busy (dimmed, not
// pressable) under one status line, "Opening Harbour…", until the new client's page loads
// (a document load, goToSwitchedClient below) or the shell names another client.

import { useCallback, useEffect, useRef, useState } from "react";

export const SWITCHING_EVENT = "vert:switching";

function announce(detail) {
  try {
    window.dispatchEvent(new CustomEvent(SWITCHING_EVENT, { detail }));
  } catch {
    // No window (a test render): nothing to announce to.
  }
}

/**
 * Land on the new client's Month-end: ONE document load, nothing queued behind it.
 *
 * WHY NOT router.push("/") + router.refresh() (verify pass 5, S-E2E-3 F12). The switch is
 * a Server Action that writes the client and month cookies, and Next re-renders the
 * route an action ran on whenever it writes a cookie. The push and the refresh were then
 * queued behind that re-render in the router's one action queue, three renders of the
 * heaviest page there is under the new client, and when the palette closed on "/" the
 * push was to the URL already on screen. 2 of 16 cmd-K switches sat on "Opening Fresh
 * Start Co…" over 6 s with the old client's sidebar. A client switch replaces every
 * figure on screen, so it is a document load: it cannot wait on a queue, and it drops
 * the router's cache of the previous client's pages, which a Back press could otherwise
 * have drawn under the new client's name. The status line stands until the page goes.
 */
export function goToSwitchedClient(win = typeof window === "undefined" ? null : window) {
  if (win && win.location && typeof win.location.assign === "function") win.location.assign("/");
}

/** `open(name)`: announce the switch to `name`, then load the new client's Month-end. */
export function useOpenSwitchedClient() {
  return useCallback((name) => {
    announce({ state: "start", name: typeof name === "string" && name.trim() ? name.trim() : null });
    goToSwitchedClient();
  }, []);
}

/** The words while a switch is under way. Pure. */
export function switchingWords(name) {
  return name ? `Opening ${name}…` : "Opening that client…";
}

/**
 * The status line, and the busy mark on the page column (`data-switching` on
 * `.shell-main`, styled in shell.css). Clears when the switch ends or when the shell
 * names a different client than the one it named when the switch began.
 */
export function SwitchingNotice({ clientId = null }) {
  const [switching, setSwitching] = useState(null);
  const from = useRef(clientId);
  useEffect(() => {
    function on(event) {
      const d = event && event.detail ? event.detail : {};
      if (d.state === "start") {
        from.current = clientId;
        setSwitching({ name: d.name || null });
      } else if (d.state === "end") setSwitching(null);
    }
    window.addEventListener(SWITCHING_EVENT, on);
    return () => window.removeEventListener(SWITCHING_EVENT, on);
  }, [clientId]);
  useEffect(() => {
    if (switching && clientId !== from.current) setSwitching(null);
  }, [clientId, switching]);
  useEffect(() => {
    const main = document.querySelector(".shell-main");
    if (!main) return undefined;
    if (switching) main.setAttribute("data-switching", "true");
    else main.removeAttribute("data-switching");
    return () => main.removeAttribute("data-switching");
  }, [switching]);
  return (
    <p className="switching-notice" role="status" aria-live="polite" hidden={!switching}>
      {switching ? switchingWords(switching.name) : null}
    </p>
  );
}
