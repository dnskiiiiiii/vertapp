// components/reports/customer-statement.js — A CUSTOMER'S STATEMENT, READ FROM THE ENGINE
// ==============================================================================
// Function-fidelity audit row 20 (w46, 4 Nov 2026). The engine sends one customer's
// statement (vert_engine/customer_statement.py shape_of; contract model
// agent_events.ShapeCustomerStatement): outstanding as at a day, or activity over a
// period, each line with its running balance, the closing balance, the ageing strip
// (Current, 1–30, 31–60, 61–90, over 90 days, and unapplied credit) and the check of
// the closing balance against the customer's total in aged receivables.
//
// A lookup only: every amount is the engine's integer, shown as sent; nothing is summed,
// netted or signed here. The tie is "tied" only on the engine's `tied: true`; a tie not
// checked is the engine's words. An unread statement carries no balance. A block that
// doesn't read as the contract says is dropped whole.
//
// It imports nothing.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const int = (v) => (Number.isInteger(v) ? v : null);
const count = (v) => (Number.isInteger(v) && v >= 0 ? v : null);
const bool = (v) => (v === true ? true : v === false ? false : null);
const ISO_DAY = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
const CONTACT = /^[A-Za-z0-9-]{1,64}$/;
// The ledger's own page for a record, as the engine built it (vert_engine/ledger_links.py).
const SAFE_URL = /^https:\/\/[a-z0-9.-]+\//;
const KINDS = new Set(["outstanding", "activity"]);
const LINE_KINDS = new Set(["invoice", "credit_note", "payment", "refund", "overpayment", "prepayment"]);
export const BUCKET_KEYS = Object.freeze(["current", "d1_30", "d31_60", "d61_90", "d90_plus", "credit"]);

function lineOf(raw) {
  if (!isObj(raw) || !LINE_KINDS.has(raw.kind) || !text(raw.activity) || typeof raw.date !== "string" || !ISO_DAY.test(raw.date)) return null;
  if (int(raw.amountCents) === null || int(raw.balanceCents) === null) return null;
  return {
    date: raw.date,
    kind: raw.kind,
    activity: text(raw.activity),
    reference: text(raw.reference),
    dueDate: typeof raw.dueDate === "string" && ISO_DAY.test(raw.dueDate) ? raw.dueDate : null,
    amount: raw.amountCents,
    open: int(raw.openCents),
    balance: raw.balanceCents,
    url: typeof raw.url === "string" && SAFE_URL.test(raw.url) ? raw.url : null,
  };
}

function bucketsOf(raw) {
  if (!Array.isArray(raw) || raw.length !== BUCKET_KEYS.length) return null;
  const out = [];
  for (let i = 0; i < raw.length; i += 1) {
    const b = raw[i];
    if (!isObj(b) || b.key !== BUCKET_KEYS[i] || !text(b.label) || int(b.cents) === null) return null;
    out.push({ key: b.key, label: text(b.label), cents: b.cents });
  }
  return out;
}

function currencyOf(raw, kind) {
  if (!isObj(raw) || typeof raw.currency !== "string" || !/^[A-Z]{3}$/.test(raw.currency)) return null;
  const lines = (Array.isArray(raw.lines) ? raw.lines : []).map(lineOf);
  if (lines.some((l) => l === null)) return null;
  const buckets = bucketsOf(raw.buckets);
  const closing = int(raw.closingCents);
  const lineCount = count(raw.lineCount);
  const more = count(raw.moreLines);
  if (!buckets || closing === null || lineCount === null || more === null || lines.length + more !== lineCount) return null;
  const opening = int(raw.openingCents);
  if (kind === "activity" && opening === null) return null;
  const tied = bool(raw.tied);
  const aged = int(raw.agedCents);
  if (tied === true && aged !== closing) return null;
  return {
    currency: raw.currency,
    opening: kind === "activity" ? opening : null,
    closing,
    overdue: int(raw.overdueCents),
    lines,
    lineCount,
    more,
    buckets,
    rollsForward: bool(raw.rollsForward),
    aged,
    tied,
  };
}

/** The engine's `shape.customerStatement`, read strictly, or null. Pure. */
export function customerStatementOf(raw) {
  if (!isObj(raw) || !KINDS.has(raw.kind) || !text(raw.title) || !text(raw.span)) return null;
  if (typeof raw.dateTo !== "string" || !ISO_DAY.test(raw.dateTo)) return null;
  const dateFrom = raw.dateFrom == null ? null : typeof raw.dateFrom === "string" && ISO_DAY.test(raw.dateFrom) ? raw.dateFrom : undefined;
  if (dateFrom === undefined || (raw.kind === "activity") !== (dateFrom !== null)) return null;
  const measured = raw.measured === true;
  const rawCurrencies = Array.isArray(raw.currencies) ? raw.currencies : [];
  // An unread statement carries no balance and says why (the contract's own rule).
  if (!measured && (rawCurrencies.length || !text(raw.words))) return null;
  const currencies = rawCurrencies.map((c) => currencyOf(c, raw.kind));
  if (currencies.some((c) => c === null)) return null;
  const contactId = typeof raw.contactId === "string" && CONTACT.test(raw.contactId) ? raw.contactId : null;
  return {
    kind: raw.kind,
    title: text(raw.title),
    contactId,
    contactName: text(raw.contactName),
    address: Array.isArray(raw.address) ? raw.address.map(text).filter(Boolean) : null,
    addressWords: text(raw.addressWords),
    orgName: text(raw.orgName),
    dateFrom,
    dateTo: raw.dateTo,
    span: text(raw.span),
    measured,
    words: text(raw.words),
    currencies,
    tied: bool(raw.tied),
    tieWords: text(raw.tieWords),
    href: statementHref(contactId, dateFrom, raw.dateTo),
  };
}

function query(contact, from, to) {
  if (!contact || !CONTACT.test(contact) || !ISO_DAY.test(to || "")) return null;
  if (from != null && (!ISO_DAY.test(from) || from > to)) return null;
  const q = new URLSearchParams({ contact });
  if (from) q.set("from", from);
  q.set("to", to);
  return q.toString();
}

/** The statement's page, or null for a question that isn't one. Pure. */
export function statementHref(contact, from, to) {
  const q = query(contact, from, to);
  return q ? `/reports/customer-statement?${q}` : null;
}

/** The engine's path for the statement, as JSON or as a file ("pdf", "xlsx"). Pure. */
export function statementApiPath(contact, from, to, format = null) {
  const q = query(contact, from, to);
  if (!q) return null;
  if (format === null) return `/reports/customer-statement?${q}`;
  return format === "pdf" || format === "xlsx" ? `/reports/customer-statement.${format}?${q}` : null;
}

/** The two downloads through this app (app/api/reports/customer-statement), or null. Pure. */
export function downloadLinks(statement) {
  if (!statement || !statement.measured) return null;
  const q = query(statement.contactId, statement.dateFrom, statement.dateTo);
  if (!q) return null;
  return { pdf: `/api/reports/customer-statement?${q}&format=pdf`, xlsx: `/api/reports/customer-statement?${q}&format=xlsx` };
}

/** The ageing buckets shown: unapplied credit only when there is some. Pure. */
export function shownBuckets(currency) {
  return currency.buckets.filter((b) => b.key !== "credit" || b.cents !== 0);
}

/** The tie, in a few words: the engine's sentence, said only on the engine's flag. Pure. */
export function tieSentence(statement) {
  if (!statement || !statement.measured) return null;
  return statement.tieWords || null;
}
