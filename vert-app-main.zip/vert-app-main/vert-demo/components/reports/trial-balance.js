// components/reports/trial-balance.js — THE TRIAL BALANCE, READ FROM THE ENGINE
// ==============================================================================
// Close checklist Step 4.1 (w31, 3 Nov 2026): "Run a Trial Balance: check for unusual
// debit or credit balances." The engine sends the full trial balance as at a date
// (vert_engine/analysis/trial_balance_report.py shape_of; contract model
// agent_events.ShapeTrialBalance), laid out as Xero's report: sections Revenue,
// Expenses, Assets, Liabilities, Equity; each account's month Debit / Credit and YTD
// Debit / YTD Credit; the Total row; each unusual balance's flag on its row.
//
// Everything here is a lookup: every amount is the engine's integer, nothing is summed.
// A block that doesn't read as the contract says is dropped whole (null). An unread
// trial balance keeps the engine's words and carries no row; totals the engine didn't
// strike (an account unread) are null, never shown as agreeing.
//
// It imports nothing, so the chat's shape reader and the page both use it.

export const SECTIONS = Object.freeze(["Revenue", "Expenses", "Assets", "Liabilities", "Equity"]);

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const cents = (v) => (Number.isInteger(v) && v > 0 ? v : null);
const total = (v) => (Number.isInteger(v) && v >= 0 ? v : null);
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;

function flagOf(raw) {
  if (raw == null) return null;
  if (!isObj(raw) || !text(raw.rule) || !text(raw.reason)) return undefined;
  return { rule: text(raw.rule), label: text(raw.label) || "Unusual", reason: text(raw.reason), info: raw.info === true };
}

function rowOf(raw) {
  if (!isObj(raw) || !text(raw.accountId) || !text(raw.name) || typeof raw.measured !== "boolean") return null;
  const flag = flagOf(raw.flag);
  if (flag === undefined) return null;
  const row = {
    accountId: text(raw.accountId),
    code: text(raw.code),
    name: text(raw.name),
    label: text(raw.label) || text(raw.name),
    type: text(raw.type) || "",
    measured: raw.measured,
    monthDebit: cents(raw.monthDebitCents),
    monthCredit: cents(raw.monthCreditCents),
    ytdDebit: cents(raw.ytdDebitCents),
    ytdCredit: cents(raw.ytdCreditCents),
    words: text(raw.words),
    retained: raw.retained === true,
    flag,
  };
  if ((row.monthDebit && row.monthCredit) || (row.ytdDebit && row.ytdCredit)) return null;
  if (!row.measured && (!row.words || row.ytdDebit || row.ytdCredit)) return null;
  return row;
}

/**
 * The payload's trial balance, read: `{asAt, period, title, currency, measured, words,
 * yearWords, syncedAt, sections: [{title, rows}], totals: {monthDebit, monthCredit,
 * ytdDebit, ytdCredit, balanced}, unread, flagged, accounts}`, or null when it isn't
 * one. Pure.
 */
export function trialBalanceOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean") return null;
  const asAt = typeof raw.asAt === "string" && ISO_DAY.test(raw.asAt) ? raw.asAt : null;
  if (!asAt || !text(raw.title)) return null;
  const sections = [];
  for (const s of Array.isArray(raw.sections) ? raw.sections : []) {
    if (!isObj(s) || !SECTIONS.includes(s.title) || !Array.isArray(s.rows) || !s.rows.length) return null;
    const rows = s.rows.map(rowOf);
    if (rows.some((r) => r === null)) return null;
    sections.push({ title: s.title, rows });
  }
  const t = isObj(raw.totals) ? raw.totals : {};
  const totals = {
    monthDebit: total(t.monthDebitCents),
    monthCredit: total(t.monthCreditCents),
    ytdDebit: total(t.ytdDebitCents),
    ytdCredit: total(t.ytdCreditCents),
    balanced: typeof t.balanced === "boolean" ? t.balanced : null,
  };
  const unread = (Array.isArray(raw.unread) ? raw.unread : []).filter((u) => isObj(u) && text(u.label) && text(u.why)).map((u) => ({ label: text(u.label), why: text(u.why) }));
  if (!raw.measured) {
    if (sections.length || !text(raw.words)) return null;
  }
  // TOTALS SHOWN AGREEING MUST AGREE, and a TB with an account unread has no total.
  if (totals.balanced === true && (totals.monthDebit !== totals.monthCredit || totals.ytdDebit !== totals.ytdCredit)) return null;
  if (totals.balanced !== null && unread.length) return null;
  return {
    asAt,
    period: asAt.slice(0, 7),
    title: text(raw.title),
    currency: text(raw.currency) || "AUD",
    measured: raw.measured,
    words: text(raw.words),
    yearWords: text(raw.yearWords),
    syncedAt: text(raw.syncedAt),
    basis: raw.basis === "postings" ? "postings" : "balances",
    sections,
    totals,
    unread,
    flagged: Number.isInteger(raw.flagged) && raw.flagged >= 0 ? raw.flagged : 0,
    accounts: Number.isInteger(raw.accounts) && raw.accounts >= 0 ? raw.accounts : 0,
    // Whether the unusual-balance review ran (lead L4-2). Absent is not a clean review.
    unusualChecked: raw.unusualChecked === true,
    unusualWords: text(raw.unusualWords),
  };
}

/** The sentence about unusual balances under the Total row. "None" only when the
 *  engine's review judged the balances; a review that didn't run says so. Pure. */
export function unusualWords(tb) {
  if (!tb || !tb.measured) return null;
  const n = tb.flagged;
  const flagged = n ? `${n} ${n === 1 ? "balance is" : "balances are"} flagged on ${n === 1 ? "its row" : "their rows"}.` : "";
  if (!tb.unusualChecked) {
    const why = tb.unusualWords || "Vert couldn't check for balances on an unusual side.";
    return flagged ? `${flagged} ${why}` : why;
  }
  return flagged || "No balance is on an unusual side.";
}

/** The words under the Total row. Pure. */
export function totalsWords(tb) {
  if (!tb || !tb.measured) return null;
  if (tb.totals.balanced === true) return "Debits equal credits.";
  if (tb.totals.balanced === false) return "Debits and credits don't agree.";
  const n = tb.unread.length;
  return `Not totalled: ${n} ${n === 1 ? "account wasn't" : "accounts weren't"} read.`;
}

/** The month's first and last day for an account's transactions from a TB row: the
 *  range Xero's drill-down opens. Pure. */
export function monthRangeOf(asAt) {
  return { from: `${asAt.slice(0, 7)}-01`, to: asAt };
}
