"use client";

// components/reports/ReportSheet.js — A REPORT BESIDE THE CHAT
// ==============================================================================
// Founder, 8 Nov 2026: the close list is worked in the chat. The bank reconciliation
// report answer's "Open the report" left for /reports/bank-reconciliation; it now opens
// the same report (BankRecReport.js, Xero's layout, with Print) in a wide side sheet,
// read through GET /api/reports/bank-reconciliation.

import { useEffect, useState } from "react";
import { Sheet } from "@/components/ui/Sheet";
import BankRecReport from "./BankRecReport";

const BANK_REC_REPORT = /^\/reports\/bank-reconciliation(?:\?([^#]*))?(?:#.*)?$/;

/** The report a link names that this sheet can draw, as `{ kind, query }`, or null. Pure. */
export function reportOf(href) {
  const m = typeof href === "string" ? BANK_REC_REPORT.exec(href) : null;
  if (!m) return null;
  const q = new URLSearchParams(m[1] || "");
  const out = new URLSearchParams();
  for (const key of ["period", "account"]) if (q.get(key)) out.set(key, q.get(key));
  return { kind: "bank_reconciliation", query: out.toString() };
}

export default function ReportSheet({ report, title = "Bank reconciliation", onClose }) {
  const [got, setGot] = useState(null);
  useEffect(() => {
    let live = true;
    fetch(`/api/reports/bank-reconciliation${report.query ? `?${report.query}` : ""}`, { cache: "no-store", credentials: "same-origin" })
      .then((r) => r.json().catch(() => null))
      .then((body) => live && setGot(body && body.read ? body : { read: { ok: false, message: "Vert couldn't read the report just now." }, ledgerName: null }))
      .catch(() => live && setGot({ read: { ok: false, message: "Vert couldn't read the report just now." }, ledgerName: null }));
    return () => {
      live = false;
    };
  }, [report.query]);
  return (
    <Sheet open side="right" title={title} onClose={onClose} className="bill-sheet report-sheet">
      {got ? (
        <BankRecReport initial={got.read} ledgerName={got.ledgerName} />
      ) : (
        <p className="ink-2" role="status">
          Reading the report…
        </p>
      )}
    </Sheet>
  );
}
