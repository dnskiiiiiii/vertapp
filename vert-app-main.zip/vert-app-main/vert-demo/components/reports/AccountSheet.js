"use client";

// components/reports/AccountSheet.js — ONE ACCOUNT'S TRANSACTIONS, BESIDE THE CHAT
// ==============================================================================
// Founder's walk, 8 Nov 2026: the trial balance review flagged three balances and gave no
// way to look into one. A review tool's flagged row opens the account's transactions for
// the month; this is that sheet (the trial balance report's own, TrialBalanceView.js),
// for any answer that names an account: read through GET /api/reports/account-
// transactions, a read.

import { useEffect, useRef, useState } from "react";
import { Sheet } from "@/components/ui/Sheet";
import AccountTransactions from "./AccountTransactions";
import { accountTransactionsPath } from "./account-transactions";

const PERIOD = /^(\d{4})-(\d{2})$/;

/** The month's first and last day for a period, or null. Pure. */
export function periodRange(period) {
  const m = PERIOD.exec(String(period || ""));
  if (!m) return null;
  const last = new Date(Date.UTC(Number(m[1]), Number(m[2]), 0)).getUTCDate();
  return { from: `${period}-01`, to: `${period}-${String(last).padStart(2, "0")}` };
}

/** The account code a cell like "090 Business Bank Account" or "090 · Bank" leads with, or null. Pure. */
export function accountCodeOf(text) {
  const m = /^\s*([0-9]{2,6})(?:\s|·|$)/.exec(String(text || ""));
  return m ? m[1] : null;
}

export default function AccountSheet({ code, label, period, onClose }) {
  const [read, setRead] = useState({ state: "reading" });
  const asked = useRef(0);
  useEffect(() => {
    const range = periodRange(period);
    const path = range ? accountTransactionsPath({ accounts: [code], from: range.from, to: range.to }) : null;
    if (!path) {
      setRead({ state: "failed", words: "Vert can't ask for that account's transactions." });
      return;
    }
    const n = ++asked.current;
    setRead({ state: "reading" });
    fetch(path, { cache: "no-store" })
      .then(async (res) => {
        const body = await res.json().catch(() => null);
        if (n !== asked.current) return;
        if (!res.ok) setRead({ state: "failed", words: (body && body.error && body.error.message) || "Vert couldn't read the account's transactions just now." });
        else setRead({ state: "read", body });
      })
      .catch(() => n === asked.current && setRead({ state: "failed", words: "Vert didn't answer just now. Try the account again." }));
  }, [code, period]);
  return (
    <Sheet open side="right" title={label || code} onClose={onClose} className="rpt-sheet">
      {read.state === "reading" ? (
        <p className="rpt-unread" role="status">
          Reading your ledger…
        </p>
      ) : read.state === "failed" ? (
        <p className="rpt-unread" role="status">
          {read.words}
        </p>
      ) : (
        <AccountTransactions accountTransactions={read.body} />
      )}
    </Sheet>
  );
}
