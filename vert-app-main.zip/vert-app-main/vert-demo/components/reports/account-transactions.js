// components/reports/account-transactions.js — ACCOUNT TRANSACTIONS, READ FROM THE ENGINE
// ==============================================================================
// Close checklist Step 4.2 (w31, 3 Nov 2026): "Check account transactions: review the
// Account Transactions report for miscoded items." The engine sends, per account, every
// transaction line Xero shares below its Advanced plan (Spend and Receive Money,
// invoices and bills, credit notes, payments, manual journals), with the opening,
// running and closing balance from the synced trial balance and each account's tie to
// its movement in the books (vert_engine/analysis/account_transactions.py shape_of;
// contract model agent_events.ShapeAccountTransactions).
//
// A lookup only: every amount is the engine's integer. An account not shown complete
// carries the engine's words saying why (a source not read, or postings Xero doesn't
// share); the screen says them, never "all transactions". A block that doesn't read as
// the contract says is dropped whole.
//
// It imports nothing.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const int = (v) => (Number.isInteger(v) ? v : null);
const pos = (v) => (Number.isInteger(v) && v > 0 ? v : null);
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;
// The ledger's own page for a record, as the engine built it (vert_engine/ledger_links.py).
const SAFE_URL = /^https:\/\/[a-z0-9.-]+\//;

function lineOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !text(raw.source) || typeof raw.date !== "string" || !ISO_DAY.test(raw.date)) return null;
  const debit = pos(raw.debitCents);
  const credit = pos(raw.creditCents);
  if (debit && credit) return null;
  // A REFERENCE THAT ONLY REPEATS THE DESCRIPTION IS BLANK (production walk, 8 Nov, D24):
  // a bank line's reference is its statement text, printed twice and pushing the columns
  // off the chat's edge.
  const description = text(raw.description) || text(raw.contact);
  const sameText = (a, b) => Boolean(a && b) && a.replace(/\s+/g, " ").trim().toLowerCase() === b.replace(/\s+/g, " ").trim().toLowerCase();
  const reference = sameText(text(raw.reference), description) ? null : text(raw.reference);
  const flag = isObj(raw.flag) && text(raw.flag.why) ? { rule: text(raw.flag.rule) || "miscoded", why: text(raw.flag.why), shouldBe: text(raw.flag.shouldBe) } : null;
  return {
    id: text(raw.id),
    date: raw.date,
    source: text(raw.source),
    contact: text(raw.contact),
    description,
    reference,
    debit,
    credit,
    running: int(raw.runningCents),
    gross: int(raw.grossCents),
    tax: int(raw.taxCents),
    url: typeof raw.url === "string" && SAFE_URL.test(raw.url) ? raw.url : null,
    flag,
  };
}

function accountOf(raw) {
  if (!isObj(raw) || !text(raw.accountId) || !text(raw.name) || !Array.isArray(raw.lines)) return null;
  const lines = raw.lines.map(lineOf);
  if (lines.some((l) => l === null)) return null;
  const complete = typeof raw.complete === "boolean" ? raw.complete : null;
  const unexplained = int(raw.unexplainedCents);
  if (complete === true && unexplained !== 0) return null;
  if (complete !== true && !text(raw.words)) return null;
  const lineCount = Number.isInteger(raw.lineCount) && raw.lineCount >= lines.length ? raw.lineCount : lines.length;
  return {
    accountId: text(raw.accountId),
    code: text(raw.code),
    name: text(raw.name),
    label: text(raw.label) || text(raw.name),
    type: text(raw.type) || "",
    opening: int(raw.openingCents),
    closing: int(raw.closingCents),
    booksClosing: int(raw.booksClosingCents),
    debit: Number.isInteger(raw.debitCents) ? raw.debitCents : 0,
    credit: Number.isInteger(raw.creditCents) ? raw.creditCents : 0,
    unexplained,
    complete,
    words: text(raw.words),
    lineCount,
    more: lineCount - lines.length,
    flagged: Number.isInteger(raw.flagged) ? raw.flagged : 0,
    lines,
  };
}

/**
 * The payload's Account Transactions, read: `{dateFrom, dateTo, currency, measured,
 * words, readAt, accounts, flagged, sources: {read, unread, neverRead}, href}`, or null
 * when it isn't one. Pure.
 */
export function accountTransactionsOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean") return null;
  if (typeof raw.dateFrom !== "string" || !ISO_DAY.test(raw.dateFrom) || typeof raw.dateTo !== "string" || !ISO_DAY.test(raw.dateTo)) return null;
  const accounts = (Array.isArray(raw.accounts) ? raw.accounts : []).map(accountOf);
  if (accounts.some((a) => a === null)) return null;
  if (!raw.measured && (accounts.length || !text(raw.words))) return null;
  const src = isObj(raw.sources) ? raw.sources : {};
  const unread = (Array.isArray(src.unread) ? src.unread : []).filter((u) => isObj(u) && text(u.words)).map((u) => ({ source: text(u.source), words: text(u.words), why: text(u.why) }));
  return {
    dateFrom: raw.dateFrom,
    dateTo: raw.dateTo,
    currency: text(raw.currency) || "AUD",
    measured: raw.measured,
    words: text(raw.words),
    readAt: text(raw.readAt),
    accounts,
    flagged: Number.isInteger(raw.flagged) ? raw.flagged : 0,
    sources: {
      read: (Array.isArray(src.read) ? src.read : []).filter(text),
      unread,
      neverRead: (Array.isArray(src.neverRead) ? src.neverRead : []).filter(text),
    },
    href: typeof raw.href === "string" && raw.href.startsWith("/") && !raw.href.startsWith("//") ? raw.href : null,
  };
}

/** The account's tie to the books in a few words: the engine's own when it gave
 *  them, else that the lines come to its movement. Pure. */
export function tieWords(account) {
  // A measured empty month is said plainly (lead L4-3), not as "these lines are all of it".
  if (account.complete === true && !(account.lines || []).length && !account.more) return "Nothing moved in this account in these dates.";
  if (account.complete === true) return "These lines are all of the account's movement in the books.";
  return account.words;
}

const ACCOUNTS = /^[A-Za-z0-9 ,&'().\-]{1,400}$/;

/** The app's read for the browser: `/api/reports/account-transactions?...`, or null
 *  when the question isn't one this app asks. Pure. */
export function accountTransactionsPath({ accounts, from, to }) {
  const list = (Array.isArray(accounts) ? accounts : [accounts]).map((a) => String(a || "").trim()).filter(Boolean);
  if (!list.length || list.length > 12) return null;
  const joined = list.join(",");
  if (!ACCOUNTS.test(joined)) return null;
  if (!ISO_DAY.test(from || "") || !ISO_DAY.test(to || "") || from > to) return null;
  const q = new URLSearchParams({ accounts: joined, from, to });
  return `/api/reports/account-transactions?${q.toString()}`;
}
