"use client";

// components/reports/TrialBalanceView.js — THE TRIAL BALANCE, WITH EACH ACCOUNT'S LINES IN PLACE
// ==============================================================================
// The trial balance (TrialBalance.js) with its rows opening a side sheet: press an
// account and its Account Transactions for the trial balance's month are read from Xero
// and drawn beside the trial balance, as Xero's drill-down opens them, without leaving
// the page or the conversation (founders, 3 Nov 2026: data seen inside the task, Ramp
// style). One read per press, through the app's route (app/api/reports/account-
// transactions), which adds the key on the server; the engine keeps a range five
// minutes, so opening the next account in the same month asks Xero nothing new.
//
// A read that failed says so in the sheet, in words; nothing is drawn as zero.

import { useCallback, useRef, useState } from "react";
import { Sheet } from "@/components/ui/Sheet";
import TrialBalance from "./TrialBalance";
import AccountTransactions from "./AccountTransactions";
import { trialBalanceOf, monthRangeOf } from "./trial-balance";
import { accountTransactionsPath } from "./account-transactions";

/** The full page for one account's month, from a TB row. Pure. */
function pageHref(tb, row) {
  const { from, to } = monthRangeOf(tb.asAt);
  const q = new URLSearchParams({ accounts: row.code || row.accountId, from, to });
  return `/reports/account-transactions?${q.toString()}`;
}

export default function TrialBalanceView({ trialBalance, compact = false }) {
  const tb = trialBalanceOf(trialBalance);
  const [open, setOpen] = useState(null);
  const [read, setRead] = useState({ state: "idle" });
  const asked = useRef(0);

  const openAccount = useCallback(
    async (row) => {
      if (!tb) return;
      const { from, to } = monthRangeOf(tb.asAt);
      const path = accountTransactionsPath({ accounts: [row.code || row.accountId], from, to });
      setOpen(row);
      if (!path) {
        setRead({ state: "failed", words: "Vert can't ask for that account's transactions." });
        return;
      }
      const n = ++asked.current;
      setRead({ state: "reading" });
      try {
        const res = await fetch(path, { cache: "no-store" });
        const body = await res.json().catch(() => null);
        if (n !== asked.current) return;
        if (!res.ok) {
          setRead({ state: "failed", words: (body && body.error && body.error.message) || "Vert couldn't read the account's transactions just now." });
          return;
        }
        setRead({ state: "read", body });
      } catch {
        if (n === asked.current) setRead({ state: "failed", words: "Vert didn't answer just now. Try the account again." });
      }
    },
    [tb]
  );

  if (!tb) return null;
  return (
    <>
      <TrialBalance trialBalance={trialBalance} onOpenAccount={tb.measured ? openAccount : null} compact={compact} />
      <Sheet open={Boolean(open)} side="right" title={open ? open.label : "Account transactions"} onClose={() => setOpen(null)} className="rpt-sheet">
        {read.state === "reading" ? (
          <p className="rpt-note" role="status">
            Reading your ledger…
          </p>
        ) : read.state === "failed" ? (
          <p className="rpt-unread" role="status">
            {read.words}
          </p>
        ) : read.state === "read" ? (
          <AccountTransactions accountTransactions={read.body} />
        ) : null}
        {open && pageHref(tb, open) ? (
          <a className="link rpt-note" href={pageHref(tb, open)}>
            Open as a page
          </a>
        ) : null}
      </Sheet>
    </>
  );
}
