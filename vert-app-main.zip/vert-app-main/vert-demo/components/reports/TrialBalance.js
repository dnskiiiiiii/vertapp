"use client";

// components/reports/TrialBalance.js — THE TRIAL BALANCE, AS DRAWN
// ==============================================================================
// Close checklist Step 4.1 (w31, 3 Nov 2026). Laid out as Xero's Trial Balance, which a
// bookkeeper scans: "As at" the date, then Revenue, Expenses, Assets, Liabilities and
// Equity, each account on one row with its code, name and type, the month's Debit and
// Credit, and the YTD Debit and YTD Credit; then the Total row and whether debits equal
// credits. An unusual balance is flagged ON ITS ROW (the word and the engine's reason),
// never shown instead of the trial balance.
//
// CLICK AN ACCOUNT, SEE ITS LINES IN PLACE (founders: data seen inside the task). Each
// row's name is a button; the caller opens that account's Account Transactions in a
// side sheet (AccountDrawer.js). Without `onOpenAccount` the rows are plain text.
//
// Every amount is the engine's integer (trial-balance.js); nothing is summed here.

import "./reports.css";
import { MONTHS, formatMoney } from "@/lib/format";
import { totalsWords, trialBalanceOf, unusualWords } from "./trial-balance";

/** The month the first two columns are: "Oct 2026", one non-breaking line. Pure. */
const monthWords = (asAt) => `${MONTHS[Number(asAt.slice(5, 7)) - 1]}\u00a0${asAt.slice(0, 4)}`;

const money = (c) => (c == null ? "" : formatMoney(c, { style: "table" }));
const ATTENTION = new Set(["wrong_side", "negative_inventory"]);

export default function TrialBalance({ trialBalance, onOpenAccount = null, compact = false }) {
  const tb = trialBalanceOf(trialBalance);
  if (!tb) return null;
  return (
    <section className="rpt" data-tb-report="" data-measured={tb.measured ? "read" : "unread"} data-compact={compact ? "" : undefined} aria-label="Trial balance">
      <header className="rpt-head">
        <h4 className="rpt-title">Trial balance</h4>
        <span className="rpt-sub">{tb.title}</span>
        {tb.measured ? <span className="rpt-sub">{tb.currency}</span> : null}
      </header>
      {!tb.measured ? (
        <p className="rpt-unread" data-rpt-unread="">
          Not read: {tb.words} An unread trial balance is unknown, not zero.
        </p>
      ) : (
        <>
          <div className="rpt-table-wrap">
            <table className="rpt-table">
              <thead>
                <tr>
                  <th scope="col" className="rpt-code">Code</th>
                  <th scope="col">Account</th>
                  <th scope="col" className="rpt-type">Type</th>
                  <th scope="col" className="num">Debit<span className="rpt-col-sub">{monthWords(tb.asAt)}</span></th>
                  <th scope="col" className="num">Credit<span className="rpt-col-sub">{monthWords(tb.asAt)}</span></th>
                  <th scope="col" className="num">YTD Debit</th>
                  <th scope="col" className="num">YTD Credit</th>
                </tr>
              </thead>
              {tb.sections.map((s) => (
                <tbody key={s.title}>
                  <tr className="rpt-section">
                    <th scope="rowgroup" colSpan={7}>{s.title}</th>
                  </tr>
                  {s.rows.map((r) => (
                    <Row key={r.accountId} row={r} onOpenAccount={onOpenAccount} />
                  ))}
                </tbody>
              ))}
              <tfoot>
                <tr className="rpt-total">
                  <th scope="row" colSpan={3}>Total</th>
                  <td className="num">{money(tb.totals.monthDebit)}</td>
                  <td className="num">{money(tb.totals.monthCredit)}</td>
                  <td className="num">{money(tb.totals.ytdDebit)}</td>
                  <td className="num">{money(tb.totals.ytdCredit)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
          <p className="rpt-words" data-tb-totals={tb.totals.balanced === true ? "agree" : tb.totals.balanced === false ? "off" : "unread"}>
            {totalsWords(tb)}
            {` ${unusualWords(tb)}`}
          </p>
          {tb.yearWords ? <p className="rpt-note">{tb.yearWords}.</p> : null}
          {tb.unread.length ? (
            <ul className="rpt-note-list">
              {tb.unread.map((u) => (
                <li key={u.label}>
                  {u.label}: {u.why}
                </li>
              ))}
            </ul>
          ) : null}
        </>
      )}
    </section>
  );
}

function Row({ row, onOpenAccount }) {
  const r = row;
  const name = onOpenAccount ? (
    <button type="button" className="rpt-open" data-open-account={r.code || r.accountId} onClick={() => onOpenAccount(r)} aria-label={`${r.label}: open its account transactions`}>
      {r.name}
    </button>
  ) : (
    r.name
  );
  return (
    <>
      <tr data-tb-row={r.accountId} data-flag={r.flag ? r.flag.rule : undefined} data-tone={r.flag && ATTENTION.has(r.flag.rule) ? "attention" : undefined}>
        <td className="rpt-code">{r.code || ""}</td>
        <th scope="row" className="rpt-name">
          {name}
          {r.flag ? <span className="rpt-flag">{r.flag.label}</span> : null}
        </th>
        <td className="rpt-type">{r.type}</td>
        <td className="num">{money(r.monthDebit)}</td>
        <td className="num">{money(r.monthCredit)}</td>
        {r.measured ? (
          <>
            <td className="num">{money(r.ytdDebit)}</td>
            <td className="num">{money(r.ytdCredit)}</td>
          </>
        ) : (
          <td className="num rpt-missing" colSpan={2}>
            Not read
          </td>
        )}
      </tr>
      {r.flag || r.words ? (
        <tr className="rpt-why" aria-hidden={r.flag ? undefined : "true"}>
          <td />
          <td colSpan={6}>{r.flag ? r.flag.reason : r.words}</td>
        </tr>
      ) : null}
    </>
  );
}
