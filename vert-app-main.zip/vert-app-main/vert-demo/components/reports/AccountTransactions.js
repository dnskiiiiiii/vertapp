"use client";

// components/reports/AccountTransactions.js — ACCOUNT TRANSACTIONS, AS DRAWN
// ==============================================================================
// Close checklist Step 4.2 (w31, 3 Nov 2026). Laid out as Xero's Account Transactions:
// one block per account, its Opening balance, then each line with Date, Source,
// Description, Reference, Debit, Credit, Balance (running) and GST, then its Closing
// balance. A line the misclassification rules would flag is marked on its row with why
// and what it should be. Under each account, its tie to the books: "all of the
// account's movement" only when the engine measured a zero gap with every source read;
// otherwise the engine's words and the gap at its size. Never "all transactions" for a
// list that might be short.
//
// Every amount is the engine's integer (account-transactions.js); nothing is summed.

import "./reports.css";
import { formatDate, formatMoney } from "@/lib/format";
import { accountTransactionsOf, tieWords } from "./account-transactions";

const money = (c) => (c == null ? "" : formatMoney(c, { style: "table" }));

export default function AccountTransactions({ accountTransactions, compact = false }) {
  const at = accountTransactionsOf(accountTransactions);
  if (!at) return null;
  return (
    <section className="rpt" data-account-transactions="" data-measured={at.measured ? "read" : "unread"} data-compact={compact ? "" : undefined} aria-label="Account transactions">
      <header className="rpt-head">
        <h4 className="rpt-title">Account transactions</h4>
        <span className="rpt-sub">
          {formatDate(at.dateFrom)} to {formatDate(at.dateTo)}
        </span>
        {at.measured ? <span className="rpt-sub">{at.currency}</span> : null}
      </header>
      {!at.measured ? (
        <p className="rpt-unread" data-rpt-unread="">
          Not read: {at.words}
        </p>
      ) : (
        at.accounts.map((a) => <AccountBlock key={a.accountId} account={a} href={compact ? at.href : null} />)
      )}
      {at.measured ? (
        <p className="rpt-note">
          From Spend and Receive Money, invoices and bills, credit notes, payments and manual journals.
          {at.sources.unread.length ? ` Not read: ${at.sources.unread.map((u) => u.words).join(", ")}.` : ""}
        </p>
      ) : null}
    </section>
  );
}

function AccountBlock({ account: a, href }) {
  // The Reference column only when a line has its own (D24); the rows' spans follow it.
  const refs = a.lines.some((l) => l.reference);
  const span = (n) => (refs ? n : n - 1);
  return (
    <div className="rpt-account" data-at-account={a.code || a.accountId} data-complete={a.complete === true ? "yes" : a.complete === false ? "no" : "unknown"}>
      <h5 className="rpt-account-title">
        {a.label}
        {a.flagged ? <span className="rpt-flag">{a.flagged === 1 ? "1 line looks miscoded" : `${a.flagged} lines look miscoded`}</span> : null}
      </h5>
      <div className="rpt-table-wrap">
        <table className="rpt-table rpt-lines">
          <thead>
            <tr>
              <th scope="col">Date</th>
              <th scope="col">Source</th>
              <th scope="col">Description</th>
              {refs ? <th scope="col">Reference</th> : null}
              <th scope="col" className="num">Debit</th>
              <th scope="col" className="num">Credit</th>
              <th scope="col" className="num">Balance</th>
              <th scope="col" className="num rpt-gst">GST</th>
            </tr>
          </thead>
          <tbody>
            <tr className="rpt-balance">
              <th scope="row" colSpan={span(6)}>Opening balance</th>
              <td className="num">{a.opening == null ? <span className="rpt-missing">Not read</span> : money(a.opening)}</td>
              <td className="rpt-gst" />
            </tr>
            {a.lines.map((l) => (
              <Line key={l.id} line={l} refs={refs} />
            ))}
            {a.more > 0 ? (
              <tr className="rpt-more">
                <td colSpan={span(8)}>{href ? <a className="link" href={href}>{`${a.more} more lines`}</a> : `${a.more} more lines`}</td>
              </tr>
            ) : null}
            {!a.lines.length ? (
              <tr className="rpt-more">
                <td colSpan={span(8)}>{a.complete === true ? "No lines in these dates." : "No lines read in these dates."}</td>
              </tr>
            ) : null}
          </tbody>
          <tfoot>
            <tr className="rpt-total">
              <th scope="row" colSpan={span(4)}>Closing balance</th>
              <td className="num">{money(a.debit || null)}</td>
              <td className="num">{money(a.credit || null)}</td>
              <td className="num">{a.closing == null ? <span className="rpt-missing">Not read</span> : money(a.closing)}</td>
              <td className="rpt-gst" />
            </tr>
          </tfoot>
        </table>
      </div>
      <p className="rpt-words" data-tie={a.complete === true ? "tied" : "untied"}>
        {tieWords(a)}
        {a.complete === false && a.unexplained != null ? ` Not in these lines: ${money(a.unexplained)}; the books close at ${money(a.booksClosing)}.` : ""}
      </p>
    </div>
  );
}

function Line({ line: l, refs = true }) {
  return (
    <>
      <tr data-at-line={l.id} data-flag={l.flag ? l.flag.rule : undefined}>
        <td className="rpt-date">{formatDate(l.date)}</td>
        <td className="rpt-source">{l.url ? <a className="link" href={l.url} target="_blank" rel="noreferrer">{l.source}</a> : l.source}</td>
        <td className="rpt-desc">
          {l.description || ""}
          {l.flag ? <span className="rpt-flag">Miscoded?</span> : null}
        </td>
        {refs ? <td className="rpt-ref">{l.reference || ""}</td> : null}
        <td className="num">{money(l.debit)}</td>
        <td className="num">{money(l.credit)}</td>
        <td className="num">{money(l.running)}</td>
        <td className="num rpt-gst">{l.tax ? money(l.tax) : ""}</td>
      </tr>
      {l.flag ? (
        <tr className="rpt-why">
          <td />
          <td colSpan={refs ? 7 : 6}>
            {l.flag.why}
            {l.flag.shouldBe ? ` Should be: ${l.flag.shouldBe}.` : ""}
          </td>
        </tr>
      ) : null}
    </>
  );
}
