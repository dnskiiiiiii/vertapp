"use client";

// components/reports/ReportForms.js — WHICH DATE, WHICH ACCOUNTS
// The report pages' questions, asked with the app's own date field (components/ui/
// DateField.js, never the browser's native picker), sent as a plain GET so the page
// reads the report on the server.

import { useState } from "react";
import { DateField } from "@/components/ui/DateField";

export function TrialBalanceDateForm({ asAt = "" }) {
  const [day, setDay] = useState(asAt || "");
  return (
    <form className="reports-form" method="get" action="/reports/trial-balance">
      <DateField label="As at" name="asAt" value={day} onChange={setDay} />
      <button type="submit" className="btn btn-secondary btn-sm">
        Show
      </button>
    </form>
  );
}

export function AccountTransactionsForm({ accounts = "", from = "", to = "" }) {
  const [first, setFirst] = useState(from || "");
  const [last, setLast] = useState(to || "");
  return (
    <form className="reports-form" method="get" action="/reports/account-transactions">
      <label className="field-label">
        Accounts
        <span className="field-box">
          <input type="text" name="accounts" defaultValue={accounts} placeholder="453, 090…" autoComplete="off" className="field-input" />
        </span>
      </label>
      <DateField label="From" name="from" value={first} onChange={setFirst} />
      <DateField label="To" name="to" value={last} onChange={setLast} />
      <button type="submit" className="btn btn-secondary btn-sm">
        Show
      </button>
    </form>
  );
}

export function GstReportForm({ from = "", to = "" }) {
  const [first, setFirst] = useState(from || "");
  const [last, setLast] = useState(to || "");
  return (
    <form className="reports-form" method="get" action="/reports/gst">
      <DateField label="From" name="from" value={first} onChange={setFirst} />
      <DateField label="To" name="to" value={last} onChange={setLast} />
      <button type="submit" className="btn btn-secondary btn-sm">
        Show
      </button>
    </form>
  );
}
