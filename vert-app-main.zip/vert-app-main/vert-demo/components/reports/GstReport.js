// components/reports/GstReport.js — THE GST REPORT, AS DRAWN
// ==============================================================================
// Function-fidelity audit row 22 (w42, 4 Nov 2026). For a month or a quarter:
//
//   1. GST by tax rate — Sales, then Purchases; each rate's net and GST, its lines under
//      it (Date, Source, Account, Description, Reference, Net, GST);
//   2. GST collected and GST paid;
//   3. the tie-out — the GST account's net movement against GST collected less GST
//      paid, the lines posted straight to the account, and anything unexplained. A ✓
//      only on the engine's `tied: true`; a movement not read is words, never $0.00;
//   4. the checks — each with the lines it found, or "Not checked" and why.
//
// A report for checking: the words say what it is (the engine's `purpose`) and the date
// basis. Rate names (including the ledger's own "BAS Excluded") are the engine's data.
// Every amount is the engine's integer (gst-report.js); nothing is summed here.

import "./reports.css";
import { formatDate, formatMoney } from "@/lib/format";
import { gstReportOf, rowsOn, tieSentence } from "./gst-report";

const money = (c) => (c == null ? "" : formatMoney(c, { style: "table" }));
const SIDES = [
  ["sales", "Sales"],
  ["purchases", "Purchases"],
];

export default function GstReport({ gstReport, compact = false }) {
  const r = gstReportOf(gstReport);
  if (!r) return null;
  return (
    <section className="rpt" data-gst-report="" data-measured={r.measured ? "read" : "unread"} data-compact={compact ? "" : undefined} aria-label="GST report">
      <header className="rpt-head">
        <h4 className="rpt-title">GST by tax rate</h4>
        <span className="rpt-sub">
          {formatDate(r.dateFrom)} to {formatDate(r.dateTo)}
        </span>
        {r.measured ? <span className="rpt-sub">{r.currency}</span> : null}
      </header>
      {!r.measured ? (
        <p className="rpt-unread" data-rpt-unread="">
          Not read: {r.words}
        </p>
      ) : (
        <>
          <RatesTable report={r} compact={compact} />
          {compact ? null : <Tie tie={r.tieOut} />}
          <Checks flags={r.flags} compact={compact} href={compact ? r.href : null} />
          {!r.complete ? (
            <p className="rpt-words" data-gst-incomplete="">
              Not read: {r.sources.unread.map((u) => u.words).join(", ")}. These totals may be short.
            </p>
          ) : null}
          {r.settingsWords ? <p className="rpt-note">Tax rate names and the chart&apos;s default rates weren&apos;t read ({r.settingsWords}); the ledger&apos;s standard rate names are shown.</p> : null}
        </>
      )}
      {r.purpose ? <p className="rpt-note" data-gst-purpose="">{r.purpose}</p> : null}
      {r.measured && r.basis ? <p className="rpt-note">{r.basis}</p> : null}
    </section>
  );
}

function RatesTable({ report: r, compact }) {
  return (
    <div className="rpt-table-wrap">
      <table className="rpt-table rpt-gst-rates">
        <thead>
          <tr>
            <th scope="col">Tax rate</th>
            <th scope="col" className="num">Net</th>
            <th scope="col" className="num">GST</th>
          </tr>
        </thead>
        {SIDES.map(([side, words]) => (
          <tbody key={side} data-gst-side={side}>
            <tr className="rpt-section">
              <th scope="rowgroup" colSpan={3}>{words}</th>
            </tr>
            {rowsOn(r, side).length ? (
              rowsOn(r, side).map((row) => <RateRow key={`${side}:${row.taxType}`} row={row} compact={compact} href={compact ? r.href : null} />)
            ) : (
              <tr className="rpt-more">
                <td colSpan={3}>No lines with a tax rate.</td>
              </tr>
            )}
          </tbody>
        ))}
        <tfoot>
          <tr className="rpt-total" data-gst-figure="collected">
            <th scope="row">GST collected</th>
            <td />
            <td className="num">{money(r.totals.collected)}</td>
          </tr>
          <tr className="rpt-total" data-gst-figure="paid">
            <th scope="row">GST paid</th>
            <td />
            <td className="num">{money(r.totals.paid)}</td>
          </tr>
          <tr className="rpt-total" data-gst-figure="net">
            <th scope="row">GST collected less GST paid</th>
            <td />
            <td className="num">{money(r.totals.net)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

function RateRow({ row, compact, href }) {
  const shown = row.lineCount === 1 ? "1 line" : `${row.lineCount} lines`;
  return (
    <>
      <tr data-gst-rate={row.taxType || "none"}>
        <th scope="row" className="rpt-name">
          {row.name}
          <span className="rpt-col-sub">{shown}</span>
        </th>
        <td className="num">{money(row.net)}</td>
        <td className="num">{money(row.gst)}</td>
      </tr>
      {compact ? null : (
        <tr className="rpt-why">
          <td colSpan={3}>
            <Lines lines={row.lines} shownAll={row.shownAll} lineCount={row.lineCount} href={href} />
          </td>
        </tr>
      )}
    </>
  );
}

function Lines({ lines, shownAll = true, lineCount = null, href = null, amounts = "row" }) {
  if (!lines.length) return null;
  return (
    <table className="rpt-table rpt-lines" data-gst-lines="">
      <thead>
        <tr>
          <th scope="col">Date</th>
          <th scope="col">Source</th>
          <th scope="col">Account</th>
          <th scope="col">Description</th>
          <th scope="col">Reference</th>
          {amounts === "row" ? (
            <>
              <th scope="col" className="num">Net</th>
              <th scope="col" className="num">GST</th>
            </>
          ) : (
            <>
              <th scope="col" className="num">Debit</th>
              <th scope="col" className="num">Credit</th>
            </>
          )}
        </tr>
      </thead>
      <tbody>
        {lines.map((l) => (
          <tr key={l.id} data-gst-line={l.id}>
            <td className="rpt-date">{formatDate(l.date)}</td>
            <td className="rpt-source">{l.url ? <a className="link" href={l.url} target="_blank" rel="noreferrer">{l.source}</a> : l.source}</td>
            <td className="rpt-code">{l.account}</td>
            <td className="rpt-desc">{l.description || ""}</td>
            <td className="rpt-ref">{l.reference || ""}</td>
            {amounts === "row" ? (
              <>
                <td className="num">{money(l.net)}</td>
                <td className="num">{money(l.gst)}</td>
              </>
            ) : (
              <>
                <td className="num">{money(l.debit)}</td>
                <td className="num">{money(l.credit)}</td>
              </>
            )}
          </tr>
        ))}
        {!shownAll && lineCount != null ? (
          <tr className="rpt-more">
            <td colSpan={7}>{href ? <a className="link" href={href}>{`Showing ${lines.length} of ${lineCount} lines`}</a> : `Showing ${lines.length} of ${lineCount} lines`}</td>
          </tr>
        ) : null}
      </tbody>
    </table>
  );
}

function Tie({ tie }) {
  if (!tie) return null;
  const state = tie.tied === true ? "tied" : tie.tied === false ? "untied" : "unchecked";
  return (
    <div className="rpt-account" data-gst-tie={state}>
      <h5 className="rpt-account-title">{tie.account ? `Tie-out to ${tie.account}` : "Tie-out to the GST account"}</h5>
      {tie.accountCode ? (
        <div className="rpt-table-wrap">
          <table className="rpt-table">
            <tbody>
              <tr>
                <th scope="row">GST collected less GST paid</th>
                <td className="num">{money(tie.coded)}</td>
              </tr>
              <tr>
                <th scope="row">The GST account&apos;s net movement</th>
                <td className="num">{tie.movement == null ? <span className="rpt-missing">Not read</span> : money(tie.movement)}</td>
              </tr>
              <tr className="rpt-balance">
                <th scope="row">Difference</th>
                <td className="num">{tie.difference == null ? <span className="rpt-missing">Not worked out</span> : money(tie.difference)}</td>
              </tr>
              <tr>
                <th scope="row">{tie.directCount === 1 ? "1 line posted straight to the GST account" : `${tie.directCount} lines posted straight to the GST account`}</th>
                <td className="num">{money(tie.direct)}</td>
              </tr>
              <tr className="rpt-total">
                <th scope="row">Unexplained</th>
                <td className="num">{tie.unexplained == null ? <span className="rpt-missing">Not worked out</span> : money(tie.unexplained)}</td>
              </tr>
            </tbody>
          </table>
        </div>
      ) : null}
      <p className="rpt-words" data-tie={state}>
        {tieSentence(tie)}
      </p>
      {tie.directLines.length ? <Lines lines={tie.directLines} amounts="sides" /> : null}
    </div>
  );
}

function Checks({ flags, compact, href }) {
  if (!flags.length) return null;
  return (
    <div className="rpt-account" data-gst-checks="">
      <h5 className="rpt-account-title">Checks</h5>
      {flags.map((f) => (
        <div key={f.key} data-gst-flag={f.key} data-found={!f.checked ? "unchecked" : f.count ? "found" : "none"}>
          <p className="rpt-words">
            <strong>{f.title}.</strong> {f.words}
          </p>
          {f.lines.length && !compact ? <Lines lines={f.lines} amounts="sides" shownAll={f.lines.length === f.count} lineCount={f.count} href={href} /> : null}
        </div>
      ))}
    </div>
  );
}
