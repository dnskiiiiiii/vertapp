"use client";

// components/reports/PrintButton.js — PRINT, OR SAVE AS PDF
// The browser's own print, which every browser can save as a PDF: the reports' print
// sheet (app/styles/reports.css) drops the app's chrome and starts each account on its
// own page, as Xero's export does. Nothing is generated or sent. Shared by the bank
// reconciliation report (w29) and the trial balance and Account Transactions (w31).

export default function PrintButton({ label = "Print or save as PDF" }) {
  return (
    <button type="button" className="btn btn-secondary rr-noprint" onClick={() => window.print()} data-report-print="">
      {label}
    </button>
  );
}
