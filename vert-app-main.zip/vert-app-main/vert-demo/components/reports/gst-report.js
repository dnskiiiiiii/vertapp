// components/reports/gst-report.js — THE GST REPORT, READ FROM THE ENGINE
// ==============================================================================
// Function-fidelity audit row 22 (w42, 4 Nov 2026). The engine sends, for a month or a
// quarter, GST by tax rate on the sales and purchases sides (net and GST), GST collected
// and paid, the GST account's net movement tied to them with the lines posted straight
// to it, and three checks (vert_engine/analysis/gst_report.py shape_of; contract model
// agent_events.ShapeGstReport).
//
// A lookup only: every amount is the engine's integer, shown as sent; nothing is summed,
// netted or signed here. A tie-out is "tied" only on the engine's `tied: true`, and a
// tie-out that couldn't be checked is the engine's words, never $0.00. An unread report
// carries no rate and no total. A block that doesn't read as the contract says is
// dropped whole.
//
// It imports nothing.

const isObj = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
const text = (v) => (typeof v === "string" && v.trim() ? v.trim() : null);
const int = (v) => (Number.isInteger(v) ? v : null);
const pos = (v) => (Number.isInteger(v) && v > 0 ? v : null);
const count = (v) => (Number.isInteger(v) && v >= 0 ? v : null);
const ISO_DAY = /^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
// The ledger's own page for a record, as the engine built it (vert_engine/ledger_links.py).
const SAFE_URL = /^https:\/\/[a-z0-9.-]+\//;
const SIDES = new Set(["sales", "purchases"]);

function lineOf(raw) {
  if (!isObj(raw) || !text(raw.id) || !text(raw.source) || typeof raw.date !== "string" || !ISO_DAY.test(raw.date)) return null;
  const debit = pos(raw.debitCents);
  const credit = pos(raw.creditCents);
  if (debit && credit) return null;
  return {
    id: text(raw.id),
    date: raw.date,
    source: text(raw.source),
    contact: text(raw.contact),
    description: text(raw.description) || text(raw.contact),
    reference: text(raw.reference),
    account: text(raw.account) || text(raw.accountCode) || "",
    taxType: typeof raw.taxType === "string" ? raw.taxType : null,
    debit,
    credit,
    net: int(raw.shownNetCents),
    gst: int(raw.shownGstCents),
    tax: int(raw.taxCents),
    url: typeof raw.url === "string" && SAFE_URL.test(raw.url) ? raw.url : null,
  };
}

function linesOf(raw) {
  const lines = (Array.isArray(raw) ? raw : []).map(lineOf);
  return lines.some((l) => l === null) ? null : lines;
}

function rowOf(raw) {
  if (!isObj(raw) || !SIDES.has(raw.side) || !text(raw.name) || int(raw.netCents) === null || int(raw.gstCents) === null) return null;
  const lines = linesOf(raw.lines);
  const lineCount = count(raw.lineCount);
  if (!lines || lineCount === null || lines.length > lineCount) return null;
  return {
    side: raw.side,
    sideWords: text(raw.sideWords) || (raw.side === "sales" ? "Sales" : "Purchases"),
    taxType: typeof raw.taxType === "string" ? raw.taxType : "",
    name: text(raw.name),
    named: raw.named !== false,
    net: raw.netCents,
    gst: raw.gstCents,
    lineCount,
    lines,
    // Shown, never worked out: "and N more" uses the engine's own count beside the list.
    shownAll: lines.length === lineCount,
  };
}

function tieOf(raw) {
  if (raw == null) return null;
  if (!isObj(raw)) return undefined;
  const tied = typeof raw.tied === "boolean" ? raw.tied : null;
  const movement = int(raw.movementCents);
  const unexplained = int(raw.unexplainedCents);
  if (tied === true && unexplained !== 0) return undefined;
  if (movement === null && (tied !== null || unexplained !== null)) return undefined;
  if (tied !== true && !text(raw.words) && movement !== null && unexplained !== 0) return undefined;
  const direct = linesOf(raw.direct);
  if (!direct) return undefined;
  return {
    accountCode: text(raw.accountCode),
    account: text(raw.account),
    collected: int(raw.collectedCents),
    paid: int(raw.paidCents),
    coded: int(raw.codedCents),
    movement,
    difference: int(raw.differenceCents),
    direct: int(raw.directCents),
    directLines: direct,
    directCount: count(raw.directCount) ?? direct.length,
    unexplained,
    tied,
    words: text(raw.words),
  };
}

function flagOf(raw) {
  if (!isObj(raw) || !text(raw.key) || !text(raw.title) || !text(raw.words) || typeof raw.checked !== "boolean") return null;
  const lines = linesOf(raw.lines);
  const n = count(raw.count);
  if (!lines || n === null || lines.length > n) return null;
  return { key: text(raw.key), title: text(raw.title), words: text(raw.words), checked: raw.checked, count: n, lines };
}

/**
 * The payload's GST report, read: `{dateFrom, dateTo, span, currency, measured, complete,
 * words, basis, purpose, href, rows, totals, tieOut, flags, sources, settingsWords}`, or
 * null when it isn't one. Pure.
 */
export function gstReportOf(raw) {
  if (!isObj(raw) || typeof raw.measured !== "boolean") return null;
  if (typeof raw.dateFrom !== "string" || !ISO_DAY.test(raw.dateFrom) || typeof raw.dateTo !== "string" || !ISO_DAY.test(raw.dateTo)) return null;
  const rows = (Array.isArray(raw.rows) ? raw.rows : []).map(rowOf);
  if (rows.some((r) => r === null)) return null;
  const flags = (Array.isArray(raw.flags) ? raw.flags : []).map(flagOf);
  if (flags.some((f) => f === null)) return null;
  const tieOut = tieOf(raw.tieOut);
  if (tieOut === undefined) return null;
  const totals = isObj(raw.totals) ? raw.totals : {};
  const collected = int(totals.collectedCents);
  const paid = int(totals.paidCents);
  if (!raw.measured && (rows.length || !text(raw.words) || collected !== null || paid !== null)) return null;
  if (raw.measured && (collected === null || paid === null)) return null;
  const src = isObj(raw.sources) ? raw.sources : {};
  return {
    dateFrom: raw.dateFrom,
    dateTo: raw.dateTo,
    span: text(raw.span) || `${raw.dateFrom} to ${raw.dateTo}`,
    currency: text(raw.currency) || "AUD",
    measured: raw.measured,
    complete: raw.complete === true,
    words: text(raw.words),
    readAt: text(raw.readAt),
    basis: text(raw.basis),
    purpose: text(raw.purpose),
    rows,
    totals: { collected, paid, net: int(totals.netCents) },
    tieOut: raw.measured ? tieOut : null,
    flags: raw.measured ? flags : [],
    settingsWords: text(raw.settingsWords),
    leftOut: count(raw.leftOut) || 0,
    sources: {
      unread: (Array.isArray(src.unread) ? src.unread : []).filter((u) => isObj(u) && text(u.words)).map((u) => ({ source: text(u.source), words: text(u.words), why: text(u.why) })),
      neverRead: (Array.isArray(src.neverRead) ? src.neverRead : []).filter(text),
    },
    href: typeof raw.href === "string" && raw.href.startsWith("/") && !raw.href.startsWith("//") ? raw.href : null,
  };
}

/** The rows on one side, in the engine's order. Pure. */
export function rowsOn(report, side) {
  return report.rows.filter((r) => r.side === side);
}

/** The tie-out in a sentence: tied, a difference, or why it couldn't be checked. Pure. */
export function tieSentence(tie) {
  if (!tie) return null;
  if (!tie.accountCode) return tie.words;
  if (tie.movement === null) return tie.words;
  if (tie.tied === true) return tie.words ? `Ties. ${tie.words}` : "Ties.";
  return tie.words;
}

/** The page's own path for a month or a quarter, or null when the dates aren't one. */
export function gstReportHref(from, to) {
  if (!ISO_DAY.test(from || "") || !ISO_DAY.test(to || "") || from > to) return null;
  return `/reports/gst?${new URLSearchParams({ from, to }).toString()}`;
}

export { ISO_DAY };
