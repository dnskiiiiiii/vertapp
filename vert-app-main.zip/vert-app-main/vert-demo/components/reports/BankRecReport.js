// components/reports/BankRecReport.js — THE BANK RECONCILIATION REPORT, AS AN ACCOUNTANT READS IT
// ==============================================================================
// Founder's close checklist, Step 2 (3 Nov 2026): "Run the Bank Reconciliation Report
// and Bank Reconciliation Detail report to confirm calculated balances match
// real-world bank statements." Xero's export, account by account, as at the month's
// end (w29-contract.md):
//
//   the summary   Balance in Xero, plus outstanding payments, less outstanding receipts,
//                 plus unreconciled statement lines = statement balance (calculated);
//                 against the balance per statement, and the difference
//   the detail    each outstanding payment, receipt and statement line: Date,
//                 Description, Reference, Amount, and its total
//
// Every figure is the engine's (lib/bank-rec-report-model.js adds nothing). A figure
// the engine didn't measure is its words, never $0.00. Printable: the print sheet drops
// the app's chrome and starts each account on a page of its own.

import Link from "next/link";

import AccountingFigure from "@/components/shared/AccountingFigure";
import { appHref } from "@/lib/agent/links";
import { reportView } from "@/lib/bank-rec-report-model";

import PrintButton from "./PrintButton";

function Amount({ cents, words = null }) {
  if (Number.isInteger(cents)) return <AccountingFigure cents={cents} />;
  return <span className="rr-unread">{words || "Not read"}</span>;
}

function Summary({ account }) {
  return (
    <table className="rr-summary">
      <caption className="sr-only">Summary, {account.label}</caption>
      <tbody>
        {account.summary.map((line) => (
          <tr key={line.key} data-ruled={line.ruled ? "" : undefined} data-line={line.key}>
            <th scope="row">{line.label}</th>
            <td className="rt">
              <Amount cents={line.cents} words={line.words} />
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function Detail({ block }) {
  return (
    <table className="rr-detail" data-detail={block.key}>
      <caption>{block.title}</caption>
      <thead>
        <tr>
          <th scope="col">Date</th>
          <th scope="col">Description</th>
          <th scope="col">Reference</th>
          <th scope="col" className="rt">
            Amount
          </th>
        </tr>
      </thead>
      <tbody>
        {!block.measured ? (
          <tr>
            <td colSpan={4} className="rr-none">
              {block.words}
            </td>
          </tr>
        ) : block.rows.length ? (
          block.rows.map((row) => (
            <tr key={row.key}>
              <td className="rr-date">{row.date}</td>
              <td>{row.description}</td>
              <td>{row.reference}</td>
              <td className="rt">
                <Amount cents={row.cents} />
              </td>
            </tr>
          ))
        ) : (
          <tr>
            <td colSpan={4} className="rr-none">
              None
            </td>
          </tr>
        )}
      </tbody>
      {block.measured ? (
        <tfoot>
          <tr>
            <th scope="row" colSpan={3}>
              Total
            </th>
            <td className="rt">
              <Amount cents={block.totalCents} />
            </td>
          </tr>
        </tfoot>
      ) : null}
    </table>
  );
}

/** Whether no line or list of the account was read: no figure anywhere. Pure. */
export function nothingRead(account) {
  const lines = Array.isArray(account && account.summary) ? account.summary : [];
  const blocks = Array.isArray(account && account.detail) ? account.detail : [];
  return lines.length > 0 && lines.every((l) => !Number.isInteger(l.cents)) && blocks.every((b) => !b.measured);
}

function Account({ account }) {
  const id = `rr-${String(account.key).replace(/[^A-Za-z0-9_-]/g, "-")}`;
  const next = account.next ? appHref(account.next.href) : null;
  return (
    <section className="rr-account" aria-labelledby={id} data-status={account.status} data-kind={account.kind}>
      <header className="rr-account-head">
        <h2 id={id} className="t-title-3" translate="no">
          {account.label}
        </h2>
        <p className="rr-verdict" data-tone={account.tone}>
          {account.verdict}
        </p>
      </header>
      {account.statement ? <p className="rr-source">{account.statement}</p> : null}
      {account.words ? <p className="rr-why">{account.words}</p> : null}
      {/* AN ACCOUNT WITH NOTHING READ IS ITS REASON, ONCE (founder's walk, 8 Nov 2026):
          seven summary lines and two empty tables each said "The reconciliation hasn't
          been done." Its verdict and why stand for them. */}
      {nothingRead(account) ? null : (
        <>
          <Summary account={account} />
          <div className="rr-details">
            {account.detail.map((block) => (
              <Detail key={block.key} block={block} />
            ))}
          </div>
        </>
      )}
      {next ? (
        <p className="rr-next rr-noprint">
          <Link className="link" href={next}>
            {account.next.label}
          </Link>
        </p>
      ) : null}
    </section>
  );
}

export default function BankRecReport({ initial, ledgerName = null }) {
  if (!initial || !initial.ok) {
    return (
      <div className="page rr-page" data-bank-rec-report="">
        <header className="page-head rr-head">
          <h1 className="t-title-1">Bank reconciliation</h1>
        </header>
        <p className="rr-words">{(initial && initial.message) || "Vert couldn't read the bank reconciliations just now."}</p>
      </div>
    );
  }
  const view = reportView(initial.body, { ledgerName });
  return (
    <div className="page rr-page" data-bank-rec-report="">
      <header className="page-head rr-head">
        <div>
          <h1 className="t-title-1">{view.title}</h1>
          {view.asAt ? <p className="page-head-sub">{view.asAt}</p> : null}
        </div>
        <PrintButton />
      </header>
      {view.words ? <p className="rr-words">{view.words}</p> : null}
      {view.accounts.length ? (
        view.accounts.map((account) => <Account key={account.key} account={account} />)
      ) : (
        <p className="rr-words">No bank or card account to reconcile.</p>
      )}
    </div>
  );
}
