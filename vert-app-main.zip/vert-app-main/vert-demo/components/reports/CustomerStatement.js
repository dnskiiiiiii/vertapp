// components/reports/CustomerStatement.js — A CUSTOMER'S STATEMENT, AS DRAWN
// ==============================================================================
// Function-fidelity audit row 20 (w46, 4 Nov 2026). One customer:
//
//   1. who and when — the customer (and, on the page, their postal address or the
//      engine's words for its absence) and the statement date or period;
//   2. the lines — Date, Activity, (Reference,) Due, Amount, (Open,) Balance; an activity
//      statement opens on the balance the day before and every line moves it. Reference
//      is drawn only when a line has one (w51: the Demo Company's invoices carry none,
//      and a column blank on every line reads as something missing);
//   3. Balance due, and the ageing strip under it;
//   4. the check against aged receivables, in the engine's words; a ✓ only on its
//      `tied: true`;
//   5. Download PDF and Excel (app/api/reports/customer-statement), and on the chat's
//      card a link to the full page.
//
// It sends nothing: a statement goes to a customer only attached to their payment
// reminder, on a person's Approve & send (ReminderDrafts.js). Every amount is the
// engine's integer (customer-statement.js); nothing is summed here.

import "./reports.css";
import { formatDate, formatMoney } from "@/lib/format";
import { IconCheck, IconDownload } from "@/components/ui/icons";
import { customerStatementOf, downloadLinks, shownBuckets } from "./customer-statement";

const money = (c) => (c == null ? "" : formatMoney(c, { style: "table" }));
const day = (d) => (d ? formatDate(d) : "");

export default function CustomerStatement({ customerStatement, compact = false }) {
  const s = customerStatementOf(customerStatement);
  if (!s) return null;
  const links = downloadLinks(s);
  const several = s.currencies.length > 1;
  return (
    <section className="rpt cst" data-customer-statement="" data-kind={s.kind} data-measured={s.measured ? "read" : "unread"} data-compact={compact ? "" : undefined} aria-label={s.title}>
      <header className="rpt-head">
        <h4 className="rpt-title">{s.title}</h4>
        <span className="rpt-sub">
          {s.contactName ? `${s.contactName} · ` : ""}
          {s.dateFrom ? `${day(s.dateFrom)} to ${day(s.dateTo)}` : `As at ${day(s.dateTo)}`}
        </span>
      </header>
      {!compact ? <To statement={s} /> : null}
      {!s.measured ? (
        <p className="rpt-unread" data-rpt-unread="">
          Not read: {s.words}
        </p>
      ) : (
        <>
          {s.currencies.length ? null : <p className="rpt-words">{s.words}</p>}
          {s.currencies.map((c) => (
            <div className="rpt-account" key={c.currency} data-statement-currency={c.currency}>
              {several ? <h5 className="rpt-account-title">In {c.currency}</h5> : null}
              <Lines statement={s} currency={c} compact={compact} />
              <Ageing currency={c} />
            </div>
          ))}
          {several && s.words ? <p className="rpt-note">{s.words}</p> : null}
          {s.tieWords ? (
            <p className="rpt-words" data-statement-tie={s.tied === true ? "tied" : s.tied === false ? "untied" : "unchecked"}>
              {s.tied === true ? <><IconCheck className="cst-tie-glyph" size={14} aria-hidden="true" />{" "}</> : null}
              {s.tieWords}
            </p>
          ) : null}
        </>
      )}
      {links || (compact && s.href) ? (
        <div className="reports-actions cst-actions" data-statement-downloads="">
          {links ? (
            <>
              <a className="btn btn-secondary btn-sm" href={links.pdf} download data-statement-download="pdf">
                <IconDownload aria-hidden="true" />
                <span>Download PDF</span>
              </a>
              <a className="btn btn-quiet btn-sm" href={links.xlsx} download data-statement-download="xlsx">
                Excel
              </a>
            </>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}

function To({ statement: s }) {
  return (
    <div className="cst-to" data-statement-to="">
      <p className="rpt-sub">To</p>
      <p className="rpt-words">
        {s.contactName || "This customer"}
        {(s.address || []).map((line) => (
          <span key={line} className="cst-line">
            {line}
          </span>
        ))}
      </p>
      {!s.address && s.addressWords ? <p className="rpt-note">{s.addressWords}</p> : null}
    </div>
  );
}

function Lines({ statement: s, currency: c, compact }) {
  const outstanding = s.kind === "outstanding";
  const withRef = s.currencies.some((cur) => cur.lines.some((l) => l.reference));
  const cols = (outstanding ? 7 : 6) - (withRef ? 0 : 1);
  return (
    <div className="rpt-table-wrap">
      <table className="rpt-table cst-lines">
        <thead>
          <tr>
            <th scope="col">Date</th>
            <th scope="col">Activity</th>
            {withRef ? <th scope="col" className="rpt-ref">Reference</th> : null}
            <th scope="col">Due</th>
            <th scope="col" className="num">Amount</th>
            {outstanding ? <th scope="col" className="num">Open</th> : null}
            <th scope="col" className="num">Balance</th>
          </tr>
        </thead>
        <tbody>
          {!outstanding ? (
            <tr className="rpt-balance" data-statement-row="opening">
              <th scope="row" colSpan={cols - 1}>Opening balance</th>
              <td className="num">{money(c.opening)}</td>
            </tr>
          ) : null}
          {c.more ? (
            <tr className="rpt-more" data-statement-more={c.more}>
              <td colSpan={cols}>{c.more === 1 ? "1 earlier line" : `${c.more} earlier lines`} on the full statement</td>
            </tr>
          ) : null}
          {c.lines.length ? (
            c.lines.map((l, i) => (
              <tr key={`${l.date}:${l.activity}:${i}`} data-statement-line={l.kind}>
                <td className="rpt-date">{day(l.date)}</td>
                <td className="rpt-name">{l.url && !compact ? <a className="link" href={l.url} target="_blank" rel="noreferrer">{l.activity}</a> : l.activity}</td>
                {withRef ? <td className="rpt-ref">{l.reference || ""}</td> : null}
                <td className="rpt-date">{day(l.dueDate)}</td>
                <td className="num">{money(l.amount)}</td>
                {outstanding ? <td className="num">{money(l.open)}</td> : null}
                <td className="num">{money(l.balance)}</td>
              </tr>
            ))
          ) : (
            <tr className="rpt-more">
              <td colSpan={cols}>{outstanding ? "Nothing open." : "Nothing in the period."}</td>
            </tr>
          )}
        </tbody>
        <tfoot>
          <tr className="rpt-total" data-statement-row="closing">
            <th scope="row" colSpan={cols - 1}>Balance due</th>
            <td className="num">{money(c.closing)}</td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}

function Ageing({ currency: c }) {
  return (
    <dl className="cst-ageing" data-statement-ageing="">
      {shownBuckets(c).map((b) => (
        <div key={b.key} data-bucket={b.key}>
          <dt>{b.label}</dt>
          <dd className="num">{money(b.cents)}</dd>
        </div>
      ))}
    </dl>
  );
}
