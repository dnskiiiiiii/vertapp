// components/auth/copy.js — WHAT THE SIGN-IN SCREEN SAYS, IN ONE PLACE
// ==============================================================================
// Spec §3.1 and §13.2: the bookkeeper's word is "Your Vert access code", never "API
// key", and the key's technical prefix is never shown or asked for. The service's own
// refusals ("Invalid or missing API key.", "It starts with vk_.") are written for an
// integrator; this module turns each KIND of outcome into a sentence a bookkeeper can
// act on, and nothing else on the screen words a refusal.
//
// WHAT IT DELIBERATELY DOES NOT DO: say which part of a wrong code was wrong. The
// service answers every bad key identically on purpose — telling the holder of a wrong
// code what was wrong with it turns an offline guess into an online one with feedback —
// and this keeps that property: every refusal of a code is the same sentence.
//
// Pure, with no imports, so tests/session.test.js can read every sentence directly.

export const SIGN_IN = Object.freeze({
  // The quiet centred lockup (founder decision D5; design-fix-2 DA2-021): the mark, "Vert",
  // this title and one value line. The product names itself once, in the title.
  title: "Sign in to Vert",
  value: "Month-end close for accounting firms",
  label: "Your Vert access code",
  submit: "Sign in",
  busy: "Checking…",
  show: "Show access code",
  hide: "Hide access code",
  help: "Where do I find it?",
  // Behind "Where do I find it?". The facts a person without a code needs: who issues
  // one, that there is no sign-up, and that a lost one is replaced rather than re-sent
  // (only a hash of it was ever stored, so re-sending is impossible).
  helpBody:
    "Whoever set up Vert for your practice issues access codes by hand; there is no self-serve sign-up. " +
    "A lost code can’t be recovered or re-sent. Ask them for a new one.",
  sample: "This sample has nothing to sign in to.",
  openSample: "Open the sample",
});

export const SIGN_IN_REFUSED = Object.freeze({
  empty: "Enter your Vert access code.",
  refused: "That code wasn’t accepted. Check it and try again.",
  paused: "Access for this practice is paused. Ask whoever set up Vert for you.",
  // §20.12 M3: a person's code whose home client the firm no longer serves.
  disengaged: "Your firm no longer works with this client, so your code doesn't open its books. Ask your firm's admin.",
  unreachable: "Vert isn’t answering right now, so your code wasn’t checked. Try again in a minute.",
  unchecked: "This Vert service isn’t checking access codes, so there’s nothing to sign in to.",
  sample: "There’s nothing to sign in to in this sample.",
});

/**
 * The sentence for a failed sign-in, from `lib/engine-source.js verifySessionKey`'s
 * outcome (`{ok: false, kind, message}`) and the code that was typed.
 */
export function signInRefusal(result, typed) {
  if (!String(typed ?? "").trim()) return SIGN_IN_REFUSED.empty;
  const kind = result && result.kind;
  if (kind === "unavailable") return SIGN_IN_REFUSED.sample;
  if (kind === "unreachable") return SIGN_IN_REFUSED.unreachable;
  // The engine's 403 words (vert_engine/tenancy/firm_directory.py); lib/roles.js engagementEnded is the same test.
  if (/engagement with this client is not active/i.test(String((result && result.message) || ""))) return SIGN_IN_REFUSED.disengaged;
  if (/suspend|paused|disabled/i.test(String((result && result.message) || ""))) return SIGN_IN_REFUSED.paused;
  return SIGN_IN_REFUSED.refused;
}

/** Why the last session ended, in one sentence, or null on a first visit. */
export function sessionEndedSentence(reason, REJECTED) {
  if (reason === REJECTED.idle) return "You were signed out after 30 minutes without activity.";
  if (reason === REJECTED.expired) return "Sessions last 8 hours, and yours has ended. Sign in again.";
  if (reason === REJECTED.malformed) return "Your session couldn’t be read. Sign in again.";
  return null;
}
