"use server";

// components/auth/actions.js — SIGN IN, SIGN OUT. THE ONLY TWO WRITES TO THE SESSION.
// ==============================================================================
// Server Actions rather than Route Handlers, for the reason lib/actions.js gives for
// the three decisions: a form that posts to a Server Action works with no JavaScript,
// returns its refusal as DATA rather than as a thrown digest, and never puts the
// credential anywhere a browser or a URL can see it. A sign-in form that POSTs a key
// to an endpoint would put that key in a request body this app logs nothing about —
// but a redirect, a referrer or an error report might.
//
// Neither action decides anything about the credential. `signIn` presents it to
// vert_api and believes the answer; that is the whole of the authentication done on
// this side of the wire, and it is deliberate — vert_engine/tenancy is the identity
// system, and a second opinion here would be a second thing to keep correct.

import { headers } from "next/headers";
import { redirect } from "next/navigation";

import { endSession, startSession, verifyKey } from "@/lib/session";
import { safeNext } from "@/lib/return-path";

import { SIGN_IN_REFUSED, signInRefusal } from "./copy";

/**
 * Is this request on HTTPS? Decides the cookie's `Secure` flag.
 *
 * Read per request rather than from an environment variable, because the same build
 * runs at `http://127.0.0.1:3000` during development and behind TLS in a deployment.
 * Hard-coding `secure: true` makes sign-in fail at localhost in a way that looks like
 * a wrong password — the browser silently drops the cookie and bounces you straight
 * back to the form, with nothing in any log to say why.
 *
 * `x-forwarded-proto` is what a terminating proxy sets, and it is what Vercel sets.
 */
async function isSecureRequest() {
  const h = await headers();
  const proto = h.get("x-forwarded-proto") || "";
  return proto.split(",")[0].trim() === "https";
}

/**
 * Exchange a pasted access code (an API key, to the service) for a session.
 *
 * The signature is `useActionState`'s: `(previousState, formData) => state`. The
 * returned state is rendered under the field, so every failure is a sentence a
 * bookkeeper can act on — a wrong key, a suspended account and an unreachable
 * service are three different problems and must not arrive as one.
 *
 * On success it REDIRECTS rather than returning. That is not decoration: a redirect
 * ends the POST, so the browser's history holds a GET of the destination and a reload
 * cannot resubmit the form with the credential in it.
 */
export async function signIn(_previous, formData) {
  const key = String(formData.get("accessCode") || "");

  const result = await verifyKey(key);
  if (!result.ok) {
    // The code is NOT echoed back into the form. A rejected credential re-rendered
    // into a value attribute is a credential in the HTML, in the browser's cache and
    // in any error reporter watching the page. The field keeps what was typed because
    // the browser still holds it (components/auth/SignInForm.js keeps it in client
    // state), not because the server sent it back (UI-052).
    return { ok: false, message: signInRefusal(result, key) };
  }

  // The service answered, but with what? An open deployment resolves ANY request to
  // its default tenant and says so on this endpoint. Sealing that as a session would
  // be this screen telling somebody they had signed in to Northwind's books when
  // nothing was signed and no key was checked. The remedy is an operator's, so it goes
  // to the server log; the screen says only that there is nothing to sign in to.
  if (result.identity.authenticated !== true) {
    console.error(
      "[vert-demo] sign-in refused: the Vert service is running with authentication off " +
        `and attributes every request to "${result.identity.tenant}". Start it with ` +
        "VERT_AUTH_DATABASE_URL set to a vert_authenticator DSN (it refuses this " +
        "configuration outright when VERT_ENV=production)."
    );
    return { ok: false, message: SIGN_IN_REFUSED.unchecked };
  }

  await startSession(key.trim(), result.identity, { secure: await isSecureRequest() });
  // Back to the page the session ended on (verify pass 1 F10), when it is a path on
  // this site; else Month-end.
  redirect(safeNext(String(formData.get("next") || "")) || "/");
}

/**
 * End the session in this browser.
 *
 * Deletes the cookie and redirects, so the next request has no credential and the
 * proxy sends it to the sign-in screen. What this does NOT do — end the session in
 * other browsers — is documented on `lib/session.js endSession`, along with the
 * control that does: revoking the key.
 */
export async function signOut() {
  await endSession();
  redirect("/login");
}
