"use client";

// components/auth/SignInForm.js — the field, the button, and the refusal.
// ==============================================================================
// Spec §3.1; audit UI-052. A client component for two reasons: `useActionState`,
// which carries the refusal back and marks the button busy while the code is checked,
// and the typed value, which lives in client state so that A WRONG CODE DOES NOT WIPE
// THE FIELD. A 60-character code that has to be re-pasted after every typo is the
// defect UI-052 measured; the value was empty 429 ms after submit.
//
// The value is kept by the browser, never returned by the server: the action does not
// echo a rejected credential into the HTML (components/auth/actions.js says why).
// Checked in a browser against a production build on 30 Sep 2026: a refused code comes
// back with the message under the field and the code still in it. (A `next dev` server
// can lose it — its reload after the action is a full page load — so check this on a
// build, not in dev.)
//
// THE MESSAGE BELONGS TO THE FIELD. It is printed under the input, joined to it with
// `aria-describedby`, marks it `aria-invalid`, and clears as soon as the person types
// (components/ui/fields.js). There is no banner above the form.
//
// MASKED, WITH SHOW/HIDE. A live credential to a client's books, typed at the exact
// moment somebody is often sharing their screen with whoever is walking them through
// setup. The eye lets them check a paste without retyping it.
//
// It still works with no JavaScript: a real <form> posting to a Server Action.

import { useActionState, useEffect, useState } from "react";

import { Button, Field, IconButton } from "@/components/ui";
import { IconEye, IconEyeOff } from "@/components/shell/icons";

import { signIn } from "./actions";
import { SIGN_IN } from "./copy";

export default function SignInForm({ next = null }) {
  const [state, action, pending] = useActionState(signIn, null);
  const [value, setValue] = useState("");
  const [shown, setShown] = useState(false);
  const error = !pending && state && !state.ok ? state.message : null;

  // FOCUS ON A DESK ONLY (WIG: autofocus on desktop; critique r1 #18). On a phone an
  // autofocused field raises the keyboard over the page before the person has read it,
  // so the field is focused after mount only under a fine pointer on a desk-wide window
  // (a phone-width window gets the phone's layout, so it gets the phone's behaviour too).
  // Not the `autoFocus` attribute: that is server-rendered and fires on every device.
  useEffect(() => {
    try {
      if (!window.matchMedia("(pointer: fine) and (min-width: 48rem)").matches) return;
      const field = document.getElementById("accessCode");
      if (field && document.activeElement === document.body) field.focus({ preventScroll: true });
    } catch {
      // No matchMedia: leave focus where the browser put it.
    }
  }, []);

  return (
    <form action={action} className="sign-in-form" noValidate>
      {/* Where the person was when the session ended (lib/return-path.js; verify pass 1
          F10). The action re-checks it, so a hand-edited value can only land on Month-end. */}
      {next ? <input type="hidden" name="next" value={next} /> : null}
      <Field
        id="accessCode"
        name="accessCode"
        label={SIGN_IN.label}
        type={shown ? "text" : "password"}
        autoComplete="current-password"
        spellCheck={false}
        autoCapitalize="off"
        autoCorrect="off"
        value={value}
        onChange={(event) => setValue(event.target.value)}
        error={error}
        reserveError
        trailing={
          <IconButton
            label={shown ? SIGN_IN.hide : SIGN_IN.show}
            pressed={shown}
            onClick={() => setShown((was) => !was)}
            className="field-trailing"
          >
            {shown ? <IconEyeOff /> : <IconEye />}
          </IconButton>
        }
      />
      <Button type="submit" variant="commit" wide busy={pending} busyLabel={SIGN_IN.busy}>
        {SIGN_IN.submit}
      </Button>
    </form>
  );
}
