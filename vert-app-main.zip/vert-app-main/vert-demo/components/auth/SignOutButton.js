"use client";

// components/auth/SignOutButton.js — the way out, inside the account menu.
// ==============================================================================
// A form rather than a link, because signing out is a write: it deletes a cookie
// holding a live credential. A GET that logs you out is a GET any prefetcher, link
// scanner or <img> tag on a page can fire, and "the app signs me out at random" is the
// bug that produces.
//
// It is a full-width row in the account menu (components/shell/AccountMenu.js), with
// the same 44 px height as every other row, so it is not the 39.7 × 14.3 px target
// the hit-targets measurement found in the old rail.

import { signOut } from "./actions";
import { IconSignOut } from "@/components/shell/icons";

export default function SignOutButton() {
  return (
    <form action={signOut} className="sign-out-form">
      <button type="submit" className="row menu-item">
        <IconSignOut />
        <span>Sign out</span>
      </button>
    </form>
  );
}
