// components/shared/EmptyState.js — A REGISTER WITH NOTHING IN IT STILL TEACHES
// ==============================================================================
// Three registers (Exceptions, the Approvals queue, the payout register) each had
// one string for two states that mean opposite things, and one of the two was a
// lie:
//
//   · "Nothing matches this filter."  — drawn when a tenant had NO exceptions at
//     all. A close with nothing left to decide is this product's best outcome,
//     and the screen reported it as a filter that had failed.
//   · the same sentence when a filter really had excluded everything, with no
//     figure for how much was excluded and no way back.
//
// So this takes both, and the caller says which. `total` is the unfiltered count.
// When it is 0 there is no filter to blame and the copy is about the SURFACE —
// what lands here, and what it will mean when it does. When it is not 0 the copy
// names the figure the filter is hiding and hands back the control that clears
// it: an empty table with a live filter and no way out is a dead end a person
// has to guess their way off.
//
// NO COLOUR, DELIBERATELY, AND ESPECIALLY NOT GREEN.
// ------------------------------------------------------------------
// An empty exception queue is tempting to draw as a green success plate. It must
// not be. Green on this app means A HUMAN VERIFIED IT (app/globals.css:56, and
// DESIGN.md states it as the rule never to collapse). Nothing has been verified
// by anybody here — the engine resolved everything it was given, which is the
// violet meaning, and even that overstates it: this is the ABSENCE of work, not
// the completion of it. A success colour on an absence would be the one visual
// claim in the product that no figure stands behind. It is prose in the body
// face, and it says what happened in words.
//
// No icon plate, no illustration, no badge — the same restraint
// `.placeholder` already holds to for a destination this release has not built.

export default function EmptyState({ lead, children, total = 0, onClear = null, clearLabel = "Clear the filters" }) {
  return (
    <div className="empty-state">
      <p className="es-lead">{lead}</p>
      <p className="es-body">{children}</p>
      {/* Only where a filter is actually hiding something. A "clear" control on a
          register that is empty because the tenant is new would clear nothing and
          reveal nothing. */}
      {onClear && total > 0 && (
        <button type="button" className="btn sm es-act" onClick={onClear}>
          {clearLabel}
        </button>
      )}
    </div>
  );
}
