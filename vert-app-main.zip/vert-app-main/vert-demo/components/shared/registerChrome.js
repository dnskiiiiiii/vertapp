// components/shared/registerChrome.js — CHROME IS EARNED BY ROWS
// ==============================================================================
// Measured on vert-platform.vercel.app, 2026-08-18, tenant `vansh-live`:
//
//   · Exceptions put THREE rows behind five dropdowns, a funnel, an export
//     button, a search field, a column of bulk checkboxes and a pager.
//   · Payouts put THREE rows behind a search field, two dropdowns, a view
//     toggle, a funnel, a pager and a per-page control.
//
// In both cases the apparatus for FINDING a row was taller than the rows, and
// every one of those controls could only ever return what was already entirely
// on screen. That is the "chrome overwhelms content" finding in the
// simplification design, and this is the rule that answers it: the filter
// apparatus renders only once a register is big enough that a person has to
// search it rather than read it. The threshold is ten, which is also the
// register's first page size — below one page there is nothing to page through
// and nothing a filter can reveal.
//
// ONE HELPER, TWO REGISTERS, DELIBERATELY. The obvious implementation is
// `rows.length > 10` written once on /payouts and once on /exceptions, and the
// reason it is not that is that two copies of a product decision drift: the day
// one register moves to 25 and the other does not, the two surfaces disagree
// about when a person needs a filter, and neither diff looks wrong on its own.
//
// IT TAKES THE UNFILTERED COUNT, NEVER WHAT THE FILTER LEFT. A register of forty
// rows narrowed to three must keep the controls that narrowed it, or a filter
// would remove its own way back — the same dead end components/shared/
// EmptyState.js exists to close. Passing `filtered.length` here is the single
// edit that reinstates it.

export const CHROME_ROW_THRESHOLD = 10;

/**
 * @param {number} total  the register's whole row count, BEFORE any filter.
 * @returns {boolean}     whether this register has earned its filter chrome.
 */
export function showsRegisterChrome(total) {
  // A count that is not a number is not a register big enough to filter. It
  // returns false rather than throwing, because the honest failure of this
  // helper is a screen with three rows and no dropdowns, not a screen that
  // refuses to render.
  return Number.isFinite(total) && total > CHROME_ROW_THRESHOLD;
}
