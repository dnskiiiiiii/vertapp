import { formatAccounting } from "@/lib/money";

// components/shared/AccountingFigure.js — THE COLUMN, NOT JUST THE STRING
// =========================================================================
// lib/money.js's formatAccounting() is correct as a string ("$150.00" /
// "($150.00)"), but a column of them right-aligned as plain text misaligns:
// the closing paren on a negative row is a real trailing glyph, so it lands
// where a positive row's last digit lands instead, and every negative row's
// digits sit visibly left of the positives above and below it.
//
// This renders the same string split in two — the figure, and the closing
// paren — with the paren always present in the DOM (real on a negative row,
// invisible but equal-width via .num-paren-ph on a positive one). Every
// number in the column now reserves the same trailing slot, so the DIGITS
// set the column's right edge, not the punctuation.
//
// Use this instead of a bare {formatAccounting(cents)} in any table column
// where more than one row's sign can differ — a single stat tile with no
// column to line up against does not need it.
export default function AccountingFigure({ cents }) {
  const text = formatAccounting(cents);
  const neg = text.endsWith(")");
  const body = neg ? text.slice(0, -1) : text;
  return (
    <span className="num">
      {body}
      <span aria-hidden="true" className={neg ? undefined : "num-paren-ph"}>{")"}</span>
    </span>
  );
}
