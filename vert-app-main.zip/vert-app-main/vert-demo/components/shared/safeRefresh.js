"use client";

// components/shared/safeRefresh.js — A BACKGROUND REFRESH THAT NEVER NAVIGATES
// ==============================================================================
// Round-3 D6: while a conversation was working, `page.goto('/connections')` from that
// chat was pulled back to /chat/c-20 sixteen seconds later. The mechanism is Next's
// own fallback (next/dist/client/components/router-reducer/fetch-server-response.js):
// when a `router.refresh()` fetch fails — and the browser CANCELS in-flight fetches
// when the page starts to leave — Next treats the failure as "do a browser navigation
// to the URL I was refreshing", which is the page being left. A refresh nobody asked
// for thereby became a navigation nobody asked for.
//
// So a refresh that runs on its own (a timer, or once on mount) goes through here,
// and is skipped when:
//   · the page is leaving — `beforeunload`/`pagehide` fired (a typed address, a
//     bookmark, page.goto) and no `pageshow` has come back since;
//   · a same-document navigation is pending — the Navigation API's
//     `navigation.transition` is set while a client navigation is under way;
//   · the tab is hidden (nobody is looking; the next visible tick catches up).
// A refresh the person caused (a button) still calls router.refresh() directly.

let leaving = false;
let leavingTimer = null;

if (typeof window !== "undefined") {
  const markLeaving = () => {
    leaving = true;
    // A beforeunload that some other handler cancels would otherwise stop the
    // background refresh for good; after a few seconds the page evidently stayed.
    clearTimeout(leavingTimer);
    leavingTimer = setTimeout(() => {
      leaving = false;
    }, 5000);
  };
  window.addEventListener("beforeunload", markLeaving);
  window.addEventListener("pagehide", markLeaving);
  window.addEventListener("pageshow", () => {
    clearTimeout(leavingTimer);
    leaving = false;
  });
}

/**
 * Why a background refresh must not run now, or null when it may. Pure over its
 * inputs so the rule is testable without a browser.
 */
export function refreshBlockedBy({ leaving: isLeaving, visibility, pendingNavigation }) {
  if (isLeaving) return "leaving";
  if (pendingNavigation) return "navigating";
  if (visibility && visibility !== "visible") return "hidden";
  return null;
}

/** Refresh the route in the background unless that could turn into a navigation. */
export function safeRefresh(router) {
  if (typeof window === "undefined") return false;
  const nav = window.navigation;
  const blocked = refreshBlockedBy({
    leaving,
    visibility: typeof document !== "undefined" ? document.visibilityState : "visible",
    pendingNavigation: Boolean(nav && nav.transition),
  });
  if (blocked) return false;
  router.refresh();
  return true;
}
