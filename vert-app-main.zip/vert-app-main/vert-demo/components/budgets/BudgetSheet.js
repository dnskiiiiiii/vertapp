"use client";

// components/budgets/BudgetSheet.js — THE BUDGETS VERT FOUND, AND THE WAY TO BRING ONE IN
// ==============================================================================
// Build plan §20.0 decisions 2–4 and 12, §20.3 F-BUD. A right sheet, anchored to the
// control that opened it (`origin`: the A1 answer's "Budgets" chip, a question card, or
// Month-end), with no route and no nav entry. In order:
//
//   1. The budgets found, newest year first: name, year (only when the name doesn't
//      already say it), source, version, and the marks in words ("Chosen for this
//      year", "Inactive", "Balance sheet: not compared"). Every budget the ledger lookup
//      found is listed: an imported one as its version, one not imported yet as a row
//      that offers Import, and a count the list can't back is said in words. A
//      balance-sheet budget is listed and declined with the engine's sentence; it is
//      never offered Choose. Under each imported budget, its tie-out line names its
//      right-hand source ("Budget $712,920.00 · QBO $712,920.00 ✓"), read from
//      GET /budgets/{id}; one that couldn't be read says so.
//   2. Import: from the connected ledger (QuickBooks, or Xero, named by the API and never
//      by this file; model.js `ledgerWord`), or from an xlsx already attached in this
//      conversation. A Xero budget is a row per financial year, and a tracking one is
//      listed with the engine's sentence and offered nothing.
//      With no file attached the sheet says how to bring one, and draws no file button.
//   3. The status of the last press, in words: "Import started in this conversation",
//      or the engine's refusal.
//
// FLUSH, LIKE THE SKILL SHEET (G4 eval-r1 #8). The sheet is the kit's right Sheet with
// its own header (title, Close) and nothing else around it: an inner fixed card (the
// chat's floating `chat-sheet-right`) drew a second, narrower panel inside the kit's
// white layer and left a blank band across the conversation at 1440.
//
// ONE COMMIT, NAMED FOR THE SELECTION (design-fix-2 DA2-053, 10 Oct 2026). The audit saw
// "Import" three ways (a heading, a button per row, a global green button not tied to any
// row), up to three chips per row and a typed tick after the figures. Now the list is a
// radio-list table, Name · Source (its mark) · Fiscal year · Total · Status in plain
// words; selecting a row names the foot's one commit ("Import “FY26 Reforecast”", or
// "Use “Budget FY2027”" for an imported version), and with nothing selected it stays
// "Import from <the ledger>" ("Import from QuickBooks"). The type glyph in the head is the pane's (DeskPane).
// A press starts a turn (decision 2) and never persists a version from here; the rules
// live in ./model.js.

import { useEffect, useId, useState } from "react";
import Link from "next/link";
import { Button, Meta, SourceLogo } from "@/components/ui";
import { getBudget, listBudgets } from "@/lib/budgets";
import PaneOrSheet from "@/components/chat/results/DeskPane";
import {
  NO_SESSION_WORDS,
  budgetRows,
  commitFor,
  importableFiles,
  ledgerImportRequest,
  ledgerPhrase,
  ledgerWord,
  lookupLine,
  pressChoose,
  pressImport,
  tieOutsById,
  totalWords,
  unlistedLine,
  unreadTieOut,
} from "./model";

import { IconCaretRight, IconRadioOff, IconRadioOn } from "@/components/ui/icons";
const COULD_NOT_READ = "Vert couldn't list the budgets just now. Nothing was changed.";

/** Why the commit waits while nothing is chosen (D10). */
export const CHOOSE_FIRST = "Choose a budget above first.";

/** At most this many tie-outs are read per open; past it a row says its tie-out wasn't read. */
export const TIE_OUT_READS = 20;
const TIE_OUT_UNREAD = "Vert couldn't read this budget just now.";

/**
 * Each listed budget's tie-out, from GET /budgets/{id} (lib/budgets.js `getBudget`):
 * the list itself carries none, and a sheet that shows a version without its tie-out
 * shows a figure nobody checked. A budget whose read fails, or past the cap, carries
 * `tieOutUnread` (why), so its row says "Tie-out not read", never nothing.
 */
export async function withTieOuts(budgets, detail = getBudget) {
  return Promise.all(
    budgets.map(async (b, i) => {
      if (!b || typeof b.budgetId !== "string" || (b.tieOut && typeof b.tieOut.words === "string")) return b;
      if (i >= TIE_OUT_READS) return { ...b, tieOutUnread: "too many budgets to read at once." };
      try {
        const got = await detail(b.budgetId);
        if (got && got.ok && got.budget && got.budget.tieOut) return { ...b, tieOut: got.budget.tieOut };
        return { ...b, tieOutUnread: (got && got.ok && "the engine sent no tie-out for it.") || (got && got.message) || TIE_OUT_UNREAD };
      } catch {
        return { ...b, tieOutUnread: TIE_OUT_UNREAD };
      }
    })
  );
}

/** Read the budget list through lib/budgets.js. Never throws; a refusal is words. */
export async function readBudgets(read = listBudgets, detail = getBudget) {
  try {
    const result = await read();
    if (result && result.ok && Array.isArray(result.budgets)) {
      return {
        ok: true,
        budgets: await withTieOuts(result.budgets, detail),
        lookups: result.lookups || null,
        ledgerBudgets: Array.isArray(result.ledgerBudgets) ? result.ledgerBudgets : null,
        words: null,
      };
    }
    return { ok: false, budgets: null, lookups: null, ledgerBudgets: null, words: (result && result.message) || COULD_NOT_READ };
  } catch {
    return { ok: false, budgets: null, lookups: null, ledgerBudgets: null, words: COULD_NOT_READ };
  }
}

/**
 * The tie-out under a budget's name, as one plain ink-3 line (design-fix-2 DA2-053; critic
 * r1 F15): no tick, no middle dots, no "QBO". The engine's words are kept and only spelled
 * for reading ("Budget $712,920.00 · QBO $712,920.00" reads "Budget $712,920.00,
 * QuickBooks $712,920.00"); a tie the engine called equal says so to a screen reader; one
 * it called unequal is said in the problem ink with what to do. Nothing is added up here.
 */
export function tieOutWords(words) {
  return String(words || "").replace(/\s+\u00b7\s+/g, ", ").replace(/\bQBO\b/g, "QuickBooks");
}

function TieOut({ line }) {
  return (
    <p className={`budget-tieout t-footnote ${line.ok ? "budget-tieout-ok" : "budget-tieout-off"}`} translate="no">
      <span className="budget-tieout-words">{tieOutWords(line.words)}</span>
      {line.ok ? <span className="sr-only"> (ties)</span> : null}
      {line.note ? <span className="budget-tieout-note"> {line.note}</span> : null}
    </p>
  );
}

/** The heading over a row's facts (U60): they are notes about the budget, not a status. */
export const NOTES_HEADING = "Notes";

/** What a row says in its Notes column: plain words, never a chip and never a tick. */
function statusWords(row) {
  return [row.version, ...row.marks];
}

/**
 * One budget as a row of the radio list (design-fix-2 DA2-053): Name, Source (its mark),
 * Fiscal year, Total, Status. A row Vert can act on (Import one the ledger holds, or
 * Choose an imported version) is a radio: selecting it names the sheet's one commit
 * ("Import “FY26 Reforecast”"). A row there is nothing to do with (the chosen one, a
 * balance-sheet budget) keeps its slot empty, so every name starts on one line.
 */
function BudgetRow({ row, tieOut, unread, selectable, selected, onSelect, name }) {
  const total = totalWords(tieOut);
  const status = statusWords(row);
  const id = `budget-${row.key}`.replace(/[^A-Za-z0-9_-]/g, "-");
  const cells = (
    <>
      <span className="budget-cell budget-cell-pick" aria-hidden="true">
        {selectable ? selected ? <IconRadioOn size={16} className="budget-radio budget-radio-on" /> : <IconRadioOff size={16} className="budget-radio" /> : null}
      </span>
      <span className="budget-cell budget-cell-name">
        <span className="budget-name" translate="no">
          {row.name}
        </span>
      </span>
      <span className="budget-cell budget-cell-source">
        <SourceLogo source={row.source === "File" ? "excel" : row.source} size={16} />
        <span>{row.source}</span>
      </span>
      <span className="budget-cell budget-cell-fy num">{row.fyWords}</span>
      <span className="budget-cell budget-cell-total num" translate="no">
        {total || <span className="budget-total-none">{row.kind === "ledger" ? <span className="sr-only">No total until it is imported</span> : "Not read"}</span>}
      </span>
      <span className="budget-cell budget-cell-status">
        {status.map((w) => (
          <Meta key={w} className="budget-status-word">
            {w}
          </Meta>
        ))}
      </span>
      {row.declined || tieOut || unread ? (
        <span className="budget-cell budget-cell-detail">
          {row.declined ? <span className="budget-declined t-footnote">{row.declined}</span> : null}
          {tieOut ? <TieOut line={tieOut} /> : unread ? <span className="budget-tieout budget-tieout-unread t-footnote">{unread}</span> : null}
        </span>
      ) : null}
    </>
  );
  return (
    <li
      className="budget-row"
      data-budget={row.budgetId || undefined}
      data-ledger-budget={row.kind === "ledger" ? row.qboId || "" : undefined}
      data-selected={selected ? "true" : undefined}
      data-selectable={selectable ? "true" : undefined}
    >
      {selectable ? (
        <label className="budget-row-hit" htmlFor={id}>
          <input
            type="radio"
            className="sr-only budget-radio-input"
            id={id}
            name={name}
            value={row.key}
            autoComplete="off"
            checked={selected}
            onChange={() => onSelect(row.key)}
            aria-label={`${row.canImport ? "Import" : "Choose"} ${row.label}`}
          />
          {cells}
        </label>
      ) : (
        <div className="budget-row-hit">{cells}</div>
      )}
    </li>
  );
}

export default function BudgetSheet({
  open = true,
  onClose,
  origin = null,
  sessionId = null,
  budgets: given,
  imported = null,
  documents = null,
  status: initialStatus = null,
  read = listBudgets,
  importAction,
  chooseAction,
  lookups: givenLookups = null,
  ledgerBudgets: givenLedger = null,
  ledgerName = null,
  onStarted = null,
}) {
  const [budgets, setBudgets] = useState(Array.isArray(given) ? given : null);
  const [readFailed, setReadFailed] = useState(null);
  const [lookups, setLookups] = useState(givenLookups);
  const [ledger, setLedger] = useState(givenLedger);
  const [status, setStatus] = useState(initialStatus);
  const [busy, setBusy] = useState(null);
  const [selected, setSelected] = useState(null);
  const groupName = `budget-pick-${useId().replace(/[^A-Za-z0-9_-]/g, "")}`;

  useEffect(() => {
    if (Array.isArray(given)) {
      setBudgets(given);
      return undefined;
    }
    if (!open) return undefined;
    let live = true;
    readBudgets(read).then((result) => {
      if (!live) return;
      if (result.ok) {
        setBudgets(result.budgets);
        setLookups(result.lookups);
        setLedger(result.ledgerBudgets);
      } else setReadFailed(result.words);
    });
    return () => {
      live = false;
    };
  }, [given, open, read]);

  // Which ledger this sheet imports from, in one word (model.js `ledgerWord`): the
  // connected ledger's name, else the engine's, else a stored budget's; null says
  // "your ledger". Never "QuickBooks" to a Xero tenant (16 Oct 2026).
  const ledgerSays = ledgerWord({ ledgerName, lookups, budgets });
  const rows = budgetRows(budgets, ledger, ledgerSays);
  const ties = tieOutsById(imported, budgets);
  const unlisted = budgets === null ? null : unlistedLine(lookups, budgets, ledger);
  const unreadById = new Map((budgets || []).map((b) => [b && b.budgetId, unreadTieOut(b)]));
  const files = importableFiles(documents);
  const lookup = lookupLine(lookups, ledgerName);
  const noSession = typeof sessionId === "string" && sessionId ? null : NO_SESSION_WORDS;
  const inFlight = busy !== null;
  // The one selection, and the commit it names (DA2-053). A key that no longer names an
  // actionable row (the list was read again) selects nothing.
  const picked = rows.find((r) => r.key === selected && (r.canImport || r.canChoose)) || null;
  const commit = commitFor(picked, ledgerSays);
  // Select, then commit (D10; critic r1 F15): while there are rows to choose from and none
  // is chosen, the commit says why it waits instead of importing something unnamed.
  const choosable = rows.some((r) => r.canImport || r.canChoose);
  const waitsForChoice = choosable && !picked ? CHOOSE_FIRST : null;

  async function run(key, press) {
    if (inFlight) return;
    setBusy(key);
    const next = await press();
    setStatus(next);
    setBusy(null);
    // The host follows a turn that started in another conversation (the month's "Import
    // budget"), where its questions will be asked; the line's link is there either way.
    if (next && next.kind === "started" && typeof onStarted === "function") onStarted(next);
  }

  const importQbo = () =>
    run("qbo", () => pressImport({ sessionId, request: { source: "qbo" }, ...(importAction ? { action: importAction } : {}) }));
  const importFile = (doc) =>
    run(`doc:${doc.documentId}`, () =>
      pressImport({ sessionId, request: { source: "document", documentId: doc.documentId }, ...(importAction ? { action: importAction } : {}) })
    );
  const importOne = (row) =>
    run(row.key, () =>
      pressImport({
        sessionId,
        request: ledgerImportRequest(row),
        ...(importAction ? { action: importAction } : {}),
      })
    );
  const choose = (row) =>
    run(`choose:${row.budgetId}`, () =>
      pressChoose({ sessionId, budgetId: row.budgetId, fy: row.fy, ...(chooseAction ? { action: chooseAction } : {}) })
    );

  return (
    // The commit sits in the foot, never under the body's scroll-edge fade (critique r1
    // #17); on a desk, inside a conversation, the whole sheet is a result pane beside the
    // rail (design-pass spec §6.11; PaneOrSheet).
    <PaneOrSheet
      open={open}
      side="right"
      body="budgets"
      title="Budgets"
      onClose={onClose}
      origin={origin || undefined}
      className="budget-sheet-layer"
      footer={
        <div className="budget-actions">
          {files.map((doc) => (
            <Button
              key={doc.documentId}
              variant="secondary"
              busy={busy === `doc:${doc.documentId}`}
              busyLabel="Starting the import…"
              disabledReason={noSession || (inFlight && busy !== `doc:${doc.documentId}` ? "Waiting for the last press." : undefined)}
              onClick={() => importFile(doc)}
            >
              Import {doc.name}
            </Button>
          ))}
          <Button
            variant="commit"
            busy={busy === commit.key}
            busyLabel={commit.busyLabel}
            disabledReason={noSession || (inFlight && busy !== commit.key ? "Waiting for the last press." : undefined) || waitsForChoice || undefined}
            onClick={() => (picked ? (picked.canImport ? importOne(picked) : choose(picked)) : importQbo())}
            data-budget-commit={picked ? picked.key : "qbo"}
          >
            {commit.label}
          </Button>
        </div>
      }
    >
      <div className="budget-sheet" data-view="budget-sheet">

        {status ? (
          <p className={`budget-status budget-status-${status.kind}`} role="status">
            {status.words}
            {status.href ? (
              <>
                {" "}
                <Link className="link" href={status.href} data-budget-open="import">
                  Open it<IconCaretRight className="caret-trailing" />
                </Link>
              </>
            ) : null}
          </p>
        ) : null}

        <section className="budget-section" aria-label="Budgets found">
          {lookup ? (
            <p className={`budget-lookup budget-lookup-${lookup.outcome}`} data-lookup={lookup.outcome}>
              {lookup.words}
            </p>
          ) : null}
          {unlisted ? (
            <p className="budget-lookup budget-unlisted" data-unlisted="">
              {unlisted}
            </p>
          ) : null}
          {budgets === null ? (
            <p className="chat-sheet-note">{readFailed || "Looking for budgets…"}</p>
          ) : rows.length ? (
            <div className="budget-table" role="radiogroup" aria-label="Budgets">
              <div className="budget-head" aria-hidden="true">
                <span className="budget-cell budget-cell-pick" />
                <span className="budget-cell budget-cell-name">Name</span>
                <span className="budget-cell budget-cell-source">Source</span>
                <span className="budget-cell budget-cell-fy">Fiscal year</span>
                <span className="budget-cell budget-cell-total">Total</span>
                {/* Notes, not Status (verify pass 2, U60): the version, "Chosen for this
                    year", "Inactive", "Not imported yet" are facts about a budget, not states
                    of work; the app's status words are Needs you, Vert's working, Waiting
                    and Done, and a column titled Status claimed these were four more. */}
                <span className="budget-cell budget-cell-status">{NOTES_HEADING}</span>
              </div>
              <ul className="budget-list">
                {rows.map((row) => (
                  <BudgetRow
                    key={row.key}
                    row={row}
                    name={groupName}
                    tieOut={row.budgetId ? ties.get(row.budgetId) || null : null}
                    unread={row.budgetId ? unreadById.get(row.budgetId) || null : null}
                    selectable={row.canChoose || row.canImport}
                    selected={Boolean(picked && picked.key === row.key)}
                    onSelect={setSelected}
                  />
                ))}
              </ul>
            </div>
          ) : (
            <p className="chat-sheet-note">No budgets yet. Import one below.</p>
          )}
          <p className="budget-help t-footnote">
            {`Select a budget to import or use it. Vert reads it and asks anything it needs in this conversation; ${ledgerPhrase(ledgerSays)} is only read, never changed.`}
            {files.length ? null : " To import from a spreadsheet, attach the .xlsx in this conversation first."}
          </p>
        </section>
      </div>
    </PaneOrSheet>
  );
}
