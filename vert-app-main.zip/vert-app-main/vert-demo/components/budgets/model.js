// components/budgets/model.js — WHAT THE BUDGET SHEET SAYS, AND WHAT ITS PRESSES DO
// ==============================================================================
// Build plan §20.0 decisions 2–4, §20.3 F-BUD. Pure functions, so every rule the sheet
// carries is tested without a browser (tests/budget-sheet.test.js), and the sheet itself
// only draws what these return.
//
// A BUDGET IMPORT IS A TURN IN A CONVERSATION (decision 2). Import and Choose never
// persist anything from here: each press calls lib/budgets.js with the current
// `sessionId`, the engine appends a user turn pinned to the budget_import template, and
// the questions (phasing, which sheet, unmapped labels) arrive as ordinary question
// cards in that turn. So the only success this sheet can report is "Import started in
// this conversation", and the only failure is the engine's own refusal, in its words.
// A press with no conversation to start in is refused before it is sent, with the
// reason on the button, rather than sent to be refused with a 422.
//
// THE TIE-OUT IS THE ENGINE'S, NOT OURS. "Budget $712,920.00 · QBO $712,920.00 ✓" is
// built in the engine against an independent right-hand side (decision 3: the raw QBO
// total, or the file's own total cell). This module never adds a line up: it shows the
// engine's words and marks a tie only where the engine said `equal: true` (the sheet draws
// the kit's Check, design-fix-2 DA2-053; a typed tick the engine's words carry is
// stripped). A tie-out the engine marked unequal is never marked, even if its words are.

import { importBudget as importAction, chooseBudget as chooseAction } from "@/lib/budgets";
import { isLedgerSource, ledgerSourceName } from "@/lib/connections-shape";
import { sourceKey } from "@/components/ui/SourceLogo";

/** Where a budget came from, in the words an accountant uses. */
export const SOURCE_WORDS = Object.freeze({ qbo: "QuickBooks", xlsx: "File", document: "File" });

/** What a budget from the ledger is called when nothing says which ledger it is. */
const SOME_LEDGER = "Ledger";

/**
 * THE LEDGER THIS SHEET IMPORTS FROM, in one word, or null when nothing says which.
 *
 * WHY IT IS ASKED AT ALL (16 Oct 2026). The sheet said "Import from QuickBooks" and
 * "QuickBooks is only read" to every tenant; since the engine imports Xero budgets too
 * (xero/engine 1363f1a) that was a Xero tenant being told about a ledger they don't
 * have. The engine still takes `source: "qbo"`, which now means "the tenant's connected
 * ledger", so which ledger it is has to be said from facts the API serves, in order:
 *
 *   1. `ledgerName`, the connected ledger's `displayName` (GET /approvals/ledger, read
 *      per tenant). QuickBooks keeps the one word this sheet has always used for it.
 *   2. The engine's own word for the ledger it looked in (`lookups.ledger.where`).
 *   3. A stored budget from a ledger, named from the connections catalogue.
 *
 * Null when none of them says, and every caller then says "your ledger": a vendor this
 * sheet was not told about is never guessed. This file spells no ledger but QuickBooks,
 * which it always has; every other name arrives from the API or the catalogue
 * (tests/claims.test.js).
 */
export function ledgerWord({ ledgerName = null, lookups = null, budgets = null } = {}) {
  const named = typeof ledgerName === "string" ? ledgerName.trim() : "";
  if (named) return sourceKey(named) === "quickbooks" ? SOURCE_WORDS.qbo : named;
  const l = lookups && lookups.ledger;
  const where = l && typeof l.where === "string" ? l.where.trim() : "";
  if (where) return where;
  const stored = (Array.isArray(budgets) ? budgets : []).find((b) => b && isLedgerSource(b.source));
  return stored ? sourceWords(stored.source) : null;
}

/** A stored budget's source in words: the sheet's own, then the catalogue's for a ledger. */
function sourceWords(source) {
  return SOURCE_WORDS[source] || ledgerSourceName(source) || null;
}

export const BALANCE_SHEET_WORDS = "Balance sheet: not compared";
export const INACTIVE_WORDS = "Inactive";
export const CHOSEN_WORDS = "Chosen for this year";
export const NO_SESSION_WORDS = "Open a conversation first: the import runs as a turn in it.";
export const STARTED_WORDS = "Import started in this conversation";
const ANSWER_THERE = "Vert will ask anything it needs there.";
const NOT_SENT = "Nothing was recorded. Try again.";

/** "FY2027". A missing year is said, never guessed from the name (decision 4). */
export function fyWords(fy) {
  return Number.isInteger(fy) ? `FY${fy}` : "Year not stated";
}

/** True for a budget Vert compares: profit and loss only (decision 4). */
export function isComparable(budget) {
  return Boolean(budget) && budget.budgetType !== "BalanceSheet";
}

/**
 * The year beside a budget's name, or null when the name already says that year
 * ("Budget FY2027" is never drawn "Budget FY2027 FY2027", G4 eval-r1 #8). Only the SAME
 * year is redundant: a name that states another year ("FY26 Reforecast", filed by its
 * dates under FY2027) keeps the engine's year beside it, because the two disagree and
 * the person must see which one Vert used.
 */
export function yearShown(name, fy) {
  if (!Number.isInteger(fy)) return fyWords(fy);
  const said = new RegExp(`(^|[^0-9])(FY\\s?)?${fy}([^0-9]|$)`, "i");
  return said.test(String(name || "")) ? null : fyWords(fy);
}

/** The name and, when it adds anything, the year: what a row and its controls are called. */
export function rowLabel(name, fy) {
  const year = yearShown(name, fy);
  return year ? `${name} ${year}` : name;
}

/** "Not imported yet": a ledger budget Vert has found but holds no version of. */
export const NOT_IMPORTED_WORDS = "Not imported yet";

const cleanName = (n) => (typeof n === "string" && n.trim() ? n.trim() : "Unnamed budget");
const sameBudget = (a, b) => cleanName(a.name).toLowerCase() === cleanName(b.name).toLowerCase() && a.fy === b.fy;

/**
 * The ledger's own budgets that Vert has NOT imported, from the engine's
 * `ledgerBudgets` (GET /budgets, alongside `lookups.ledger`). Each one the ledger
 * holds is listed (G4 eval-r1 #8: the sheet said "found 5" and listed 2): an imported
 * one appears once, as its imported row (matched by the engine's `importedBudgetId`,
 * else by name and year from a ledger source), and every other one as a row of its
 * own with its marks, so an inactive or balance-sheet budget is shown and marked,
 * never silently dropped.
 *
 * ONE BUDGET, SEVERAL YEARS (16 Oct 2026). A Xero budget carries no year of its own, so
 * the engine lists it once per financial year, every row with the same `qboId` and the
 * same `importedBudgetId` (the stored id has no year in it). Where the ledger's list
 * holds an id more than once, the id alone cannot say which year was imported, so the
 * imported version must also be for that row's year; a QuickBooks budget, listed once,
 * is matched by its id exactly as before.
 */
export function ledgerEntries(ledgerBudgets, budgets) {
  const imported = (Array.isArray(budgets) ? budgets : []).filter((b) => b && typeof b.budgetId === "string");
  const list = Array.isArray(ledgerBudgets) ? ledgerBudgets : [];
  const seen = new Map();
  for (const l of list) if (l && typeof l.qboId === "string") seen.set(l.qboId, (seen.get(l.qboId) || 0) + 1);
  return list.filter((l) => {
    if (!l || typeof l !== "object") return false;
    const perYear = seen.get(l.qboId) > 1;
    const held = (b) => b.budgetId === l.importedBudgetId && (!perYear || b.fy === l.fy);
    if (typeof l.importedBudgetId === "string" && imported.some(held)) return false;
    return !imported.some((b) => isLedgerSource(b.source) && sameBudget(b, l));
  });
}

/** The mark on a profit-and-loss budget the engine declined anyway (a Xero tracking budget). */
export const DECLINED_WORDS = "Not compared";

/** The engine's own sentence for declining a budget, or null. */
const engineDeclined = (b) => (typeof b.declined === "string" && b.declined.trim() ? b.declined : null);

function marksOf(b, comparable) {
  const marks = [];
  if (b.chosen && comparable) marks.push(CHOSEN_WORDS);
  if (b.active === false) marks.push(INACTIVE_WORDS);
  if (!comparable) marks.push(BALANCE_SHEET_WORDS);
  else if (engineDeclined(b)) marks.push(DECLINED_WORDS);
  return marks;
}

const DECLINED_DEFAULT = "This is a balance-sheet budget. Vert compares profit-and-loss budgets only.";
// A balance-sheet budget is declined with the engine's sentence or this one. A
// profit-and-loss budget is declined only when the engine says so, in its words (the
// ledger list's `declined`: a Xero tracking budget, which budgets one tracking option
// rather than the whole business). Either way it offers nothing.
const declinedOf = (b, comparable) => (comparable ? engineDeclined(b) : engineDeclined(b) || DECLINED_DEFAULT);

/**
 * The rows the sheet lists, newest year first, the chosen one first within its year.
 * Each row carries the marks it shows in words, and whether Choose is offered: never
 * for a balance-sheet budget (it is declined, with the engine's sentence), and never
 * for the one already chosen. `ledgerBudgets` adds the ledger's budgets not imported
 * yet (see ledgerEntries): those offer Import (that one budget), never Choose, since
 * there is no version to choose until it is imported.
 */
export function budgetRows(budgets, ledgerBudgets = null, ledger = null) {
  const list = Array.isArray(budgets) ? budgets.filter((b) => b && typeof b.budgetId === "string") : [];
  const fromLedger = ledgerEntries(ledgerBudgets, list).map((l) => ({ ...l, __ledger: true }));
  const ordered = [...list, ...fromLedger].sort((a, b) => {
    const fa = Number.isInteger(a.fy) ? a.fy : -1;
    const fb = Number.isInteger(b.fy) ? b.fy : -1;
    if (fa !== fb) return fb > fa ? 1 : -1;
    if (Boolean(a.chosen) !== Boolean(b.chosen)) return a.chosen ? -1 : 1;
    if (Boolean(a.__ledger) !== Boolean(b.__ledger)) return a.__ledger ? 1 : -1;
    return String(a.name || "").localeCompare(String(b.name || ""));
  });
  return ordered.map((b) => {
    const comparable = isComparable(b);
    const name = cleanName(b.name);
    const fy = Number.isInteger(b.fy) ? b.fy : null;
    const declined = declinedOf(b, comparable);
    const base = {
      name,
      fy,
      fyWords: fyWords(b.fy),
      yearShown: yearShown(name, b.fy),
      label: rowLabel(name, b.fy),
      marks: marksOf(b.__ledger ? { ...b, chosen: false } : b, comparable),
      declined,
    };
    if (b.__ledger) {
      const qboId = typeof b.qboId === "string" && b.qboId ? b.qboId : null;
      return {
        ...base,
        // The year is part of the key: one Xero budget is a row per financial year.
        key: `ledger:${qboId || name}:${fy ?? "no-year"}`,
        kind: "ledger",
        budgetId: null,
        qboId,
        // The rows carry no source of their own: they are the connected ledger's.
        source: (typeof ledger === "string" && ledger.trim()) || SOME_LEDGER,
        version: NOT_IMPORTED_WORDS,
        canChoose: false,
        canImport: comparable && !declined && Boolean(qboId),
      };
    }
    return {
      ...base,
      key: b.budgetId,
      kind: "imported",
      budgetId: b.budgetId,
      qboId: null,
      source: sourceWords(b.source) || "Source not stated",
      version: Number.isInteger(b.version) ? `Version ${b.version}` : "Version not stated",
      canChoose: comparable && !b.chosen && Number.isInteger(b.fy),
      canImport: false,
    };
  });
}

/**
 * What the ledger holds that the list does not show, in words, or null when the list
 * shows everything the lookup found. "Found 5" over two rows was a count the sheet
 * could not back (G4 eval-r1 #8); when the engine sent no list of the ledger's budgets,
 * the difference is said, never left for the reader to notice.
 */
export function unlistedLine(lookups, budgets, ledgerBudgets = null) {
  const l = lookups && lookups.ledger;
  if (!l || l.outcome !== "found" || !Number.isInteger(l.count) || l.count < 1) return null;
  const list = Array.isArray(budgets) ? budgets.filter((b) => b && typeof b.budgetId === "string") : [];
  const fromLedger = Array.isArray(ledgerBudgets)
    ? list.filter((b) => isLedgerSource(b.source)).length + ledgerEntries(ledgerBudgets, list).length
    : list.filter((b) => isLedgerSource(b.source)).length;
  const missing = l.count - fromLedger;
  if (missing <= 0) return null;
  const them = missing === 1 ? "1 of them isn't" : `${missing} of them aren't`;
  return `${them} imported yet, so not listed here.`;
}

/**
 * One tie-out line from the engine's `artifact.budget.tieOut`, or null when there is
 * none. `ok` is the engine's `equal` and nothing else; a tick in the engine's words is
 * removed here, so only `ok` (drawn as the kit's Check) ever says it ties.
 */
export function tieOutLine(tieOut) {
  if (!tieOut || typeof tieOut.words !== "string" || !tieOut.words.trim()) return null;
  const words = tieOut.words.replace(/\s*✓\s*$/u, "").trim();
  const equal = tieOut.equal === true;
  return {
    ok: equal,
    words,
    source: typeof tieOut.rightSource === "string" ? tieOut.rightSource : null,
    // An unread right side is not a difference: its words already say "not read" and
    // why, and calling it "doesn't tie" would claim a measurement Vert never made.
    note: equal || /\bnot read\b/.test(words) ? null : "This import doesn't tie to its source, so check the difference before relying on it.",
  };
}

/**
 * The tie-outs, by budget id: from the budget cards the conversation holds
 * (`imported`), and from each listed budget's own `tieOut` (GET /budgets/{id}, read by
 * readBudgets). A card in the conversation wins: it is the import turn's own record.
 */
export function tieOutsById(imported, budgets = null) {
  const out = new Map();
  for (const b of Array.isArray(budgets) ? budgets : []) {
    if (!b || typeof b.budgetId !== "string") continue;
    const line = tieOutLine(b.tieOut);
    if (line) out.set(b.budgetId, line);
  }
  for (const item of Array.isArray(imported) ? imported : []) {
    const budget = item && (item.budget || item);
    if (!budget || typeof budget.budgetId !== "string") continue;
    const line = tieOutLine(budget.tieOut);
    if (line) out.set(budget.budgetId, line);
  }
  return out;
}

/**
 * The budget's own total for the Total column, as the engine wrote it at the head of its
 * tie-out ("Budget $712,920.00 · QBO …" gives "$712,920.00"), or null when there is no
 * tie-out or it doesn't open that way. Read from the engine's words, never added up.
 */
export function totalWords(line) {
  const words = line && typeof line.words === "string" ? line.words : "";
  const m = /^Budget\s+(\S*\d[\d,]*(?:\.\d+)?)/u.exec(words);
  return m ? m[1] : null;
}

/**
 * The sheet's one commit, named for the selection (design-fix-2 DA2-053): a ledger budget
 * not imported yet is "Import “<name>”", an imported version is "Use “<name>”", and with
 * nothing selected it is the plain "Import from <the ledger>" ("Import from QuickBooks";
 * `ledgerWord`, and "your ledger" when nothing says which). `key` matches the busy key
 * the sheet sets while that press is in flight.
 */
export function commitFor(row, ledger = SOURCE_WORDS.qbo) {
  if (row && row.canImport) return { key: row.key, label: `Import \u201c${row.label}\u201d`, busyLabel: "Starting the import…" };
  if (row && row.canChoose) return { key: `choose:${row.budgetId}`, label: `Use \u201c${row.label}\u201d`, busyLabel: "Choosing…" };
  return { key: "qbo", label: `Import from ${ledgerPhrase(ledger)}`, busyLabel: "Starting the import…" };
}

/** The ledger as a sentence names it: its word, or "your ledger". */
export function ledgerPhrase(ledger) {
  return typeof ledger === "string" && ledger.trim() ? ledger.trim() : "your ledger";
}

/**
 * What Import on one of the ledger's budgets sends: `source: "qbo"` (the engine's word
 * for "the tenant's connected ledger", whichever it is), the ledger's own id for the
 * budget (`qboId`; a Xero BudgetID for a Xero tenant) and the row's year, which is how
 * the engine tells one year of a Xero budget from another.
 */
export function ledgerImportRequest(row) {
  return { source: "qbo", qboId: row.qboId, ...(Number.isInteger(row.fy) ? { fy: row.fy } : {}) };
}

/** "Tie-out not read: <why>" for a listed budget whose tie-out couldn't be read. */
export function unreadTieOut(budget) {
  const why = budget && typeof budget.tieOutUnread === "string" && budget.tieOutUnread.trim() ? budget.tieOutUnread.trim() : null;
  return why ? `Tie-out not read: ${why}` : null;
}

/** The conversation an import runs in, as a link this app serves. */
export function conversationHref(sessionId) {
  return typeof sessionId === "string" && /^[A-Za-z0-9_.:-]{1,200}$/.test(sessionId) ? `/chat/${encodeURIComponent(sessionId)}` : null;
}

/**
 * The status line after a press, from the action's answer. Never claims more than it got.
 *
 * WHERE THE TURN RUNS. The engine runs every import in the month's "Import budget"
 * conversation (vert_api/routers/budgets.py `_import_conversation`), so a press from any
 * other conversation starts its turn THERE. The line then says so and carries the way to
 * it (`href`): the questions are asked in that conversation, and a line saying "started
 * in this conversation" while nothing appeared here would send the person looking in the
 * wrong place. Pressed from the import conversation itself, there is nowhere to go.
 */
export function statusFrom(result, verb = "import", currentSessionId = null) {
  if (result && result.ok === true && typeof result.turnId === "string" && result.turnId) {
    const sessionId = typeof result.sessionId === "string" && result.sessionId ? result.sessionId : null;
    const elsewhere = Boolean(sessionId && currentSessionId && sessionId !== currentSessionId);
    const lead = elsewhere
      ? verb === "choose"
        ? "Choice sent to the Import budget conversation"
        : "Import started in the Import budget conversation"
      : verb === "choose"
        ? "Choice sent to this conversation"
        : STARTED_WORDS;
    return {
      kind: "started",
      words: `${lead}. ${ANSWER_THERE}`,
      sessionId,
      turnId: result.turnId,
      href: elsewhere ? conversationHref(sessionId) : null,
    };
  }
  const message = result && typeof result.message === "string" && result.message.trim() ? result.message.trim() : NOT_SENT;
  return { kind: "refused", words: message, sessionId: null, turnId: null, href: null };
}

/**
 * Press Import. `request` is `{source: "qbo"} | {source: "document", documentId, sheet?}`.
 * Without a session it is not sent. The action never throws (lib/budgets.js), but a
 * transport that does is still a refusal in words, never a silent nothing.
 */
export async function pressImport({ sessionId, request, action = importAction }) {
  if (typeof sessionId !== "string" || !sessionId) return { kind: "refused", words: NO_SESSION_WORDS, sessionId: null, turnId: null, href: null };
  let result;
  try {
    result = await action({ sessionId, ...request });
  } catch {
    result = null;
  }
  return statusFrom(result, "import", sessionId);
}

/** Press Choose on a row. Same rules as Import. */
export async function pressChoose({ sessionId, budgetId, fy, action = chooseAction }) {
  if (typeof sessionId !== "string" || !sessionId) return { kind: "refused", words: NO_SESSION_WORDS, sessionId: null, turnId: null, href: null };
  let result;
  try {
    result = await action({ sessionId, budgetId, fy });
  } catch {
    result = null;
  }
  return statusFrom(result, "choose", sessionId);
}

/** The xlsx files attached in this conversation, the only files Import can name. */
export function importableFiles(documents) {
  return (Array.isArray(documents) ? documents : []).filter(
    (d) => d && typeof d.documentId === "string" && /\.xlsx$/i.test(String(d.name || ""))
  );
}

/**
 * The ledger lookup's line ("Looked for budgets in QuickBooks: found none"), in the
 * engine's words, or null when the engine sent none. `{{ledger}}` is the ledger's name.
 * An `unchecked` lookup keeps its reason: Vert couldn't look, which is not "none".
 */
export function lookupLine(lookups, ledgerName = null) {
  const l = lookups && lookups.ledger;
  if (!l || typeof l.words !== "string" || !l.words.trim() || !["found", "none", "unchecked"].includes(l.outcome)) return null;
  return { outcome: l.outcome, words: l.words.replace(/\{\{\s*ledger\s*\}\}/g, ledgerName || "the ledger") };
}
