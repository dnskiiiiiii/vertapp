"use client";

// components/budgets/sheet-context.js — HOW A CONTROL IN THE CONVERSATION OPENS THE BUDGET SHEET
// ==============================================================================
// Build plan §20.0 decision 12: the budget sheet has no route and no nav entry; it is
// opened from the conversation ("Choose a budget", the answer's next action) and from
// Month-end. The conversation view (components/chat/ConversationView.js) provides
// `{ open(trigger) }`; a next action asks for it here, so no component between them has
// to pass a handler down. Outside a conversation there is no provider and the context
// is null: the control then links to the conversation at `?sheet=budgets`, which opens
// the sheet on arrival, or draws nothing (no false affordance).

import { createContext, useContext } from "react";

export const BudgetSheetContext = createContext(null);

/** The conversation's budget sheet, or null where there is none. */
export function useBudgetSheet() {
  return useContext(BudgetSheetContext);
}
