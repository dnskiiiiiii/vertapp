"use client";

// components/home/newTask.js — "NEW TASK" ON THE HOMEPAGE, BEHIND ONE FUNCTION
// ==============================================================================
// The board's header has a New task button. It opens the shell's one new-task form
// (components/month/NewTaskProvider.js: presets, the person's own description, Once or
// Every month), grown from the button that was pressed and carrying the month's groups.
// The return shape is the board's contract and stays as it was:
//
//   const { open, available, element } = useNewTask({ month, period, viewer });
//   open(triggerElement)   opens the form, anchored to what was pressed
//   available              false where a task cannot be made
//   element                always null: the form is mounted once, in AppShell
//
// Nothing is sent until the person presses the form's own commit.

import { useNewTask as useNewTaskForm } from "@/components/month/NewTaskProvider";

export function useNewTask({ month, period } = {}) {
  const { openNewTask, available } = useNewTaskForm();
  const groups = month && Array.isArray(month.groups) ? month.groups : undefined;

  function open(trigger) {
    openNewTask({ origin: trigger || undefined, period, ...(groups ? { groups } : {}) });
  }

  return { open, available, element: null };
}
