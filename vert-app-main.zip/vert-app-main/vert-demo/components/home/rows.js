// components/home/rows.js — THE ORCHESTRATION BOARD, FROM THE PAYLOAD
// ==============================================================================
// Founders' meeting, 22 Oct 2026: the homepage goes back to "the actual original design,
// which was the orchestration agents, where we have the rows right here and you can see
// what agents are performing, what agents need clarification and what tasks are done"
// (vert-v1 app/workflows, "Orchestrate the close like a board"). Pure functions from what
// Month-end already reads to what the board (Board.js) draws:
//
//   · the month (`GET /close/{period}`): one row per task, in the engine's order, under
//     the word the engine gave it — nothing here decides a status (lib/status.js);
//   · each needs-you task's open cards and questions (`itemsByTask`, read by app/page.js
//     for the checklist's cards anyway): the first one is the row's line;
//   · each read conversation's latest run (`runs`, by session id; runOf below): the step
//     a working task is on, and its steps for the mini bar;
//   · the sidebar's conversation list (`conversations`, the shell's own read): when each
//     row last moved.
//
// EVERY ROW IS THE PAYLOAD'S (staging w39 check, 4 Nov 2026). The board used to add a
// row of its own for each task conversation of the month on no checklist row (an
// account's own rec, a task run on demand, an entry asked for in the chat), read from
// the sidebar's list, and the header counted none of them: October read "5 need you ·
// 5 done of 15" over 8 rows under Needs you. The engine now lists those conversations
// in `tasks` (each marked `beside`, keyed by its conversation) and counts them, so the
// board draws the payload's rows and nothing else, and every row drawn is counted.
//
// NOTHING IS COUNTED HERE (UI-001). The summary is the payload's `counts`, in words; a
// row's count is the task's own `decisions`; a group carries no number at all.
//
// (Named rows.js, not board.js: on a case-insensitive disk board.js IS Board.js.)

import { bindFigures } from "@/lib/agent/events";
import { problemSentence } from "@/lib/agent/words";
import { formatMoney, metaLine } from "@/lib/format";
import { canStartHeld, decisionsWord, monthName, monthState, recursMonthly, rowFigureOf, taskKey, verdictLine } from "@/components/month/model";
import { listableTasks } from "@/components/month/GroupBy";

/** The four groups, in the order the board draws them, each keyed by its status word. */
export const BOARD_GROUPS = Object.freeze([
  Object.freeze({ key: "working", word: "Vert's working", label: "Working now", empty: "Nothing running right now." }),
  Object.freeze({ key: "needs", word: "Needs you", label: "Needs you", empty: "Nothing needs you." }),
  Object.freeze({ key: "waiting", word: "Waiting", label: "Waiting", empty: null }),
  Object.freeze({ key: "done", word: "Done", label: "Done", empty: null }),
]);

//: The group a month that hasn't started lists its tasks under.
export const NOT_STARTED_LABEL = "Not started";

//: What a row says when the payload and its run give it no words of their own.
const STATUS_SENTENCE = Object.freeze({
  "Needs you": "Has something for you to decide",
  "Vert's working": "Working on it now",
  Waiting: "Waiting to continue",
  Done: "Finished",
});

function said(text) {
  return typeof text === "string" && text.trim() ? text.trim() : null;
}

function isCount(n) {
  return typeof n === "number" && Number.isInteger(n) && n >= 0;
}

/**
 * Engine prose with its `{{fig:ref}}` placeholders bound to the event's own figures, as
 * one line of text. A figure the event did not measure is said as "an amount", never
 * as a number nobody read. The money is the engine's cents, formatted, never worked out.
 */
export function plainLine(text, figures = null) {
  if (!said(text)) return null;
  let out = "";
  for (const part of bindFigures(text, figures)) {
    if (part.t === "text") out += part.v;
    else if (part.figure && typeof part.figure.cents === "number" && Number.isFinite(part.figure.cents) && part.figure.measured !== false) out += formatMoney(part.figure.cents);
    else out += "an amount";
  }
  return out.replace(/\s+/g, " ").trim() || null;
}

/* ── the run, from its own events ──────────────────────────────────────────── */

const TERMINAL = new Set(["needs_you", "waiting", "done"]);

/**
 * The latest run of one conversation: `{ steps: [{label, done}], running, current,
 * verdict, summary, at, lastSeq }`, or null when the events hold no run. A run starts at
 * its `run_state: working`; its steps are the tool calls after that, each done once its
 * result is in or the run has ended (a terminal `run_state`). `current` is the step it is
 * on while running. Only the latest run counts: an earlier one's steps are history.
 * Pure.
 */
export function runOf(events) {
  if (!Array.isArray(events) || !events.length) return null;
  const list = events.filter((e) => e && typeof e === "object").sort((a, b) => (a.seq || 0) - (b.seq || 0));
  let start = -1;
  list.forEach((e, i) => {
    if (e.type === "run_state" && e.payload && e.payload.state === "working") start = i;
  });
  if (start < 0) return null;
  const run = list.slice(start + 1);
  const answered = new Set(run.filter((e) => e.type === "tool_result" && e.payload && e.payload.callId != null).map((e) => e.payload.callId));
  const end = run.find((e) => e.type === "run_state" && e.payload && TERMINAL.has(e.payload.state)) || null;
  const steps = run
    .filter((e) => e.type === "tool_call" && e.payload)
    .map((e) => ({ label: said(e.payload.label) || "A step", done: Boolean(end) || answered.has(e.payload.callId) }));
  const answer = [...run].reverse().find((e) => e.type === "assistant_text" && e.payload && said(e.payload.verdict)) || null;
  const open = steps.filter((s) => !s.done);
  const last = list[list.length - 1];
  return {
    steps,
    running: !end,
    current: end ? null : open.length ? open[open.length - 1].label : steps.length ? steps[steps.length - 1].label : null,
    verdict: answer ? plainLine(answer.payload.verdict, answer.payload.figures) : null,
    summary: end ? said(end.payload.summary) : null,
    at: (end && end.at) || (last && last.at) || null,
    lastSeq: last && Number.isInteger(last.seq) ? last.seq : null,
  };
}

/**
 * The steps in words, for the mini bar's accessible name: "Step 2 of 2 so far, running",
 * "3 steps, all done". Null with no steps. Pure.
 */
export function stepsWords(run) {
  const steps = run && Array.isArray(run.steps) ? run.steps : [];
  if (!steps.length) return null;
  const n = steps.length;
  if (run.running) return `Step ${n} of ${n} so far, running`;
  return n === 1 ? "1 step, done" : `${n} steps, all done`;
}

/* ── one row ───────────────────────────────────────────────────────────────── */

/**
 * The first open item's words: a question's title, a card's proposal. A plan's card
 * names whose plan it is ("Start the Fixed assets plan?"), as its closed row does
 * (NeedsYouList decisionRowText): the engine's "Start this plan?" names no task.
 */
function firstItemLine(items, title = null) {
  const first = Array.isArray(items) ? items.find((i) => i && (i.type === "question" || i.type === "action")) : null;
  if (!first) return null;
  if (first.type === "question") return plainLine(first.question && first.question.title, first.question && first.question.figures);
  const a = first.action || {};
  if (a.kind === "plan" && said(title)) return `Start the ${said(title)} plan?`;
  return plainLine(a.proposal, a.figures);
}

function lowerFirst(sentence) {
  return /^Vert\b/.test(sentence) ? sentence : sentence.replace(/^./, (c) => c.toLowerCase());
}

/**
 * The row's one line, by its state (pure):
 *   a problem   "Couldn't finish: …" — the engine's code in words
 *   not started what Start will lead to (the engine's `preview.line`)
 *   Needs you   the first open question or decision, else the engine's line
 *   working     the step it is on, else the engine's line
 *   Waiting     the engine's line ("After the payout breaks and the bank rec")
 *   Done        the engine's line ("0 of 4 match the bank"), else the run's verdict
 * and, when none of those has words, the status's own short sentence.
 */
export function rowLine(task, { items = null, run = null, notStarted = false } = {}) {
  if (task.problem && typeof task.problem === "object") return `Couldn't finish: ${lowerFirst(problemSentence(task.problem.code))}`;
  if (notStarted) return said(task.preview && task.preview.line) || said(task.line) || "Runs when the month is started";
  const line = said(task.line);
  if (task.status === "Needs you") return firstItemLine(items, task.title) || line || STATUS_SENTENCE[task.status];
  if (task.status === "Vert's working") return (run && run.running && run.current) || line || STATUS_SENTENCE[task.status];
  if (task.status === "Done") return line || (run && run.verdict) || STATUS_SENTENCE.Done;
  return line || STATUS_SENTENCE[task.status] || null;
}

/**
 * The row's one action, or null: "Run again" for a run that couldn't finish (its
 * template is what runs it again), "Start" for a task made with Create, "Answer" for a
 * row that needs you, "Open" for any other row with a conversation. A row with no conversation opens nothing. Pure.
 */
export function rowAction(row) {
  if (!row) return null;
  if (row.problem && row.template) return { kind: "run_again", label: "Run again" };
  // A person's task made with Create waits for Start (the engine's `held`): its row's
  // action is the conversation's own Start, never Open (walkthrough, 27 Oct 2026).
  if (row.held && row.taskId) return { kind: "start", label: "Start" };
  if (!row.href) return null;
  if (row.status === "Needs you") return { kind: "answer", label: "Answer" };
  return { kind: "open", label: "Open" };
}

/**
 * The run whose steps the row draws as a bar: one that is running, or one that took more
 * than one step. A finished one-step run's bar would be a single full segment that says
 * nothing the word beside it doesn't. Pure.
 */
function barOf(run) {
  if (!run || !Array.isArray(run.steps) || !run.steps.length) return null;
  return run.running || run.steps.length > 1 ? run : null;
}

function hrefOf(sessionId) {
  return typeof sessionId === "string" && sessionId ? `/chat/${encodeURIComponent(sessionId)}` : null;
}

function timeOf(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const ms = Date.parse(value);
    return Number.isFinite(ms) ? ms : null;
  }
  return null;
}

/**
 * Every row of the board: the payload's rows, in its order — the checklist's, the
 * person's tasks, then the task conversations beside the checklist (`beside`: started
 * from chat, an account's own rec), which the payload counts like any row. The sidebar's
 * list gives each row its time only; it adds no row. Pure.
 *
 * Row: `{ key, title, status, notStarted, line, figure, count, steps, at, href,
 * sessionId, template, problem, held, taskId, monthly, fromChat }`.
 */
export function boardRows({ month, itemsByTask = {}, runs = {}, figures = {}, conversations = [] } = {}) {
  const state = monthState(month);
  const tasks = listableTasks(month);
  const listed = new Map((Array.isArray(conversations) ? conversations : []).filter((c) => c && c.id != null).map((c) => [String(c.id), c]));
  const runFor = (sessionId) => (sessionId && runs && runs[sessionId]) || null;
  // A line that only repeats the row's count is said once (walk 2 D19: "1 decision · 1 decision").
  const notCount = (line, count) => (line && count && line.trim().toLowerCase() === count.trim().toLowerCase() ? null : line);
  const rows = tasks.map((task) => {
    const sessionId = typeof task.sessionId === "string" && task.sessionId ? task.sessionId : null;
    const notStarted = state === "not_started" && !sessionId;
    const run = runFor(sessionId);
    // By row (model.js taskKey): two recs beside the checklist share a template.
    const key = taskKey(task);
    const beside = task.beside === true;
    const items = key && itemsByTask ? itemsByTask[key] : null;
    const convo = sessionId ? listed.get(sessionId) : null;
    const figure = key && figures ? rowFigureOf(task, figures[key]) : null;
    const count = !notStarted && task.status === "Needs you" && isCount(task.decisions) && task.decisions > 0 ? decisionsWord(task.decisions) : null;
    return {
      key: key || task.title,
      title: said(task.title) || "A task",
      status: task.status,
      notStarted,
      line: notCount(rowLine(task, { items, run, notStarted }), count),
      // The bank rec's closing balance, as the checklist row states it (S-UI-11).
      figure: figure && said(figure.text) && task.status !== "Needs you" ? figure.text : null,
      count,
      steps: barOf(run),
      at: timeOf(convo && convo.updatedAt) ?? timeOf(task.status === "Done" ? task.doneAt : null),
      href: hrefOf(sessionId),
      sessionId,
      template: typeof task.template === "string" ? task.template : null,
      // A row beside the checklist offers no Run again: its template would run the
      // month's own task, not this conversation's work (an account's own rec).
      problem: !beside && task.problem && typeof task.problem === "object" ? task.problem : null,
      // A person's task made with Create, waiting for Start (model.js canStartHeld).
      held: canStartHeld(task),
      taskId: typeof task.id === "string" && task.id ? task.id : null,
      monthly: recursMonthly(task),
      fromChat: beside,
    };
  });
  return rows;
}

/**
 * The rows under their groups, in BOARD_GROUPS order. Working now and Needs you are
 * drawn even when empty — "Nothing running right now." answers "what is Vert doing" —
 * while an empty Waiting or Done is left out. In a month that hasn't started, the tasks
 * nobody has run are one "Not started" group first, and nothing is said about running
 * or needing you before anything has been started. Pure.
 */
export function boardGroups(rows, month) {
  const list = Array.isArray(rows) ? rows : [];
  const out = [];
  const waiting = list.filter((r) => r.notStarted);
  if (waiting.length) out.push({ key: "not_started", label: NOT_STARTED_LABEL, word: null, rows: waiting, empty: null });
  const started = monthState(month) !== "not_started";
  for (const g of BOARD_GROUPS) {
    const rowsIn = list.filter((r) => !r.notStarted && r.status === g.word);
    if (!rowsIn.length && !(g.empty && started)) continue;
    out.push({ key: g.key, label: g.label, word: g.word, rows: rowsIn, empty: rowsIn.length ? null : g.empty });
  }
  return out;
}

/**
 * The header's one line: "3 need you, 2 working · 5 done of 12", each count the
 * payload's. A count of nothing is left out ("1 needs you · 3 done of 4"); with nothing
 * needing you it says so. A month that hasn't started, was closed or is being re-read
 * says the verdict's words instead. Null when any count is unread: absent, never zero.
 */
export function summaryLine(month, { recounting = false, catchingUp = false } = {}) {
  const state = monthState(month);
  if (state === "not_read") return null;
  if (state !== "running" && state !== "done") return verdictLine(month);
  if (recounting || catchingUp) return verdictLine(month, { recounting, catchingUp });
  const c = month.counts;
  if (![c.needsYou, c.working, c.done, c.total].every(isCount)) return null;
  const parts = [c.needsYou > 0 ? `${c.needsYou} need${c.needsYou === 1 ? "s" : ""} you` : "Nothing needs you"];
  if (c.working > 0) parts.push(`${c.working} working`);
  parts.push(`${c.done} done of ${c.total}`);
  // At most one middle dot (DA2-033, lib/format.js metaLine): "3 need you, 2 working ·
  // 5 done of 12" — the open work, then how far the month has got.
  return metaLine(parts);
}

/** The not-started group's caption: "These run when you start July." Pure. */
export function notStartedCaption(month, period = null) {
  return `These run when you start ${monthName(month, period)}.`;
}
