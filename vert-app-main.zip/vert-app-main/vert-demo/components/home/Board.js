"use client";

// components/home/Board.js — THE ORCHESTRATION BOARD: WHAT VERT IS DOING, WHAT NEEDS YOU
// ==============================================================================
// The homepage's body (founders, 22 Oct 2026; vert-v1's "Orchestrate the close like a
// board"). Every task of the month is one dense row under its group — Working now, Needs
// you, Waiting, Done — and each row reads left to right as one sentence:
//
//   ● Needs you   Resolve payout breaks   4 decisions · Two deposits of $5,000.00 …   ▮▮▯   4m   Answer
//
// the status (glyph AND word: colour never carries it alone), the task, the one line of
// what it needs / is doing / found (components/home/board.js rowLine), the run's steps
// when it has them, when it last moved, and one action. The whole row is one link to the
// task's conversation, where the work is; Run again and Start, the actions that write,
// are their own buttons beside the link, never inside it. A row with no conversation yet (a month
// that hasn't started) opens nothing and says so by not being a link.
//
// LIVE (components/home/live.js): rows take the sidebar's newer reading of their word
// and time, and a working row is followed for its steps; when a word moves the page is
// read again once. In the sample nothing is followed: nobody is working there.
//
// Below 640 px a row stacks: the status and title, then the line, then the steps, the
// time and the action on one line (app/styles/home.css).

import { useEffect, useId, useState } from "react";
import ShellLink from "@/components/shell/ShellLink";
import { useRouter } from "next/navigation";
import { Button, StatusMark } from "@/components/ui";
import { IconRunAgain } from "@/components/ui/icons";
import { startConversation } from "@/lib/agent/actions";
import { callSafely } from "@/lib/decisions";
import { startHeldTask } from "@/lib/tasks";
import { MonthlyTag } from "@/components/month/TaskRow";
import { statusStyle } from "@/lib/status";
import { ageLabel, ageWords } from "@/components/shell/age";
import { useShellReading } from "@/components/shell/live-shell";
import { boardGroups, boardRows, notStartedCaption, rowAction, stepsWords } from "./rows";
import { useLiveBoard } from "./live";

//: The most step segments a row draws; a longer run shows its latest ones.
export const MAX_SEGMENTS = 8;

export default function Board({ month, period, itemsByTask = {}, runs = {}, figures = {}, disabledReason = null }) {
  const shell = useShellReading();
  const served = boardRows({ month, itemsByTask, runs, figures, conversations: shell && Array.isArray(shell.conversations) ? shell.conversations : [] });
  const rows = useLiveBoard(served, { shell, enabled: !disabledReason });
  const groups = boardGroups(rows, month);
  const now = useNow();
  if (!groups.length) return null;
  return (
    <div className="board" data-board="">
      {groups.map((group) => (
        <BoardGroup key={group.key} group={group} month={month} period={period} now={now} disabledReason={disabledReason} />
      ))}
    </div>
  );
}

/** The clock for the rows' ages, read after mount so the server and the browser agree. */
function useNow() {
  const [now, setNow] = useState(null);
  useEffect(() => {
    setNow(Date.now());
    const timer = setInterval(() => setNow(Date.now()), 30_000);
    return () => clearInterval(timer);
  }, []);
  return now;
}

function BoardGroup({ group, month, period, now, disabledReason }) {
  const headId = useId();
  const tone = group.word ? statusStyle(group.word) : "status-neutral";
  return (
    <section className="board-group" data-board-group={group.label} data-tone={tone} data-empty={group.rows.length ? undefined : "true"} aria-labelledby={headId}>
      <h2 className="board-group-head" id={headId}>
        <span className="board-group-label">{group.label}</span>
      </h2>
      {group.key === "not_started" ? <p className="board-group-note t-footnote">{notStartedCaption(month, period)}</p> : null}
      {group.rows.length ? (
        <ul className="board-rows">
          {group.rows.map((row) => (
            <BoardRow key={row.key} row={row} period={period} now={now} disabledReason={disabledReason} />
          ))}
        </ul>
      ) : group.empty ? (
        <p className="board-group-empty t-footnote">{group.empty}</p>
      ) : null}
    </section>
  );
}

function BoardRow({ row, period, now, disabledReason }) {
  const action = rowAction(row);
  const runAgain = action && action.kind === "run_again";
  const start = action && action.kind === "start";
  const own = runAgain || start;
  const age = now === null ? null : ageLabel(row.at, now);
  const inner = (
    <>
      <span className="board-row-status">
        {row.notStarted ? (
          <span className="status-mark status-neutral board-not-started" data-ui="StatusMark">
            <span className="board-glyph-ring" aria-hidden="true" />
            <span className="status-word">Not started</span>
          </span>
        ) : (
          <StatusMark word={row.status} />
        )}
      </span>
      <span className="board-row-title">
        <span className="sr-only"> · </span>
        {row.title}
        {row.monthly ? <MonthlyTag /> : null}
      </span>
      <span className="board-row-line" title={row.line || undefined}>
        <span className="sr-only"> · </span>
        {row.count ? (
          <>
            <span className="board-row-count">{row.count}</span>
            {row.line ? <span className="board-row-sep">{" · "}</span> : null}
          </>
        ) : null}
        {row.line}
        {row.figure ? <span className="board-row-figure num">{` · ${row.figure}`}</span> : null}
      </span>
      <span className="board-row-steps">{row.steps ? <Steps run={row.steps} /> : null}</span>
      <span className="board-row-age t-caption num">
        {age ? (
          <time dateTime={new Date(row.at).toISOString()} title={ageWords(age)}>
            <span className="sr-only">{` · ${ageWords(age)}`}</span>
            <span aria-hidden="true">{age}</span>
          </time>
        ) : null}
      </span>
      {action && !own ? (
        <span className="board-row-act" data-action={action.kind}>
          <span className="sr-only"> · </span>
          {action.label}
        </span>
      ) : (
        <span className="board-row-act" data-vacant="true" />
      )}
    </>
  );
  return (
    <li className="board-row" data-task={row.template || undefined} data-status={row.notStarted ? "not_started" : statusStyle(row.status)} data-linked={row.href ? "true" : undefined} data-moved={row.moved ? "true" : undefined}>
      {row.href ? (
        // On intent, not on sight (walk 2, N11): twelve sighted rows were twelve live
        // conversation renders on every Month-end load (components/shell/ShellLink.js).
        <ShellLink className="board-row-link" href={row.href}>
          {inner}
        </ShellLink>
      ) : (
        <div className="board-row-link">{inner}</div>
      )}
      {runAgain ? <RunAgain row={row} period={period} disabledReason={disabledReason} /> : null}
      {start ? <StartHeld row={row} disabledReason={disabledReason} /> : null}
    </li>
  );
}

/** The run's steps as a mini bar of segments, said in words for a screen reader. */
function Steps({ run }) {
  const steps = run.steps.length > MAX_SEGMENTS ? run.steps.slice(-MAX_SEGMENTS) : run.steps;
  return (
    <span className="board-steps" role="img" aria-label={stepsWords(run)} data-running={run.running ? "true" : undefined}>
      {steps.map((step, i) => (
        <span key={i} className="board-step" data-done={step.done ? "true" : undefined} />
      ))}
    </span>
  );
}

/**
 * Start, for a task made with Create (walkthrough, 27 Oct 2026): the conversation's own
 * Start and the checklist row's (TaskRow.js), `POST /tasks/{id}/start` through
 * lib/tasks.js, on the press only. Its first turn runs inside the request, and the
 * person goes to the conversation to watch it, as the checklist's Start takes them. A
 * refusal says so in place, in the engine's words when it gave some.
 */
function StartHeld({ row, disabledReason }) {
  const router = useRouter();
  const [state, setState] = useState({ state: "idle", message: null });
  async function start() {
    setState({ state: "busy", message: null });
    const result = await callSafely(startHeldTask, row.taskId);
    if (!result || !result.ok) {
      setState({ state: "failed", message: (result && result.message) || "Not started. Nothing was run." });
      return;
    }
    setState({ state: "idle", message: null });
    const session = (result.task && result.task.sessionId) || row.sessionId;
    if (session) router.push(`/chat/${encodeURIComponent(session)}`);
    else router.refresh();
  }
  return (
    <span className="board-row-again" data-start="">
      <Button variant="secondary" size="sm" onClick={start} busy={state.state === "busy"} busyLabel="Starting…" disabled={Boolean(disabledReason)} title={disabledReason || undefined} data-board-start={row.taskId}>
        Start
      </Button>
      {state.state === "failed" ? (
        <span className="board-row-failed t-caption" role="alert">
          {state.message}
        </span>
      ) : null}
    </span>
  );
}

/**
 * Run again, for a run that couldn't finish: `POST /agent/sessions {period, template}`
 * on the press (never on load), then the page is read again. A refusal says so in place.
 */
function RunAgain({ row, period, disabledReason }) {
  const router = useRouter();
  const [state, setState] = useState("idle");
  async function run() {
    setState("busy");
    const result = await callSafely(startConversation, { period, template: row.template });
    if (!result || !result.ok) {
      setState("failed");
      return;
    }
    setState("idle");
    router.refresh();
  }
  return (
    <span className="board-row-again">
      <Button variant="secondary" size="sm" icon={<IconRunAgain />} onClick={run} busy={state === "busy"} busyLabel="Running…" disabled={Boolean(disabledReason)} title={disabledReason || undefined}>
        Run again
      </Button>
      {state === "failed" ? (
        <span className="board-row-failed t-caption" role="alert">
          Not sent. Nothing was recorded.
        </span>
      ) : null}
    </span>
  );
}
