"use client";

// components/home/live.js — THE BOARD'S ROWS, KEPT CURRENT WHILE VERT WORKS
// ==============================================================================
// A board that says "Working now" has to move when the work does, without anyone
// reloading. Two existing patterns do it, and nothing new is asked of the engine:
//
//   1. THE SIDEBAR'S OWN RE-READ (components/shell/live-shell.js). While any
//      conversation is Vert's working, the shell re-reads `GET /agent/sessions` and the
//      month's badge every 15 s from app/api/shell, and AppShell hands that reading down
//      (useShellReading). Each row takes its conversation's newer word and time from it
//      (liveRows): no second poll of the same list.
//   2. THE CONVERSATION'S POLLING FALLBACK (app/api/agent/sessions/[id], the chat's
//      `?after=` read). A row that is Vert's working is followed there every
//      FOLLOW_MS, so its line and its step bar move with the run. At most FOLLOW_MAX
//      rows are followed at once, only while the tab is visible, and never in the
//      sample, which has nobody working.
//
// WHEN A ROW'S WORD CHANGES (a run finished, or started needing you), the page is read
// again ONCE per reason (router.refresh in a transition; never keyed on the month object,
// which every refresh draws anew, so a key on it asked again in a loop) so its line, its question and the header's
// counts come from the same new reading. Never on a timer: live-shell.js says why a
// refresh on a clock is a navigation waiting to be cancelled (eval iter 1, D6).
//
// EVERY READ HERE IS A GET, AND NONE IS SENT ON LOAD UNLESS A ROW IS ALREADY WORKING
// (tests/p0-quiet-page-load.test.js walks this file).

import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { mergeEvents } from "@/lib/agent/events";
import { runOf } from "./rows";
import { STALLED_MS } from "@/components/shell/live-shell";

export const FOLLOW_MS = 4000;
export const FOLLOW_MAX = 3;
// The reads one row is followed for in a page's life (Vercel CPU, 4 Nov 2026): 150 at
// FOLLOW_MS is ten minutes, past any run a 300 s request can make. A row still drawn
// working after that is read again by the page's next render, not by this timer.
export const FOLLOW_MAX_READS = 150;

/**
 * The rows with the shell's newer reading laid over them: each row whose conversation
 * the reading lists takes its word and its time, and is marked `moved` when the word
 * differs from the one the page was drawn with. A reading that lists nothing changes
 * nothing. Pure.
 */
export function liveRows(rows, conversations) {
  if (!Array.isArray(rows) || !Array.isArray(conversations) || !conversations.length) return rows;
  const by = new Map(conversations.filter((c) => c && c.id != null).map((c) => [String(c.id), c]));
  let changed = false;
  const out = rows.map((row) => {
    const c = row.sessionId ? by.get(row.sessionId) : null;
    if (!c) return row;
    const at = typeof c.updatedAt === "number" && Number.isFinite(c.updatedAt) ? c.updatedAt : row.at;
    // ONLY NEWS IS LAID OVER (local browser walk, 4 Nov 2026). A conversation's word and
    // its task's can differ for good (a scan's conversation Done while its task Waits),
    // and the row is the engine's reading of both. Laid over when nothing had changed
    // since that reading, the board grouped the scan under Done against its own header,
    // and every page load read the month twice. A conversation the reading already saw
    // (the same `updatedAt`) leaves the engine's word standing.
    const newer = typeof row.at !== "number" || typeof at !== "number" || at > row.at;
    const moved = newer && typeof c.status === "string" && c.status !== row.status && !row.notStarted;
    if (!moved && at === row.at) return row;
    changed = true;
    // A ROW WITH OPEN DECISIONS IS NEVER LAID OVER AS DONE (staging browser walk 7,
    // W7-2: "Done · 1 decision" while sign-off listed it Needs you). The row's count
    // is the engine's; the page is read again once, and its answer settles the word.
    if (moved && c.status === "Done" && row.count) return { ...row, at, moved: true };
    return { ...row, at, ...(moved ? { status: c.status, moved: true } : {}) };
  });
  return changed ? out : rows;
}

/** Whether any row's word moved since the page was drawn: then the page is read again. Pure. */
export function nextLiveRefresh(rows) {
  return Array.isArray(rows) && rows.some((r) => r && r.moved === true);
}

/**
 * Why the page should be read again, as one string, or null when nothing asks it: each
 * row whose word moved (and to which word), and each followed run that ended while its
 * row is still drawn working (and at which event). A refresh is asked once per distinct
 * reason, so the same reason after the refresh asks nothing (board load, 27 Oct 2026: a
 * key on the month object asked again after every refresh, in a loop). A run held from
 * before the refresh whose row has moved on asks nothing: its news is on the page. Pure.
 */
export function liveRefreshSignature(rows, followed = {}) {
  const parts = [];
  for (const r of Array.isArray(rows) ? rows : []) {
    if (!r || !r.sessionId) continue;
    if (r.moved === true) parts.push(`${r.sessionId}>${r.status}`);
    const run = followed && followed[r.sessionId];
    if (run && run.running === false && r.status === "Vert's working") parts.push(`${r.sessionId}@${run.lastSeq ?? ""}`);
  }
  return parts.length ? parts.sort().join("|") : null;
}

/**
 * The rows followed for their steps: working, with a conversation, at most FOLLOW_MAX,
 * and, given `nowMs`, moved within STALLED_MS of it (a row with no time is followed).
 * Pure.
 */
export function pollTargets(rows, { enabled, nowMs = null }) {
  if (!enabled || !Array.isArray(rows)) return [];
  const quiet = (r) => typeof r.at === "number" && Number.isFinite(r.at) && Number.isFinite(nowMs) && nowMs - r.at > STALLED_MS;
  return rows.filter((r) => r && r.status === "Vert's working" && r.sessionId && !quiet(r)).slice(0, FOLLOW_MAX);
}

/**
 * Follow the working rows' runs: `{ [sessionId]: run }`, newer than the page's. A
 * followed conversation is read whole once, then with `?after=` its last seq (a GET),
 * every FOLLOW_MS while the tab is visible, and its latest run worked out from what is
 * held (runOf). A read that fails changes nothing on screen.
 */
export function useFollowedRuns(targets) {
  const [runs, setRuns] = useState({});
  const held = useRef({});
  const reads = useRef({});
  const ids = targets.map((r) => r.sessionId).join("|");
  useEffect(() => {
    if (!ids) return undefined;
    let stopped = false;
    const controller = new AbortController();
    async function follow(id) {
      const mine = held.current[id] || { events: [], after: null };
      const url = `/api/agent/sessions/${encodeURIComponent(id)}${mine.after === null ? "" : `?after=${mine.after}`}`;
      const res = await fetch(url, { cache: "no-store", signal: controller.signal, headers: { accept: "application/json" } });
      if (!res.ok) return;
      const body = await res.json();
      if (stopped || !body || !Array.isArray(body.events) || !body.events.length) return;
      const events = mergeEvents(mine.events, body.events);
      const last = events[events.length - 1];
      held.current[id] = { events, after: last && Number.isInteger(last.seq) ? last.seq : mine.after };
      const run = runOf(events);
      if (run) setRuns((now) => ({ ...now, [id]: run }));
    }
    function tick() {
      if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
      for (const id of ids.split("|")) {
        const n = reads.current[id] || 0;
        if (n >= FOLLOW_MAX_READS) continue;
        reads.current[id] = n + 1;
        follow(id).catch(() => {});
      }
    }
    const timer = setInterval(tick, FOLLOW_MS);
    return () => {
      stopped = true;
      clearInterval(timer);
      controller.abort();
    };
  }, [ids]);
  return runs;
}

/**
 * The rows as the board draws them now: the page's, the shell's newer words and times
 * over them, and the followed runs' steps. When a word has moved, the page is read again
 * once per reason (liveRefreshSignature), in a transition.
 */
export function useLiveBoard(rows, { shell = null, enabled = false } = {}) {
  const router = useRouter();
  const [, startRefresh] = useTransition();
  const laid = useMemo(() => liveRows(rows, shell && Array.isArray(shell.conversations) ? shell.conversations : null), [rows, shell]);
  const followed = useFollowedRuns(pollTargets(laid, { enabled, nowMs: Date.now() }));
  const asked = useRef(null);
  // A moved word, or a followed run that ended (a word about to move): the page is read
  // again for it, once per reason (liveRefreshSignature).
  const reason = enabled ? liveRefreshSignature(laid, followed) : null;
  useEffect(() => {
    if (!reason || asked.current === reason) return;
    asked.current = reason;
    startRefresh(() => router.refresh());
  }, [reason, router]);
  return useMemo(() => {
    if (!Object.keys(followed).length) return laid;
    return laid.map((row) => {
      const run = row.sessionId ? followed[row.sessionId] : null;
      if (!run || row.status !== "Vert's working") return row;
      return { ...row, steps: run.steps.length ? run : row.steps, line: (run.running && run.current) || row.line };
    });
  }, [laid, followed]);
}
