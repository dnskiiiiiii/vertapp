# Design

> **Superseded (10 Oct 2026).** The current design contract is
> [`docs/design-calm-neutral.md`](docs/design-calm-neutral.md): the "Calm neutral" theme
> (9 Oct) as amended by the design-fix-2 pass (Archivo and Inter, the 8-step scale, the
> evergreen reserved for the one commit and the focus ring, Done as a neutral glyph and
> word, Phosphor icons, the command menu). It is implemented in `app/styles/tokens.css`,
> `base.css` and `kit.css`. Everything below is the historical record of how the earlier
> colours were measured; none of it is current.


> **Partly superseded (30 Sep 2026).** Type, space, motion and materials are the agent
> workspace design system: [`docs/agent-workspace-design.md`](docs/agent-workspace-design.md)
> §11, implemented in `app/styles/tokens.css` — the rem type scale in the system face,
> depth by shade and shadow, 3:1 control borders, a visible focus ring. **The colours on
> this page are NOT superseded:** the true-black rail, the light active pill, white content
> with black titles and Vert purple were restored by founder directive the same day
> (build plan §9.2.T), and `tokens.css` carries them. Satoshi is the wordmark's face only.
> Read `tokens.css` first; this page is the record of how those colours were measured.

Source of truth: the 38 Vert Frontier reference screens
(`/Users/vanshm/Downloads/Private & Shared 7/Frontier/`). All 38 were opened and
**pixel-sampled**; the values below are measured, not chosen. Where a value looks
surprising, it is because that is what the references measure. Do not "correct"
it toward convention.

Where these references and `vert-v1` disagree, the references win.

Canonical screens to match:

| File | Surface | Pattern it defines |
|---|---|---|
| `ai-edited-image 1.png` | Accounting → Matching | Expandable row, **2-column** inline detail |
| `ai-edited-image 2.png` | Reconciliation → Reconcile | Expandable row, **4-column** inline detail |
| `image 2.png` | Workflow → Clarification | **The AI rail.** Canonical. |
| `image 14.png` | Reconciliation → Exceptions | Row → 280px detail rail |
| `image 15.png` | Reconciliation → Approvals | 3-pane queue → detail |

Ignore `image 11 / 17 / 24 / 25` — external inspiration, not Vert.

## The IA: four rail destinations, no tabs

**Superseded 2026-08-18** — see
`docs/superpowers/specs/2026-08-18-ui-simplification-design.md`. This section
used to read "Reconciliation has four tabs, not three" and specify the tab row
below. That IA shipped, and it is what the tab row is measured against in the
references — but it did not survive contact with a live tenant.

The IA is now four peer destinations in the rail, and there is no tab strip:

| Destination | What it is |
|---|---|
| **Payouts** | the PAYOUT register, and the landing surface. Carries the clearing-account tie-out as a strip above it |
| **Approvals** | draft journal entries awaiting a human decision |
| **Exceptions** | unreconciled, uncoded, uncategorised |
| **Connections** | what is connected, the chart mapping, statement import |

Command · Insights · Checklist · Chat remain in the rail as a disabled "Coming
later" group. They are real destinations by URL and are unbuilt.

**Reconcile is gone as a destination.** It was the trial-balance view, and this
build has no general ledger behind it — on a live tenant it could render a
heading, "No trial balance is shown", and three lines explaining why, and that
was the app's landing screen. The half with something real behind it, the
clearing roll-forward, was NOT deleted: it is
`components/reconcile/ClearingAccounts.js`, mounted on Payouts.

`design-refs/reconcile.jpg` remains the reference for the
register-plus-4-column-expansion layout, which Payouts uses. When a general
ledger is wired in, the trial-balance view earns its destination back — and this
section should be rewritten again rather than left to rot, which is precisely
what `ReconcileTabs.js` did and why that drift went unnoticed for weeks.

## Theme

Two first-class themes over **one geometry** — a token swap, not two designs.
Nine reference screens are full-dark with identical layout.

- **Transactional surfaces** (Matching, Reconcile, Exceptions, Approvals,
  Checklist, Workflows, the AI rail) → **black rail + white content**.
- **Analytical surfaces** (dashboards, Models, Reports, Financials, Monitor,
  Chat) → **full dark**.

V1 builds light-first, tokenised so dark is a later swap.

## Color

**The rail is true black `#000000`** (measured #000004–#030305). Flat, hard edge,
no border, no shadow. Not a lifted charcoal.

**The content ground is white `#FFFFFF`** — cards included. 51–62% of every light
reference measured pure white. There is **no grey backdrop anywhere**; depth comes
from 1px `#EFF1F4` hairlines. `#FAFBFC` is reserved for table header rows and
toolbar strips only. This is the single easiest thing to get wrong.

**Accent is violet `#4F1FE8`** — hue 251–257°, L ≈ 48% (measured #4B0CEB, #512EE0,
#512AF5, #440AD1). Noticeably deeper and more violet than an indigo. The tint scale
is load-bearing for AI surfaces: `#F8F5FE` (hero card, dropzone), `#F5EDFD` (user
chat bubble), `#F9F7FD` (selected row), `#EBE6FE` (pill fill).

The brand board (`image 23.png`) shows a mint `#00D2A8`. **It never appears in
product UI.** Logo and marketing only.

**Seven semantic slots**, and the split matters:

| Meaning | Fill / text | Used for |
|---|---|---|
| success | `#EDFAF0` / `#12805A` | Approved, Reconciled, Matched, $0.00 variance |
| **AI-completed** | `#F2EEFF` / `#4F1FE8` | Completed, AI Generated, confidence tags |
| info | `#EFF4FE` / `#2563EB` | Assigned, In Review |
| warning | `#FFF7E4` / `#B45309` | Pending, Prepared, Needs Review |
| danger | `#FEEDEC` / `#DC2626` | Escalated, Behind, negative variance |
| teal | `#E7F7F8` / `#0E7490` | Unmatched Adjustment |
| neutral | `#F1F2F4` / `#6B7280` | Not Started, Viewed |

**Green means a human verified it. Violet means the machine completed it.** Never
collapse those two.

## Typography

**Satoshi** (brand board), Regular / Medium / Semibold. Fallback Inter, system-ui.

| Role | Size | Weight | Color |
|---|---|---|---|
| Page title | 26px | 600 | `#000` |
| Page description | 13px | 400 | `#64748B` |
| Card / section heading | 15px | 600 | `#111` |
| Rail card title | 13px | 600 | `#111` |
| **Table column header** | 11–12px, **sentence case, not upper** | 500 | `#8A90A0` |
| Table body | 13px | 400 | `#2A2C3B` |
| KPI value | 30px (tall card) / 24px (strip) | 600 | `#000` |
| Pill | 11–12px | 500 | semantic |

Figures: right-aligned, `tabular-nums`, parenthesised negatives `($1,173.30)`.

**No monospace appears in any of the 38 images** — reference IDs use the same
sans. Do not introduce a mono face.

## Layout

- Rail **240–250px**. Content padding **32px**. Card gutter **16px**, stack gap
  **24px**, card padding 20–24px, radius 12px (buttons/inputs 8px, pills 999px).
- 4px spacing base: 4 / 8 / 12 / 16 / 20 / 24 / 32.
- Dashboards fluid-width; prose documents capped ~720px.
- **Table rows 46–48px.** Header 48–56px on `#FAFBFC`, 1px `#E2E5EA` bottom rule.
  No zebra striping.

## Components

**KPI cards, two variants.** *Tall* (~193px): label, tinted status icon
top-right, 30px value, delta line, full-bleed sparkline across the bottom ~90px.
*Strip* (~72px): label + 24px value stacked left, 32px circular tinted icon
right, no chart. **4 or 5 across**, 16px gap.

**Expandable rows — the signature pattern.** Chevron rotates; panel opens inline,
white, 1px framed, ~24px padding, equal columns divided by 1px vertical rules.
Two variants: **2-column** (Matching) and **4-column** (Reconcile: Account Details
/ Reconciliation Summary / Variance Analysis / Recent Activity). Both close with a
**left-aligned ghost-button action row** — `View Reconciliation · View Entries ·
Investigation Underway`. Only one row expanded at a time.

**Confidence.** Inline 4px bar, radius 2, track `#E7E9E9`, green→amber→red by
band, `%` label right. Always paired with a status pill.

**Buttons.** One filled violet primary per view. Secondary = white + 1px border.
Ghost = no fill, used inside cards. Red is never a button fill — red is for data.

**Sidebar.** Logo lockup inside the rail, as the website's header draws it: the navy
striped circular mark (`public/brand/vert-mark-navy*.webp`, from the website) at 32px,
a 10px gap, and "Vert" at medium weight, −0.02em tracking, in ink. The violet disc with
a white crescent was never Vert's logo and is gone (founder, 10 Oct 2026). Optional
`⌘K` search. Primary group (Command · Spaces · Monitor) at ~48px pitch. Divider.
Collapsible groups with children indented ~26px, iconless, joined by a faint
vertical guide. Spacer. **`+ New Chat` — white fill, black label**, never accent.
Divider. Avatar + name + role + gear. Active item = rounded-8 pill, `#E6E8EA`
fill with **black** text (inverted).

## The AI rail — canonical, `image 2.png`

**400px**, full height, **white** ground (not tinted), 1px `#EFF1F4` left border,
**16px** inner padding, cards stacked at **24px** gaps, radius 12.

**Header** (~64px, closed by a 1px rule): violet glyph + `Vert AI` 15px/600,
right-aligned `⤢` and `✕`.

**Cards, in order:**
1. **Progress** — titled (`Clarification progress`). A **horizontal 5-node
   stepper**: 14px circles on a 2px `#E7E8ED` connector. Active = violet core
   `#3C06D8` in a `#E4D2F8` halo; complete = solid violet; future = grey ring.
   **Labels sit beneath each node**, 11px, centred.
2. **Context provided** — dashed 1.5px violet border, radius 12, fill `#FAF7FE`,
   upload glyph, "Drag and drop files here or click to upload".
3. **What I know so far** (in-flight) / **What I did** (complete) — **green ✓
   glyph, no checkbox**, 13px statements at ~38px pitch.
4. **Why this matters** — 13px muted prose, 3–4 lines.

**Variants seen in the same slot:** violet-tinted hero result card (`#F8F5FE`);
live plan card; collapsible `Reasoning` / `Audit Trail` / `Workflow Plan`
accordions; `Sources (12)` file list; artifact-preview mode where the rail becomes
a spreadsheet viewer.

**Footer** is one of exactly two things: a follow-up composer, or
🔒 `Your data is secure and never used to train models.`

**No model selector appears in any of the 38 references.** BYOM is a real team
decision (2026-07-26) so the control stays, but it does not belong as a rail card
competing with this structure — put it in the rail header or in settings.

## Interaction

Row expansion (one at a time) · row → detail rail (Exceptions, 280px) · 3-pane
queue for Approvals (360px queue | detail) · bulk select via header + row
checkboxes · `1–25 of 1,264` left, numbered pager right with `#F9F7FD` active
page · every AI action carries reasoning, sources and an audit trail.

## Bans

Monospace as a typeface · JSON on screen · tool-name chips · architecture panels ·
confidence weight breakdowns · method columns · step counters · ms timings ·
gradient text or marks · sparkle icons · side-stripe accent borders · a grey
content backdrop · status carried by colour alone.
