// proxy.js — the two gates in front of every request.
// ================================================
// Next 16 calls this file `proxy.js`; it is what earlier versions called
// `middleware.js`, and it runs before any route is matched.
//
// Two unrelated things live here because there is one place to put them:
//
//   1. HTTP basic auth for the shared demo deployment. Vercel's own deployment
//      protection is a Pro feature; this is the free equivalent. It gates the whole
//      site behind one shared password so a crawlable *.vercel.app URL does not put
//      unreleased product design in a search index. It is NOT about tenancy and does
//      not know what a tenant is.
//   2. The session gate. Whether THIS browser has signed in, which tenant's books
//      that entitles it to, and whether the session has aged out. This is the one
//      that matters.
//
// ────────────────────────────────────────────────────────────────────────────
// THE RUNTIME, AND WHY IT MATTERS THAT IT IS NODE
// ────────────────────────────────────────────────────────────────────────────
//
// Next 16 runs the proxy on Node.js, always, and rejects a `runtime` key in the
// config below outright. Worth knowing rather than assuming, because the alternative
// breaks this file in a way no log would explain: at the edge `process.env` is
// inlined at BUILD time, so `VERT_SESSION_SECRET` — supplied at `next start`, like
// every other runtime secret — would read as undefined here and as its real value in
// the app. The proxy would seal and open cookies with a different key from the rest
// of the process, every session would look forged to one half of the app, and the
// symptom would be an endless redirect between `/` and `/login`.
//
// Under Node it is a live read of the same environment the app sees. The sealing in
// `lib/session-seal.js` still uses Web Crypto rather than `node:crypto`, so nothing
// here depends on that guarantee holding forever.
//
// ────────────────────────────────────────────────────────────────────────────
// WHAT THIS GATE IS, AND — MORE IMPORTANTLY — WHAT IT IS NOT
// ────────────────────────────────────────────────────────────────────────────
//
// It is a ROUTER, not the access control. It decides which screen you land on. It is
// deliberately not the thing standing between an anonymous request and a customer's
// books, and no middleware should be: CVE-2025-29927 was exactly that assumption in
// this framework, and the general shape of it — "the check ran in a layer that can be
// skipped" — is the same defect this repo has shipped six times.
//
// The access control is two layers further in and neither can be skipped by a header:
//
//   · `lib/session.js authHeaders()` returns null with no valid session, so the
//     request to vert_api carries no credential.
//   · vert_api refuses it with 401 — the tenant comes from a scrypt-verified key,
//     not from anything in this process — and `readCloseData()` renders the failure
//     with no figures on it.
//
// So a request that somehow reached `/` without passing through here does not get
// somebody's books. It gets an error card. This file's job is to make sure the
// ordinary case gets a sign-in screen instead, which is a usability job.
//
// ────────────────────────────────────────────────────────────────────────────
// THE SLIDING IDLE WINDOW LIVES HERE, BECAUSE THIS IS THE ONLY PLACE IT CAN
// ────────────────────────────────────────────────────────────────────────────
//
// A Server Component cannot set a cookie — Next forbids it, because a component may
// run after the response has begun streaming. So the `seen` timestamp that keeps an
// active session alive has to be re-stamped somewhere that can write a response
// header, and for a plain page navigation that is here and nowhere else.
//
// Re-sealing carries `issuedAt` forward, so the 8-hour absolute expiry is NOT
// refreshed. Only the 30-minute idle window is. Without that distinction a session
// in steady use would live forever and the absolute bound would be decorative.

import { NextResponse } from "next/server";

import { PUBLIC_DOC_HEADER, isPublicDoc } from "@/lib/public-docs";
import { isLinkClient, linkMonthOf, isLinkMonth, loginPath, needsClientHop, placeHop, safeNext, signInReturn, withoutClient } from "@/lib/return-path";
import {
  SESSION_COOKIE,
  cookieOptions,
  openSealed,
  sealSession,
} from "@/lib/session-seal";

export const config = {
  // Everything except Next's own assets, the favicon (app/favicon.ico, app/icon.png, app/icon1.png, app/apple-icon.png) and
  // the logo's image files under public/brand/. The sign-in page draws the logo before
  // anyone has a session, so the session gate must not turn its image into a redirect
  // to the very page that asked for it; the mark is public on Vert's website anyway.
  //
  // There is deliberately no `runtime` key: Next 16 always runs the proxy on Node.js
  // and REFUSES to build if the file asks for a runtime at all. That is the property
  // the header above depends on, now guaranteed by the framework rather than
  // requested by this file — `process.env.VERT_SESSION_SECRET` is a live read here
  // and holds the same value the app sees.
  matcher: ["/((?!_next/static|_next/image|favicon.ico|icon.png|icon1.png|apple-icon.png|brand/).*)"],
};

const LOGIN_PATH = "/login";

// The two preference cookies the proxy reads (lib/session.js CLIENT_COOKIE, lib/period.js
// MONTH_COOKIE). Spelled here rather than imported: lib/session.js pulls in next/headers
// and lib/period.js the format tables, and neither belongs in the proxy.
// tests/vf-shell-p5.test.js holds both names equal to their owners'.
export const CLIENT_COOKIE_NAME = "vert_client";
export const MONTH_COOKIE_NAME = "vert_month";
const YEAR_S = 31536000;

/** Is this request one the router fired ahead of a press (never a person's choice)? */
function isPrefetch(request) {
  const h = request.headers;
  return Boolean(h.get("next-router-prefetch") || h.get("purpose") === "prefetch" || h.get("sec-purpose") === "prefetch");
}

/** The request's Cookie header with `name` set to `value` (the rest kept as sent). */
/**
 * Is this a page the browser is LOADING (an address typed, a link opened in a tab, a
 * reload), as opposed to a fetch the in-app router made?
 *
 * WHY NOT "NOT A PREFETCH" (verify pass 6, S-E2E-2 F14). Next strips its router headers
 * (`rsc`, `next-router-prefetch`, `next-router-state-tree`, the segment prefetch) from
 * the request before the proxy sees it (next/dist/server/web/adapter.js FLIGHT_HEADERS),
 * so `isPrefetch` never sees a router prefetch and the proxy cannot tell one from an in-app
 * navigation. The sidebar's task links are prefetched as soon as they are drawn, so every
 * Month-end paint fetched `/chat/2026-07-…` and the proxy wrote July over the month the
 * person had just chosen: "Start August" then re-read the page under July. A document
 * load says so itself (`Sec-Fetch-Dest: document`, or for a browser that sends no fetch
 * metadata, an Accept that asks for HTML); a router fetch says `empty` and `*\/*`.
 */
function isDocumentLoad(request) {
  const h = request.headers;
  const dest = h.get("sec-fetch-dest");
  if (dest) return dest === "document";
  return /\btext\/html\b/.test(h.get("accept") || "");
}

function cookieHeaderWith(request, name, value) {
  const raw = request.headers.get("cookie") || "";
  const kept = raw
    .split(";")
    .map((part) => part.trim())
    .filter((part) => part && !part.startsWith(`${name}=`));
  kept.push(`${name}=${encodeURIComponent(value)}`);
  return kept.join("; ");
}

/**
 * THE TWO DOCUMENTS THAT MUST BE READABLE BY SOMEBODY WITH NO ACCOUNT.
 *
 * `/privacy` and `/terms` are the URLs handed to Shopify and Intuit on a vendor
 * application. The person who opens them is a reviewer at a payments company who has
 * never heard of us, has no credential, and will not ask for one: a page that answers
 * them with a sign-in screen has failed the requirement it exists to satisfy, and the
 * application is rejected without anyone at Vert learning why.
 *
 * BOTH gates are bypassed, and the second one is the one that would actually have bit.
 * The session gate at least redirects somewhere a human could reason about. The shared
 * demo password above it returns a bare 401 with a browser credential prompt on top of
 * it — to a reviewer, an unreachable URL. It is set on the deployment, so testing this
 * with the variables unset locally proves nothing.
 *
 * This list is exact strings, not a prefix match. `startsWith("/terms")` would also
 * open `/terms-internal` or anything else later filed under a name beginning that way,
 * and a public-by-accident route in an app serving customers' books is the one mistake
 * this file's own header warns about six times.
 *
 * The list itself, and the header the root layout reads, live in `lib/public-docs.js`
 * so that this file and the layout cannot disagree about which routes are public.
 */

/**
 * Is there anything to sign in to?
 *
 * The same environment variable `lib/engine-source.js` reads to choose between the
 * live service and the committed sample close, and `lib/session.js` re-expresses as
 * AUTH_REQUIRED: there is something to authenticate against exactly when there is a
 * service behind the app.
 *
 * Read here rather than imported, and that is a constraint rather than a preference.
 * `lib/session.js` imports `next/headers`, which does not belong in a proxy, and
 * `lib/engine-source.js` imports the whole sample close as JSON — evaluating that on
 * every request to answer a question about one variable. The demo's own architecture
 * test (`tests/no-arithmetic.test.js`) also holds `lib/` to a single reader of this
 * variable; this file is not under `lib/`.
 *
 * So it is duplicated in exactly one place, deliberately, and `tests/session.test.js`
 * drives THIS function — the real proxy, in both modes — against `SOURCE` so the two
 * cannot drift into a gate that is on in one layer and off in the other.
 *
 * A function rather than a constant: this process is long-lived and a constant
 * evaluated at import would freeze whatever the environment said at module load.
 */
export function authRequired() {
  return Boolean((process.env.NEXT_PUBLIC_VERT_API_URL || "").trim());
}

/** The shared-demo password gate. Unchanged behaviour: unset variables mean OPEN. */
function basicAuthRefusal(request) {
  const user = process.env.DEMO_USER;
  const pass = process.env.DEMO_PASS;
  if (!user || !pass) return null;

  const header = request.headers.get("authorization");
  if (header) {
    const [scheme, encoded] = header.split(" ");
    if (scheme === "Basic" && encoded) {
      const [u, p] = atob(encoded).split(":");
      if (u === user && p === pass) return null;
    }
  }

  return new Response("Authentication required", {
    status: 401,
    headers: { "WWW-Authenticate": 'Basic realm="Vert demo", charset="UTF-8"' },
  });
}

export default async function proxy(request) {
  const { pathname, search } = request.nextUrl;

  // BEFORE EITHER GATE. A public legal document is served to anyone who asks, with the
  // header that tells app/layout.js to draw it on its own rather than inside the
  // product shell — the shell reads the close, and a signed-out request has nothing to
  // read it with.
  if (isPublicDoc(pathname)) {
    const headers = new Headers(request.headers);
    headers.set(PUBLIC_DOC_HEADER, "1");
    return NextResponse.next({ request: { headers } });
  }

  const refusal = basicAuthRefusal(request);
  if (refusal) return refusal;

  if (!authRequired()) return;

  const onLoginScreen = pathname === LOGIN_PATH;

  const cookie = request.cookies.get(SESSION_COOKIE)?.value;
  const opened = await openSealed(cookie);

  if (!opened.ok) {
    if (onLoginScreen) {
      // Already where they need to be. The cookie is still cleared when there was
      // one: an expired or forged value left in the jar would be re-read on every
      // subsequent request, and `app/login/page.js` reads its own reason from it to
      // say WHY the last session ended — which it can only do once. Clearing it here
      // rather than on the way in would lose that sentence.
      return NextResponse.next();
    }
    // THE WAY BACK (verify pass 1 F10, S-CF-9). The page asked for rides along as
    // `?next=`, so signing in again lands where the person was (lib/return-path.js).
    // THE CLIENT AND MONTH GO WITH IT (verify pass 5, S-CF-9 F3): a new session starts on
    // the key's home client, so the page alone came back as another client's September.
    // What this browser had open rides along as the hop through /clients/open, which
    // proves the client under the new key before remembering it (lib/return-path.js).
    const back = signInReturn(`${pathname}${search || ""}`, {
      client: request.cookies.get(CLIENT_COOKIE_NAME)?.value,
      month: request.cookies.get(MONTH_COOKIE_NAME)?.value,
    }) || "/";
    if (request.headers.get("next-action")) {
      // A SERVER ACTION CANNOT FOLLOW A 307. The browser's action client read the old
      // redirect as "an unexpected response", and the card pressed said "No answer, and
      // Vert couldn't read the approval back", with no route to sign in. This is the
      // answer the action client navigates on: `x-action-redirect` with no body, which
      // it treats as an external redirect and follows with a full page load. The dead
      // cookie is left for the sign-in screen, which reads it to say why the session
      // ended, and which is not itself an action.
      return new Response(null, {
        status: 401,
        headers: { "x-action-redirect": `${loginPath(back)};push`, "content-type": "text/plain", "cache-control": "no-store" },
      });
    }
    const destination = request.nextUrl.clone();
    destination.pathname = LOGIN_PATH;
    destination.search = new URL(loginPath(back), "http://vert.invalid").search;
    const response = NextResponse.redirect(destination);
    if (cookie) {
      // A dead cookie is deleted rather than left to be re-evaluated forever. Deleted
      // on the REDIRECT, so the sign-in screen's own read (one request later) is the
      // last one that sees it — which is what lets it name the reason.
      response.cookies.set(SESSION_COOKIE, "", { ...cookieOptions(), maxAge: 0 });
    }
    return response;
  }

  // Signed in, and standing on the sign-in screen. Send them to the close.
  if (onLoginScreen) {
    const destination = request.nextUrl.clone();
    const next = safeNext(request.nextUrl.searchParams.get("next"));
    const target = new URL(next || "/", "http://vert.invalid");
    destination.pathname = target.pathname;
    destination.search = target.search;
    return NextResponse.redirect(destination);
  }

  const isAction = Boolean(request.headers.get("next-action"));
  const prefetch = isPrefetch(request);

  // AN ADDRESS THAT NAMES ANOTHER CLIENT IS HONOURED OR STRIPPED (verify pass 5, S-E2E-3
  // F12). `/?client=X` and `/records?client=X` showed the session's client under an
  // address naming X. Such a page goes through the hop, which switches (proven by the
  // engine) or refuses, and lands on the page without `client`. Never on a prefetch: the
  // router fetches links nobody pressed, and a prefetch must not switch anyone's client.
  if (!isAction && !prefetch) {
    const chosen = request.cookies.get(CLIENT_COOKIE_NAME)?.value;
    const current = isLinkClient(chosen) ? chosen : opened.session.tenant || null;
    if (needsClientHop(pathname, search, { current })) {
      const named = request.nextUrl.searchParams.get("client");
      const hop = placeHop(withoutClient(`${pathname}${search || ""}`) || "/", { client: named });
      const destination = request.nextUrl.clone();
      const target = new URL(hop, "http://vert.invalid");
      destination.pathname = target.pathname;
      destination.search = target.search;
      return NextResponse.redirect(destination);
    }
  }

  // A TASK CONVERSATION'S MONTH IS THE VISIBLE MONTH, BEFORE THE SHELL IS DRAWN (verify
  // pass 5, F-14). Opening `/chat/2026-07-bank_reconciliation` by URL left the top bar on
  // September: the month followed only after the page had drawn, through a browser-side
  // cookie write and a refresh (components/shell/MonthControl.js SetVisibleMonth), and
  // until that refresh landed the bar named another month over July's figures. A task's
  // id names its month, so the proxy sets the month cookie on the request the layout
  // reads AND on the response, and the first byte already says July. A free
  // conversation's id names no month; SetVisibleMonth still follows it.
  // ONLY ON A DOCUMENT LOAD (verify pass 6, S-E2E-2 F14; isDocumentLoad): a router fetch
  // of a task link, prefetch or not, never moves the month. In-app navigation keeps the
  // layout anyway, and the conversation page sets its month itself (SetVisibleMonth).
  let monthCookie = null;
  if (!isAction && !prefetch && isDocumentLoad(request)) {
    // And Month-end's `/?period=2026-08` (p1/fix7): an address that names its month
    // outright wins over the cookie, so the page and the sidebar count that month.
    const month = linkMonthOf(pathname, search);
    if (month && isLinkMonth(month) && request.cookies.get(MONTH_COOKIE_NAME)?.value !== month) monthCookie = month;
  }

  // Signed in and going somewhere real. Slide the idle window — and only the idle
  // window: `issuedAt` is carried forward so the absolute expiry keeps its original
  // deadline. `search` is untouched; this is a pass-through, not a redirect.
  let response;
  if (monthCookie) {
    const headers = new Headers(request.headers);
    headers.set("cookie", cookieHeaderWith(request, MONTH_COOKIE_NAME, monthCookie));
    response = NextResponse.next({ request: { headers } });
    // Not httpOnly: the month control reads it back in the browser (lib/session.js rememberMonth).
    response.cookies.set(MONTH_COOKIE_NAME, monthCookie, {
      sameSite: "lax",
      secure: request.nextUrl.protocol === "https:",
      path: "/",
      maxAge: YEAR_S,
    });
  } else {
    response = NextResponse.next();
  }
  // NOT ON A SERVER ACTION, AND NOT ON A PREFETCH. Next counts any cookie written
  // while an action runs, this one included, as the action having revalidated, and
  // the browser then re-renders the whole route after it. Every mount-time action
  // (the Connections page has two) became a self-triggered re-render seconds after
  // load, and a navigation started in that window was "interrupted by another
  // navigation" back to the page being left (eval iter 1, D6). A prefetch is not use
  // either: the router fires them for links nobody pressed. The window still slides
  // on every page load and every real navigation around the action.
  if (isAction || prefetch) {
    return response;
  }
  const resealed = await sealSession(
    {
      key: opened.session.key,
      tenant: opened.session.tenant,
      keyId: opened.session.keyId,
      environment: opened.session.environment,
      label: opened.session.label,
      // The person a person key named, carried through the slide (§19.0.9): a refresh
      // that dropped it would sign Sam Lee out of his own name after one page load.
      person: opened.session.person,
      firm: opened.session.firm,
    },
    { issuedAt: opened.session.issuedAt }
  );
  response.cookies.set(
    SESSION_COOKIE,
    resealed,
    cookieOptions({
      secure: request.nextUrl.protocol === "https:",
      // The browser-side Max-Age tracks what is LEFT of the absolute window rather
      // than restarting it, so the cookie and the sealed payload agree about when
      // this session dies. They are checked independently — the sealed `exp` is the
      // one that is enforced — and two clocks disagreeing is a bug report about
      // being signed out early.
      maxAgeMs: opened.session.expiresAt - Date.now(),
    })
  );
  return response;
}
