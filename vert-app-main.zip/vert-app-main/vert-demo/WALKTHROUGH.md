# Vert demo — what everything is

Plain-language guide. Assumes no accounting background.
Run with `npm run dev`, open http://localhost:3000

---

## 1. The problem this product solves

A Shopify store sells $10,000 of product on Monday. On Thursday, **$8,640**
arrives in their bank account.

Nobody told the accountant where the other $1,360 went. It was:

| | |
|---|---|
| Processing fees | Stripe/Shopify keep ~2.9% |
| Refunds | customers sent things back |
| Chargebacks | customers disputed payments |
| Reserve | the processor holds some of your money back |
| GST | tax you collected, which was never your revenue |

So the accountant has to take one bank deposit and prove, to the cent, what it
is made of — then write the bookkeeping entry that records all of it correctly.
Today that's done by hand in spreadsheets, one processor at a time, every month.

**Vert does that automatically and proves the arithmetic.**

---

## 2. Words you'll see on screen

**Payout** — the lump sum a payment processor deposits into your bank. One payout
= hundreds of individual sales, minus everything above.

**Decomposition** — breaking a payout back into its parts (sales, fees, refunds,
chargebacks, reserve, tax). The core thing Vert does.

**Clearing account** — a temporary holding account. When you make a sale you
haven't been paid for yet, the money sits in "clearing". When the payout lands,
it leaves clearing and enters your bank.

**Why clearing must return to zero** — this is the single most important idea in
the product. Money goes *into* clearing when you sell, and *out* when you get
paid. If clearing still has a balance and nothing is genuinely in transit, then
something went in that never came out. **A clearing account that won't return to
zero means the books are wrong.** That's what the red `($150.00)` is.

**Journal entry (JE)** — the formal bookkeeping record. Always two sides:
**debits** (blue on screen) and **credits** (amber). They must be equal. If they
aren't, the entry is invalid and cannot be posted.

**Trial balance** — a list of every account and its balance. Used to check the
books hang together.

**Reconciliation** — proving an account's balance is supported by evidence.
"Our books say $42,350 in receivables; here are the invoices that prove it."

**Exception** — something Vert could not resolve on its own, so a human must
decide.

**Draft** — an entry Vert has written but not filed. Nothing Vert produces posts
automatically; a person always approves it, in Vert, before anything is sent.

> **Ledger note, 2026-08-06: the first target is now QuickBooks, not Xero.** Xero is
> superseded, not deleted (`V1-STATUS.md` §3.3) — the poster still works and its tests
> still run.
>
> This paragraph used to end "Xero does not allow any outside tool to finish a bank
> reconciliation, so the last click always happens in the ledger." Two things are wrong
> with saying that now, and only one of them is the vendor's name.
>
> 1. **QuickBooks has no draft state.** A created `JournalEntry` is in the trial balance
>    the moment it arrives — measured against the live sandbox. Xero holds what a third
>    party creates as a DRAFT that a human approves *inside the books*; QuickBooks has
>    no such thing, so on QuickBooks **the approval in Vert is the only gate.** What
>    replaces the in-ledger DRAFT is that the live poster is unreachable by default
>    (it cannot be constructed without an HTTP client and an account mapping) and the
>    entry is idempotent on `DocNumber`, so a re-run returns the existing entry instead
>    of a second one. Say that, if asked. It is a guard against duplication, not a
>    second review, and pretending otherwise is the one thing not to do on this slide.
> 2. **"No outside tool can finish a bank reconciliation" is a *Xero* fact**, formally
>    confirmed with that vendor. **Whether QuickBooks has the same restriction has not
>    been researched.** Do not assert it about QuickBooks either way.
>
> Also unresearched, and worth pre-empting from an Australian room: **AU GST has never
> been proven on QuickBooks.** The engine splits GST onto its own journal line, but no
> tax code is sent to the ledger and the poster refuses any draft carrying one — the
> sandbox is a US company. Nothing in this product touches a BAS.

---

## 3. The sidebar

Five areas. **Only Reconciliation is built** — the other four are deliberate
placeholders for later versions.

| Area | Status | What it will be |
|---|---|---|
| Command | placeholder | Overview + agent workflows in progress |
| Insights | placeholder | Anomaly and error monitoring (V1.2) |
| Checklist | placeholder | Month-end close checklist (V1.2) |
| **Reconciliation** | **built** | The V1 product. Badge shows open exceptions. |
| Chat | placeholder | Ad-hoc questions about your data |

---

## 4. The four Reconciliation tabs

### Reconcile — "is the close done?"
The status view. Two tables:

- **Clearing accounts** — the health check. Recognised vs landed vs in transit,
  and anything unexplained. Shopify says *"Rolls forward"* (healthy). Stripe says
  *"Does not roll forward"* with `($150.00)` — that's the problem to chase.
- **Trial balance** — six accounts, book balance vs supporting evidence, and the
  variance. Green means it ties, amber means it doesn't.

### Approvals — "what needs my sign-off?"
Three panes. Left: the queue of draft entries. Middle/right: the selected one in
full — a plain-English summary, the AI's reasoning as a checklist, the journal
entry preview, the before/after effect, and similar past approvals.

Nothing here has been filed, and nothing is sent to a ledger by this build.
Approving stages the entry — and on QuickBooks that approval is the only gate,
because a journal entry that reaches it is in the trial balance at once.

### Payments — "prove this payout" ← **the main screen**
The payout register. Every payout this period with its deposit, what the parts
add up to, the variance, a confidence score and a status.

**Click any row and it opens in place** showing:
1. A plain-English sentence explaining the gap
2. Four panels — account details, reconciliation summary, variance, recent activity
3. The decomposition table, ending in `Σ net — ties out to the cent`
4. The bank tie-out line
5. The draft journal entry with per-line sources, and proof debits = credits
6. Approve / view entries / view exceptions

There's a **Vert AI** button in the header. Open it and a panel appears on the
right showing the agent's five steps (Reading → Decomposing → Matching →
Drafting → Verifying), what it found, and why it matters.

### Exceptions — "what couldn't be resolved?"
A register of the 11 open items — date, amount, source, description, type,
account, days open, status. Each has **Investigate**. Grouped by *reason*, never
auto-guessed: Vert says "I don't know" rather than picking wrong.

---

## 5. How to walk it in five minutes

1. **Reconcile** — see Stripe Clearing `($150.00)`, "Does not roll forward".
   Something is wrong and the product says so on the landing screen.
2. Click **"Open Payments to see which payout carries it"**.
3. **Payments** — click **SP-9001** (a healthy one). Read the sentence, watch the
   decomposition tie to the cent, see the draft entry balance. This is the
   product working.
4. Click **SP-BROKEN**. The transaction detail is **$150.00 short** of what the
   bank paid. The verifier re-checks the numbers itself, fails 4 of 6 checks, and
   **refuses to create the entry**. It cannot be approved from either screen.
5. **Exceptions** — that $150 appears as a "Payout break", blocked, 15 days open.

Step 4 is the point of the whole thing. Most AI tools produce a confident wrong
answer. This one produces nothing and tells you exactly what's missing.

---

## 6. What's real and what's staged

**Real:** every number. Decomposition, matching, journal entries, the balance
proof, the verifier — all computed by actual code in `lib/` on the fixture data.
No figure on any screen is typed in by hand.

**Staged — but read the correction below:** the narration in the committed build.

**Not connected:** no real Stripe, Shopify or ledger *in the demo*. The data is a
fictional company, Northwind Retail Pty Ltd, June 2026.

> ### Correction, 2026-08-06 — "there are no live AI calls" is no longer accurate
>
> This section read: ~~*"**Staged:** the agent. **There are no live AI calls.** The steps
> and narration are written and timed to look live."*~~ Replace it with the following,
> which has three parts. Saying only the first or only the third is misleading in
> opposite directions.
>
> **1. The export can call a real model, and it has been run that way.** One environment
> variable swaps the recorded transport for OpenAI and bakes genuine model output into
> the file the demo renders. It is opt-in and never inferred — an absent variable means
> recorded, not "try live and fall back".
>
> **2. The screen states its own provenance.** The proposal card reads a `live` flag out
> of the data, so a recorded run is captioned *"Recorded output, replayed from a
> transcript"* and a live one is not. The caption cannot silently disagree with what
> produced the file.
>
> **3. The committed build is still the recorded replay, deliberately.** The cheap model
> abstains variably — 1, 0 and 1 proposals across three identical runs, with one run
> leaving both escalated payouts empty. Abstaining is *correct behaviour*, but
> re-rolling until a run looked good would be **selecting on the outcome**: the caption
> "real model output" would be true and still misleading about what is typical.
>
> **What to say:** *"The numbers are real and computed by the engine. The narration in
> this build is recorded, and the screen says so. It can run against a live model with
> one environment variable — and when it does, the numbers don't change, because the
> model isn't allowed to produce one."*
>
> **That last clause is measured, not a slogan.** The whole export was run scripted and
> then live, and everything except the narration came back byte-identical; the blocked
> payout stayed blocked. `V1-STATUS.md` §6c.2.
>
> Running it live in front of an audience is one command and is *more* convincing than
> the baked file, because it is visibly happening.

> ### Before you demo anything: regenerate the data file
>
> `lib/engine-output.json` is **currently stale** and shows GST of **$900.00** on
> `SP-9001` where the engine computes **$909.09** — a GST-inclusive gross of $10,000
> carries $909.09, not $900.00. Five other values on that payout are wrong with it.
> **None of the 178 tests can detect this**, because they all read that file as ground
> truth. `V1-STATUS.md` §2.5.
>
> `SP-9001` is the payout the demo presents as *clean*. Do not show it until the file
> is regenerated.

---

## 6a. What you must NOT claim — there is now a measured number

As of 2026-07-30 the engine has been benchmarked (`vert-engine/vert_bench`), and
re-measured 2026-08-06: the corpus is now **50 authored cases, 42 of them graded**,
across 10 strata, validated by a mutation sweep that caught 4/4 deliberate corruptions.

| | first run | after fixing 7 defects |
|---|---|---|
| Auto-resolution, weighted | 17.0% | **90.7%** |
| Auto-resolution, unweighted | 19.0% | **73.8%** |
| Silent errors | 40.5% | **0.0%** |
| Correctness incl. correct declines | — | ~~99.0%~~ → **100.0%** |
| False escalations | — | ~~1~~ → **0** |

> **Updated 2026-08-06, and the update needs a caveat rather than a victory lap.**
> Correctness is now **1.0000** and false escalations are **0** (both re-measured this
> evening; the other three figures did not move). **A correctness figure of exactly
> 100% is a number to distrust, not to quote proudly:** it means every graded case now
> lands on its authored outcome, so **the corpus has stopped discriminating.** It needs
> harder cases before that figure means anything more than "we have run out of test".
> Quote 0% silent errors instead — that one is still load-bearing.

**Quote 0% silent errors before you quote anything else.** It means the engine
never produced a wrong entry that looked right — it either got it right or it
declined. For an accountant that is the number that matters.

**On the two auto-resolution figures: the spread between them is the mix
assumption.** 90.7% assumes a payout mix we declared; 73.8% treats every stratum
equally. The easiest stratum carries 42% of the weight. Until Phase 3 puts real
volume through it, **73.8% is the number you can defend without an argument** and
90.7% is the number conditional on a mix you haven't proven. At n=42 the benchmark
resolves ~15-point differences, not 3-point ones.

The seven defects were all invisible to the engine's own `integrity_ok` /
`balanced` / `validate_je` checks — an entry can satisfy all three and still be
wrong, which is exactly why the external benchmark exists.

**What this still means for the demo.** Everything on screen is true of the
payouts on screen. Do not generalise from two fixtures — cite the benchmark
instead, and say which figure you're using and why.

## 7. The one idea worth remembering

Most accounting AI lets the model do the maths. If the model is wrong, you get a
wrong number that looks right.

Vert never lets the model touch a number. Code does the arithmetic; a separate
**verifier** re-derives every figure from the source records and compares. If
they disagree, nothing is produced.

That's why the model dropdown in the AI panel is safe: switching models changes
who writes the narration, and cannot change a single figure.

**As of 2026-08-06 that sentence is measured rather than promised.** The entire export
was generated twice — once from the recorded transcript, once against a live OpenAI
model — and every value outside the narration came back byte-identical. The deliberately
broken payout stayed blocked under both. A real model read a $150 hole, wrote its own
explanation of it, and could not clear the block or move a number. `V1-STATUS.md` §6c.2.

If you only remember one thing from this document, remember that one, because it is the
thing competitors cannot say.
