# The steps between a blocked payout and a posted entry

Measured, not estimated. Every count below came from driving a signed-in tenant
against a live engine and a live PostgreSQL database — 18 migrations, `--repository
store`, 31 payouts, 30 bank lines, six of them blocked — and counting the presses.
Nothing here is read off the code.

The brief was the founder's:

> "Before Apple Pay… other products took seven steps. Apple Pay is three.
> Reconciliation is the same: people are just reading what's going on, clicking a
> button, and sending it to the general ledger."

So this document counts **actions separately from reads**. An action is a discrete
thing a person does: a click, a keystroke sequence, a scroll to find a control. A
read is something they look at. Reading is the job. Clicking is the tax.

Each step is also marked for whether it is **one obvious click** or a **hunt** — a
step whose cost is not the press but finding the thing to press.

**Before** columns were measured on 2026-08-27 at `e83438e`. **After** columns were
re-measured on 2026-08-30 at `2454f29`, from a freshly reseeded tenant for each path,
against the same database and the same seed.

**Every count in this document was re-checked on 2026-08-30 against a live stack**,
not against another sentence in it. A PostgreSQL cluster was built from empty, 18
migrations applied, the corpus seeded with `--repository store`, and the figures read
off the API: **18 migrations** (`schema_migrations`), **31 payouts**, **30 bank lines**
(both counted in the database), **25 `awaiting_approval` and 6 `blocked`** and **8 open
exceptions** (`GET /payouts`, `GET /exceptions`). Path D was then driven on the wire —
the pin recorded, the payout re-reconciled, the entry approved — and every line of its
BEFORE/AFTER block below reproduced, down to the draft entry id. Path F's rejection and
Path B's proposal were checked the same way. The one figure that did not survive is in
Path D's invariants table and is corrected there.

**Paths A, A′ and G were re-driven again on 2026-08-30 at `741ead9`**, after the
changes to check 5 and to the two surfaces that hand it a reviewer's pin, on a tenant
dropped and reseeded from empty so that nothing had been approved before the count was
taken. The press counts are unchanged — A is 2, A′ is 2*N*, G is 3. **One entity count
was wrong and is corrected below: Path G signs twenty-five entries, not twenty-four.**

---

## The scoreboard

| # | Path | Actions before | Actions after | Reads before | Reads after | Reaches a posted entry? |
|---|------|---:|---:|---:|---:|---|
| A | Clean payout, the one the queue pre-selects | 2 | **2** | 3 | 3 | Yes |
| A′ | …*N* payouts, one at a time | 2*N* | **2*N*** | — | — | Yes |
| B | Blocked payout → posted → agent proposal accepted | 14 | **12** | 7 | 6 | Yes |
| C | Blocked on a classification → posted | 11 | **9** | 6 | 5 | Yes |
| D | Blocked on a bank pin | 7 | **9** | 3 | 3 | **Yes** |
| E | Chart gap filed | 7 | **7** | 3 | 3 | No, by design |
| F | Rejection | 2 | **2** | 2 | 2 | Yes (withdrawn) |
| G | Bulk approve, 25 payouts at once | 3 | **3** | 3 | 3 | Yes |
|   | **Seven paths, total** | **46** | **44** | | | |

**Four presses removed, and they are the same two presses twice.** Both Path B and
Path C ended with the reviewer walking back to a record the product had never stopped
knowing about. That walk is gone. Nothing else moved, and the sections below say for
each remaining path whether that is because it is already minimal or because the
shortening would have cost something worth more than a press.

*The total row falls by two, not by four, and the two figures are not in conflict: B
and C give up two presses each, and Path D gains two — the handoff and the signature
it never had. 46 − 4 + 2 = 44. Spelled out here because a total that moves by half of
the headline number is exactly the kind of thing a reader is otherwise left to
reconcile from a paragraph three sections away, and every figure this document has had
to withdraw was arrived at that way.*

Three numbers matter more than the rest.

**G is already Apple Pay.** Twenty-five general ledger entries signed in three
presses. Whatever else is true, the volume path is done — and it is the one path
where I recommend against every shortening I could find. See *Path G*.

**D terminates.** It did not, for four rounds. A reviewer could do all seven steps
correctly, get a success plate, have their answer written into an append-only audit
table, and the payout was exactly as blocked as before. `vert-engine` `3507ba6` fixed
the engine half; the round of 2026-08-30 fixed ours. Path D now runs **9 presses**
from the rail to a signed entry, end to end, and the last two are the two it never
had: the handoff, and the signature.

That is **+2 against the 7 in the "before" column, and it is not a regression** —
those 7 presses bought a recorded assertion and stopped. The 2 that follow are the
ones that reach a general ledger entry, which no count of D has ever included before,
and there is no shorter way to sign something than to go to it and sign it.

**What was ours, and what it cost.** `lib/verifier.js` check 5 counted bank deposits by
amount and date alone, saw two, and reported *"1 of 6 checks do not agree"* — so the
queue held a payout the engine had already cleared, and correctly offered no approve
control on it. The check was not wrong about what it measured; it was measuring the
one thing a pin cannot move. It now honours a NAMED reviewer's recorded pin and still
refuses `tieToBank()`'s unaided match. See *Path D*.

**The remaining presses are load-bearing.** After the walk was removed, I could not
find a press in these seven paths that a person could skip and still see what they
were signing. The section *Where the steps actually are* takes each one in turn.

---

## Path A — a clean payout that just needs approving

**Before: 2 actions, 3 reads. After: 2 actions, 3 reads. Unchanged, and minimal.**

| # | Kind | Step | Obvious or hunt | Keep or remove |
|---|------|------|---|---|
| — | read | The landing page | — | — |
| 1 | click | Rail → Approvals | Obvious | **Keep** — see below |
| — | read | The queue opens with a row **already selected** | — | — |
| — | read | The journal preview, the verdict, the six checks, the working paper | — | — |
| 2 | click | Approve draft entry | Obvious | **Keep** — this is the signature |

This is the best path in the product and it is genuinely minimal. The queue
pre-selecting a row is worth a lot: it removes the click that every other
list-plus-detail screen charges before you can read anything.

**Why step 1 stays, though it looks like the cheapest press in the product to
remove.** Sign-in lands on `/` , which reads the tenant's connections and bank
mapping and then redirects: to `/setup` if anything is missing, otherwise to
`HOME_HREF`, which is `/payouts`. So on a finished tenant the reviewer still arrives
one click from the queue. Pointing `HOME_HREF` at `/approvals` would delete this press
from Paths A, C, F and G — and add it to every session that begins at the register
instead, which is the screen `app/page.js` calls "the work this product exists to do".
That is a trade between two audiences, not a saving, and it is the founder's call
rather than mine. Recorded here as an option, not taken.

### A′ — and then the second one costs two again

After an approval the selection **does not advance**. The approved row leaves the
"Awaiting you" list, the detail pane stays parked on the record just decided, and the
Approve control disappears from the screen entirely.

Driven on 2026-08-30, approving three clean payouts one at a time: **6 actions** — one
to reach the queue, three Approve presses, and two clicks to pick up the next row.
So approving *N* payouts one at a time costs **2*N*** actions.

> **A correction I am withdrawing.** The 2026-08-27 version of this document gave
> this as **1 + 2*N*** and put the 43-payout close at 87 presses. That is wrong and it
> was never measured; it was arithmetic done in my head. The rail click is paid once
> and there are only *N*−1 row clicks, so the total is 1 + *N* + (*N*−1) = 2*N*. For
> the 43-payout close named in `ApprovalQueue.js`'s own header comment the figure is
> **86**, not 87. The shape of the finding is unchanged; the number was wrong and I am
> correcting it rather than leaving it standing.

**I recommend against making the selection advance, and this is the recommendation I
am least willing to trade.** It would remove *N*−1 presses, which is the largest
single number in this document. It would also destroy a safety property the product
has today and that I verified while measuring: **after an approval there is no
approve control on the screen at all** — the count of "Approve draft entry" buttons
goes to zero. A second press, a double-click, a stuck key or an impatient hand hits
nothing.

Auto-advance would put a *different* payout's Approve button under the cursor, in the
same pixel position, within a few hundred milliseconds of the press that approved the
last one. That is not "one fewer click". That is a person signing a general ledger
entry they have not read, by pressing the same button twice. The bulk bar (Path G)
already exists to escape the per-payout cost, and it escapes it properly — by showing
the count before the press.

---

## Path B — a blocked payout with an agent proposal to accept

**Before: 14 actions, 7 reads. After: 12 actions, 6 reads.** Still the longest path in
the product, and the one whose shape is most likely to surprise.

**Accepting a proposal is not how work gets done.** It does not resolve, post or
reclassify anything, and it cannot be reached first. `ProposalDecision` requires an
`approvalId` — the id of an approval already recorded on that payout — so an
acceptance can only ever be recorded *alongside a signature a person has already
given*. On a blocked payout, Accept is disabled and says so:

> "This payout is blocked, so it cannot be approved and there is no approval for an
> acceptance to be recorded alongside… Resolve the break this exception is about
> first."

That is a deliberate and well-argued design: a machine cannot mint an approval id,
so an acceptance cannot be manufactured. It is **load-bearing and must stay**. But
it means the real order is: *resolve the break → approve the entry → then, on the
approvals screen, record that you agreed with the agent.*

| # | Kind | Step | Obvious or hunt | Keep or remove |
|---|------|------|---|---|
| 1 | click | Rail → Exceptions | Obvious | **Keep** — navigation to the queue |
| — | read | Scan the 8-row table for the payout | **Hunt** | see *the id in the prose cell*, below |
| 2 | click | Row → Investigate | Obvious | **Keep** |
| — | read | The proposal, the WHY, the critic's second read, the provenance block | — | — |
| 3 | scroll | Scroll the page to the classify panel | **Hunt** | **Keep** — see *the long page*, below |
| 4 | select | Account | Obvious | **Keep** — what is being asserted |
| 5 | select | Ground | Obvious | **Keep** — why it is being asserted |
| 6 | type | Note | Obvious | **Keep** — the words a later reader gets |
| 7 | click | Record classification | Obvious | **Keep** — the assertion |
| — | read | "The engine re-ran… the payout is now awaiting approval" | — | — |
| ~~8~~ | ~~click~~ | ~~Rail → Approvals~~ | ~~Hunt~~ | **Removed** |
| ~~9~~ | ~~click~~ | ~~Next page, looking for the payout~~ | ~~Hunt~~ | **Removed** |
| ~~—~~ | ~~read~~ | ~~Locate it in the queue (page 2 of 3)~~ | ~~Hunt~~ | **Removed** |
| ~~10~~ | ~~click~~ | ~~Queue row~~ | ~~Obvious~~ | **Removed** |
| 8 | click | "Approve po_8Hm →" on the outcome plate | Obvious | new — the address, not the signature |
| — | read | The journal preview, the verdict, the checks | — | — |
| 9 | click | Approve draft entry | Obvious | **Keep** — this is the signature |
| — | read | The proposal card is on this same screen | — | — |
| 10 | scroll | Scroll to the proposal decision | **Hunt** | **Keep** — see below |
| 11 | type | Note on the decision | Obvious | **Keep** |
| 12 | click | Accept | Obvious | **Keep** |

Driven end to end on 2026-08-30 against `po_8Hm`, from a reseeded tenant. The
acceptance landed: *"Proposal 1 accepted by key: steps-measure alongside approval 2,
and recorded in the audit trail."*

One correction to an earlier reading of my own, restated because it still stands: I
first concluded that Accept was a control that could never be pressed, because
resolving the exception removes it from the Exceptions table and takes that page —
and the proposal card on it — out of reach. That was wrong, and I withdrew it.
`ProposalDecision` is mounted on the **approvals detail** as well, which is where the
acceptance is meant to happen and where it does happen. Steps 10–12 are on the same
screen as step 9, with no navigation between.

---

## Path C — a blocked payout needing a classification

**Before: 11 actions, 6 reads. After: 9 actions, 5 reads.** Steps 1–8 of Path B, then
Approve. This is the path the founder's question is really about, and it is where the
four removed presses came from.

This path *works*: the engine re-runs on the assertion, resolves the exception, and
moves the payout to `awaiting_approval`. Verified against the database.

**What was removed, and why it was safe.** At step 7 the screen tells the reviewer, by
name, that *this payout* is now awaiting approval. Before, they then had to leave that
screen, navigate to a different one, page through a 25-row queue, and find the payout
they had been looking at a second ago — three actions and a hunting read to return to
a record the product never stopped knowing about. Now the outcome plate carries a link
to it.

The link is **the address of the signature, not the signature**. Pressing it navigates;
it approves nothing, selects nothing for a bulk action, and pre-fills nothing. The
reviewer still lands on the approvals detail, still reads the journal preview and the
six checks, and still presses Approve. Every figure they see before signing is
unchanged.

It is also gated on two reads that must both hold, and refuses on absence rather than
guessing: the engine's own re-run must report the payout in exactly `awaiting_approval`
— the one state `PAYOUT_TRANSITIONS` permits `→ approved` from — **and** the escalation
list must be *present and empty*. An absent list is not an empty one; a build whose
response omitted the field has not told us the payout is clear, it has told us nothing,
and pointing a reviewer at an approval screen on the strength of a field nobody read is
the unread zero this codebase refuses everywhere else. On absence, no link is drawn at
all. A payout that is still blocked gets no link, which is the same rule as *a blocked
payout offers no approve control*, applied one screen earlier.

**Verified live, 2026-08-30.** The link resolved to `/approvals?payout=po_8Hm`; the
screen opened on **page 2** of the queue with `po_8Hm` both selected in the detail pane
*and* visible in the list beside it. That last part is the failure this could easily
have been: a selected card on a page the reader is not looking at. The landing page is
computed from the same filter and the same page size the queue slices with, so it
cannot disagree.

---

## Path D — a blocked payout needing a bank pin

**Before: 7 actions, and it did not terminate. After: 9 actions, and it does.**

Re-driven end to end on 2026-08-30 at `41014b4`, at a true 1280, signed in as
`vansh-live` against a live `vert_api` over a live PostgreSQL — 18 migrations,
`--repository store`, 31 payouts, 30 bank lines, 8 open exceptions — on a database
seeded fresh for this measurement. `.next` was deleted and rebuilt from clean first,
and hydration was confirmed on the signed-in page before a press was counted.

| # | Kind | Step | Obvious or hunt | Keep or remove |
|---|------|------|---|---|
| 1 | click | Rail → Exceptions | Obvious | **Keep** |
| — | read | Scan the table for the payout (the id lives inside the Description cell) | **Hunt** | — |
| 2 | click | Row → Investigate | Obvious | **Keep** |
| — | read | The rail: description, source details, the two rival deposits | — | — |
| 3 | scroll | Scroll to the pin panel | **Hunt** | **Keep** — see *the long page* |
| 4 | click | Choose the settling deposit (radio) | Obvious | **Keep** — the fact asserted |
| 5 | select | Ground | Obvious | **Keep** |
| 6 | type | Note | Obvious | **Keep** |
| 7 | click | Record pin | Obvious | **Keep** |
| — | read | The outcome panel — what was recorded, and what the engine did next | — | — |
| 8 | click | **Approve po_14Pv →** (the handoff, deep-linked) | Obvious | **Keep** — see below |
| — | read | The journal preview, the verdict, the six checks | — | — |
| 9 | click | Approve draft entry | Obvious | **Keep** — this is the signature |

**Presses 8 and 9 are new, and they are the reason the path finishes.** Neither is a
step that was added to the work: 8 is the address of the screen where a person reads
what they are signing, and 9 is the signature. Path A pays exactly the same two.

### What the 9 presses actually produced

Read back off the API afterwards, not off the screen:

```
BEFORE  state       blocked — "Deterministic tie-out escalated: bank_unmatched."
        exceptions  bank_unmatched: "Paid, but 2 deposits match equally well
                                     (1 Jul line 29, 3 Jul line 30)."
        tie         {"status": "ambiguous", "candidates": [both]}
        assertions  []                      assertionsMeasured: true

AFTER   state       approved — "Approved by key: vansh laptop (approval 1)."
        approvals   [{approvalId: 1, decision: "approve", actor: "key: vansh laptop"}]
        entries     [("je:b0c15f19db19", "staged")]
        exceptions  []
        tie         {"status": "matched", "bankId": "1 Jul line 29"}
        assertions  [bank_pin / deposit_identified / ["1 Jul line 29"]
                     / actor "key: vansh laptop" / answersCheck "bank_unmatched"]
```

On screen: *"Approved by key: vansh laptop and staged as draft DRAFT-po_14Pv."*

**The exceptions register goes from 8 open to 7.** Measured on screen before press 1
and after press 9, and itemised against `GET /exceptions`, which reports the same
seven: `po_15Qw`, `po_16Rx` (both `bank_unmatched`), `po_13Nt` (`gst_undetermined`),
`SP-BROKEN`, `po_8Hm`, and `SP-9002` / `po_11Lq` (both `in_transit`). One payout left
the register, because one payout was resolved.

> **A correction to the previous round of this document,** which recorded "the
> exceptions register drops from 8 open to 6". It drops to **7**. I could not
> reproduce 6 on any of four seeded runs, and the register above accounts for all
> seven remaining items by payout and kind. The earlier figure is withdrawn.

### The invariants, checked rather than assumed

`/approvals?payout=<id>` was loaded for each of the five payouts still blocked and for
`po_14Pv` after its approval, and the approve controls on the page were attributed to
the record they belong to by walking up to the nearest container naming exactly one
payout:

| payout | still blocked on | approve controls **for it** | "checks do not agree" |
|---|---|---:|---|
| `po_15Qw` | `bank_unmatched` — the abstention | **0** | true |
| `po_16Rx` | `bank_unmatched` — no deposit at all | **0** | true |
| `SP-BROKEN` | `payout_integrity_break` | **0** | true |
| `po_8Hm` | `unclassified_txn` | **0** | false |
| `po_13Nt` | `gst_undetermined` | **0** | false |
| `po_14Pv` | *approved* | **0** | false |

> **A fourth correction, and it is the Path G mistake again.** Until 2026-08-30 this
> table had five rows and the sentence above it said six loads — "each of the five
> payouts still blocked **and** `po_14Pv` after its approval". Only four of the five
> rows were blocked payouts; the fifth was `po_14Pv`. **`po_13Nt` was missing**, and
> the omission was inconsistent with this document's own stated preconditions for as
> long as it stood: the header says 31 payouts and six blocked, one of the six is
> resolved on this path, so five remain and the table listed four.
>
> Re-measured 2026-08-30 on a database dropped and reseeded from empty — 18 migrations,
> `--repository store` — by driving the pin and the approval against the API and reading
> the state back off the wire rather than off a screen: **31 payouts, 25
> `awaiting_approval`, 6 `blocked` before**; and after `po_14Pv` is pinned and approved,
> **25 `awaiting_approval`, 5 `blocked`, 1 `approved`** — `SP-BROKEN`, `po_8Hm`,
> **`po_13Nt`**, `po_15Qw`, `po_16Rx`. That is the five the prose and the "Blocked (5)"
> chip have always claimed. The row is now there.
>
> **Its two screen columns said *not measured* until 2026-08-31, and now they are
> measured.** They were left blank deliberately: the other rows are readings taken off
> `/approvals?payout=<id>` in a browser, `po_13Nt` had never been loaded, and this
> product's rule is that an unread zero is not a measured zero. Copying **0** and *true*
> down from the rows beside it would have been the fabrication the rest of this document
> spends its length refusing — a figure that is probably right, arrived at by inference,
> printed as an observation. So the page was loaded.
>
> **How it was read.** A freshly seeded stack — 19 migrations (the set is 19 now, not the
> 18 this document quoted; `0019_supersede_the_unapproved` has landed since),
> `--repository store`, 31 payouts, tenant `vansh-live` — served by `vert_api.dev_server`
> against PostgreSQL with a `vert_authenticator` DSN, so the demo's sign-in has a real key
> to check rather than an open service to refuse. Signed in through the actual `/login`
> form with a key from `onboard issue-key`, then `/approvals?payout=po_13Nt` loaded in
> headless Chromium, and every approve control on the page attributed to the record it
> belongs to by walking up to the nearest container naming exactly one payout — the same
> method as the rows above.
>
> **Result: 0 approve controls for it, and "checks do not agree" is false.** The pane
> says *"Held — this payout is not ready to approve"*, and the payout's own figures are
> why the second column reads false: the wire has it `tie: matched` on 1 Jul line 28, its
> decomposition `integrityOk: true`, and its draft entry balanced across three lines with
> no suspense plug. Nothing disagrees. It is blocked because the GST split is unknown —
> *"Charge lines carry no tax figure"* — which is a question nobody has answered, not a
> check that failed. That is the same shape as `po_8Hm`, the other row reading false.
>
> **What validates the reading.** The same run re-read the four rows this table already
> carried, and reproduced all four exactly: `po_15Qw` 0/true, `po_16Rx` 0/true,
> `SP-BROKEN` 0/true, `po_8Hm` 0/false. A method that agrees with four recorded
> observations is the method that took them.
>
> **And the one precondition to state.** The reading was taken BEFORE the `po_14Pv` pin
> and approval on this path, so the queue chip reads "Blocked (6)" and `po_14Pv`'s own row
> would read 0/true rather than the 0/false recorded above — which is the expected
> difference and is itself the evidence that this run is the pre-press state. It does not
> reach `po_13Nt`: the two cells are per-payout, `po_13Nt` is not the payout being pressed,
> and its blocked reason is untouched by that path. The chip is a page-level count and is
> not one of the two cells.

A blocked payout offers no approve control at all, and after an approval there is no
approve control on screen. Both held. The queue's "Blocked (5)" chip counts those five
and does not count `po_14Pv` — an earlier reading of mine that the queue still called
`po_14Pv` blocked was a measurement error, reading the page-level chip as a row label,
and it is withdrawn.

### Why the last press did not exist before, and what changed

The wire carried the pin the whole time, on `bank_lines.matchedPayoutId`, and it was
not usable — which is the finding the previous round stopped at and was right to.

`matched_payout_id` is written by **ingestion**: `schema.sql` calls it a hint carried
by the feed, and a re-sync rewrites it. It is **also** written, as an overlay, by
`StoreRepository._with_pins` when a person records a `bank_pin`. One field, two
authorities, nothing on it to tell them apart. A verifier that read it would have
quietly started trusting ingestion, which is the one thing it exists not to do.

**The engine publishes the two separately, and this round used that rather than
inferring provenance from a shape.** Since `vert-engine` `d3528f0`, `GET
/payouts/{id}` carries **`assertions`** — the standing answers on file — each with its
`kind`, `value`, the `txnIds` it names, and the **`actor`** who recorded it and when;
beside **`assertionsMeasured`**, which says whether that layer could be read at all.
Measured on this run, `actor` came back `"key: vansh laptop"` — the API key label,
which is what the audit trail records. Ingestion cannot put a row there.

So `lib/verifier.js` check 5 now:

* still finds the deposit itself, by amount and date, and **still never reads
  `matchedPayoutId` and never reuses `tieToBank()`'s match** — the claim it is handed
  carries `tie`, and a test drives a claim whose tie states `matched` on one of the
  two rivals and requires the verdict not to move by a byte;
* accepts a **named** reviewer's standing `bank_pin` as evidence, and refuses anything
  it cannot attribute: a non-`measured` assertions block, an abstention, an answer of
  another kind, a record with no `assertionId`, and a record with no `actor`. A pin
  this verifier cannot attribute to somebody is worth exactly what `matchedPayoutId`
  is worth;
* **narrows only.** The pin is intersected with the candidates the check found for
  itself, so a pin naming a deposit that is $2 out, or outside the date window, or on
  a payout with no candidate at all, settles nothing — which is why `po_16Rx` above is
  still refused, and correctly.

### The two payouts that are still blocked, and are meant to be

`po_15Qw` is the **abstention**: two rivals, and nobody has said which. Check 5 counts
two, expects one, and refuses — which is the honest answer to a question nobody has
answered. `po_16Rx` is **paid with no deposit at all**: zero candidates against an
expectation of one, and no pin can conjure one. Neither is a bug, and both would be
hidden by a check that trusted the wire.

## Path E — filing a chart gap

**Before: 7 actions, 3 reads. After: 7 actions, 3 reads. Unchanged, and correctly so.**

Identical in shape to Path D's first seven presses, reached through a disclosure under
the classify panel labelled "None of these accounts is where this belongs". It stops
there and does not pay D's eighth and ninth, because there is nothing to approve —
see below.

It deliberately does **not** resolve the payout, and says so twice — before the press
and after it. Verified again on 2026-08-30:

> You recorded that no account in the chart is where this line belongs — the line
> keeps its category, the value stays in Payout Suspense, and the payout stays blocked
> on the same question until the chart can answer it.

That is correct. **This path is not a candidate for shortening.** It is a report, not
a resolution, and it is honest about being one. Every one of its seven presses is
either navigation to the record or a component of the report itself.

---

## Path F — a rejection

**Before: 2 actions, 2 reads. After: 2 actions, 2 reads. Minimal.**

Rail → Approvals, then Reject. Verified on 2026-08-30: the press is immediate, and the
draft entry is withdrawn with *"po_11Lq rejected, and its draft entry withdrawn."*

There is nothing to remove here. Worth flagging in the other direction: **a rejection
takes no note and no confirmation.** Every other recorded decision in the product
requires words — the classify panel, the pin panel, the chart gap panel and the
proposal decision all refuse to submit without a ground and a note, on the stated
grounds that "an acceptance with no words behind it tells a reader six months from now
that somebody clicked something". A rejection is also a recorded decision in the audit
trail, and it is the one that is signed in silence. That is an inconsistency, and the
fix for it would *add* a press rather than remove one. It is recorded here as a
question for the founder, not as a change I have made.

---

## Path G — a bulk action over several payouts

**Before: 3 actions, 3 reads. After: 3 actions, 3 reads.**

| # | Kind | Step | Obvious or hunt | Keep or remove |
|---|------|------|---|---|
| 1 | click | Rail → Approvals | Obvious | **Keep** |
| — | read | The queue: "25 approvable" | — | — |
| 2 | click | Select-all | Obvious | **Keep** — this is the scope |
| — | read | The bulk bar: "25 selected of 25 approvable" | — | — |
| 3 | click | Approve 25 | Obvious | **Keep** — this is the signature |

**This path is already minimal and I recommend it is not touched.** Re-driven on
2026-08-30 from a clean seed: three presses, twenty-five entries recorded.

> **A correction I am withdrawing.** Every figure in this section said **24** until
> 2026-08-30. It is 25. The queue reads "Awaiting you (25)", the select-all reads "25
> approvable", the bulk bar reads "25 selected of 25 approvable" and the button reads
> "Approve 25" — on a tenant dropped and reseeded from empty, with nothing pressed
> before the reading was taken. `GET /approvals` agrees: 31 payouts, 25
> `awaiting_approval`, 6 `blocked`, and 25 + 6 = 31.
>
> The 24 was arrived at the way a stale count usually is, and I made the same mistake
> again while checking it: the first reading of this re-drive also said 24, because it
> was taken after the same session had already approved one payout on Path A. A queue
> count read part-way through a drive is a count of what is left, not of what the path
> starts from. The document's own header states 31 payouts and six blocked, which
> implies 25 and never implied 24 — the figure was inconsistent with its own stated
> preconditions for as long as it stood.
>
> The press count is unaffected: it was three then and it is three now. What was wrong
> is the number of general ledger entries one of those presses signs, which is the
> largest consequence in this document.

The select-all ticks only what is selectable, so the number beside the button is the
number of entries that will be sent — no arithmetic for the reader to do. It selects
across the whole filter rather than the visible page, which is what keeps it at three
presses instead of four-per-page.

**Why nothing here should be shortened, in the terms the brief set.** This is the
highest-consequence control in the product: one press, twenty-five general ledger
entries. There are exactly two presses that could in principle go, and both fail the
same test:

- **Merging select-all into the Approve button** ("Approve all 25") would take it to
  two. It would also delete the moment where the reviewer sees the scope of what they
  are about to sign *as a separate act from signing it*. Today, pressing select-all
  and reading "25 selected of 25 approvable" is the step where a person confirms the
  number is the number they meant. Removing it means the first and only time the count
  is read is on the button they are already pressing. That is a person signing more
  entries with less shown, which is the one thing the brief says not to do.

- **Skipping the queue and offering bulk approve from the landing page** would take it
  to two as well, and would mean twenty-five entries approved by somebody who never
  opened the screen that lists them. Worse than the above.

One observation, in the safety direction rather than the speed one, unchanged from the
first measurement: twenty-five general ledger entries are signed here with **no
confirmation step**. The count is stated plainly before the press, which is the
strongest part of the design, but the press itself is final and immediate. If anything
in this document argues for *adding* a press, it is this one — and that is a decision
for the founder, because it costs the number he is trying to bring down.

---

## Where the steps actually are

Counting across all seven paths, the presses fall into three groups.

### Load-bearing — a person is seeing what they are signing

The account, the ground and the note on every assertion panel. The note on a proposal
decision. The Approve press itself. The select-all that states the scope of a bulk
approve. The requirement that an acceptance follow an approval. None of these should
be removed. **Removing a confirmation from a flow that writes to a general ledger is
where being wrong is expensive**, and every one of these is a step that exists so a
person sees what they are signing rather than a step that exists because nobody
removed it.

### Hunting — the cost is finding the control, not pressing it

**The three-action round trip from a resolved exception back to the same payout's
approval. This is gone**, in both paths that had it, and it was the single largest
removable cost in the product.

Two hunts remain, and both are honestly described here as *not* fixed:

**The id in the prose cell.** The exceptions table has no identifier column; a payout
id such as `po_15Qw` lives inside the Description text. Finding a specific payout is a
scan rather than a look. This costs a *read*, not an action — the founder said reading
is fine — so it is recorded and not acted on.

**The long page.** This corrects a claim in the first version of this document, which
described the exception detail as "a 280px rail" the reviewer scrolls. It is not a
narrow rail with its own scroller; the whole page scrolls, and it is long. Measured at
1440×1000 on `po_8Hm`, viewport 1000px, document 5964px:

| y | what is there |
|---:|---|
| 0 | top of the exception detail — description, source, account, the proposal |
| 1791 | "Show the reasoning behind this" |
| 3260 | Accept / Dismiss — **disabled on a blocked payout** |
| 3454 | top of "Suggested next steps" — the card holding the control that resolves it |
| 3947 | the first control inside it: the account selector |
| 5261 | "Record classification" — the press at the far end of a 2167px panel |
| 5964 | end of page |

So the reviewer scrolls about three and a half screens through the evidence before
reaching anything they can act on, and the last thing they pass on the way — the
Accept/Dismiss pair — is disabled on exactly the payouts where this page is used.

**I am not shortening it, and the reason is the ordering.** Those first 3454 pixels are
the proposal, the reasoning, the critic's second read and the provenance block: they are
the evidence, and the control sitting *after* the evidence is the correct order for a
screen where the next act is an assertion. Moving the classify panel above the proposal
would remove the scroll and would also let a person record a classification without
having passed the agent's reading and the critic's answer to it. That is a step that
exists so a person sees what they are signing, and the brief is explicit that such a
step is not ceremony.

### A change I built, measured, and took back out

The 2026-08-30 draft of this document proposed one more thing, and I built it: give the
disabled panel's own sentence — "Resolve the break this exception is about first" — an
in-page anchor to the panel that resolves it. It was written, styled, covered by ten
tests, and all nine mutations against it were caught.

**Then I drove it in a browser and it disproved its own premise.** The draft claimed the
disabled Accept pair sat "two full screens above" the control that resolves the payout.
It does not. It sits **194px** above the top of the resolve panel and **687px** above
that panel's first control — less than one viewport-height. I had reached "two screens"
by comparing the Accept button against `Record classification` at y=5261, which is the
*submit* button at the bottom of a 2167px panel. The distance a reviewer actually
travels is the one to where they start filling the panel in, not to the button they
press last, and by that measure the resolve panel is simply the next thing on the page.

There is no hunt there to remove. A link that saves two-thirds of a screen of scrolling
on a reader who is already scrolling downward is not worth a new control, a new prop and
a new class on the screen where assertions are made. The change was reverted in full —
component, rail, stylesheet and tests — and this paragraph is here instead of it.

That is the third figure of mine this document has had to withdraw, and all three were
found the same way: by driving the thing rather than reasoning about it.

### Ceremony — nothing

I did not find a press in these seven paths that exists for no reason. This product has
been through several review rounds and the obvious padding is already gone. After the
walk was removed, **every remaining press in every path is either the reviewer arriving
at the record, or the reviewer stating something that goes into the audit trail.**

That is the answer to the founder's question, and it is two answers rather than one.
The clicking he wanted gone was real, and four presses of it are gone. What is left is
not clicking. It is a person saying what they decided and why, and then signing it.
