# Every control, and whether a person can actually press it

Measured, not estimated. Every figure below came from a signed-in `vansh-live`
tenant driven against a live engine and a live PostgreSQL database — 17 migrations,
`--repository store`, 31 payouts, 30 bank lines — at a true 1280×900 and a true
390×844, on all twelve signed-in routes and on the three panels that only exist
after a press. **454 control observations.** Nothing here is read off the stylesheet.

Recorded four times across earlier rounds and deferred each time, because it is a
change to the chrome of every screen rather than something to bolt onto another
round's work.

---

## How a hit box was measured, and why not with `getBoundingClientRect`

**A box is not a target.** The two come apart in both directions, and both
directions occur in this product:

* a pseudo-element can extend a target well past its element's own rect — which is
  what the register's checkbox now relies on;
* something painted on top can shrink a target to nothing while both rects stay
  exactly as they were.

So the probe hit-tests. From each control's centre it steps outward along the four
axes with `elementFromPoint`, keeping the furthest point that still resolves to that
control, and reports what comes back. Two things this caught that a box reading
would have reported wrongly:

* **The wrapping `<label>` counts.** A checkbox or radio inside a label is pressed
  anywhere in that label. The first pass measured the `<input>` and reported the
  exception panel's identity radios as a 13×13 defect. They are not: their label is
  932×50, and clicking its far end checks the radio — verified by doing it. **That
  finding was withdrawn before anything was built on it.**
* **A control must be on screen to be hit-tested.** `elementFromPoint` answers only
  for coordinates inside the viewport, so the probe scrolls each control into view
  first. Without that it silently fell back to the box and reported 16×20.5 for
  register checkboxes whose real target is the 40×47 cell — on exactly the rows that
  happened to be below the fold.

A text field is *not* widened by its label: a label focuses a field but does not let
you place the caret, so the field itself is the target that counts.

---

## The threshold

| where | figure | source |
|---|---|---|
| every width, every control | **24 × 24** | WCAG 2.2 SC 2.5.8 *Target Size (Minimum)*, Level AA — normative |
| 390, controls that sign ledger entries | **44 × 44** | SC 2.5.5 (AAA); Apple HIG 44pt; Material 48dp |

Two exceptions in SC 2.5.8 are taken, and one is deliberately refused.

**Taken — the inline exception.** A link inside a sentence is sized by the line
height of the prose around it, and growing it moves the paragraph. Six such links
(`/privacy`, `/terms`, the clearing-account note on `/payouts`, the setup link on
`/connections`) are exempt and are left alone.

**Refused — the spacing exception.** SC 2.5.8 also passes an undersized target when
no other target's centre is within 24px. Measured, *every* undersized control in
this product had its nearest neighbour 29–235px away, so **the product already
conformed at AA before this change**. The exception asks whether a press will land
on the *wrong* control. It does not ask whether a press will land on the control at
all. On a 15px checkbox that decides which payouts get signed, those are different
promises, and only the second one is the product's job. So the size is held to and
the exception is recorded rather than used.

---

## What was measured, and what it is now

`before` and `after` are both hit-tested, at 1280 unless the row says otherwise.

| control | routes | before | after |
|---|---|---|---|
| **row / header checkbox** `.cbx` | `/`, `/payouts`, `/approvals` | **15 × 15** | **40 × 47** |
| — the same, at 390 | | 15 × 15 | 39 × 46.5 |
| **approvals card checkbox** `.cbx` | `/approvals` | **15 × 15** | **24.5 × 44** |
| **bulk select-all** `.appr-bulk-all` | `/approvals` | 100.7 × 18 | 101 × 36 |
| **Sign out** `.side-gear` | all ten signed-in routes | **39.7 × 14.3** | **40 × 25** |
| **exception detail close** `.exc-rail-close` | `/exceptions` panel | **20 × 20** | **24 × 24** |
| register search `input[type=search]` | `/`, `/payouts` | 205 × 21.5 | 205 × 34 |
| queue search `input[type=text]` | `/approvals` | 277 × 21.5 | 277 × 34 |
| exceptions search `input[type=text]` | `/exceptions` | 879 × 21.5 | 879 × 34 |
| API key field `input[type=password]` | `/connections`, `/setup` | 856 × 21.5 | 856 × 38 |
| statement picker `input[type=file]` | `/connections` | 246 × 21 | 246 × 25 |
| "Why" disclosure `summary` | `/exceptions` | 24.8 × 18 | 31 × 24 |
| legal contents links | `/privacy`, `/terms` | ~120 × 19 | ~122 × 29 |

**At 1280 nothing in the product is now under 24 × 24.**

---

## Re-verified by driving the controls, 2026-08-30 at `741ead9`

The table above is a measurement. This is the check that it is still true, taken
independently: a fresh clean build, a tenant dropped and reseeded from empty on a
local PostgreSQL — **18 migrations** now, not 17 — 31 payouts, 6 blocked, 8 open
exceptions, signed in with a key issued by `onboard issue-key`, at a true 1280 × 900
and a true 390 × 844.

Every figure in the table reproduced to within a pixel. (The probe counts inclusive
pixels, so a target whose rect is 24.0 reads as 24 or 25 depending on where the
centre rounds; that is the arithmetic, not a discrepancy.) Spot figures: Sign out
40 × 26 against a 39.7 × 24.3 rect; select-all 101 × 37; approvals card checkbox
25 × 45; exception detail close 24 × 25; register search 205 × 35; file picker
246 × 26; "Why" 31 × 25.

**No walk was truncated by the fold.** Every one of the outward walks stopped because
another element answered, never because the coordinate left the viewport — which is
the failure the section above records and the one this probe was written to refuse
rather than paper over. Where a walk did hit its step limit (the 879px exceptions
search at 1280) the figure is reported as a lower bound rather than a size.

### The presses

Geometry is not the claim; a press landing is. So each of the three checkbox targets
was pressed at the four extreme points of its own measured hit box — one pixel inside
each edge, on the control's centre lines — and at the centre, and the input was read
before and after. **Thirty presses, thirty toggles, at both widths.**

| control | 1280 | 390 |
|---|---|---|
| register **row** checkbox `.pt td.mid > .cbx-hit` | 40 × 46, all 5 toggle | 39 × 47, all 5 toggle |
| register **header** checkbox `.pt th.mid > .cbx-hit` | 40 × 78, all 5 toggle | 39 × 105, all 5 toggle |
| approvals card checkbox `.appr-card-row > .cbx-hit` | 25 × 45, all 5 toggle | 25 × 45, all 5 toggle |

> **A measurement I am withdrawing.** The first run of this press probe reported the
> right, top and bottom edges of the header and card checkboxes as **DEAD**. They are
> not. It measured the hit box once and then pressed four times into it, and the first
> press opens the bulk-action bar, which moves the layout under the three that follow.
> Each press now gets a fresh page load and fresh geometry, and every one of them
> lands. The earlier reading was an artefact of the probe, not a property of the
> product, and nothing was built on it.

### One correction to the table above

**The header checkbox does not measure 40 × 47.** The row `.cbx` and the header `.cbx`
share a line in the table, and they are not the same size: the target is the cell, and
the header cell is taller than a body cell because its label wraps. Measured
**40 × 78 at 1280 and 39 × 105 at 390**, against the body row's 40 × 46 and 39 × 47.
Both are far past the floor and the mechanism is exactly the one the table describes —
`inset: 0` against a positioned cell — so this is a figure that was too small, not a
target that is. The 40 × 47 is the row.

### Where a target is deliberately under 44 on one axis

Two controls do not reach 44 × 44 at 390, and both are capped on purpose, argued in
`app/globals.css` at the rule:

* the register row/header checkbox is **39 wide**, because the target is the cell and
  the cell is the ceiling — growing past its edge would put "select this payout for
  signing" on top of "open this payout";
* the approvals card checkbox is **25 wide**, because the row begins at the viewport
  edge at 390 and sideways growth there hangs off-screen.

Both clear 44 on the axis that can carry it (46, 47, 78, 105 and 45), and both clear
24 × 24 on every axis at every width. Reported here as recorded judgements rather than
findings — an earlier draft of this section flagged them as failures against a 44 × 44
floor that this document does not claim for them.

### The row checkbox is the one that mattered

It was the smallest target in the product and it sits on the highest-consequence
control in it: these checkboxes choose the payouts that bulk approve signs, and one
press of Approve signs every one of them. 15 × 15 is 225 px². The cell is 1,880 px²
— **8.4× the area**, and it is dead space being spent, not space taken from anything
else: the cell already swallowed clicks so that ticking a box would not also expand
the row.

---

## Enlarging a target without moving anything

Two techniques, and the choice between them is forced by what the control is.

**A padding-and-negative-margin pair**, for everything that is not a checkbox:

    padding-block: 5px;   margin-block: -5px;

Padding grows the border box, which is what the pointer is tested against. An equal
negative margin shrinks the *margin* box back, and the margin box is what the parent
lays out against. The target grows; nothing moves.

**A wrapping `<label>` with an out-of-flow `::after`**, for checkboxes, because the
pair above does not work on one. `input[type=checkbox]` is a replaced element and
Chrome lays it out at its intrinsic size — `box-sizing: content-box; padding: 5px`
was tried first and `getBoundingClientRect()` still reported 15 × 15 — and a
replaced element renders neither `::before` nor `::after`. A label is a real box,
and a press inside it toggles the input with no JavaScript at all.

### Proof that nothing moved

Page height, page width, table width, every `tbody` row height and the rail's height,
captured before and after across all 24 route/width pairs: **identical on every one.**
Checked visually at both widths as well.

Getting there took three corrections, each found by measuring rather than by
reasoning:

1. **The label was absolutely positioned at first**, which left the register's
   checkbox cell with no in-flow content — and the header row was 2px taller than its
   own text *because* the checkbox's line box was setting it. `thead` went 49.8 → 47.8
   on `/payouts` and `/`. Two pixels, and still the thing this change is not allowed
   to do. The label is now a plain in-flow block and only its `::after` is out of flow.
2. **The file picker grew the page by 2px.** `BankStatementImport` sets
   `marginBottom: 10` as an *inline* style, which beats a stylesheet's `margin-block`,
   so half the cancellation never applied. It grows upward instead, which is exactly
   neutral.
3. **The approvals card checkbox hung off the screen.** See below.

---

## What was not enlarged, and why

**The 28–40px band at 390** — pagination `.pg`, the icon buttons `.iconbtn` and
`.gbtn`, `.btn`, `.nav-item`, `.chip`, `.tab`, the selects, the rail's close. All of
them clear 24 × 24. None reaches 44 × 44, and none was grown to it, because the gaps
between them are measured and smaller than the growth would need:

| group | smallest gap | control | growth needed per side |
|---|---:|---:|---:|
| `.iconbtn` on `/payouts` | **−1px** (touching) | 36px | 4px |
| `.btn` on `/approvals` | **2px** | 30px | 7px |
| `.pg` on `/approvals` | 4px | 28px | 8px |
| `.tab` on `/approvals` | 4px | 40px | 2px |
| `.chip` on `/approvals` | 6px | 33px | 5.5px |

Every one of these would overlap its neighbour. The `.btn` row on `/approvals` is
the case that settles it: the adjacent pair is **Approve draft entry** and **Reject**,
2px apart. Growing Reject to 44 would put its hit box 5px inside Approve's. A bigger
Reject next to Approve is worse than a small Reject, so it stays as it is.

**44 × 44 is not reached for the checkboxes at 390**, and this is recorded rather
than rounded up:

* the **register** checkbox already fills its cell edge to edge. The column is 34–40px
  by design and the only way to 44 is to widen it, which moves the table. Outside the
  cell is the row, which is itself a control that expands the payout — so the cell is
  both the fix and the ceiling.
* the **bulk select-all** fills its 36px bar.
* the **card checkbox** is 24.5 × 44 — the touch figure on the axis that can carry it,
  the floor cleared on the axis that cannot.

**The approvals card checkbox, twice measured wrong.** It was first given 9.5px of
symmetric padding on the reasoning that the row's 10px flex gap would absorb it. It
does, on the right. It does not on the left: at 390 the card row begins at the
viewport edge, and the probe found the label at **x = −9** with all ninety of its
points covered by the rail. 5px each way survived that, but hit-testing still returned
**20px** of pressable width rather than 25 — the left 5px sits outside the row and does
not answer to the pointer. All of the growth now goes right, into the gap, which
belongs to this row and holds nothing.

**One class of bug this change could have shipped and did not.** `.cbx-hit` was
written first as a bare class carrying `position: absolute`. The approvals queue's
card checkbox uses the same class in a plain flex row with no positioned ancestor, so
the rule threw it against the *initial* containing block and it rendered at the
top-left corner of the document, underneath the rail, on every approvals card at 390.
Nothing in the suite would have caught it and it is invisible at 1280. The nine-point
probe reported it as ninety covered points and named `ASIDE.sidebar` as what was
sitting on them. A class that means "fill the cell" must say which cell, or it fills
the page.

---

## The probe, re-run

`elementFromPoint` at nine points inside each control's box, after scrolling it into
view, on every route at both widths:

    438 controls, 3768 points, 0 problems

A stricter variant was also run, testing the nine points of each control's *measured
region* — including its four corners, which the axis walk never visits. It reports 783
problems. **It reports exactly 783 on the unmodified build as well**, so the number is
a property of the existing UI's shape (a pressable region is not always a rectangle;
most of them are `.nav-item`s whose vertical walk crosses into the nav's gap) and not
a regression. This change contributes zero.

Behaviour, driven at both widths:

* a press in the far corner of the checkbox cell — 10px from the glyph — selects the
  payout, does **not** expand the row, and brings up the selection bar;
* a press in the middle of the row expands it and does **not** change the checkbox.
