# Vert V1 — Verified Status

**Verification run:** 2026-08-06 **(second pass, evening)** — previous passes 2026-08-06
morning and 2026-08-03.
**Verified by:** full-system measurement pass. No feature work was done in this run.
Where a claim in a previous revision was found stale, the stale claim is named in §6
rather than edited away. **§6a is the 2026-08-06 morning drift list, §6b is the
dead-capability list, and §6c is the evening drift list. §8 is the release-readiness
verdict.** If you have read this document before, read §6c and §8 first.

> **~~THE SUITE IS RED AS OF THIS PASS.~~ RESOLVED WITHIN THE HOUR — and the sequence is
> worth keeping, so it is struck rather than deleted.**
>
> Measured mid-pass: `1 failed, 1943 passed, 134 skipped`, the failure being
> `tests/test_boundary.py::test_vert_engine_never_imports_vert_connect`, tripped by a
> QuickBooks poster under construction in another agent's session.
>
> **Re-measured at the end of the same pass: `2185 passed, 1 skipped`.** The other agent
> reworded the offending docstrings *and* added four more boundary tests (16 → 20), and
> Postgres containers came up, so the 134 Postgres-gated skips now execute instead.
>
> **The tree moved three times during one documentation pass** (1940 → 1943 → 2185
> passing). This is the clearest possible illustration of the standing caveat in §2.1:
> **do not quote a test count from this document without re-running it.** The count is a
> photograph of a moving object.

Sections not touched on 2026-08-06 still carry their 2026-08-03 measurement and say
so. Where a §2 block was re-run today it is dated in place.

This document exists because the value of this project's eval work is that it does
not overclaim. A benchmark number is worth exactly as much as the reader's ability to
reproduce it, so every claim below carries the command that proves it, and every claim
that *cannot* be proved in this environment is quarantined into §3 and §4 instead of
being softened into §2.

The distinction the whole document turns on:

- **§2 Verified** — a command was run in this environment on 2026-08-03 and its output
  is pasted below, unedited.
- **§3 Written but unverifiable here** — the code exists and is reviewed, but the thing
  that would test it (a PostgreSQL server, a live vendor credential, a model key, a
  Shopify approval) is not available. **Reviewed is not tested.**
- **§4 Not built** — no code, or a placeholder.

---

## 1. Headline

| Measure | Result | Status |
|---|---|---|
| Python test suite | green. **Count deliberately not pinned** — it read 1940 → 1943 → 2185 → 2189 during one pass, and **2505 passed / 1 skipped** on the 2026-08-06 final pass. Re-run it; §2.1 | green |
| Demo test suite | **278 passed, 0 failed** (2026-08-06 final pass; was 178) | green |
| Mutation sweep (can the benchmark detect a broken engine?) | 4 / 4 detected | green |
| Auto-resolution rate | **88.1% weighted / 72.1% unweighted (31/43 graded)** — quotable only beside the two rows below and the stratum mix the report prints | at baseline |
| Silent-error rate | **0.0% (0/43)** | at target |
| Correct-decline rate | **11.9% weighted / 27.9% unweighted (12/43)** | — |
| Engine release gate | 161 / 161 (100.0%) | green |
| Demo export determinism | byte-identical across 2 fresh runs; **committed file still DRIFTED — see §2.5** | red |
| Live model, end to end through the export | ran; `live:true`, and **not one number moved** — §6c.2 | green |
| Live Stripe ingestion | real API answered; the dispute refinement fires on a real node — §3.4 | green |
| Live Shopify GraphQL | real store answered; the adapter reads the correct tax field — §3.4 | green |
| Managed Postgres (Neon), RLS enforceable | connected as `vert_app`; not superuser, not `BYPASSRLS`; 10 policies, RLS forced on 8 tables | green |
| Deployed RLS matches `schema.sql` | **yes, as of the 2026-08-06 final pass — §9.4.** All 13 policies on Neon match; `payouts` is back to `tenant_id = vert_current_tenant()`, which RAISES on an unset session. Verified by a live read that was itself refused with `insufficient_privilege`. | green |
| API routes exercised | 10 / 10 against a real SQLite store (2026-08-06 morning, not re-run) | green |
| SP-BROKEN blocked | yes — engine, demo, API, **and under a live model** | green |

> **2026-08-06, FINAL PASS.** The table above has been re-measured and two of its rows
> moved: the demo suite (178 → 278) and the RLS row (red → green). The prose
> immediately below is the *evening* pass's account and is kept as written; where it
> is now out of date the correction is in **§9**, which is the final pass's record and
> is the section to read first. §9.3 is the list of places the product still sends a
> bookkeeper to a terminal, which is the deliverable that pass was asked for.

**Two things were red and neither is the arithmetic.** Auto-resolution, silent errors,
the release gate and the mutation sweep are all unmoved, and the central architectural
claim got *stronger* this pass: running the whole export against a real OpenAI model
changed the narration and **left every number byte-identical** (§6c.2).

What is red:

1. **The committed demo export** still shows an understated GST figure on `SP-9001`
   (§2.5) — unchanged since this morning, one command to fix, and no test can see it.
2. ~~**The RLS policy actually deployed on the managed database is not the one in
   `schema.sql`.** On `payouts` it fails quiet where every other table fails loud
   (§6c.3).~~ **FIXED and re-verified on 2026-08-06 (final pass) — see §9.4.** Struck
   rather than deleted, because the gap that let it happen — there is still no drift
   check between `schema.sql` and a live database — is not fixed.

*(A third — a red test suite — appeared and was resolved during this pass; see the note
above and §6c.1.)*

What changed since 2026-07-31 is mostly *coverage*: the suite grew from 669 to **well
over two thousand** tests with the arrival of `vert_api`, `vert_engine/tenancy`,
`vert_engine/observability`, `vert_agent/secrets`, the migration runner and the live
PostgreSQL suite. Two items previously in §4 (Not built) have moved up: the demo now
has a real test suite, and there is now a working HTTP API.

*(An exact figure stood here and has been removed rather than updated a fifth time —
§2.1 explains why this document no longer pins one.)*

---

## 2. Built and VERIFIED

Everything in this section was executed in this environment. Run from
`/Users/vanshm/Documents/Vert/Accounting/vert-engine` unless stated otherwise.

> **Dates vary within this section and each block says which it carries.** The original
> pass was 2026-08-03; §2.1, §2.3, §2.5 and §2.6 were re-run on 2026-08-06 morning; and
> §2.1, §2.2, §2.3, §2.4 and §2.5 were re-run again on **2026-08-06 evening**. A block
> with no evening date still carries its earlier measurement — notably §2.7–§2.11
> (demo build, API routes, dependency surface), which were **not** re-run this evening
> and should not be quoted as current without doing so.
>
> Re-run and unmoved on 2026-08-06 evening: release gate **161/161**, mutation sweep
> **4/4**, benchmark **0.9073 weighted / 1.0000 correct / 0 silent / 0 false-escalation**,
> export determinism (two fresh exports byte-identical), demo suite **178 passed**.

### 2.1 The deterministic engine and its services — green, count not pinned

> **Re-measured four times on 2026-08-06 evening, and it changed every time.** This
> heading read ~~**2073 tests**~~ (morning), then ~~**1 failing**~~ (mid-pass), then
> ~~**2185**~~, then 2189 — the last two being the same command minutes apart. The
> intermediate states are kept in §6c.1 rather than erased, because how a number moved
> is more informative than the number.

```
.venv/bin/python -m pytest -q          # Postgres containers up
```

```
2185 passed, 1 skipped, 1 warning in 30.48s      # 21:0x
2189 passed, 1 skipped, 1 warning in 29.73s      # 21:1x, same command, minutes later
```

**Both runs are shown because the second one is the point.** Four tests arrived between
two invocations of the same command while this paragraph was being written. Across this
single pass the total went **1940 → 1943 → 2185 → 2189**.

**This document therefore declines to state a current test count as a fact.** The suite
is green; the number is whatever `pytest -q` says when you run it.

**Both parts of that improvement have a cause, and neither is "the engine got better":**

1. **A failure was fixed while this pass ran.** Mid-pass the suite reported
   `1 failed, 1943 passed, 134 skipped` — the `vert_connect` boundary guard, tripped by
   docstrings in an in-flight QuickBooks poster. Another agent reworded them and **added
   four more boundary tests** (16 → 20), which is the right response to a guard firing.
   §6c.1.
2. **The 134 Postgres-gated skips now execute**, because containers are up
   (`vert-pg` on 55432, `vert-pg-tenancy` on 55433). Without a server they skip and
   never fail — that is by design (§3.1) and is not a defect to be "fixed".

So the honest reading of `2185 passed` is: *the suite is green, on a machine with
Postgres running, at one instant in a tree three agents were writing to.* Re-run it.

The single remaining skip is the documented one: a path that requires opentelemetry to
be absent from the process entirely, covered by a sibling file that blocks the import.

> **This number is a snapshot of a moving tree, and saying so is the point.** The same
> command returned **2065 passed, 1 skipped** at 08:2x and **2073 passed, 1 skipped**
> at 08:56 on the same day — eight tests arrived in between. `find . -name '*.py'
> -newermt 2026-08-06T07:30` showed `vert_engine/money.py`,
> `vert_engine/confidence.py`, `tests/test_boundary.py` and
> `tests/test_ingestion_stripe.py` all written within the preceding ten minutes, and a
> package that appears in none of these three documents — **`vert_connect/`** (a live
> Stripe HTTP client, `vert_connect/stripe_http.py`) — created the same morning. Every
> run in this section was green; the count moved because the codebase moved. Do not
> treat a single total from this document as reproducible to the digit without
> re-running it.

**The one skip, named rather than buried** (`-rs`):

```
SKIPPED [1] vert_engine/observability/tests/test_export.py:172: this path needs
opentelemetry to be absent entirely. Exercised by running the suite with the import
blocked; see test_runtime_absent.py for the technique.
```

That is an honest skip: the path *is* covered, by a sibling file that blocks the
import, and the skip exists because both cannot hold in one process.

The single warning is a Starlette deprecation notice from FastAPI's TestClient
(`install httpx2`). It is third-party, not ours, and affects no assertion.

Distribution across the suite, so a reader can see where the coverage actually sits
rather than trusting a single total (files with ≥25 tests):

| Tests | File | What it covers |
|---:|---|---|
| 84 | `tests/test_journal.py` | JE construction, balance, minor units |
| 152 | `vert_engine/state/tests/test_store.py` | transitions, entry ids, audit chain — **on SQLite and on real PostgreSQL**, §3.1. The Postgres half skips without a server. |
| 79 | `vert_engine/state/tests/test_rls.py` | RLS policy DDL — parse-only, and deliberately so: it is the RLS coverage that cannot skip. Execution is `test_rls_live.py`, §3.1 |
| 32 | `vert_engine/state/tests/test_rls_live.py` | RLS **executed** — two tenants, one database, read/update/delete isolation with a mutation proof each. Skips without a server. |
| 76 | `vert_bench/tests/test_independence.py` | benchmark can't grade itself |
| 66 | `vert_engine/tenancy/tests/test_keys.py` | API-key hashing/lookup |
| 65 | `tests/test_ingestion_shopify.py` | GraphQL seam, MoneyV2 via Decimal |
| 56 | `tests/test_ingestion_stripe.py` | pagination, float refusal, tax rule |
| 55 | `vert_api/tests/test_shape_contract.py` | response shapes are frozen |
| 49 | `vert_agent/secrets/tests/test_refs_and_resolver.py` | `key_ref` resolution |
| 48 | `vert_engine/state/tests/test_migrations.py` | migration refusals — **see §3.1** |
| 48 | `vert_api/tests/test_config.py` | config parsing and refusals |
| 46 | `vert_engine/tenancy/tests/test_isolation.py` | two tenants, written as an attack |
| 45 | `tests/test_fixtures.py` | fixture integrity |
| 43 | `vert_agent/secrets/tests/test_env.py` | env resolver |
| 43 | `tests/test_posting_xero.py` | account mapping, idempotency tag |
| 40 | `vert_engine/observability/tests/test_config.py` | otel config |
| 39 | `vert_engine/tenancy/tests/test_auth.py` | authenticator |
| 39 | `vert_agent/secrets/tests/test_structure.py` | no secret on an attribute/repr |
| 36 | `vert_agent/transports/tests/test_litellm_transport.py` | transport — **see §3.2** |
| 34 | `vert_engine/observability/tests/test_semconv.py` | span naming |
| 32 | `vert_agent/tests/test_pipeline.py` | reconcile→propose→critique→persist |
| 31 | `vert_engine/observability/tests/test_spans.py` | span emission |
| 31 | `vert_engine/observability/tests/test_cardinality.py` | metric cardinality bounds |
| 29 | `vert_agent/secrets/tests/test_redaction.py` | no leak via log/traceback |
| 28 | `vert_agent/secrets/tests/test_cloud_resolvers.py` | AWS/GCP — **see §3.5** |
| 27 | `vert_engine/observability/tests/test_cache_alarm.py` | cache-hit alarm |
| 26 | `vert_agent/secrets/tests/test_connectors.py` | connector wiring |
| 25 | `vert_engine/state/tests/test_schema_drift.py` | state vocabulary written 3× |
| 25 | `vert_engine/observability/tests/test_metrics.py` | metric definitions |
| 25 | `vert_agent/secrets/tests/test_cache.py` | secret cache TTL |

Full per-file counts: `.venv/bin/python -m pytest -q --collect-only`.

### 2.2 The benchmark is not blind — 4/4 mutations detected

This is the load-bearing check. An eval that has never been observed to fail is not
evidence; it is decoration. The sweep deliberately breaks the engine four ways and
requires the benchmark to notice each one.

```
.venv/bin/python -m vert_bench.mutation
```

```
==============================================================================
VERT BENCH — MUTATION SWEEP (can this benchmark detect a broken engine?)
==============================================================================
baseline: 42 case(s)  auto-resolved 0.9073  correct 1.0000  silent 0  false-esc 0
          baseline via vert_bench.runner.run(corpus[50], convention=clearing_bridge, gst_treatment=split_out)
------------------------------------------------------------------------------
[ OK  ] fee_sign_flip
         Processing-fee leg posted on the wrong side
         DETECTED — auto-resolution 0.9073 → 0.0133; correctness 1.0000 → 0.0250; false escalations 0 → 30 (caught by the engine's own self-check)
[ OK  ] gst_leg_dropped
         GST/Tax Payable folded into Product Revenue
         DETECTED — auto-resolution 0.9073 → 0.7507; correctness 1.0000 → 0.8408; silent errors 0 → 7 (caught by authored ground truth)
[ OK  ] bank_tie_tolerance_60d
         Bank-tie date tolerance widened from 4 days to 60
         DETECTED — correctness 1.0000 → 0.9860; silent errors 0 → 1 (caught by authored ground truth)
[ OK  ] refunds_to_processing_fees
         Refund gross booked to Payment Processing Fees
         DETECTED — auto-resolution 0.9073 → 0.6993; correctness 1.0000 → 0.7920; silent errors 0 → 8 (caught by authored ground truth)
------------------------------------------------------------------------------
All 4 mutations detected. The benchmark has been observed to fail on a broken engine, which is the minimum required before its number means anything.
==============================================================================
```

Note what each mutation is caught *by*. `fee_sign_flip` is caught by the engine's own
self-check — the engine notices and escalates. The other three are caught **only** by
externally authored ground truth, which is the reason authored ground truth exists:
three of four realistic breakages are invisible to any check the engine runs on itself.

### 2.3 Correctness headline — unchanged

```
.venv/bin/python -c "from vert_bench.runner import run; from vert_bench.report import render; from vert_bench.cases import ALL_CASES; from vert_bench.spec import PostingConvention as PC, GstTreatment as GT; out=render(run(ALL_CASES, convention=PC.clearing_bridge, gst_treatment=GT.split_out)); i=out.find('1. Auto-resolution'); print(out[i:i+600])"
```

```
1. Auto-resolution rate
      weighted 90.7%   unweighted 73.8%   (31/42 cases)
      Share of graded payouts carried end to end with no human touch AND matching the authored entry
      line for line. Balanced-and-confident is not enough; only an externally-authored match counts.
      31 of 42 graded cases were authored as auto-resolvable — that is the ceiling this rate can
      reach.

  2. Silent-error rate
      weighted 0.0%   unweighted 0.0%   (0/42 cases)
      Share of graded payouts where the engine was confident and wrong — a balanced, unblocked entry
      that does not match the
```

Identical to the recorded baseline of 90.7% / 73.8% / 0 silent errors. The engine's
auto-resolution rate has not moved.

Read the ceiling honestly: 31 of 42 auto-resolved against 31 authored as
auto-resolvable — the rate is **at** its ceiling, not below it. The unweighted rate is
73.8% because 11 of the 42 cases were *authored to require a human* — the engine
escalating them is correct behaviour, not failure.

> **Corrected 2026-08-06.** This paragraph read *"against 32 authored as
> auto-resolvable … 10 of the 42 … There is 1 false escalation in the corpus."* The
> corpus now grades **0 false escalations** and correctness is **1.0000**, not 0.9900.
> The corpus itself also grew from 42 to **50 authored cases, 42 of them graded** (8
> skipped, 0 errors) — measured today with
> `run(ALL_CASES, …).n_cases / n_graded / n_skipped`. A correctness figure of exactly
> 1.0000 is the kind of number to distrust rather than celebrate: it means every
> graded case now lands on its authored outcome, so the corpus has stopped
> discriminating and needs harder cases before this figure means anything more.

### 2.4 Engine release gate — 161/161

```
.venv/bin/python -m vert_engine.evals.harness
```

```
============================================================
VERT ENGINE — RELEASE GATE
============================================================
[PASS] decomposition_ties               50/50
[PASS] je_balanced                      75/75
[PASS] founder_summary_reconciles       25/25
[PASS] adversarial_integrity            4/4
[PASS] adversarial_confidence           2/2
[PASS] matching_no_false_positive       5/5
------------------------------------------------------------
[PASS] TOTAL 161/161  (100.0%)
============================================================
```

### 2.5 Demo export is deterministic

```
.venv/bin/python -m vert_engine.export_demo \
  /Users/vanshm/Documents/Vert/Accounting/vert-demo/lib/engine-output.json
```

Exports 26 payouts (the corpus is 27 as of 2026-08-23; this is the run as it was made). Tail of the run:

```
  SP-9012      ties=True  balanced=True  tie=matched   exceptions=[]
  SP-9002      ties=True  balanced=True  tie=unmatched exceptions=['in_transit']
  po_11Lq      ties=True  balanced=True  tie=unmatched exceptions=['in_transit']
  SP-9013      ties=True  balanced=True  tie=matched   exceptions=[]
  po_12Mr      ties=True  balanced=True  tie=matched   exceptions=[]
  SP-BROKEN    ties=False balanced=True  tie=matched   exceptions=['payout_integrity_break'] proposals=1
```

Determinism is a property worth proving rather than asserting, because a demo export
that drifts between runs would make every screenshot unreproducible. **The export is
still deterministic. The committed file is no longer what it produces.** Measured
2026-08-06:

```
fc201ab47e4e23886e85ec9044b29ea3762c6d693b241c9d356d87d4e740ec57  /tmp/a.json
fc201ab47e4e23886e85ec9044b29ea3762c6d693b241c9d356d87d4e740ec57  /tmp/b.json
df412094a013fcab07cc97edb3dc7b19b0adb10382be52918323cb04ebad8237  .../vert-demo/lib/engine-output.json
```

> **THIS SECTION'S CLAIM WAS FALSE AS WRITTEN.** It read *"Two fresh exports and the
> committed file are byte-identical"* at hash `4dc316dc…`, which now matches none of
> the three. Two fresh exports still agree with each other to the byte — determinism
> holds — but the **committed file has drifted from the engine**, and the drift is a
> wrong number on screen, not a formatting difference. Six values differ, all on
> `SP-9001`:
>
> | Path | committed (on screen now) | engine today |
> |---|---:|---:|
> | `summary/gst` | 90000 | **90909** |
> | `summary/grossSales` | 910000 | **909091** |
> | `payout/orderSplit/gst` | 90000 | **90909** |
> | `payout/orderSplit/product` | 890000 | **889091** |
> | `je/lines/6/cr` | 890000 | **889091** |
> | `je/lines/8/cr` | 85455 | **86364** |
>
> The engine is the correct one. `vert_engine/fixtures.py:242-250` records why: a
> GST-inclusive charge gross of 1,000,000 carries 90,909 of GST under s.9-70/9-75, and
> the old header value of 90,000 *"understated the GST liability on the payout the demo
> calls clean"*. The fixture was fixed; `lib/engine-output.json` was never regenerated.
> A `git diff` on that file shows only a two-line insertion adding `"live": false`,
> so it was hand-edited rather than re-exported.
>
> **Nothing catches this.** All 178 demo tests read `lib/engine-output.json` as ground
> truth (`tests/engine-output.test.js:27`, `no-arithmetic.test.js:36`,
> `engine-source.test.js:53`); not one compares it against a fresh export. The seam
> the whole demo rests on has no freshness check. Fixing the file is one command;
> the missing check is the real gap.

### 2.6 The demo has a real test suite — 178 tests

**This was §4.3 "Not built" in the previous revision. It is now built.**

> **Re-measured 2026-08-06.** This heading and the pasted output read **133** until
> that date. Four test files have arrived since: `claims.test.js`,
> `provenance.test.js`, `static-mode.test.js`, `writes.test.js`. The per-file table
> that used to sit here has been removed rather than guessed at — several files do not
> report a count when run individually, so `npm test` is the only figure measured.

```
cd /Users/vanshm/Documents/Vert/Accounting/vert-demo && npm test
```

```
ℹ tests 178
ℹ suites 0
ℹ pass 178
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1008.635709
```

**None of the 178 checks that `lib/engine-output.json` is current.** Every one of them
reads it as ground truth. See §2.5 — it is not current.

The suite is worth more than its count, for three reasons:

1. **It has its own mutation sweep.** `verifier.mutation.test.js` breaks the demo six
   ways and requires the verifier to refuse each one — the same discipline as §2.2,
   applied to the JS side:

   ```
   ✔ DETECTED — fee_leg_on_the_wrong_side
   ✔ DETECTED — agent_understates_its_own_total
   ✔ DETECTED — a_transaction_row_vanishes
   ✔ DETECTED — a_transaction_amount_is_edited
   ✔ DETECTED — a_duplicate_deposit_appears
   ✔ DETECTED — the_deposit_never_landed
   ✔ the sweep as a whole: every clean payout is refused under every applicable mutation
   ```

2. **It records its own blind spots as tests**, rather than omitting them:

   ```
   ✔ BLIND SPOT — GST folded into Product Revenue is NOT detected
   ✔ BLIND SPOT — swapping two revenue accounts' amounts is NOT detected
   ```

   Those two assert that the verifier *fails* to catch a real defect class. They will
   break loudly if someone believes the verifier is stronger than it is. This is the
   most valuable thing in the JS suite.

3. **It has controls**, so the mutation results are not just sensitivity to noise:

   ```
   ✔ CONTROL — rewriting the memo does not move the verdict
   ✔ CONTROL — reordering the entry's lines does not move the verdict
   ✔ CONTROL — reordering the bank feed does not move the verdict
   ✔ CONTROL — a bank line far outside the four-day window is not mistaken for the deposit
   ```

The three-gate SP-BROKEN guarantee (§2.9) now has regression tests in
`gates.test.js`. The previous revision's warning — *"a refactor could silently defeat
it"* — no longer applies.

### 2.7 Demo builds clean, 10 routes, all serving 200

```
cd /Users/vanshm/Documents/Vert/Accounting/vert-demo && npm run build
```

```
▲ Next.js 16.2.12 (Turbopack)
  Creating an optimized production build ...
✓ Compiled successfully in 1665ms
  Running TypeScript ...
  Finished TypeScript in 55ms ...
✓ Generating static pages using 7 workers (13/13) in 206ms

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /chat
├ ○ /checklist
├ ○ /command
├ ○ /icon.svg
├ ○ /insights
├ ○ /reconciliation
├ ○ /reconciliation/approvals
├ ○ /reconciliation/exceptions
├ ƒ /reconciliation/payments
└ ○ /settings

ƒ Proxy (Middleware)
```

Served on port 3111 and curled. Both the followed (`-L`) and raw status are shown, so
the redirect is visible rather than hidden behind a flag:

```
200 (raw 307)  /
200 (raw 200)  /chat
200 (raw 200)  /checklist
200 (raw 200)  /command
200 (raw 200)  /insights
200 (raw 200)  /reconciliation
200 (raw 200)  /reconciliation/approvals
200 (raw 200)  /reconciliation/exceptions
200 (raw 200)  /reconciliation/payments
200 (raw 200)  /settings
```

`/` is a **307 redirect to `/reconciliation`** by design. Four of the ten are
placeholders — see §4.1. A 200 from `/chat` means a file was served, nothing more.

### 2.8 The API — 10 routes exercised against a real SQLite store

**This did not exist in the previous revision.** `vert_api` is a FastAPI application
over the `Store` interface; **271** of the suite's tests were its own when last counted
(`pytest vert_api -q` → `271 passed`, re-measured 2026-08-06; this read *244 of the
1774* until then).

Started with a seeded SQLite database, no network, frozen clock:

```
.venv/bin/python -m vert_api.dev_server --db /tmp/vert-dev.db --port 8077
```

```
seeded /tmp/vert-dev.db — 26 payouts, agent and critic replayed from
vert_engine.demo_transcript (no provider called)
```

**Every route in the OpenAPI document was exercised.** Responses are real, pasted
verbatim, truncated only where marked.

| Route | Result |
|---|---|
| `GET /health` | 200 |
| `GET /ready` | 200, 6+ named checks all `ok` |
| `GET /payouts` | 200, 26 payouts |
| `GET /payouts/{id}` | 200 (SP-BROKEN detail below) |
| `POST /payouts/{id}/reconcile` | 200, idempotent |
| `GET /approvals` | 200 |
| `POST /approvals/{id}/approve` | 200 clean / **409 blocked** |
| `POST /approvals/{id}/reject` | 200 |
| `GET /exceptions` | 200, grouped |
| `GET /bank-lines` | 200 |


> **Count updated 2026-08-23: the fixture corpus is now 27 payouts** (14 Shopify Payments, 13 Stripe), measured with `len(tools.Repository.from_fixtures().payouts())`. The transcripts above are verbatim records of runs made when it was 26 and are left as they were run — a transcript edited to match today's numbers is no longer a transcript. What was stale was the count being quoted as a current fact elsewhere.

**Health and readiness.** *(Shape changed 2026-08-23: `/ready` no longer requires a credential — it answered 401 on every authenticated deployment — and every check now also carries `measured` / `not_measured_reason`, with an `unmeasured` list at the top level. The transcript below is the run as it was made.)*

The point stands: `/ready` does not merely answer — each check says what it
proves, which is the difference between a probe and a green light:

```json
{"ready":true,"service":"vert-api","version":"1.0.0","checks":[
 {"name":"database_reachable","ok":true,"proves":"A connection was obtained and the payouts relation answered a read."},
 {"name":"schema_journal_entries","ok":true,"proves":"journal_entries answers a read — drafts can be staged and listed."},
 {"name":"schema_proposals","ok":true,"proves":"proposals answers a read — agent output can be queued and listed."},
 {"name":"schema_approvals","ok":true,"proves":"approvals answers a read — human decisions can be recorded and listed."},
 {"name":"schema_audit_log","ok":true,"proves":"audit_log answers a read — the hash-chained trail is present."},
 {"name":"payout_state_vocabulary","ok":true, ...}]}
```

**Reconcile is idempotent.** Re-running against an already-reconciled payout changes
nothing and says so — `changed:false`, `entryAlreadyExisted:true`, and critically
`modelConsulted:false`:

```json
{"run":{"payoutId":"SP-9003","outcome":"resolved","state":"awaiting_approval",
 "entryExternalId":"je:3e642fe025ff","entryAlreadyExisted":true,
 "proposalIds":[],"criticNotesQueued":0,"agentAttempts":0,
 "modelConsulted":false,"steps":[],"changed":false}}
```

**A write with no named human is refused before anything else is checked** (HTTP 400).
This fires *before* the blocked check, which is the correct order — the system will
not evaluate a request it could not attribute:

```json
{"error":{"code":"actor_required","message":"This request writes to the close and no
actor was named. Send the X-Vert-Actor header identifying the person acting.
Authentication establishes the tenant, not the human — and recording nobody as having
approved a journal entry is not an option.","detail":{"header":"X-Vert-Actor"}}}
```

**A clean approval succeeds** and records the actor and a monotonic approval id:

```json
{"approval":{"approvalId":1,"decision":"approve","actor":"vansh","note":"reviewed",
 "decidedAt":"2026-07-01T00:00:00+00:00"},
 "payoutId":"SP-9003","state":{"status":"approved",
 "statusReason":"Approved by vansh (approval 1).","revision":3, ...}}
```

**A rejection discards the draft** rather than orphaning it — note the entry moves to
`discarded` with a reason naming the approval that caused it:

```json
{"approval":{"approvalId":2,"decision":"reject","actor":"vansh",
 "note":"fee coding looks wrong"},"payoutId":"po_2Bd",
 "state":{"status":"rejected","statusReason":"Rejected by vansh (approval 2).",
 "entries":[{"externalId":"je:c8170d372a37","status":"discarded",
 "statusReason":"Payout rejected by vansh (approval 2)."}]}}
```

**Illegal transitions are refused and enumerate what would have been accepted** —
re-approving an approved payout (HTTP 409):

```json
{"error":{"code":"illegal_transition","message":"payout 'SP-9003' cannot move
'approved' → 'approved'. Legal from 'approved': ['blocked', 'posted'].",
"detail":{"subject":"payout","subjectId":"SP-9003","from":"approved","to":"approved",
"legal":["blocked","posted"]}}}
```

**Unknown ids 404 with a next action, not a bare code:**

```json
{"error":{"code":"not_found","message":"Payout 'NOPE' is not in the close register.
Nothing has been ingested or reconciled for it yet — POST /payouts/NOPE/reconcile to
bring it in.","detail":{"payoutId":"NOPE"}}}
```

**Bad enum values are refused and name the accepted set** (HTTP 400) —
`GET /payouts?state=bogus`:

```json
{"error":{"code":"invalid_request","detail":{"errors":[{"loc":["query","state"],
"msg":"Input should be 'ingested', 'reconciled', 'blocked', 'awaiting_approval',
'approved', 'posted' or 'rejected'","type":"enum"}]}}}
```

`GET /exceptions?severity=bogus` behaves identically
(`Input should be 'needs_action' or 'review'`). Filters work:
`GET /payouts?state=blocked` → `['SP-BROKEN', 'po_8Hm']`;
`GET /payouts?limit=2` → `['SP-9003', 'po_2Bd']`.

**The API fails closed on authentication.** `create_app()` with neither an
authenticator nor an explicit opt-in refuses to construct at all:

```
UnauthenticatedDeployment:
create_app() needs either an `authenticator` or an explicit `allow_unauthenticated=True`.

  Production:  create_app(authenticator=Authenticator(...), ...)
  Local dev:   create_app(allow_unauthenticated=True, default_tenant=...)

Refusing to start an API that stages and approves journal entries with no way to tell
callers apart. There is no default for this on purpose: a safe default here would be
one someone could inherit without deciding.
```

`dev_server` passes `allow_unauthenticated=True` explicitly and `/health` reports
`"authenticated":false`, so the weakened mode is visible from outside the process,
not merely inside it.

**The audit chain survived every write.** After the approve and the reject above, the
hash chain verifies for each touched payout (`verify_audit_trail` raises
`AuditChainBroken` on failure and returns None on success):

```
SP-9003   -> verify_audit_trail: None  records: 7
po_2Bd    -> verify_audit_trail: None  records: 8
SP-BROKEN -> verify_audit_trail: None  records: 6
po_8Hm    -> verify_audit_trail: None  records: 6
```

137 audit rows total, single tenant `northwind`, and the actor is carried through the
transition — not just the approval row:

```
SP-9003 | payout.ingested        | engine      | None            -> ingested
SP-9003 | payout.transitioned    | engine      | ingested        -> reconciled
SP-9003 | journal_entry.staged   | engine      | None            -> draft
SP-9003 | journal_entry.transitioned | engine  | draft           -> staged
SP-9003 | payout.transitioned    | engine      | reconciled      -> awaiting_approval
SP-9003 | approval.approve       | vansh       | None            -> approve
SP-9003 | payout.transitioned    | user:vansh  | awaiting_approval -> approved
```

### 2.9 SP-BROKEN is blocked on all three surfaces

SP-BROKEN is the adversarial fixture: a $5,000.00 payout whose transaction detail sums
to $4,850.00. It is $150.00 short and the engine must never smooth the hole.

**Surface 1 — the engine:**

```
.venv/bin/python -c "
from vert_engine import tools
r = tools.reconcile_payout('SP-BROKEN')
print('integrity_ok:', r.decomposition.integrity_ok)
print('delta_minor :', r.decomposition.delta_minor)
print('exceptions  :', [(e.kind, e.severity) for e in r.exceptions])
print('je.balanced :', r.je.balanced)"
```

```
integrity_ok: False
delta_minor : -15000
exceptions  : [('payout_integrity_break', <ExceptionSeverity.needs_action: 'needs_action'>)]
je.balanced : True
```

`balanced: True` alongside `integrity_ok: False` is the intended design, not a
contradiction: the $150.00 hole is parked on **Payout Suspense** so the entry is still
well-formed double-entry, while the integrity break is raised separately. A balanced
entry is not a correct one, and the engine reports both facts rather than letting the
balance imply correctness. The API detail makes the parking visible —
`"Payout Suspense" cr 15000` against `sumDr 515000 / sumCr 515000 / balanced true`,
with `"delta":-15000,"integrityOk":false`.

**Surface 2 — the demo.** SP-BROKEN fails 3 of the verifier's 6 checks, and this is
now asserted by `gates.test.js` rather than only by curl:

```
✔ SP-BROKEN is blocked, short by exactly $150.00
✔ SP-BROKEN fails exactly three checks, each by its recorded delta
✔ SP-BROKEN's agent_claim_matches_replay PASSES — the agent reported the break honestly
✔ SP-BROKEN's entry still BALANCES — balanced is not the same as correct
✔ every payout other than SP-BROKEN passes all six checks
✔ SP-BROKEN is the ONLY blocked payout in the corpus
```

Confirmed against the served HTML as well:

```
blocked:true  -> 1
blocked:false -> 25
```

`agent_claim_matches_replay` passing is the interesting one. The agent reported the
break honestly, so the verifier is not catching a liar — it is catching an
**unpostable entry**. Those are different failures and the check set distinguishes them.

**The three gates**, each independent, so a UI bug in one cannot defeat the others:

1. `components/reconcile/ReconcileScreen.js` — bulk select skips blocked ids.
2. `components/approvals/ApprovalDetail.js` — `handleApprove()` returns early on
   `verdict.blocked`. It does not depend on Reconcile having run.
3. `lib/store.js` `RECORD_APPROVAL` — a silent no-op once the payout is marked blocked.

Gate 3 is the one that matters, because it is the only one that holds if gates 1 and 2
are both wrong. **All three now have tests** (§2.6).

**Surface 3 — the API.** `POST /approvals/SP-BROKEN/approve` with a valid actor is
refused with **HTTP 409**, and the error says how the block clears:

```json
{"error":{"code":"payout_blocked","message":"Payout 'SP-BROKEN' cannot be approved:
1 deterministic tie-out(s) are failing (payout_integrity_break). A block clears by
fixing the underlying records and re-running POST /payouts/SP-BROKEN/reconcile until
the engine raises nothing — never by approving through it.",
"detail":{"payoutId":"SP-BROKEN","state":"blocked","failingChecks":[
 {"type":"payout_integrity_break","severity":"needs_action",
  "detail":"Parts don't sum to the payout (off by $150.00 AUD)."}]}}}
```

**A discrepancy worth stating rather than smoothing.** The API blocks **two** payouts;
the demo blocks **one**. This is not a bug, but the two surfaces do not mean the same
thing by "blocked":

- The **demo's** `blocked` is the verifier's verdict — *is this entry postable?* Only
  SP-BROKEN fails that.
- The **API's** `blocked` is a payout *state* — *did any deterministic tie-out
  escalate?* Two payouts did: SP-BROKEN (`payout_integrity_break`) and po_8Hm
  (`unclassified_txn`, $315.00 sitting in suspense).

The API is the stricter of the two, and `po_8Hm` is refused with the same 409. Being
stricter server-side is the right direction for a gate. But **the demo would let a
human click approve on po_8Hm and the API would refuse it** — the surfaces disagree,
and anyone demoing should not claim they are the same gate.

### 2.10 The demo runs end to end against the live API

The demo has an API mode (`NEXT_PUBLIC_VERT_API_URL`). This is the closest thing to a
full-stack run that exists without external credentials, and it works:

```
cd /Users/vanshm/Documents/Vert/Accounting/vert-demo
NEXT_PUBLIC_VERT_API_URL=http://127.0.0.1:8077 npm run build   # exit 0
NEXT_PUBLIC_VERT_API_URL=http://127.0.0.1:8077 npm run start -- -p 3112
```

All ten routes serve 200 with the data assembled from the running FastAPI service, and
SP-BROKEN is still the only blocked verdict:

```
200 /   200 /chat   200 /checklist   200 /command   200 /insights
200 /reconciliation   200 /reconciliation/approvals
200 /reconciliation/exceptions   200 /reconciliation/payments   200 /settings

blocked:true  -> 1
blocked:false -> 25
```

**And it fails loudly rather than silently falling back.** With
`NEXT_PUBLIC_VERT_API_URL` set but the API stopped, the build **exits 1**:

```
build exit=1
NEXT_PUBLIC_VERT_API_URL is set, so this demo will not render from
lib/engine-output.json instead — stale figures under a live-looking header ...
```

That refusal is the property worth having. A demo that quietly served last week's
numbers when its backend was down would be the single most dangerous defect in the
product, and it is tested (`engine-source.test.js`, 22 tests).

**Scope of this claim, stated precisely:** the chain proved here is
`Next.js → FastAPI → SQLiteStore → deterministic engine`. It is **not** a live
end-to-end run — the payout data originates from fixtures and the model layer is
scripted (see §4.2, §4.4). Note also that API mode populates the static routes at
**build** time, so a running demo does not re-read the API per request; stopping the
API after a successful build leaves the already-prerendered pages serving.

*This run's artefacts were cleaned up: the demo was rebuilt in its default static mode
and `lib/engine-output.json` re-verified at the hash in §2.5.*

### 2.11 Dependency surface stays minimal

```
.venv/bin/python -c "import tomllib; d=tomllib.load(open('pyproject.toml','rb')); ..."
```

```
runtime dependencies: ['pydantic>=2.0']

  extra dev:       ['pytest>=8.0', 'pglast>=8.0', 'httpx>=0.27', 'PyYAML>=6.0']
  extra api:       ['fastapi>=0.115', 'uvicorn[standard]>=0.30']
  extra litellm:   ['litellm>=1.63.0']
  extra aws:       ['boto3>=1.34']
  extra gcp:       ['google-cloud-secret-manager>=2.20', 'google-crc32c>=1.5']
  extra postgres:  ['psycopg[binary]>=3.1']
  extra otel:      ['opentelemetry-api>=1.30', 'opentelemetry-sdk>=1.30']
  extra otel-otlp: [... , 'opentelemetry-exporter-otlp-proto-grpc>=1.30']
```

**The base runtime dependency is still `pydantic` alone.** Everything that touches the
outside world — the HTTP server, the model gateway, both cloud secret backends, the
Postgres driver, the telemetry exporter — is an opt-in extra. A deployment that only
runs the engine carries none of their import graphs. That is a supply-chain decision,
restated at every addition since the last revision and still holding.

`psycopg` **is** installed in this venv — **3.3.4**, verified 2026-08-06. This line
read *"`psycopg` is **not installed** … nothing here has spoken to Postgres"* until
that date; the `[postgres]` extra was installed so §3.1 could be executed, and the
statement is now false in both halves. The dependency claim above is unaffected —
`psycopg` is still an extra, not a base dependency.

One correction to the previous revision's grep-based claim, recorded in §6.3: the
engine now contains exactly one `urllib` import —
`vert_engine/state/migrations.py:97: from urllib.parse import urlsplit` — used solely
to redact credentials out of a DSN before it reaches a log. It is string parsing, not
networking. A direct search for wire calls in `vert_engine/` and `vert_agent/` returns
nothing but the test that asserts their absence:

```
grep -rnE "(requests|httpx)\.(get|post|put|request)|urlopen|socket\.socket|http\.client" \
     --include="*.py" vert_engine/ vert_agent/
# → vert_agent/tests/test_agent.py:326 only (the assertion itself)
```

---

## 3. Built but UNVERIFIABLE without external access

Everything here is written and reviewed. **None of it has met the real thing.** Each
item names the exact access required and what specifically remains unproven.

### 3.1 ~~PostgreSQL~~ — RUN AGAINST A SERVER (Docker AM, **managed Neon PM**), 2026-08-06

**This section used to open: *"the largest unverified surface in the project"*, and
said `pg_store.py`, `schema.sql`, the RLS policies and the migration runner had never
been executed.** That is no longer true of the first three. Docker was started,
PostgreSQL 16.14 was run in a throwaway container, and the store was exercised against
it. What follows is only what was executed and observed.

> **ADDED 2026-08-06 (evening): the schema now also lives on a real managed instance,
> and connecting to it surfaced the single highest-consequence finding in this
> document.**
>
> The morning pass listed *"which role production connects as"* as the highest-consequence
> unknown here. It is no longer unknown, and the answer was the bad one.
>
> **A Neon connection string hands you `neondb_owner`, and that role has `BYPASSRLS`.**
> Connected as it, all ten policies are inert — a session reads, updates and deletes
> every tenant's rows and **nothing reports a problem**. The application behaves
> correctly; the isolation is simply absent. `schema.sql` already answered the
> table-owner case with `FORCE ROW LEVEL SECURITY`, but FORCE binds the owner and does
> not touch `BYPASSRLS`, which is a role attribute and outranks it. The documented
> mitigation did not cover the most likely real deployment.
>
> The fix is a runtime refusal, not a comment: `PostgresStore.assert_rls_is_enforceable()`
> (`pg_store.py:216`) reads `rolsuper` / `rolbypassrls` for `current_user` and refuses
> to serve tenant data as either. **Call it; do not route around it.**
>
> Verified against the live Neon database this pass, connected as `vert_app`:
>
> ```
> role attributes: {'current_user': 'vert_app', 'rolsuper': False, 'rolbypassrls': False}
> policies present: 10
>   api_keys / approvals / audit_log / journal_entries / journal_entry_lines
>   / payouts / proposals / tenants   → relrowsecurity=True, relforcerowsecurity=True
> ```
>
> So the schema is deployed, RLS is enabled **and forced** on all eight tables, and the
> application role is correctly attributed. That is the good half.
>
> **The bad half — the deployed policy set does not match `schema.sql`.** See §6c.3.
> One table, `payouts`, carries a `USING` clause that no committed DDL produces.

**Everything below skips when no server is reachable** — `pg_backend.py` probes once
and every Postgres case reports a skip naming the docker command. It never fails for
want of a server, and it never silently passes. A green suite on a machine without
Postgres proves exactly what it always proved.

**The role is the experiment.** The store connects as `vert_app`: not a superuser, not
`BYPASSRLS`, and not the table owner. All three bypass every policy, and a suite run
as any of them is green because nothing is filtering. `test_rls_live.py` asserts the
probe role is none of the three before it asserts anything else.

**What is NOW verified by execution:**

| Tests | What was actually executed |
|---:|---|
| 152 `test_store.py` | The contract suite, **parameterised over both backends** — all 76 cases on SQLite and again on real Postgres. Previously SQLite only. |
| 32 `test_rls_live.py` | Two tenants' rows in one database; one session cannot read, update or delete the other's, across all eight tenant tables. `vert_current_tenant()` raises — rather than returning zero rows — when no tenant is declared. Each isolation case is paired with a **mutation proof**: widen the tenant predicate to `true` and the same statement succeeds, which is what separates "the policy stopped it" from "there was nothing there". A seed-non-vacuity check guards the sweep, because "A sees no row of B's" passes trivially on an empty table. |
| 20 `test_pg_pooling.py` | Every read path leaves the connection `idle`, not `idle in transaction`, and carries no residual `vert.tenant_id`. See the defect list below. |
| 5 `test_pg_live.py` | The append-only triggers raise on TRUNCATE (row triggers do not fire for it); `vert_app` holds no TRUNCATE either; `SELECT … FOR UPDATE` serialises two workers racing one payout while leaving two workers on different payouts alone — which SQLite's whole-database lock cannot demonstrate. |
| 17 `test_pg_tenant_session.py` | Unchanged in purpose, and still the check that needs no server. Split one case in two: the DDL must run **outside** a tenant scope, and the tenant-row INSERT must run **inside** one. |
| 79 `test_rls.py`, 6 `test_postgres_ddl.py`, 25 `test_schema_drift.py`, 48 `test_migrations.py` | Unchanged. These are the coverage that **cannot skip**, which is why they still earn their place now that a live suite exists alongside them. |

**`schema.sql` was accepted first try.** Applied to an empty database with
`ON_ERROR_STOP=1`: exit 0, zero errors, and idempotent on a second run. RLS is enabled
**and forced** on all eight tables, with all ten policies present. The dialect
divergence that seemed likely — the DDL had only ever been applied to SQLite — did not
materialise.

**Four defects were found, all invisible to SQLite and to the mock suite, all fixed
and regression-tested:**

1. **`initialise` never provisioned the tenant row.** Every ledger table has a foreign
   key into `tenants`, so the first `upsert_payout` died on a bare
   `ForeignKeyViolation`. `SQLiteStore.initialise` had always done it; the two had
   diverged silently.
2. **Constraint violations escaped as raw `psycopg` errors instead of `StateError`.**
   The Store contract is `StateError` and `vert_api.errors` maps it to a typed
   refusal, sending everything else to the last-resort handler. So re-ingesting a
   processor payout under a second engine id answered an **opaque 500** on the
   production backend and a typed refusal on the tested one. Three paths affected.
3. **`resolve_proposal` dropped the sentence naming the rule** it was enforcing —
   `vert_api` passes these messages straight to the client.
4. **Every read left the connection `idle in transaction`.** This is the serious one.
   `schema.sql` argues a pooled connection cannot leak a tenant because the setting is
   transaction-local — *"discarded at COMMIT and cannot be inherited by whoever
   borrows the connection next"*. That premise requires the transaction to end, and
   the read paths never committed. Measured: after a `get_payout` the setting was
   still live on the connection and an unscoped `SELECT` on it **returned the previous
   tenant's rows instead of raising**. The one-character `true` is necessary and not
   sufficient. It also held locks indefinitely — a `TRUNCATE` in the new suite blocked
   forever behind a plain read, which is how it was found.

**What remains UNVERIFIED:**

- **Behind a connection pooler.** Whether `set_config(…, true)` behaves as required
  under PgBouncer in transaction mode is a property of the pooler, not of this SQL,
  and no pooler was involved. Defect 4 is precisely the class of bug that lives here.
- **The migration runner** (`migrations.py`) — still never executed against a server.
  `pg_try_advisory_lock` is still assumed, and whether a rollback actually reverses
  DDL is still unknown. Only `pg_store.py` and `schema.sql` were exercised.
- ~~**Which role a deployment connects as.**~~ **ANSWERED 2026-08-06 (evening), and the
  answer was the dangerous one — see the Neon note at the top of this section.** The
  managed default role has `BYPASSRLS`; a runtime guard now refuses to boot as it. What
  remains is narrower: nothing *enforces* that a deployment calls
  `assert_rls_is_enforceable()` before serving, and **no test reads the policies that
  are actually deployed** (`grep -rn pg_policies --include=*.py` over the whole repo
  returns nothing). §6c.3 is what that blind spot let through.
- **That the deployed schema equals the committed schema.** Newly demonstrated false on
  one table this pass (§6c.3). There is no drift check between `schema.sql` and a live
  database — `test_schema_drift.py` compares the vocabulary across three *source*
  files, which is a different property entirely.
- Load, scale, backup and restore, failover, and any Postgres version other than 16.14
  (the Neon instance was not version-pinned or load-tested here — only its role
  attributes, policy set and RLS flags were read).

**To re-run it:**

```bash
docker run -d --rm -e POSTGRES_PASSWORD=vert -p 55432:5432 --name vert-pg postgres:16
pip install -e '.[postgres]'
pytest vert_engine/state/tests            # Postgres cases skip if the container is absent
docker stop vert-pg
```

### 3.2 ~~Live model transport~~ — RUN AGAINST A REAL PROVIDER, 2026-08-05, re-verified 2026-08-06

> **This section's premise is obsolete and is struck rather than deleted.**
> ~~*"**Access required:** a provider API key (Anthropic or OpenAI) and `pip install
> litellm`. **Neither is present; there is no network in tests.**"*~~
>
> A key was supplied and the path has now run end to end against OpenAI —
> `gpt-4.1-mini` proposing, `gpt-4o-mini` critiquing. `AGENT-LIVE.md` §10 is the
> primary record. **Re-verified independently in this pass**, and the result is the
> strongest evidence in this document for the product's central claim — see §6c.2:
> the live export writes `live:true` and the real model's own reasoning text, and
> **every number in the file is byte-identical to the deterministic run.**
>
> Two things §3.2 warned could not be surfaced by a fake *were* surfaced by the real
> thing, exactly as predicted: a capability-table row for a model that does not exist,
> and a critic that had never sent its JSON schema. Both are fixed.
>
> The paragraph below still describes the **test suite**, which is unchanged and still
> runs against a fake with no network. That remains true and is why it is kept.

**Test-suite scope (unchanged):** the 36 transport tests install a fake `litellm`
module into `sys.modules`. No key, no network, no clock.

36 tests pass by installing a **fake `litellm` module** into `sys.modules`. They verify
the adapter's own logic: that it refuses LiteLLM's routing/fallbacks/retries/cache,
that `__slots__` prevents stashing a credential, that a missing `key_ref` is a loud
error rather than a silent fall-through to an ambient environment key, that cache
counters are normalised across OpenAI's and Anthropic's two different shapes, and that
the module body imports cleanly with no litellm installed.

**Specifically unproven — revised 2026-08-06.** These read as one undifferentiated
list before a provider had ever answered. Now they split:

- ~~that any real provider accepts the emitted call shape~~ — **proven for OpenAI**
  (`gpt-4.1-mini`, `gpt-4o-mini`). **Still unproven for Anthropic**, which is the
  provider this repo was designed around and the one every capability-table row was
  originally written from memory for.
- ~~that a real `SecretResolver` works end to end~~ — **proven for `env://` only**, and
  `env://` is the development scheme that needs two opt-ins and is refused in
  production. The two cloud resolvers remain unrun (§3.5), so the resolver path that
  would actually ship is still untested.
- **Structured-output enforcement across providers** — still unproven in the direction
  that matters. The failure the module warns about (an unsupported keyword being a 400
  on one provider and a **silent no-op** on another) is precisely what the critic bug
  turned out to be, and it was caught by inspection, not by a test.
- **Cost** — no longer pure arithmetic but not yet a bill: roughly a tenth of a cent per
  payout on `gpt-4.1-mini`, from token counts on real responses. No invoice observed.

### 3.3 Xero draft posting — `vert_engine/posting/xero.py` — **SUPERSEDED, NOT DELETED**

> **Team decision, 2026-08-06: Xero is out of the V1 critical path. QuickBooks is
> first, then NetSuite/Sage. The ICP moves upmarket.**
>
> **Superseded is not deleted.** `vert_engine/posting/xero.py` still exists, its 43
> tests still run, and nothing about it has been found wrong. It is not on the path to
> the first customer any more. If the ICP moves back down-market it is still here.
>
> **Why QuickBooks first, recorded because this is the real fork and it is an
> architectural one, not a sales preference.** Verified against the code this pass:
>
> - `Poster` (`vert_engine/posting/base.py:21`) is a **one-method contract** —
>   `post_draft_je(je: JEDraft) -> PostResult`. A ledger that accepts a flat list of
>   debits and credits against a flat chart of accounts fits that seam with no change
>   to the engine at all.
> - `JournalLine` (`vert_engine/models.py:230`) is exactly four fields:
>   ```python
>   class JournalLine(BaseModel):
>       account: str
>       dr_minor: Cents = 0
>       cr_minor: Cents = 0
>       tax_ref: Optional[str] = None
>   ```
> - **QuickBooks has a flat chart of accounts. It fits that shape today.**
> - **NetSuite and Sage do not.** Their journal lines are *dimensional* —
>   subsidiary, department, class, location — and a line without the required
>   dimensions is rejected by the ledger, not merely posted untagged. `JournalLine`
>   **cannot express a dimension**, so those two are not an adapter exercise: they
>   require widening the core journal model, which changes `build_je`, `validate_je`,
>   the balance proof, every fixture and the benchmark's authored ground truth.
>
> So the ordering is not "QuickBooks is easier". It is that QuickBooks is reachable
> **behind the existing seam** and NetSuite/Sage are reachable only **through the
> journal model**. Doing the cheap one first buys a real second ledger before paying
> for dimensional lines, and it keeps the dimensional work as one deliberate change
> rather than something smuggled in beside an integration.
>
> **Status of the QuickBooks poster: being written right now, in another session.**
> `vert_engine/posting/quickbooks.py` and `vert_connect/quickbooks_http.py` both exist
> as of this pass. They were **not** reviewed here and are **not** claimed to work —
> the only thing this document knows about them is that they currently break the
> `vert_connect` boundary test (§6c.1). Nothing about QuickBooks may be called verified
> until that agent reports and someone measures it.

**Access required (Xero, if resumed):** a Xero developer app, OAuth2 client
credentials, and a connected tenant with a chart of accounts.

43 tests cover the mapping against an injected fake `XeroHttpClient`: engine account
*names* → Xero *codes*, raising on an unmapped account rather than guessing, and
content-derived idempotency tagging stamped into the Narration so a repeat post returns
the existing journal instead of duplicating.

**Specifically unproven:** that the ManualJournal payload is accepted by the live API;
OAuth2 token refresh; tenant selection; rate-limit behaviour; and whether the
idempotency tag survives a real Xero round trip (the highest-value unknown — the whole
duplicate-protection story rests on it).

Unchanged and not a gap: **DRAFT is the only status emitted.** Xero's `IsReconciled` is
read-only and the vendor formally declined programmatic bank reconciliation, so no code
path attempts it. `XeroPoster` (the default) holds no HTTP client and therefore cannot
post at all.

### 3.4 ~~Stripe and Shopify ingestion~~ — BOTH HAVE NOW ANSWERED LIVE, 2026-08-06

> **This section's heading premise — that neither had met the real thing — is struck.**
> Both were probed against live systems in this pass, through `vert_connect` (stdlib
> `urllib` only, verified: the two clients import nothing outside `json`, `time`,
> `urllib.*` and `typing`, plus one engine error type).
>
> **Stripe — real API answered.** The pinned API version took effect
> (`last_version: 2026-07-29.dahlia`), which is the check that matters most, because a
> silently-unpinned version means the mappers are parsing an unknown shape.
>
> **The chargeback finding reproduces exactly.** A census of the live account's 100
> most recent balance transactions:
>
> ```
> Counter({('charge', 'charge'): 12, ('refund', 'refund'): 2, ('adjustment', 'dispute'): 1})
> ```
>
> A chargeback does **not** arrive as `type=dispute`. It arrives as
> `type=adjustment` with `reporting_category=dispute`, and `types.py` maps
> `adjustment` to the recognised-but-unattributed bucket — so a real dispute was
> landing in Payout Suspense with its own accounting treatment unrecorded. Run against
> the live node, the fix fires:
>
> ```
> raw type      : adjustment
> reporting_cat : dispute
> type map ->   : adjustment   <-- suspense before the fix
> refined ->    : dispute
> ```
>
> The refinement (`refine_category`, `stripe.py:409`) is narrow by construction: it is
> consulted **only** for lines already bound for suspense and never overrides a
> category the type map recognised, on the stated grounds that a richer signal
> disagreeing with a known type is a reason to investigate rather than to silently
> prefer one. That restraint is the right shape and worth preserving.
>
> **Caveat on the Stripe probe, stated because it limits the claim:** the test account
> holds **zero payouts**. `GET /v1/payouts` returned an empty list. So pagination at
> volume, `expand[]=data.source`, and payout-scoped balance-transaction fetching are
> *still* unproven against real data — what was proven is auth, version pinning,
> response shape for balance transactions, and the dispute refinement.
>
> **Shopify — real store answered** (`vert-6lwwrulp.myshopify.com`, GraphQL, no PCD
> data requested). **A claim circulating in the handoff notes is wrong and is corrected
> here.** The claim was *"REST `total_tax` reads 0.00 where GraphQL and the line-level
> `taxLines` read correctly."* GraphQL has **two** total-tax fields and they disagree:
>
> ```
> #1001 totalTaxSet= 0.0 | currentTotalTaxSet= 11.0  | sum(taxLines)= 11.0
> #1002 totalTaxSet= 0.0 | currentTotalTaxSet= 3.17  | sum(taxLines)= 3.17
> #1003 totalTaxSet= 0.0 | currentTotalTaxSet= 0.0   | sum(taxLines)= 12.27
> #1004 totalTaxSet= 0.0 | currentTotalTaxSet= 24.27 | sum(taxLines)= 24.27
> ```
>
> `totalTaxSet` reads **0.00 on every order in the store** — it is not a REST-only
> problem. **The adapter does not read it.** `shopify.py:162` reads
> `currentTotalTaxSet`, which is correct on every row above.
>
> **This matters as a warning, not as a defect:** anyone "simplifying"
> `currentTotalTaxSet` to `totalTaxSet` would zero out GST on every Shopify order and
> the arithmetic would still tie, because zero tax is internally consistent. That is
> the silent-error class the whole benchmark exists to catch.
>
> **Order #1003 is not a discrepancy** — checked before reporting it as one. It has one
> refund and `currentTotalPriceSet = 0.0`: the order was fully refunded, so post-refund
> tax of 0.00 is the correct current value and the 12.27 in `taxLines` is the original.
> The adapter reads the right field for the right reason.
>
> **Still unproven for Shopify:** everything behind Protected Customer Data approval,
> which is unchanged and still the longest-lead item in this document. The
> `nodes(ids:)` order lookup — the part that lets a Shopify payout resolve without
> escalating — was **not** exercised, because it is exactly the part PCD gates.

**Stripe — access required:** a Stripe API key (restricted, read-only is sufficient).

56 tests against a recorded client seam cover pagination on `starting_after`, refusal
of float amounts (refused, never coerced), and the tax rule — `tax` stays `None` unless
Stripe Tax actually computed it, because `0` would assert a GST-free supply. GST on
Stripe's own fees is treated as an input tax credit and never read as the sale's tax.
**Unproven:** live response shapes, API version drift, real pagination at volume, rate
limits, and whether `expand[]=data.source` returns what the adapter expects.

**Shopify — access required:** shop credentials **and Protected Customer Data (PCD)
approval, which has not been granted.** This is a process gate, not a technical one,
and it is the **longest-lead item in this document** (see §5 item 1).

65 tests against a recorded GraphQL seam cover cursor pagination on
`pageInfo.endCursor`, the `nodes(ids:)` order lookup that populates the
product/shipping/GST split, the all-or-nothing rule (any missing order discards the
split entirely and escalates the payout), and `MoneyV2` decimal strings parsed through
`Decimal` with a currency-aware minor unit — never float. **Unproven:** anything
against a live shop. The order lookup is the part that lets a Shopify payout resolve
without escalating, and it is precisely the part gated behind PCD approval.

### 3.5 Secret manager backends — `vert_agent/secrets/{aws,gcp}.py`

**Access required:** an AWS account with Secrets Manager and IAM, or a GCP project with
Secret Manager; plus `boto3` / `google-cloud-secret-manager`, neither installed.

28 tests exercise both backends through fake modules in `sys.modules`: ref parsing,
resource-name construction, parameter validation, the JSON-key path, binary and
non-UTF-8 refusal, the CRC32C integrity check, the lazy import, and the fact that no
failure path echoes a credential. 29 further tests (`test_redaction.py`) assert a
secret cannot escape via an attribute, a `repr`, a log record or a traceback — the
requirement is met *structurally* in the local tests.

**Specifically unproven:** the real response shape, the real error surface, IAM
behaviour, whether either client is constructed correctly, and whether rotation works.
Both modules say UNVERIFIED at the top of their docstrings.

### 3.6 Observability — `vert_engine/observability/`

**Access required:** a running OTLP collector and a backend to receive spans.

294 tests (`pytest vert_engine/observability -q` → `294 passed, 1 skipped`, re-measured
2026-08-06; this read 292 until then) run against
the **real** `opentelemetry-api`/`sdk` (1.44.0, installed), so
span naming, semantic conventions, metric definitions, cardinality bounds, the cache
alarm and graceful degradation when otel is absent are genuinely exercised in-process.
`test_collector_config.py` parses the collector YAML.

**Unproven:** that a real collector accepts the config, that spans arrive at a backend,
and that cardinality holds at production volume rather than on fixtures.

### 3.7 Deployment — `Dockerfile`, `docker-compose.yml`, `deploy/`, `proxy.js`

**Access required:** a running Docker daemon (installed, **not running**) and a Vercel
account/token.

Neither the image nor the compose stack has ever been built or started. The demo's edge
auth gate (`proxy.js`) is reviewed and **fails open by design** when `DEMO_USER` /
`DEMO_PASS` are unset — chosen so a missing env var cannot lock you out mid-presentation.
That behaviour is what ran in §2.7. **It is not verified that a 401 is returned when
they are set, nor that Vercel's edge runtime applies the matcher as written.** Before
sharing any public link, set both and confirm a 401.

---

## 4. NOT built

### 4.1 Four demo routes are placeholders

`/command`, `/insights`, `/checklist`, `/chat` are **7-line placeholder files each**.
They return 200 — that is the entirety of what §2.7 claims about them. There is no
functionality behind any of the four.

```
$ wc -l vert-demo/app/{command,insights,checklist,chat}/page.js
       7 vert-demo/app/command/page.js
       7 vert-demo/app/insights/page.js
       7 vert-demo/app/checklist/page.js
       7 vert-demo/app/chat/page.js
      28 total
```

**They are deliberate placeholders and are staying that way.** V1's surfaces are
Reconcile / Approvals / Payments / Exceptions and that list does not grow. Building
into these four is the exact scope drift the decisions register exists to prevent.

### 4.2 The demo agent is theatre — **NOW ONLY PARTLY TRUE. Read all of this.**

> **Revised 2026-08-06.** The old text read: *"**No live model call happens anywhere in
> the demo.**"* ~~That sentence is now false~~ and replacing it with "the demo is live"
> would be equally false in the other direction. The accurate version has three parts
> and demoing honestly requires all three.

**1. The export CAN call a real provider, and this was run.** Setting
`VERT_MODEL_PROVIDER` and friends swaps the scripted transport for a real one and bakes
genuine model output into `engine-output.json`. Verified this pass end to end against
OpenAI: the file came back carrying `"live": true`, `"model": "openai/gpt-4.1-mini"`,
`"criticModel": "openai/gpt-4o-mini"` and reasoning text the model actually wrote.

The seam is **opt-in and never inferred** — an absent variable means scripted, not "try
live and fall back". That refusal is deliberate: a silent fallback is how a run you
believed was live ships recorded text. A live agent with a *scripted critic* is also
refused outright, on the grounds that a review which did not read what it claims to
have reviewed is worse than no review.

**2. The screen states its own provenance.** `ProposalCard` captions from the `live`
flag rather than from a hard-coded string, so a scripted run is labelled *"Recorded
output, replayed from a transcript"* and a live run is not. The caption cannot silently
disagree with what produced the file.

**3. The COMMITTED export is still the deterministic replay, BY DELIBERATE CHOICE —
and the reason is a matter of research integrity, not of engineering.**

`gpt-4.1-mini` produced **1, 0, and 1 proposals across three identical runs.** One run
abstained on both escalated payouts, leaving two empty panels. **Abstention is correct
behaviour** — the guards are supposed to reject a non-answer, and on `po_8Hm` the model
correctly concluded there was no admissible alternative classification. But it makes the
demo non-deterministic.

**Re-rolling until a run looks good would be selecting on the outcome.** The caption
"real model output" would be literally true and still misleading about what is typical.
So the committed file is the deterministic one, honestly captioned. This is the same
discipline as the rest of the document: a demo that shows the good roll is a benchmark
that reports the good seed.

**What to say when demoing, precisely:** *"The numbers are real and computed by the
engine. The narration in the committed file is recorded, and the screen says so. It can
run against a live model with one environment variable — and when it does, the numbers
do not change, because the model is not allowed to produce one."* That last clause is
now measured, not asserted: see §6c.2.

**The open question this leaves is a product one, not a bug.** The cheap model abstains
often. Whether that is the right trade for a propose-only agent, or whether a stronger
model earns its cost, is now *measurable* — which it was not before 2026-08-05.

### 4.3 No live end-to-end run — **STILL TRUE. The ends have moved; the chain has not.**

> **Re-verified 2026-08-06 (evening) by the author of this revision, not relayed.**
> Another agent is working on the posting end as this is written. **This verdict is not
> being marked closed on the strength of work in flight**, and it should not be closed
> by anyone who has not personally watched a payout make the whole trip.

The verdict stands: **no payout has ever travelled processor → engine → ledger against
real systems.** What has changed is that both *ends* have now independently met
something real, while the *chain between them* has still never been joined.

Measured this pass, stated as three separate facts because they are three separate
facts:

| Segment | Status as of my own verification |
|---|---|
| Stripe → engine | **Real, partially.** The live API answered and a real chargeback node was ingested and correctly refined to `dispute` (§3.4). But the account has **zero payouts**, so no real *payout* has been decomposed. |
| Shopify → engine | **Real, partially.** The live store answered and the tax field the adapter reads is correct on real orders (§3.4). The order-split lookup — the part that decides whether a payout escalates — is **PCD-gated and was not run**. |
| engine → ledger | **Not run at all.** No journal entry has ever been posted to any real ledger by any code in this repository. Xero is superseded (§3.3); the QuickBooks poster is mid-build in another session, currently breaks the boundary test, and has been reviewed by nobody here. |
| the three joined together | **Never.** |

**The honest summary of the gap:** the two ingestion ends were *probed* — real
credentials, real responses, real parsing. That is meaningfully more than "a fake on the
other side", and §3.4 now says so. It is meaningfully less than an end-to-end run,
because a probe reads a response and an end-to-end run carries a specific payout from a
processor through decomposition and a tie-out into a draft entry in a real ledger, and
then proves that entry is right.

**What would actually close this item**, so nobody closes it on less:

1. A real payout, with real balance transactions, decomposed by the engine.
2. Its GST split populated from a real order lookup (⇒ Shopify PCD approval).
3. A draft entry posted to a real ledger and read back.
4. The idempotency tag proven to survive a **repeat** post — the entire
   duplicate-protection story rests on exactly this and it has never been observed.
5. A tie-out failure proven to **block** on that same live path, not just on fixtures.

Item 4 is the one most likely to be skipped and is the one most worth having.

§2.10 remains the longest chain that has actually run
(`Next.js → FastAPI → SQLiteStore → engine`), and both of its ends are still fixtures.

### 4.4 No production deployment — **mostly still true, one clause now false**

> **Corrected 2026-08-06 (evening).** This read *"**No Postgres instance provisioned**,
> no secret manager wired, no tenant onboarded, no container ever built, nothing
> deployed to Vercel."* The first clause is struck: ~~no Postgres instance
> provisioned~~. A **managed Neon instance exists, has `schema.sql` applied, has all
> ten policies present and RLS forced on all eight tables, and has a correctly
> attributed non-`BYPASSRLS` application role** (§3.1).

Precisely what is and is not true now:

- ~~No Postgres instance provisioned~~ → **provisioned and schema-loaded.** But see
  §6c.3: what is deployed on it is **not** what `schema.sql` says, so "provisioned" must
  not be read as "correctly provisioned".
- **No secret manager wired** — still true. The only resolver exercised against a real
  key is `env://`, which is the development scheme, needs two independent opt-ins, and
  is refused outright when the environment names production. Neither cloud resolver has
  ever run (§3.5), so the path that would actually ship remains untested.
- **No tenant onboarded** — still true. The Neon database's tenant tables are empty;
  every scoped read this pass returned zero rows because there is nothing in them.
- **No container ever built** — still true.
- **Nothing deployed to Vercel** — *not* true as written, and it was not true this
  morning either: `HANDOFF.md` §2 records a live public URL. What remains true is that
  **the auth gate is inert** — `proxy.js` fails open when `DEMO_USER`/`DEMO_PASS` are
  unset, and a 401 has never been confirmed. A public unauthenticated demo link is a
  different problem from "nothing is deployed", and the second sentence was hiding the
  first.

`ModelSpec.key_ref` is still an opaque handle by construction, and that property held
under a live run.

### 4.5 Things previously in this section that have since been built

Recorded so the trend is auditable rather than implied:

- **Demo test suite** (was §4.3) — now 178 tests, §2.6. The previous revision called
  this "the largest untested surface in the project"; that is no longer true. The
  largest untested surface is now PostgreSQL (§3.1).
- **HTTP API** — did not exist at the last revision; now 10 routes and 244 tests, §2.8.

---

## 5. What Vansh must do, in order

Only items that **genuinely require a human** are listed. Anything an agent could have
done has been done. Ordering is by *lead time first*, then by how much verification
each unblocks — start the thing with a queue before the thing you control.

### 1. Apply for Shopify Protected Customer Data approval

- **Why blocking:** without it the Shopify order lookup cannot run, and that lookup is
  what lets a Shopify payout resolve without escalating. Exactly half the demo corpus
  is Shopify (14 of 27 payouts; the other 13 are Stripe — recounted 2026-08-23). §3.4 stays unverifiable until
  this clears, and no amount of engineering shortens it.
- **Why first:** it is the only item with a **review queue you do not control**. Every
  other item on this list is same-day once you sit down. Start the clock today.
- **How long:** ~30–60 min to complete the application; **days to weeks** for review.
- **Start here:** https://partners.shopify.com → your app → **API access** →
  **Protected customer data access** → request. Read
  https://shopify.dev/docs/apps/launch/protected-customer-data first; the data-handling
  and retention answers are the part that gets applications bounced.

### 2. Provision a **production** PostgreSQL server

> **This item was rewritten 2026-08-06.** It read *"`schema.sql`, `pg_store.py`, every
> RLS policy and the whole migration runner have **never been executed by a
> database**"* — which contradicted §3.1 in this same document, where three of those
> four were run against PostgreSQL 16.14 in Docker and four defects were found and
> fixed. Docker is running here and the throwaway container is a
> `docker run` away, so the local half of this item is **not blocked on you** and has
> been done. What follows is the part that still is.

> **Updated again 2026-08-06 (evening): a managed instance now EXISTS.** A Neon
> database has `schema.sql` applied, ten policies present, RLS forced on all eight
> tables, and a correctly attributed `vert_app` role. The provisioning half of this item
> is done. **Two new things replaced it, and one of them is a live defect** —
> read §6c.3 before doing anything else here.

- ~~**What is left for you: a managed instance you own**~~ — **provisioned.** Connecting
  to it answered the question this item called *"the highest-consequence unknown in this
  document"*, and the answer was the bad one: **the managed default role
  (`neondb_owner`) has `BYPASSRLS`**, which makes all ten policies inert with no
  symptom. `assert_rls_is_enforceable()` now refuses to boot as such a role. Connect as
  `vert_app`, never as the owner.
- **NEW, and it is a real defect on the live database:** the deployed `payouts` policy
  does not match `schema.sql` and fails **quiet** where every other table fails loud
  (§6c.3). One `CREATE POLICY` fixes the table; the missing drift check between
  committed DDL and deployed DDL is the actual work, and no test in the repo does it.
- **Still genuinely left for you:** behaviour behind a connection pooler (PgBouncer
  transaction mode especially, where defect 4 in §3.1 lives — and note the Neon
  connection string in use is already a **`-pooler`** endpoint, so this is no longer
  hypothetical), and backup/restore/failover.
- **Still unrun even locally:** the migration runner (`migrations.py`). No test in
  `vert_engine/state/tests/test_migrations.py` touches `pg_backend`, so
  `pg_try_advisory_lock` is still assumed and DDL rollback is still unknown. That one
  is agent work against the same throwaway container and does **not** need you.
- **Why you:** provisioning a managed instance needs your account and billing details.
- **How long:** ~20 min (managed).
- **Start here** — the cheap path first:

  ```bash
  open -a Docker            # then wait for the whale icon to settle
  docker info               # must succeed before continuing
  cd /Users/vanshm/Documents/Vert/Accounting/vert-engine
  docker compose up -d postgres
  .venv/bin/pip install -e '.[postgres]'
  psql -f vert_engine/state/schema.sql -d <empty_db>
  ```

  For a managed instance instead: https://neon.tech or https://supabase.com/dashboard
  (both have a free tier sufficient for this).
- **Hand back to an agent** once `docker info` succeeds or you have a connection
  string — the porting of the test fixture and the three SQLite-impossible proofs in
  §3.1 are agent work.

### 3. ~~Create a model API key~~ **DONE** — and a secret manager to hold it, **still open**

> **Half-closed 2026-08-06.** ~~*"No provider has ever accepted a call from this code."*~~
> An OpenAI key was supplied and the whole path has run (§3.2, `AGENT-LIVE.md` §10).
> **What is left is the part that was always the point:** the key resolved through
> `env://`, the development scheme, which needs two opt-ins and is **refused outright in
> production**. So the resolver path that would actually ship is still untested, and
> §3.5 is unmoved. Choosing and wiring the secret manager remains yours.

- **Why still blocking:** §3.5. Neither cloud resolver has run. A deployment cannot use
  `env://`, by design and by refusal, so today there is **no supported way to give a
  production instance a model key.**
- **Why you:** issuing a key requires your account and payment method, and per the
  locked architecture the key must live in a secret manager and **never** in code, env,
  config or a gateway. Choosing the manager is your call.
- **How long:** ~10 min for the key; ~30 min for the secret manager and IAM.
- **Start here:** https://console.anthropic.com/settings/keys → create key. Then AWS
  Secrets Manager (https://console.aws.amazon.com/secretsmanager) or GCP Secret Manager
  (https://console.cloud.google.com/security/secret-manager). Install the matching
  extra: `.venv/bin/pip install -e '.[aws]'` or `'.[gcp]'`, plus `'.[litellm]'`.
- **Critical check, do not skip:** a call that succeeds with `key_ref=None` means
  LiteLLM found an ambient key — the exact failure mode that module exists to prevent.
  Supply the key **only** through the injected `SecretResolver`, never the environment.

### 4. ~~Obtain Stripe and Xero credentials~~ → **Stripe DONE. Xero SUPERSEDED. Now: QuickBooks + a Stripe account with real payouts**

> **Rewritten 2026-08-06 (evening).** Two of the three premises changed the same day.
>
> - ~~Stripe credentials~~ — **supplied, and the live API answered** (§3.4). The
>   chargeback finding came out of exactly this.
> - ~~Xero~~ — **superseded, not deleted** (§3.3). QuickBooks is first; the reason is
>   architectural and is written down there. Do **not** spend the ~30 minutes on the
>   Xero OAuth dance right now.

- **What is actually blocking now, in order:**

  1. **A QuickBooks Online developer account and a sandbox company.** This is the new
     item 4 and it is the one that unblocks the highest-value unrun test in the whole
     project: **whether the content-derived idempotency tag survives a real round trip.**
     Post a draft, post it again, and prove you get the existing journal back rather
     than a duplicate. Use the **sandbox**, never a real ledger.
     Start here: https://developer.intuit.com → create an app → sandbox company.
  2. **A Stripe account that actually has payouts in it.** The current test account has
     **zero**, so pagination, `expand[]=data.source` and payout-scoped fetching remain
     unexercised (§3.4). Triggering a test payout is enough; this does not need a
     production account.
- **Why you:** account ownership and OAuth consent against a real org.
- **How long:** ~30 min QuickBooks (app + sandbox + OAuth); ~10 min to generate Stripe
  test payouts.
- **Note on Stripe key hygiene:** the key in use is a **test** key. When a restricted
  key is issued for anything real, make it read-only on Balance/Payouts/Charges —
  nothing in the engine needs write on Stripe.

### 5. Create a Vercel token and set the demo auth pair

- **Why blocking:** §3.7. Nothing has ever been deployed, and `proxy.js` **fails open**
  when `DEMO_USER` / `DEMO_PASS` are unset. A public link right now would be
  unauthenticated.
- **Why you:** the token is account-scoped and the credentials are yours to choose.
- **How long:** ~10 min.
- **Start here:** https://vercel.com/account/tokens → create token. Then set
  `DEMO_USER` and `DEMO_PASS` in the project's environment variables and **confirm a
  401 before sharing the link with anyone.** That confirmation is the deliverable, not
  the deploy.
- **Lowest priority:** it gates a demo, not correctness. Items 1–4 gate whether the
  product works.

### Not on this list, on purpose

Porting the store fixture to Postgres, writing the RLS row-filter tests, building the
Docker image, wiring the resolver, updating this document — all agent work, all blocked
only by items 1–5 above. Do not do any of it yourself.

---

## 6. Documentation drift found during this run

Recorded rather than silently corrected, because a status document that edits away its
own errors is not a status document.

> **Three sub-lists, in time order.** §6a is the 2026-08-06 **morning** drift list; §6b
> is the standing dead-capability list (exported, documented, called from nowhere); §6c
> is the 2026-08-06 **evening** list and contains the two findings most worth acting on —
> the deployed-vs-committed RLS divergence (§6c.3) and the live-model proof that no
> number moves (§6c.2). The numbered items immediately below predate all three.

1. **Test count** — the previous revision's headline of **669 passed** is stale; the
   suite now reports **1774 passed, 1 skipped**. Growth, not regression.

2. **"The demo has no automated tests"** (previous §4.3) — **no longer true.** 133
   tests, §2.6. The accompanying warning that the three-gate guarantee "has no
   regression test" is also now obsolete.

3. **"No HTTP library is imported anywhere in the engine"** (previous §2.9) — the grep
   as written now has **one match**: `vert_engine/state/migrations.py:97: from
   urllib.parse import urlsplit`, used to redact credentials from a DSN before logging.
   It is string parsing and reaches no network, but the previously stated command no
   longer returns empty and the claim has been restated precisely in §2.11 rather than
   repeated.

4. **"Runtime dependency is pydantic alone"** — still **true of the declared base
   dependency**, but the venv now contains fastapi, uvicorn, starlette, httpx and
   opentelemetry. All are declared as **optional extras**, not base dependencies
   (§2.11). Worth restating carefully, because "pip list is short" and "the dependency
   list is short" are no longer the same claim.

5. **Carried forward, still unfixed in HANDOFF.md** — §2 there states SP-BROKEN *"fails
   4 of 6 verifier checks"* (it fails **3**), and *"nine routes"* (there are **ten**).
   Both were reported in the previous revision and neither has been corrected.

   *(2026-08-06: the "4 of 6" claim has now been corrected in HANDOFF.md. The "nine
   routes" claim is not in HANDOFF.md and appears never to have been — this entry was
   itself wrong on that half.)*

### 6a. Drift found on 2026-08-06

Everything in this sub-section was found by re-running the commands this document
already cites. Each was corrected in place above **and** named here.

1. **§2.5 demo-export determinism was FALSE.** The committed
   `vert-demo/lib/engine-output.json` no longer matches a fresh export. Six values on
   `SP-9001` differ and the engine is the correct side of the difference; the file
   carries a GST figure the engine's own fixture comment calls understated. Two fresh
   exports still agree byte-for-byte, so determinism itself holds. **The single most
   consequential item in this revision** — it is a wrong number on screen, and no test
   in either suite would ever notice.

2. **Test counts.** Engine `1774` → **2073** (Postgres up) / **1940 passed, 134
   skipped** (no server). Demo `133` → **178**. Observability `292` → **294**.
   API `244` → **271**. The engine total moved by 8 *during this session*; §2.1
   records why, and why that matters more than the digit.

3. **Benchmark correctness `0.9900` → `1.0000`, false escalations `1` → `0`,** and the
   authored auto-resolvable ceiling `32` → `31`. Corpus grew from 42 to **50 cases, 42
   graded**. Auto-resolution (90.7% / 73.8%) and silent errors (0) did not move.

4. **§2.11 "`psycopg` is not installed"** — false; 3.3.4 is installed.

5. **§5 item 2 contradicted §3.1** in this same document, telling Vansh that Postgres
   had never been executed when §3.1 records it being executed. Rewritten.

6. **Two previously-reported dead exports are now genuinely wired** and the docs that
   still call them dead are wrong: `require_same_tenant()` is called at
   `vert_api/deps.py:253` and `vert_engine/tenancy/fastapi_dep.py:177`, and the critic
   now sends its schema (`vert_agent/critic.py:241,291`). Both fixes are real. HANDOFF
   §6 still listed the first as unwired; corrected there.

7. **Newly found dead capability, not fixed, reported only** — see the remaining-work
   note in §6b.

### 6b. Exported, documented, called from nowhere in production

The same shape as `require_same_tenant()` and the critic's `json_schema=None`, found by
scanning every public definition and every `__all__` entry for a substantive
non-import reference in non-test source. Reported, not fixed.

| Symbol | Defined | Consequence |
|---|---|---|
| `install_logging_filter` / `install_redacting_excepthook` | `vert_agent/secrets/redaction.py:474,514` | Installed **only** by the CLI (`vert_agent/run.py:770-771`). `vert_api` imports `redaction` nowhere, yet `vert_api/errors.py:371` logs unhandled exceptions with `exc_info=exc` — a full traceback. The credential-redaction guarantee is a property of the CLI, not of the service. **Highest-risk item here.** |
| `Store.verify_audit_trail` | `vert_engine/state/store.py:833` | Tamper evidence over the hash chain, never invoked outside tests. `vert_api/errors.py:270` maps `AuditChainBroken` → HTTP 500 and that branch is unreachable; `/ready` reads `audit_log` but never verifies it (`vert_api/readiness.py:133`). A corrupted chain is detected by nobody. |
| `Store.resolve_proposal` | `store.py:764`, `sqlite_store.py:945`, `pg_store.py:897` | The documented path for a human to accept or dismiss a queued proposal. There is no proposals router in `vert_api/routers/`, so `ProposalState.accepted` and `.dismissed` are unreachable in production and every proposal stays `queued` forever. |
| `StratumResult.auto_resolution_rate` / `.silent_error_rate` / `.correct_decline_rate` / `.false_escalation_rate` | `vert_bench/runner.py:151-164` | Four rate properties on the object `run()` returns, computed nowhere in production — `report.py` builds its `RateSummary`s from `_ratio` directly (`runner.py:336-342`). Two implementations of the headline metric, only one of them exercised. |
| `TenantContext.is_live` / `.log_fields` | `vert_engine/tenancy/context.py:151,154` | `is_live` is documented as the thing that stops a test key posting a real journal entry; nothing calls it. `log_fields` is documented as the single implementation of "what is safe to log"; nothing calls it either, so every log site decides for itself. |
| `TEST_KDF` | `vert_engine/tenancy/keys.py`, re-exported from `vert_engine/tenancy/__init__.py` | A deliberately weak KDF for tests, on the package's public surface. 37 test references, zero production. Nothing stops a production import. |
| `format_redacted_exception` | `vert_agent/secrets/redaction.py:394` | Redundant rather than dangerous: `RedactingFilter` and the excepthook already do this job. A second implementation nothing calls is a second implementation to drift. |
| `money.cents_to_dollars` / `money.is_balanced` | `vert_engine/money.py:29,45` | `cents_to_dollars` returns a **float** in a codebase whose whole rule is integer cents. Unused; a live import waiting to happen. |
| `strata.anchor_total` | `vert_bench/strata.py:180` | No caller and no test. |

---

### 6c. Drift found on 2026-08-06 (evening pass)

Everything here was measured in this pass. Items 1 and 3 are new failures; item 2 is a
new *proof*, recorded because a document that only logs bad news is also miscalibrated.

**1. ~~The engine suite is RED~~ — appeared and was RESOLVED inside this pass. Kept
because the sequence is the lesson.**

Mid-pass: `1 failed, 1943 passed, 134 skipped`. The failure was
`tests/test_boundary.py::test_vert_engine_never_imports_vert_connect`, caused by a
QuickBooks poster under construction in another session naming
`vert_connect.quickbooks_http` in two **docstrings**
(`vert_engine/posting/quickbooks.py:102,191`). No import existed; the check is
deliberately cruder than an import graph, on the reasoning that a docstring naming a
transport is how a real import eventually arrives.

End of pass: **`2185 passed, 1 skipped`.** The other agent removed the module paths from
the prose and **added four further boundary tests** (16 → 20). That is the correct
resolution — the alternative, teaching the check to ignore docstrings, would have been a
loosening, and this project's rule is that a guard which rejects is a guard working.

**Three things worth extracting from this, none of them about the bug:**

- **The guard did its job on a live in-flight change**, which is more than most such
  tests ever get to demonstrate.
- **The response strengthened the check rather than the codebase's excuses for it.**
- **The suite's headline moved 1940 → 1943 → 2185 → 2189 during a single documentation
  pass**, the last two on the same command minutes apart. Any count in this document is
  a photograph. §2.1 says so; this is the proof, and it is why §2.1 now refuses to state
  one.

**Caveat that survives the fix:** the boundary tests remain a *string* check over source
text, not an import-graph check. That is a deliberate over-approximation and it will keep
producing failures like this one. It is the right trade — but nobody should be surprised
by it a second time, and nobody should quietly narrow it when it fires.

**2. The architectural lock survived contact with a real model — and this is the single
most valuable measurement in this revision.** The full demo export was run twice: once
scripted, once against live OpenAI. Then everything except the agent narration was
compared:

```
everything EXCEPT the agent block identical: True
bankLines identical : True
payoutIds identical : True
```

The live agent block differs completely — different provider, different model, genuinely
different prose, `"live": true` vs `"live": false`, and `attempts: 2` vs `1` (the live
model needed a reask; the guards bit). **And not one number moved.** `SP-BROKEN` carried
the identical exception under both:

```
scripted: [{'type': 'payout_integrity_break', 'detail': "Parts don't sum to the payout (off by $150.00 AUD).", ...}]
live    : [{'type': 'payout_integrity_break', 'detail': "Parts don't sum to the payout (off by $150.00 AUD).", ...}]
```

A real LLM ran over a blocked payout, queued a proposal, and **could not clear the
block or alter a figure.** "The model never computes or writes a number" and "LLM output
queues only and can never clear a block" have been demonstrated against a live provider
rather than argued from code review.

**3. THE DEPLOYED RLS POLICY DOES NOT MATCH `schema.sql`, AND THE MISMATCH IS ON THE
PRIMARY LEDGER TABLE.** New, unreported anywhere else, and the most consequential
finding of this pass.

`schema.sql:700-704` creates the payouts policy with the **raising** helper:

```sql
CREATE POLICY payouts_tenant_isolation ON payouts
    FOR ALL
    USING (tenant_id = vert_current_tenant())
    WITH CHECK (tenant_id = vert_current_tenant());
```

The policy **actually deployed** on the managed database reads:

```
payouts   payouts_tenant_isolation   PERMISSIVE  cmd=ALL  roles=['public']
            qual=(tenant_id = current_setting('vert.tenant_id'::text, true))
            with_check=(tenant_id = vert_current_tenant())
```

The `USING` clause has been replaced with the bare `current_setting(..., true)` form.
**No committed DDL anywhere in this repository produces that clause** — the only other
occurrence of that expression in the source tree is *inside* the body of
`vert_current_tenant()` itself (`schema.sql:619`), which then raises. So this was
changed on the server, not by applying the schema.

**The behavioural consequence, measured on the live database as `vert_app`:**

```
  payouts              NO TENANT DECLARED -> returned 0 rows  <-- fails QUIET
  journal_entries      NO TENANT DECLARED -> RAISED  <-- fails LOUD
  approvals            NO TENANT DECLARED -> RAISED  <-- fails LOUD
  proposals            NO TENANT DECLARED -> RAISED  <-- fails LOUD
  audit_log            NO TENANT DECLARED -> RAISED  <-- fails LOUD
  tenants              NO TENANT DECLARED -> RAISED  <-- fails LOUD
```

`payouts` is the odd one out, and it is **the close register** — the table the whole
product is about.

**Scope it honestly: this is a fail-quiet, not a cross-tenant leak.** With a tenant
set, `tenant_id = current_setting(...)` filters correctly; with none set,
`tenant_id = NULL` is NULL and the row is filtered, so no other tenant's rows are
exposed. The write side still uses the raising helper, so writes cannot land untagged.

**But it is the exact failure `schema.sql` says in capitals it must not do.** From the
function's own comment block (`schema.sql:606-613`):

> *"IT RAISES INSTEAD OF RETURNING NULL, and that is the most important decision in this
> section. … an unscoped query silently returns ZERO ROWS. For this product an empty
> result is not a safe failure — it reads as **'this customer has no payouts to close'**,
> which is a correct-looking answer to the wrong question, at month end. Loud beats
> empty every time."*

A forgotten `set_config` against the deployed database produces a clean, empty,
correct-looking close on the one table where that is most dangerous.

**Why nothing caught it:** no test in the repository reads deployed policy DDL.
`grep -rn "pg_policies" --include="*.py"` over the whole tree returns **nothing**.
`test_rls.py` (79 tests) parses `schema.sql`; `test_rls_live.py` (32) executes against a
container built *from* `schema.sql`. Both verify the file. Neither verifies the server.
**A live database can drift arbitrarily far from the committed schema and every one of
the 111 RLS tests stays green.** That missing check is a bigger finding than the single
bad policy.

**Not fixed here.** Fixing the deployed policy is one `CREATE POLICY`; the drift check
is the real work, and changing production DDL is not a documentation pass's business.

## 7. The honest one-paragraph summary

> **Rewritten 2026-08-06 (evening).** The previous version is preserved immediately
> below it, struck, because it was accurate this morning and the record of what we
> believed and when is worth keeping.

The deterministic engine is real, measured, and has been observed to fail when
deliberately broken — 161/161 on the release gate, 90.7% weighted auto-resolution with
zero silent errors across 50 authored cases (42 graded), and a mutation sweep that
catches all four seeded defects. **Its central architectural claim is no longer just
argued from code review: a real OpenAI model was run over the entire export and changed
the narration while leaving every single number byte-identical, and it could not clear
the block on `SP-BROKEN` (§6c.2).** That is the thing this project exists to be able to
say, and it is now measured. Against that: **the suite is red** (§6c.1, another agent's
in-flight poster tripping a boundary guard — the guard is working), **the committed demo
export still shows an understated GST figure** that neither test suite can see (§2.5),
and **the RLS policy deployed on the managed database is not the one in `schema.sql`** —
on `payouts`, the close register, it fails quiet where every other table fails loud
(§6c.3), and no test anywhere reads deployed DDL. Of the outside-world seams, PostgreSQL,
a live model, live Stripe and live Shopify have now all met the real thing; **no ledger
has**, Xero is superseded by QuickBooks (§3.3, and the reason is that `JournalLine` is
flat and NetSuite/Sage need dimensions), both cloud secret managers are unrun, and **no
payout has ever made the full trip end to end** (§4.3 — still open, and not to be closed
by anyone who has not watched it happen). Most of what remains on the critical path
still requires Vansh (§5); the longest pole is unchanged and is the Shopify PCD
application, because it is the only item with a queue you do not control.

> ~~**Superseded 2026-08-06 evening.** The deterministic engine is real, measured, and
> has been observed to fail when deliberately broken — 2073 tests, 161/161 on the release
> gate … The product's central claim holds on all three surfaces … **The one thing that
> is currently wrong is on screen:** the committed demo export has drifted from the
> engine and understates GST on `SP-9001` … Stripe, Shopify, Xero, both secret managers
> and every deployment artefact remain **reviewed seams with a fake on the other side**
> … The demo's agent narration is authored theatre and must be declared when demoing.~~
>
> Struck because four of its claims stopped being true the same day: the suite is no
> longer all-passing, "the one thing wrong" is no longer one thing, Stripe and Shopify
> are no longer fakes, and "the narration is theatre" is now only partly true (§4.2).

---

## 8. RELEASE READINESS — what a customer could rely on today

**Read this section as the verdict and the rest of the document as its evidence.** It is
written for the question "what happens if someone starts using this on Monday", not for
the question "how much has been built".

### 8.1 What a customer could rely on today

These are load-bearing, measured, and would survive a hostile review:

- **The arithmetic, and its refusal to guess.** Integer cents end to end, 161/161 on the
  release gate, **0.0% silent errors** across 42 graded cases. The engine either gets a
  payout right or declines it. For an accountant that is the only number that matters,
  and it is the one to quote first.
- **A blocked payout stays blocked.** A payout that does not tie is refused by the
  engine, by the demo, by the API with a 409 that explains how to clear it — **and now
  by the live-model path too.** The model queued a proposal against `SP-BROKEN` and the
  block did not move (§6c.2).
- **The model cannot touch a number.** Demonstrated, not asserted: swap in a real
  provider and the numbers are byte-identical (§6c.2).
- **Deterministic-only is a complete deployment.** Turning the agent off loses proposals
  and nothing else. `VERT_AGENT_ENABLED=0` is a supported configuration, not a degraded
  one.
- **The benchmark can detect a broken engine** — 4/4 seeded defects caught, three of
  them *only* by externally authored ground truth. An eval that has never been observed
  to fail is decoration; this one has been.
- **Nothing reaches the wire by accident.** No HTTP library is importable from
  `vert_engine`; live transports live in `vert_connect` and depend on the engine, never
  the reverse. The guard is currently *failing loudly* over a docstring (§6c.1), which
  is the system working as designed.

### 8.2 What would embarrass us today

In the order it would happen:

1. **The demo shows a wrong GST figure right now.** `SP-9001` renders $900.00 where the
   engine computes $909.09 (§2.5). It has been known since this morning and is one
   command to fix. If a prospect recomputes GST on a $10,000 GST-inclusive payout in
   their head — and the ICP can — this is the worst possible number to have wrong, in
   the demo's showcase "clean" payout. **Regenerate before any demo.**
2. **The live database's payouts table fails quiet.** A forgotten tenant scope returns
   "no payouts to close" instead of raising (§6c.3). Nobody has been harmed because
   there is no data in it yet. That is timing, not safety.
3. **The public demo link has an inert auth gate.** `proxy.js` fails open when
   `DEMO_USER`/`DEMO_PASS` are unset and a 401 has never been confirmed (§3.7, §4.4).
4. **Credential redaction is a property of the CLI, not the service.** The scrub that
   catches a provider echoing a key back is installed only in `vert_agent/run.py`, while
   `vert_api/errors.py:371` logs full tracebacks (§6b). Structural protections still
   hold; the substring scrub does not.
5. **A queued proposal can never be resolved.** No proposals router exists, so a human
   cannot accept or dismiss one (§6b). The propose-only rule is intact; the human's half
   of it is missing — which is awkward, because the human is the entire point.
6. **The audit chain is never verified by running code** (§6b). Tamper evidence that
   nothing checks is a hash, not evidence.

*(A red test suite sat at position 3 of this list for part of the evening and was fixed
before the pass ended — §6c.1.)*

### 8.3 What is still unproven

Not broken — *unmeasured*. Do not let these be described as "done" without evidence:

| Unproven | Why it matters |
|---|---|
| **A full live run, processor → engine → ledger** | Never happened (§4.3). Both ends have been probed; the chain has not been joined. |
| **Idempotency across a real repeat post** | The entire duplicate-protection story rests on it and it has never been observed against any real ledger. The single most valuable unrun test in the project. |
| **QuickBooks, at all** | Mid-build in another session, currently red, reviewed by nobody here (§3.3). |
| **NetSuite / Sage** | Blocked on a core model change, not an adapter — `JournalLine` cannot express a dimension (§3.3). Do not scope these as integrations. |
| **Shopify order split** | PCD-gated. It is the part that decides whether a Shopify payout escalates, and it is exactly the part not yet runnable (§3.4). |
| **Stripe at volume** | The test account has zero payouts; pagination and payout-scoped fetching are unexercised (§3.4). |
| **Anthropic as a provider** | Only OpenAI has answered, and the capability table was originally written from memory (§3.2). |
| **Both cloud secret managers** | Only `env://` has resolved a real key, and `env://` is refused in production (§3.5). |
| **The migration runner** | Still never executed against any server, local or managed. `pg_try_advisory_lock` is assumed and DDL rollback is unknown (§3.1). |
| **Postgres behind a pooler** | Defect 4 in §3.1 is precisely the bug class that lives there, and no pooler has been involved. |
| **Agent proposal quality with a human** | The one number that decides whether the agent is worth having — how often a working accountant accepts a proposal — has a reserved slot and no data. |

### 8.4 The one-line verdict

**The deterministic core is defensible today and the propose-only architecture has now
been proven against a real model. Nothing that touches a customer's ledger is ready, and
the two things currently red are both fixable this week.** The gap between this project
and a product is not engine quality — it is that no payout has yet made the whole trip,
and that the checks guarding the *deployed* system are weaker than the ones guarding
the *committed* one.

---

## 9. The 2026-08-06 FINAL PASS — the product walked as a bookkeeper

**What this pass did.** Both suites and the benchmark were re-run; the whole stack was
brought up **authenticated** against Neon with a live QuickBooks ledger and a live sync
worker; and the product was then driven end to end **in a real headless Chrome with real
keystrokes and real mouse clicks** — not curl, not a Server Action invoked over HTTP,
not a rendered component asserted in a test. Sign in, press Sync, read the close, open a
payout, approve it, post it.

### 9.1 Measurements, re-run

| | Result |
|---|---|
| Engine suite | `2505 passed, 1 skipped` (`.venv/bin/python -m pytest -q`) |
| Demo suite | `278 passed, 0 failed` (`npm test`) |
| Benchmark | **88.1% weighted / 72.1% unweighted auto-resolution, 31 of 43 graded** — **beside 0.0% silent error (0/43)** and 11.9%/27.9% correct declines, over the declared stratum mix the report prints (42% S1 plain Stripe, 16% S2 refunds, 14% S4 Shopify split, …). Those weights are **declared assumptions, not measured prevalence**, and reweighting them moves every weighted figure without a case changing. Do not quote the first number alone. |

The engine and demo counts are higher than the brief's baseline (2329/1 and 199) because
peer agents added tests during the day, and higher again by the 15 this pass added.

### 9.2 What was fixed, with the mutation that proves each test bites

Every fix below was reverted after the test was written, the failure observed, and the
fix restored. Where the defect was found in a browser, the browser evidence is named.

1. **The Post button did nothing at all.** `lib/decisions.js` built the `post` callback
   and left it out of the object `useDecisions()` returned, so `decisions.post` was
   `undefined` and the click threw a `TypeError` inside React's handler — no request, no
   pixel, on the one irreversible control in the product. One line. The suite reported
   the same 268 passed with and without it, because every existing test read source
   text. `tests/posting.test.js` now renders the hook and asserts that **every**
   `decisions.<name>` the screens reach for is something the hook hands out.
   *Proved fixed by clicking it: JournalEntry 151 in the live QuickBooks sandbox.*

2. **A write control was offered on a payout the engine had blocked.** The gates read
   `verdict.blocked` — the demo's own recomputation of **six** tie-outs — while the
   engine raises more exceptions than six. Driven live: `po_8Hm` is `blocked` on
   `unclassified_txn`, no local check fired, "Approve draft entry" rendered **enabled**,
   a real click sent the request, and the API answered **409**. The engine gate held, and
   it is the one that matters — but the bookkeeper met an error where a disabled control
   and a reason belonged. `lib/feeds.js blockedForDisplay` now applies the rule the
   module already stated for `approved`: *when the database has an opinion it is the
   only opinion*, and the local verdict may add a block, never clear one.

3. **"$0.00 unexplained."** The blocked copy assumed every block is an amount break. On
   the live Neon payout the screen read "…$916.15 against a declared deposit of $916.15
   — $0.00 unexplained" and "Approval stays closed until the $0.00 difference above is
   explained", while the real reasons — `gst_undetermined`, `bank_unmatched` — went
   unmentioned. It now says the parts tie, names the checks that did not, and surfaces
   the engine's own `statusReason`, which was in the payload all along and never read.

4. **"AI Generated" on a deterministically drafted entry — the first architectural rule,
   inverted, on the highest-stakes screen.** The approvals pane badged every draft "AI
   Generated", the queue card repeated it, and the six deterministic tie-outs were headed
   "AI Reasoning". All three were hardcoded literals, false in every mode. On the live
   deployment the agent is **OFF** and the payload carries no `agent` block at all, so the
   screen was crediting a model that was not running with figures `vert_engine/journal.py`
   computed. Now "Drafted by Vert" and "Vert's checks"; the queue filter formerly labelled
   "AI" (its predicate is `confidence.band === "high"`, arithmetic) is "Confident".
   `tests/provenance.test.js` **forbids the words** rather than expecting the replacements.

5. **Every screen was headed "June 2026" over August books.** `GET /payouts` returned
   `fixtures.PERIOD` — a constant in the demo corpus — for every tenant. It was not only
   a wrong caption: vert-demo ages the exception register against the end of the close
   month, so **every open exception read "-37 days open"**. `queries.register_period`
   now derives it from the register's own arrival dates, over the *whole* register so a
   filter cannot re-date the books, and returns **null** rather than guessing when a
   register straddles a month end. Live, the header now reads "August 2026" and days
   open reads 25.

6. **Python identifiers on the bookkeeper's screen.** Pressing Sync with a missing
   credential produced, verbatim on screen: `SystemExit: STRIPE_SECRET is not set.`
   The worker now keeps the class name in the operator's log (`diagnosis`) and serves
   the exception's own sentence (`message`); `SyncReport` strips a leading identifier
   as well, because it renders a string another process produced. The demo test that
   *encoded* this defect — it asserted `/StripeHttpError: 503/` as the expected on-screen
   text — is replaced by one that forbids the whole class of them.

7. **Vert's own operation name attributed to the vendor.** The sync report said
   *"Shopify could not be read … Its own words: `VertShopifyPayoutsPage`: GraphQL
   reported errors: Access denied…"*. `VertShopifyPayoutsPage` is our GraphQL operation
   name, printed inside the one phrase that promises verbatim quotation.
   `_vendors_own_words` strips our prefix at that boundary and nowhere else, so the log
   and the traceback keep it.

8. **A posted payout was badged "Reconciled".** `STATUS_TONE` had no `posted` key, so an
   entry sitting in a customer's trial balance was labelled with the state it was in
   before the irreversible act, beside a body correctly reading "In QuickBooks Online —
   JournalEntry 151". The most consequential state in the system now has a word.

9. **`schema.sql` never granted `USAGE ON SCHEMA public`.** Every table grant is inert
   without it. Invisible on stock PostgreSQL, which leaves PUBLIC holding it — **verified
   both ways**: with PUBLIC's USAGE revoked on a local `postgres:16`, `vert_authenticator`
   cannot read `api_keys`. Neon revokes it, so following `onboard.py`'s remedy exactly
   produced a service that booted and failed every request. The grant is in `schema.sql`
   and the line is in all three remedy texts.

10. **A doubled full stop** — `Invalid or missing API key.. Expected 200 with a JSON body.`

### 9.3 WHERE A BOOKKEEPER STILL NEEDS A TERMINAL — the deliverable

Walked signed-in, on the live authenticated stack, in a browser. In order of how early
they bite.

1. **Getting a key at all.** `python -m vert_engine.tenancy.onboard provision` then
   `issue-key`. This is *correct* — onboarding is an owner act and `vert_app` deliberately
   holds no DDL and SELECT-only on `tenants` — but it means **a customer cannot become a
   customer without someone at Vert running two commands.** There is no self-serve signup
   and no operator console. This is the first thing between here and a beta.
2. **Connecting Stripe, Shopify or QuickBooks.** There is no connect flow. Every
   credential is a process environment variable read at boot (`STRIPE_SECRET`,
   `SHOPIFY_TOKEN`, `VERT_QBO_*`), so **connecting a customer's accounts is an edit to a
   deployment and a restart.** The QuickBooks refresh token also *rotates on use* and is
   not persisted — a restart after a rotation needs the connection re-authorised by hand.
3. **Choosing which bank account to read.** `sync_bank_lines` exists and works against
   real QuickBooks data, but which `Account.Id` to read is stored nowhere and there is no
   table for per-tenant connection configuration. It has no route and no button; its only
   caller is a `python -m` entry point.
4. **Resolving any block.** This is the largest gap. **There is no route and no control
   that clears an exception.** The sync report tells the bookkeeper "Supply the tax
   component per charge (Shopify order data or Stripe Tax), or confirm the supplies are
   GST-free" — and the product offers no way to do either. On the exceptions register
   the "Investigate" action is an `<a href>` back to the payments register: a loop. So on
   the live tenant **every payout is permanently blocked from the UI**, correctly and
   unfixably. The engine's own refusal even names the remedy as an HTTP call — *"re-running
   `POST /payouts/po_8Hm/reconcile`"* — on a screen that has a "Re-run reconciliation"
   button three inches away.
5. **`/settings` is empty in API mode.** It renders its heading and its description —
   "which processors are connected and which clearing account each one pays into, how
   close a deposit has to be before it counts as a match, and which model the agent may
   consult" — and then nothing. Every setting it names is an environment variable.
6. **Sign out everywhere.** Documented in `lib/session.js` as `onboard revoke`. Correctly
   *not* built as a button, since no server-side session record exists — but the control
   a customer would ask for is a shell command.
7. **Seeing the worker's progress log.** `run_sync`'s `emit()` goes to a logger uvicorn
   installs no handler for, so at INFO nothing is emitted.

### 9.4 Re-verified on Neon, and now green

Three findings in `ONBOARDING.md §5` and one in `§6c.3` were fixed by other passes during
the day. Measured directly this pass, as `vert_app`:

* `vert_authenticator` **has LOGIN** (§5.1 resolved) — authenticated traffic served.
* The `payouts` policy is `tenant_id = vert_current_tenant()`, the **fail-loud** form, and
  all 13 deployed policies match `schema.sql` exactly (§5.2 / §6c.3 resolved).
* `vert_app` holds **no DELETE** on any table (§5.3 resolved).
* The guard is live, not merely present: a `SELECT` on `tenants` outside a tenant-scoped
  transaction was refused with `insufficient_privilege` and the policy's own sentence.

**Still not closed:** there is no automated drift check between `schema.sql` and a
deployed database. All four of the above were found by hand and could regress the same way.

### 9.5 Corrections to earlier claims

* **"There is no configuration in which a bookkeeper can both sign in and press Post"** —
  false. `VERT_REPOSITORY=fixtures` with a PostgreSQL store *and* `VERT_AUTH_DATABASE_URL`
  boots authenticated with a ledger attached; so does a Postgres store seeded through
  `run_payout`. This pass signed in with a real scrypt-verified key and posted from the
  browser.
* **The brief's own run recipe produces a product nobody can enter.** With
  `VERT_ALLOW_UNAUTHENTICATED=1`, the demo is in API mode, so every route redirects to
  `/login` — and `/login` then correctly refuses, because there is nothing to
  authenticate against ("This Vert service is running with authentication switched off,
  so there is nothing to sign in to"). Each half is right; together they are a locked
  door. **Develop against the demo with `NEXT_PUBLIC_VERT_API_URL` unset (static mode),
  or run the API authenticated.** See `DEPLOY.md §8.2`.
* `fixtures.BUSINESS` is **still** returned as the register's `business` for every tenant
  (`vert_api/routers/payouts.py`), so a second tenant's screens are headed
  "Northwind Retail Pty Ltd". Left deliberately: the fix needs a `display_name` accessor
  on `Store` and therefore edits to `store.py`, `pg_store.py` and `sqlite_store.py`, all
  of which had uncommitted work from other sessions. `tenants.display_name` exists and
  `vert_app` may already SELECT it, so this is small — it is just not *contained*.
